package com.invfix.flat.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxScreen;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/**
 * Импакт-кадры 3D-2D: Attack — как у Tesseract в The Shooting Star 1.4.3 (TesseractFx, удар с
 * последовательностью кадров: в декомпиляции — v#a(ScreenFx, float, int[], int, Vec3, float, float)):
 *  - белая вспышка на 0,05 с;
 *  - кадры по 1/12 с из спектральных режимов композита (27–32 — спектр, 33 — призма, 34 — полосы, 35 —
 *    изометрический каркас), центр — цель; картинка покадровая, 12 кадров/с; зум-размытие через кадр
 *    0,9 / 0,25;
 *  - радужная вспышка палитры Tesseract, гаснущая за ~1 с; тряска, аберрация, свечение — те же окна.
 *
 * Последовательности — тоже из Tesseract: на 60 с — удар «G» ({30, 35, 34, 30, 27, 32}), граффити —
 * финальный «I» ({35, 33, 27, 34, 30, 29, 32, 31, 28, 35}). Сила — по расстоянию до камеры.
 */
@OnlyIn(Dist.CLIENT)
public final class FlatImpactFx extends FxEffect {

    private static final int[] PLANE = {30, 35, 34, 30, 27, 32};
    private static final int[] GRAFFITI = {35, 33, 27, 34, 30, 29, 32, 31, 28, 35};
    /** Палитра вспышек Tesseract. */
    private static final int[] SPECTRUM = {0xFF222C, 0xFF8010, 0xFFE21E, 0x28EC54, 0x1C84FF, 0x5430FF, 0xBA3CFF};
    private static final float FRAME = 1.0F / 12.0F;
    private static final float LENGTH = 2.5F;
    private static final double REACH = 96.0;

    private final Vec3 at;
    private final int[] modes;

    public FlatImpactFx(Vec3 at, boolean graffiti) {
        this.at = at;
        this.modes = graffiti ? GRAFFITI : PLANE;
    }

    @Override
    protected int duration() {
        return (int) (LENGTH * 20.0F) + 1;
    }

    @Override
    public Vec3 focus() {
        return at;
    }

    @Override
    public double range() {
        return REACH;
    }

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        float t = ticks(frame) / 20.0F;
        if (t < 0.0F || t >= LENGTH) return;
        float s = (float) Mth.clamp(1.0 - frame.camera().distanceTo(at) / REACH, 0.25, 1.0);
        if (t < 0.05F) {
            screen.addFlash(0xFFFFFF, 4.5F * s);
        } else if (t - 0.05F < modes.length * FRAME) {
            impactSequence(screen, t - 0.05F, at, s, FRAME, modes);
            int step = (int) ((t - 0.05F) / FRAME);
            screen.stepFps = screen.stepFps > 0.0F ? Math.min(screen.stepFps, 12.0F) : 12.0F;
            screen.zoomBlur = Math.max(screen.zoomBlur, (step % 2 == 0 ? 0.9F : 0.25F) * s);
        }
        screen.addFlash(SPECTRUM[(int) (t * 9.0F) % SPECTRUM.length], (float) Math.exp(-t * 5.0) * 0.8F * s);
        screen.shake = Math.max(screen.shake, window(t, 0.0F, 0.02F, 0.5F, 2.0F) * 1.2F * s);
        screen.aberration = Math.max(screen.aberration, window(t, 0.0F, 0.02F, 0.4F, 1.5F) * 1.2F * s);
        screen.bloom = Math.max(screen.bloom, 0.75F * window(t, 0.0F, 0.1F, 1.0F, 2.5F));
    }
}
