package com.invfix.flat.client;

import com.invfix.flat.Flat;
import com.invfix.flat.FlatFrame;
import com.invfix.flat.FlatState;
import com.invfix.flat.FlatSurface;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;

/**
 * Рисунок 3D-2D, «нарисованный» по поверхности: каждая вершина модели проецируется на плоскость
 * рисунка (вдоль нормали — вид как есть, с поворотом тела на все 360°) и укладывается на поверхность
 * блоков, огибая края, — как картинка, наклеенная на блоки:
 *  - за краем стены в пустоту (наверху, сбоку) — загибается на ребро блока (на крышу, на боковую грань);
 *  - упирается в блок впереди (пол под стеной, стена у пола) — загибается на него.
 * Поэтому ничто (уши, руки, голова при повороте) не торчит за пределы блоков.
 *
 * Укладка — по прямой от ног рисунка: сначала вдоль «вверх» рисунка, потом вбок; на каждой границе
 * клеток — продолжение по той же плоскости, внутренний или внешний загиб. Большие грани модели
 * дробятся на сетку (до {@link #CELL} блока), чтобы сгиб был по ребру, а не хордой.
 *
 * Вершины приходят в пространстве позы рендера; позу на входе (положение игрока) запоминаем и
 * переводим вершины обратно в мировые оси относительно игрока. Глубина модели (вдоль нормали) не
 * пропадает совсем — {@link #FLAT} от неё оставляет порядок наложения частей.
 *
 * Над поверхностью рисунок — на {@link #GAP} и слоями по {@link #FLAT}: вблизи это миллиметры, вплотную к
 * блоку. Точность буфера глубины падает с расстоянием, поэтому дальше {@link #NEAR} блоков зазор и слои
 * растут пропорционально расстоянию до камеры (вдали этого не видно) — без мерцания с гранью блока и
 * частей модели между собой.
 */
@OnlyIn(Dist.CLIENT)
final class FlatFold {

    /** Толщина рисунка — доля исходной глубины (вблизи камеры). */
    static final double FLAT = 0.01;
    /** Зазор от поверхности (вблизи камеры). */
    static final double GAP = 0.001;
    /** До этого расстояния от камеры зазор и толщина не растут, блоки. */
    static final double NEAR = 4.0;
    /** Шаг дробления граней модели, блоки. */
    static final double CELL = 0.125;
    static final int MAX_SPLIT = 8;
    private static final double EPS = 1.0E-5;

    private final BlockGetter level;
    private final Matrix4f pose;
    private final Matrix4f inverse;
    private final Matrix3f normal;
    /** Мировое положение начала позы (игрок). */
    private final double ox, oy, oz;
    /** Ноги рисунка, мир. */
    private final double fx, fy, fz;
    /** Нормаль, «вверх» рисунка, «вбок». */
    private final double[] n, e2, e1;
    private final boolean floorDepthUp;
    private final Map<Long, Boolean> full = new HashMap<>();

    FlatFold(BlockGetter level, FlatState s, PoseStack.Pose at, Vec3 origin) {
        this.level = level;
        this.pose = new Matrix4f(at.pose());
        this.inverse = new Matrix4f(at.pose()).invert();
        this.normal = new Matrix3f(at.normal());
        this.ox = origin.x;
        this.oy = origin.y;
        this.oz = origin.z;
        // оси рисунка — из его системы (FlatFrame) в мир: укладка идёт по мировым граням
        FlatFrame frame = s.frame();
        this.n = vec(frame.toWorld(FlatState.vec(s.normal)));
        Vec3 feet = origin.subtract(frame.toWorld(FlatState.vec(s.normal)).scale(Flat.LIFT));
        this.fx = feet.x;
        this.fy = feet.y;
        this.fz = feet.z;
        if (s.kind == FlatState.FLOOR) {
            e2 = vec(frame.toWorld(new Vec3(0, 0, 1)));
            e1 = vec(frame.toWorld(new Vec3(1, 0, 0)));
        } else {
            e2 = vec(frame.toWorld(FlatState.vec(s.up)));
            Direction.Axis a = s.alongAxis();
            e1 = vec(frame.toWorld(new Vec3(a == Direction.Axis.X ? 1 : 0, a == Direction.Axis.Y ? 1 : 0, a == Direction.Axis.Z ? 1 : 0)));
        }
        this.floorDepthUp = s.kind == FlatState.FLOOR;
    }

    private static double[] vec(Vec3 v) {
        return new double[]{v.x, v.y, v.z};
    }

    MultiBufferSource wrap(MultiBufferSource source) {
        return type -> new Consumer(source.getBuffer(type), type.mode() == VertexFormat.Mode.QUADS);
    }

    // ── укладка ──────────────────────────────────────────────────────────────

    private boolean full(int x, int y, int z) {
        long key = BlockPos.asLong(x, y, z);
        Boolean b = full.get(key);
        if (b == null) {
            b = FlatSurface.full(level, new BlockPos(x, y, z));
            full.put(key, b);
        }
        return b;
    }

    private boolean fullAt(double x, double y, double z) {
        return full(Mth.floor(x), Mth.floor(y), Mth.floor(z));
    }

    /**
     * Точка модели (мир относительно игрока: lx, ly, lz) → на поверхности (out: мир относительно
     * игрока, нормаль грани, на которую легла, слой по глубине модели).
     */
    void map(double lx, double ly, double lz, double[] outPos, double[] outNormal, double[] outLayer) {
        // относительно ног рисунка
        double qx = ox + lx - fx, qy = oy + ly - fy, qz = oz + lz - fz;
        double d = qx * n[0] + qy * n[1] + qz * n[2];
        double t = qx * e2[0] + qy * e2[1] + qz * e2[2];
        double s = qx * e1[0] + qy * e1[1] + qz * e1[2];
        double[] p = {fx, fy, fz};
        double[] nn = n.clone();
        walk(p, nn, e2, t);
        walk(p, nn, e1, s);
        // слой: 0 — самая дальняя от зрителя часть модели (на полу — ноги, на стене — задняя сторона)
        outLayer[0] = floorDepthUp ? Math.max(0.0, d) / 3.0 : Math.max(0.0, d + 0.3);
        outPos[0] = p[0] - ox;
        outPos[1] = p[1] - oy;
        outPos[2] = p[2] - oz;
        outNormal[0] = nn[0];
        outNormal[1] = nn[1];
        outNormal[2] = nn[2];
    }

    /** По поверхности из p на dist вдоль dir (в плоскости грани nn), с загибами на рёбрах. */
    private void walk(double[] p, double[] nn, double[] dir, double dist) {
        double sg0 = dist < 0 ? -1.0 : 1.0;
        double[] w = {dir[0] * sg0, dir[1] * sg0, dir[2] * sg0};
        double r = Math.abs(dist);
        for (int iter = 0; iter < 8 && r > 1.0E-9; iter++) {
            int ai = Math.abs(w[0]) > 0.5 ? 0 : Math.abs(w[1]) > 0.5 ? 1 : 2;
            double sg = w[ai];
            double c = p[ai];
            // идём из клетки позади (на самой границе — уже на ней)
            double b = sg > 0 ? Math.floor(c - EPS) + 1.0 : Math.floor(c + EPS);
            double toEdge = Math.max(0.0, (b - c) * sg);
            if (r <= toEdge) {
                add(p, w, r);
                return;
            }
            add(p, w, toEdge);
            r -= toEdge;
            boolean front = fullAt(p[0] + nn[0] * 0.5 + w[0] * 0.5, p[1] + nn[1] * 0.5 + w[1] * 0.5,
                    p[2] + nn[2] * 0.5 + w[2] * 0.5);
            if (front) {
                // внутренний угол: на блок впереди, прочь от прежней поверхности
                double[] nw = nn.clone();
                for (int i = 0; i < 3; i++) nn[i] = -w[i];
                System.arraycopy(nw, 0, w, 0, 3);
            } else if (!fullAt(p[0] - nn[0] * 0.5 + w[0] * 0.5, p[1] - nn[1] * 0.5 + w[1] * 0.5,
                    p[2] - nn[2] * 0.5 + w[2] * 0.5)) {
                // внешний угол: опора кончилась — за ребро, вниз по боковой грани
                double[] nw = {-nn[0], -nn[1], -nn[2]};
                System.arraycopy(w, 0, nn, 0, 3);
                System.arraycopy(nw, 0, w, 0, 3);
            }
            // сдвинуться с ребра, чтобы следующая граница была впереди
            double step = Math.min(r, 2.0 * EPS);
            add(p, w, step);
            r -= step;
        }
        add(p, w, r);
    }

    private static void add(double[] p, double[] w, double k) {
        p[0] += w[0] * k;
        p[1] += w[1] * k;
        p[2] += w[2] * k;
    }

    // ── вершины ──────────────────────────────────────────────────────────────

    /** Перехват вершин: грань из 4 вершин → сетка, каждая точка уложена на поверхность. */
    private final class Consumer implements VertexConsumer {

        private final VertexConsumer out;
        private final boolean quads;
        private final int size;
        private final float[] x = new float[4], y = new float[4], z = new float[4];
        private final float[] u = new float[4], v = new float[4];
        private final int[] color = new int[4], overlay = new int[4], light = new int[4];
        private int count;
        private final Vector3f tmp = new Vector3f();
        private final double[] mp = new double[3], mn = new double[3], ml = new double[1];
        private final Vector3f lift = new Vector3f();

        Consumer(VertexConsumer out, boolean quads) {
            this.out = out;
            this.quads = quads;
            this.size = quads ? 4 : 1;
        }

        private int cur() {
            return Math.max(0, count - 1);
        }

        @Override
        public VertexConsumer addVertex(float px, float py, float pz) {
            if (count >= size) flush();
            x[count] = px;
            y[count] = py;
            z[count] = pz;
            color[count] = -1;
            overlay[count] = 0;
            light[count] = 0;
            u[count] = v[count] = 0.0F;
            count++;
            return this;
        }

        @Override
        public VertexConsumer setColor(int r, int g, int b, int a) {
            color[cur()] = (a & 255) << 24 | (r & 255) << 16 | (g & 255) << 8 | (b & 255);
            return this;
        }

        @Override
        public VertexConsumer setUv(float uu, float vv) {
            u[cur()] = uu;
            v[cur()] = vv;
            return this;
        }

        @Override
        public VertexConsumer setUv1(int a, int b) {
            overlay[cur()] = (a & 65535) | (b & 65535) << 16;
            return this;
        }

        @Override
        public VertexConsumer setUv2(int a, int b) {
            light[cur()] = (a & 65535) | (b & 65535) << 16;
            return this;
        }

        @Override
        public VertexConsumer setNormal(float nx, float ny, float nz) {
            // нормаль — последняя у вершины: грань собрана
            if (count >= size) flush();
            return this;
        }

        @Override
        public void addVertex(float px, float py, float pz, int c, float uu, float vv, int ov, int li,
                              float nx, float ny, float nz) {
            if (count >= size) flush();
            x[count] = px;
            y[count] = py;
            z[count] = pz;
            color[count] = c;
            u[count] = uu;
            v[count] = vv;
            overlay[count] = ov;
            light[count] = li;
            count++;
            if (count >= size) flush();
        }

        private void flush() {
            int k = count;
            count = 0;
            if (k < size) return;
            // в мир относительно игрока
            double[][] l = new double[k][3];
            for (int i = 0; i < k; i++) {
                inverse.transformPosition(x[i], y[i], z[i], tmp);
                l[i][0] = tmp.x;
                l[i][1] = tmp.y;
                l[i][2] = tmp.z;
            }
            if (!quads) {
                emit(l[0][0], l[0][1], l[0][2], color[0], u[0], v[0], overlay[0], light[0]);
                return;
            }
            double edge = Math.max(Math.max(len(l[0], l[1]), len(l[1], l[2])), Math.max(len(l[2], l[3]), len(l[3], l[0])));
            int split = Mth.clamp((int) Math.ceil(edge / CELL), 1, MAX_SPLIT);
            for (int i = 0; i < split; i++) {
                for (int j = 0; j < split; j++) {
                    corner((float) i / split, (float) j / split, l);
                    corner((float) (i + 1) / split, (float) j / split, l);
                    corner((float) (i + 1) / split, (float) (j + 1) / split, l);
                    corner((float) i / split, (float) (j + 1) / split, l);
                }
            }
        }

        private double len(double[] a, double[] b) {
            double dx = a[0] - b[0], dy = a[1] - b[1], dz = a[2] - b[2];
            return Math.sqrt(dx * dx + dy * dy + dz * dz);
        }

        /** Точка грани (a — от 0-й к 1-й вершине, b — от 0-й к 3-й). */
        private void corner(float a, float b, double[][] l) {
            float w0 = (1 - a) * (1 - b), w1 = a * (1 - b), w2 = a * b, w3 = (1 - a) * b;
            double px = l[0][0] * w0 + l[1][0] * w1 + l[2][0] * w2 + l[3][0] * w3;
            double py = l[0][1] * w0 + l[1][1] * w1 + l[2][1] * w2 + l[3][1] * w3;
            double pz = l[0][2] * w0 + l[1][2] * w1 + l[2][2] * w2 + l[3][2] * w3;
            float uu = u[0] * w0 + u[1] * w1 + u[2] * w2 + u[3] * w3;
            float vv = v[0] * w0 + v[1] * w1 + v[2] * w2 + v[3] * w3;
            emit(px, py, pz, color[0], uu, vv, overlay[0], light[0]);
        }

        private void emit(double lx, double ly, double lz, int c, float uu, float vv, int ov, int li) {
            map(lx, ly, lz, mp, mn, ml);
            // точка на самой поверхности; поза рендера — относительно камеры: длина — расстояние до неё
            pose.transformPosition((float) mp[0], (float) mp[1], (float) mp[2], tmp);
            double scale = Math.max(1.0, tmp.length() / NEAR);
            float h = (float) ((GAP + ml[0] * FLAT) * scale);
            pose.transformDirection(lift.set((float) mn[0] * h, (float) mn[1] * h, (float) mn[2] * h));
            float px = tmp.x + lift.x, py = tmp.y + lift.y, pz = tmp.z + lift.z;
            tmp.set((float) mn[0], (float) mn[1], (float) mn[2]);
            normal.transform(tmp);
            out.addVertex(px, py, pz, c, uu, vv, ov, li, tmp.x, tmp.y, tmp.z);
        }
    }
}
