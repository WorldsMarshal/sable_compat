package com.invfix.flat.client;

import com.invfix.flat.FlatAttack;
import com.invfix.flat.FlatPackets;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Меню 3D-2D: Attack (Shift + клавиша): режим — цель в 2D на 60 с (двигается, уязвима, потом обратно)
 * или граффити (неподвижна, через секунду умирает, рисунок держится ещё 60 с).
 */
@OnlyIn(Dist.CLIENT)
public final class FlatAttackScreen extends Screen {

    private int mode;
    private int left, top;
    private final int panelW = 280, panelH = 92;

    public FlatAttackScreen() {
        super(Component.literal("3D-2D: Attack"));
        mode = FlatClient.myAttackMode();
    }

    private Component modeLabel() {
        return Component.literal(mode == FlatAttack.MODE_GRAFFITI
                ? "Режим: §cГраффити §7(смерть через 1 с, рисунок — 60 с)"
                : "Режим: §dв 2D на 60 с §7(двигается, уязвима)");
    }

    @Override
    protected void init() {
        left = (width - panelW) / 2;
        top = (height - panelH) / 2;
        addRenderableWidget(Button.builder(modeLabel(), b -> {
            mode = mode == FlatAttack.MODE_GRAFFITI ? FlatAttack.MODE_PLANE : FlatAttack.MODE_GRAFFITI;
            b.setMessage(modeLabel());
        }).bounds(left + 10, top + 28, panelW - 20, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Применить"), b -> {
            PacketDistributor.sendToServer(new FlatPackets.AttackSetMode(mode), new CustomPacketPayload[0]);
            onClose();
        }).bounds(left + 10, top + panelH - 28, (panelW - 30) / 2, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Отмена"), b -> onClose())
                .bounds(left + 20 + (panelW - 30) / 2, top + panelH - 28, (panelW - 30) / 2, 20).build());
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderTransparentBackground(g);
        g.fill(left, top, left + panelW, top + panelH, 0xE0101418);
        g.renderOutline(left, top, panelW, panelH, 0xFFE07CFF);
        g.drawString(font, "§d§l3D-2D: Attack", left + 10, top + 9, 0xFFFFFF, false);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
