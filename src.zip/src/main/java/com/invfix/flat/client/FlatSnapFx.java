package com.invfix.flat.client;

import com.invfix.flat.Flat;
import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxPass;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Вспышка щелчка (flat_snap.fsh): очень яркая, но маленькая точка света у руки — белое ядро в несколько
 * пикселей и тугой ореол, на мгновение (около 0,2 с). Без bloom: тот включает автоэкспозицию всего
 * кадра, а вспышка должна остаться точкой.
 *
 * Загорается на щелчке в звуке ({@link Flat#CLICK_TICKS} после нажатия) и держится у руки щёлкнувшего
 * (Flat#hand); нет его у клиента — там, где рука была при нажатии. Только тем, кто видит щёлкнувшую
 * напрямую (FlatSight).
 */
@OnlyIn(Dist.CLIENT)
public final class FlatSnapFx extends FxEffect {

    private static final int DURATION = 5;

    @Nullable
    private final Entity owner;
    private final Vec3 fallback;
    private final int delay;
    private boolean seen;

    public FlatSnapFx(@Nullable Entity owner, Vec3 fallback, int delay) {
        this.owner = owner;
        this.fallback = fallback;
        this.delay = delay;
        this.seen = FlatSight.seen(owner, fallback);
    }

    @Override
    protected void onTick(net.minecraft.client.Minecraft minecraft, net.minecraft.client.multiplayer.ClientLevel level, int age) {
        seen = FlatSight.seen(owner, fallback);
    }

    @Override
    protected int duration() {
        return DURATION + delay;
    }

    private Vec3 at(float partial) {
        return owner != null && !owner.isRemoved() ? Flat.hand(owner, partial) : fallback;
    }

    @Override
    public Vec3 focus() {
        return at(1.0F);
    }

    @Override
    public double range() {
        return 160.0;
    }

    /** Яркость: вспыхивает за полтика и гаснет за 4 тика — от щелчка. */
    private float strength(FxFrame frame) {
        float t = ticks(frame) - delay;
        if (t < 0.0F) return 0.0F;
        float rise = Math.min(1.0F, t / 0.5F);
        return rise * (float) Math.exp(-Math.max(0.0F, t - 0.5F) * 1.1F);
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        float k = strength(frame);
        if (k <= 0.003F || !seen) return;
        Vec3 rel = frame.rel(at(frame.partial()));
        float[] pts = new float[16 * 4];
        pts[0] = (float) rel.x;
        pts[1] = (float) rel.y;
        pts[2] = (float) rel.z;
        pts[3] = k;
        out.add(new FxPass("flat_snap", u -> {
            u.f4("P0", k, 0.0F, 0.0F, 0.0F);
            u.vec4s("Pts", pts);
        }));
    }
}
