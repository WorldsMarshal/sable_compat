package com.invfix.flat.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxPass;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.List;

/**
 * Вспышка щелчка при входе в 2D (flat_snap.fsh): очень яркая, но маленькая точка света у руки —
 * белое ядро в несколько пикселей и тугой ореол, на мгновение (около 0,2 с). Без bloom: тот включает
 * автоэкспозицию всего кадра, а вспышка должна остаться точкой.
 */
@OnlyIn(Dist.CLIENT)
public final class FlatSnapFx extends FxEffect {

    private static final int DURATION = 5;

    private final Vec3 at;

    public FlatSnapFx(Vec3 at) {
        this.at = at;
    }

    @Override
    protected int duration() {
        return DURATION;
    }

    @Override
    public Vec3 focus() {
        return at;
    }

    @Override
    public double range() {
        return 160.0;
    }

    /** Яркость: вспыхивает за полтика и гаснет за 4 тика. */
    private float strength(FxFrame frame) {
        float t = ticks(frame);
        float rise = Math.min(1.0F, t / 0.5F);
        return rise * (float) Math.exp(-Math.max(0.0F, t - 0.5F) * 1.1F);
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        float k = strength(frame);
        if (k <= 0.003F) return;
        Vec3 rel = frame.rel(at);
        float[] pts = new float[16 * 4];
        pts[0] = (float) rel.x;
        pts[1] = (float) rel.y;
        pts[2] = (float) rel.z;
        pts[3] = k;
        out.add(new FxPass("flat_snap", u -> {
            u.f4("P0", k, 0.0F, 0.0F, 0.0F);
            u.vec4s("Pts", pts);
        }));
    }
}
