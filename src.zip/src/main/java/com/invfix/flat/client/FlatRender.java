package com.invfix.flat.client;

import com.invfix.flat.Flat;
import com.invfix.flat.FlatState;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.event.RenderNameTagEvent;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;
import net.neoforged.neoforge.common.util.TriState;
import org.joml.Quaternionf;

/**
 * Рисунок 3D-2D: обычная модель игрока (со всей анимацией — ходьба, повороты тела и головы на все
 * 360°, броня, предметы), уложенная на поверхность блоков (FlatFold): вид вдоль нормали, края
 * загибаются по рёбрам блоков.
 *  - на полу — вид сверху;
 *  - на стене — вид спереди, как стоит;
 *  - лёжа («пол как стена») — модель сначала кладётся головой в сторону up (поворот тела — вокруг
 *    этой оси; смотрит туда же — лицом вверх), потом вид сверху.
 *
 * RenderPlayerEvent.Pre отменяется, и тот же рендерер рисует модель заново — в буфер, который
 * укладывает вершины на поверхность. Имени над рисунком нет, руки от первого лица — тоже.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class FlatRender {

    /** Идёт наша перерисовка: свой же Pre пропустить. */
    private static boolean rendering;

    private FlatRender() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRenderPre(RenderPlayerEvent.Pre event) {
        if (rendering || !(event.getEntity() instanceof AbstractClientPlayer player)) return;
        FlatState s = Flat.state(player);
        Minecraft mc = Minecraft.getInstance();
        if (s == null || mc.level == null) return;
        event.setCanceled(true);
        float partial = event.getPartialTick();
        Vec3 origin = new Vec3(Mth.lerp(partial, player.xOld, player.getX()), Mth.lerp(partial, player.yOld, player.getY()),
                Mth.lerp(partial, player.zOld, player.getZ()));
        PoseStack pose = event.getPoseStack();
        FlatFold fold = new FlatFold(mc.level, s, pose.last(), origin);
        pose.pushPose();
        if (s.kind == FlatState.SIDE) {
            Direction v = s.up;
            // на 90° вокруг UP × v: «вверх» модели — в v, её «вперёд» по взгляду в v — вверх
            pose.mulPose(new Quaternionf().rotationAxis(Mth.HALF_PI, v.getStepZ(), 0.0F, -v.getStepX()));
            pose.mulPose(Axis.YP.rotationDegrees(180.0F));
        }
        rendering = true;
        try {
            event.getRenderer().render(player, player.getYRot(), partial, pose, fold.wrap(event.getMultiBufferSource()),
                    event.getPackedLight());
        } finally {
            rendering = false;
            pose.popPose();
        }
    }

    @SubscribeEvent
    public static void onNameTag(RenderNameTagEvent event) {
        if (Flat.flat(event.getEntity())) event.setCanRender(TriState.FALSE);
    }

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (Flat.flat(Minecraft.getInstance().player)) event.setCanceled(true);
    }
}
