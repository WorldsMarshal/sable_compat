package com.invfix.flat.client;

import com.invfix.flat.Flat;
import com.invfix.flat.FlatState;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.RenderLivingEvent;
import net.neoforged.neoforge.client.event.RenderNameTagEvent;
import net.neoforged.neoforge.common.util.TriState;
import org.joml.Quaternionf;

import java.util.ArrayList;
import java.util.List;

/**
 * Рисунок 3D-2D (свой у игрока и наложенный 3D-2D: Attack — у любой живой сущности): обычная модель
 * (со всей анимацией — ходьба, повороты тела и головы на все 360°, броня, предметы), уложенная на
 * поверхность блоков (FlatFold): вид вдоль нормали, края загибаются по рёбрам блоков.
 *  - на полу — вид сверху;
 *  - на стене — вид спереди, как стоит;
 *  - в режиме «пол как стена» — модель в системе рисунка (Flat#tilt, как камера): верх — к голове.
 *
 * RenderLivingEvent.Pre отменяется, и тот же рендерер рисует модель заново — в буфер, который
 * укладывает вершины на поверхность. Имени над рисунком нет, руки от первого лица — тоже.
 *
 * Граффити (неподвижный рисунок) — без красной вспышки урона и без падения при смерти. Когда тело
 * умершего граффити исчезло, рисунок («призрак» — та же сущность, уже вне мира) рисуется здесь же,
 * после сущностей мира, до своего срока.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class FlatRender {

    /** Идёт наша перерисовка: свой же Pre пропустить. */
    private static boolean rendering;

    private record Ghost(LivingEntity entity, FlatState state, long until) {}

    private static final List<Ghost> GHOSTS = new ArrayList<>();

    private FlatRender() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRenderPre(RenderLivingEvent.Pre<?, ?> event) {
        if (rendering) return;
        LivingEntity entity = event.getEntity();
        FlatState s = Flat.state(entity);
        Minecraft mc = Minecraft.getInstance();
        if (s == null || mc.level == null) return;
        event.setCanceled(true);
        float partial = event.getPartialTick();
        Vec3 origin = new Vec3(Mth.lerp(partial, entity.xOld, entity.getX()), Mth.lerp(partial, entity.yOld, entity.getY()),
                Mth.lerp(partial, entity.zOld, entity.getZ()));
        draw(mc, entity, s, partial, origin, event.getPoseStack(), event.getMultiBufferSource(), event.getPackedLight());
    }

    /** Модель тем же рендерером — в буфер, укладывающий её на поверхность. */
    private static void draw(Minecraft mc, LivingEntity entity, FlatState s, float partial, Vec3 origin, PoseStack pose,
                             MultiBufferSource buffers, int light) {
        EntityRenderer<? super LivingEntity> renderer = mc.getEntityRenderDispatcher().getRenderer(entity);
        FlatFold fold = new FlatFold(mc.level, s, pose.last(), origin);
        pose.pushPose();
        // в режиме «пол как стена» — модель в системе рисунка (как и камера)
        Quaternionf tilt = Flat.tilt(s);
        if (tilt != null) pose.mulPose(tilt);
        int hurt = entity.hurtTime, death = entity.deathTime;
        if (s.frozen) {
            entity.hurtTime = 0;
            entity.deathTime = 0;
        }
        rendering = true;
        try {
            renderer.render(entity, entity.getYRot(), partial, pose, fold.wrap(buffers), light);
        } finally {
            rendering = false;
            entity.hurtTime = hurt;
            entity.deathTime = death;
            pose.popPose();
        }
    }

    // ── граффити после смерти ────────────────────────────────────────────────

    /** Тело умершего граффити исчезло: рисунок держится до игрового времени until. */
    static void addGhost(LivingEntity entity, FlatState s, long until) {
        entity.setOldPosAndRot();
        entity.yBodyRotO = entity.yBodyRot;
        entity.yHeadRotO = entity.yHeadRot;
        entity.hurtTime = 0;
        entity.deathTime = 0;
        GHOSTS.add(new Ghost(entity, s, until));
    }

    static void clearGhosts() {
        GHOSTS.clear();
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || GHOSTS.isEmpty()) return;
        if (com.invfix.portal.client.PortalPassCompat.inPortalPass()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            GHOSTS.clear();
            return;
        }
        long now = level.getGameTime();
        GHOSTS.removeIf(g -> g.until() < now || g.entity().level() != level);
        if (GHOSTS.isEmpty()) return;
        Vec3 cam = event.getCamera().getPosition();
        PoseStack pose = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        EntityRenderDispatcher dispatcher = mc.getEntityRenderDispatcher();
        boolean depthWrite = org.lwjgl.opengl.GL11.glGetBoolean(org.lwjgl.opengl.GL11.GL_DEPTH_WRITEMASK);
        RenderSystem.depthMask(true);
        try {
            for (Ghost g : GHOSTS) {
                LivingEntity e = g.entity();
                Vec3 at = e.position();
                if (at.distanceToSqr(cam) > 128.0 * 128.0) continue;
                pose.pushPose();
                pose.translate(at.x - cam.x, at.y - cam.y, at.z - cam.z);
                draw(mc, e, g.state(), 1.0F, at, pose, buffers, dispatcher.getPackedLightCoords(e, 1.0F));
                pose.popPose();
            }
            buffers.endBatch();
        } finally {
            RenderSystem.depthMask(depthWrite);
        }
    }

    // ── прочее ───────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onNameTag(RenderNameTagEvent event) {
        // и у призраков граффити (они уже вне мира — по флагу перерисовки)
        if (rendering || Flat.flat(event.getEntity())) event.setCanRender(TriState.FALSE);
    }

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (Flat.flat(Minecraft.getInstance().player)) event.setCanceled(true);
    }
}
