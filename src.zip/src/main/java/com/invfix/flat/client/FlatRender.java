package com.invfix.flat.client;

import com.invfix.flat.Flat;
import com.invfix.flat.FlatState;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.event.RenderNameTagEvent;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;
import net.neoforged.neoforge.common.util.TriState;
import org.joml.Quaternionf;

import java.util.IdentityHashMap;
import java.util.Map;

/**
 * Рисунок 3D-2D: обычная модель игрока (со всей анимацией, бронёй, предметами), сплющенная в плоскость
 * поверхности — {@link #FLAT} толщины, у самой поверхности:
 *  - на полу — вид сверху: стоящая фигура, сжатая по вертикали, повёрнута, как идёт;
 *  - на стене — стоя, лицом наружу, сжатая по нормали стены;
 *  - лёжа («пол как стена») — лицом вверх, головой в сторону up, сжатая по вертикали.
 *
 * Матрица ставится в RenderPlayerEvent.Pre (поза уже перенесена в положение игрока) и снимается в
 * Post — самой модели рисует ванильный рендерер. Имени над рисунком нет, руки от первого лица — тоже.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class FlatRender {

    /** Толщина рисунка — доля исходной глубины. */
    private static final float FLAT = 0.02F;
    /** Зазор от поверхности: сплющенная модель — ±0,005 вокруг своей середины (рука в замахе — больше). */
    private static final double GAP = 0.015;

    /** Для кого в этом кадре матрица поставлена (снять в Post). */
    private static final Map<Player, PoseStack> PUSHED = new IdentityHashMap<>();

    private FlatRender() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRenderPre(RenderPlayerEvent.Pre event) {
        Player player = event.getEntity();
        FlatState s = Flat.state(player);
        if (s == null) return;
        PoseStack pose = event.getPoseStack();
        float body = Mth.rotLerp(event.getPartialTick(), player.yBodyRotO, player.yBodyRot);
        pose.pushPose();
        PUSHED.put(player, pose);
        double back = GAP - Flat.LIFT;
        switch (s.kind) {
            case FlatState.WALL -> {
                Direction n = s.normal;
                pose.translate(n.getStepX() * back, n.getStepY() * back, n.getStepZ() * back);
                pose.scale(n.getAxis() == Direction.Axis.X ? FLAT : 1.0F, 1.0F, n.getAxis() == Direction.Axis.Z ? FLAT : 1.0F);
                // рендерер повернёт модель на 180 - body: вместе — лицом по нормали
                pose.mulPose(Axis.YP.rotationDegrees(body - n.toYRot()));
            }
            case FlatState.SIDE -> {
                Direction v = s.up;
                pose.translate(0.0, back, 0.0);
                pose.scale(1.0F, FLAT, 1.0F);
                // лицом против v, затем на 90° вокруг UP × v: голова — в v, лицо — вверх
                pose.mulPose(new Quaternionf().rotationAxis(Mth.HALF_PI, v.getStepZ(), 0.0F, -v.getStepX()));
                pose.mulPose(Axis.YP.rotationDegrees(body - v.getOpposite().toYRot()));
            }
            default -> {
                pose.translate(0.0, back, 0.0);
                pose.scale(1.0F, FLAT, 1.0F);
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRenderPost(RenderPlayerEvent.Post event) {
        PoseStack pose = PUSHED.remove(event.getEntity());
        if (pose != null) pose.popPose();
    }

    @SubscribeEvent
    public static void onNameTag(RenderNameTagEvent event) {
        if (Flat.flat(event.getEntity())) event.setCanRender(TriState.FALSE);
    }

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (Flat.flat(Minecraft.getInstance().player)) event.setCanceled(true);
    }
}
