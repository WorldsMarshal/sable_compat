package com.invfix.flat.client;

import com.invfix.flat.Flat;
import com.invfix.flat.FlatPackets;
import com.invfix.flat.FlatSounds;
import com.invfix.flat.FlatState;
import com.invfix.flat.FlatSurface;
import com.invfix.fx.FxManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.sounds.WeighedSoundEvents;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 3D-2D на клиенте: состояние игроков (пакет State), движение своего рисунка, меню режима
 * (Shift + клавиша способности).
 *
 * Движение — в конце тика своего игрока (до отправки положения серверу), по клавишам ходьбы
 * относительно взгляда, скорость — обычная ходьба (бег — ×1,3):
 *  - на полу — куда идёшь, ступеньки и переходы на стены — FlatSurface#moveFloor; прыжка нет;
 *  - на стене — вбок (проекция хода на стену); прыжок — на блок выше (наверху — на крышу),
 *    присед — на блок ниже (внизу — на пол);
 * В режиме «пол как стена» всё это — в системе рисунка (его верх — к голове, FlatFrame): взгляд, ход
 * и правила поверхностей в ней те же, поэтому пол мира — стена, стена к голове — пол и т.д.
 * Удержание прыжка / приседа повторяет шаг каждые {@link #STEP_REPEAT} тиков.
 *
 * Поверхность под рисунком пропала — на соседнюю (FlatSurface#relocate); некуда — Drop серверу.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class FlatClient {

    /** Обычная ходьба, блоков за тик (4,317 блока/с). */
    private static final double WALK = 0.21585;
    private static final double SPRINT = 1.3;
    private static final int STEP_REPEAT = 6;

    private static boolean mySide;
    private static int myAttackMode;
    private static boolean wasAttackMenuDown;
    /** Умершие граффити: id → сколько ещё держится рисунок после исчезновения тела. */
    private static final java.util.Map<Integer, Integer> GRAFFITI = new java.util.HashMap<>();
    private static ClientLevel lastLevel;
    private static boolean wasMenuDown;
    private static int jumpHeld, shiftHeld;
    private static int dropCooldown;

    private FlatClient() {}

    // ── пакеты ───────────────────────────────────────────────────────────────

    public static void onState(FlatPackets.State pkt) {
        Minecraft mc = Minecraft.getInstance();
        checkLevel();
        if (mc.level == null) return;
        Entity entity = mc.level.getEntity(pkt.entityId());
        if (pkt.removed()) {
            FlatState was = Flat.state(entity);
            Flat.setClient(pkt.entityId(), null);
            if (entity == mc.player) reframe(mc.player, was, null);
            if (entity instanceof Player player) {
                player.setForcedPose(null);
                if (pkt.crawl()) player.setPose(Pose.SWIMMING);
                player.refreshDimensions();
            }
            return;
        }
        FlatState s = FlatState.read(pkt.state());
        Flat.setClient(pkt.entityId(), s);
        Vec3 feet = new Vec3(pkt.x(), pkt.y(), pkt.z());
        if (entity instanceof Player player) {
            player.setForcedPose(Pose.STANDING);
            player.setPose(Pose.STANDING);
            if (player == mc.player) {
                Vec3 pos = Flat.pos(s, feet);
                player.setPos(pos.x, pos.y, pos.z);
                player.xo = player.xOld = pos.x;
                player.yo = player.yOld = pos.y;
                player.zo = player.zOld = pos.z;
                player.setDeltaMovement(Vec3.ZERO);
                jumpHeld = shiftHeld = 0;
                reframe(player, null, s);
            }
            player.refreshDimensions();
        }
    }

    public static void onSnap(FlatPackets.Snap pkt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) snap(mc, mc.level.getEntity(pkt.entityId()), new Vec3(pkt.x(), pkt.y(), pkt.z()));
    }

    public static void onSettings(boolean side) {
        mySide = side;
    }

    public static void onAttackSettings(int mode) {
        myAttackMode = mode;
    }

    static int myAttackMode() {
        return myAttackMode;
    }

    static boolean mySide() {
        return mySide;
    }

    /**
     * Щелчок: звук (FlatSounds — щелчок X) от руки щёлкнувшего и вспышка — на щелчке в звуке
     * (Flat#CLICK_TICKS). Нет сущности у клиента — там, где рука была при нажатии.
     */
    private static void snap(Minecraft mc, Entity owner, Vec3 at) {
        FxManager.add(new FlatSnapFx(owner, at, Flat.CLICK_TICKS));
        WeighedSoundEvents sound = mc.getSoundManager().getSoundEvent(FlatSounds.SNAP_ID);
        if (sound == null || sound.getWeight() <= 0 || mc.level == null) return;
        if (owner != null) mc.level.playLocalSound(owner, FlatSounds.SNAP.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
        else mc.level.playLocalSound(at.x, at.y, at.z, FlatSounds.SNAP.get(), SoundSource.PLAYERS, 1.0F, 1.0F, false);
    }

    /** Удар 3D-2D: Attack: импакт-кадры — на щелчке в звуке (FlatImpactFx). */
    public static void onImpact(FlatPackets.Impact pkt) {
        if (Minecraft.getInstance().level == null) return;
        FxManager.add(new FlatImpactFx(new Vec3(pkt.x(), pkt.y(), pkt.z()), pkt.graffiti()));
    }

    /** Другой мир — состояния старого больше не наши. */
    private static void checkLevel() {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == lastLevel) return;
        lastLevel = level;
        Flat.clearClient();
        GRAFFITI.clear();
    }

    @SubscribeEvent
    public static void onLeave(EntityLeaveLevelEvent event) {
        if (!event.getLevel().isClientSide() || !(event.getEntity() instanceof LivingEntity living)) return;
        FlatState s = Flat.state(living);
        Flat.setClient(living.getId(), null);
        // граффити: тело исчезло, рисунок остаётся (FlatRender)
        Integer ticks = GRAFFITI.remove(living.getId());
        if (s != null && ticks != null) FlatRender.addGhost(living, s, event.getLevel().getGameTime() + ticks);
    }

    /** Граффити entityId умер: когда тело исчезнет, рисунок держится ещё ticks тиков. */
    public static void onGraffitiDead(int entityId, int ticks) {
        GRAFFITI.put(entityId, ticks);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        Flat.clearClient();
        GRAFFITI.clear();
        FlatRender.clearGhosts();
        lastLevel = null;
    }

    // ── движение ─────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (!(event.getEntity() instanceof LocalPlayer player) || player != mc.player) return;
        FlatState s = Flat.state(player);
        if (s == null) {
            jumpHeld = shiftHeld = 0;
            return;
        }
        if (dropCooldown > 0) dropCooldown--;
        if (mc.level == null) return;
        // мир в системе рисунка (в режиме «пол как стена» — повёрнутый): правила те же, что в обычном
        net.minecraft.world.level.BlockGetter level = FlatSurface.view(mc.level, s);
        FlatSurface.Placement cur = new FlatSurface.Placement(s, Flat.feet(s, player.position()));

        // поверхность пропала — на соседнюю, иначе выпасть
        if (!FlatSurface.fits(level, s, cur.feet())) {
            FlatSurface.Placement moved = FlatSurface.relocate(level, cur);
            if (moved == null) {
                if (dropCooldown == 0) {
                    dropCooldown = 20;
                    PacketDistributor.sendToServer(new FlatPackets.Drop(), new CustomPacketPayload[0]);
                }
                hold(player);
                return;
            }
            apply(player, cur, moved);
            return;
        }

        // граффити: ни шагу
        if (s.frozen) {
            hold(player);
            return;
        }

        boolean jump = player.input.jumping;
        boolean shift = player.input.shiftKeyDown;
        boolean doJump = jump && (jumpHeld++ % STEP_REPEAT == 0);
        boolean doShift = shift && (shiftHeld++ % STEP_REPEAT == 0);
        if (!jump) jumpHeld = 0;
        if (!shift) shiftHeld = 0;

        Vec3 move = walk(mc, player, s);
        FlatSurface.Placement next = cur;
        switch (s.kind) {
            case FlatState.FLOOR -> next = FlatSurface.moveFloor(level, s, cur.feet(), move.x, move.z);
            case FlatState.WALL -> {
                next = FlatSurface.moveWall(level, s, cur.feet(), along(s, move));
                FlatState ns = next.state();
                if (ns.kind == FlatState.WALL && doJump) {
                    FlatSurface.Placement up = FlatSurface.wallUp(level, ns, next.feet());
                    if (up != null) next = up;
                } else if (ns.kind == FlatState.WALL && doShift) {
                    FlatSurface.Placement down = FlatSurface.wallDown(level, ns, next.feet());
                    if (down != null) next = down;
                }
            }
            default -> {}
        }
        apply(player, cur, next);
    }

    /** Ход за тик по клавишам относительно взгляда (по горизонтали), в системе рисунка. */
    private static Vec3 walk(Minecraft mc, LocalPlayer player, FlatState s) {
        float forward = (player.input.up ? 1.0F : 0.0F) - (player.input.down ? 1.0F : 0.0F);
        float strafe = (player.input.left ? 1.0F : 0.0F) - (player.input.right ? 1.0F : 0.0F);
        if (forward == 0.0F && strafe == 0.0F) return Vec3.ZERO;
        double len = Math.sqrt(forward * forward + strafe * strafe);
        double speed = WALK * (mc.options.keySprint.isDown() ? SPRINT : 1.0) / len;
        float yaw = player.getYRot() * Mth.DEG_TO_RAD;
        double sin = Mth.sin(yaw), cos = Mth.cos(yaw);
        // взгляд — в системе рисунка (Flat#tilted), ход — в ней же, как и правила поверхностей
        return new Vec3((strafe * cos - forward * sin) * speed, 0.0, (forward * cos + strafe * sin) * speed);
    }

    /** Ход вдоль поверхности (по её горизонтальной оси). */
    private static double along(FlatState s, Vec3 move) {
        Direction.Axis a = s.alongAxis();
        return a == Direction.Axis.X ? move.x : a == Direction.Axis.Z ? move.z : 0.0;
    }

    private static void apply(LocalPlayer player, FlatSurface.Placement cur, FlatSurface.Placement next) {
        Vec3 pos = Flat.pos(next.state(), next.feet());
        player.setPos(pos.x, pos.y, pos.z);
        hold(player);
        // анимация ходьбы: ваниль считает её в travel, а он у рисунка не идёт (сдвиг с начала тика)
        player.calculateEntityAnimation(false);
        turnBody(player);
        if (!next.state().sameSurface(cur.state())) {
            Flat.setClient(player.getId(), next.state());
            reframe(player, cur.state(), next.state());
            player.refreshDimensions();
            PacketDistributor.sendToServer(new FlatPackets.Move(next.state().write(), next.feet().x, next.feet().y,
                    next.feet().z), new CustomPacketPayload[0]);
        }
    }

    /**
     * Тело — по ходу, как у ванили (LivingEntity#tick: поворот к направлению движения, задом наперёд —
     * спиной, и tickHeadTurn): там это считается до нашего сдвига рисунка и видит нулевой ход. Лёжа —
     * ход в системе рисунка.
     */
    private static void turnBody(LocalPlayer player) {
        Vec3 d = Flat.toLocal(Flat.state(player), new Vec3(player.getX() - player.xo, player.getY() - player.yo,
                player.getZ() - player.zo));
        double dx = d.x;
        double dz = d.z;
        if (dx * dx + dz * dz <= 0.0025F) return;
        float move = (float) Mth.atan2(dz, dx) * Mth.RAD_TO_DEG - 90.0F;
        float off = Mth.abs(Mth.wrapDegrees(player.getYRot()) - move);
        float target = 95.0F < off && off < 265.0F ? move - 180.0F : move;
        if (player.attackAnim > 0.0F) target = player.getYRot();
        player.yBodyRot += Mth.wrapDegrees(target - player.yBodyRot) * 0.3F;
        float head = Mth.wrapDegrees(player.getYRot() - player.yBodyRot);
        float max = player.isBlocking() ? 15.0F : 50.0F;
        if (Math.abs(head) > max) player.yBodyRot += head - Math.signum(head) * max;
    }

    /**
     * Сменилась система взгляда (вход и выход в режиме «пол как стена»): yaw / pitch пересчитываются так, чтобы
     * взгляд смотрел туда же в мире — меняется только «верх». Взгляд вдоль нового «верха» (полюс):
     * поворот вокруг него — по прежнему верху экрана.
     */
    private static void reframe(Player player, FlatState from, FlatState to) {
        Direction ga = from == null ? Direction.UP : from.g, gb = to == null ? Direction.UP : to.g;
        if (ga == gb) return;
        float yaw = player.getYRot(), pitch = player.getXRot();
        Vec3 look = Flat.toLocal(to, Flat.toWorld(from, Vec3.directionFromRotation(pitch, yaw)));
        Vec3 top = Flat.toLocal(to, Flat.toWorld(from, Vec3.directionFromRotation(pitch - 90.0F, yaw)));
        float newPitch = (float) Math.toDegrees(Math.asin(Mth.clamp(-look.y, -1.0, 1.0)));
        float newYaw;
        if (look.x * look.x + look.z * look.z > 0.0025) {
            newYaw = (float) Math.toDegrees(Math.atan2(-look.x, look.z));
        } else if (look.y > 0.0) {
            // смотрит вверх: верх экрана — против направления yaw
            newYaw = (float) Math.toDegrees(Math.atan2(top.x, -top.z));
        } else {
            newYaw = (float) Math.toDegrees(Math.atan2(-top.x, top.z));
        }
        player.setYRot(newYaw);
        player.setXRot(newPitch);
        player.yRotO = newYaw;
        player.xRotO = newPitch;
        player.setYHeadRot(newYaw);
        player.yHeadRotO = newYaw;
        player.yBodyRot = newYaw;
        player.yBodyRotO = newYaw;
    }

    private static void hold(LocalPlayer player) {
        player.setDeltaMovement(Vec3.ZERO);
        player.resetFallDistance();
        player.setOnGround(true);
    }

    // ── меню ─────────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        checkLevel();
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            wasMenuDown = wasAttackMenuDown = false;
            return;
        }
        boolean down = mc.screen == null && slotKeyDown(mc, Flat.ABILITY);
        if (down && !wasMenuDown && rawDown(mc, mc.options.keyShift) && Flat.eligible(mc.player)) {
            mc.setScreen(new FlatScreen());
        }
        wasMenuDown = down;
        boolean attack = mc.screen == null && slotKeyDown(mc, com.invfix.flat.FlatAttack.ABILITY);
        if (attack && !wasAttackMenuDown && rawDown(mc, mc.options.keyShift) && com.invfix.flat.FlatAttack.eligible(mc.player)) {
            mc.setScreen(new FlatAttackScreen());
        }
        wasAttackMenuDown = attack;
    }

    private static boolean slotKeyDown(Minecraft mc, String ability) {
        try {
            net.mcreator.invincibleinc.network.InvincibleIncModVariables.PlayerVariables v =
                    mc.player.getData(net.mcreator.invincibleinc.network.InvincibleIncModVariables.PLAYER_VARIABLES);
            boolean row1 = v.AbilityRow == 1.0;
            String[] slots = {
                    row1 ? v.AbilitySlot1 : v.AbilitySlot1_row2,
                    row1 ? v.AbilitySlot2 : v.AbilitySlot2_row2,
                    row1 ? v.AbilitySlot3 : v.AbilitySlot3_row2,
                    row1 ? v.AbilitySlot4 : v.AbilitySlot4_row2,
                    row1 ? v.AbilitySlot5 : v.AbilitySlot5_row2};
            net.minecraft.client.KeyMapping[] keys = {
                    net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings.ABILITY_1,
                    net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings.ABILITY_2,
                    net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings.ABILITY_3,
                    net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings.ABILITY_4,
                    net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings.ABILITY_5};
            for (int i = 0; i < 5; i++) {
                if (ability.equals(slots[i]) && rawDown(mc, keys[i])) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    /** Клавиша зажата — прямо по окну (как у Size Difference): мимо состояния привязок. */
    private static boolean rawDown(Minecraft mc, net.minecraft.client.KeyMapping km) {
        if (km == null) return false;
        com.mojang.blaze3d.platform.InputConstants.Key key = km.getKey();
        if (key == null || key.getValue() == com.mojang.blaze3d.platform.InputConstants.UNKNOWN.getValue()) return false;
        long window = mc.getWindow().getWindow();
        return switch (key.getType()) {
            case KEYSYM -> com.mojang.blaze3d.platform.InputConstants.isKeyDown(window, key.getValue());
            case MOUSE -> org.lwjgl.glfw.GLFW.glfwGetMouseButton(window, key.getValue()) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
            default -> km.isDown();
        };
    }
}
