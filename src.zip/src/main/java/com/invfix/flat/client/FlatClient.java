package com.invfix.flat.client;

import com.invfix.flat.Flat;
import com.invfix.flat.FlatPackets;
import com.invfix.flat.FlatSounds;
import com.invfix.flat.FlatState;
import com.invfix.flat.FlatSurface;
import com.invfix.fx.FxManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.sounds.WeighedSoundEvents;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 3D-2D на клиенте: состояние игроков (пакет State), движение своего рисунка, меню режима
 * (Shift + клавиша способности).
 *
 * Движение — в конце тика своего игрока (до отправки положения серверу), по клавишам ходьбы
 * относительно взгляда, скорость — обычная ходьба (бег — ×1,3):
 *  - на полу — куда идёшь, ступеньки и переходы на стены — FlatSurface#moveFloor; прыжка нет;
 *  - на стене — вбок (проекция хода на стену); прыжок — на блок выше (наверху — на крышу),
 *    присед — на блок ниже (внизу — на пол);
 *  - лёжа («пол как стена») — вбок так же, прыжок / присед — на клетку к голове / к ногам.
 * Удержание прыжка / приседа повторяет шаг каждые {@link #STEP_REPEAT} тиков.
 *
 * Поверхность под рисунком пропала — на соседнюю (FlatSurface#relocate); некуда — Drop серверу.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class FlatClient {

    /** Обычная ходьба, блоков за тик (4,317 блока/с). */
    private static final double WALK = 0.21585;
    private static final double SPRINT = 1.3;
    private static final int STEP_REPEAT = 6;

    private static boolean mySide;
    private static ClientLevel lastLevel;
    private static boolean wasMenuDown;
    private static int jumpHeld, shiftHeld;
    private static int dropCooldown;

    private FlatClient() {}

    // ── пакеты ───────────────────────────────────────────────────────────────

    public static void onState(FlatPackets.State pkt) {
        Minecraft mc = Minecraft.getInstance();
        checkLevel();
        if (mc.level == null) return;
        Entity entity = mc.level.getEntity(pkt.entityId());
        if (pkt.removed()) {
            Flat.setClient(pkt.entityId(), null);
            if (entity instanceof Player player) {
                player.setForcedPose(null);
                if (pkt.crawl()) player.setPose(Pose.SWIMMING);
                player.refreshDimensions();
            }
            return;
        }
        FlatState s = FlatState.read(pkt.state());
        Flat.setClient(pkt.entityId(), s);
        Vec3 feet = new Vec3(pkt.x(), pkt.y(), pkt.z());
        if (entity instanceof Player player) {
            player.setForcedPose(Pose.STANDING);
            player.setPose(Pose.STANDING);
            if (player == mc.player) {
                Vec3 pos = Flat.pos(s, feet);
                player.setPos(pos.x, pos.y, pos.z);
                player.xo = player.xOld = pos.x;
                player.yo = player.yOld = pos.y;
                player.zo = player.zOld = pos.z;
                player.setDeltaMovement(Vec3.ZERO);
                jumpHeld = shiftHeld = 0;
            }
            player.refreshDimensions();
        }
    }

    public static void onSnap(FlatPackets.Snap pkt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) snap(mc, new Vec3(pkt.x(), pkt.y(), pkt.z()));
    }

    public static void onSettings(boolean side) {
        mySide = side;
    }

    static boolean mySide() {
        return mySide;
    }

    /** Щелчок: вспышка у руки и звук, если он есть (FlatSounds). */
    private static void snap(Minecraft mc, Vec3 at) {
        FxManager.add(new FlatSnapFx(at));
        WeighedSoundEvents sound = mc.getSoundManager().getSoundEvent(FlatSounds.SNAP_ID);
        if (sound != null && sound.getWeight() > 0 && mc.level != null) {
            mc.level.playLocalSound(at.x, at.y, at.z, FlatSounds.SNAP.get(), SoundSource.PLAYERS, 1.0F, 1.0F, false);
        }
    }

    /** Другой мир — состояния старого больше не наши. */
    private static void checkLevel() {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == lastLevel) return;
        lastLevel = level;
        Flat.clearClient();
    }

    @SubscribeEvent
    public static void onLeave(EntityLeaveLevelEvent event) {
        if (event.getLevel().isClientSide() && event.getEntity() instanceof Player) {
            Flat.setClient(event.getEntity().getId(), null);
        }
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        Flat.clearClient();
        lastLevel = null;
    }

    // ── движение ─────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (!(event.getEntity() instanceof LocalPlayer player) || player != mc.player) return;
        FlatState s = Flat.state(player);
        if (s == null) {
            jumpHeld = shiftHeld = 0;
            return;
        }
        if (dropCooldown > 0) dropCooldown--;
        ClientLevel level = mc.level;
        if (level == null) return;
        FlatSurface.Placement cur = new FlatSurface.Placement(s, Flat.feet(s, player.position()));

        // поверхность пропала — на соседнюю, иначе выпасть
        if (!FlatSurface.fits(level, s, cur.feet())) {
            FlatSurface.Placement moved = FlatSurface.relocate(level, cur, mySide);
            if (moved == null) {
                if (dropCooldown == 0) {
                    dropCooldown = 20;
                    PacketDistributor.sendToServer(new FlatPackets.Drop(), new CustomPacketPayload[0]);
                }
                hold(player);
                return;
            }
            apply(player, cur, moved);
            return;
        }

        boolean jump = player.input.jumping;
        boolean shift = player.input.shiftKeyDown;
        boolean doJump = jump && (jumpHeld++ % STEP_REPEAT == 0);
        boolean doShift = shift && (shiftHeld++ % STEP_REPEAT == 0);
        if (!jump) jumpHeld = 0;
        if (!shift) shiftHeld = 0;

        Vec3 move = walk(mc, player);
        FlatSurface.Placement next = cur;
        switch (s.kind) {
            case FlatState.FLOOR -> next = FlatSurface.moveFloor(level, s, cur.feet(), move.x, move.z);
            case FlatState.WALL -> {
                next = FlatSurface.moveWall(level, s, cur.feet(), along(s, move));
                FlatState ns = next.state();
                if (ns.kind == FlatState.WALL && doJump) {
                    FlatSurface.Placement up = FlatSurface.wallUp(level, ns, next.feet(), mySide);
                    if (up != null) next = up;
                } else if (ns.kind == FlatState.WALL && doShift) {
                    FlatSurface.Placement down = FlatSurface.wallDown(level, ns, next.feet(), mySide);
                    if (down != null) next = down;
                }
            }
            case FlatState.SIDE -> {
                next = FlatSurface.moveSide(level, s, cur.feet(), along(s, move));
                FlatState ns = next.state();
                if (ns.kind == FlatState.SIDE && (doJump || doShift)) {
                    FlatSurface.Placement step = FlatSurface.stepSide(level, ns, next.feet(), doJump ? 1 : -1);
                    if (step != null) next = step;
                }
            }
            default -> {}
        }
        apply(player, cur, next);
    }

    /** Ход за тик по клавишам относительно взгляда (по горизонтали). */
    private static Vec3 walk(Minecraft mc, LocalPlayer player) {
        float forward = (player.input.up ? 1.0F : 0.0F) - (player.input.down ? 1.0F : 0.0F);
        float strafe = (player.input.left ? 1.0F : 0.0F) - (player.input.right ? 1.0F : 0.0F);
        if (forward == 0.0F && strafe == 0.0F) return Vec3.ZERO;
        double len = Math.sqrt(forward * forward + strafe * strafe);
        double speed = WALK * (mc.options.keySprint.isDown() ? SPRINT : 1.0) / len;
        float yaw = player.getYRot() * Mth.DEG_TO_RAD;
        double sin = Mth.sin(yaw), cos = Mth.cos(yaw);
        return new Vec3((strafe * cos - forward * sin) * speed, 0.0, (forward * cos + strafe * sin) * speed);
    }

    /** Ход вдоль поверхности (по её горизонтальной оси). */
    private static double along(FlatState s, Vec3 move) {
        Direction.Axis a = s.alongAxis();
        return a == Direction.Axis.X ? move.x : a == Direction.Axis.Z ? move.z : 0.0;
    }

    private static void apply(LocalPlayer player, FlatSurface.Placement cur, FlatSurface.Placement next) {
        Vec3 pos = Flat.pos(next.state(), next.feet());
        player.setPos(pos.x, pos.y, pos.z);
        hold(player);
        // анимация ходьбы: ваниль считает её в travel, а он у рисунка не идёт (сдвиг с начала тика)
        player.calculateEntityAnimation(false);
        if (!next.state().sameSurface(cur.state())) {
            Flat.setClient(player.getId(), next.state());
            player.refreshDimensions();
            PacketDistributor.sendToServer(new FlatPackets.Move(next.state().write(), next.feet().x, next.feet().y,
                    next.feet().z), new CustomPacketPayload[0]);
        }
    }

    private static void hold(LocalPlayer player) {
        player.setDeltaMovement(Vec3.ZERO);
        player.resetFallDistance();
        player.setOnGround(true);
    }

    // ── меню ─────────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        checkLevel();
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            wasMenuDown = false;
            return;
        }
        boolean down = mc.screen == null && slotKeyDown(mc);
        if (down && !wasMenuDown && rawDown(mc, mc.options.keyShift) && Flat.eligible(mc.player)) {
            mc.setScreen(new FlatScreen());
        }
        wasMenuDown = down;
    }

    private static boolean slotKeyDown(Minecraft mc) {
        try {
            net.mcreator.invincibleinc.network.InvincibleIncModVariables.PlayerVariables v =
                    mc.player.getData(net.mcreator.invincibleinc.network.InvincibleIncModVariables.PLAYER_VARIABLES);
            boolean row1 = v.AbilityRow == 1.0;
            String[] slots = {
                    row1 ? v.AbilitySlot1 : v.AbilitySlot1_row2,
                    row1 ? v.AbilitySlot2 : v.AbilitySlot2_row2,
                    row1 ? v.AbilitySlot3 : v.AbilitySlot3_row2,
                    row1 ? v.AbilitySlot4 : v.AbilitySlot4_row2,
                    row1 ? v.AbilitySlot5 : v.AbilitySlot5_row2};
            net.minecraft.client.KeyMapping[] keys = {
                    net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings.ABILITY_1,
                    net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings.ABILITY_2,
                    net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings.ABILITY_3,
                    net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings.ABILITY_4,
                    net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings.ABILITY_5};
            for (int i = 0; i < 5; i++) {
                if (Flat.ABILITY.equals(slots[i]) && rawDown(mc, keys[i])) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    /** Клавиша зажата — прямо по окну (как у Size Difference): мимо состояния привязок. */
    private static boolean rawDown(Minecraft mc, net.minecraft.client.KeyMapping km) {
        if (km == null) return false;
        com.mojang.blaze3d.platform.InputConstants.Key key = km.getKey();
        if (key == null || key.getValue() == com.mojang.blaze3d.platform.InputConstants.UNKNOWN.getValue()) return false;
        long window = mc.getWindow().getWindow();
        return switch (key.getType()) {
            case KEYSYM -> com.mojang.blaze3d.platform.InputConstants.isKeyDown(window, key.getValue());
            case MOUSE -> org.lwjgl.glfw.GLFW.glfwGetMouseButton(window, key.getValue()) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
            default -> km.isDown();
        };
    }
}
