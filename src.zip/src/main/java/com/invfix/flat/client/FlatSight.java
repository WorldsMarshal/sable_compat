package com.invfix.flat.client;

import com.invfix.flat.Flat;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import javax.annotation.Nullable;

/**
 * Видна ли щёлкнувшая (кастер) из камеры напрямую: VFX её Dimension-способностей (вспышка, комикс-панель,
 * импакт-кадры) видят только те, кто видит её саму; за блоками — только звук. Сама себе — всегда.
 * Луч из камеры к глазам, середине тела и руке, по видимым формам блоков (стекло не мешает); хоть один
 * дошёл — видна. Кастера у клиента нет — к точке fallback (null — не видна).
 */
@OnlyIn(Dist.CLIENT)
public final class FlatSight {

    private FlatSight() {}

    public static boolean seen(@Nullable Entity caster, @Nullable Vec3 fallback) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return false;
        if (caster != null && (caster == mc.player || caster == mc.getCameraEntity())) return true;
        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
        if (caster != null && !caster.isRemoved()) {
            return clear(mc, cam, caster.getEyePosition())
                    || clear(mc, cam, caster.getBoundingBox().getCenter())
                    || clear(mc, cam, Flat.hand(caster, 1.0F));
        }
        return fallback != null && clear(mc, cam, fallback);
    }

    private static boolean clear(Minecraft mc, Vec3 from, Vec3 to) {
        // постройка Sable — попадание в мире (SableCompat): иначе даль до её участка считалась бы «чисто»
        BlockHitResult hit = com.invfix.compat.SableCompat.clip(mc.level, new ClipContext(from, to, ClipContext.Block.VISUAL,
                ClipContext.Fluid.NONE, CollisionContext.empty()));
        return hit.getType() == HitResult.Type.MISS || hit.getLocation().distanceToSqr(from) >= from.distanceToSqr(to) - 0.04;
    }
}
