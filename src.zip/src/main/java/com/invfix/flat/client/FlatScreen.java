package com.invfix.flat.client;

import com.invfix.flat.FlatPackets;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Меню 3D-2D (Shift + клавиша): обычный режим (пол — вид сверху, стены — стоя) или «пол как стена» —
 * верх рисунка смещён (FlatFrame): на полу — лёжа, головой туда, куда смотришь при входе, и до выхода
 * так же для всех граней (стена к голове — пол, вид сверху; остальные — стены); со стены вход — видом
 * сверху, верх — из стены.
 */
@OnlyIn(Dist.CLIENT)
public final class FlatScreen extends Screen {

    private boolean side;
    private int left, top;
    private final int panelW = 280, panelH = 92;

    public FlatScreen() {
        super(Component.literal("3D-2D"));
        side = FlatClient.mySide();
    }

    private Component modeLabel() {
        return Component.literal(side ? "Режим: §dпол как стена §7(верх смещён)" : "Режим: §fобычный");
    }

    @Override
    protected void init() {
        left = (width - panelW) / 2;
        top = (height - panelH) / 2;
        addRenderableWidget(Button.builder(modeLabel(), b -> {
            side = !side;
            b.setMessage(modeLabel());
        }).bounds(left + 10, top + 28, panelW - 20, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Применить"), b -> {
            PacketDistributor.sendToServer(new FlatPackets.SetSide(side), new CustomPacketPayload[0]);
            onClose();
        }).bounds(left + 10, top + panelH - 28, (panelW - 30) / 2, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Отмена"), b -> onClose())
                .bounds(left + 20 + (panelW - 30) / 2, top + panelH - 28, (panelW - 30) / 2, 20).build());
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderTransparentBackground(g);
        g.fill(left, top, left + panelW, top + panelH, 0xE0101418);
        g.renderOutline(left, top, panelW, panelH, 0xFFE07CFF);
        g.drawString(font, "§d§l3D-2D", left + 10, top + 9, 0xFFFFFF, false);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
