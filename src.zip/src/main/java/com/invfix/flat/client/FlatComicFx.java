package com.invfix.flat.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import com.invfix.flat.Flat;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Щелчок пальцев как комикс-панель (snap_comic.fsh) — импакт-кадрами на щелчке в звуке
 * ({@link Flat#CLICK_TICKS} после нажатия), за {@link #END} с:
 *  - 0–0,05 с — жёсткая вспышка (белая; у инверсии — чёрная);
 *  - до {@link #HOLD} с — панель шагами по 1/12 с: каждый кадр заново встряхивает буквы, звезду и линии,
 *    слово «выпрыгивает» (крупнее в первые кадры);
 *  - затем два гаснущих кадра.
 * Панель (FlatPackets.Snap#variant): SNAP-взрыв, PA!! панель, разлом клиньями, инверсия-молния.
 *
 * Щёлкнувшая — на весь экран (с тряской, аберрацией, зум-размытием и покадровостью 12 к/с); остальные в
 * {@link #RANGE} блоках — в рваном комикс-облаке у её руки, размером и силой по расстоянию.
 */
@OnlyIn(Dist.CLIENT)
public final class FlatComicFx extends FxEffect {

    private static final float FLASH = 0.05F;
    private static final float FRAME = 1.0F / 12.0F;
    private static final float HOLD = 0.42F;
    private static final float END = 0.55F;
    private static final double RANGE = 48.0;

    @Nullable
    private final Entity owner;
    private final Vec3 fallback;
    private final int variant;
    private final int delay;
    private final float seed;

    public FlatComicFx(@Nullable Entity owner, Vec3 fallback, int variant, int delay) {
        this.owner = owner;
        this.fallback = fallback;
        this.variant = Mth.clamp(variant, 0, 3);
        this.delay = delay;
        this.seed = (float) (Math.random() * 10.0);
    }

    @Override
    protected int duration() {
        return delay + (int) Math.ceil(END * 20.0F) + 1;
    }

    private Vec3 hand(float partial) {
        return owner != null && !owner.isRemoved() ? Flat.hand(owner, partial) : fallback;
    }

    private boolean self() {
        Minecraft mc = Minecraft.getInstance();
        return owner != null && owner == mc.player;
    }

    @Override
    public Vec3 focus() {
        return hand(1.0F);
    }

    @Override
    public double range() {
        return RANGE;
    }

    /** Секунды от щелчка. */
    private float since(FxFrame frame) {
        return (ticks(frame) - delay) / 20.0F;
    }

    /** Сила кадра: полная до HOLD, потом два гаснущих кадра. */
    private static float strength(float t) {
        if (t < HOLD) return 1.0F;
        return t < HOLD + FRAME ? 0.55F : 0.25F;
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        if (frame.inPortal()) return;
        float t = since(frame);
        if (t < 0.0F || t >= END) return;
        boolean full = self();
        Vec3 at = hand(frame.partial());
        float[] uv = FxManager.uvRaw(at);
        float cx, cy, radius, k;
        if (full) {
            // за камерой (третье лицо спереди) — справа внизу, как рука в кадре
            boolean seen = uv[2] > 0.05F;
            cx = seen ? Mth.clamp(uv[0], 0.0F, 1.0F) : 0.72F;
            cy = seen ? Mth.clamp(uv[1], 0.0F, 1.0F) : 0.3F;
            radius = 1.0F;
            k = strength(t);
        } else {
            if (uv[2] <= 0.05F) return;
            double d = frame.camera().distanceTo(at);
            if (d > RANGE) return;
            cx = uv[0];
            cy = uv[1];
            if (cx < -0.3F || cx > 1.3F || cy < -0.3F || cy > 1.3F) return;
            radius = (float) Mth.clamp(3.2 / Math.max(d, 0.5), 0.1, 0.42);
            k = strength(t) * (float) Mth.clamp(1.0 - d / RANGE, 0.35, 1.0);
        }
        int step = t < FLASH ? -1 : (int) ((t - FLASH) / FRAME);
        float pop = step <= 0 ? 1.35F : step == 1 ? 1.12F : step == 2 ? 1.03F : 1.0F;
        float fx = cx, fy = cy, fr = radius, fk = k, fs = step;
        out.add(new FxPass("snap_comic", u -> {
            u.f4("P0", variant, t, fk, full ? 1.0F : 0.0F);
            u.f4("P1", fx, fy, fr, seed);
            u.f4("P2", fs, pop, 0.0F, 0.0F);
        }));
    }

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        float t = since(frame);
        if (t < 0.0F || t >= END) return;
        if (self()) {
            int step = t < FLASH ? -1 : (int) ((t - FLASH) / FRAME);
            screen.stepFps = screen.stepFps > 0.0F ? Math.min(screen.stepFps, 12.0F) : 12.0F;
            screen.shake = Math.max(screen.shake, window(t, 0.0F, 0.02F, 0.12F, 0.3F) * 0.6F);
            screen.aberration = Math.max(screen.aberration, window(t, 0.0F, 0.02F, 0.25F, END) * 0.7F);
            screen.zoomBlur = Math.max(screen.zoomBlur, (step % 2 == 0 ? 0.45F : 0.15F) * window(t, 0.0F, 0.02F, 0.3F, END));
        } else {
            float p = proximity(frame, hand(frame.partial()), 16.0);
            if (p > 0.0F) screen.shake = Math.max(screen.shake, window(t, 0.0F, 0.02F, 0.1F, 0.25F) * 0.25F * p);
        }
    }
}
