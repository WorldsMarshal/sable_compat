package com.invfix.flat;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.phys.Vec3;

/**
 * Где и как лежит рисунок 3D-2D. Направления {@link #normal} и {@link #up} и «ноги» рисунка — в системе
 * его «гравитации» (FlatFrame по {@link #g} — мировому верху рисунка); в обычном режиме она совпадает с
 * миром. «Ноги» — точка на плоскости поверхности (FlatSurface): на полу — под центром, на стене — под
 * ногами; положение сущности — они же, поднятые на Flat.LIFT, в мире.
 *
 *  - {@link #FLOOR} — грань смотрит в верх рисунка: вид сверху (плоская проекция стоящей фигуры);
 *  - {@link #WALL} — грань поперёк верха: стоя, как картина; normal — куда смотрит стена, up — вверх.
 */
public final class FlatState {

    public static final int FLOOR = 1, WALL = 2;

    public int kind = FLOOR;
    public Direction normal = Direction.UP;
    public Direction up = Direction.UP;
    /** Мировой верх рисунка (его «гравитация»): UP — обычный режим. */
    public Direction g = Direction.UP;

    public FlatState() {}

    public FlatState(int kind, Direction normal, Direction up, Direction g) {
        this.kind = kind;
        this.normal = normal;
        this.up = up;
        this.g = g;
    }

    /** Тот же верх рисунка, другая поверхность. */
    public FlatState with(int kind, Direction normal, Direction up) {
        return new FlatState(kind, normal, up, g);
    }

    public FlatState copy() {
        return new FlatState(kind, normal, up, g);
    }

    public FlatFrame frame() {
        return FlatFrame.of(g);
    }

    public boolean sameSurface(FlatState o) {
        return o != null && kind == o.kind && normal == o.normal && up == o.up && g == o.g;
    }

    /** Ось вдоль поверхности, поперёк up (на стене — горизонталь вдоль неё), в системе рисунка. */
    public Direction.Axis alongAxis() {
        return FlatSurface.third(normal.getAxis(), up.getAxis());
    }

    public CompoundTag write() {
        CompoundTag t = new CompoundTag();
        t.putByte("kind", (byte) kind);
        t.putByte("normal", (byte) normal.get3DDataValue());
        t.putByte("up", (byte) up.get3DDataValue());
        t.putByte("g", (byte) g.get3DDataValue());
        return t;
    }

    public static FlatState read(CompoundTag t) {
        return new FlatState(t.getByte("kind"), Direction.from3DDataValue(t.getByte("normal")),
                Direction.from3DDataValue(t.getByte("up")),
                t.contains("g") ? Direction.from3DDataValue(t.getByte("g")) : Direction.UP);
    }

    /** Единичный вектор направления. */
    public static Vec3 vec(Direction d) {
        return new Vec3(d.getStepX(), d.getStepY(), d.getStepZ());
    }
}
