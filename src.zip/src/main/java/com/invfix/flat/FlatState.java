package com.invfix.flat;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.phys.Vec3;

/**
 * Где и как лежит рисунок 3D-2D. «Ноги» рисунка — точка на плоскости поверхности (FlatSurface):
 * на полу — под центром, на стене — под ногами; положение сущности — они же, поднятые на Flat.LIFT.
 *
 *  - {@link #FLOOR} — на полу, вид сверху (плоская проекция стоящей фигуры);
 *  - {@link #WALL} — на стене, стоя, как картина: normal — куда смотрит стена, up — вверх;
 *  - {@link #SIDE} — на полу «как на стене» (притяжение вбок): фигура лежит, голова — в сторону up.
 */
public final class FlatState {

    public static final int FLOOR = 1, WALL = 2, SIDE = 3;

    public int kind = FLOOR;
    public Direction normal = Direction.UP;
    public Direction up = Direction.UP;

    public FlatState() {}

    public FlatState(int kind, Direction normal, Direction up) {
        this.kind = kind;
        this.normal = normal;
        this.up = up;
    }

    public FlatState copy() {
        return new FlatState(kind, normal, up);
    }

    public boolean sameSurface(FlatState o) {
        return o != null && kind == o.kind && normal == o.normal && up == o.up;
    }

    /** Ось вдоль поверхности, поперёк up (на стене — горизонталь вдоль неё). */
    public Direction.Axis alongAxis() {
        return FlatSurface.third(normal.getAxis(), up.getAxis());
    }

    public CompoundTag write() {
        CompoundTag t = new CompoundTag();
        t.putByte("kind", (byte) kind);
        t.putByte("normal", (byte) normal.get3DDataValue());
        t.putByte("up", (byte) up.get3DDataValue());
        return t;
    }

    public static FlatState read(CompoundTag t) {
        return new FlatState(t.getByte("kind"), Direction.from3DDataValue(t.getByte("normal")),
                Direction.from3DDataValue(t.getByte("up")));
    }

    /** Мировой единичный вектор направления. */
    public static Vec3 vec(Direction d) {
        return new Vec3(d.getStepX(), d.getStepY(), d.getStepZ());
    }
}
