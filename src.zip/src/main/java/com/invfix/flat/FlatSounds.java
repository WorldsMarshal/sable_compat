package com.invfix.flat;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Звуки 3D-2D (все — моно, из точки):
 *  - flat/snap — щелчок пальцев X (To Be Hero X), 1,2 с: вступление и щелчок на 0,57 с (Flat#CLICK_TICKS);
 *    у 3D-2D и у 3D-2D: Attack, от руки щёлкнувшего;
 *  - flat/strike, flat/fold — удар 3D-2D: Attack (на 60 с / граффити): куски звука Tesseract из The
 *    Shooting Star 1.4.3 — tess_rw_10 («sever») и tess_rw_15 («fold»), под те же удары, что и импакт-кадры
 *    (client.FlatImpactFx).
 * Клиент играет щелчок, только если у события есть звук (вес > 0, client.FlatClient).
 */
public final class FlatSounds {

    public static final ResourceLocation SNAP_ID = ResourceLocation.fromNamespaceAndPath("sable_compat", "flat_snap");

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, "sable_compat");

    public static final DeferredHolder<SoundEvent, SoundEvent> SNAP = SOUNDS.register("flat_snap",
            () -> SoundEvent.createVariableRangeEvent(SNAP_ID));
    public static final DeferredHolder<SoundEvent, SoundEvent> STRIKE = SOUNDS.register("flat_strike",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("sable_compat", "flat_strike")));
    public static final DeferredHolder<SoundEvent, SoundEvent> FOLD = SOUNDS.register("flat_fold",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("sable_compat", "flat_fold")));

    private FlatSounds() {}
}
