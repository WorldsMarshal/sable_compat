package com.invfix.flat;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Щелчок пальцев при входе в 2D (flat/snap). Пока звука нет: в sounds.json у события пустой список —
 * клиент его не играет (client.FlatClient проверяет вес). Файл кладётся в sounds/flat/snap.ogg и
 * прописывается в sounds.json.
 */
public final class FlatSounds {

    public static final ResourceLocation SNAP_ID = ResourceLocation.fromNamespaceAndPath("sable_compat", "flat_snap");

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, "sable_compat");

    public static final DeferredHolder<SoundEvent, SoundEvent> SNAP = SOUNDS.register("flat_snap",
            () -> SoundEvent.createVariableRangeEvent(SNAP_ID));

    private FlatSounds() {}
}
