package com.invfix.flat;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Звук 3D-2D: flat/snap — щелчок пальцев X (To Be Hero X), 0,85 с, моно, от руки щёлкнувшего; сам щелчок
 * — на 0,22 с (Flat#CLICK_TICKS). Один на 3D-2D и 3D-2D: Attack. Клиент играет его, только если у события
 * есть звук (вес > 0, client.FlatClient).
 */
public final class FlatSounds {

    public static final ResourceLocation SNAP_ID = ResourceLocation.fromNamespaceAndPath("sable_compat", "flat_snap");

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, "sable_compat");

    public static final DeferredHolder<SoundEvent, SoundEvent> SNAP = SOUNDS.register("flat_snap",
            () -> SoundEvent.createVariableRangeEvent(SNAP_ID));

    private FlatSounds() {}
}
