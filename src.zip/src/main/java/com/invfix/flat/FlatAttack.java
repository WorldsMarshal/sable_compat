package com.invfix.flat;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * 3D-2D: Attack (Kitsune, LVL {@link #LVL_REQUIRED}): щелчок — и живая сущность под прицелом (до
 * {@link #RANGE} блоков) становится рисунком.
 *
 * Удар — на щелчке в звуке (Flat#CLICK_TICKS после нажатия): тогда цель становится рисунком, звучит удар
 * Tesseract (flat/strike, flat/fold), а импакт-кадры — на ударе в нём (client.FlatImpactFx).
 *
 * Куда: по линии взгляда за целью до {@link #BEHIND} блоков есть блок — на его грань (стена — стоя,
 * пол — вид сверху); иначе — на пол под ней.
 *
 * Режимы (Shift + клавиша — меню):
 *  - {@link #MODE_PLANE} — на {@link #PLANE_TICKS} тиков (60 с): рисунок двигается сам (игрок — своим
 *    управлением 3D-2D, моб — своим ИИ по тем же правилам поверхностей), уязвим, потом — обратно в 3D;
 *  - {@link #MODE_GRAFFITI} — неподвижен (ни шагу, ни поворота), через {@link #GRAFFITI_DEATH_TICKS} тиков
 *    умирает от наложившего ({@link #FOLDED}); рисунок остаётся ещё {@link #GHOST_TICKS} тиков (60 с; на
 *    клиенте — client.FlatRender).
 *
 * Своя неуязвимость 3D-2D и «мобы не замечают» на наложенный рисунок не действуют, своей клавишей из
 * него не выйти. Погибший рисунок остаётся рисунком, пока тело не исчезнет.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class FlatAttack {

    public static final String ABILITY = "§d§l3D-2D: Attack";
    public static final int LVL_REQUIRED = 100;

    public static final int MODE_PLANE = 0, MODE_GRAFFITI = 1;
    static final String MODE_KEY = "sable_compat:flat_attack_mode";

    public static final int PLANE_TICKS = 60 * 20;
    public static final int GRAFFITI_DEATH_TICKS = 20;
    public static final int GHOST_TICKS = 60 * 20;
    static final double RANGE = 32.0;
    static final double BEHIND = 6.0;
    /** Шаг моба по стене вверх / вниз — не чаще. */
    private static final int MOB_STEP_TICKS = 6;
    /** Скорость моба за тик ≈ его скорость × это (установившийся ход по земле в ванили). */
    private static final double MOB_SPEED_SCALE = 2.16;

    /**
     * Наложенный рисунок: сущность, режим, тик сервера, когда отпустить (60 с) или убить (граффити), кто
     * наложил (убийство граффити — на его счёт).
     */
    private static final class Victim {
        final LivingEntity entity;
        final int mode;
        final long until;
        final UUID caster;

        Victim(LivingEntity entity, int mode, long until, UUID caster) {
            this.entity = entity;
            this.mode = mode;
            this.until = until;
            this.caster = caster;
        }
    }

    /**
     * Смерть граффити: свой тип урона (data/sable_compat/damage_type/folded.json) — сквозь неуязвимость,
     * тотем, броню, эффекты, щит и кадры неуязвимости (теги minecraft:bypasses_*), без отбрасывания;
     * причина смерти — «{игрок} folded».
     */
    public static final net.minecraft.resources.ResourceKey<net.minecraft.world.damagesource.DamageType> FOLDED =
            net.minecraft.resources.ResourceKey.create(net.minecraft.core.registries.Registries.DAMAGE_TYPE,
                    net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("sable_compat", "folded"));

    private static final Map<UUID, Victim> VICTIMS = new HashMap<>();

    /** Щёлкнула — удар на щелчке в звуке (тик сервера due). */
    private record Pending(ServerPlayer caster, LivingEntity target, int mode, long due) {}

    private static final Map<UUID, Pending> PENDING = new HashMap<>();
    private static final Map<UUID, Boolean> KEY_DOWN = new HashMap<>();
    private static final Map<UUID, Integer> MOB_STEP = new HashMap<>();

    private FlatAttack() {}

    /** На сущность наложен 3D-2D: Attack (сервер). */
    public static boolean victim(@Nullable Entity entity) {
        return entity != null && VICTIMS.containsKey(entity.getUUID());
    }

    public static int mode(Player player) {
        return player.getPersistentData().getInt(MODE_KEY) == MODE_GRAFFITI ? MODE_GRAFFITI : MODE_PLANE;
    }

    public static boolean eligible(@Nullable Entity entity) {
        return Flat.eligible(entity);
    }

    // ── клавиша, настройки ───────────────────────────────────────────────────

    public static void handleKeyState(ServerPlayer player, boolean pressed) {
        boolean was = Boolean.TRUE.equals(KEY_DOWN.put(player.getUUID(), pressed));
        if (!pressed || was || player.isShiftKeyDown()) return;
        try {
            cast(player);
        } catch (Exception ignored) {}
    }

    static void setMode(ServerPlayer player, int mode) {
        if (!eligible(player)) return;
        player.getPersistentData().putInt(MODE_KEY, mode == MODE_GRAFFITI ? MODE_GRAFFITI : MODE_PLANE);
        sendSettings(player);
    }

    private static void sendSettings(ServerPlayer player) {
        PacketDistributor.sendToPlayer(player, new FlatPackets.AttackSettings(mode(player)));
    }

    // ── каст ─────────────────────────────────────────────────────────────────

    private static void cast(ServerPlayer player) {
        if (!eligible(player) || player.isSpectator() || PENDING.containsKey(player.getUUID())) return;
        LivingEntity target = aim(player);
        if (target == null) {
            player.displayClientMessage(Component.literal("§7Нет цели"), true);
            return;
        }
        Victim was = VICTIMS.get(target.getUUID());
        if (was != null && was.mode == MODE_GRAFFITI) return;
        FlatSurface.Placement p = place(player, target);
        if (p == null) {
            player.displayClientMessage(Component.literal("§7Цель некуда прилепить"), true);
            return;
        }
        Vec3 hand = FlatHandler.snapHand(player);
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player,
                new FlatPackets.Snap(player.getId(), hand.x, hand.y, hand.z));
        // сам удар — на щелчке в звуке
        PENDING.put(player.getUUID(), new Pending(player, target, mode(player),
                player.getServer().getTickCount() + Flat.CLICK_TICKS));
    }

    /** Щелчок прозвучал: цель — в рисунок (куда — по месту на этот момент), удар. */
    private static void strike(Pending c, long now) {
        ServerPlayer player = c.caster;
        LivingEntity target = c.target;
        if (player.isRemoved() || !player.isAlive() || target.isRemoved() || !target.isAlive()
                || target.level() != player.level()) return;
        Victim was = VICTIMS.get(target.getUUID());
        if (was != null && was.mode == MODE_GRAFFITI) return;
        FlatSurface.Placement p = place(player, target);
        if (p == null) {
            player.displayClientMessage(Component.literal("§7Цель некуда прилепить"), true);
            return;
        }
        int mode = c.mode;
        p.state().frozen = mode == MODE_GRAFFITI;
        putIn(target, p);
        // импакт-кадры (как у Tesseract) — всем рядом, с центром на рисунке
        Vec3 mid = Flat.pos(p.state(), p.feet()).add(Flat.eye(p.state(), Flat.pos(p.state(), p.feet())))
                .scale(0.5);
        PacketDistributor.sendToPlayersNear((net.minecraft.server.level.ServerLevel) target.level(), null,
                mid.x, mid.y, mid.z, 96.0, new FlatPackets.Impact(mid.x, mid.y, mid.z, mode == MODE_GRAFFITI));
        VICTIMS.put(target.getUUID(), new Victim(target, mode,
                now + (mode == MODE_GRAFFITI ? GRAFFITI_DEATH_TICKS : PLANE_TICKS), player.getUUID()));
    }

    /** Живая сущность под прицелом (не сквозь блоки). */
    @Nullable
    private static LivingEntity aim(ServerPlayer player) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 end = eye.add(look.scale(RANGE));
        BlockHitResult block = player.level().clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        if (block.getType() == HitResult.Type.BLOCK) end = block.getLocation();
        AABB box = player.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(player, eye, end, box,
                e -> e instanceof LivingEntity l && l.isAlive() && !e.isSpectator() && e != player,
                eye.distanceToSqr(end));
        return hit != null && hit.getEntity() instanceof LivingEntity l ? l : null;
    }

    /**
     * Куда прилепить: уже рисунок — туда же; по линии взгляда за целью (до BEHIND блоков) — на грань
     * блока; иначе — на пол под ней (до 16 блоков вниз).
     */
    @Nullable
    private static FlatSurface.Placement place(ServerPlayer player, LivingEntity target) {
        FlatState cur = Flat.state(target);
        if (cur != null) return new FlatSurface.Placement(cur.copy(), Flat.feet(cur, target.position()));
        Level level = target.level();
        Vec3 center = target.position().add(0.0, target.getBbHeight() * 0.5, 0.0);
        Vec3 dir = center.subtract(player.getEyePosition()).normalize();
        BlockHitResult hit = level.clip(new ClipContext(center, center.add(dir.scale(BEHIND)), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, target));
        if (hit.getType() == HitResult.Type.BLOCK) {
            Direction face = hit.getDirection();
            Vec3 at = hit.getLocation();
            FlatSurface.Placement p = null;
            if (face.getAxis().isHorizontal()) {
                // рисунок — серединой туда, куда пришёлся взгляд
                p = FlatSurface.wallAt(level, face, at.subtract(0.0, 1.0, 0.0));
            } else if (face == Direction.UP) {
                p = FlatSurface.floorAt(level, new Vec3(at.x, hit.getBlockPos().getY() + 1, at.z));
            }
            if (p != null) return p;
        }
        int y = Mth.floor(target.getY() + 1.0E-4);
        for (int dy : new int[]{0, 1}) {
            FlatSurface.Placement p = FlatSurface.floorAt(level, new Vec3(target.getX(), y + dy, target.getZ()));
            if (p != null) return p;
        }
        for (int dy = 1; dy <= 16; dy++) {
            FlatSurface.Placement p = FlatSurface.floorAt(level, new Vec3(target.getX(), y - dy, target.getZ()));
            if (p != null) return p;
        }
        return null;
    }

    /** Сущность — в рисунок. */
    private static void putIn(LivingEntity target, FlatSurface.Placement p) {
        if (target instanceof ServerPlayer sp) {
            FlatHandler.putIn(sp, p);
            return;
        }
        FlatState s = p.state();
        Flat.SERVER.put(target.getUUID(), s);
        target.stopRiding();
        target.ejectPassengers();
        target.noPhysics = true;
        target.setDeltaMovement(Vec3.ZERO);
        target.resetFallDistance();
        target.refreshDimensions();
        Vec3 pos = Flat.pos(s, p.feet());
        target.teleportTo(pos.x, pos.y, pos.z);
        if (s.frozen && target instanceof Mob mob) {
            mob.getNavigation().stop();
            mob.setNoAi(true);
        }
        broadcast(target, s, p.feet());
    }

    private static void broadcast(LivingEntity target, FlatState s, Vec3 feet) {
        PacketDistributor.sendToPlayersTrackingEntity(target,
                new FlatPackets.State(target.getId(), s.write(), feet.x, feet.y, feet.z, false));
    }

    // ── моб в 2D ─────────────────────────────────────────────────────────────

    /**
     * Ход моба-рисунка вместо travel (сервер): куда ведёт его ИИ (цель MoveControl, пока моб идёт), —
     * по поверхностям, по тем же правилам, что и у игрока: на полу — ход, ступеньки и переходы; на стене —
     * вбок, вверх / вниз по блоку. Граффити — ни шагу.
     */
    public static void travel(LivingEntity mob) {
        FlatState s = Flat.state(mob);
        if (s == null) return;
        mob.setDeltaMovement(Vec3.ZERO);
        mob.resetFallDistance();
        mob.setOnGround(true);
        BlockGetter view = FlatSurface.view(mob.level(), s);
        FlatSurface.Placement cur = new FlatSurface.Placement(s, Flat.feet(s, mob.position()));
        if (!FlatSurface.fits(view, s, cur.feet())) {
            FlatSurface.Placement moved = FlatSurface.relocate(view, cur);
            if (moved == null) {
                release(mob);
                return;
            }
            applyMob(mob, cur, moved);
            return;
        }
        if (s.frozen) return;
        FlatSurface.Placement next = cur;
        if (mob instanceof Mob m && (m.zza != 0.0F || m.xxa != 0.0F)) {
            Vec3 want = new Vec3(m.getMoveControl().getWantedX() - mob.getX(), m.getMoveControl().getWantedY() - mob.getY(),
                    m.getMoveControl().getWantedZ() - mob.getZ());
            double h = Math.sqrt(want.x * want.x + want.z * want.z);
            double step = Math.min(m.getSpeed() * MOB_SPEED_SCALE, h);
            double dx = h > 1.0E-4 ? want.x / h * step : 0.0;
            double dz = h > 1.0E-4 ? want.z / h * step : 0.0;
            if (s.kind == FlatState.FLOOR) {
                next = FlatSurface.moveFloor(view, s, cur.feet(), dx, dz);
            } else {
                Direction.Axis a = s.alongAxis();
                next = FlatSurface.moveWall(view, s, cur.feet(), a == Direction.Axis.X ? dx : a == Direction.Axis.Z ? dz : 0.0);
                int cool = MOB_STEP.getOrDefault(mob.getUUID(), 0);
                if (cool > 0) {
                    MOB_STEP.put(mob.getUUID(), cool - 1);
                } else if (next.state().kind == FlatState.WALL && Math.abs(want.y) > 0.6) {
                    FlatSurface.Placement v = want.y > 0 ? FlatSurface.wallUp(view, next.state(), next.feet())
                            : FlatSurface.wallDown(view, next.state(), next.feet());
                    if (v != null) {
                        next = v;
                        MOB_STEP.put(mob.getUUID(), MOB_STEP_TICKS);
                    }
                }
            }
        }
        applyMob(mob, cur, next);
    }

    private static void applyMob(LivingEntity mob, FlatSurface.Placement cur, FlatSurface.Placement next) {
        Vec3 pos = Flat.pos(next.state(), next.feet());
        mob.setPos(pos.x, pos.y, pos.z);
        mob.calculateEntityAnimation(false);
        if (!next.state().sameSurface(cur.state())) {
            Flat.SERVER.put(mob.getUUID(), next.state());
            mob.refreshDimensions();
            broadcast(mob, next.state(), next.feet());
        }
    }

    // ── конец ────────────────────────────────────────────────────────────────

    /** Снова 3D: в ближайшее место, куда встанет. */
    private static void release(LivingEntity entity) {
        VICTIMS.remove(entity.getUUID());
        MOB_STEP.remove(entity.getUUID());
        if (entity instanceof ServerPlayer sp) {
            FlatHandler.exit(sp, false);
            return;
        }
        FlatState s = Flat.SERVER.get(entity.getUUID());
        if (s == null) return;
        Vec3 feet = Flat.feet(s, entity.position());
        FlatSurface.Exit spot = FlatSurface.exitSpot(entity.level(), entity, new FlatSurface.Placement(s, feet),
                entity.getType().getDimensions().scale(entity.getScale()), null);
        Flat.SERVER.remove(entity.getUUID());
        entity.noPhysics = false;
        if (entity instanceof Mob mob && s.frozen) mob.setNoAi(false);
        entity.refreshDimensions();
        Vec3 to = spot != null ? spot.pos() : Flat.pos(s, feet);
        PacketDistributor.sendToPlayersTrackingEntity(entity,
                new FlatPackets.State(entity.getId(), new CompoundTag(), to.x, to.y, to.z, false));
        entity.teleportTo(to.x, to.y, to.z);
    }

    /**
     * Смерть рисунка 3D-2D: Attack. true — это он: погибает рисунком (клиенты не возвращают 3D до
     * исчезновения тела), граффити — рисунок остаётся ещё GHOST_TICKS.
     */
    static boolean onDeath(LivingEntity entity) {
        Victim v = VICTIMS.remove(entity.getUUID());
        MOB_STEP.remove(entity.getUUID());
        if (v == null) return false;
        if (v.mode == MODE_GRAFFITI) {
            FlatPackets.GraffitiDead pkt = new FlatPackets.GraffitiDead(entity.getId(), GHOST_TICKS);
            if (entity instanceof ServerPlayer sp) PacketDistributor.sendToPlayersTrackingEntityAndSelf(sp, pkt);
            else PacketDistributor.sendToPlayersTrackingEntity(entity, pkt);
        }
        return true;
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        // игроков ведёт FlatHandler (своё 3D-2D и наложенное — вместе)
        if (event.getEntity() instanceof Player || event.getEntity().level().isClientSide()) return;
        onDeath(event.getEntity());
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        long now = event.getServer().getTickCount();
        if (!PENDING.isEmpty()) {
            java.util.List<Pending> ready = new java.util.ArrayList<>();
            PENDING.values().removeIf(c -> {
                if (c.due() > now) return false;
                ready.add(c);
                return true;
            });
            for (Pending c : ready) {
                try {
                    strike(c, now);
                } catch (Exception ignored) {}
            }
        }
        if (VICTIMS.isEmpty()) return;
        Iterator<Victim> it = VICTIMS.values().iterator();
        java.util.List<Victim> due = new java.util.ArrayList<>();
        while (it.hasNext()) {
            Victim v = it.next();
            if (v.entity.isRemoved()) {
                it.remove();
                continue;
            }
            if (now >= v.until) due.add(v);
        }
        for (Victim v : due) {
            LivingEntity e = v.entity;
            if (v.mode == MODE_PLANE) {
                release(e);
            } else if (e.isAlive()) {
                // граффити: умирает от наложившего — убийство, опыт, добыча, статистика — на его счёт
                ServerPlayer caster = event.getServer().getPlayerList().getPlayer(v.caster);
                e.hurt(new net.minecraft.world.damagesource.DamageSource(e.level().registryAccess()
                        .registryOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE).getHolderOrThrow(FOLDED),
                        caster), Float.MAX_VALUE);
                if (e.isAlive()) release(e);
            }
        }
    }

    /** Моб ушёл из мира (умер и исчез, выгружен) — состояние больше не нужно. */
    @SubscribeEvent
    public static void onLeave(EntityLeaveLevelEvent event) {
        Entity e = event.getEntity();
        if (e.level().isClientSide() || e instanceof Player) return;
        if (Flat.SERVER.remove(e.getUUID()) != null) {
            VICTIMS.remove(e.getUUID());
            MOB_STEP.remove(e.getUUID());
        }
    }

    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof Player || !(event.getTarget() instanceof LivingEntity target)
                || !(event.getEntity() instanceof ServerPlayer viewer)) return;
        FlatState s = Flat.SERVER.get(target.getUUID());
        if (s == null) return;
        Vec3 feet = Flat.feet(s, target.position());
        PacketDistributor.sendToPlayer(viewer, new FlatPackets.State(target.getId(), s.write(), feet.x, feet.y, feet.z, false));
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && eligible(player)) sendSettings(player);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        KEY_DOWN.remove(event.getEntity().getUUID());
        VICTIMS.remove(event.getEntity().getUUID());
        PENDING.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        VICTIMS.remove(event.getEntity().getUUID());
    }

    /** Выбранный режим переживает смерть. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        CompoundTag old = event.getOriginal().getPersistentData();
        if (old.contains(MODE_KEY)) event.getEntity().getPersistentData().putInt(MODE_KEY, old.getInt(MODE_KEY));
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        VICTIMS.clear();
        KEY_DOWN.clear();
        PENDING.clear();
        MOB_STEP.clear();
    }
}
