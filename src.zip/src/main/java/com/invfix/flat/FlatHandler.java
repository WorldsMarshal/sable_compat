package com.invfix.flat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityEvent;
import net.neoforged.neoforge.event.entity.living.LivingChangeTargetEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 3D-2D на сервере.
 *
 * Клавиша по фронту нажатия (с Shift — ничего: это меню на клиенте): в 3D — войти (куда — по взгляду,
 * FlatSurface#enter; некуда — сообщение), в 2D — выйти в ближайшее свободное место (FlatSurface#exitSpot;
 * негде — сообщение). Двигается рисунок на клиенте (client.FlatClient), сервер принимает положение без
 * проверки столкновений (noPhysics) и смену поверхности — пакетом Move, если рисунок там помещается.
 *
 * В 2D: хитбокс {@link Flat#SIZE} (событие размера), поза — стоя, урон — только тот, что идёт сквозь
 * неуязвимость (/kill, пустота), мобы не берут в цель и бросают уже взятую. Поверхность пропала, а
 * клиент не перенёс рисунок (или прислал Drop) — выпасть в 3D.
 *
 * Смерть, смена измерения — снова 3D без выхода; выход из игры — выход (чтобы не сохраниться в стене).
 */
@EventBusSubscriber(modid = "sable_compat")
public final class FlatHandler {

    /** Сколько тиков рисунок может не помещаться, пока клиент не перенёс его, — потом выпасть. */
    private static final int LOST_TICKS = 40;

    private static final Map<UUID, Boolean> KEY_DOWN = new HashMap<>();
    private static final Map<UUID, Integer> LOST = new HashMap<>();

    private FlatHandler() {}

    public static void handleKeyState(ServerPlayer player, boolean pressed) {
        boolean was = Boolean.TRUE.equals(KEY_DOWN.put(player.getUUID(), pressed));
        if (!pressed || was || player.isShiftKeyDown()) return;
        try {
            if (Flat.SERVER.containsKey(player.getUUID())) exit(player, true);
            else enter(player);
        } catch (Exception ignored) {}
    }

    // ── вход и выход ─────────────────────────────────────────────────────────

    private static void enter(ServerPlayer player) {
        if (!Flat.eligible(player) || player.isSpectator() || player.isPassenger() || player.isSleeping()) return;
        FlatSurface.Placement p = FlatSurface.enter(player.level(), player, Flat.sideMode(player));
        if (p == null) {
            player.displayClientMessage(Component.literal("§7Некуда лечь: нужна стена рядом или пол"), true);
            return;
        }
        Vec3 hand = snapHand(player);
        FlatState s = p.state();
        Flat.SERVER.put(player.getUUID(), s);
        LOST.remove(player.getUUID());
        player.setForcedPose(Pose.STANDING);
        player.noPhysics = true;
        player.setDeltaMovement(Vec3.ZERO);
        player.resetFallDistance();
        player.refreshDimensions();
        // сначала состояние (клиент сам ставит себя в рисунок), потом телепорт
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, state(player, s, p.feet(), false, true, hand));
        Vec3 pos = Flat.pos(s, p.feet());
        player.connection.teleport(pos.x, pos.y, pos.z, player.getYRot(), player.getXRot());
        forgetAsTarget(player);
    }

    /** Точка щелчка: правая рука, поднятая перед собой. */
    private static Vec3 snapHand(Player player) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        float yaw = player.getYRot() * Mth.DEG_TO_RAD;
        Vec3 right = new Vec3(-Mth.cos(yaw), 0.0, -Mth.sin(yaw));
        return eye.add(look.scale(0.45)).add(right.scale(0.3)).add(0.0, -0.25, 0.0);
    }

    /** Выйти в 3D. ask — по клавише: негде — остаться (с сообщением); иначе — хоть на месте. */
    static void exit(ServerPlayer player, boolean ask) {
        FlatState s = Flat.SERVER.get(player.getUUID());
        if (s == null) return;
        Vec3 feet = Flat.feet(s, player.position());
        FlatSurface.Exit spot = FlatSurface.exitSpot(player.level(), player, new FlatSurface.Placement(s, feet));
        if (spot == null && ask) {
            player.displayClientMessage(Component.literal("§7Здесь не выйти: нет места"), true);
            return;
        }
        Vec3 to = spot != null ? spot.pos() : feet;
        boolean crawl = spot != null && spot.crawl();
        clear(player);
        if (crawl) player.setPose(Pose.SWIMMING);
        // сначала состояние: иначе клиент, ещё рисунок, переносил бы себя с места выхода на поверхность
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player,
                new FlatPackets.State(player.getId(), new CompoundTag(), to.x, to.y, to.z, crawl, false, 0, 0, 0));
        player.connection.teleport(to.x, to.y, to.z, player.getYRot(), player.getXRot());
    }

    /** Снова 3D на месте, без поиска места (смерть, смена измерения). */
    private static void clear(ServerPlayer player) {
        if (Flat.SERVER.remove(player.getUUID()) == null) return;
        LOST.remove(player.getUUID());
        player.setForcedPose(null);
        player.noPhysics = player.isSpectator();
        player.refreshDimensions();
    }

    private static void clearAndTell(ServerPlayer player) {
        if (!Flat.SERVER.containsKey(player.getUUID())) return;
        clear(player);
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player,
                new FlatPackets.State(player.getId(), new CompoundTag(), player.getX(), player.getY(), player.getZ(),
                        false, false, 0, 0, 0));
    }

    private static FlatPackets.State state(ServerPlayer player, FlatState s, Vec3 feet, boolean crawl, boolean snap, Vec3 hand) {
        return new FlatPackets.State(player.getId(), s.write(), feet.x, feet.y, feet.z, crawl, snap, hand.x, hand.y, hand.z);
    }

    // ── от клиента ───────────────────────────────────────────────────────────

    /** Рисунок перешёл на другую поверхность (или повернулся на полу). */
    static void onMove(ServerPlayer player, FlatState s, Vec3 feet) {
        FlatState cur = Flat.SERVER.get(player.getUUID());
        if (cur == null || s.kind < FlatState.FLOOR || s.kind > FlatState.SIDE) return;
        if (feet.distanceToSqr(Flat.feet(cur, player.position())) > 9.0) return;
        if (!FlatSurface.fits(player.level(), s, feet)) return;
        boolean surface = !s.sameSurface(cur);
        Flat.SERVER.put(player.getUUID(), s);
        if (surface) player.refreshDimensions();
        PacketDistributor.sendToPlayersTrackingEntity(player, state(player, s, feet, false, false, Vec3.ZERO));
    }

    static void drop(ServerPlayer player) {
        if (Flat.SERVER.containsKey(player.getUUID())) exit(player, false);
    }

    // ── настройки ────────────────────────────────────────────────────────────

    static void setSide(ServerPlayer player, boolean side) {
        if (!Flat.eligible(player)) return;
        player.getPersistentData().putBoolean(Flat.SIDE_KEY, side);
        sendSettings(player);
    }

    private static void sendSettings(ServerPlayer player) {
        PacketDistributor.sendToPlayer(player, new FlatPackets.Settings(Flat.sideMode(player)));
    }

    // ── размер, урон, мобы ───────────────────────────────────────────────────

    /** Хитбокс рисунка — последним, поверх размеров других способностей. Обе стороны. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onSize(EntityEvent.Size event) {
        FlatState s = Flat.state(event.getEntity());
        if (s == null) return;
        event.setNewSize(EntityDimensions.fixed(Flat.SIZE, Flat.SIZE).withEyeHeight(Flat.eyeHeight(s)));
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !Flat.SERVER.containsKey(player.getUUID())) return;
        if (!event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent event) {
        LivingEntity target = event.getNewAboutToBeSetTarget();
        if (target instanceof ServerPlayer player && Flat.SERVER.containsKey(player.getUUID())) {
            event.setNewAboutToBeSetTarget(null);
        }
    }

    /** Мобы рядом бросают игрока как цель. */
    private static void forgetAsTarget(ServerPlayer player) {
        AABB box = player.getBoundingBox().inflate(64.0);
        for (Mob mob : player.serverLevel().getEntitiesOfClass(Mob.class, box)) {
            if (mob.getTarget() == player) mob.setTarget(null);
            try {
                if (mob.getBrain().getMemory(MemoryModuleType.ATTACK_TARGET).filter(t -> t == player).isPresent()) {
                    mob.getBrain().eraseMemory(MemoryModuleType.ATTACK_TARGET);
                }
            } catch (IllegalStateException ignored) {
                // у моба нет такой памяти
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        FlatState s = Flat.SERVER.get(player.getUUID());
        if (s == null) return;
        player.resetFallDistance();
        player.setDeltaMovement(Vec3.ZERO);
        if (player.tickCount % 20 == 0) forgetAsTarget(player);
        // поверхность пропала, а клиент рисунок не перенёс — выпасть
        if (FlatSurface.fits(player.level(), s, Flat.feet(s, player.position()))) {
            LOST.remove(player.getUUID());
        } else if (LOST.merge(player.getUUID(), 1, Integer::sum) > LOST_TICKS) {
            exit(player, false);
        }
    }

    // ── жизнь ────────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) clearAndTell(player);
    }

    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (!(event.getTarget() instanceof ServerPlayer target) || !(event.getEntity() instanceof ServerPlayer viewer)) return;
        FlatState s = Flat.SERVER.get(target.getUUID());
        if (s == null) return;
        Vec3 feet = Flat.feet(s, target.position());
        PacketDistributor.sendToPlayer(viewer, state(target, s, feet, false, false, Vec3.ZERO));
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && Flat.eligible(player)) sendSettings(player);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        KEY_DOWN.remove(player.getUUID());
        FlatState s = Flat.SERVER.get(player.getUUID());
        if (s == null) return;
        Vec3 feet = Flat.feet(s, player.position());
        FlatSurface.Exit spot = FlatSurface.exitSpot(player.level(), player, new FlatSurface.Placement(s, feet));
        clear(player);
        Vec3 to = spot != null ? spot.pos() : feet;
        player.moveTo(to.x, to.y, to.z, player.getYRot(), player.getXRot());
    }

    @SubscribeEvent
    public static void onChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) clearAndTell(player);
    }

    /** Выбранный режим переживает смерть. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        CompoundTag old = event.getOriginal().getPersistentData();
        if (old.contains(Flat.SIDE_KEY)) event.getEntity().getPersistentData().putBoolean(Flat.SIDE_KEY, old.getBoolean(Flat.SIDE_KEY));
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        Flat.SERVER.clear();
        KEY_DOWN.clear();
        LOST.clear();
    }
}
