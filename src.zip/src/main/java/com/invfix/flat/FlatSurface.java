package com.invfix.flat;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Правила поверхностей 3D-2D — общие для сервера (вход, выход) и клиента (движение).
 *
 * Рисунок живёт в «клетках» перед поверхностью: клетка годится, если сама она не полный блок
 * (воздух, полублок, люк, кровать, забор, решётка… — всё, что не полный куб: под ними можно
 * проскользнуть), а за ней, против нормали, — полный блок (сама поверхность).
 *
 *  - на полу (FLOOR) — след 0,6 × 0,6 вокруг центра, все клетки слоя должны годиться;
 *  - стоя (WALL) — 2 клетки в высоту (по up) и 0,6 в ширину.
 *
 * Пол: ступенька в 1 блок вверх или вниз проходится сама; стена от 2 блоков — переход на неё снизу;
 * обрыв от 2 блоков — переход на стену обрыва сверху. Стена: вбок — плавно, внешние и внутренние углы
 * — на соседнюю стену; прыжок — на блок выше (наверху — на крышу), присед — на блок ниже (внизу — на
 * пол).
 *
 * Всё — в системе «гравитации» рисунка (FlatFrame, {@link #view}): в режиме «пол как стена» верх —
 * к голове, и те же правила дают пол мира как стену, стену, смотрящую в верх рисунка, как пол, и т.д.
 * Вход и выход — в мире ({@link #enter}, {@link #exitSpot}).
 */
public final class FlatSurface {

    /** Рисунок: как лежит и где его ноги. */
    public record Placement(FlatState state, Vec3 feet) {}

    /** Выход в 3D: куда и лёжа ли (места только на ползущий хитбокс). */
    public record Exit(Vec3 pos, boolean crawl) {}

    static final double HALF = 0.3;
    static final double EPS = 1.0E-4;
    /** Насколько заходить в соседнюю клетку при ступеньке, чтобы след целиком был в ней. */
    static final double INSET = 0.31;

    private static final EntityDimensions STANDING = EntityDimensions.scalable(0.6F, 1.8F);
    private static final EntityDimensions CRAWLING = EntityDimensions.scalable(0.6F, 0.6F);

    private FlatSurface() {}

    // ── клетки ───────────────────────────────────────────────────────────────

    public static boolean full(BlockGetter level, BlockPos pos) {
        if (level instanceof FlatFrame.View view) return view.full(pos);
        return level.getBlockState(pos).isCollisionShapeFullBlock(level, pos);
    }

    /** Мир, как его видит рисунок (в системе его гравитации). */
    public static BlockGetter view(BlockGetter world, FlatState s) {
        return s.frame().view(world);
    }

    /** Клетка годится для рисунка на поверхности с нормалью n. */
    public static boolean valid(BlockGetter level, BlockPos cell, Direction n) {
        return !full(level, cell) && full(level, cell.relative(n.getOpposite()));
    }

    static Direction.Axis third(Direction.Axis a, Direction.Axis b) {
        for (Direction.Axis x : Direction.Axis.values()) {
            if (x != a && x != b) return x;
        }
        return Direction.Axis.Y;
    }

    static int step(Direction d) {
        return d.getAxisDirection().getStep();
    }

    /** Клетка перед поверхностью (по нормали) для точки на её плоскости. */
    static int planeCell(Vec3 feet, Direction n) {
        return Mth.floor(feet.get(n.getAxis()) + 0.5 * step(n));
    }

    /** Нижняя клетка стоящей фигуры (ноги на границе клеток, фигура — в сторону up). */
    static int bottomCell(Vec3 feet, Direction up) {
        return Mth.floor(feet.get(up.getAxis()) + EPS * step(up));
    }

    static int lo(double c) {
        return Mth.floor(c - HALF + EPS);
    }

    static int hi(double c) {
        return Mth.floor(c + HALF - EPS);
    }

    static BlockPos pos(Direction.Axis a, int va, Direction.Axis b, int vb, Direction.Axis c, int vc) {
        int[] xyz = new int[3];
        xyz[a.ordinal()] = va;
        xyz[b.ordinal()] = vb;
        xyz[c.ordinal()] = vc;
        return new BlockPos(xyz[0], xyz[1], xyz[2]);
    }

    static Vec3 with(Vec3 v, Direction.Axis a, double value) {
        return switch (a) {
            case X -> new Vec3(value, v.y, v.z);
            case Y -> new Vec3(v.x, value, v.z);
            case Z -> new Vec3(v.x, v.y, value);
        };
    }

    static Direction dir(Direction.Axis axis, int sign) {
        return Direction.fromAxisAndDirection(axis,
                sign > 0 ? Direction.AxisDirection.POSITIVE : Direction.AxisDirection.NEGATIVE);
    }

    /** Граница между клеткой c и соседней в сторону d — координата по оси d. */
    static double boundary(BlockPos c, Direction d) {
        int v = c.get(d.getAxis());
        return step(d) > 0 ? v + 1 : v;
    }

    // ── помещается ли рисунок ────────────────────────────────────────────────

    public static boolean fits(BlockGetter level, FlatState s, Vec3 feet) {
        return s.kind == FlatState.FLOOR ? floorFits(level, feet) : uprightFits(level, feet, s.normal, s.up);
    }

    public static boolean floorFits(BlockGetter level, Vec3 feet) {
        int y = planeCell(feet, Direction.UP);
        for (int x = lo(feet.x); x <= hi(feet.x); x++) {
            for (int z = lo(feet.z); z <= hi(feet.z); z++) {
                if (!valid(level, new BlockPos(x, y, z), Direction.UP)) return false;
            }
        }
        return true;
    }

    public static boolean uprightFits(BlockGetter level, Vec3 feet, Direction n, Direction up) {
        Direction.Axis ua = third(n.getAxis(), up.getAxis());
        int p = planeCell(feet, n);
        int b = bottomCell(feet, up);
        double a = feet.get(ua);
        for (int k = 0; k < 2; k++) {
            for (int c = lo(a); c <= hi(a); c++) {
                if (!valid(level, pos(n.getAxis(), p, up.getAxis(), b + step(up) * k, ua, c), n)) return false;
            }
        }
        return true;
    }

    /**
     * Держится ли рисунок хоть на чём-то: есть ли хоть один полный блок из тех, к которым он прилеплен
     * (стоя — 2 ряда по ширине фигуры за поверхностью, на полу — клетки под следом).
     */
    public static boolean supported(BlockGetter level, FlatState s, Vec3 feet) {
        if (s.kind == FlatState.FLOOR) {
            int y = planeCell(feet, Direction.UP) - 1;
            for (int x = lo(feet.x); x <= hi(feet.x); x++) {
                for (int z = lo(feet.z); z <= hi(feet.z); z++) {
                    if (full(level, new BlockPos(x, y, z))) return true;
                }
            }
            return false;
        }
        Direction n = s.normal, up = s.up;
        Direction.Axis ua = third(n.getAxis(), up.getAxis());
        int p = planeCell(feet, n) - step(n);
        int b = bottomCell(feet, up);
        double a = feet.get(ua);
        for (int k = 0; k < 2; k++) {
            for (int c = lo(a); c <= hi(a); c++) {
                if (full(level, pos(n.getAxis(), p, up.getAxis(), b + step(up) * k, ua, c))) return true;
            }
        }
        return false;
    }

    // ── пол: край ────────────────────────────────────────────────────────────

    /**
     * Рисунок на полу упёрся в сторону d клеткой c (его ведущая клетка на слое пола). enter — ноги,
     * сдвинутые так, что ведущая часть целиком в соседней клетке (для ступенек).
     */
    @Nullable
    static Placement floorEdge(BlockGetter level, FlatState s, Vec3 feet, BlockPos c, Direction d, Vec3 enter) {
        BlockPos nc = c.relative(d);
        Direction.Axis da = d.getAxis();
        Direction.Axis oa = da == Direction.Axis.X ? Direction.Axis.Z : Direction.Axis.X;
        double edge = boundary(c, d);
        if (full(level, nc)) {
            if (!full(level, nc.above())) {
                Vec3 f = enter.add(0.0, 1.0, 0.0);
                return fits(level, s, f) ? new Placement(s, f) : null;
            }
            // стена от 2 блоков — на неё снизу
            return wallAt(level, s.with(FlatState.WALL, d.getOpposite(), Direction.UP),
                    with(with(feet, da, edge), Direction.Axis.Y, c.getY()), oa, c);
        }
        if (!full(level, nc.below())) {
            if (full(level, nc.below(2))) {
                Vec3 f = enter.add(0.0, -1.0, 0.0);
                return fits(level, s, f) ? new Placement(s, f) : null;
            }
            // обрыв от 2 блоков — на его стену, головой к краю
            return wallAt(level, s.with(FlatState.WALL, d, Direction.UP),
                    with(with(feet, da, edge), Direction.Axis.Y, c.getY() - 2), oa, c);
        }
        return null;
    }

    /** Стена: сначала там же вдоль неё, иначе — по центру клетки c. */
    @Nullable
    private static Placement wallAt(BlockGetter level, FlatState w, Vec3 f, Direction.Axis along, BlockPos c) {
        if (uprightFits(level, f, w.normal, w.up)) return new Placement(w, f);
        Vec3 g = with(f, along, c.get(along) + 0.5);
        return uprightFits(level, g, w.normal, w.up) ? new Placement(w, g) : null;
    }

    /** Ход по полу на (dx, dz): скольжение по осям, на главной оси — ступеньки и переходы. */
    public static Placement moveFloor(BlockGetter level, FlatState s, Vec3 feet, double dx, double dz) {
        boolean xFirst = Math.abs(dx) >= Math.abs(dz);
        Vec3 f = feet;
        for (int i = 0; i < 2; i++) {
            boolean x = (i == 0) == xFirst;
            double dd = x ? dx : dz;
            if (Math.abs(dd) < 1.0E-7) continue;
            Vec3 g = f.add(x ? dd : 0.0, 0.0, x ? 0.0 : dd);
            if (floorFits(level, g)) {
                f = g;
                continue;
            }
            if (i == 0) {
                Direction d = dir(x ? Direction.Axis.X : Direction.Axis.Z, dd > 0 ? 1 : -1);
                BlockPos c = BlockPos.containing(f.x, f.y + 0.5, f.z);
                Placement t = floorEdge(level, s, f, c, d, with(f, d.getAxis(), boundary(c, d) + INSET * step(d)));
                if (t != null) return t;
            }
        }
        return new Placement(s, f);
    }

    // ── стена ────────────────────────────────────────────────────────────────

    /** По стене вбок на a: плавно; упёрлась — внутренний или внешний угол. */
    public static Placement moveWall(BlockGetter level, FlatState s, Vec3 feet, double a) {
        if (Math.abs(a) < 1.0E-7) return new Placement(s, feet);
        Direction n = s.normal;
        Direction.Axis ua = s.alongAxis();
        Vec3 g = with(feet, ua, feet.get(ua) + a);
        if (uprightFits(level, g, n, Direction.UP)) return new Placement(s, g);
        int sign = a > 0 ? 1 : -1;
        Direction d = dir(ua, sign);
        double c0 = feet.get(ua);
        int p = planeCell(feet, n);
        BlockPos c = pos(n.getAxis(), p, Direction.Axis.Y, bottomCell(feet, Direction.UP), ua, sign > 0 ? hi(c0) : lo(c0));
        BlockPos nc = c.relative(d);
        double edge = boundary(c, d);
        // внутренний угол: впереди стена от 2 блоков — на неё
        if (full(level, nc) && full(level, nc.above())) {
            FlatState w = s.with(FlatState.WALL, d.getOpposite(), Direction.UP);
            Vec3 f = with(with(feet, ua, edge), n.getAxis(), p + 0.5);
            if (uprightFits(level, f, w.normal, w.up)) return new Placement(w, f);
            return new Placement(s, feet);
        }
        // внешний угол: стена кончилась — на боковую грань опоры
        BlockPos back = nc.relative(n.getOpposite());
        if (!full(level, nc) && !full(level, nc.above()) && (!full(level, back) || !full(level, back.above()))) {
            FlatState w = s.with(FlatState.WALL, d, Direction.UP);
            Vec3 f = with(with(feet, ua, edge), n.getAxis(), p - step(n) + 0.5);
            if (uprightFits(level, f, w.normal, w.up)) return new Placement(w, f);
        }
        return new Placement(s, feet);
    }

    /** По стене на блок выше; наверху — на крышу. */
    @Nullable
    public static Placement wallUp(BlockGetter level, FlatState s, Vec3 feet) {
        Vec3 f = feet.add(0.0, 1.0, 0.0);
        if (uprightFits(level, f, s.normal, Direction.UP)) return new Placement(s, f);
        Direction n = s.normal;
        Direction.Axis ua = s.alongAxis();
        double a = feet.get(ua);
        int p = planeCell(feet, n);
        BlockPos top = pos(n.getAxis(), p - step(n), Direction.Axis.Y, bottomCell(feet, Direction.UP) + 1, ua, Mth.floor(a));
        if (!full(level, top) || full(level, top.above())) return null;
        int layer = top.getY() + 1;
        FlatState fl = s.with(FlatState.FLOOR, Direction.UP, Direction.UP);
        Vec3 g = with(new Vec3(top.getX() + 0.5, layer, top.getZ() + 0.5), ua, a);
        if (floorFits(level, g)) return new Placement(fl, g);
        g = new Vec3(top.getX() + 0.5, layer, top.getZ() + 0.5);
        return floorFits(level, g) ? new Placement(fl, g) : null;
    }

    /** По стене на блок ниже; внизу — на пол перед ней. */
    @Nullable
    public static Placement wallDown(BlockGetter level, FlatState s, Vec3 feet) {
        Vec3 f = feet.add(0.0, -1.0, 0.0);
        if (uprightFits(level, f, s.normal, Direction.UP)) return new Placement(s, f);
        Direction n = s.normal;
        Direction.Axis ua = s.alongAxis();
        double a = feet.get(ua);
        int p = planeCell(feet, n);
        BlockPos c = pos(n.getAxis(), p, Direction.Axis.Y, bottomCell(feet, Direction.UP), ua, Mth.floor(a));
        if (!full(level, c.below())) return null;
        FlatState fl = s.with(FlatState.FLOOR, Direction.UP, Direction.UP);
        Vec3 g = with(new Vec3(c.getX() + 0.5, c.getY(), c.getZ() + 0.5), ua, a);
        if (floorFits(level, g)) return new Placement(fl, g);
        g = new Vec3(c.getX() + 0.5, c.getY(), c.getZ() + 0.5);
        return floorFits(level, g) ? new Placement(fl, g) : null;
    }

    // ── поверхность пропала: на соседнюю ─────────────────────────────────────

    /**
     * Поверхность под рисунком пропала (сломали, сдвинул поршень): на ближайшую годную рядом — сначала
     * та же, со сдвигом, потом любой пол или стена в 2 блоках. null — некуда.
     */
    @Nullable
    public static Placement relocate(BlockGetter level, Placement cur) {
        FlatState s = cur.state();
        Vec3 f = cur.feet();
        double[] offs = {0.0, 0.3, -0.3, 0.6, -0.6, 1.0, -1.0, 1.5, -1.5};
        if (s.kind == FlatState.FLOOR) {
            for (int dy : new int[]{0, -1, 1}) {
                for (double ox : offs) {
                    for (double oz : offs) {
                        Vec3 g = new Vec3(f.x + ox, Math.round(f.y) + dy, f.z + oz);
                        if (floorFits(level, g)) return new Placement(s, g);
                    }
                }
            }
        } else {
            Direction.Axis ua = s.alongAxis();
            for (int k : new int[]{0, -1, 1}) {
                for (double o : offs) {
                    Vec3 g = with(f, ua, f.get(ua) + o).add(FlatState.vec(s.up).scale(k));
                    if (uprightFits(level, g, s.normal, s.up)) return new Placement(s, g);
                }
            }
        }
        BlockPos base = BlockPos.containing(f.x, f.y + 0.5, f.z);
        for (int r = 0; r <= 2; r++) {
            for (BlockPos cell : BlockPos.betweenClosed(base.offset(-r, -r, -r), base.offset(r, r, r))) {
                if (Math.max(Math.abs(cell.getX() - base.getX()), Math.max(Math.abs(cell.getY() - base.getY()),
                        Math.abs(cell.getZ() - base.getZ()))) != r) continue;
                Placement p = anyAt(level, cell.immutable(), s);
                if (p != null) return p;
            }
        }
        return null;
    }

    /** Любой рисунок с ногами в клетке cell (тот же верх, что у s): пол, потом стены. */
    @Nullable
    private static Placement anyAt(BlockGetter level, BlockPos cell, FlatState s) {
        Vec3 center = new Vec3(cell.getX() + 0.5, cell.getY(), cell.getZ() + 0.5);
        if (floorFits(level, center)) return new Placement(s.with(FlatState.FLOOR, Direction.UP, Direction.UP), center);
        for (Direction n : Direction.Plane.HORIZONTAL) {
            Vec3 g = with(center, n.getAxis(), boundary(cell.relative(n.getOpposite()), n));
            if (uprightFits(level, g, n, Direction.UP)) return new Placement(s.with(FlatState.WALL, n, Direction.UP), g);
        }
        return null;
    }

    // ── вход ─────────────────────────────────────────────────────────────────

    /**
     * Куда лечь при входе — по взгляду: стена ближе 1,5 блока — на неё, где стоишь; пол (и в прыжке,
     * если смотришь на пол) — в точку взгляда; иначе, стоя на земле, — на пол под ногами. null — некуда.
     *
     * Обычный режим: верх рисунка — верх мира. «Пол как стена» (sideMode): на полу верх — к голове, по
     * взгляду (пол — стена в системе рисунка); на стене верх — из стены наружу (стена — пол, вид сверху).
     * Ноги рисунка — в его системе.
     */
    @Nullable
    public static Placement enter(Level level, Player player, boolean sideMode) {
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getLookAngle().scale(5.0));
        // постройка Sable — попадание в мире (SableCompat), не в её участке за миллионы блоков
        BlockHitResult hit = com.invfix.compat.SableCompat.clip(level,
                new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 pos = player.position();
        Direction head = Direction.fromYRot(player.getYRot());
        if (hit.getType() == HitResult.Type.BLOCK) {
            Direction face = hit.getDirection();
            BlockPos b = hit.getBlockPos();
            if (face.getAxis().isHorizontal()) {
                double plane = boundary(b, face);
                if (Math.abs(pos.get(face.getAxis()) - plane) <= 1.5) {
                    Placement w = sideMode
                            ? onWorldWallAsFloor(level, face, with(pos.add(0.0, 0.9, 0.0), face.getAxis(), plane))
                            : onWall(level, FlatFrame.of(Direction.UP), face, with(pos, face.getAxis(), plane));
                    if (w != null) return w;
                }
            } else if (face == Direction.UP) {
                Vec3 at = new Vec3(hit.getLocation().x, b.getY() + 1, hit.getLocation().z);
                Placement f = sideMode ? onWall(level, FlatFrame.of(head), Direction.UP, at)
                        : onFloor(level, FlatFrame.of(Direction.UP), at);
                if (f != null) return f;
            }
        }
        if (player.onGround()) {
            int y = Mth.floor(pos.y + EPS);
            for (int dy : new int[]{0, 1, -1, -2}) {
                Vec3 at = new Vec3(pos.x, y + dy, pos.z);
                Placement f = sideMode ? onWall(level, FlatFrame.of(head), Direction.UP, at)
                        : onFloor(level, FlatFrame.of(Direction.UP), at);
                if (f != null) return f;
            }
        }
        return null;
    }

    /** На стену мира (грань face), стоя, около точки at на её плоскости; верх — верх мира. null — нельзя. */
    @Nullable
    public static Placement wallAt(Level level, Direction face, Vec3 at) {
        return face.getAxis().isHorizontal() ? onWall(level, FlatFrame.of(Direction.UP), face, at) : null;
    }

    /** На пол мира около точки at (y — уровень пола); верх — верх мира. null — нельзя. */
    @Nullable
    public static Placement floorAt(Level level, Vec3 at) {
        return onFloor(level, FlatFrame.of(Direction.UP), at);
    }

    /**
     * На пол мира около точки at — лёжа, как в режиме «пол как стена»: головой в сторону head
     * (горизонталь), пол в системе рисунка — стена. null — нельзя.
     */
    @Nullable
    public static Placement lyingAt(Level level, Direction head, Vec3 at) {
        return head.getAxis().isHorizontal() ? onWall(level, FlatFrame.of(head), Direction.UP, at) : null;
    }

    /** «Пол как стена» на стене мира: верх рисунка — из стены, стена в его системе — пол. */
    @Nullable
    private static Placement onWorldWallAsFloor(Level level, Direction face, Vec3 atWorld) {
        return onFloor(level, FlatFrame.of(face), atWorld);
    }

    /**
     * На грань мира worldNormal, ставшую в системе frame стеной: стоя, ноги около точки atWorld (на её
     * плоскости).
     */
    @Nullable
    private static Placement onWall(Level level, FlatFrame frame, Direction worldNormal, Vec3 atWorld) {
        Direction n = frame.toFrame(worldNormal);
        if (n.getAxis() == Direction.Axis.Y) return null;
        BlockGetter v = frame.view(level);
        Vec3 at = frame.toFrame(atWorld);
        double plane = at.get(n.getAxis());
        Direction.Axis ua = third(n.getAxis(), Direction.Axis.Y);
        FlatState w = new FlatState(FlatState.WALL, n, Direction.UP, frame.up);
        int y = Mth.floor(at.y + 0.5);
        for (int dy : new int[]{0, -1, 1}) {
            for (double o : new double[]{0.0, 0.3, -0.3, 0.6, -0.6}) {
                Vec3 g = new Vec3(0, y + dy, 0);
                g = with(g, n.getAxis(), plane);
                g = with(g, ua, at.get(ua) + o);
                if (uprightFits(v, g, n, Direction.UP)) return new Placement(w, g);
            }
        }
        return null;
    }

    /** На грань мира, ставшую в системе frame полом (смотрит в верх рисунка): около точки atWorld. */
    @Nullable
    private static Placement onFloor(Level level, FlatFrame frame, Vec3 atWorld) {
        BlockGetter v = frame.view(level);
        Vec3 at = frame.toFrame(atWorld);
        at = new Vec3(at.x, Math.round(at.y), at.z);
        FlatState fl = new FlatState(FlatState.FLOOR, Direction.UP, Direction.UP, frame.up);
        double[] offs = {0.0, 0.3, -0.3, 0.6, -0.6};
        for (double ox : offs) {
            for (double oz : offs) {
                Vec3 g = at.add(ox, 0.0, oz);
                if (floorFits(v, g)) return new Placement(fl, g);
            }
        }
        return null;
    }

    // ── выход ────────────────────────────────────────────────────────────────

    /**
     * Где выйти в 3D: ближайшее место, куда встанет обычный хитбокс, иначе — лежачий (0,6 блока: под
     * открытым люком, в лазе); сначала в 1,6 блока от рисунка, потом в 3,2. null — негде.
     */
    @Nullable
    public static Exit exitSpot(Level level, Player player, Placement cur) {
        return exitSpot(level, player, cur, STANDING, CRAWLING);
    }

    /** Выход для любой сущности: её хитбокс стоя, иначе (если есть) — лёжа. */
    @Nullable
    public static Exit exitSpot(Level level, net.minecraft.world.entity.Entity entity, Placement cur,
                                EntityDimensions standing, @Nullable EntityDimensions crawling) {
        FlatState s = cur.state();
        FlatFrame frame = s.frame();
        // от середины рисунка, чуть от поверхности (в мире)
        Vec3 mid = cur.feet().add(FlatState.vec(s.normal).scale(0.31));
        if (s.kind == FlatState.WALL && !frame.identity()) mid = mid.add(0.0, 0.9, 0.0);
        Vec3 start = frame.toWorld(mid);
        BlockPos base = BlockPos.containing(start);
        java.util.List<BlockPos> cells = new java.util.ArrayList<>();
        for (BlockPos c : BlockPos.betweenClosed(base.offset(-3, -3, -3), base.offset(3, 3, 3))) cells.add(c.immutable());
        cells.sort(java.util.Comparator.comparingDouble(c -> c.getCenter().distanceToSqr(start)));
        for (double reach : new double[]{1.6, 3.2}) {
            for (boolean crawl : new boolean[]{false, true}) {
                if (crawl && crawling == null) continue;
                EntityDimensions dims = crawl ? crawling : standing;
                for (BlockPos c : cells) {
                    Vec3 p = new Vec3(c.getX() + 0.5, c.getY(), c.getZ() + 0.5);
                    if (p.distanceTo(start) > reach) continue;
                    // на пол клетки, если под ней что-то есть (полублок и т.п.) — ступить на его верх
                    AABB box = dims.makeBoundingBox(p);
                    if (level.noCollision(entity, box)) return new Exit(p, crawl);
                }
            }
        }
        return null;
    }
}
