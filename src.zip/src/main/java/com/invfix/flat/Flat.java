package com.invfix.flat;

import com.invfix.kitsune.KitsuneRace;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 3D-2D (Kitsune, LVL {@link #LVL_REQUIRED}): игрок теряет объём и становится рисунком на полу или
 * стене (FlatSurface — правила поверхностей, FlatHandler — сервер, client.FlatClient — движение).
 *
 * Положение игрока — «ноги» рисунка на плоскости поверхности, поднятые на {@link #LIFT} по нормали
 * (чтобы точка была вне блока). Хитбокс — {@link #SIZE}, без столкновений (noPhysics).
 */
public final class Flat {

    public static final String ABILITY = "§d§l3D-2D";
    public static final int LVL_REQUIRED = 100;

    /** Ключ режима «пол как стена» (лёжа) в persistent data игрока. */
    static final String SIDE_KEY = "sable_compat:flat_side";

    /** Отступ положения игрока от плоскости поверхности. */
    public static final double LIFT = 0.05;
    /** Ширина и высота хитбокса рисунка. */
    public static final float SIZE = 0.01F;
    /** Глаза над поверхностью (камера). */
    public static final double EYE_OUT = 0.1;
    /** Высота глаз стоящей фигуры (на стене; лёжа — вдоль up). */
    public static final double EYE_UP = 1.62;

    /** Сервер: игроки в 2D по UUID. */
    static final Map<UUID, FlatState> SERVER = new HashMap<>();
    /** Клиент: сущности в 2D по id. */
    static final Map<Integer, FlatState> CLIENT = new HashMap<>();

    private Flat() {}

    @Nullable
    public static FlatState state(@Nullable Entity entity) {
        if (!(entity instanceof Player)) return null;
        if (entity.level() == null) return null;
        return entity.level().isClientSide() ? CLIENT.get(entity.getId()) : SERVER.get(entity.getUUID());
    }

    public static boolean flat(@Nullable Entity entity) {
        return state(entity) != null;
    }

    /** Клиент: состояние сущности (пакет). null — снова 3D. */
    public static void setClient(int entityId, @Nullable FlatState s) {
        if (s == null) CLIENT.remove(entityId);
        else CLIENT.put(entityId, s);
    }

    public static void clearClient() {
        CLIENT.clear();
    }

    /** Положение игрока для ног рисунка. */
    public static Vec3 pos(FlatState s, Vec3 feet) {
        return feet.add(FlatState.vec(s.normal).scale(LIFT));
    }

    /** Ноги рисунка по положению игрока. */
    public static Vec3 feet(FlatState s, Vec3 pos) {
        return pos.subtract(FlatState.vec(s.normal).scale(LIFT));
    }

    /**
     * Глаза рисунка по положению игрока: на стене — на высоте головы, на полу — над самой поверхностью,
     * лёжа — у головы; всегда чуть над поверхностью.
     */
    public static Vec3 eye(FlatState s, Vec3 pos) {
        Vec3 out = FlatState.vec(s.normal).scale(EYE_OUT - LIFT);
        if (s.kind == FlatState.FLOOR) return pos.add(out);
        return pos.add(out).add(FlatState.vec(s.up).scale(EYE_UP));
    }

    /** Высота глаз над положением (для размеров): на стене — как стоя, иначе — над полом. */
    public static float eyeHeight(FlatState s) {
        return s.kind == FlatState.WALL ? (float) EYE_UP : (float) (EYE_OUT - LIFT);
    }

    /** Выбран ли режим «пол как стена». */
    public static boolean sideMode(Player player) {
        return player.getPersistentData().getBoolean(SIDE_KEY);
    }

    public static boolean eligible(@Nullable Entity entity) {
        if (!(entity instanceof Player player)) return false;
        try {
            InvincibleIncModVariables.PlayerVariables v = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            return KitsuneRace.isKitsune(v.Race) && v.Lvl >= LVL_REQUIRED;
        } catch (Exception e) {
            return false;
        }
    }
}
