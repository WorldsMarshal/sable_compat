package com.invfix.flat;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Пакеты 3D-2D. */
public final class FlatPackets {

    private FlatPackets() {}

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath("sable_compat", path);
    }

    /**
     * Сервер → игроки рядом и сама: игрок entityId в 2D (state — как лежит, x/y/z — ноги рисунка) или
     * снова в 3D (state пустой; crawl — вышла лёжа).
     */
    public record State(int entityId, CompoundTag state, double x, double y, double z, boolean crawl)
            implements CustomPacketPayload {
        public static final Type<State> TYPE = new Type<>(id("flat_state"));
        public static final StreamCodec<FriendlyByteBuf, State> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> {
                    buf.writeVarInt(m.entityId());
                    buf.writeNbt(m.state());
                    buf.writeDouble(m.x());
                    buf.writeDouble(m.y());
                    buf.writeDouble(m.z());
                    buf.writeBoolean(m.crawl());
                },
                buf -> new State(buf.readVarInt(), buf.readNbt(), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                        buf.readBoolean()));

        @Override public Type<State> type() { return TYPE; }

        public boolean removed() {
            return state == null || state.isEmpty();
        }
    }

    /** Сервер → игроки рядом и сама: щелчок пальцев — вспышка в точке x/y/z (рука), ещё в 3D. */
    public record Snap(double x, double y, double z) implements CustomPacketPayload {
        public static final Type<Snap> TYPE = new Type<>(id("flat_snap"));
        public static final StreamCodec<FriendlyByteBuf, Snap> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> {
                    buf.writeDouble(m.x());
                    buf.writeDouble(m.y());
                    buf.writeDouble(m.z());
                },
                buf -> new Snap(buf.readDouble(), buf.readDouble(), buf.readDouble()));

        @Override public Type<Snap> type() { return TYPE; }
    }

    /** Клиент → сервер: рисунок перешёл на другую поверхность (ноги x/y/z). */
    public record Move(CompoundTag state, double x, double y, double z) implements CustomPacketPayload {
        public static final Type<Move> TYPE = new Type<>(id("flat_move"));
        public static final StreamCodec<FriendlyByteBuf, Move> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> {
                    buf.writeNbt(m.state());
                    buf.writeDouble(m.x());
                    buf.writeDouble(m.y());
                    buf.writeDouble(m.z());
                },
                buf -> new Move(buf.readNbt(), buf.readDouble(), buf.readDouble(), buf.readDouble()));

        @Override public Type<Move> type() { return TYPE; }

        public static void handleServer(Move pkt, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (ctx.player() instanceof ServerPlayer player && pkt.state() != null)
                    FlatHandler.onMove(player, FlatState.read(pkt.state()), new net.minecraft.world.phys.Vec3(pkt.x(), pkt.y(), pkt.z()));
            });
        }
    }

    /** Клиент → сервер: поверхность пропала, а соседней нет — выпасть в 3D. */
    public record Drop() implements CustomPacketPayload {
        public static final Type<Drop> TYPE = new Type<>(id("flat_drop"));
        public static final StreamCodec<FriendlyByteBuf, Drop> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> {}, buf -> new Drop());

        @Override public Type<Drop> type() { return TYPE; }

        public static void handleServer(Drop pkt, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (ctx.player() instanceof ServerPlayer player) FlatHandler.drop(player);
            });
        }
    }

    /** Клиент → сервер: режим «пол как стена». */
    public record SetSide(boolean side) implements CustomPacketPayload {
        public static final Type<SetSide> TYPE = new Type<>(id("flat_set_side"));
        public static final StreamCodec<FriendlyByteBuf, SetSide> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> buf.writeBoolean(m.side()), buf -> new SetSide(buf.readBoolean()));

        @Override public Type<SetSide> type() { return TYPE; }

        public static void handleServer(SetSide pkt, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (ctx.player() instanceof ServerPlayer player) FlatHandler.setSide(player, pkt.side());
            });
        }
    }

    /** Сервер → игрок: выбранный режим (для меню и движения). */
    public record Settings(boolean side) implements CustomPacketPayload {
        public static final Type<Settings> TYPE = new Type<>(id("flat_settings"));
        public static final StreamCodec<FriendlyByteBuf, Settings> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> buf.writeBoolean(m.side()), buf -> new Settings(buf.readBoolean()));

        @Override public Type<Settings> type() { return TYPE; }
    }

    /** Клиент → сервер: назначить способность в слот. */
    public record Assign() implements CustomPacketPayload {
        public static final Type<Assign> TYPE = new Type<>(id("flat_assign"));
        public static final StreamCodec<FriendlyByteBuf, Assign> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> {}, buf -> new Assign());

        @Override public Type<Assign> type() { return TYPE; }

        public static void handleServer(Assign pkt, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (!(ctx.player() instanceof ServerPlayer player) || !Flat.eligible(player)) return;
                try {
                    InvincibleIncModVariables.PlayerVariables vars =
                            player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                    vars.AbilitySet = Flat.ABILITY;
                    vars.abilityDescription = Flat.ABILITY + " | LVL:" + Flat.LVL_REQUIRED
                            + " | Войти в 2D / выйти (Shift — режим пола)";
                    vars.markSyncDirty();
                } catch (Exception ignored) {}
            });
        }
    }
}
