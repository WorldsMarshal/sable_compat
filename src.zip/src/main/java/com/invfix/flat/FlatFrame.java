package com.invfix.flat;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

import javax.annotation.Nullable;

/**
 * «Гравитация» рисунка 3D-2D: мир, повёрнутый так, что верх рисунка ({@link #up}, мировое направление)
 * становится верхом (+Y). В обычном режиме верх — верх мира (поворота нет); в режиме «пол как стена» —
 * направление к голове при входе, до выхода. Правила поверхностей (FlatSurface) работают в этой
 * системе как в обычном мире: грань, смотрящая в верх, — пол (вид сверху), поперёк — стена (стоя),
 * против — потолок.
 *
 * Поворот — на 90° вокруг UP × up (для up = DOWN — на 180° вокруг X): целочисленный, клетка в клетку.
 */
public final class FlatFrame {

    private static final FlatFrame[] BY_UP = new FlatFrame[6];

    /** Мировое направление верха системы. */
    public final Direction up;
    /** Мировые образы осей системы X, Y, Z (столбцы поворота). */
    private final int[][] axes = new int[3][3];
    private final boolean identity;

    private FlatFrame(Direction up) {
        this.up = up;
        this.identity = up == Direction.UP;
        double[][] basis = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
        for (int i = 0; i < 3; i++) {
            double[] a = basis[i];
            double[] r;
            if (identity) {
                r = a;
            } else if (up == Direction.DOWN) {
                r = new double[]{a[0], -a[1], -a[2]};
            } else {
                // Родриг на 90°: k(k·a) + k × a, k = UP × up
                double kx = up.getStepZ(), kz = -up.getStepX();
                double dot = kx * a[0] + kz * a[2];
                r = new double[]{kx * dot + (-kz * a[1]), kz * a[0] - kx * a[2], kz * dot + kx * a[1]};
            }
            for (int j = 0; j < 3; j++) axes[i][j] = (int) Math.round(r[j]);
        }
    }

    public static FlatFrame of(Direction up) {
        FlatFrame f = BY_UP[up.ordinal()];
        if (f == null) BY_UP[up.ordinal()] = f = new FlatFrame(up);
        return f;
    }

    public boolean identity() {
        return identity;
    }

    public Vec3 toWorld(Vec3 f) {
        if (identity) return f;
        return new Vec3(axes[0][0] * f.x + axes[1][0] * f.y + axes[2][0] * f.z,
                axes[0][1] * f.x + axes[1][1] * f.y + axes[2][1] * f.z,
                axes[0][2] * f.x + axes[1][2] * f.y + axes[2][2] * f.z);
    }

    public Vec3 toFrame(Vec3 w) {
        if (identity) return w;
        return new Vec3(axes[0][0] * w.x + axes[0][1] * w.y + axes[0][2] * w.z,
                axes[1][0] * w.x + axes[1][1] * w.y + axes[1][2] * w.z,
                axes[2][0] * w.x + axes[2][1] * w.y + axes[2][2] * w.z);
    }

    public Direction toWorld(Direction d) {
        if (identity) return d;
        Vec3 v = toWorld(FlatState.vec(d));
        return Direction.fromDelta((int) Math.round(v.x), (int) Math.round(v.y), (int) Math.round(v.z));
    }

    public Direction toFrame(Direction d) {
        if (identity) return d;
        Vec3 v = toFrame(FlatState.vec(d));
        return Direction.fromDelta((int) Math.round(v.x), (int) Math.round(v.y), (int) Math.round(v.z));
    }

    /** Мировая клетка для клетки системы (по центру). */
    public BlockPos cellToWorld(BlockPos p) {
        if (identity) return p;
        Vec3 c = toWorld(new Vec3(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5));
        return BlockPos.containing(c.x, c.y, c.z);
    }

    /** Поворот системы для камеры и модели; null — без поворота. */
    @Nullable
    public Quaternionf quaternion() {
        if (identity) return null;
        if (up == Direction.DOWN) return new Quaternionf().rotationX(Mth.PI);
        return new Quaternionf().rotationAxis(Mth.HALF_PI, up.getStepZ(), 0.0F, -up.getStepX());
    }

    /** Мир, как его видит рисунок: клетки системы → мировые. */
    public BlockGetter view(BlockGetter world) {
        return identity ? world : new View(world, this);
    }

    /** Повёрнутый мир. Полнота блока проверяется по мировой клетке (FlatSurface#full). */
    public static final class View implements BlockGetter {
        private final BlockGetter world;
        private final FlatFrame frame;

        View(BlockGetter world, FlatFrame frame) {
            this.world = world;
            this.frame = frame;
        }

        public boolean full(BlockPos framePos) {
            BlockPos w = frame.cellToWorld(framePos);
            return world.getBlockState(w).isCollisionShapeFullBlock(world, w);
        }

        @Nullable
        @Override
        public BlockEntity getBlockEntity(BlockPos pos) {
            return world.getBlockEntity(frame.cellToWorld(pos));
        }

        @Override
        public BlockState getBlockState(BlockPos pos) {
            return world.getBlockState(frame.cellToWorld(pos));
        }

        @Override
        public FluidState getFluidState(BlockPos pos) {
            return world.getFluidState(frame.cellToWorld(pos));
        }

        @Override
        public int getHeight() {
            return world.getHeight();
        }

        @Override
        public int getMinBuildHeight() {
            return world.getMinBuildHeight();
        }
    }
}
