package com.invfix.stats;

import com.invfix.ViltrumiteImmunityHandler;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;

/**
 * Единственная точка расчёта смягчения урона.
 *
 * Раньше защита была размазана по двум местам с разными правилами:
 *   AttackDuraProcedureMixin        — ближний бой и invincible_inc:attack_power
 *   ViltrumiteImmunityHandler       — снаряды и всё остальное
 * а тип invincible_inc:powers не обрабатывался НИГДЕ и проходил в HP насквозь,
 * игнорируя весь щит. Теперь весь урон идёт через mitigate().
 */
public final class DamageMath {

    private static final String HUMAN_RACE = "\u00a7f\u00a7lHuman";

    private DamageMath() {}

    /** Результат прогона урона через конвейер. */
    public record Result(
            float raw,          // входящий урон
            double totalDr,     // суммарный процентный срез (0..1)
            float afterDr,      // после процентного среза
            double absorbed,    // сколько съел пул щита
            double drained,     // на сколько просел DamageTolerance
            float toHp          // сколько дошло до здоровья
    ) {}

    /**
     * Прогнать урон через щит. Метод МУТИРУЕТ vars.DamageTolerance, если
     * consume = true.
     *
     * @param consume списывать ли пул (false — «сухой» расчёт для UI/отладки)
     * @return результат; при отсутствии данных — сквозной прогон без изменений
     */
    public static Result mitigate(Entity victim, float raw, boolean consume) {
        if (victim == null || raw <= 0.0F) {
            return new Result(raw, 0, raw, 0, 0, raw);
        }

        InvincibleIncModVariables.PlayerVariables vars;
        try {
            vars = victim.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        } catch (Exception ignored) {
            return new Result(raw, 0, raw, 0, 0, raw);
        }

        // Human не имеет расовой защиты — у него DamageTolerance принудительно 0.
        if (HUMAN_RACE.equals(vars.Race)) {
            return new Result(raw, 0, raw, 0, 0, raw);
        }

        // ── 1. Процентный срез от Durability ────────────────────────────────
        double duraEff = vars.currentDura
                * safeMul(vars.statMultiplier)
                * safeMul(vars.DurabilityStatMultiplier);

        double duraDr = 0.0D;
        if (duraEff > 0.0D) {
            duraDr = ShieldConfig.DURA_DR_MAX * duraEff / (duraEff + ShieldConfig.DURA_DR_HALF);
        }

        // ── 2. Базовый DamageReduction (стат из UI) ─────────────────────────
        double baseDr = 0.0D;
        if (ShieldConfig.USE_BASE_DR) {
            baseDr = clamp(vars.DamageReduction, 0.0D, 0.95D);
        }

        // Слои мультипликативны: 60% и 40% дают 76%, а не 100%.
        double totalDr = 1.0D - (1.0D - duraDr) * (1.0D - baseDr);
        totalDr = clamp(totalDr, 0.0D, ShieldConfig.TOTAL_DR_CAP);

        float afterDr = (float) (raw * (1.0D - totalDr));

        // ── 3. Пул щита ─────────────────────────────────────────────────────
        double tolerance = Math.max(0.0D, vars.DamageTolerance);
        double drainRate = drainRate(vars.Race, vars.currentDura);
        double capacity = tolerance / drainRate;

        double absorbed = Math.min(afterDr, capacity);
        double drained = absorbed * drainRate;

        if (consume && drained > 0.0D) {
            try {
                vars.DamageTolerance = Math.max(0.0D, tolerance - drained);
                vars.markSyncDirty();
            } catch (Exception ignored) {}
        }

        // ── 4. Остаток в HP ─────────────────────────────────────────────────
        float toHp = (float) Math.max(0.0D, afterDr - absorbed);
        if (toHp > 0.0F && toHp < ShieldConfig.MIN_CHIP) {
            toHp = ShieldConfig.MIN_CHIP;
        }

        return new Result(raw, totalDr, afterDr, absorbed, drained, toHp);
    }

    /**
     * Расход пула на единицу поглощённого урона.
     * Меньше — эффективнее щит (Metroman 0.1 = пул ×10).
     */
    public static double drainRate(String race, double currentDura) {
        double rate = ViltrumiteImmunityHandler.getRaceMultiplier(race);

        if (ShieldConfig.USE_DYNAMIC_DRAIN) {
            rate *= 1.0D / (1.0D + ShieldConfig.DYNAMIC_ALPHA * currentDura);
        }

        return Math.max(ShieldConfig.MIN_DRAIN, rate);
    }

    /** Полная ёмкость щита в единицах урона — для HUD и отладки. */
    public static double shieldCapacity(Entity entity) {
        try {
            InvincibleIncModVariables.PlayerVariables v =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            return v.DamageTolerance / drainRate(v.Race, v.currentDura);
        } catch (Exception ignored) {
            return 0.0D;
        }
    }

    /** Сырой урон, необходимый для ваншота с полным щитом. */
    public static double oneShotThreshold(Entity entity) {
        try {
            InvincibleIncModVariables.PlayerVariables v =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);

            Result dry = mitigate(entity, 1000.0F, false);
            double keep = 1.0D - dry.totalDr();
            if (keep <= 0.0D) return Double.POSITIVE_INFINITY;

            double hp = entity instanceof net.minecraft.world.entity.LivingEntity le
                    ? le.getHealth() : v.currentHealth;

            return (shieldCapacity(entity) + hp) / keep;
        } catch (Exception ignored) {
            return 0.0D;
        }
    }

    private static double safeMul(double v) {
        return (v <= 0.0D || Double.isNaN(v)) ? 1.0D : v;
    }

    private static double clamp(double v, double lo, double hi) {
        return v < lo ? lo : Math.min(v, hi);
    }
}
