package com.invfix.stats;

import com.invfix.mixin.RangedAttributeAccessor;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;

/**
 * Снятие ванильных потолков атрибутов.
 *
 * Мод invincible_inc пишет статы напрямую в ванильные атрибуты, но у тех зашит
 * RangedAttribute-диапазон. Всё выше потолка срезается на чтении: стат в GUI
 * растёт, фактическая величина стоит.
 *
 *   MAX_HEALTH      1024 -> 2e9
 *   MAX_ABSORPTION  2048 -> 2e9
 *   ATTACK_DAMAGE   2048 -> 2e9
 *
 * Не трогаем осознанно: MOVEMENT_SPEED (ломается коллизия и прогрузка чанков,
 * плюс AttributeCaps и так прижимает к 0.28), ARMOR (CombatRules внутри формулы
 * клампит до 20), KNOCKBACK_RESISTANCE (это доля 0..1).
 *
 * ── ДВА ПУТИ ЗАПИСИ ──────────────────────────────────────────────────────────
 * Основной — миксин-аксессор {@link RangedAttributeAccessor}. Запасной —
 * рефлексия: для НЕстатических final-полей setAccessible(true) даёт право на
 * запись, так что это рабочий путь, если аксессор почему-то не применился
 * (например потерялась строка в sable_compat.mixins.json).
 *
 * Молчаливого провала быть не должно: если не сработал ни один путь — WARN.
 * Иначе HP остаётся 1024 при статe 38445, и симптом выглядит как «мод не пашет».
 *
 * ── ТОЧНОСТЬ ─────────────────────────────────────────────────────────────────
 * maxValue — double, 2e9 туда влезает. Но здоровье живёт в float
 * (LivingEntity.DATA_HEALTH_ID): мантисса 24 бита -> целые точны до 2^24 =
 * 16 777 216. На 1e9 шаг уже 64, то есть урон меньше 32 округлится в ноль.
 * Потолок сам по себе безвреден — это граница clamp'а; опасно лишь фактическое
 * HP выше FLOAT_SAFE. RealHealthSync это стережёт.
 */
@EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD)
public final class AttributeLimits {

    private static final Logger LOG = LoggerFactory.getLogger("invfix/attr-limits");

    /** Граница int (2147483647) с запасом вниз. */
    public static final double CEILING = 2_000_000_000.0D;

    /** Выше этого значения float перестаёт быть точным до единицы. */
    public static final double FLOAT_SAFE = 16_777_216.0D;

    private AttributeLimits() {}

    @SubscribeEvent
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(AttributeLimits::apply);
    }

    private static void apply() {
        raise(Attributes.MAX_HEALTH,     "MAX_HEALTH",     CEILING);
        raise(Attributes.MAX_ABSORPTION, "MAX_ABSORPTION", CEILING);
        raise(Attributes.ATTACK_DAMAGE,  "ATTACK_DAMAGE",  CEILING);
    }

    private static void raise(Holder<Attribute> holder, String name, double newMax) {
        Attribute attr;
        try {
            attr = holder.value();
        } catch (Throwable t) {
            LOG.warn("[invfix] {}: атрибут недоступен, потолок не снят", name);
            return;
        }

        if (!(attr instanceof RangedAttribute)) {
            LOG.warn("[invfix] {}: не RangedAttribute, потолок не снят", name);
            return;
        }

        if (viaAccessor(attr, newMax) || viaReflection(attr, newMax)) return;

        LOG.warn("[invfix] {}: НЕ УДАЛОСЬ снять потолок — ни миксин, ни рефлексия "
                + "не сработали. Проверь, что \"RangedAttributeAccessor\" прописан "
                + "в sable_compat.mixins.json", name);
    }

    /** Основной путь: миксин-аксессор. */
    private static boolean viaAccessor(Attribute attr, double newMax) {
        try {
            if (attr instanceof RangedAttributeAccessor acc) {
                if (acc.invfix$getMaxValue() >= newMax) return true;
                acc.invfix$setMaxValue(newMax);
                return acc.invfix$getMaxValue() >= newMax;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    /** Запасной путь: прямая запись в поле. */
    private static boolean viaReflection(Attribute attr, double newMax) {
        try {
            Field f = RangedAttribute.class.getDeclaredField("maxValue");
            f.setAccessible(true);
            if (f.getDouble(attr) >= newMax) return true;
            f.setDouble(attr, newMax);
            return f.getDouble(attr) >= newMax;
        } catch (Throwable ignored) {
            return false;
        }
    }
}
