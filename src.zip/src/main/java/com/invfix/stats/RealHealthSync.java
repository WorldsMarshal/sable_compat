package com.invfix.stats;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Приведение фактического MAX_HEALTH к стату Health.
 *
 * ИНВАРИАНТ МОДА: vars.currentHealth == baseValue(MAX_HEALTH).
 * Обе величины двигаются синхронно:
 *   WhenjoinFirstTimeProcedure / FullResetProcedure — обе в 20.0
 *   HealthStatUpProcedure                           — обе +1 за итерацию
 *   SetHealthProcedure (команда)                    — обе в аргумент
 *
 * Расхождение возникало из-за клампа на чтении (см. AttributeLimits): стат рос,
 * getMaxHealth() возвращал 1024. После снятия потолка baseValue сам по себе
 * встаёт на место — но у части игроков он мог разъехаться, если по нему проехали
 * сторонние процедуры или сейв переносился между версиями. Этот класс чинит
 * расхождение и подтягивает текущее HP, чтобы игрок не остался с 1024/38445.
 *
 * ВАЖНО: правится именно baseValue. Модификаторы (импланты, NanoHeart,
 * Nanomachines, брошки Mk2) живут отдельным слоем и не затрагиваются.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class RealHealthSync {

    /** Как часто сверять инвариант в тике (тиков). */
    private static final int CHECK_INTERVAL = 40;

    /** Порог расхождения, ниже которого не дёргаемся (float-погрешность). */
    private static final double EPSILON = 0.5D;

    private RealHealthSync() {}

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        sync(event.getEntity(), true);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        sync(event.getEntity(), true);
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        sync(event.getEntity(), true);
    }

    @SubscribeEvent
    public static void onTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) return;
        if (player.tickCount % CHECK_INTERVAL != 0) return;
        sync(player, false);
    }

    /**
     * @param healUp подтянуть текущее HP до нового максимума (вход/респаун/клон).
     *               В тике этого не делаем — иначе игрок хилился бы бесплатно
     *               каждый раз, когда стат Health вырастет посреди боя.
     */
    public static void sync(Player player, boolean healUp) {
        if (player == null || player.level().isClientSide()) return;

        double stat;
        try {
            stat = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES).currentHealth;
        } catch (Exception ignored) {
            return;
        }

        // 0 — игрок ещё не инициализирован модом (первый вход до WhenjoinFirstTime).
        if (stat <= 0.0D) return;

        // Не даём вылезти за пределы точной зоны float — иначе мелкий урон
        // начнёт молча теряться на округлении.
        if (stat > AttributeLimits.FLOAT_SAFE) {
            stat = AttributeLimits.FLOAT_SAFE;
        }

        AttributeInstance inst = player.getAttribute(Attributes.MAX_HEALTH);
        if (inst == null) return;

        if (Math.abs(inst.getBaseValue() - stat) > EPSILON) {
            inst.setBaseValue(stat);
        }

        float max = player.getMaxHealth();
        if (player.getHealth() > max) {
            player.setHealth(max);
        } else if (healUp && player.getHealth() > 0.0F && player.getHealth() < max) {
            player.setHealth(max);
        }
    }
}
