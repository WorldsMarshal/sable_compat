package com.invfix.stats;

import net.mcreator.invincibleinc.init.InvincibleIncModMobEffects;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Процентный реген HP вне боя для здоровья, вкачанного модом invincible_inc.
 *
 * ── ЗАЧЕМ ────────────────────────────────────────────────────────────────────
 * Ванильная регенерация — единицы HP за секунды, она рассчитана на пул в 20.
 * После фикса реального maxHealth пулы стали шести-семизначными: отхилить
 * ~500k HP после драки с Торментором ванильным темпом — часы реального
 * времени. Реген должен масштабироваться вместе с пулом, поэтому процент.
 *
 * ── МЕХАНИКА ─────────────────────────────────────────────────────────────────
 *   вне боя (нет эффекта IN_COMBAT): +HP_REGEN_FRACTION от maxHealth за цикл
 *   в бою: ничего — этот реген боевой баланс не трогает вообще
 *
 * Каденс цикла — тот же, что у регена щита (DurabilityRegenerationProcedure):
 * там таймер копит DamageReductionRegenNumber за тик до порога
 * DamageReductionRegenTimeMax (по умолчанию 200; Number 1.0–2.0 от статов,
 * т.е. цикл 100–200 тиков = 5–10 сек). Свой счётчик мы не заводим и чужой
 * не трогаем — период вычисляется из тех же переменных:
 *
 *   период = ceil(TimeMax / Number) тиков
 *
 * ── КОМУ ПОЛОЖЕНО ────────────────────────────────────────────────────────────
 * Только персонажам, чьё HP вкачано модом: стат currentHealth > BASE_HEALTH
 * (ванильные 20). Human и свежие персонажи на базовых 20 живут на ванильной
 * регенерации, для них ничего не меняется.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class HealthRegen {

    /** Доля maxHealth, восстанавливаемая за цикл вне боя. */
    public static final double HP_REGEN_FRACTION = 0.05D;

    /** Базовое ванильное здоровье: стат выше — значит, HP вкачано модом. */
    private static final double BASE_HEALTH = 20.0D;

    private HealthRegen() {}

    @SubscribeEvent
    public static void onTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) return;
        if (!player.isAlive()) return;

        InvincibleIncModVariables.PlayerVariables vars;
        try {
            vars = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        } catch (Exception ignored) {
            return;
        }

        // Только модовое HP.
        if (vars.currentHealth <= BASE_HEALTH) return;

        // Каденс цикла — как у регена щита.
        double number = vars.DamageReductionRegenNumber > 0.0D
                ? vars.DamageReductionRegenNumber : 1.0D;
        double timeMax = vars.DamageReductionRegenTimeMax > 0.0D
                ? vars.DamageReductionRegenTimeMax : 200.0D;
        int period = Math.max(1, (int) Math.ceil(timeMax / number));

        if (player.tickCount % period != 0) return;

        // Только вне боя.
        if (player.hasEffect(InvincibleIncModMobEffects.IN_COMBAT)) return;

        float max = player.getMaxHealth();
        float hp = player.getHealth();
        if (hp <= 0.0F || hp >= max) return;

        float heal = (float) (max * HP_REGEN_FRACTION);
        player.setHealth(Math.min(max, hp + heal));
    }
}
