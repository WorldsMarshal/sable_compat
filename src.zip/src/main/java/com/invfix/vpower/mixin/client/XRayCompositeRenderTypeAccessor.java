package com.invfix.vpower.mixin.client;

import net.minecraft.client.renderer.RenderType.CompositeState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(
   targets = {"net.minecraft.client.renderer.RenderType$CompositeRenderType"}
)
public interface XRayCompositeRenderTypeAccessor {
   @Accessor("state")
   CompositeState theboysmod$getState();
}
