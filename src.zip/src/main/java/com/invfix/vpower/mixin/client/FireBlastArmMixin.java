package com.invfix.vpower.mixin.client;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.FireBlastSkill;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(
   value = {HumanoidModel.class},
   priority = 3000
)
public class FireBlastArmMixin<T extends LivingEntity> {
   @Shadow
   @Final
   public ModelPart rightArm;

   @Inject(
      method = {"setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V"},
      at = {@At("RETURN")}
   )
   private void adjustArmForFireBlast(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo ci) {
      if (entity instanceof Player player) {
         SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         String skillId = FireBlastSkill.ID.toString();
         if (skillData.isSkillActive(skillId)) {
            float pitchRad = (float)Math.toRadians((double)headPitch);
            float yawRad = (float)Math.toRadians((double)netHeadYaw);
            this.rightArm.xRot = -1.5708F + pitchRad;
            this.rightArm.yRot = yawRad;
            this.rightArm.zRot = 0.0F;
         }
      }
   }
}
