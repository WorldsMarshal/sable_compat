package com.invfix.vpower.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.ToadSkill;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({LivingEntity.class})
public class LeglessPlayerMixin {
   private static final float TOAD_MAX_HEIGHT = 1.0F;
   private static final String TOAD_ID = ToadSkill.ID.toString();

   @ModifyReturnValue(
      method = {"getDimensions"},
      at = {@At("RETURN")}
   )
   private EntityDimensions theboysMod$modifyDimensions(EntityDimensions original) {
      LivingEntity self = (LivingEntity)(Object)this;
      if (self instanceof Player player && theboysMod$hasToadSkill(player)) {
         return theboysMod$capHeight(original, 1.0F);
      }

      FleshRegenData data;
      try {
         data = (FleshRegenData)self.getData(ModAttachments.FLESH_REGEN.get());
      } catch (Exception var10) {
         return original;
      }

      if (self.isPassenger()) {
         return original;
      } else {
         int bodyScore = data.getScore("Body");
         int rightLegScore = data.getScore("Right.Leg");
         int leftLegScore = data.getScore("Left.Leg");
         int rightFeetScore = data.getScore("Right.Feet");
         int leftFeetScore = data.getScore("Left.Feet");
         float heightScale = 1.0F;
         if (bodyScore == 0) {
            heightScale = 0.2F;
         } else if (rightLegScore == 0 && leftLegScore == 0) {
            heightScale = 0.5F;
         } else if (rightFeetScore == 0 && leftFeetScore == 0) {
            heightScale = 0.85F;
         }

         return heightScale != 1.0F ? original.scale(1.0F, heightScale) : original;
      }
   }

   private static boolean theboysMod$hasToadSkill(Player player) {
      try {
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         return data.hasSkill(TOAD_ID);
      } catch (Exception var2) {
         return false;
      }
   }

   private static EntityDimensions theboysMod$capHeight(EntityDimensions original, float maxHeight) {
      return !(original.height() <= maxHeight) && !(original.height() <= 0.0F) ? original.scale(1.0F, maxHeight / original.height()) : original;
   }
}
