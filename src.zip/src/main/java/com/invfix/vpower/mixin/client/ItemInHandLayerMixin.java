package com.invfix.vpower.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.invfix.vpower.client.belial.NailongBelialClientHandler;
import com.invfix.vpower.client.toad.ToadClientHandler;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ItemInHandLayer.class})
public class ItemInHandLayerMixin {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void theboysMod$hideHeldItemsInToad(
      PoseStack poseStack,
      MultiBufferSource buffer,
      int packedLight,
      LivingEntity livingEntity,
      float limbSwing,
      float limbSwingAmount,
      float partialTicks,
      float ageInTicks,
      float netHeadYaw,
      float headPitch,
      CallbackInfo ci
   ) {
      if (livingEntity instanceof AbstractClientPlayer player && (ToadClientHandler.hasToad(player) || NailongBelialClientHandler.isTransformed(player))) {
         ci.cancel();
      }
   }
}
