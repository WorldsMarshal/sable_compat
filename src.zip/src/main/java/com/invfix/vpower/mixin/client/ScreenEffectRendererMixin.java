package com.invfix.vpower.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.util.IntangibilityUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ScreenEffectRenderer.class})
public class ScreenEffectRendererMixin {
   @Inject(
      method = {"renderScreenEffect"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void theboysmod$skipFireOverlay(Minecraft minecraft, PoseStack poseStack, CallbackInfo ci) {
      try {
         if (minecraft.player != null) {
            SkillData data = (SkillData)minecraft.player.getData(ModSkillAttachments.SKILL_DATA.get());
            if (data.getFireTimer() > 0) {
               ci.cancel();
               return;
            }

            if (IntangibilityUtil.hasAnyIntangibleSkillActive(data)) {
               ci.cancel();
            }
         }
      } catch (Throwable var4) {
      }
   }
}
