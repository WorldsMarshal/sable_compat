package com.invfix.vpower.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.invfix.vpower.VPower;
import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.client.ClientSkillStateCache;
import com.invfix.vpower.client.belial.NailongBelialClientHandler;
import com.invfix.vpower.client.dynamictexture.FleshRegenTextureManager;
import com.invfix.vpower.client.dynamictexture.HumanTorchTextureManager;
import com.invfix.vpower.client.fashionegg.EggShellClientHandler;
import com.invfix.vpower.client.flight.FlightClientHandler;
import com.invfix.vpower.client.invisibility.InvisibilityRenderHelper;
import com.invfix.vpower.client.renderer.FleshRegenEntityRenderer;
import com.invfix.vpower.client.renderer.HumanTorchRenderer;
import com.invfix.vpower.client.renderer.layer.DiamondClawsLayer;
import com.invfix.vpower.client.toad.ToadClientHandler;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.ChickenEggHeadSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LivingEntityRenderer.class})
public abstract class LivingEntityRendererMixin<T extends LivingEntity, M extends EntityModel<T>> {
   @Unique
   private FleshRegenEntityRenderer theboysMod$fleshRegenRenderer;
   @Unique
   private HumanTorchRenderer theboysMod$humanTorchRenderer;
   @Unique
   private int theboysMod$savedHurtTime = 0;
   @Shadow
   protected M model;

   @Shadow
   public abstract boolean addLayer(RenderLayer<T, M> var1);

   @Inject(
      method = {"<init>"},
      at = {@At("TAIL")}
   )
   @SuppressWarnings({"unchecked", "rawtypes"})
   private void onInit(Context context, EntityModel<T> model, float shadowRadius, CallbackInfo ci) {
      if (model instanceof HumanoidModel) {
         this.theboysMod$fleshRegenRenderer = new FleshRegenEntityRenderer();
         this.theboysMod$humanTorchRenderer = new HumanTorchRenderer();
         this.addLayer((RenderLayer<T, M>)new DiamondClawsLayer((RenderLayerParent)(Object)this));
      }
   }

   @Inject(
      method = {"render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"},
      at = {@At("HEAD")}
   )
   private void theboysMod$setHurtTimeForFire(
      T entity, float entityYaw, float partialTicks, PoseStack matrixStack, MultiBufferSource buffer, int packedLight, CallbackInfo ci
   ) {
      this.theboysMod$savedHurtTime = entity.hurtTime;
      boolean invisibilityHidden = InvisibilityRenderHelper.shouldHideBody(entity);

      try {
         SkillData skillData = (SkillData)entity.getData(ModSkillAttachments.SKILL_DATA.get());
         if (entity instanceof AbstractClientPlayer player
            && skillData.getFireTimer() > 0
            && !EggShellClientHandler.shouldHideBody(player)
            && !ToadClientHandler.hasToad(player)
            && !NailongBelialClientHandler.isTransformed(player)
            && !invisibilityHidden) {
            entity.hurtTime = 10;
         }

         int vt = skillData.getVibrateTimer();
         if (vt > 0) {
            float previous = (float)skillData.getPrevVibrateTimer();
            float intensity = Mth.lerp(partialTicks, previous, (float)vt) / 10.0F;
            float offsetX = (float)(Math.random() - 0.5) * 0.14F * intensity;
            float offsetZ = (float)(Math.random() - 0.5) * 0.14F * intensity;
            matrixStack.translate(offsetX, 0.0F, offsetZ);
         }
      } catch (Exception var16) {
      }
   }

   @Inject(
      method = {"render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"},
      at = {@At(
         value = "INVOKE",
         shift = Shift.AFTER,
         target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;setupRotations(Lnet/minecraft/world/entity/LivingEntity;Lcom/mojang/blaze3d/vertex/PoseStack;FFFF)V"
      )}
   )
   private void theboysMod$applyEggShellRoll(
      T entity, float entityYaw, float partialTicks, PoseStack matrixStack, MultiBufferSource buffer, int packedLight, CallbackInfo ci
   ) {
      if (entity instanceof AbstractClientPlayer player && EggShellClientHandler.shouldHideBody(player)) {
         float roll = EggShellClientHandler.getBodyRollDegrees(player, partialTicks);
         if (Math.abs(roll) < 0.01F) {
            return;
         }

         matrixStack.translate(0.0F, 0.9F, 0.0F);
         matrixStack.mulPose(Axis.XP.rotationDegrees(roll));
         matrixStack.translate(0.0F, -0.9F, 0.0F);
         return;
      }
   }

   @Inject(
      method = {"render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"},
      at = {@At(
         value = "INVOKE",
         shift = Shift.AFTER,
         target = "Lnet/minecraft/client/model/EntityModel;setupAnim(Lnet/minecraft/world/entity/Entity;FFFFF)V"
      )}
   )
   private void onRender(T entity, float entityYaw, float partialTicks, PoseStack matrixStack, MultiBufferSource buffer, int packedLight, CallbackInfo ci) {
      if (entity instanceof AbstractClientPlayer player && this.model instanceof PlayerModel<?> playerModel) {
         boolean invisibilityHidden = InvisibilityRenderHelper.shouldHideBody(player);
         if (player.isSpectator()) {
            return;
         }

         Minecraft mc = Minecraft.getInstance();
         boolean isFirstPersonSelf = mc.player != null && mc.player == player && mc.options.getCameraType().isFirstPerson();
         boolean hasGuiOpen = mc.screen != null;
         if (isFirstPersonSelf && !hasGuiOpen) {
            if (EggShellClientHandler.shouldHideBody(player)) {
               this.theboysMod$hideEggShellPlayerParts(player, playerModel);
            }

            if (ToadClientHandler.hasToad(player)) {
               this.theboysMod$hideAllPlayerParts(playerModel);
               return;
            }

            if (NailongBelialClientHandler.isTransformed(player)) {
               this.theboysMod$hideAllPlayerParts(playerModel);
               return;
            }

            if (invisibilityHidden) {
               this.theboysMod$hideAllPlayerParts(playerModel);
               return;
            }

            try {
               SkillData fpSkillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
               int fpFireTimer = fpSkillData.getFireTimer();
               if (!EggShellClientHandler.shouldHideBody(player) && fpFireTimer > 0 && HumanTorchTextureManager.shouldRenderBody(fpFireTimer)) {
                  ResourceLocation fpTexture = HumanTorchTextureManager.getTexture(fpFireTimer);
                  if (fpTexture != null) {
                     RenderType fpRenderType = HumanTorchRenderer.getTranslucentNoDepthTest(fpTexture);
                     VertexConsumer fpConsumer = buffer.getBuffer(fpRenderType);
                     int fpColor = -50331649;
                     matrixStack.pushPose();
                     matrixStack.translate(0.0, 0.9, 0.0);
                     matrixStack.scale(1.01F, 1.01F, 1.01F);
                     matrixStack.translate(0.0, -0.9, 0.0);
                     playerModel.renderToBuffer(matrixStack, fpConsumer, 15728880, OverlayTexture.NO_OVERLAY, fpColor);
                     matrixStack.popPose();
                  }
               }
            } catch (Exception var36) {
               VPower.LOGGER.error("[HumanTorch Mixin] FP render error", var36);
            }

            return;
         }

         if (FlightClientHandler.isFlying() && !player.isFallFlying() && playerModel.attackTime > 0.0F && player.attackAnim > 0.0F) {
            ModelPart rightArm = playerModel.rightArm;
            float f1 = 1.0F - playerModel.attackTime;
            f1 *= f1;
            f1 *= f1;
            f1 = 1.0F - f1;
            float f2 = Mth.sin(f1 * (float) Math.PI);
            float f3 = Mth.sin(playerModel.attackTime * (float) Math.PI) * -(playerModel.head.xRot - 0.7F) * 0.75F;
            rightArm.xRot -= f2 * 1.2F + f3;
            rightArm.zRot = rightArm.zRot + Mth.sin(playerModel.attackTime * (float) Math.PI) * -0.4F;
            playerModel.rightSleeve.copyFrom(rightArm);
         }

         FleshRegenData data = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
         int headValue = data.getScore("Head");
         boolean hideHead = FleshRegenTextureManager.shouldHidePlayerHead(headValue) || this.theboysMod$hasChickenEggHead(player);
         playerModel.head.visible = !hideHead;
         playerModel.hat.visible = !hideHead;
         int bodyValue = data.getScore("Body");
         boolean hideBody = FleshRegenTextureManager.shouldHidePlayerBody(bodyValue);
         playerModel.body.visible = !hideBody;
         playerModel.jacket.visible = !hideBody;
         int rightArmValue = data.getScore("Right.Arm");
         int rightHandValue = data.getScore("Right.Hand");
         boolean hideRightArm = rightArmValue >= 0 && rightArmValue <= 17 || rightHandValue >= 0 && rightHandValue <= 11;
         playerModel.rightArm.visible = !hideRightArm;
         playerModel.rightSleeve.visible = !hideRightArm;
         int leftArmValue = data.getScore("Left.Arm");
         int leftHandValue = data.getScore("Left.Hand");
         boolean hideLeftArm = leftArmValue >= 0 && leftArmValue <= 17 || leftHandValue >= 0 && leftHandValue <= 11;
         playerModel.leftArm.visible = !hideLeftArm;
         playerModel.leftSleeve.visible = !hideLeftArm;
         int rightLegValue = data.getScore("Right.Leg");
         int rightFeetValue = data.getScore("Right.Feet");
         boolean hideRightLeg = rightLegValue >= 0 && rightLegValue <= 19 || rightFeetValue >= 0 && rightFeetValue <= 10;
         playerModel.rightLeg.visible = !hideRightLeg;
         playerModel.rightPants.visible = !hideRightLeg;
         int leftLegValue = data.getScore("Left.Leg");
         int leftFeetValue = data.getScore("Left.Feet");
         boolean hideLeftLeg = leftLegValue >= 0 && leftLegValue <= 19 || leftFeetValue >= 0 && leftFeetValue <= 10;
         playerModel.leftLeg.visible = !hideLeftLeg;
         playerModel.leftPants.visible = !hideLeftLeg;
         boolean eggShellHidden = EggShellClientHandler.shouldHideBody(player);
         if (eggShellHidden) {
            this.theboysMod$hideEggShellPlayerParts(player, playerModel);
         }

         boolean toadHidden = ToadClientHandler.hasToad(player);
         if (toadHidden) {
            this.theboysMod$hideAllPlayerParts(playerModel);
         }

         boolean belialHidden = NailongBelialClientHandler.isTransformed(player);
         if (belialHidden) {
            this.theboysMod$hideAllPlayerParts(playerModel);
         }

         boolean needsRender = headValue >= 0 && headValue < 17
            || bodyValue >= 0 && bodyValue <= 19
            || rightArmValue >= 0 && rightArmValue <= 17
            || rightHandValue >= 0 && rightHandValue <= 11
            || leftArmValue >= 0 && leftArmValue <= 17
            || leftHandValue >= 0 && leftHandValue <= 11
            || rightLegValue >= 0 && rightLegValue <= 19
            || rightFeetValue >= 0 && rightFeetValue <= 10
            || leftLegValue >= 0 && leftLegValue <= 19
            || leftFeetValue >= 0 && leftFeetValue <= 10;
         if (eggShellHidden || toadHidden || belialHidden || invisibilityHidden) {
            needsRender = false;
         }

         if (needsRender && this.theboysMod$fleshRegenRenderer != null) {
            try {
               this.theboysMod$fleshRegenRenderer.setPlayerModel((PlayerModel<AbstractClientPlayer>)playerModel);
               this.theboysMod$fleshRegenRenderer.renderFleshRegenOnPlayer(player, matrixStack, buffer, packedLight, partialTicks);
            } catch (Exception var38) {
               VPower.LOGGER.error("[FleshRegen Mixin] Render error: ", var38);
            }
         }
      }
   }

   @Unique
   private boolean theboysMod$hasChickenEggHead(AbstractClientPlayer player) {
      try {
         SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         if (skillData.hasSkill(ChickenEggHeadSkill.ID.toString())) {
            return true;
         }
      } catch (Exception var3) {
      }

      return ClientSkillStateCache.hasSkill(player.getId(), ChickenEggHeadSkill.ID.toString()) || EggShellClientHandler.shouldRenderEggHead(player);
   }

   @Unique
   private void theboysMod$hideEggShellPlayerParts(AbstractClientPlayer player, PlayerModel<?> playerModel) {
      if (this.theboysMod$hasChickenEggHead(player)) {
         playerModel.head.visible = false;
         playerModel.hat.visible = false;
      }

      playerModel.body.visible = false;
      playerModel.jacket.visible = false;
      playerModel.rightArm.visible = false;
      playerModel.rightSleeve.visible = false;
      playerModel.leftArm.visible = false;
      playerModel.leftSleeve.visible = false;
      playerModel.rightLeg.visible = false;
      playerModel.rightPants.visible = false;
      playerModel.leftLeg.visible = false;
      playerModel.leftPants.visible = false;
   }

   @Unique
   private void theboysMod$hideAllPlayerParts(PlayerModel<?> playerModel) {
      playerModel.head.visible = false;
      playerModel.hat.visible = false;
      playerModel.body.visible = false;
      playerModel.jacket.visible = false;
      playerModel.rightArm.visible = false;
      playerModel.rightSleeve.visible = false;
      playerModel.leftArm.visible = false;
      playerModel.leftSleeve.visible = false;
      playerModel.rightLeg.visible = false;
      playerModel.rightPants.visible = false;
      playerModel.leftLeg.visible = false;
      playerModel.leftPants.visible = false;
   }

   @Inject(
      method = {"render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V"
      )}
   )
   private void onPostRender(T entity, float entityYaw, float partialTicks, PoseStack matrixStack, MultiBufferSource buffer, int packedLight, CallbackInfo ci) {
      if (entity instanceof AbstractClientPlayer player && this.model instanceof PlayerModel<?> playerModel) {
         try {
            SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            int fireTimer = skillData.getFireTimer();
            if (EggShellClientHandler.shouldHideBody(player)
               || ToadClientHandler.hasToad(player)
               || NailongBelialClientHandler.isTransformed(player)
               || InvisibilityRenderHelper.shouldHideBody(player)) {
               entity.hurtTime = this.theboysMod$savedHurtTime;
               return;
            }

            if (fireTimer > 0) {
               int deepRedColor = -52429;
               ResourceLocation skinTex = player.getSkin().texture();
               RenderType redType = RenderType.entityTranslucent(skinTex);
               VertexConsumer redBuf = buffer.getBuffer(redType);
               matrixStack.pushPose();
               matrixStack.translate(0.0, 0.9, 0.0);
               matrixStack.scale(1.003F, 1.003F, 1.003F);
               matrixStack.translate(0.0, -0.9, 0.0);
               playerModel.renderToBuffer(matrixStack, redBuf, 15728880, OverlayTexture.NO_OVERLAY, deepRedColor);
               matrixStack.popPose();
            }

            if (fireTimer > 0 && HumanTorchTextureManager.shouldRenderBody(fireTimer)) {
               ResourceLocation texture = HumanTorchTextureManager.getTexture(fireTimer);
               if (texture != null) {
                  RenderType renderType = HumanTorchRenderer.getTranslucent(texture);
                  VertexConsumer vertexConsumer = buffer.getBuffer(renderType);
                  int color = -50331649;
                  matrixStack.pushPose();
                  matrixStack.translate(0.0, 0.9, 0.0);
                  matrixStack.scale(1.01F, 1.01F, 1.01F);
                  matrixStack.translate(0.0, -0.9, 0.0);
                  playerModel.renderToBuffer(matrixStack, vertexConsumer, 15728880, OverlayTexture.NO_OVERLAY, color);
                  matrixStack.popPose();
               }
            }
         } catch (Exception var17) {
            VPower.LOGGER.error("[HumanTorch Mixin] Render error: ", var17);
         }

         entity.hurtTime = this.theboysMod$savedHurtTime;
      }
   }
}
