package com.invfix.vpower.mixin.client;

import com.invfix.vpower.client.ClientSkillStateCache;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.util.IntangibilityUtil;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Entity.class})
public class EntityFireRenderMixin {
   @Inject(
      method = {"isOnFire"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onIsOnFire(CallbackInfoReturnable<Boolean> cir) {
      Entity entity = (Entity)(Object)this;
      if (entity instanceof LivingEntity living) {
         try {
            SkillData data = (SkillData)living.getData(ModSkillAttachments.SKILL_DATA.get());
            if (this.theboysMod$isIntangible(living, data) || data.getFireTimer() > 0 || this.theboysMod$hasFleshStrengthFireImmunity(data)) {
               cir.setReturnValue(false);
            }
         } catch (Throwable var5) {
            if (this.theboysMod$isCachedIntangible(living)) {
               cir.setReturnValue(false);
            }
         }
      }
   }

   @Unique
   private boolean theboysMod$isIntangible(LivingEntity living, SkillData data) {
      return living.isAlive() && (IntangibilityUtil.hasAnyIntangibleSkillActive(data) || this.theboysMod$isCachedIntangible(living));
   }

   @Unique
   private boolean theboysMod$isCachedIntangible(LivingEntity living) {
      return living.isAlive()
         && (
            ClientSkillStateCache.isSkillActive(living.getId(), IntangibilityUtil.SKILL_ID)
               || ClientSkillStateCache.isSkillActive(living.getId(), IntangibilityUtil.SPIRITUALIZATION_ID)
         );
   }

   @Unique
   private boolean theboysMod$hasFleshStrengthFireImmunity(SkillData data) {
      return (data.hasSkill("theboysmod:flesh_regen") || data.hasSkill("theboysmod:flesh_strength")) && data.getFleshStrengthLevel() >= 2;
   }
}
