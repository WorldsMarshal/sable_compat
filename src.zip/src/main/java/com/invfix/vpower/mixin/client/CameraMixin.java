package com.invfix.vpower.mixin.client;

import com.invfix.vpower.client.animation.AnimationHelper;
import com.invfix.vpower.client.toad.ToadClientHandler;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Camera.class})
public abstract class CameraMixin {
   @Shadow
   protected abstract void move(float var1, float var2, float var3);

   @Inject(
      method = {"setup"},
      at = {@At("RETURN")}
   )
   private void onSetup(BlockGetter level, Entity entity, boolean detached, boolean thirdPersonReverse, float partialTick, CallbackInfo ci) {
      if (!detached) {
         if (entity instanceof Player player) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.player.getUUID().equals(player.getUUID())) {
               if (AnimationHelper.isMeditating(player)) {
                  this.move(0.0F, -0.5F, 0.0F);
               }

               if (entity instanceof AbstractClientPlayer clientPlayer && ToadClientHandler.hasToad(clientPlayer)) {
                  this.move(0.0F, 0.0F, 0.0F);
               }
            }
         }
      }
   }
}
