package com.invfix.vpower.mixin.client;

import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({MouseHandler.class})
public interface MouseHandlerAccessor {
   @Accessor("mouseGrabbed")
   void theboysmod$setMouseGrabbed(boolean var1);

   @Accessor("xpos")
   void theboysmod$setXpos(double var1);

   @Accessor("ypos")
   void theboysmod$setYpos(double var1);
}
