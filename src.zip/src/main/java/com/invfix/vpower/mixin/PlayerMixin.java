package com.invfix.vpower.mixin;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.FleshRegenSkill;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Player.class})
public abstract class PlayerMixin {
   @Inject(
      method = {"canEat"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void theboysMod$canEat(boolean ignoreHunger, CallbackInfoReturnable<Boolean> cir) {
      Player player = (Player)(Object)this;
      if (player != null) {
         try {
            SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            String skillId = FleshRegenSkill.ID.toString();
            if (skillData.hasSkill(skillId)) {
               cir.setReturnValue(true);
            }
         } catch (Exception var6) {
         }
      }
   }
}
