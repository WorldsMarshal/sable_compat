package com.invfix.vpower.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.invfix.vpower.client.belial.NailongBelialClientHandler;
import com.invfix.vpower.client.fashionegg.EggShellClientHandler;
import com.invfix.vpower.client.toad.ToadClientHandler;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({HumanoidArmorLayer.class})
public class HumanoidArmorLayerMixin {
   @Inject(
      method = {"renderArmorPiece(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/entity/EquipmentSlot;ILnet/minecraft/client/model/HumanoidModel;FFFFFF)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void theboysMod$hideArmorInEggShell(
      PoseStack poseStack,
      MultiBufferSource bufferSource,
      LivingEntity livingEntity,
      EquipmentSlot slot,
      int packedLight,
      HumanoidModel<?> model,
      float limbSwing,
      float limbSwingAmount,
      float partialTick,
      float ageInTicks,
      float netHeadYaw,
      float headPitch,
      CallbackInfo ci
   ) {
      if (livingEntity instanceof AbstractClientPlayer player
         && (EggShellClientHandler.shouldHideBody(player) || ToadClientHandler.hasToad(player) || NailongBelialClientHandler.isTransformed(player))) {
         ci.cancel();
      }
   }
}
