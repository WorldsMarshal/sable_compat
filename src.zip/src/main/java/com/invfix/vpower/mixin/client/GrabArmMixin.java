package com.invfix.vpower.mixin.client;

import com.invfix.vpower.client.GrabClientState;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(
   value = {PlayerModel.class},
   priority = 3000
)
public class GrabArmMixin<T extends LivingEntity> {
   @Inject(
      method = {"setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V"},
      at = {@At("RETURN")}
   )
   private void forceGrabArmPose(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo ci) {
      if (entity instanceof Player player) {
         if (GrabClientState.isGrabbing(player.getId())) {
            ModelPart rightArm = ((HumanoidModel)(Object)this).rightArm;
            float pitchRad = (float)Math.toRadians((double)headPitch);
            float yawRad = (float)Math.toRadians((double)netHeadYaw);
            rightArm.xRot = -1.5708F + pitchRad;
            rightArm.yRot = yawRad;
            rightArm.zRot = 0.0F;
            ModelPart rightSleeve = ((PlayerModel)(Object)this).rightSleeve;
            rightSleeve.xRot = rightArm.xRot;
            rightSleeve.yRot = rightArm.yRot;
            rightSleeve.zRot = rightArm.zRot;
         }
      }
   }
}
