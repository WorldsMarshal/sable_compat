package com.invfix.vpower.mixin;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.SpeedSkill;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({LocalPlayer.class})
public abstract class SpeedEatingMixin {
   @Redirect(
      method = {"aiStep"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/player/LocalPlayer;isUsingItem()Z"
      )
   )
   private boolean theboysMod$noItemUseSlowdown(LocalPlayer self) {
      boolean actuallyUsing = self.isUsingItem();
      if (!actuallyUsing) {
         return false;
      } else {
         try {
            SkillData data = (SkillData)self.getData(ModSkillAttachments.SKILL_DATA.get());
            String speedId = SpeedSkill.ID.toString();
            if (data.hasSkill(speedId) && data.isSkillActive(speedId) && data.getSpeedAdjustment() > 0) {
               return false;
            }
         } catch (Exception var5) {
         }

         return true;
      }
   }
}
