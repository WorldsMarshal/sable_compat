package com.invfix.vpower.mixin;

import java.util.HashMap;
import java.util.Map;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.SpeedSkill;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.BlockStateBase;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.EntityCollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({BlockStateBase.class})
public abstract class WaterWalkMixin {
   @Unique
   private static final Map<Integer, VoxelShape> theboysmod$SHAPES = new HashMap<>();

   @Shadow
   protected abstract BlockState asState();

   @Inject(
      method = {"getCollisionShape(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/phys/shapes/CollisionContext;)Lnet/minecraft/world/phys/shapes/VoxelShape;"},
      at = {@At("RETURN")},
      cancellable = true
   )
   public void theboysMod$waterWalk(BlockGetter level, BlockPos pos, CollisionContext context, CallbackInfoReturnable<VoxelShape> cir) {
      BlockState state = this.asState();
      if (state.getBlock() instanceof LiquidBlock) {
         if (state.getFluidState().is(FluidTags.WATER)) {
            if (context instanceof EntityCollisionContext entityCtx) {
               if (entityCtx.getEntity() instanceof Player player) {
                  if (!player.isInWater()) {
                     try {
                        SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
                        String speedId = SpeedSkill.ID.toString();
                        if (!data.hasSkill(speedId) || !data.isSkillActive(speedId) || data.getSpeedAdjustment() <= 0) {
                           return;
                        }
                     } catch (Exception var10) {
                        return;
                     }

                     int heightPixels = (int)(state.getFluidState().getHeight(level, pos) * 15.0F) + 2;
                     VoxelShape shape = theboysmod$SHAPES.computeIfAbsent(heightPixels, i -> Block.box(0.0, 0.0, 0.0, 16.0, (double)i.intValue(), 16.0));
                     cir.setReturnValue(shape);
                  }
               }
            }
         }
      }
   }
}
