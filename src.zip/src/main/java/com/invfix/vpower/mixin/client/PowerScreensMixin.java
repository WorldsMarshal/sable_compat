package com.invfix.vpower.mixin.client;

import com.invfix.vpower.client.VPowerMenuButtons;
import net.mcreator.invincibleinc.client.gui.AbilitiesMenuAtomicScreen;
import net.mcreator.invincibleinc.client.gui.AbilitiesMenuSuperSpeedScreen;
import net.mcreator.invincibleinc.client.gui.AbilitiesMenuTechJackerScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Способности препарата V во вкладке PWR людей с силой Invincible (Super Speed, Atomic, Tech Jacket): на свободных
 * местах листа (VPowerMenuButtons.FREE_SLOTS — листы этих сил нарисованы как у Вильтрумитов).
 */
@Mixin(value = {AbilitiesMenuSuperSpeedScreen.class, AbilitiesMenuAtomicScreen.class, AbilitiesMenuTechJackerScreen.class}, remap = false)
public abstract class PowerScreensMixin extends AbstractContainerScreen<AbstractContainerMenu> {

    public PowerScreensMixin(AbstractContainerMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
    }

    @Inject(method = "init", at = @At("TAIL"), remap = true)
    private void invfix$vPowerButtons(CallbackInfo ci) {
        LocalPlayer self = Minecraft.getInstance().player;
        if (self == null) return;
        int[] slot = {0};
        int[][] slots = VPowerMenuButtons.FREE_SLOTS;
        VPowerMenuButtons.add(self, () -> {
            int[] p = slots[Math.min(slot[0]++, slots.length - 1)];
            return new int[]{this.leftPos + p[0], this.topPos + p[1]};
        }, this::addRenderableWidget);
    }
}
