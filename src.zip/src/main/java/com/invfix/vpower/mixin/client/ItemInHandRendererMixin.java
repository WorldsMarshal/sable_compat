package com.invfix.vpower.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.invfix.vpower.client.belial.NailongBelialClientHandler;
import com.invfix.vpower.client.toad.ToadClientHandler;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ItemInHandRenderer.class})
public class ItemInHandRendererMixin {
   @Inject(
      method = {"renderArmWithItem"},
      at = {@At("HEAD")}
   )
   private void theboysMod$renderHeldItemToadArm(
      AbstractClientPlayer player,
      float partialTicks,
      float pitch,
      InteractionHand hand,
      float swingProgress,
      ItemStack stack,
      float equippedProgress,
      PoseStack poseStack,
      MultiBufferSource buffer,
      int combinedLight,
      CallbackInfo ci
   ) {
      if (!stack.isEmpty() && ToadClientHandler.hasToad(player)) {
         HumanoidArm arm = hand == InteractionHand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
         ToadClientHandler.renderFirstPersonArm(poseStack, buffer, combinedLight, partialTicks, player, arm);
      } else if (!stack.isEmpty() && NailongBelialClientHandler.isSkillActive(player)) {
         HumanoidArm belialArm = hand == InteractionHand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
         if (NailongBelialClientHandler.isTransforming(player)) {
            NailongBelialClientHandler.renderFirstPersonTransformer(poseStack, buffer, combinedLight, partialTicks, player, belialArm);
         } else if (NailongBelialClientHandler.isTransformed(player)) {
            NailongBelialClientHandler.renderFirstPersonArm(poseStack, buffer, combinedLight, partialTicks, player, belialArm);
         }
      }
   }

   @Inject(
      method = {"renderItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void theboysMod$hideFirstPersonHandItemsInToad(
      LivingEntity entity,
      ItemStack stack,
      ItemDisplayContext displayContext,
      boolean leftHand,
      PoseStack poseStack,
      MultiBufferSource buffer,
      int seed,
      CallbackInfo ci
   ) {
      if (entity instanceof AbstractClientPlayer player
         && ToadClientHandler.hasToad(player)
         && (displayContext == ItemDisplayContext.FIRST_PERSON_LEFT_HAND || displayContext == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND)) {
         ci.cancel();
      }

      if (entity instanceof AbstractClientPlayer player
         && NailongBelialClientHandler.isTransformed(player)
         && (displayContext == ItemDisplayContext.FIRST_PERSON_LEFT_HAND || displayContext == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND)) {
         ci.cancel();
      }
   }
}
