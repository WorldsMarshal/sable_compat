package com.invfix.vpower.mixin;

import com.invfix.vpower.VFlight;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.mcreator.invincibleinc.procedures.FlightOnOffProcedure;
import net.mcreator.invincibleinc.procedures.FlightTicksProcedure;
import net.mcreator.invincibleinc.procedures.OnplayerTickProcedure;
import net.mcreator.invincibleinc.procedures.SpeedAdjustOnKeyPressedProcedure;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Навык Flight → полёт Invincible (VFlight). */
public final class VFlightMixins {

    private VFlightMixins() {}

    /** Включение / выключение полёта: навык Flight — как пассивка «Flight». */
    @Mixin(value = FlightOnOffProcedure.class, remap = false)
    public static class OnOff {
        @WrapOperation(method = "execute", at = @At(value = "INVOKE", target = "Ljava/lang/String;equals(Ljava/lang/Object;)Z"), remap = false)
        private static boolean invfix$vFlight(String passive, Object other, Operation<Boolean> original,
                                              @Local(argsOnly = true) Entity entity) {
            return original.call(passive, other) || ("Flight".equals(other) && VFlight.has(entity));
        }
    }

    /** Тик игрока: без пассивки «Flight» полёт выключается — навык Flight его не выключает. */
    @Mixin(value = OnplayerTickProcedure.class, remap = false)
    public static class PlayerTick {
        @WrapOperation(method = "execute", at = @At(value = "INVOKE", target = "Ljava/lang/String;equals(Ljava/lang/Object;)Z"), remap = false)
        private static boolean invfix$vFlight(String passive, Object other, Operation<Boolean> original,
                                              @Local(argsOnly = true) Entity entity) {
            return original.call(passive, other) || ("Flight".equals(other) && VFlight.has(entity));
        }
    }

    /** Полёт: сразу после родного «предел = trueSpeed / 2» — предел V (и скорость не выше него). */
    @Mixin(value = FlightTicksProcedure.class, remap = false)
    public static class Ticks {
        @Inject(method = "execute", at = @At(value = "FIELD", opcode = Opcodes.PUTFIELD,
                target = "Lnet/mcreator/invincibleinc/network/InvincibleIncModVariables$PlayerVariables;flightspeedmax:D",
                shift = At.Shift.AFTER), remap = false)
        private static void invfix$vFlightCap(LevelAccessor world, double x, double y, double z, Entity entity, CallbackInfo ci) {
            VFlight.capSpeed(entity);
        }
    }

    /** Клавиша скорости: прибавка сравнивается с пределом V. */
    @Mixin(value = SpeedAdjustOnKeyPressedProcedure.class, remap = false)
    public static class SpeedAdjust {
        @Inject(method = "execute", at = @At("HEAD"), remap = false)
        private static void invfix$vFlightCap(Entity entity, CallbackInfo ci) {
            VFlight.capSpeed(entity);
        }
    }
}
