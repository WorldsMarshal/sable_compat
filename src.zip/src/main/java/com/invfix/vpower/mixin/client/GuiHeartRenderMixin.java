package com.invfix.vpower.mixin.client;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.client.gui.Gui;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({Gui.class})
public class GuiHeartRenderMixin {
   @Redirect(
      method = {"renderHealthLevel"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/entity/player/Player;getAttributeValue(Lnet/minecraft/core/Holder;)D"
      )
   )
   private double redirectGetAttributeValue(Player player, Holder<Attribute> attribute) {
      double realValue = player.getAttributeValue(attribute);

      try {
         if (attribute.value() == Attributes.MAX_HEALTH.value()) {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            if (data.hasSkill("theboysmod:flesh_strength")) {
               float ourExtra = data.getMaxShieldHp();
               return Math.max(20.0, realValue - (double)ourExtra);
            }
         }
      } catch (Throwable var7) {
      }

      return realValue;
   }

   @Redirect(
      method = {"renderHealthLevel"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/entity/player/Player;getHealth()F"
      )
   )
   private float redirectGetHealth(Player player) {
      float realHealth = player.getHealth();

      try {
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         if (data.hasSkill("theboysmod:flesh_strength")) {
            float ourExtra = data.getMaxShieldHp();
            float vanillaMax = (float)Math.max(20.0, (double)(player.getMaxHealth() - ourExtra));
            return Math.min(realHealth, vanillaMax);
         }
      } catch (Throwable var6) {
      }

      return realHealth;
   }
}
