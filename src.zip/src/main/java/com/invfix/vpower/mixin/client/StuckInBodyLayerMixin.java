package com.invfix.vpower.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.invfix.vpower.client.ClientSkillStateCache;
import com.invfix.vpower.client.belial.NailongBelialClientHandler;
import com.invfix.vpower.client.fashionegg.EggShellClientHandler;
import com.invfix.vpower.client.toad.ToadClientHandler;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.util.IntangibilityUtil;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.StuckInBodyLayer;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({StuckInBodyLayer.class})
public class StuckInBodyLayerMixin {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void theboysMod$hideStuckItemsInEggShell(
      PoseStack poseStack,
      MultiBufferSource buffer,
      int packedLight,
      LivingEntity livingEntity,
      float limbSwing,
      float limbSwingAmount,
      float partialTicks,
      float ageInTicks,
      float netHeadYaw,
      float headPitch,
      CallbackInfo ci
   ) {
      if (livingEntity instanceof AbstractClientPlayer player
         && (EggShellClientHandler.shouldHideBody(player) || ToadClientHandler.hasToad(player) || NailongBelialClientHandler.isTransformed(player))) {
         ci.cancel();
         return;
      }

      if (this.theboysMod$isIntangible(livingEntity)) {
         ci.cancel();
      }
   }

   @Unique
   private boolean theboysMod$isIntangible(LivingEntity livingEntity) {
      if (!livingEntity.isAlive()) {
         return false;
      } else {
         try {
            SkillData data = (SkillData)livingEntity.getData(ModSkillAttachments.SKILL_DATA.get());
            if (IntangibilityUtil.hasAnyIntangibleSkillActive(data)) {
               return true;
            }
         } catch (Exception var3) {
         }

         return ClientSkillStateCache.isSkillActive(livingEntity.getId(), IntangibilityUtil.SKILL_ID)
            || ClientSkillStateCache.isSkillActive(livingEntity.getId(), IntangibilityUtil.SPIRITUALIZATION_ID);
      }
   }
}
