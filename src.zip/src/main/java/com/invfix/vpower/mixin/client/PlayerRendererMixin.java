package com.invfix.vpower.mixin.client;

import com.invfix.vpower.client.flight.FlightClientHandler;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({PlayerRenderer.class})
public class PlayerRendererMixin {
   @Inject(
      at = {@At("RETURN")},
      method = {"setModelProperties"}
   )
   private void theboysMod$disableCrouchDuringFlight(AbstractClientPlayer player, CallbackInfo ci) {
      PlayerRenderer renderer = (PlayerRenderer)(Object)this;
      PlayerModel<AbstractClientPlayer> model = (PlayerModel<AbstractClientPlayer>)renderer.getModel();
      if (model.crouching && FlightClientHandler.isFlying()) {
         model.crouching = false;
      }
   }
}
