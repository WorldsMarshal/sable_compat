package com.invfix.vpower.mixin.accessor;

import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({FallingBlockEntity.class})
public interface FallingBlockEntityAccessor {
   @Accessor("blockState")
   void theboysmod$setBlockState(BlockState var1);
}
