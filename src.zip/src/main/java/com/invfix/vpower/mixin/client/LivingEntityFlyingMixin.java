package com.invfix.vpower.mixin.client;

import com.invfix.vpower.client.flight.FlightClientHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({LivingEntity.class})
public class LivingEntityFlyingMixin {
   @Inject(
      method = {"isFallFlying"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void theboysmod$overrideFallFlying(CallbackInfoReturnable<Boolean> cir) {
      LivingEntity self = (LivingEntity)(Object)this;
      if (self instanceof Player player) {
         Minecraft mc = Minecraft.getInstance();
         if (mc.level != null && mc.player != null) {
            if (player.getId() != mc.player.getId()) {
               if (FlightClientHandler.isRemoteFlying(player.getId())) {
                  cir.setReturnValue(true);
               }
            }
         }
      }
   }
}
