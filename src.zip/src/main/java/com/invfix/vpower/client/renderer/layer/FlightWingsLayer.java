package com.invfix.vpower.client.renderer.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.client.ClientSkillStateCache;
import com.invfix.vpower.client.animation.AnimationHelper;
import com.invfix.vpower.client.fashionegg.EggShellClientHandler;
import com.invfix.vpower.client.flight.WingFlightClientHandler;
import com.invfix.vpower.client.invisibility.InvisibilityRenderHelper;
import com.invfix.vpower.client.model.wings.FeatheredWingsModel;
import com.invfix.vpower.client.model.wings.WingEntityModel;
import com.invfix.vpower.client.model.wings.WingsModels;
import com.invfix.vpower.client.toad.ToadClientHandler;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.WingsSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

public class FlightWingsLayer<T extends LivingEntity, M extends EntityModel<T>> extends RenderLayer<T, M> {
   private static final ResourceLocation PRIMARY_TEXTURE = ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/entity/wings/feathered_wings.png");
   private static final ResourceLocation SECONDARY_TEXTURE = ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/entity/wings/feathered_wings_2.png");
   private final FeatheredWingsModel<T> featheredWings;

   public FlightWingsLayer(RenderLayerParent<T, M> context, EntityModelSet loader) {
      super(context);
      this.featheredWings = new FeatheredWingsModel<>(loader.bakeLayer(WingsModels.FEATHERED));
   }

   public void render(
      PoseStack poseStack,
      MultiBufferSource bufferSource,
      int packedLight,
      T entity,
      float limbSwing,
      float limbSwingAmount,
      float partialTick,
      float ageInTicks,
      float netHeadYaw,
      float headPitch
   ) {
      if (this.shouldRender(entity)) {
         poseStack.pushPose();
         poseStack.translate(0.0, 0.0, 0.125);
         WingEntityModel<T> wingModel = this.featheredWings;
         this.getParentModel().copyPropertiesTo(wingModel);
         wingModel.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
         VertexConsumer secondary = bufferSource.getBuffer(RenderType.entityTranslucent(SECONDARY_TEXTURE));
         wingModel.renderToBuffer(poseStack, secondary, packedLight, OverlayTexture.NO_OVERLAY, -1);
         VertexConsumer primary = bufferSource.getBuffer(RenderType.entityTranslucent(PRIMARY_TEXTURE));
         wingModel.renderToBuffer(poseStack, primary, packedLight, OverlayTexture.NO_OVERLAY, -1);
         poseStack.popPose();
      }
   }

   private boolean shouldRender(T entity) {
      if (entity.isInvisible() || InvisibilityRenderHelper.shouldHideBody(entity)) {
         return false;
      } else if (entity instanceof AbstractClientPlayer player) {
         if (EggShellClientHandler.shouldHideBody(player) || ToadClientHandler.hasToad(player)) {
            return false;
         } else if (!this.hasBodyForWings(player)) {
            return false;
         } else {
            Minecraft mc = Minecraft.getInstance();
            boolean isLocalPlayer = mc.player != null && mc.player.getId() == player.getId();
            if (!isLocalPlayer && ClientSkillStateCache.hasKnownSkills(player.getId())) {
               if (ClientSkillStateCache.hasSkill(player.getId(), WingsSkill.ID.toString())) {
                  WingFlightClientHandler.setRemoteWingKnown(player.getId(), true);
                  return true;
               } else {
                  WingFlightClientHandler.setRemoteWingKnown(player.getId(), false);
                  return false;
               }
            } else if (WingFlightClientHandler.isRemoteWingActive(player.getId())) {
               return true;
            } else if (!isLocalPlayer && WingFlightClientHandler.isRemoteWingKnown(player.getId())) {
               return true;
            } else if (!isLocalPlayer || !WingFlightClientHandler.isWingHovering() && !WingFlightClientHandler.isWingFlying()) {
               String currentAnimation = AnimationHelper.getCurrentAnimation(player);
               if (!isLocalPlayer && currentAnimation != null && currentAnimation.startsWith("wings_hover")) {
                  WingFlightClientHandler.setRemoteWingKnown(player.getId(), true);
               }

               boolean hoverAnimActive = AnimationHelper.isPlayingAnimation(player)
                  && ("wings_hover.start".equals(currentAnimation) || "wings_hover.on".equals(currentAnimation));
               if (hoverAnimActive) {
                  return true;
               } else {
                  try {
                     SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
                     return skillData.hasSkill(WingsSkill.ID.toString());
                  } catch (Exception var8) {
                     return false;
                  }
               }
            } else {
               return true;
            }
         }
      } else {
         try {
            SkillData data = (SkillData)entity.getData(ModSkillAttachments.SKILL_DATA.get());
            return data.hasSkill(WingsSkill.ID.toString());
         } catch (Exception var9) {
            return false;
         }
      }
   }

   private boolean hasBodyForWings(AbstractClientPlayer player) {
      try {
         FleshRegenData data = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
         return data.getScore("Body") != 0;
      } catch (Exception var3) {
         return true;
      }
   }
}
