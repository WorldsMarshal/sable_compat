package com.invfix.vpower.client.lasereye;

import com.invfix.threatmode.ThreatModeClientEvents;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.client.ClientSkillStateCache;
import com.invfix.vpower.network.LaserEyeHitPosSyncPacket;
import com.invfix.vpower.registry.ModSounds;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.LaserEyeSkill;
import com.invfix.vpower.util.IntangibilityUtil;
import com.invfix.vpower.util.LaserEyeGeometry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.PacketDistributor;

@OnlyIn(Dist.CLIENT)
public class LaserEyeClientHandler {
   private static final Map<Integer, Float> BEAM_VALUES = new ConcurrentHashMap<>();
   private static final Map<Integer, Float> PREV_BEAM_VALUES = new ConcurrentHashMap<>();
   private static final Map<Integer, Vec3> HIT_POSITIONS = new ConcurrentHashMap<>();
   private static final Map<Integer, Integer> NETWORK_BEAM_TTL = new ConcurrentHashMap<>();
   public static final float MAX_DISTANCE = 500.0F;
   private static final float EXTEND_SPEED = 0.15F;
   private static final float RETRACT_SPEED = 0.25F;
   private static final int NETWORK_HIT_TTL_TICKS = 6;
   private static final String LASER_EYE_ID = LaserEyeSkill.ID.toString();
   private static final Map<Integer, LaserEyeLoopSound> ACTIVE_SOUNDS = new ConcurrentHashMap<>();
   private static final Set<Integer> PREV_BEAM_ENTITIES = ConcurrentHashMap.newKeySet();
   private static boolean clientHeld = false;

   public static void setClientHeld(boolean held) {
      clientHeld = held;
   }

   public static void clientTick() {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level != null) {
         tickNetworkHitState(mc);
         Set<Integer> currentBeamEntities = ConcurrentHashMap.newKeySet();

         for (AbstractClientPlayer player : mc.level.players()) {
            int id = player.getId();
            boolean stateActive = isLaserActive(player);
            boolean networkActive = hasFreshNetworkHit(id);
            boolean active = stateActive || networkActive;
            float prev = BEAM_VALUES.getOrDefault(id, 0.0F);
            PREV_BEAM_VALUES.put(id, prev);
            float value;
            if (active) {
               value = Math.min(prev + 0.15F, 1.0F);
               if (prev <= 0.0F) {
                  playOneShotSound(player, (SoundEvent)ModSounds.LASER_EYE_START.get(), 1.0F);
                  startLoopSound(id, player);
               }

               currentBeamEntities.add(id);
               boolean isLocalPlayer = mc.player != null && mc.player.getId() == id;
               if (isLocalPlayer) {
                  updateRaycast(player);
                  Vec3 hitPos = HIT_POSITIONS.get(id);
                  if (hitPos != null) {
                     PacketDistributor.sendToServer(new LaserEyeHitPosSyncPacket(id, hitPos.x, hitPos.y, hitPos.z), new CustomPacketPayload[0]);
                  }
               } else if (!networkActive) {
                  updateRaycast(player);
               }
            } else {
               value = Math.max(prev - 0.25F, 0.0F);
               if (value <= 0.0F) {
                  BEAM_VALUES.remove(id);
                  PREV_BEAM_VALUES.remove(id);
                  HIT_POSITIONS.remove(id);
                  continue;
               }
            }

            BEAM_VALUES.put(id, value);
         }

         if (mc.player != null) {
         }

         Set<Integer> networkDrivenIds = ConcurrentHashMap.newKeySet();
         networkDrivenIds.addAll(NETWORK_BEAM_TTL.keySet());

         for (Integer id : BEAM_VALUES.keySet()) {
            Entity tracked = mc.level.getEntity(id);
            if (tracked instanceof LivingEntity) {
               LivingEntity living = (LivingEntity)tracked;
               if (!(living instanceof Player)) {
                  networkDrivenIds.add(id);
               }
            }
         }

         for (Integer idx : networkDrivenIds) {
            if (!(mc.level.getEntity(idx) instanceof LivingEntity living) || !living.isAlive() || living.isRemoved() || living.getHealth() <= 0.0F) {
               NETWORK_BEAM_TTL.remove(idx);
               BEAM_VALUES.remove(idx);
               PREV_BEAM_VALUES.remove(idx);
               HIT_POSITIONS.remove(idx);
               stopLoopSound(idx);
               PREV_BEAM_ENTITIES.remove(idx);
               continue;
            }

            if (!(living instanceof Player)) {
               boolean active = hasFreshNetworkHit(idx);
               float prev = BEAM_VALUES.getOrDefault(idx, 0.0F);
               PREV_BEAM_VALUES.put(idx, prev);
               float value;
               if (active) {
                  value = Math.min(prev + 0.15F, 1.0F);
                  if (prev <= 0.0F) {
                     playOneShotSound(living, (SoundEvent)ModSounds.LASER_EYE_START.get(), 1.0F);
                     startLoopSound(idx, living);
                  }

                  currentBeamEntities.add(idx);
               } else {
                  value = Math.max(prev - 0.25F, 0.0F);
                  if (value <= 0.0F) {
                     BEAM_VALUES.remove(idx);
                     PREV_BEAM_VALUES.remove(idx);
                     HIT_POSITIONS.remove(idx);
                     continue;
                  }
               }

               BEAM_VALUES.put(idx, value);
            }
         }

         for (int idx : PREV_BEAM_ENTITIES) {
            if (!currentBeamEntities.contains(idx)) {
               if (mc.level.getEntity(idx) instanceof LivingEntity living) {
                  playOneShotSound(living, (SoundEvent)ModSounds.LASER_EYE_END.get(), 1.0F);
               }

               stopLoopSound(idx);
            }
         }

         PREV_BEAM_ENTITIES.clear();
         PREV_BEAM_ENTITIES.addAll(currentBeamEntities);
      }
   }

   public static boolean isLaserActive(Player player) {
      Minecraft mc = Minecraft.getInstance();
      // Playful mode у себя: свой луч не рисуется (и не шлёт точку попадания и звук) — только свечение глаз
      if (player == mc.player && ThreatModeClientEvents.isHeld()) {
         return false;
      }
      if (mc.player != null && player.getId() == mc.player.getId()) {
         try {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            return data.hasSkill(LASER_EYE_ID) && clientHeld;
         } catch (Exception var3) {
            return false;
         }
      } else {
         return ClientSkillStateCache.isSkillActive(player.getId(), LASER_EYE_ID);
      }
   }

   private static boolean hasFreshNetworkHit(int entityId) {
      return NETWORK_BEAM_TTL.getOrDefault(entityId, 0) > 0 && HIT_POSITIONS.containsKey(entityId);
   }

   private static void tickNetworkHitState(Minecraft mc) {
      for (Entry<Integer, Integer> entry : NETWORK_BEAM_TTL.entrySet()) {
         int entityId = entry.getKey();
         if (mc.level.getEntity(entityId) instanceof LivingEntity living && living.isAlive() && !living.isRemoved() && !(living.getHealth() <= 0.0F)) {
            int ttl = entry.getValue();
            if (ttl <= 1) {
               NETWORK_BEAM_TTL.remove(entityId);
               HIT_POSITIONS.remove(entityId);
            } else {
               NETWORK_BEAM_TTL.put(entityId, ttl - 1);
            }
            continue;
         }

         NETWORK_BEAM_TTL.remove(entityId);
         HIT_POSITIONS.remove(entityId);
         BEAM_VALUES.remove(entityId);
         PREV_BEAM_VALUES.remove(entityId);
         stopLoopSound(entityId);
         PREV_BEAM_ENTITIES.remove(entityId);
      }
   }

   private static void updateRaycast(Player player) {
      Vec3 eyePos = LaserEyeGeometry.getDynamicEyeBase(player, 1.0F);
      Vec3 lookVec = player.getLookAngle();
      LaserEyeGeometry.TraceResult trace = LaserEyeGeometry.traceBeam(player, eyePos, lookVec, 500.0, 0.35, LaserEyeClientHandler::canClientLaserHit);
      HIT_POSITIONS.put(player.getId(), trace.hitPos());
   }

   private static void updateNpcRaycast(LivingEntity entity) {

      Vec3 eyePos = LaserEyeGeometry.getDynamicEyeBase(entity, 1.0F);
      Vec3 lookVec = entity.getViewVector(1.0F);
      if (lookVec.lengthSqr() < 1.0E-6) {
         lookVec = entity.getLookAngle();
      }

      LaserEyeGeometry.TraceResult trace = LaserEyeGeometry.traceBeam(entity, eyePos, lookVec, 500.0, 0.8, LaserEyeClientHandler::canClientLaserHit);
      HIT_POSITIONS.put(entity.getId(), trace.hitPos());
   }

   private static boolean canClientLaserHit(LivingEntity target) {
      return !ClientSkillStateCache.isSkillActive(target.getId(), IntangibilityUtil.SKILL_ID)
         && !ClientSkillStateCache.isSkillActive(target.getId(), IntangibilityUtil.SPIRITUALIZATION_ID);
   }

   public static void setRemoteHitPos(int entityId, Vec3 hitPos) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level == null
         || !(mc.level.getEntity(entityId) instanceof LivingEntity living)
         || living.isAlive() && !living.isRemoved() && !(living.getHealth() <= 0.0F)) {
         HIT_POSITIONS.put(entityId, hitPos);
         NETWORK_BEAM_TTL.put(entityId, 6);
      } else {
         NETWORK_BEAM_TTL.remove(entityId);
         HIT_POSITIONS.remove(entityId);
      }
   }

   public static float getBeamValue(int entityId, float partialTick) {
      float current = BEAM_VALUES.getOrDefault(entityId, 0.0F);
      float prev = PREV_BEAM_VALUES.getOrDefault(entityId, 0.0F);
      return prev + (current - prev) * partialTick;
   }

   public static Vec3 getHitPosition(int entityId) {
      return HIT_POSITIONS.get(entityId);
   }

   public static boolean hasVisibleBeam(int entityId) {
      return BEAM_VALUES.getOrDefault(entityId, 0.0F) > 0.0F;
   }

   public static void clearAll() {
      BEAM_VALUES.clear();
      PREV_BEAM_VALUES.clear();
      HIT_POSITIONS.clear();
      NETWORK_BEAM_TTL.clear();
      clientHeld = false;

      for (LaserEyeLoopSound sound : ACTIVE_SOUNDS.values()) {
         sound.markStopped();
      }

      ACTIVE_SOUNDS.clear();
      PREV_BEAM_ENTITIES.clear();
   }

   private static void startLoopSound(int entityId, LivingEntity entity) {
      if (!ACTIVE_SOUNDS.containsKey(entityId)) {
         LaserEyeLoopSound loopSound = new LaserEyeLoopSound(entity);
         ACTIVE_SOUNDS.put(entityId, loopSound);
         Minecraft.getInstance().getSoundManager().play(loopSound);
      }
   }

   private static void stopLoopSound(int entityId) {
      LaserEyeLoopSound sound = ACTIVE_SOUNDS.remove(entityId);
      if (sound != null) {
         sound.markStopped();
      }
   }

   private static void playOneShotSound(LivingEntity entity, SoundEvent sound, float volume) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level != null) {
         SoundSource source = entity instanceof Player ? SoundSource.PLAYERS : SoundSource.HOSTILE;
         mc.level.playLocalSound(entity.getX(), entity.getY(), entity.getZ(), sound, source, volume, 1.0F, false);
      }
   }
}
