package com.invfix.vpower.client.afterimage;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.client.invisibility.InvisibilityRenderHelper;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.SpeedSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class AfterimageManager {
   private static final float SPACING = 1.0F;
   private static final int MAX_FRAMES = 8;
   public static final int MAX_LIFE_TICKS = 10;
   private static final double MIN_SPEED_THRESHOLD = 0.15;
   private static final Map<Integer, Deque<AfterimageData>> AFTERIMAGES = new ConcurrentHashMap<>();
   private static final Map<Integer, Vec3> LAST_TRAIL_POS = new ConcurrentHashMap<>();
   private static long clientTick = 0L;

   public static void tick() {
      clientTick++;
      Minecraft mc = Minecraft.getInstance();
      if (mc.level != null && mc.player != null) {
         for (AbstractClientPlayer player : mc.level.players()) {
            int id = player.getId();
            boolean shouldTrail = shouldProducePlayerAfterimage(player);
            if (shouldTrail) {
               sampleEntityAfterimage(player);
            } else {
               LAST_TRAIL_POS.remove(id);
            }

            cleanupQueue(id);
         }

      } else {
         AFTERIMAGES.clear();
         LAST_TRAIL_POS.clear();
      }
   }

   private static void sampleEntityAfterimage(LivingEntity living) {
      int id = living.getId();
      Vec3 snapshotPos = new Vec3(living.xo, living.yo, living.zo);
      Vec3 lastPos = LAST_TRAIL_POS.get(id);
      float minDist = living.getBbWidth() * 1.0F;
      boolean shouldSpawn;
      if (lastPos == null) {
         shouldSpawn = isMoving(living);
      } else {
         shouldSpawn = lastPos.distanceTo(snapshotPos) >= (double)minDist;
      }

      if (shouldSpawn) {
         Deque<AfterimageData> queue = AFTERIMAGES.computeIfAbsent(id, k -> new ArrayDeque<>());
         AfterimageData snapshot = new AfterimageData(
            snapshotPos,
            new Vec3(living.xo, living.yo, living.zo),
            living.yBodyRotO,
            living.yBodyRotO,
            living.yHeadRotO,
            living.yHeadRotO,
            living.xRotO,
            living.xRotO,
            living.walkAnimation.position(),
            living.walkAnimation.speed(),
            living.isFallFlying(),
            living.getDeltaMovement(),
            clientTick
         );
         queue.addLast(snapshot);
         LAST_TRAIL_POS.put(id, snapshotPos);

         while (queue.size() > 8) {
            queue.pollFirst();
         }
      }
   }

   private static void cleanupQueue(int id) {
      Deque<AfterimageData> queue = AFTERIMAGES.get(id);
      if (queue != null) {
         Iterator<AfterimageData> it = queue.iterator();

         while (it.hasNext()) {
            if (it.next().isExpired(clientTick, 10)) {
               it.remove();
            }
         }

         if (queue.isEmpty()) {
            AFTERIMAGES.remove(id);
         }
      }
   }

   private static boolean isMoving(LivingEntity entity) {
      return entity.xo != entity.getX() || entity.yo != entity.getY() || entity.zo != entity.getZ();
   }

   private static boolean shouldProducePlayerAfterimage(Player player) {
      if (InvisibilityRenderHelper.shouldHideBody(player)) {
         return false;
      } else {
         try {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            String speedSkillId = SpeedSkill.ID.toString();
            if (!data.hasSkill(speedSkillId) || !data.isSkillActive(speedSkillId)) {
               return false;
            }

            if (data.getSpeedAdjustment() <= 0) {
               return false;
            }
         } catch (Exception var4) {
            return false;
         }

         Vec3 delta = player.getDeltaMovement();
         double horizontalSpeed = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
         return horizontalSpeed > 0.15;
      }
   }


   public static Deque<AfterimageData> getAfterimages(int entityId) {
      return AFTERIMAGES.get(entityId);
   }

   public static long getClientTick() {
      return clientTick;
   }

   public static void clearAll() {
      AFTERIMAGES.clear();
      LAST_TRAIL_POS.clear();
      clientTick = 0L;
   }
}
