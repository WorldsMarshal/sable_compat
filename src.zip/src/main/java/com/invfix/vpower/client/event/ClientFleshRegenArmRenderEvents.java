package com.invfix.vpower.client.event;

import com.mojang.blaze3d.vertex.PoseStack;
import com.invfix.vpower.VPower;
import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.client.fp.FleshRegenArmGeoRenderer;
import com.invfix.vpower.client.invisibility.InvisibilityRenderHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.world.entity.HumanoidArm;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.RenderArmEvent;
import net.neoforged.neoforge.common.NeoForge;

@OnlyIn(Dist.CLIENT)
public class ClientFleshRegenArmRenderEvents {
   private static FleshRegenArmGeoRenderer renderer;

   public static void register() {
      NeoForge.EVENT_BUS.register(new ClientFleshRegenArmRenderEvents());
      renderer = new FleshRegenArmGeoRenderer();
   }

   private ClientFleshRegenArmRenderEvents() {
   }

   @SubscribeEvent
   public void onRenderArm(RenderArmEvent event) {
      AbstractClientPlayer mc = event.getPlayer();
      if (mc instanceof AbstractClientPlayer) {
         AbstractClientPlayer player = mc;
         Minecraft mcx = Minecraft.getInstance();
         boolean firstPerson = mcx.player != null && mcx.player.getUUID().equals(mc.getUUID()) && mcx.options.getCameraType().isFirstPerson();
         if (firstPerson) {
            if (InvisibilityRenderHelper.shouldHideBody(mc)) {
               event.setCanceled(true);
            } else {
               FleshRegenData data;
               try {
                  data = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
               } catch (Exception var23) {
                  return;
               }

               HumanoidArm arm = event.getArm();
               String armKey = arm == HumanoidArm.RIGHT ? "Right.Arm" : "Left.Arm";
               String handKey = arm == HumanoidArm.RIGHT ? "Right.Hand" : "Left.Hand";
               int armValue = data.getScore(armKey);
               int handValue = data.getScore(handKey);
               boolean armRegenerating = armValue >= 0 && armValue < 18;
               boolean handRegenerating = handValue >= 0 && handValue < 12;
               boolean needsFleshRegen = armRegenerating || handRegenerating;
               if (needsFleshRegen) {
                  try {
                     event.setCanceled(true);
                  } catch (Throwable var22) {
                     return;
                  }

                  if (mcx.getEntityRenderDispatcher().getRenderer(mc) instanceof PlayerRenderer playerRenderer) {
                     PoseStack poseStack = event.getPoseStack();
                     MultiBufferSource buffer = event.getMultiBufferSource();
                     int packedLight = event.getPackedLight();
                     float partialTick = mcx.getTimer().getGameTimeDeltaPartialTick(true);

                     try {
                        renderer.renderArm(
                           poseStack, buffer, packedLight, partialTick, player, (PlayerModel<AbstractClientPlayer>)playerRenderer.getModel(), arm
                        );
                     } catch (Exception var21) {
                        VPower.LOGGER.error("[FleshRegen] First person arm render failed", var21);
                     }
                  }
               }
            }
         }
      }
   }
}
