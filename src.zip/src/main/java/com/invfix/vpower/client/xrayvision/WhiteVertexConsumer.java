package com.invfix.vpower.client.xrayvision;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.texture.OverlayTexture;

public class WhiteVertexConsumer implements VertexConsumer {
   private final VertexConsumer delegate;
   private final int alpha;

   public WhiteVertexConsumer(VertexConsumer delegate, int alpha) {
      this.delegate = delegate;
      this.alpha = alpha;
   }

   public VertexConsumer addVertex(float x, float y, float z) {
      this.delegate.addVertex(x, y, z);
      this.delegate.setColor(255, 255, 255, this.alpha);
      this.delegate.setUv(0.0F, 0.0F);
      this.delegate.setOverlay(OverlayTexture.NO_OVERLAY);
      this.delegate.setLight(15728880);
      this.delegate.setNormal(0.0F, 1.0F, 0.0F);
      return this;
   }

   public VertexConsumer setColor(int red, int green, int blue, int ignoredAlpha) {
      this.delegate.setColor(255, 255, 255, this.alpha);
      return this;
   }

   public VertexConsumer setUv(float u, float v) {
      this.delegate.setUv(u, v);
      return this;
   }

   public VertexConsumer setUv1(int u, int v) {
      this.delegate.setUv1(u, v);
      return this;
   }

   public VertexConsumer setUv2(int u, int v) {
      this.delegate.setLight(15728880);
      return this;
   }

   public VertexConsumer setNormal(float x, float y, float z) {
      this.delegate.setNormal(x, y, z);
      return this;
   }
}
