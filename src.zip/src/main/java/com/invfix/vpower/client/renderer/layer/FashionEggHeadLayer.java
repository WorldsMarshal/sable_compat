package com.invfix.vpower.client.renderer.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Optional;
import com.invfix.vpower.client.ClientSkillStateCache;
import com.invfix.vpower.client.fashionegg.EggShellClientHandler;
import com.invfix.vpower.client.invisibility.InvisibilityRenderHelper;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.ChickenEggHeadSkill;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager.ControllerRegistrar;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoObjectRenderer;
import software.bernie.geckolib.util.GeckoLibUtil;

public class FashionEggHeadLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
   private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/custom/fashionegg/fashionegg.png");
   private final FashionEggHeadLayer.FashionEggRenderer renderer = new FashionEggHeadLayer.FashionEggRenderer();

   public FashionEggHeadLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
      super(parent);
   }

   public void render(
      PoseStack poseStack,
      MultiBufferSource bufferSource,
      int packedLight,
      AbstractClientPlayer player,
      float limbSwing,
      float limbSwingAmount,
      float partialTick,
      float ageInTicks,
      float netHeadYaw,
      float headPitch
   ) {
      if (shouldRender(player)) {
         this.renderer.setPlayerModel((PlayerModel<AbstractClientPlayer>)this.getParentModel());
         this.renderer.renderOnPlayer(poseStack, bufferSource, packedLight, partialTick);
      }
   }

   private static boolean shouldRender(AbstractClientPlayer player) {
      if (player != null && !player.isSpectator() && !player.isInvisible() && !InvisibilityRenderHelper.shouldHideBody(player)) {
         try {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            if (data.hasSkill(ChickenEggHeadSkill.ID.toString())) {
               return true;
            }
         } catch (Exception var2) {
         }

         return ClientSkillStateCache.hasSkill(player.getId(), ChickenEggHeadSkill.ID.toString()) || EggShellClientHandler.shouldRenderEggHead(player);
      } else {
         return false;
      }
   }

   private static final class FashionEggAnimatable implements GeoAnimatable {
      private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

      public void registerControllers(ControllerRegistrar controllers) {
      }

      public AnimatableInstanceCache getAnimatableInstanceCache() {
         return this.cache;
      }

      public double getTick(Object object) {
         return 0.0;
      }
   }

   private static final class FashionEggModel extends GeoModel<FashionEggHeadLayer.FashionEggAnimatable> {
      public ResourceLocation getModelResource(FashionEggHeadLayer.FashionEggAnimatable animatable) {
         return ResourceLocation.fromNamespaceAndPath("theboysmod", "geo/custom/fashionegg/fashionegg.geo.json");
      }

      public ResourceLocation getTextureResource(FashionEggHeadLayer.FashionEggAnimatable animatable) {
         return FashionEggHeadLayer.TEXTURE;
      }

      public ResourceLocation getAnimationResource(FashionEggHeadLayer.FashionEggAnimatable animatable) {
         return null;
      }
   }

   private static final class FashionEggRenderer extends GeoObjectRenderer<FashionEggHeadLayer.FashionEggAnimatable> {
      private static final FashionEggHeadLayer.FashionEggAnimatable INSTANCE = new FashionEggHeadLayer.FashionEggAnimatable();
      private PlayerModel<AbstractClientPlayer> playerModel;

      private FashionEggRenderer() {
         super(new FashionEggHeadLayer.FashionEggModel());
      }

      private void setPlayerModel(PlayerModel<AbstractClientPlayer> playerModel) {
         this.playerModel = playerModel;
      }

      private void renderOnPlayer(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick) {
         RenderType renderType = RenderType.entityTranslucent(FashionEggHeadLayer.TEXTURE);
         this.render(poseStack, INSTANCE, bufferSource, renderType, null, packedLight, partialTick);
      }

      public void preRender(
         PoseStack poseStack,
         FashionEggHeadLayer.FashionEggAnimatable animatable,
         BakedGeoModel model,
         @Nullable MultiBufferSource bufferSource,
         @Nullable VertexConsumer buffer,
         boolean isReRender,
         float partialTick,
         int packedLight,
         int packedOverlay,
         int colour
      ) {
         this.objectRenderTranslations = new Matrix4f(poseStack.last().pose());
         this.syncHeadBone(model);
      }

      public void actuallyRender(
         PoseStack poseStack,
         FashionEggHeadLayer.FashionEggAnimatable animatable,
         BakedGeoModel model,
         @Nullable RenderType renderType,
         MultiBufferSource bufferSource,
         @Nullable VertexConsumer buffer,
         boolean isReRender,
         float partialTick,
         int packedLight,
         int packedOverlay,
         int colour
      ) {
         poseStack.pushPose();
         poseStack.scale(-1.0F, -1.0F, 1.0F);
         poseStack.translate(0.0F, -1.5F, 0.0F);
         poseStack.translate(0.0F, 0.01F, 0.0F);
         this.modelRenderTranslations = new Matrix4f(poseStack.last().pose());

         for (GeoBone bone : model.topLevelBones()) {
            this.renderRecursively(poseStack, animatable, bone, renderType, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, colour);
         }

         poseStack.popPose();
      }

      private void syncHeadBone(BakedGeoModel model) {
         resetBone(model, "body");
         if (this.playerModel != null) {
            Optional<GeoBone> optionalHead = model.getBone("head");
            if (!optionalHead.isEmpty()) {
               ModelPart head = this.playerModel.head;
               GeoBone headBone = optionalHead.get();
               headBone.setPosX(head.x);
               headBone.setPosY(-head.y);
               headBone.setPosZ(head.z);
               headBone.setRotX(-head.xRot);
               headBone.setRotY(-head.yRot);
               headBone.setRotZ(head.zRot);
               headBone.setScaleX(head.xScale);
               headBone.setScaleY(head.yScale);
               headBone.setScaleZ(head.zScale);
            }
         }
      }

      private static void resetBone(BakedGeoModel model, String boneName) {
         Optional<GeoBone> optionalBone = model.getBone(boneName);
         if (!optionalBone.isEmpty()) {
            GeoBone bone = optionalBone.get();
            bone.setPosX(0.0F);
            bone.setPosY(0.0F);
            bone.setPosZ(0.0F);
            bone.setRotX(0.0F);
            bone.setRotY(0.0F);
            bone.setRotZ(0.0F);
            bone.setScaleX(1.0F);
            bone.setScaleY(1.0F);
            bone.setScaleZ(1.0F);
         }
      }
   }
}
