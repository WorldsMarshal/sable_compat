package com.invfix.vpower.client.flight;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.VPower;
import com.invfix.vpower.client.animation.AnimationHelper;
import com.invfix.vpower.client.animation.ModAnimations;
import com.invfix.vpower.network.FlightPosePacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent.Pre;
import net.neoforged.neoforge.client.event.InputEvent.Key;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public class FlightClientHandler {
   private static final float WINGS_SPEED = 0.045F;
   private static final float UPWARD_ATTACK_MULTIPLIER = 2.75F;
   private static final float UPWARD_ATTACK_ANGLE = 15.0F;
   private static final float MOMENTUM_BLEND_FACTOR = 1.5F;
   private static final float MAX_FLIGHT_HEIGHT = 320.0F;
   private static boolean hovering = false;
   private static boolean flying = false;
   private static int verticalHover = 0;
   private static long lastJumpTime = 0L;
   private static final long DOUBLE_CLICK_THRESHOLD = 300L;
   private static boolean flyingAnimActive = false;
   private static boolean hoverAnimActive = false;
   private static long lastWTime = 0L;
   private static boolean doubleTapW = false;
   private static final Map<Integer, Boolean> REMOTE_FLYING = new ConcurrentHashMap<>();

   public static void setRemoteFlying(int entityId, boolean isFlying) {
      if (isFlying) {
         REMOTE_FLYING.put(entityId, true);
      } else {
         REMOTE_FLYING.remove(entityId);
      }
   }

   public static boolean isRemoteFlying(int entityId) {
      return REMOTE_FLYING.getOrDefault(entityId, false);
   }

   public static void clearRemoteCache() {
      REMOTE_FLYING.clear();
   }

   public static boolean isFlying() {
      return hovering || flying || WingFlightClientHandler.isWingHovering() || WingFlightClientHandler.isWingFlying();
   }

   public static float getHoveringAnimation(float partialTicks) {
      return !hovering && !flying && !WingFlightClientHandler.isWingHovering() ? 0.0F : 1.0F;
   }

   public static float getLevitationAnimation(float partialTicks) {
      return WingFlightClientHandler.isWingFlying() ? 1.0F : 0.0F;
   }

   public static float getFlightAnimation(float partialTicks) {
      return 0.0F;
   }

   @SubscribeEvent
   public static void onKeyInput(Key event) {
      Minecraft mc = Minecraft.getInstance();
      LocalPlayer player = mc.player;
      if (player != null && mc.screen == null) {
         if (hasFlightSkill(player)) {
            if (event.getKey() == 32 && event.getAction() == 1) {
               long currentTime = System.currentTimeMillis();
               if (currentTime - lastJumpTime <= 300L) {
                  lastJumpTime = 0L;
                  if (flying) {
                     stopFlying(player);
                  } else if (hovering) {
                     stopHover(player);
                  } else if (!player.onGround()) {
                     if (player.getAbilities().flying) {
                        player.getAbilities().flying = false;
                     }

                     startHover(player);
                  }
               } else {
                  lastJumpTime = currentTime;
               }
            }

            if (mc.options.keyUp.matches(event.getKey(), event.getScanCode()) && event.getAction() == 1) {
               long currentTime = System.currentTimeMillis();
               if (hovering && currentTime - lastWTime <= 400L) {
                  doubleTapW = true;
                  VPower.LOGGER.info("[Flight] Double-tap detected on mapped forward key!");
               }

               lastWTime = currentTime;
            }
         }
      }
   }

   @SubscribeEvent
   public static void onClientTick(Pre event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null && mc.level != null && !mc.isPaused()) {
         LocalPlayer player = mc.player;
         if (!hasFlightSkill(player)) {
            if (hovering || flying) {
               stopFlying(player);
               stopHover(player);
            }
         } else if (flying) {
            handleFlightTick(player);
            if (!mc.options.keyUp.isDown()) {
               stopFlying(player);
               startHover(player);
            }

            if (player.onGround()) {
               stopFlying(player);
            }
         } else {
            handleHoverTick(player);
            if (doubleTapW && System.currentTimeMillis() - lastWTime > 500L) {
               doubleTapW = false;
            }

            boolean isSprinting = player.isSprinting() || mc.options.keySprint.isDown() || doubleTapW;
            if (hovering && mc.options.keyUp.isDown() && isSprinting && !player.onGround()) {
               if (doubleTapW) {
                  VPower.LOGGER.info("[Flight] Triggering flight via double-tap W");
               }

               doubleTapW = false;
               startFlying(player);
            }

            checkRemotePlayersLanding(mc);
         }
      }
   }

   private static void handleHoverTick(LocalPlayer player) {
      if (hovering) {
         player.fallDistance = 0.0F;
         player.setSwimming(false);
         player.setForcedPose(Pose.STANDING);
         player.noPhysics = true;
         if (player.getAbilities().flying) {
            player.getAbilities().flying = false;
         }

         boolean inWater = player.isInWater() || player.isUnderWater();
         BlockPos feetPos = player.blockPosition();
         BlockPos belowPos = feetPos.below();
         boolean solidBelow = player.level().getBlockState(belowPos).isSolid() && player.getY() - (double)belowPos.getY() <= 1.0;
         if (solidBelow && player.getDeltaMovement().y <= 0.0 && !Minecraft.getInstance().options.keyJump.isDown()) {
            stopHover(player);
         } else {
            Minecraft mc = Minecraft.getInstance();
            boolean jump = mc.options.keyJump.isDown();
            boolean sneak = mc.options.keyShift.isDown();
            if (jump && !sneak) {
               verticalHover = Mth.clamp(verticalHover + 1, -20, 20);
            } else if (sneak && !jump) {
               verticalHover = Mth.clamp(verticalHover - 1, -20, 20);
            } else if (verticalHover != 0) {
               verticalHover = Mth.clamp(verticalHover + (verticalHover > 0 ? -1 : 1), -20, 20);
            }

            double moveSpeed = 0.1;
            Vec3 moveInput = getMovementVector(player, player.xxa, player.zza).scale(moveSpeed);
            double manualVy = (double)verticalHover / 40.0;
            double autoOscillation = verticalHover == 0 ? Math.sin((double)((float)player.tickCount / 10.0F)) / 100.0 : 0.0;
            Vec3 v = player.getDeltaMovement();
            double damp = inWater ? 0.95 : 0.8;
            player.setDeltaMovement((v.x + moveInput.x) * damp, moveInput.y + manualVy + autoOscillation, (v.z + moveInput.z) * damp);
         }
      }
   }

   private static Vec3 getMovementVector(Player player, float xxa, float zza) {
      Vec3 look = player.getLookAngle();
      Vec3 right = look.cross(new Vec3(0.0, 1.0, 0.0)).normalize();
      if (right.lengthSqr() < 1.0E-4) {
         float f = player.getYRot() * (float) (Math.PI / 180.0);
         right = new Vec3((double)Mth.cos(f), 0.0, (double)Mth.sin(f)).normalize();
      }

      Vec3 forwardPart = look.scale((double)zza);
      Vec3 strafePart = right.scale((double)(-xxa));
      return forwardPart.add(strafePart);
   }

   private static void handleFlightTick(LocalPlayer player) {
      if (flying) {
         player.fallDistance = 0.0F;
         player.setSwimming(false);
         if (!player.isFallFlying()) {
            player.startFallFlying();
         }

         Minecraft mc = Minecraft.getInstance();
         boolean forward = mc.options.keyUp.isDown();
         if (forward) {
            Vec3 lookDirection = player.getLookAngle();
            Vec3 currentVelocity = player.getDeltaMovement();
            boolean sneak = mc.options.keyShift.isDown();
            boolean jump = mc.options.keyJump.isDown();
            if (sneak && !jump) {
               player.setDeltaMovement(currentVelocity.x, currentVelocity.y - 0.08, currentVelocity.z);
               currentVelocity = player.getDeltaMovement();
            } else if (jump && !sneak) {
               player.setDeltaMovement(currentVelocity.x, currentVelocity.y + 0.05, currentVelocity.z);
               currentVelocity = player.getDeltaMovement();
            }

            if (player.horizontalCollision) {
               double up = 0.2;
               double slide = 0.1;
               Vec3 adjust = new Vec3(lookDirection.x * slide, up, lookDirection.z * slide);
               player.setDeltaMovement(currentVelocity.scale(0.6).add(adjust));
            } else {
               float upwardsAngleOfAttack = Mth.degreesDifferenceAbs(player.getXRot(), -90.0F);
               float baseSpeed = 0.045F;
               if (upwardsAngleOfAttack <= 15.0F) {
                  baseSpeed *= 2.75F;
               }

               if (player.getY() > 320.0 && lookDirection.y > 0.0) {
                  baseSpeed *= 0.3F;
               }

               if (player.isInWater() || player.isUnderWater() || player.isInLava()) {
                  baseSpeed *= 5.5F;
                  player.setSwimming(false);
               }

               Vec3 targetVelocity = new Vec3(
                  lookDirection.x * (double)baseSpeed + (lookDirection.x * 1.5 - currentVelocity.x) * (double)baseSpeed,
                  lookDirection.y * (double)baseSpeed + (lookDirection.y * 1.5 - currentVelocity.y) * (double)baseSpeed,
                  lookDirection.z * (double)baseSpeed + (lookDirection.z * 1.5 - currentVelocity.z) * (double)baseSpeed
               );
               player.setDeltaMovement(currentVelocity.add(targetVelocity));
            }
         }
      }
   }

   private static void startHover(LocalPlayer player) {
      hovering = true;
      verticalHover = 0;
      if (player.isFallFlying()) {
         player.stopFallFlying();
      }

      Vec3 v = player.getDeltaMovement();
      player.setDeltaMovement(v.x * 0.6, 0.0, v.z * 0.6);
      player.fallDistance = 0.0F;
      player.setSwimming(false);
      if (!hoverAnimActive) {
         AnimationHelper.playAnimationWithFade(player, ModAnimations.HOVER_ON, 3, true, false);
         hoverAnimActive = true;
      }

      PacketDistributor.sendToServer(new FlightPosePacket(FlightPosePacket.Action.START_HOVER), new CustomPacketPayload[0]);
   }

   private static void stopHover(LocalPlayer player) {
      hovering = false;
      verticalHover = 0;
      player.noPhysics = false;
      player.setForcedPose(null);
      if (hoverAnimActive) {
         AnimationHelper.stopAnimation(player, 3);
         hoverAnimActive = false;
      }

      if (flyingAnimActive) {
         AnimationHelper.stopAnimation(player, 3);
         flyingAnimActive = false;
      }

      PacketDistributor.sendToServer(new FlightPosePacket(FlightPosePacket.Action.STOP_HOVER), new CustomPacketPayload[0]);
   }

   private static void startFlying(LocalPlayer player) {
      hovering = false;
      flying = true;
      verticalHover = 0;
      hoverAnimActive = false;
      player.noPhysics = false;
      player.startFallFlying();
      Vec3 currentVelocity = player.getDeltaMovement();
      Vec3 lookDirection = player.getLookAngle();
      boolean inWater = player.isInWater() || player.isUnderWater();
      double boostMultiplier = inWater ? 2.0 : 1.0;
      if (lookDirection.y > 0.1) {
         player.setDeltaMovement(currentVelocity.add(0.0, 0.3 * boostMultiplier, 0.0));
      } else {
         player.setDeltaMovement(currentVelocity.add(lookDirection.x * 0.5 * boostMultiplier, 0.2 * boostMultiplier, lookDirection.z * 0.5 * boostMultiplier));
      }

      AnimationHelper.playAnimationWithFade(player, ModAnimations.FLIGHT_ON, 2, true, true);
      flyingAnimActive = true;
      PacketDistributor.sendToServer(new FlightPosePacket(FlightPosePacket.Action.START), new CustomPacketPayload[0]);
   }

   private static void stopFlying(LocalPlayer player) {
      boolean wasFlying = flying;
      flying = false;
      if (player.isFallFlying()) {
         player.stopFallFlying();
      }

      if (flyingAnimActive) {
         AnimationHelper.stopAnimation(player, 2);
         flyingAnimActive = false;
      }

      if (wasFlying) {
         PacketDistributor.sendToServer(new FlightPosePacket(FlightPosePacket.Action.STOP), new CustomPacketPayload[0]);
      }
   }

   private static void checkRemotePlayersLanding(Minecraft mc) {
      if (mc.level != null && mc.player != null) {
         for (Player remotePlayer : mc.level.players()) {
            if (remotePlayer.getId() != mc.player.getId()) {
               if (isRemoteFlying(remotePlayer.getId()) && remotePlayer.onGround()) {
                  setRemoteFlying(remotePlayer.getId(), false);
               }

               if (WingFlightClientHandler.isRemoteWingActive(remotePlayer.getId())) {
                  String currentAnim = AnimationHelper.getCurrentAnimation(remotePlayer);
                  boolean hoveringAnim = currentAnim != null && currentAnim.startsWith("wings_hover");
                  if (remotePlayer.onGround() && !hoveringAnim) {
                     WingFlightClientHandler.setRemoteWingState(remotePlayer.getId(), false, false);
                  }
               }
            }
         }
      }
   }

   /**
    * Свой полёт The Boys — только у Fire (Human Torch), пока горит (fireTimer). Навык Flight летает полётом Invincible
    * (VPowerFlight), Spiritualization не перенесён.
    */
   private static boolean hasFlightSkill(LocalPlayer player) {
      try {
         SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         return skillData.getFireTimer() > 0;
      } catch (Exception var4) {
         return false;
      }
   }


}
