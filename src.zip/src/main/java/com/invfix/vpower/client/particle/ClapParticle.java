package com.invfix.vpower.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import org.jetbrains.annotations.NotNull;

public class ClapParticle extends TextureSheetParticle {
   private static final int LIFETIME = 15;
   private static final float QUAD_SIZE = 2.0F;
   private final SpriteSet sprites;

   protected ClapParticle(ClientLevel level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, SpriteSet sprites) {
      super(level, x, y, z, xSpeed, ySpeed, zSpeed);
      this.sprites = sprites;
      this.lifetime = 15;
      this.quadSize = 2.0F;
      this.gravity = 0.0F;
      this.hasPhysics = false;
      this.xd = xSpeed;
      this.yd = ySpeed;
      this.zd = zSpeed;
      this.setSpriteFromAge(this.sprites);
   }

   public void tick() {
      super.tick();
      this.setSpriteFromAge(this.sprites);
   }

   @NotNull
   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_OPAQUE;
   }

   public static class Provider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public Provider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      public Particle createParticle(
         @NotNull SimpleParticleType type, @NotNull ClientLevel level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed
      ) {
         return new ClapParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, this.sprites);
      }
   }
}
