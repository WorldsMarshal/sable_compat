package com.invfix.vpower.client.animation;

import com.google.gson.JsonObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.PreparableReloadListener;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.PreparableReloadListener.PreparationBarrier;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.profiling.ProfilerFiller;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.cache.GeckoLibCache;
import software.bernie.geckolib.loading.json.typeadapter.KeyFramesAdapter;
import software.bernie.geckolib.loading.object.BakedAnimations;

@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT},
   bus = EventBusSubscriber.Bus.MOD
)
public class PlayerAnimationsLoader implements PreparableReloadListener {
   private static final String PLAYER_ANIMATIONS_PATH = "player_animations";
   private static final PlayerAnimationsLoader INSTANCE = new PlayerAnimationsLoader();

   @SubscribeEvent
   public static void onRegisterReloadListeners(RegisterClientReloadListenersEvent event) {
      event.registerReloadListener(INSTANCE);
      GeckoLibConstants.LOGGER.info("[theboysMod] PlayerAnimationsLoader registered via NeoForge event");
   }

   public CompletableFuture<Void> reload(
      PreparationBarrier stage,
      ResourceManager resourceManager,
      ProfilerFiller preparationsProfiler,
      ProfilerFiller reloadProfiler,
      Executor backgroundExecutor,
      Executor gameExecutor
   ) {
      return CompletableFuture.supplyAsync(
            () -> resourceManager.listResources("player_animations", fileName -> fileName.toString().endsWith(".animation.json")), backgroundExecutor
         )
         .thenCompose(stage::wait)
         .thenAcceptAsync(resources -> {
            Map<ResourceLocation, BakedAnimations> animationsCache = GeckoLibCache.getBakedAnimations();
            if (animationsCache == null || animationsCache.isEmpty()) {
               GeckoLibConstants.LOGGER.warn("[theboysMod] GeckoLib cache is empty, animations may not load properly");
            }

            for (ResourceLocation resource : resources.keySet()) {
               try {
                  BakedAnimations animations = loadAnimationsFile(resource, resourceManager);
                  animationsCache.put(resource, animations);
                  GeckoLibConstants.LOGGER.info("[theboysMod] Loaded player animation into GeckoLib cache: {}", resource);
               } catch (Exception var6x) {
                  GeckoLibConstants.LOGGER.error("[theboysMod] Failed to load player animation: {}", resource, var6x);
               }
            }
         }, gameExecutor);
   }

   private static BakedAnimations loadAnimationsFile(ResourceLocation location, ResourceManager manager) {
      try {
         BakedAnimations var5;
         try (InputStream inputStream = manager.getResourceOrThrow(location).open()) {
            String content = new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
            JsonObject json = (JsonObject)GsonHelper.fromJson(KeyFramesAdapter.GEO_GSON, content, JsonObject.class);
            var5 = (BakedAnimations)KeyFramesAdapter.GEO_GSON.fromJson(GsonHelper.getAsJsonObject(json, "animations"), BakedAnimations.class);
         }

         return var5;
      } catch (Exception var8) {
         GeckoLibConstants.LOGGER.error("Couldn't load animation file: " + location, var8);
         throw new RuntimeException(var8);
      }
   }
}
