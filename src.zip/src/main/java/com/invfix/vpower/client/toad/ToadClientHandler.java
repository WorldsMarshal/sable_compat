package com.invfix.vpower.client.toad;

import com.mojang.blaze3d.vertex.PoseStack;
import com.invfix.vpower.VPower;
import com.invfix.vpower.client.ClientSkillStateCache;
import com.invfix.vpower.client.fp.ToadArmGeoRenderer;
import com.invfix.vpower.client.invisibility.InvisibilityRenderHelper;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.ToadSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.world.entity.HumanoidArm;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderArmEvent;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public final class ToadClientHandler {
   public static final float CAMERA_Y_OFFSET = 0.0F;
   private static final String TOAD_ID = ToadSkill.ID.toString();
   private static final ToadArmGeoRenderer ARM_RENDERER = new ToadArmGeoRenderer();

   private ToadClientHandler() {
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public static void onRenderArm(RenderArmEvent event) {
      AbstractClientPlayer partialTick = event.getPlayer();
      if (partialTick instanceof AbstractClientPlayer && hasToad(partialTick)) {
         if (InvisibilityRenderHelper.shouldHideBody(partialTick)) {
            event.setCanceled(true);
         } else {
            event.setCanceled(true);
            float partialTickx = mcPartialTick();
            renderFirstPersonArm(event.getPoseStack(), event.getMultiBufferSource(), event.getPackedLight(), partialTickx, partialTick, event.getArm());
         }
      }
   }

   public static void renderFirstPersonArm(
      PoseStack poseStack, MultiBufferSource buffer, int packedLight, float partialTick, AbstractClientPlayer player, HumanoidArm arm
   ) {
      if (player != null && poseStack != null && buffer != null) {
         if (!InvisibilityRenderHelper.shouldHideBody(player)) {
            Minecraft mc = Minecraft.getInstance();
            boolean firstPerson = mc.player != null && mc.player.getUUID().equals(player.getUUID()) && mc.options.getCameraType().isFirstPerson();
            if (firstPerson) {
               if (mc.getEntityRenderDispatcher().getRenderer(player) instanceof PlayerRenderer playerRenderer) {
                  try {
                     ARM_RENDERER.renderArm(
                        poseStack, buffer, packedLight, partialTick, player, (PlayerModel<AbstractClientPlayer>)playerRenderer.getModel(), arm
                     );
                  } catch (Exception var11) {
                     VPower.LOGGER.error("[Toad] First person arm render failed", var11);
                  }
               }
            }
         }
      }
   }

   private static float mcPartialTick() {
      return Minecraft.getInstance().getTimer().getGameTimeDeltaPartialTick(true);
   }

   public static boolean hasToad(AbstractClientPlayer player) {
      if (player == null) {
         return false;
      } else {
         try {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            if (data.hasSkill(TOAD_ID)) {
               return true;
            }
         } catch (Exception var2) {
         }

         return ClientSkillStateCache.hasSkill(player.getId(), TOAD_ID);
      }
   }
}
