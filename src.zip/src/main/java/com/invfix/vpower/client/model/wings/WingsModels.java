package com.invfix.vpower.client.model.wings;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;

public final class WingsModels {
   public static final ModelLayerLocation FEATHERED = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("theboysmod", "feathered_wings"), "main");

   private WingsModels() {
   }
}
