package com.invfix.vpower.client.soundwave;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class SoundWaveChargeFovHandler {
   private static final float FOV_ZOOM_MIN = 0.85F;
   private static final float TRANSITION_SPEED = 0.22F;
   private static boolean charging = false;
   private static float chargeProgress = 0.0F;
   private static float currentMultiplier = 1.0F;

   private SoundWaveChargeFovHandler() {
   }

   public static void setChargeProgress(float progress) {
      charging = true;
      chargeProgress = clamp(progress);
   }

   public static void stopCharging() {
      charging = false;
      chargeProgress = 0.0F;
   }

   public static void tick() {
      float target = charging ? 1.0F - 0.14999998F * chargeProgress : 1.0F;
      if (Math.abs(currentMultiplier - target) < 0.002F) {
         currentMultiplier = target;
      } else {
         currentMultiplier = currentMultiplier + (target - currentMultiplier) * 0.22F;
      }
   }

   public static float getCurrentMultiplier() {
      return currentMultiplier;
   }

   public static boolean isZooming() {
      return currentMultiplier < 0.999F;
   }

   private static float clamp(float value) {
      return Math.max(0.0F, Math.min(1.0F, value));
   }
}
