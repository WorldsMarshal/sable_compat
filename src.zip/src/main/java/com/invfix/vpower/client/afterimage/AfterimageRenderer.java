package com.invfix.vpower.client.afterimage;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.Deque;
import com.invfix.vpower.client.invisibility.InvisibilityRenderHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class AfterimageRenderer {
   private static final float TINT_R = 0.4F;
   private static final float TINT_G = 0.6F;
   private static final float TINT_B = 1.0F;

   public static void renderAll(PoseStack poseStack, float partialTick) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level != null && mc.player != null) {
         Vec3 cameraPos = mc.gameRenderer.getMainCamera().getPosition();
         BufferSource bufferSource = mc.renderBuffers().bufferSource();
         long currentTick = AfterimageManager.getClientTick();
         renderPlayerAfterimages(mc, poseStack, bufferSource, cameraPos, partialTick, currentTick);
      }
   }

   private static void renderPlayerAfterimages(
      Minecraft mc, PoseStack poseStack, BufferSource bufferSource, Vec3 cameraPos, float partialTick, long currentTick
   ) {
      for (AbstractClientPlayer player : mc.level.players()) {
         int id = player.getId();
         Deque<AfterimageData> afterimages = AfterimageManager.getAfterimages(id);
         if (afterimages != null
            && !afterimages.isEmpty()
            && !InvisibilityRenderHelper.shouldHideBody(player)
            && (player != mc.player || !mc.options.getCameraType().isFirstPerson())) {
            EntityRenderDispatcher dispatcher = mc.getEntityRenderDispatcher();
            EntityRenderer<? super AbstractClientPlayer> rawRenderer = dispatcher.getRenderer(player);
            if (rawRenderer instanceof PlayerRenderer) {
               PlayerRenderer playerRenderer = (PlayerRenderer)rawRenderer;
               PlayerModel<AbstractClientPlayer> model = (PlayerModel<AbstractClientPlayer>)playerRenderer.getModel();
               ResourceLocation skinTexture = player.getSkin().texture();
               RenderType renderType = RenderType.entityTranslucent(skinTexture);

               for (AfterimageData snapshot : afterimages) {
                  float alpha = snapshot.getAlpha(currentTick, 10);
                  if (!(alpha <= 0.0F)) {
                     alpha = Math.min(alpha * 0.6F, 0.5F);
                     poseStack.pushPose();
                     double renderX = snapshot.position.x - cameraPos.x;
                     double renderY = snapshot.position.y - cameraPos.y;
                     double renderZ = snapshot.position.z - cameraPos.z;
                     poseStack.translate(renderX, renderY, renderZ);
                     poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - snapshot.yBodyRot));
                     if (snapshot.isFallFlying) {
                        Vec3 vel = snapshot.velocity;
                        double horizontalSpeed = vel.horizontalDistance();
                        float pitchAngle = 0.0F;
                        if (horizontalSpeed > 0.01) {
                           pitchAngle = (float)Math.toDegrees(Math.atan2(vel.y, horizontalSpeed));
                        }

                        pitchAngle = Mth.clamp(pitchAngle, -70.0F, 70.0F);
                        float bodyLean = -90.0F + pitchAngle;
                        poseStack.mulPose(Axis.XP.rotationDegrees(bodyLean));
                        poseStack.translate(0.0F, -1.0F, 0.2F);
                        poseStack.scale(-1.0F, -1.0F, 1.0F);
                        poseStack.translate(0.0F, -1.501F, 0.0F);
                     } else {
                        poseStack.scale(-1.0F, -1.0F, 1.0F);
                        poseStack.translate(0.0F, -1.501F, 0.0F);
                     }

                     float headYawRel = snapshot.yHeadRot - snapshot.yBodyRot;
                     headYawRel = Math.max(-60.0F, Math.min(60.0F, headYawRel));
                     model.young = false;
                     model.riding = false;
                     model.setupAnim(player, snapshot.limbSwingPos, snapshot.limbSwingSpeed, (float)currentTick + partialTick, headYawRel, snapshot.xRot);
                     VertexConsumer tintedConsumer = new AfterimageRenderer.TintedVertexConsumer(bufferSource.getBuffer(renderType), 0.4F, 0.6F, 1.0F, alpha);
                     int light = 15728640;
                     model.body.render(poseStack, tintedConsumer, light, OverlayTexture.NO_OVERLAY);
                     model.head.render(poseStack, tintedConsumer, light, OverlayTexture.NO_OVERLAY);
                     model.leftArm.render(poseStack, tintedConsumer, light, OverlayTexture.NO_OVERLAY);
                     model.rightArm.render(poseStack, tintedConsumer, light, OverlayTexture.NO_OVERLAY);
                     model.leftLeg.render(poseStack, tintedConsumer, light, OverlayTexture.NO_OVERLAY);
                     model.rightLeg.render(poseStack, tintedConsumer, light, OverlayTexture.NO_OVERLAY);
                     poseStack.popPose();
                  }
               }
            }
         }
      }
   }




   private static class TintedVertexConsumer implements VertexConsumer {
      private final VertexConsumer delegate;
      private final int tintR;
      private final int tintG;
      private final int tintB;
      private final int tintA;

      TintedVertexConsumer(VertexConsumer delegate, float r, float g, float b, float a) {
         this.delegate = delegate;
         this.tintR = (int)(r * 255.0F);
         this.tintG = (int)(g * 255.0F);
         this.tintB = (int)(b * 255.0F);
         this.tintA = (int)(a * 255.0F);
      }

      public VertexConsumer addVertex(float x, float y, float z) {
         this.delegate.addVertex(x, y, z);
         return this;
      }

      public VertexConsumer setColor(int red, int green, int blue, int alpha) {
         this.delegate.setColor(this.tintR, this.tintG, this.tintB, this.tintA);
         return this;
      }

      public VertexConsumer setUv(float u, float v) {
         this.delegate.setUv(u, v);
         return this;
      }

      public VertexConsumer setUv1(int u, int v) {
         this.delegate.setUv1(u, v);
         return this;
      }

      public VertexConsumer setUv2(int u, int v) {
         this.delegate.setUv2(u, v);
         return this;
      }

      public VertexConsumer setNormal(float x, float y, float z) {
         this.delegate.setNormal(x, y, z);
         return this;
      }
   }
}
