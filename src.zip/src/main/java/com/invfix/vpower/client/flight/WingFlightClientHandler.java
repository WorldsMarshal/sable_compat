package com.invfix.vpower.client.flight;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.client.animation.AnimationHelper;
import com.invfix.vpower.client.animation.ModAnimations;
import com.invfix.vpower.network.FlightPosePacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.FlightSkill;
import com.invfix.vpower.skill.skills.WingsSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent.Pre;
import net.neoforged.neoforge.client.event.InputEvent.Key;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public final class WingFlightClientHandler {
   private static final long DOUBLE_CLICK_THRESHOLD_MS = 300L;
   private static final long DOUBLE_TAP_W_THRESHOLD_MS = 400L;
   private static final float HOVER_MOVE_SPEED = 0.1F;
   private static final float HOVER_DAMP_AIR = 0.8F;
   private static final float HOVER_DAMP_WATER = 0.95F;
   private static final float WINGS_SPEED = 0.0125F;
   private static final float MOMENTUM_BLEND_FACTOR = 1.5F;
   private static final float UPWARD_ATTACK_MULTIPLIER = 2.75F;
   private static final float UPWARD_ATTACK_ANGLE = 15.0F;
   private static final float REQUIRED_FOOD_AMOUNT = 6.001F;
   private static final float EXHAUSTION_AMOUNT = 0.03F;
   private static long lastJumpTime = 0L;
   private static long lastWTime = 0L;
   private static boolean doubleTapW = false;
   private static boolean wingHovering = false;
   private static boolean wingFlying = false;
   private static int verticalHover = 0;
   private static final Map<Integer, Boolean> REMOTE_WING_KNOWN = new ConcurrentHashMap<>();
   private static final Map<Integer, Boolean> REMOTE_WING_ACTIVE = new ConcurrentHashMap<>();
   private static final Map<Integer, Boolean> REMOTE_WING_HOVERING = new ConcurrentHashMap<>();

   private WingFlightClientHandler() {
   }

   public static boolean isWingFlying() {
      return wingFlying;
   }

   public static boolean isWingHovering() {
      return wingHovering;
   }

   public static void setRemoteWingState(int entityId, boolean active, boolean hovering) {
      if (active) {
         REMOTE_WING_KNOWN.put(entityId, true);
         REMOTE_WING_ACTIVE.put(entityId, true);
         if (hovering) {
            REMOTE_WING_HOVERING.put(entityId, true);
         } else {
            REMOTE_WING_HOVERING.remove(entityId);
         }
      } else {
         REMOTE_WING_ACTIVE.remove(entityId);
         REMOTE_WING_HOVERING.remove(entityId);
      }
   }

   public static boolean isRemoteWingKnown(int entityId) {
      return REMOTE_WING_KNOWN.getOrDefault(entityId, false);
   }

   public static void setRemoteWingKnown(int entityId, boolean known) {
      if (known) {
         REMOTE_WING_KNOWN.put(entityId, true);
      } else {
         REMOTE_WING_KNOWN.remove(entityId);
         REMOTE_WING_ACTIVE.remove(entityId);
         REMOTE_WING_HOVERING.remove(entityId);
      }
   }

   public static boolean isRemoteWingActive(int entityId) {
      return REMOTE_WING_ACTIVE.getOrDefault(entityId, false);
   }

   public static boolean isRemoteWingHovering(int entityId) {
      return REMOTE_WING_HOVERING.getOrDefault(entityId, false);
   }

   public static void clearRemoteCache() {
      REMOTE_WING_KNOWN.clear();
      REMOTE_WING_ACTIVE.clear();
      REMOTE_WING_HOVERING.clear();
   }

   @SubscribeEvent
   public static void onKeyInput(Key event) {
      if (event.getAction() == 1) {
         Minecraft mc = Minecraft.getInstance();
         LocalPlayer player = mc.player;
         if (player != null && mc.screen == null) {
            if (hasWingsSkill(player) && !hasLegacyFlightAbility(player) && hasBodyForWings(player)) {
               if (event.getKey() == 32) {
                  handleJumpToggle(player);
               }

               if (mc.options.keyUp.matches(event.getKey(), event.getScanCode())) {
                  long now = System.currentTimeMillis();
                  if (wingHovering && now - lastWTime <= 400L) {
                     doubleTapW = true;
                  }

                  lastWTime = now;
               }
            }
         }
      }
   }

   private static void handleJumpToggle(LocalPlayer player) {
      long now = System.currentTimeMillis();
      if (now - lastJumpTime > 300L) {
         lastJumpTime = now;
      } else {
         lastJumpTime = 0L;
         if (wingFlying) {
            stopWingFlying(player);
            stopWingHover(player);
         } else if (wingHovering) {
            stopWingHover(player);
         } else {
            if (!player.onGround() && !player.isInWater() && !player.isUnderWater()) {
               startWingHover(player);
            }
         }
      }
   }

   @SubscribeEvent
   public static void onClientTick(Pre event) {
      Minecraft mc = Minecraft.getInstance();
      LocalPlayer player = mc.player;
      if (player != null && mc.level != null && !mc.isPaused()) {
         if (hasWingsSkill(player) && !hasLegacyFlightAbility(player) && hasBodyForWings(player)) {
            if (player.onGround() && !wingHovering && !wingFlying) {
               setRemoteWingState(player.getId(), false, false);
            }

            if (!wingHovering && !wingFlying && player.isFallFlying()) {
               wingFlying = true;
            }

            if (wingFlying) {
               handleFlightTick(player, mc);
            } else {
               handleHoverTick(player, mc);
               if (doubleTapW && System.currentTimeMillis() - lastWTime > 500L) {
                  doubleTapW = false;
               }

               boolean sprintTrigger = player.isSprinting() || mc.options.keySprint.isDown() || doubleTapW;
               if (wingHovering && mc.options.keyUp.isDown() && sprintTrigger && !player.onGround()) {
                  doubleTapW = false;
                  startWingFlying(player);
               }
            }
         } else {
            if (wingHovering || wingFlying) {
               stopWingFlying(player);
               stopWingHover(player);
            }

            setRemoteWingKnown(player.getId(), false);
         }
      }
   }

   private static void handleFlightTick(LocalPlayer player, Minecraft mc) {
      if (!player.isFallFlying()) {
         wingFlying = false;
         if (!player.onGround() && !player.isInWater() && !player.isUnderWater()) {
            startWingHover(player);
         }
      } else {
         wingFlying = true;
         player.fallDistance = 0.0F;
         if (player.onGround()) {
            stopWingFlying(player);
            stopWingHover(player);
         } else if (!mc.options.keyShift.isDown() && !player.isInWater() && !player.isUnderWater()) {
            if (!player.isCreative() && (float)player.getFoodData().getFoodLevel() < 6.001F) {
               stopWingFlying(player);
               if (!player.onGround()) {
                  startWingHover(player);
               }
            } else if (!mc.options.keyUp.isDown()) {
               stopWingFlying(player);
               if (!player.onGround()) {
                  startWingHover(player);
               }
            } else {
               Vec3 look = player.getLookAngle();
               Vec3 velocity = player.getDeltaMovement();
               float upwardAttack = Mth.degreesDifferenceAbs(player.getXRot(), -90.0F);
               float speed = 0.0125F * (upwardAttack <= 15.0F ? 2.75F : 1.0F);
               player.setDeltaMovement(
                  velocity.add(
                     look.x * (double)speed + (look.x * 1.5 - velocity.x) * (double)speed,
                     look.y * (double)speed + (look.y * 1.5 - velocity.y) * (double)speed,
                     look.z * (double)speed + (look.z * 1.5 - velocity.z) * (double)speed
                  )
               );
               if (!player.isCreative() && player.tickCount % 20 == 0) {
                  player.getFoodData().addExhaustion(0.03F);
               }
            }
         } else {
            stopWingFlying(player);
            if (!player.onGround() && !player.isInWater() && !player.isUnderWater()) {
               startWingHover(player);
            }
         }
      }
   }

   private static void handleHoverTick(LocalPlayer player, Minecraft mc) {
      if (wingHovering) {
         if (player.onGround()) {
            stopWingHover(player);
         } else {
            player.fallDistance = 0.0F;
            player.setSwimming(false);
            player.setForcedPose(Pose.STANDING);
            player.noPhysics = true;
            if (player.getAbilities().flying) {
               player.getAbilities().flying = false;
            }

            boolean inWater = player.isInWater() || player.isUnderWater();
            BlockPos feetPos = player.blockPosition();
            BlockPos belowPos = feetPos.below();
            boolean solidBelow = player.level().getBlockState(belowPos).isSolid() && player.getY() - (double)belowPos.getY() <= 1.0;
            if (solidBelow && player.getDeltaMovement().y <= 0.0 && !mc.options.keyJump.isDown()) {
               stopWingHover(player);
            } else {
               boolean jump = mc.options.keyJump.isDown();
               boolean sneak = mc.options.keyShift.isDown();
               if (jump && !sneak) {
                  verticalHover = Mth.clamp(verticalHover + 1, -20, 20);
               } else if (sneak && !jump) {
                  verticalHover = Mth.clamp(verticalHover - 1, -20, 20);
               } else if (verticalHover != 0) {
                  verticalHover = Mth.clamp(verticalHover + (verticalHover > 0 ? -1 : 1), -20, 20);
               }

               Vec3 moveInput = getMovementVector(player, player.xxa, player.zza).scale(0.1F);
               double manualVy = (double)verticalHover / 40.0;
               double autoOscillation = verticalHover == 0 ? Math.sin((double)((float)player.tickCount / 10.0F)) / 100.0 : 0.0;
               Vec3 velocity = player.getDeltaMovement();
               double damp = inWater ? 0.95F : 0.8F;
               player.setDeltaMovement((velocity.x + moveInput.x) * damp, moveInput.y + manualVy + autoOscillation, (velocity.z + moveInput.z) * damp);
            }
         }
      }
   }

   private static void startWingHover(LocalPlayer player) {
      wingHovering = true;
      wingFlying = false;
      verticalHover = 0;
      doubleTapW = false;
      if (player.isFallFlying()) {
         player.stopFallFlying();
      }

      Vec3 v = player.getDeltaMovement();
      player.setDeltaMovement(v.x * 0.6, 0.0, v.z * 0.6);
      player.fallDistance = 0.0F;
      player.setSwimming(false);
      AnimationHelper.playAnimationWithFade(player, ModAnimations.WINGS_HOVER_START, 2, false, false);
      PacketDistributor.sendToServer(new FlightPosePacket(FlightPosePacket.Action.START_HOVER), new CustomPacketPayload[0]);
   }

   private static void stopWingHover(LocalPlayer player) {
      boolean wasHovering = wingHovering;
      wingHovering = false;
      verticalHover = 0;
      player.noPhysics = false;
      player.setForcedPose(null);
      AnimationHelper.playAnimationWithFade(player, ModAnimations.WINGS_HOVER_STOP, 2, false, false);
      if (wasHovering) {
         PacketDistributor.sendToServer(new FlightPosePacket(FlightPosePacket.Action.STOP_HOVER), new CustomPacketPayload[0]);
      }
   }

   private static void startWingFlying(LocalPlayer player) {
      wingHovering = false;
      wingFlying = true;
      verticalHover = 0;
      player.noPhysics = false;
      player.setForcedPose(null);
      AnimationHelper.stopAnimation(player, 2);
      if (!player.isFallFlying()) {
         player.startFallFlying();
      }

      Vec3 velocity = player.getDeltaMovement();
      Vec3 look = player.getLookAngle();
      if (look.y > 0.1) {
         player.setDeltaMovement(velocity.add(0.0, 0.25, 0.0));
      } else {
         player.setDeltaMovement(velocity.add(look.x * 0.35, 0.15, look.z * 0.35));
      }

      PacketDistributor.sendToServer(new FlightPosePacket(FlightPosePacket.Action.START), new CustomPacketPayload[0]);
   }

   private static void stopWingFlying(LocalPlayer player) {
      boolean wasFlying = wingFlying;
      wingFlying = false;
      if (player.isFallFlying()) {
         player.stopFallFlying();
      }

      if (wasFlying) {
         PacketDistributor.sendToServer(new FlightPosePacket(FlightPosePacket.Action.STOP), new CustomPacketPayload[0]);
      }
   }

   private static Vec3 getMovementVector(Player player, float xxa, float zza) {
      Vec3 look = player.getLookAngle();
      Vec3 right = look.cross(new Vec3(0.0, 1.0, 0.0)).normalize();
      if (right.lengthSqr() < 1.0E-4) {
         float yaw = player.getYRot() * (float) (Math.PI / 180.0);
         right = new Vec3((double)Mth.cos(yaw), 0.0, (double)Mth.sin(yaw)).normalize();
      }

      Vec3 forwardPart = look.scale((double)zza);
      Vec3 strafePart = right.scale((double)(-xxa));
      return forwardPart.add(strafePart);
   }

   private static boolean hasWingsSkill(LocalPlayer player) {
      try {
         SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         return skillData.hasSkill(WingsSkill.ID.toString());
      } catch (Exception var2) {
         return false;
      }
   }

   private static boolean hasLegacyFlightAbility(LocalPlayer player) {
      try {
         SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         return skillData.hasSkill(FlightSkill.ID.toString()) || skillData.getFireTimer() > 0;
      } catch (Exception var2) {
         return false;
      }
   }

   private static boolean hasBodyForWings(LocalPlayer player) {
      try {
         FleshRegenData data = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
         return data.getScore("Body") != 0;
      } catch (Exception var2) {
         return true;
      }
   }


}
