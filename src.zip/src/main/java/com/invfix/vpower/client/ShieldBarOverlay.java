package com.invfix.vpower.client;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.FleshStrengthSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw.Layer;
import net.minecraft.client.player.LocalPlayer;

public class ShieldBarOverlay {
   private static final String SKILL_ID = FleshStrengthSkill.ID.toString();
   private static final int COLOR_BG = -1442840576;
   private static final int COLOR_SHIELD = -11549705;
   private static final int COLOR_SHIELD_LO = -30107;
   private static final int COLOR_BORDER = -7829368;
   private static final int BAR_WIDTH = 81;
   private static final int BAR_HEIGHT = 5;
   public static final Layer HUD_SHIELD = (guiGraphics, deltaTracker) -> {
      Minecraft mc = Minecraft.getInstance();
      LocalPlayer player = mc.player;
      if (player != null && !mc.options.hideGui) {
         if (!player.isSpectator()) {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            if (data.hasSkill(SKILL_ID)) {
               float ourExtraHp = data.getMaxShieldHp();
               float baseMaxHealth = 20.0F;
               if (!(ourExtraHp <= 0.0F)) {
                  float vanillaMaxHp = player.getMaxHealth() - ourExtraHp;
                  float shield = Math.max(0.0F, player.getHealth() - vanillaMaxHp);
                  int screenWidth = mc.getWindow().getGuiScaledWidth();
                  int screenHeight = mc.getWindow().getGuiScaledHeight();
                  float displayMaxHp = Math.max(baseMaxHealth, player.getMaxHealth() - ourExtraHp);
                  int heartRows = (int)Math.ceil((double)displayMaxHp / 2.0 / 10.0);
                  float absorption = player.getAbsorptionAmount();
                  int absorptionRows = (int)Math.ceil((double)absorption / 2.0 / 10.0);
                  int totalHeartRows = heartRows + absorptionRows;
                  int barX = screenWidth / 2 - 91;
                  int barY = screenHeight - 39 - totalHeartRows * 10 - 1;
                  renderShieldBar(guiGraphics, mc, barX, barY, shield, ourExtraHp);
               }
            }
         }
      }
   };

   private static void renderShieldBar(GuiGraphics g, Minecraft mc, int x, int y, float shield, float maxShield) {
      float ratio = Math.max(0.0F, Math.min(1.0F, shield / maxShield));
      int filled = Math.round(81.0F * ratio);
      g.fill(x - 1, y - 1, x + 81 + 1, y + 5 + 1, -7829368);
      g.fill(x, y, x + 81, y + 5, -1442840576);
      if (filled > 0) {
         int color = ratio < 0.25F ? -30107 : -11549705;
         g.fill(x, y, x + filled, y + 5, color);
         int highlight = blendAlpha(color, 1728053247);
         g.fill(x, y, x + filled, y + 1, highlight);
      }

      String text = String.format("%.0f/%.0f", shield, maxShield);
      g.pose().pushPose();
      g.pose().scale(0.75F, 0.75F, 1.0F);
      int textX = (int)((float)(x + 81 + 3) / 0.75F);
      int textY = (int)((float)y / 0.75F);
      g.drawString(mc.font, text, textX, textY, -5383962, false);
      g.pose().popPose();
   }

   private static int blendAlpha(int base, int overlay) {
      int a2 = overlay >> 24 & 0xFF;
      int r = lerp(base >> 16 & 0xFF, overlay >> 16 & 0xFF, a2);
      int gv = lerp(base >> 8 & 0xFF, overlay >> 8 & 0xFF, a2);
      int b = lerp(base & 0xFF, overlay & 0xFF, a2);
      return 0xFF000000 | r << 16 | gv << 8 | b;
   }

   private static int lerp(int a, int b, int alpha) {
      return a + (b - a) * alpha / 255;
   }
}
