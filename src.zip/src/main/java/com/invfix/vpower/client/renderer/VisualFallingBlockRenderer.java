package com.invfix.vpower.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.invfix.vpower.entity.effect.VisualFallingBlockEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.client.model.data.ModelData;

@OnlyIn(Dist.CLIENT)
public class VisualFallingBlockRenderer extends EntityRenderer<VisualFallingBlockEntity> {
   private final BlockRenderDispatcher dispatcher;

   public VisualFallingBlockRenderer(Context context) {
      super(context);
      this.shadowRadius = 0.5F;
      this.dispatcher = context.getBlockRenderDispatcher();
   }

   public void render(VisualFallingBlockEntity entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
      BlockState blockState = entity.getBlockState();
      if (blockState.getRenderShape() == RenderShape.MODEL) {
         Level level = entity.level();
         poseStack.pushPose();
         BlockPos blockPos = BlockPos.containing(entity.getX(), entity.getBoundingBox().maxY, entity.getZ());
         poseStack.translate(-0.5, 0.0, -0.5);
         BakedModel model = this.dispatcher.getBlockModel(blockState);
         long seed = blockState.getSeed(entity.getStartPos());

         for (RenderType renderType : model.getRenderTypes(blockState, RandomSource.create(seed), ModelData.EMPTY)) {
            this.dispatcher
               .getModelRenderer()
               .tesselateBlock(
                  level,
                  model,
                  blockState,
                  blockPos,
                  poseStack,
                  buffer.getBuffer(renderType),
                  false,
                  RandomSource.create(),
                  seed,
                  OverlayTexture.NO_OVERLAY,
                  ModelData.EMPTY,
                  renderType
               );
         }

         poseStack.popPose();
         super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
      }
   }

   public ResourceLocation getTextureLocation(VisualFallingBlockEntity entity) {
      return TextureAtlas.LOCATION_BLOCKS;
   }
}
