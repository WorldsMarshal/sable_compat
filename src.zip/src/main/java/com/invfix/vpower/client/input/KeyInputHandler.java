package com.invfix.vpower.client.input;

import java.util.Locale;
import com.invfix.vpower.VPower;
import com.invfix.vpower.client.GrabClientState;
import com.invfix.vpower.client.animation.AnimationHelper;
import com.invfix.vpower.client.animation.ModAnimations;
import com.invfix.vpower.client.gui.overlay.ChargeBarOverlay;
import com.invfix.vpower.client.lasereye.LaserEyeClientHandler;
import com.invfix.vpower.client.soundwave.SoundWaveChargeFovHandler;
import com.invfix.vpower.client.xrayvision.XRayVisionClientHandler;
import com.invfix.vpower.network.GrabPacket;
import com.invfix.vpower.network.ScaleSetPacket;
import com.invfix.vpower.network.SkillSetActivePacket;
import com.invfix.vpower.network.SkillTogglePacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillConsumptionProfiles;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.SkillRegistry;
import com.invfix.vpower.skill.base.Skill;
import com.invfix.vpower.skill.base.SkillType;
import com.invfix.vpower.skill.skills.EggShellSkill;
import com.invfix.vpower.skill.skills.FireBlastSkill;
import com.invfix.vpower.skill.skills.GrabSkill;
import com.invfix.vpower.skill.skills.LaserEyeSkill;
import com.invfix.vpower.skill.skills.ScaleSkill;
import com.invfix.vpower.skill.skills.SoundWaveAttackSkill;
import com.invfix.vpower.skill.skills.StompSkill;
import com.invfix.vpower.skill.skills.SuperJumpSkill;
import com.invfix.vpower.skill.skills.XRayVisionSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.InputEvent.MouseScrollingEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Ввод навыков V — клавиши способностей Invincible (VSlots): навык берётся из строки слота текущего ряда. Как в The Boys,
 * кроме панели (H), пресетов и шести своих клавиш; нажатия опрашиваются каждый тик (клавиши могут быть и кнопками мыши).
 */
@OnlyIn(Dist.CLIENT)
public class KeyInputHandler {
   private final boolean[] wasKeyDown = new boolean[VSlots.COUNT];
   private static boolean wasFireBlastKeyDown = false;
   private static boolean wasSoundWaveKeyDown = false;
   private static boolean wasSuperJumpKeyDown = false;
   private static int nextLocalStompTick = 0;
   private static boolean soundWaveClientActive = false;
   private static int soundWaveAnimTicks = 0;
   private static boolean soundWaveLooping = false;
   private static final int SOUND_WAVE_START_TICKS = 60;
   private static final int SOUND_WAVE_MAX_CHARGE_TICKS = 100;
   private static boolean superJumpClientActive = false;
   private static int superJumpAnimTicks = 0;
   private static boolean superJumpLooping = false;
   private static int superJumpReleaseAnimTicks = 0;
   private static final int SUPER_JUMP_START_TICKS = 5;
   private static final int SUPER_JUMP_MAX_CHARGE_TICKS = 60;
   private static final int SUPER_JUMP_RELEASE_TICKS = 40;
   private static boolean wasScaleKeyDown = false;
   private static boolean scaleSelecting = false;
   private static float selectedScale = 1.0F;
   private static final float SCALE_SELECT_STEP = 0.1F;
   private static KeyInputHandler instance;

   public static void register() {
      instance = new KeyInputHandler();
      NeoForge.EVENT_BUS.register(instance);
   }

   private KeyInputHandler() {
   }

   /** Клавиши слотов: фронты нажатия и отпускания (как InputEvent.Key в The Boys). */
   private void pollSlotKeys() {
      for (int i = 0; i < VSlots.COUNT; i++) {
         boolean isDown = VSlots.down(i);
         if (isDown != this.wasKeyDown[i]) {
            String skillId = VSlots.skillId(i);
            if (!isPolledChanneledSkill(skillId)) {
               this.handleSkillSlotInput(i, isDown);
            }
            this.wasKeyDown[i] = isDown;
         }
      }
   }

   @SubscribeEvent
   public void onClientTick(Post event) {
      Minecraft mc = Minecraft.getInstance();
      tickSuperJumpReleaseAnimation(mc);
      if (mc.player != null) {
         this.pollSlotKeys();
      }
      if (mc.player != null && !mc.isPaused() && mc.screen == null) {
         if (!ModKeyBindings.ADJUST_DAMAGE.isDown()) {
            pollSoundWaveKey(mc);
            pollSuperJumpKey(mc);
            pollScaleKey(mc);
            String fireBlastId = FireBlastSkill.ID.toString();
            int fireBlastSlot = VSlots.find(fireBlastId);

            if (fireBlastSlot >= 0) {
               boolean isKeyPhysicallyDown = VSlots.down(fireBlastSlot);
               if (isKeyPhysicallyDown != wasFireBlastKeyDown) {
                  wasFireBlastKeyDown = isKeyPhysicallyDown;
                  SkillData skillData = (SkillData)mc.player.getData(ModSkillAttachments.SKILL_DATA.get());
                  if (!skillData.hasSkill(fireBlastId)) {
                     if (isKeyPhysicallyDown) {
                        mc.player.displayClientMessage(Component.translatable("skill.theboysmod.failure.no_skill"), true);
                     }

                     return;
                  }

                  setFireBlastActive(mc, isKeyPhysicallyDown);
               }
            }
         }
      } else {
         if (wasFireBlastKeyDown) {
            setFireBlastActive(mc, false);
            wasFireBlastKeyDown = false;
         }

         if (wasSoundWaveKeyDown) {
            if (soundWaveClientActive) {
               setSoundWaveActive(mc, false);
            }

            wasSoundWaveKeyDown = false;
         }

         if (wasSuperJumpKeyDown) {
            if (superJumpClientActive) {
               setSuperJumpActive(mc, false);
            }

            wasSuperJumpKeyDown = false;
         }

         if (wasScaleKeyDown || scaleSelecting) {
            cancelScaleSelection(mc);
            wasScaleKeyDown = false;
         }
      }
   }

   private static boolean isPolledChanneledSkill(String skillId) {
      return skillId != null
         && (
            skillId.equals(FireBlastSkill.ID.toString())
               || skillId.equals(SoundWaveAttackSkill.ID.toString())
               || skillId.equals(SuperJumpSkill.ID.toString())
               || skillId.equals(ScaleSkill.ID.toString())
         );
   }

   private static void pollSoundWaveKey(Minecraft mc) {
      String soundWaveId = SoundWaveAttackSkill.ID.toString();
      int soundWaveSlot = findSkillSlot(soundWaveId);
      if (soundWaveSlot < 0) {
         if (soundWaveClientActive) {
            setSoundWaveActive(mc, false);
         }

         wasSoundWaveKeyDown = false;
      } else {
         boolean isKeyPhysicallyDown = isSkillSlotKeyPhysicallyDown(mc, soundWaveSlot);
         SkillData skillData = (SkillData)mc.player.getData(ModSkillAttachments.SKILL_DATA.get());
         if (soundWaveClientActive && !skillData.isSkillActive(soundWaveId)) {
            setSoundWaveActive(mc, false);
            wasSoundWaveKeyDown = isKeyPhysicallyDown;
         } else {
            if (isKeyPhysicallyDown != wasSoundWaveKeyDown) {
               wasSoundWaveKeyDown = isKeyPhysicallyDown;
               if (!skillData.hasSkill(soundWaveId)) {
                  if (isKeyPhysicallyDown) {
                     mc.player.displayClientMessage(Component.translatable("skill.theboysmod.failure.no_skill"), true);
                  }

                  return;
               }

               if (!isKeyPhysicallyDown && !soundWaveClientActive) {
                  return;
               }

               if (isKeyPhysicallyDown && !SkillConsumptionProfiles.canCurrentlySustain(mc.player, SkillConsumptionProfiles.SOUND_WAVE_ATTACK)) {
                  mc.player.displayClientMessage(Component.translatable("skill.theboysmod.failure.low_food"), true);
                  return;
               }

               setSoundWaveActive(mc, isKeyPhysicallyDown);
            }

            if (soundWaveClientActive && wasSoundWaveKeyDown) {
               tickSoundWaveAnimation(mc);
            }
         }
      }
   }

   private static int findSkillSlot(String skillId) {
      return VSlots.find(skillId);
   }

   private static boolean isSkillSlotKeyPhysicallyDown(Minecraft mc, int slot) {
      return VSlots.down(slot);
   }

   private static void tickSoundWaveAnimation(Minecraft mc) {
      soundWaveAnimTicks++;
      if (!soundWaveLooping && soundWaveAnimTicks >= 60) {
         soundWaveLooping = true;
         AnimationHelper.playAnimationWithFade(mc.player, ModAnimations.SOUND_WAVES_ON, 2, true, true);
      }

      float chargeProgress = (float)soundWaveAnimTicks / 100.0F;
      ChargeBarOverlay.showHeld(chargeProgress, -1);
      SoundWaveChargeFovHandler.setChargeProgress(chargeProgress);
   }

   private static void pollSuperJumpKey(Minecraft mc) {
      String superJumpId = SuperJumpSkill.ID.toString();
      int superJumpSlot = findSkillSlot(superJumpId);
      if (superJumpSlot < 0) {
         if (superJumpClientActive) {
            setSuperJumpActive(mc, false);
         }

         wasSuperJumpKeyDown = false;
      } else {
         boolean isKeyPhysicallyDown = isSkillSlotKeyPhysicallyDown(mc, superJumpSlot);
         SkillData skillData = (SkillData)mc.player.getData(ModSkillAttachments.SKILL_DATA.get());
         if (superJumpClientActive && !skillData.isSkillActive(superJumpId)) {
            setSuperJumpActive(mc, false);
            wasSuperJumpKeyDown = isKeyPhysicallyDown;
         } else {
            if (isKeyPhysicallyDown != wasSuperJumpKeyDown) {
               wasSuperJumpKeyDown = isKeyPhysicallyDown;
               if (!skillData.hasSkill(superJumpId)) {
                  if (isKeyPhysicallyDown) {
                     mc.player.displayClientMessage(Component.translatable("skill.theboysmod.failure.no_skill"), true);
                  }

                  return;
               }

               if (!isKeyPhysicallyDown && !superJumpClientActive) {
                  return;
               }

               if (isKeyPhysicallyDown && !mc.player.onGround()) {
                  mc.player.displayClientMessage(Component.translatable("skill.theboysmod.failure.must_be_grounded"), true);
                  return;
               }

               if (isKeyPhysicallyDown && !SkillConsumptionProfiles.canCurrentlySustain(mc.player, SkillConsumptionProfiles.SUPER_JUMP)) {
                  mc.player.displayClientMessage(Component.translatable("skill.theboysmod.failure.low_food"), true);
                  return;
               }

               setSuperJumpActive(mc, isKeyPhysicallyDown);
            }

            if (superJumpClientActive && wasSuperJumpKeyDown) {
               tickSuperJumpAnimation(mc);
            }
         }
      }
   }

   private static void pollScaleKey(Minecraft mc) {
      String scaleId = ScaleSkill.ID.toString();
      int scaleSlot = findSkillSlot(scaleId);
      if (scaleSlot < 0) {
         if (scaleSelecting) {
            cancelScaleSelection(mc);
         }

         wasScaleKeyDown = false;
      } else {
         boolean isKeyPhysicallyDown = isSkillSlotKeyPhysicallyDown(mc, scaleSlot);
         SkillData skillData = (SkillData)mc.player.getData(ModSkillAttachments.SKILL_DATA.get());
         if (isKeyPhysicallyDown != wasScaleKeyDown) {
            wasScaleKeyDown = isKeyPhysicallyDown;
            if (!skillData.hasSkill(scaleId)) {
               if (isKeyPhysicallyDown) {
                  mc.player.displayClientMessage(Component.translatable("skill.theboysmod.failure.no_skill"), true);
               }
            } else {
               if (isKeyPhysicallyDown) {
                  beginScaleSelection(mc, skillData, scaleId);
               } else {
                  finishScaleSelection(mc, skillData, scaleId);
               }
            }
         }
      }
   }

   private static void beginScaleSelection(Minecraft mc, SkillData skillData, String scaleId) {
      selectedScale = roundScale(skillData.getTargetScale());
      scaleSelecting = true;
      skillData.setSkillActive(scaleId, true);
      PacketDistributor.sendToServer(new SkillSetActivePacket(scaleId, true), new CustomPacketPayload[0]);
      showScaleSelection(mc);
   }

   private static void finishScaleSelection(Minecraft mc, SkillData skillData, String scaleId) {
      if (scaleSelecting) {
         scaleSelecting = false;
         skillData.setSkillActive(scaleId, false);
         skillData.setTargetScale(selectedScale);
         PacketDistributor.sendToServer(new ScaleSetPacket(selectedScale), new CustomPacketPayload[0]);
         showScaleSelection(mc);
      }
   }

   private static void cancelScaleSelection(Minecraft mc) {
      if (mc.player == null) {
         scaleSelecting = false;
      } else {
         String scaleId = ScaleSkill.ID.toString();
         SkillData skillData = (SkillData)mc.player.getData(ModSkillAttachments.SKILL_DATA.get());
         scaleSelecting = false;
         skillData.setSkillActive(scaleId, false);
         PacketDistributor.sendToServer(new SkillSetActivePacket(scaleId, false), new CustomPacketPayload[0]);
      }
   }

   private static void adjustSelectedScale(Minecraft mc, double scrollY) {
      float delta = scrollY > 0.0 ? 0.1F : -0.1F;
      selectedScale = roundScale(selectedScale + delta);
      showScaleSelection(mc);
   }

   private static float roundScale(float scale) {
      float rounded = (float)Math.round(scale / 0.1F) * 0.1F;
      return SkillData.clampPlayerScale(rounded);
   }

   private static void showScaleSelection(Minecraft mc) {
      if (mc.player != null) {
         mc.player
            .displayClientMessage(
               Component.translatable("skill.theboysmod.scale.select", new Object[]{String.format(Locale.ROOT, "%.1f", selectedScale)}), true
            );
      }
   }

   private static void tickSuperJumpAnimation(Minecraft mc) {
      superJumpAnimTicks++;
      if (!superJumpLooping && superJumpAnimTicks >= 5) {
         superJumpLooping = true;
         AnimationHelper.playAnimationWithFade(mc.player, ModAnimations.SUPER_JUMP_ON, 2, true, true);
      }

      float chargeProgress = (float)superJumpAnimTicks / 60.0F;
      ChargeBarOverlay.showHeld(chargeProgress, -11151105);
   }

   private static void setSuperJumpActive(Minecraft mc, boolean active) {
      String superJumpId = SuperJumpSkill.ID.toString();
      if (mc.player != null) {
         SkillData skillData = (SkillData)mc.player.getData(ModSkillAttachments.SKILL_DATA.get());
         boolean wasActive = superJumpClientActive;
         skillData.setSkillActive(superJumpId, active);
         superJumpClientActive = active;
         PacketDistributor.sendToServer(new SkillSetActivePacket(superJumpId, active), new CustomPacketPayload[0]);
         superJumpAnimTicks = 0;
         superJumpLooping = false;
         if (active) {
            superJumpReleaseAnimTicks = 0;
            ChargeBarOverlay.showHeld(0.0F, -11151105);
            AnimationHelper.playAnimationWithFade(mc.player, ModAnimations.SUPER_JUMP_START, 2, false, true);
         } else {
            ChargeBarOverlay.clearHeld();
            if (wasActive) {
               superJumpReleaseAnimTicks = 40;
               AnimationHelper.playAnimationWithFade(mc.player, ModAnimations.SUPER_JUMP_UP, 2, true, true);
            }
         }
      }
   }

   private static void tickSuperJumpReleaseAnimation(Minecraft mc) {
      if (mc.player != null && superJumpReleaseAnimTicks > 0) {
         superJumpReleaseAnimTicks--;
         if (superJumpReleaseAnimTicks == 0 && "super_jump.up".equals(AnimationHelper.getCurrentAnimation(mc.player))) {
            AnimationHelper.stopAnimation(mc.player, 2);
         }
      }
   }

   private static void setSoundWaveActive(Minecraft mc, boolean active) {
      String soundWaveId = SoundWaveAttackSkill.ID.toString();
      if (mc.player != null) {
         SkillData skillData = (SkillData)mc.player.getData(ModSkillAttachments.SKILL_DATA.get());
         skillData.setSkillActive(soundWaveId, active);
         soundWaveClientActive = active;
         PacketDistributor.sendToServer(new SkillSetActivePacket(soundWaveId, active), new CustomPacketPayload[0]);
         soundWaveAnimTicks = 0;
         soundWaveLooping = false;
         if (!active) {
            ChargeBarOverlay.clearHeld();
            SoundWaveChargeFovHandler.stopCharging();
         }

         if (active) {
            SoundWaveChargeFovHandler.setChargeProgress(0.0F);
            AnimationHelper.playAnimationWithFade(mc.player, ModAnimations.SOUND_WAVES_START, 2, false, true);
         } else {
            AnimationHelper.playAnimationWithFade(mc.player, ModAnimations.SOUND_WAVES_UP, 2, false, true);
         }
      }
   }

   private static void setFireBlastActive(Minecraft mc, boolean active) {
      String fireBlastId = FireBlastSkill.ID.toString();
      if (mc.player != null) {
         SkillData skillData = (SkillData)mc.player.getData(ModSkillAttachments.SKILL_DATA.get());
         skillData.setSkillActive(fireBlastId, active);
         PacketDistributor.sendToServer(new SkillSetActivePacket(fireBlastId, active), new CustomPacketPayload[0]);
         if (active) {
            AnimationHelper.playAnimationWithFade(mc.player, ModAnimations.ZHANG_XIN_LEI_FP, 1, true, true);
         } else {
            AnimationHelper.stopAnimation(mc.player, 2);
         }
      }
   }

   @SubscribeEvent
   public void onMouseScroll(MouseScrollingEvent event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null && mc.screen == null) {
         double scrollY = event.getScrollDeltaY();
         if (scrollY != 0.0) {
            if (scaleSelecting) {
               adjustSelectedScale(mc, scrollY);
               event.setCanceled(true);
            }
         }
      }
   }

   private void handleSkillSlotInput(int slotIndex, boolean isDown) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null && mc.screen == null) {
         if (!ModKeyBindings.ADJUST_DAMAGE.isDown()) {
            if (isDown) {
               VPower.LOGGER.debug("[SkillInput] Slot {} pressed", slotIndex);
            }

            String skillId = VSlots.skillId(slotIndex);
            if (skillId != null && !skillId.isEmpty()) {
               if (isDown) {
                  VPower.LOGGER.debug("[SkillInput] Slot {} has skill: {}", slotIndex, skillId);
               }

               Skill skill = SkillRegistry.getSkill(skillId);
               if (skill != null) {
                  SkillData skillData = (SkillData)mc.player.getData(ModSkillAttachments.SKILL_DATA.get());
                  if (!skillData.hasSkill(skillId)) {
                     if (isDown) {
                        mc.player.displayClientMessage(Component.translatable("skill.theboysmod.failure.no_skill"), true);
                     }
                  } else if (skill.getType() == SkillType.CHANNELED) {
                     if (skillId.equals(XRayVisionSkill.ID.toString())) {
                        XRayVisionClientHandler.setActive(isDown);
                        skillData.setSkillActive(skillId, isDown);
                     } else {
                        if (skillId.equals(LaserEyeSkill.ID.toString())) {
                           LaserEyeClientHandler.setClientHeld(isDown);
                           skillData.setSkillActive(skillId, isDown);
                        }

                        if (skillId.equals(GrabSkill.ID.toString())) {
                           skillData.setSkillActive(skillId, isDown);
                           if (isDown) {
                              PacketDistributor.sendToServer(new GrabPacket(GrabPacket.Action.GRAB), new CustomPacketPayload[0]);
                           } else {
                              PacketDistributor.sendToServer(new GrabPacket(GrabPacket.Action.RELEASE), new CustomPacketPayload[0]);
                              GrabClientState.clearGrabbing(Minecraft.getInstance().player.getId());
                           }
                        } else {
                           skillData.setSkillActive(skillId, isDown);
                           PacketDistributor.sendToServer(new SkillSetActivePacket(skillId, isDown), new CustomPacketPayload[0]);
                        }
                     }
                  } else {
                     if (isDown) {
                        if (skillId.equals(EggShellSkill.ID.toString())) {
                           boolean newState = !skillData.isSkillActive(skillId);
                           skillData.setSkillActive(skillId, newState);
                           PacketDistributor.sendToServer(new SkillSetActivePacket(skillId, newState), new CustomPacketPayload[0]);
                           return;
                        }

                        if (skillId.equals(StompSkill.ID.toString())
                           && mc.player.onGround()
                           && !mc.player.isInWater()
                           && !mc.player.isInLava()
                           && mc.player.tickCount >= nextLocalStompTick) {
                           nextLocalStompTick = mc.player.tickCount + 26;
                           AnimationHelper.playAnimationWithFade(mc.player, ModAnimations.STOMP, 1, false, true);
                        }

                        PacketDistributor.sendToServer(new SkillTogglePacket(slotIndex, skillId), new CustomPacketPayload[0]);
                     }
                  }
               }
            }
         }
      }
   }

   public static KeyInputHandler getInstance() {
      return instance;
   }
}
