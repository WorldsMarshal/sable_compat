package com.invfix.vpower.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.NotNull;

public class BloodParticle extends TextureSheetParticle {
   private final SpriteSet sprites;

   protected BloodParticle(ClientLevel level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, SpriteSet sprites) {
      super(level, x, y, z, xSpeed, ySpeed, zSpeed);
      this.sprites = sprites;
      this.gravity = 0.38F + this.random.nextFloat() * 0.1F;
      this.friction = 0.92F;
      this.quadSize = 0.3F + this.random.nextFloat() * 0.22F;
      this.lifetime = 16 + this.random.nextInt(8);
      this.hasPhysics = true;
      this.alpha = 0.95F;
      this.xd = xSpeed;
      this.yd = ySpeed;
      this.zd = zSpeed;
      this.setSpriteFromAge(this.sprites);
   }

   public void tick() {
      super.tick();
      if (!this.removed) {
         this.alpha = Mth.lerp((float)this.age / (float)this.lifetime, 0.98F, 0.28F);
         this.setSpriteFromAge(this.sprites);
         if (this.onGround) {
            this.xd *= 0.7;
            this.zd *= 0.7;
         }
      }
   }

   @NotNull
   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   public static class Provider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public Provider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      public Particle createParticle(
         @NotNull SimpleParticleType type, @NotNull ClientLevel level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed
      ) {
         return new BloodParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, this.sprites);
      }
   }
}
