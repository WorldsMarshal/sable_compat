package com.invfix.vpower.client.xrayvision;

import javax.annotation.Nullable;
import com.invfix.vpower.VPower;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.resources.ResourceLocation;

public class XRayVisionShader {
   @Nullable
   private PostChain postChain;
   @Nullable
   private PostPass blit0;
   @Nullable
   private PostPass blur1;
   @Nullable
   private PostPass blur2;
   private int displayWidth;
   private int displayHeight;
   private int tick = 0;
   private int prevTick = 0;
   private static final int MAX_TICKS = 10;

   public void remake(Minecraft mc) {
      this.close();

      try {
         ResourceLocation loc = ResourceLocation.withDefaultNamespace("shaders/post/entity_outline.json");
         this.postChain = new PostChain(mc.getTextureManager(), mc.getResourceManager(), mc.getMainRenderTarget(), loc);
         this.postChain.close();
         this.postChain = null;
      } catch (Exception var3) {
         VPower.LOGGER.warn("Failed to create X-Ray vision shader", var3);
         this.postChain = null;
      }
   }

   public void tick(boolean active) {
      this.prevTick = this.tick;
      if (active) {
         if (this.tick < 10) {
            this.tick++;
         }
      } else {
         if (this.tick > 0) {
            this.tick -= 2;
         }

         if (this.tick < 0) {
            this.tick = 0;
         }
      }
   }

   public float getProgress(float partialTick) {
      return ((float)this.tick + (float)(this.tick - this.prevTick) * partialTick) / 10.0F;
   }

   public boolean isActive() {
      return this.tick > 0;
   }

   public void resetTicks() {
      this.prevTick = this.tick = 0;
   }

   public void close() {
      if (this.postChain != null) {
         this.postChain.close();
         this.postChain = null;
      }
   }
}
