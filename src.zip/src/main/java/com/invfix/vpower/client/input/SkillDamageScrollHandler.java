package com.invfix.vpower.client.input;

import com.invfix.vpower.client.gui.overlay.ChargeBarOverlay;
import com.invfix.vpower.network.SkillDamageAdjustPacket;
import com.invfix.vpower.network.SpeedAdjustPacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.SpeedSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.InputEvent.MouseScrollingEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public class SkillDamageScrollHandler {
   private static final int STEP = 5;
   private static final int MIN = 0;
   private static final int MAX = 100;

   @SubscribeEvent
   public static void onMouseScroll(MouseScrollingEvent event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null && mc.screen == null) {
         if (ModKeyBindings.ADJUST_DAMAGE.isDown()) {
            double scrollY = event.getScrollDeltaY();
            if (scrollY != 0.0) {
               int delta = scrollY > 0.0 ? 5 : -5;
               SkillData data = (SkillData)mc.player.getData(ModSkillAttachments.SKILL_DATA.get());
               // без навыков V колесо с этой клавишей не трогаем
               if (data.getAllSkills().isEmpty()) return;
               String targetSkillId = null;

               for (int i = 0; i < VSlots.COUNT; i++) {
                  if (VSlots.down(i)) {
                     String slotSkillId = VSlots.skillId(i);
                     if (slotSkillId != null && !slotSkillId.isEmpty()) {
                        targetSkillId = slotSkillId;
                     }
                     break;
                  }
               }

               if (targetSkillId != null) {
                  if (targetSkillId.equals(SpeedSkill.ID.toString())) {
                     int current = data.getSpeedAdjustment();
                     int newVal = Math.max(0, Math.min(100, current + delta));
                     if (newVal != current) {
                        data.setSpeedAdjustment(newVal);
                        PacketDistributor.sendToServer(new SpeedAdjustPacket(newVal), new CustomPacketPayload[0]);
                     }

                     showHud(newVal);
                  } else {
                     int current = data.getDamageMultiplier(targetSkillId);
                     int newVal = Math.max(0, Math.min(100, current + delta));
                     if (newVal != current) {
                        data.setDamageMultiplier(targetSkillId, newVal);
                        PacketDistributor.sendToServer(new SkillDamageAdjustPacket(targetSkillId, newVal), new CustomPacketPayload[0]);
                     }

                     showHud(newVal);
                  }
               } else {
                  int current = data.getMeleeDamageMultiplier();
                  int newVal = Math.max(0, Math.min(100, current + delta));
                  if (newVal != current) {
                     data.setMeleeDamageMultiplier(newVal);
                     PacketDistributor.sendToServer(new SkillDamageAdjustPacket("", newVal), new CustomPacketPayload[0]);
                  }

                  showHud(newVal);
               }

               event.setCanceled(true);
            }
         }
      }
   }

   private static void showHud(int percentage) {
      ChargeBarOverlay.showTimed((float)percentage / 100.0F, -1);
   }
}
