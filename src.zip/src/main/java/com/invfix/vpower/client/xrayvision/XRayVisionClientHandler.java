package com.invfix.vpower.client.xrayvision;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.XRayVisionSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class XRayVisionClientHandler {
   private static boolean active = false;
   private static final double MAX_RANGE = 100.0;
   private static final double MAX_Y_DIFF = 18.0;
   private static final int GLOW_COLOR = 16777215;

   public static void setActive(boolean value) {
      active = value;
   }

   public static boolean isActive() {
      if (!active) {
         return false;
      } else {
         Minecraft mc = Minecraft.getInstance();
         if (mc.player == null) {
            active = false;
            return false;
         } else {
            return hasXRaySkill(mc.player);
         }
      }
   }

   public static boolean shouldEntityGlow(Entity entity) {
      if (!isActive()) {
         return false;
      } else {
         Minecraft mc = Minecraft.getInstance();
         if (mc.player != null && entity != null && entity != mc.player && !entity.isRemoved()) {
            double dynamicRange = getCurrentRange(mc);
            double maxYDiff = 18.0 * (dynamicRange / 100.0);
            double dx = entity.getX() - mc.player.getX();
            double dy = entity.getY() - mc.player.getY();
            double dz = entity.getZ() - mc.player.getZ();
            return Math.abs(dy) > maxYDiff ? false : dx * dx + dz * dz <= dynamicRange * dynamicRange;
         } else {
            return false;
         }
      }
   }

   public static double getCurrentRange() {
      return getCurrentRange(Minecraft.getInstance());
   }

   public static double getCurrentRange(Minecraft mc) {
      if (mc != null && mc.player != null) {
         try {
            SkillData data = (SkillData)mc.player.getData(ModSkillAttachments.SKILL_DATA.get());
            int pct = data.getDamageMultiplier(XRayVisionSkill.ID.toString());
            return 100.0 * (double)pct / 100.0;
         } catch (Exception var3) {
            return 100.0;
         }
      } else {
         return 100.0;
      }
   }

   public static int getGlowColor() {
      return 16777215;
   }

   public static double getMaxRange() {
      return 100.0;
   }

   private static boolean hasXRaySkill(LocalPlayer player) {
      try {
         SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         return skillData.hasSkill(XRayVisionSkill.ID.toString());
      } catch (Exception var2) {
         return false;
      }
   }
}
