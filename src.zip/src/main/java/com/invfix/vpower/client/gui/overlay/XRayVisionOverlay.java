package com.invfix.vpower.client.gui.overlay;

import com.invfix.vpower.client.xrayvision.XRayVisionClientHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw.Layer;
import net.minecraft.client.player.LocalPlayer;

public final class XRayVisionOverlay {
   private static final int FILTER_COLOR = 1429681975;
   public static final Layer HUD_XRAY_VISION_FILTER = (guiGraphics, deltaTracker) -> {
      Minecraft minecraft = Minecraft.getInstance();
      LocalPlayer player = minecraft.player;
      if (player != null && !player.isSpectator() && XRayVisionClientHandler.isActive()) {
         renderFilter(guiGraphics, guiGraphics.guiWidth(), guiGraphics.guiHeight());
      }
   };

   private XRayVisionOverlay() {
   }

   private static void renderFilter(GuiGraphics graphics, int width, int height) {
      graphics.fill(0, 0, width, height, 1429681975);
   }
}
