package com.invfix.vpower.client.renderer.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Optional;
import com.invfix.vpower.client.claw.ClawClientHandler;
import com.invfix.vpower.client.claw.ClawGeoModel;
import com.invfix.vpower.client.claw.ClawState;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import software.bernie.geckolib.animation.state.BoneSnapshot;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoObjectRenderer;

public class DiamondClawsLayer<T extends LivingEntity, M extends HumanoidModel<T>> extends RenderLayer<T, M> {
   private final DiamondClawsLayer.ClawRenderer<T, M> renderer = new DiamondClawsLayer.ClawRenderer<>();

   public DiamondClawsLayer(RenderLayerParent<T, M> parent) {
      super(parent);
   }

   public void render(
      PoseStack poseStack,
      MultiBufferSource bufferSource,
      int packedLight,
      T entity,
      float limbSwing,
      float limbSwingAmount,
      float partialTick,
      float ageInTicks,
      float netHeadYaw,
      float headPitch
   ) {
      if (ClawClientHandler.shouldRender(entity)) {
         this.renderer.setContext(entity, (M)this.getParentModel(), partialTick);
         this.renderer.renderOnPlayer(poseStack, bufferSource, packedLight, partialTick);
      }
   }

   private static final class ClawRenderer<T extends LivingEntity, M extends HumanoidModel<T>> extends GeoObjectRenderer<ClawState> {
      private static final ClawState INSTANCE = new ClawState();
      private static final float MODEL_Y_OFFSET = -1.5F;
      private static final float ARM_POS_X_OFFSET = 5.0F;
      private static final float ARM_POS_Y_OFFSET = 2.0F;
      private final ClawGeoModel clawModel = (ClawGeoModel)this.model;
      private T entity;
      private M entityModel;
      private float partialTick;

      private ClawRenderer() {
         super(new ClawGeoModel());
      }

      private void setContext(T entity, M entityModel, float partialTick) {
         this.entity = entity;
         this.entityModel = entityModel;
         this.partialTick = partialTick;
         this.clawModel.setSlim(ClawClientHandler.isSlim(entity));
      }

      private void renderOnPlayer(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick) {
         RenderType renderType = RenderType.entityTranslucent(ClawGeoModel.TEXTURE);
         this.render(poseStack, INSTANCE, bufferSource, renderType, null, packedLight, partialTick);
      }

      public void preRender(
         PoseStack poseStack,
         ClawState animatable,
         BakedGeoModel model,
         @Nullable MultiBufferSource bufferSource,
         @Nullable VertexConsumer buffer,
         boolean isReRender,
         float partialTick,
         int packedLight,
         int packedOverlay,
         int colour
      ) {
         this.objectRenderTranslations = new Matrix4f(poseStack.last().pose());
         this.syncPlayerBones(model);
      }

      public void actuallyRender(
         PoseStack poseStack,
         ClawState animatable,
         BakedGeoModel model,
         @Nullable RenderType renderType,
         MultiBufferSource bufferSource,
         @Nullable VertexConsumer buffer,
         boolean isReRender,
         float partialTick,
         int packedLight,
         int packedOverlay,
         int colour
      ) {
         poseStack.pushPose();
         poseStack.scale(-1.0F, -1.0F, 1.0F);
         poseStack.translate(0.0F, -1.5F, 0.0F);
         poseStack.translate(0.0F, 0.01F, 0.0F);
         this.modelRenderTranslations = new Matrix4f(poseStack.last().pose());

         for (GeoBone bone : model.topLevelBones()) {
            this.renderRecursively(poseStack, animatable, bone, renderType, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, colour);
         }

         poseStack.popPose();
      }

      private void syncPlayerBones(BakedGeoModel model) {
         if (this.entity != null && this.entityModel != null) {
            this.syncArmBone(model, this.entityModel.rightArm, "right_arm", HumanoidArm.RIGHT);
            this.syncArmBone(model, this.entityModel.leftArm, "left_arm", HumanoidArm.LEFT);
            float progress = ClawClientHandler.getExtensionProgress(this.entity, this.partialTick);
            applyClawOffset(model, "claws", 1.0F - progress);
            applyClawOffset(model, "claws2", progress - 1.0F);
         }
      }

      private void syncArmBone(BakedGeoModel model, ModelPart part, String boneName, HumanoidArm arm) {
         Optional<GeoBone> optionalBone = model.getBone(boneName);
         if (!optionalBone.isEmpty()) {
            GeoBone bone = optionalBone.get();
            boolean usableHand = ClawClientHandler.hasUsableHand(this.entity, arm);
            resetBone(bone);
            bone.setHidden(true);
            bone.setChildrenHidden(!usableHand);
            if (usableHand && part != null) {
               float x = part.x;
               float y = -part.y + 2.0F;
               float z = part.z;
               if (arm == HumanoidArm.RIGHT) {
                  x += 5.0F;
               } else {
                  x -= 5.0F;
               }

               bone.setPosX(x);
               bone.setPosY(y);
               bone.setPosZ(z);
               bone.setRotX(-part.xRot);
               bone.setRotY(-part.yRot);
               bone.setRotZ(part.zRot);
               bone.setScaleX(part.xScale);
               bone.setScaleY(part.yScale);
               bone.setScaleZ(part.zScale);
            }
         }
      }

      private static void applyClawOffset(BakedGeoModel model, String boneName, float xOffset) {
         Optional<GeoBone> optionalBone = model.getBone(boneName);
         if (!optionalBone.isEmpty()) {
            GeoBone bone = optionalBone.get();
            resetBone(bone);
            bone.setHidden(false);
            bone.setChildrenHidden(false);
            bone.setPosX(bone.getPosX() + xOffset);
            bone.setPosY(bone.getPosY() + Math.abs(xOffset) * 6.0F);
         }
      }

      private static void resetBone(GeoBone bone) {
         BoneSnapshot snapshot = bone.getInitialSnapshot();
         bone.setPosX(0.0F);
         bone.setPosY(0.0F);
         bone.setPosZ(0.0F);
         bone.setRotX(snapshot.getRotX());
         bone.setRotY(snapshot.getRotY());
         bone.setRotZ(snapshot.getRotZ());
         bone.setScaleX(snapshot.getScaleX());
         bone.setScaleY(snapshot.getScaleY());
         bone.setScaleZ(snapshot.getScaleZ());
         bone.setHidden(false);
         bone.setChildrenHidden(false);
      }
   }
}
