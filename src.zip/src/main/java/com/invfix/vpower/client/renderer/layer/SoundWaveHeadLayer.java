package com.invfix.vpower.client.renderer.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.client.ClientSkillStateCache;
import com.invfix.vpower.client.invisibility.InvisibilityRenderHelper;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.SoundWaveAttackSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;

public class SoundWaveHeadLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
   private static final String SOUND_WAVE_ATTACK_ID = SoundWaveAttackSkill.ID.toString();
   private static final int HEAD_RED_RGB = 16724016;
   private static final int MAX_ALPHA = 208;
   private static final int FADE_IN_TICKS = 12;
   private static final int FADE_OUT_TICKS = 20;
   private static final Map<Integer, SoundWaveHeadLayer.FadeState> FADE_STATES = new ConcurrentHashMap<>();
   private final PlayerModel<AbstractClientPlayer> headModel;

   public SoundWaveHeadLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> renderer, PlayerModel<AbstractClientPlayer> headModel) {
      super(renderer);
      this.headModel = headModel;
   }

   public void render(
      PoseStack poseStack,
      MultiBufferSource bufferSource,
      int packedLight,
      AbstractClientPlayer player,
      float limbSwing,
      float limbSwingAmount,
      float partialTick,
      float ageInTicks,
      float netHeadYaw,
      float headPitch
   ) {
      if (!player.isSpectator() && !player.isInvisible() && !InvisibilityRenderHelper.shouldHideBody(player)) {
         boolean active = isSoundWaveActive(player);
         float intensity = updateAndGetIntensity(player, active);
         if (!(intensity <= 0.0F)) {
            PlayerModel<AbstractClientPlayer> parentModel = (PlayerModel<AbstractClientPlayer>)this.getParentModel();
            this.syncHeadModel(parentModel);
            VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityTranslucent(player.getSkin().texture()));
            int color = toRedOverlayColor(intensity);
            poseStack.pushPose();
            this.headModel.renderToBuffer(poseStack, vertexConsumer, 15728880, OverlayTexture.NO_OVERLAY, color);
            poseStack.popPose();
         }
      } else {
         FADE_STATES.remove(player.getId());
      }
   }

   private static float updateAndGetIntensity(AbstractClientPlayer player, boolean active) {
      int entityId = player.getId();
      long gameTime = player.level().getGameTime();
      SoundWaveHeadLayer.FadeState state = FADE_STATES.get(entityId);
      if (state == null) {
         if (!active) {
            return 0.0F;
         }

         state = new SoundWaveHeadLayer.FadeState(gameTime - 1L);
         FADE_STATES.put(entityId, state);
      }

      long elapsed = Math.max(0L, Math.min(5L, gameTime - state.lastGameTime));

      for (long i = 0L; i < elapsed; i++) {
         if (active) {
            state.intensity = Math.min(1.0F, state.intensity + 0.083333336F);
         } else {
            state.intensity = Math.max(0.0F, state.intensity - 0.05F);
         }
      }

      state.lastGameTime = gameTime;
      if (!active && state.intensity <= 0.0F) {
         FADE_STATES.remove(entityId);
         return 0.0F;
      } else {
         return state.intensity;
      }
   }

   private static int toRedOverlayColor(float intensity) {
      int alpha = Math.max(0, Math.min(208, Math.round(208.0F * intensity)));
      return alpha << 24 | 16724016;
   }

   private void syncHeadModel(PlayerModel<AbstractClientPlayer> parentModel) {
      this.headModel.young = parentModel.young;
      this.headModel.crouching = parentModel.crouching;
      this.headModel.riding = parentModel.riding;
      this.setAllVisible(false);
      this.headModel.head.visible = parentModel.head.visible;
      this.headModel.hat.visible = parentModel.hat.visible;
      copyModelPart(parentModel.head, this.headModel.head);
      copyModelPart(parentModel.hat, this.headModel.hat);
   }

   private void setAllVisible(boolean visible) {
      this.headModel.head.visible = visible;
      this.headModel.hat.visible = visible;
      this.headModel.body.visible = visible;
      this.headModel.jacket.visible = visible;
      this.headModel.rightArm.visible = visible;
      this.headModel.rightSleeve.visible = visible;
      this.headModel.leftArm.visible = visible;
      this.headModel.leftSleeve.visible = visible;
      this.headModel.rightLeg.visible = visible;
      this.headModel.rightPants.visible = visible;
      this.headModel.leftLeg.visible = visible;
      this.headModel.leftPants.visible = visible;
   }

   private static void copyModelPart(ModelPart src, ModelPart dst) {
      dst.xRot = src.xRot;
      dst.yRot = src.yRot;
      dst.zRot = src.zRot;
      dst.x = src.x;
      dst.y = src.y;
      dst.z = src.z;
      dst.xScale = src.xScale;
      dst.yScale = src.yScale;
      dst.zScale = src.zScale;
   }

   private static boolean isSoundWaveActive(AbstractClientPlayer player) {
      try {
         Minecraft minecraft = Minecraft.getInstance();
         if (minecraft.player != null && minecraft.player.getId() == player.getId()) {
            SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            return skillData.hasSkill(SOUND_WAVE_ATTACK_ID) && skillData.isSkillActive(SOUND_WAVE_ATTACK_ID);
         } else {
            return ClientSkillStateCache.isSkillActive(player.getId(), SOUND_WAVE_ATTACK_ID);
         }
      } catch (Exception var3) {
         return false;
      }
   }

   private static class FadeState {
      private long lastGameTime;
      private float intensity;

      private FadeState(long lastGameTime) {
         this.lastGameTime = lastGameTime;
         this.intensity = 0.0F;
      }
   }
}
