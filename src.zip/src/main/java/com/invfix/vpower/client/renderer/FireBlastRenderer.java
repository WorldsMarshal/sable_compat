package com.invfix.vpower.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import java.util.List;
import com.invfix.vpower.entity.projectile.FireBlastProjectile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.joml.Matrix4f;
import org.joml.Vector3f;

@OnlyIn(Dist.CLIENT)
public class FireBlastRenderer extends EntityRenderer<FireBlastProjectile> {
   private static final ResourceLocation SOLID = ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/entity/fire_blast/solid.png");

   public FireBlastRenderer(Context context) {
      super(context);
   }

   public void render(FireBlastProjectile entity, float yaw, float partialTicks, PoseStack poseStack, MultiBufferSource bufferSource, int light) {
      if (entity.getOwner() != null) {
         poseStack.pushPose();
         Entity owner = entity.getOwner();
         boolean handPositioned = false;
         if (owner instanceof AbstractClientPlayer player
            && Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(player) instanceof PlayerRenderer playerRenderer) {
            PlayerModel<AbstractClientPlayer> model = (PlayerModel<AbstractClientPlayer>)playerRenderer.getModel();
            PoseStack bonePose = new PoseStack();
            float bodyYaw = Mth.rotLerp(partialTicks, player.yBodyRotO, player.yBodyRot);
            bonePose.mulPose(Axis.YP.rotationDegrees(180.0F - bodyYaw));
            bonePose.scale(-1.0F, -1.0F, 1.0F);
            bonePose.scale(0.9375F, 0.9375F, 0.9375F);
            bonePose.translate(0.0F, -1.501F, 0.0F);
            model.body.translateAndRotate(bonePose);
            model.rightArm.translateAndRotate(bonePose);
            bonePose.translate(0.0625F, 0.625F, 0.0F);
            Vector3f handLocal = bonePose.last().pose().transformPosition(new Vector3f(0.0F, 0.0F, 0.0F));
            Vec3 playerPos = player.getPosition(partialTicks);
            Vec3 entityPos = entity.getPosition(partialTicks);
            poseStack.translate(
               playerPos.x - entityPos.x + (double)handLocal.x(),
               playerPos.y - entityPos.y + (double)handLocal.y(),
               playerPos.z - entityPos.z + (double)handLocal.z()
            );
            handPositioned = true;
         }

         if (!handPositioned) {
            poseStack.mulPose(Axis.YP.rotationDegrees(-owner.getYRot()));
            poseStack.translate(-0.35, -0.05, 0.15);
         }

         float headYaw = Mth.rotLerp(partialTicks, owner.yRotO, owner.getYRot());
         float headPitch = Mth.lerp(partialTicks, owner.xRotO, owner.getXRot());
         poseStack.mulPose(Axis.YP.rotationDegrees(-headYaw));
         poseStack.mulPose(Axis.XP.rotationDegrees(headPitch));
         if (entity.getAge() % 2 == 0 && !Minecraft.getInstance().isPaused()) {
            entity.generateFireBeams();
         }

         List<Vec3> segments = entity.getBeamCache();
         Pose pose = poseStack.last();
         float extensionTicks = 4.0F;
         float rawProgress = ((float)entity.getAge() + partialTicks) / extensionTicks;
         float extension = Mth.clamp(rawProgress, 0.0F, 1.0F);
         float effectiveRange = entity.getEffectiveRange();
         float width = 0.3F;
         float height = width;
         Vec3 start = Vec3.ZERO;
         VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityTranslucentEmissive(this.getTextureLocation(entity)));

         for (int i = 0; i < segments.size() - 1; i += 2) {
            Vec3 from = segments.get(i).scale((double)extension).add(start);
            Vec3 to = segments.get(i + 1).scale((double)extension).add(start);
            if (!(from.z > (double)effectiveRange)) {
               if (to.z > (double)effectiveRange) {
                  double t = ((double)effectiveRange - from.z) / (to.z - from.z);
                  to = from.add(to.subtract(from).scale(t));
               }

               this.drawHull(from, to, width, height, pose, consumer, 255, 120, 30, 40);
               this.drawHull(from, to, width * 0.55F, height * 0.55F, pose, consumer, 255, 200, 50, 70);
               this.drawHull(from, to, width * 0.2F, height * 0.2F, pose, consumer, 255, 255, 220, 200);
            }
         }

         poseStack.popPose();
         super.render(entity, yaw, partialTicks, poseStack, bufferSource, light);
      }
   }

   public void drawHull(Vec3 from, Vec3 to, float width, float height, Pose pose, VertexConsumer consumer, int r, int g, int b, int a) {
      this.drawQuad(from.subtract(0.0, (double)(height * 0.5F), 0.0), to.subtract(0.0, (double)(height * 0.5F), 0.0), width, 0.0F, pose, consumer, r, g, b, a);
      this.drawQuad(from.add(0.0, (double)(height * 0.5F), 0.0), to.add(0.0, (double)(height * 0.5F), 0.0), width, 0.0F, pose, consumer, r, g, b, a);
      this.drawQuad(from.subtract((double)(width * 0.5F), 0.0, 0.0), to.subtract((double)(width * 0.5F), 0.0, 0.0), 0.0F, height, pose, consumer, r, g, b, a);
      this.drawQuad(from.add((double)(width * 0.5F), 0.0, 0.0), to.add((double)(width * 0.5F), 0.0, 0.0), 0.0F, height, pose, consumer, r, g, b, a);
   }

   public void drawQuad(Vec3 from, Vec3 to, float width, float height, Pose pose, VertexConsumer consumer, int r, int g, int b, int a) {
      Matrix4f poseMatrix = pose.pose();
      float halfWidth = width * 0.5F;
      float halfHeight = height * 0.5F;
      consumer.addVertex(poseMatrix, (float)from.x - halfWidth, (float)from.y - halfHeight, (float)from.z)
         .setColor(r, g, b, a)
         .setUv(0.0F, 1.0F)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(240)
         .setNormal(0.0F, 1.0F, 0.0F);
      consumer.addVertex(poseMatrix, (float)from.x + halfWidth, (float)from.y + halfHeight, (float)from.z)
         .setColor(r, g, b, a)
         .setUv(1.0F, 1.0F)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(240)
         .setNormal(0.0F, 1.0F, 0.0F);
      consumer.addVertex(poseMatrix, (float)to.x + halfWidth, (float)to.y + halfHeight, (float)to.z)
         .setColor(r, g, b, a)
         .setUv(1.0F, 0.0F)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(240)
         .setNormal(0.0F, 1.0F, 0.0F);
      consumer.addVertex(poseMatrix, (float)to.x - halfWidth, (float)to.y - halfHeight, (float)to.z)
         .setColor(r, g, b, a)
         .setUv(0.0F, 0.0F)
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(240)
         .setNormal(0.0F, 1.0F, 0.0F);
   }

   public ResourceLocation getTextureLocation(FireBlastProjectile entity) {
      return SOLID;
   }
}
