package com.invfix.vpower.client.renderer.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Optional;
import com.invfix.vpower.client.belial.NailongBelialClientHandler;
import com.invfix.vpower.client.fashionegg.EggShellClientHandler;
import com.invfix.vpower.client.invisibility.InvisibilityRenderHelper;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager.ControllerRegistrar;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoObjectRenderer;
import software.bernie.geckolib.util.GeckoLibUtil;

public class NailongBelialBodyLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
   private static final ResourceLocation BODY_TEXTURE = ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/transform/nailong_belial/long_belial.png");
   private static final ResourceLocation TRANSFORMER_TEXTURE = ResourceLocation.fromNamespaceAndPath(
      "theboysmod", "textures/transformer/ultraman_belial/normal/belial_transformer.png"
   );
   private final NailongBelialBodyLayer.BelialBodyRenderer bodyRenderer = new NailongBelialBodyLayer.BelialBodyRenderer();
   private final NailongBelialBodyLayer.BelialTransformerRenderer transformerRenderer = new NailongBelialBodyLayer.BelialTransformerRenderer();

   public NailongBelialBodyLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
      super(parent);
   }

   public void render(
      PoseStack poseStack,
      MultiBufferSource bufferSource,
      int packedLight,
      AbstractClientPlayer player,
      float limbSwing,
      float limbSwingAmount,
      float partialTick,
      float ageInTicks,
      float netHeadYaw,
      float headPitch
   ) {
      if (shouldRender(player)) {
         PlayerModel<AbstractClientPlayer> parentModel = (PlayerModel<AbstractClientPlayer>)this.getParentModel();
         if (NailongBelialClientHandler.shouldRenderBody(player)) {
            this.bodyRenderer.setPlayerModel(parentModel);
            this.bodyRenderer.renderOnPlayer(poseStack, bufferSource, packedLight, partialTick);
         }

         if (NailongBelialClientHandler.shouldRenderTransformer(player)) {
            this.transformerRenderer.setPlayerModel(parentModel);
            this.transformerRenderer.renderOnPlayer(poseStack, bufferSource, packedLight, partialTick);
         }
      }
   }

   private static boolean shouldRender(AbstractClientPlayer player) {
      return player != null
            && !player.isSpectator()
            && !player.isInvisible()
            && !InvisibilityRenderHelper.shouldHideBody(player)
            && !EggShellClientHandler.shouldHideBody(player)
         ? NailongBelialClientHandler.shouldRenderBody(player) || NailongBelialClientHandler.shouldRenderTransformer(player)
         : false;
   }

   private static final class BelialAnimatable implements GeoAnimatable {
      private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

      public void registerControllers(ControllerRegistrar controllers) {
      }

      public AnimatableInstanceCache getAnimatableInstanceCache() {
         return this.cache;
      }

      public double getTick(Object object) {
         return 0.0;
      }
   }

   private static final class BelialBodyModel extends GeoModel<NailongBelialBodyLayer.BelialAnimatable> {
      public ResourceLocation getModelResource(NailongBelialBodyLayer.BelialAnimatable animatable) {
         return ResourceLocation.fromNamespaceAndPath("theboysmod", "geo/transform/nailong_belial/long_belial.geo.json");
      }

      public ResourceLocation getTextureResource(NailongBelialBodyLayer.BelialAnimatable animatable) {
         return NailongBelialBodyLayer.BODY_TEXTURE;
      }

      public ResourceLocation getAnimationResource(NailongBelialBodyLayer.BelialAnimatable animatable) {
         return null;
      }
   }

   private static final class BelialBodyRenderer extends NailongBelialBodyLayer.SyncedBelialRenderer {
      private BelialBodyRenderer() {
         super(new NailongBelialBodyLayer.BelialBodyModel());
      }

      @Override
      protected ResourceLocation texture() {
         return NailongBelialBodyLayer.BODY_TEXTURE;
      }

      @Override
      protected void syncPlayerBones(BakedGeoModel model) {
         if (this.playerModel != null) {
            this.syncBone(model, this.playerModel.body, "body", NailongBelialBodyLayer.BodyPart.BODY);
            this.syncBone(model, this.playerModel.head, "head", NailongBelialBodyLayer.BodyPart.HEAD);
            this.syncBone(model, this.playerModel.rightArm, "right_arm", NailongBelialBodyLayer.BodyPart.RIGHT_ARM);
            this.syncBone(model, this.playerModel.leftArm, "left_arm", NailongBelialBodyLayer.BodyPart.LEFT_ARM);
            this.syncBone(model, this.playerModel.rightLeg, "right_leg", NailongBelialBodyLayer.BodyPart.RIGHT_LEG);
            this.syncBone(model, this.playerModel.leftLeg, "left_leg", NailongBelialBodyLayer.BodyPart.LEFT_LEG);
         }
      }
   }

   private static final class BelialTransformerModel extends GeoModel<NailongBelialBodyLayer.BelialAnimatable> {
      public ResourceLocation getModelResource(NailongBelialBodyLayer.BelialAnimatable animatable) {
         return ResourceLocation.fromNamespaceAndPath("theboysmod", "geo/transformer/ultraman_belial/normal/belial_transformer.geo.json");
      }

      public ResourceLocation getTextureResource(NailongBelialBodyLayer.BelialAnimatable animatable) {
         return NailongBelialBodyLayer.TRANSFORMER_TEXTURE;
      }

      public ResourceLocation getAnimationResource(NailongBelialBodyLayer.BelialAnimatable animatable) {
         return null;
      }
   }

   private static final class BelialTransformerRenderer extends NailongBelialBodyLayer.SyncedBelialRenderer {
      private BelialTransformerRenderer() {
         super(new NailongBelialBodyLayer.BelialTransformerModel());
      }

      @Override
      protected ResourceLocation texture() {
         return NailongBelialBodyLayer.TRANSFORMER_TEXTURE;
      }

      @Override
      protected void syncPlayerBones(BakedGeoModel model) {
         if (this.playerModel != null) {
            this.syncBone(model, this.playerModel.rightArm, "right_arm", NailongBelialBodyLayer.BodyPart.RIGHT_ARM);
         }
      }
   }

   private static enum BodyPart {
      HEAD,
      BODY,
      RIGHT_ARM,
      LEFT_ARM,
      RIGHT_LEG,
      LEFT_LEG;
   }

   private abstract static class SyncedBelialRenderer extends GeoObjectRenderer<NailongBelialBodyLayer.BelialAnimatable> {
      private static final NailongBelialBodyLayer.BelialAnimatable INSTANCE = new NailongBelialBodyLayer.BelialAnimatable();
      private static final float MODEL_Y_OFFSET = -1.5F;
      private static final float ARM_POS_X_OFFSET = 5.0F;
      private static final float ARM_POS_Y_OFFSET = 2.0F;
      private static final float LEG_POS_X_OFFSET = 2.0F;
      private static final float LEG_POS_Y_OFFSET = 12.0F;
      protected PlayerModel<AbstractClientPlayer> playerModel;

      private SyncedBelialRenderer(GeoModel<NailongBelialBodyLayer.BelialAnimatable> model) {
         super(model);
      }

      protected void setPlayerModel(PlayerModel<AbstractClientPlayer> playerModel) {
         this.playerModel = playerModel;
      }

      protected void renderOnPlayer(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick) {
         RenderType renderType = RenderType.entityTranslucent(this.texture());
         this.render(poseStack, INSTANCE, bufferSource, renderType, null, packedLight, partialTick);
      }

      protected abstract ResourceLocation texture();

      protected abstract void syncPlayerBones(BakedGeoModel var1);

      public void preRender(
         PoseStack poseStack,
         NailongBelialBodyLayer.BelialAnimatable animatable,
         BakedGeoModel model,
         @Nullable MultiBufferSource bufferSource,
         @Nullable VertexConsumer buffer,
         boolean isReRender,
         float partialTick,
         int packedLight,
         int packedOverlay,
         int colour
      ) {
         this.objectRenderTranslations = new Matrix4f(poseStack.last().pose());
         this.syncPlayerBones(model);
      }

      public void actuallyRender(
         PoseStack poseStack,
         NailongBelialBodyLayer.BelialAnimatable animatable,
         BakedGeoModel model,
         @Nullable RenderType renderType,
         MultiBufferSource bufferSource,
         @Nullable VertexConsumer buffer,
         boolean isReRender,
         float partialTick,
         int packedLight,
         int packedOverlay,
         int colour
      ) {
         poseStack.pushPose();
         poseStack.scale(-1.0F, -1.0F, 1.0F);
         poseStack.translate(0.0F, -1.5F, 0.0F);
         poseStack.translate(0.0F, 0.01F, 0.0F);
         this.modelRenderTranslations = new Matrix4f(poseStack.last().pose());

         for (GeoBone bone : model.topLevelBones()) {
            this.renderRecursively(poseStack, animatable, bone, renderType, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, colour);
         }

         poseStack.popPose();
      }

      protected void syncBone(BakedGeoModel model, ModelPart part, String boneName, NailongBelialBodyLayer.BodyPart bodyPart) {
         Optional<GeoBone> optionalBone = model.getBone(boneName);
         if (!optionalBone.isEmpty()) {
            GeoBone bone = optionalBone.get();
            float x = part.x;
            float y = -part.y;
            float z = part.z;
            switch (bodyPart) {
               case BODY:
                  x = 0.0F;
                  break;
               case RIGHT_ARM:
                  x += 5.0F;
                  y += 2.0F;
                  break;
               case LEFT_ARM:
                  x -= 5.0F;
                  y += 2.0F;
                  break;
               case RIGHT_LEG:
                  x += 2.0F;
                  y += 12.0F;
                  break;
               case LEFT_LEG:
                  x -= 2.0F;
                  y += 12.0F;
            }

            bone.setPosX(x);
            bone.setPosY(y);
            bone.setPosZ(z);
            bone.setRotX(-part.xRot);
            bone.setRotY(-part.yRot);
            bone.setRotZ(part.zRot);
            bone.setScaleX(part.xScale);
            bone.setScaleY(part.yScale);
            bone.setScaleZ(part.zScale);
         }
      }
   }
}
