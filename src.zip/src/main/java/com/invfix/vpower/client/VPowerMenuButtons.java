package com.invfix.vpower.client;

import com.invfix.vpower.VPowerMenu;
import com.invfix.vpower.network.VSkillSelectPacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.VAbilities;
import com.invfix.vpower.skill.base.Skill;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Кнопки способностей V во вкладке PWR (VPowerMenu). Иконки — sable_compat:textures/screens/ab_v_*.png
 * (tools/v_icons.py). Способность с действием — выбрать для слота, пассивная — только описание.
 */
@OnlyIn(Dist.CLIENT)
public final class VPowerMenuButtons {

    /** Родной ряд способностей листа сил (у Вильтрумитов — кнопки 7–12), относительно leftPos / topPos. */
    public static final int[][] NATIVE_ROW = {{149, 99}, {174, 99}, {199, 99}, {224, 99}, {249, 99}, {274, 99}};

    /**
     * Свободные места листа сил — те же, что у наших кнопок у Вильтрумитов (AbilitiesMenuPowerViltrumiteScreenMixin):
     * листы Super Speed, Atomic и Tech Jacket нарисованы так же (экран 435×300, лист с +46,+29, ряд способностей
     * на y 102, кнопки слотов на y 184–204).
     */
    public static final int[][] FREE_SLOTS = freeSlots();

    private VPowerMenuButtons() {}

    private static int[][] freeSlots() {
        List<int[]> out = new ArrayList<>();
        for (int x = 149; x <= 349; x += 25) out.add(new int[]{x, 124});
        for (int x = 299; x <= 349; x += 25) out.add(new int[]{x, 99});
        for (int x = 149; x <= 349; x += 25) out.add(new int[]{x, 55});
        for (int y = 35; y <= 235; y += 25) if (y + 20 <= 154 || y >= 172) out.add(new int[]{405, y});
        for (int y = 35; y <= 235; y += 25) out.add(new int[]{20, y});
        for (int x = 46; x <= 371; x += 25) out.add(new int[]{x, 270});
        for (int x = 46; x <= 371; x += 25) out.add(new int[]{x, 5});
        return out.toArray(new int[0][]);
    }

    /** Кнопки всех способностей V игрока; place — абсолютные {x, y} очередного места. */
    public static void add(Player player, Supplier<int[]> place, Consumer<ImageButton> addWidget) {
        SkillData data = player.getData(ModSkillAttachments.SKILL_DATA.get());
        for (Skill skill : VPowerMenu.skills(player)) {
            int[] p = place.get();
            String id = skill.getId().toString();
            ImageButton button = button(p[0], p[1], skill.getId().getPath(),
                    () -> PacketDistributor.sendToServer(new VSkillSelectPacket(id)));
            button.setTooltip(Tooltip.create(tooltip(skill, data.isTemporarySkill(id))));
            addWidget.accept(button);
        }
    }

    private static Component tooltip(Skill skill, boolean temporary) {
        boolean action = VAbilities.assignable(skill);
        MutableComponent text = Component.empty()
                .append(Component.literal(VAbilities.PREFIX).append(skill.getName()))
                .append(Component.literal(temporary ? " §6(Temp V)" : ""))
                .append(Component.literal(action ? "\n§7Кнопка — выбрать, затем кнопка слота" : "\n§8Пассивная — работает сама"))
                .append(Component.literal("\n§7")).append(skill.getDescription());
        return text;
    }

    private static ImageButton button(int x, int y, String path, Runnable onPress) {
        WidgetSprites sprites = new WidgetSprites(
                ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/screens/ab_v_" + path + ".png"),
                ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/screens/ab_v_" + path + "_hover.png"));
        return new ImageButton(x, y, 20, 20, sprites, e -> onPress.run()) {
            @Override
            public void renderWidget(GuiGraphics g, int mx, int my, float pt) {
                g.blit(this.sprites.get(this.isActive(), this.isHoveredOrFocused()),
                        this.getX(), this.getY(), 0.0F, 0.0F, this.width, this.height, this.width, this.height);
            }
        };
    }
}
