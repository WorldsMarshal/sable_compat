package com.invfix.vpower.client.lasereye;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.invfix.vpower.client.ClientSkillStateCache;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.LaserEyeSkill;
import com.invfix.vpower.util.LaserEyeGeometry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.client.event.RenderPlayerEvent.Post;
import org.joml.Matrix4f;
import org.joml.Vector3f;

@OnlyIn(Dist.CLIENT)
public class LaserEyeRenderer {
   private static final float CORE_R = 1.0F;
   private static final float CORE_G = 0.9F;
   private static final float CORE_B = 0.85F;
   private static final float CORE_ALPHA = 0.95F;
   private static final float GLOW_R = 1.0F;
   private static final float GLOW_G = 0.15F;
   private static final float GLOW_B = 0.1F;
   private static final float GLOW_ALPHA = 0.6F;
   private static final LaserEyeRenderer.BeamPalette DEFAULT_BEAM = new LaserEyeRenderer.BeamPalette(1.0F, 0.9F, 0.85F, 0.95F, 1.0F, 0.15F, 0.1F, 0.6F);
   private static final LaserEyeRenderer.BeamPalette MCA_BLUE_BEAM = new LaserEyeRenderer.BeamPalette(0.65F, 0.92F, 1.0F, 0.95F, 0.1F, 0.55F, 1.0F, 0.6F);
   private static final LaserEyeRenderer.BeamPalette TEMPORARY_YELLOW_BEAM = new LaserEyeRenderer.BeamPalette(
      1.0F, 0.98F, 0.62F, 0.95F, 1.0F, 0.78F, 0.05F, 0.6F
   );
   private static final float BEAM_WIDTH = 0.04375F;
   private static final int BLOOM_LAYERS = 3;
   private static final float ROTATION_SPEED = 1.0F;
   private static final float RIGHT_EYE_X = 0.075F;
   private static final float RIGHT_EYE_Y = -0.125F;
   private static final float RIGHT_EYE_Z = -0.25F;
   private static final float LEFT_EYE_X = -0.075F;
   private static final float LEFT_EYE_Y = -0.125F;
   private static final float LEFT_EYE_Z = -0.25F;

   private static float getBeamWidth() {
      try {
         Minecraft mc = Minecraft.getInstance();
         if (mc.player == null) {
            return 0.04375F;
         } else {
            SkillData data = (SkillData)mc.player.getData(ModSkillAttachments.SKILL_DATA.get());
            int pct = data.getDamageMultiplier(LaserEyeSkill.ID.toString());
            float scale = Math.max(0.1F, (float)pct / 200.0F);
            return 0.04375F * scale;
         }
      } catch (Exception var4) {
         return 0.04375F;
      }
   }

   public static void renderInPlayerEvent(Post event) {
   }

   public static void renderAllRemotePlayers(PoseStack poseStack, float partialTick) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level != null && mc.player != null) {
         Vec3 cameraPos = mc.gameRenderer.getMainCamera().getPosition();
         BufferSource bufferSource = mc.renderBuffers().bufferSource();

         for (AbstractClientPlayer player : mc.level.players()) {
            boolean isLocalPlayer = player == mc.player;
            if (!isLocalPlayer || !mc.options.getCameraType().isFirstPerson()) {
               int id = player.getId();
               if (LaserEyeClientHandler.hasVisibleBeam(id)) {
                  float beamValue = LaserEyeClientHandler.getBeamValue(id, partialTick);
                  if (!(beamValue <= 0.0F)) {
                     Vec3 hitPos = LaserEyeClientHandler.getHitPosition(id);
                     if (hitPos != null) {
                        float headYaw = Mth.lerp(partialTick, player.yHeadRotO, player.yHeadRot);
                        float headPitch = Mth.lerp(partialTick, player.xRotO, player.getXRot());
                        Vec3 eyePos = getDynamicEyeBase(player, partialTick, headYaw, headPitch);
                        Vec3 beamDir = hitPos.subtract(eyePos);
                        double fullDistance = beamDir.length();
                        if (!(fullDistance < 0.01)) {
                           beamDir = beamDir.normalize();
                           float beamLength = (float)(fullDistance * (double)beamValue);
                           double yawRad = Math.toRadians((double)headYaw);
                           Vec3 right = new Vec3(Math.cos(yawRad), 0.0, Math.sin(yawRad));
                           double sideOffset = getDynamicEyeSideOffset(player);
                           Vec3 rightStart = eyePos.add(right.scale(sideOffset));
                           Vec3 rightEnd = rightStart.add(beamDir.scale((double)beamLength));
                           Vec3 leftStart = eyePos.add(right.scale(-sideOffset));
                           Vec3 leftEnd = leftStart.add(beamDir.scale((double)beamLength));
                           int ticks = player.tickCount;
                           LaserEyeRenderer.BeamPalette palette = getPlayerBeamPalette(player);
                           renderWorldSpaceBeam(poseStack, bufferSource, cameraPos, rightStart, rightEnd, ticks, partialTick, 0.04375F, palette);
                           renderWorldSpaceBeam(poseStack, bufferSource, cameraPos, leftStart, leftEnd, ticks, partialTick, 0.04375F, palette);
                        }
                     }
                  }
               }
            }
         }

         for (LivingEntity entity : mc.level.getEntitiesOfClass(LivingEntity.class, mc.player.getBoundingBox().inflate(64.0))) {
            if (!(entity instanceof AbstractClientPlayer)) {
               int id = entity.getId();
               if (LaserEyeClientHandler.hasVisibleBeam(id)) {
                  float beamValue = LaserEyeClientHandler.getBeamValue(id, partialTick);
                  if (!(beamValue <= 0.0F)) {
                     Vec3 hitPos = LaserEyeClientHandler.getHitPosition(id);
                     if (hitPos != null) {
                        float headYaw = Mth.lerp(partialTick, entity.yHeadRotO, entity.yHeadRot);
                        float headPitch = Mth.lerp(partialTick, entity.xRotO, entity.getXRot());
                        double yawRad = Math.toRadians((double)headYaw);
                        double pitchRad = Math.toRadians((double)headPitch);
                        double cosP = Math.cos(pitchRad);
                        new Vec3(-Math.sin(yawRad) * cosP, -Math.sin(pitchRad), Math.cos(yawRad) * cosP);
                        Vec3 eyePos = getDynamicEyeBase(entity, partialTick, headYaw, headPitch);
                        Vec3 beamDir = hitPos.subtract(eyePos);
                        double fullDistance = beamDir.length();
                        if (!(fullDistance < 0.01)) {
                           beamDir = beamDir.normalize();
                           float beamLength = (float)(fullDistance * (double)beamValue);
                           Vec3 right = new Vec3(Math.cos(yawRad), 0.0, Math.sin(yawRad));
                           double sideOffset = getDynamicEyeSideOffset(entity);
                           Vec3 rightStart = eyePos.add(right.scale(sideOffset));
                           Vec3 rightEnd = rightStart.add(beamDir.scale((double)beamLength));
                           Vec3 leftStart = eyePos.add(right.scale(-sideOffset));
                           Vec3 leftEnd = leftStart.add(beamDir.scale((double)beamLength));
                           int ticks = entity.tickCount;
                           LaserEyeRenderer.BeamPalette palette = DEFAULT_BEAM;
                           renderWorldSpaceBeam(poseStack, bufferSource, cameraPos, rightStart, rightEnd, ticks, partialTick, 0.04375F, palette);
                           renderWorldSpaceBeam(poseStack, bufferSource, cameraPos, leftStart, leftEnd, ticks, partialTick, 0.04375F, palette);
                        }
                     }
                  }
               }
            }
         }

         bufferSource.endBatch(RenderType.lightning());
      }
   }

   private static void renderEyeBeam(
      PoseStack poseStack,
      MultiBufferSource bufferSource,
      PlayerModel<?> model,
      AbstractClientPlayer player,
      float partialTick,
      float eyeX,
      float eyeY,
      float eyeZ,
      float beamLength,
      Vec3 hitPos,
      Vec3 cameraPos,
      int ticks,
      float beamWidth
   ) {
      PoseStack bonePS = new PoseStack();
      float bodyYaw = Mth.rotLerp(partialTick, player.yBodyRotO, player.yBodyRot);
      bonePS.mulPose(Axis.YP.rotationDegrees(180.0F - bodyYaw));
      if (player.isFallFlying()) {
         float flyTicks = (float)player.getFallFlyingTicks() + partialTick;
         float flyFactor = Mth.clamp(flyTicks * flyTicks / 100.0F, 0.0F, 1.0F);
         if (!player.isAutoSpinAttack()) {
            bonePS.mulPose(Axis.XP.rotationDegrees(flyFactor * (-90.0F - player.getXRot())));
         }

         Vec3 viewVec = player.getViewVector(partialTick);
         Vec3 moveVec = player.getDeltaMovementLerped(partialTick);
         double moveLenSq = moveVec.horizontalDistanceSqr();
         double viewLenSq = viewVec.horizontalDistanceSqr();
         if (moveLenSq > 0.0 && viewLenSq > 0.0) {
            double dot = (moveVec.x * viewVec.x + moveVec.z * viewVec.z) / Math.sqrt(moveLenSq * viewLenSq);
            double cross = moveVec.x * viewVec.z - moveVec.z * viewVec.x;
            bonePS.mulPose(Axis.YP.rotationDegrees((float)(Math.signum(cross) * Math.acos(dot)) * (180.0F / (float)Math.PI)));
         }
      }

      if (player.isVisuallySwimming()) {
         float swimAmount = player.getSwimAmount(partialTick);
         float pitch = !player.isInWater() && !player.isInFluidType((fluidType, height) -> player.canSwimInFluidType(fluidType))
            ? -90.0F
            : -90.0F - player.getXRot();
         float lerpPitch = Mth.lerp(swimAmount, 0.0F, pitch);
         bonePS.mulPose(Axis.XP.rotationDegrees(lerpPitch));
         if (player.isVisuallySwimming()) {
            bonePS.translate(0.0F, -1.0F, 0.3F);
         }
      }

      bonePS.scale(-1.0F, -1.0F, 1.0F);
      bonePS.translate(0.0F, -1.501F, 0.0F);
      model.head.translateAndRotate(bonePS);
      bonePS.translate(eyeX, eyeY, eyeZ);
      Vector3f eyeRelEntity = new Vector3f(0.0F, 0.0F, 0.0F);
      bonePS.last().pose().transformPosition(eyeRelEntity);
      poseStack.pushPose();
      poseStack.translate(eyeRelEntity.x, eyeRelEntity.y, eyeRelEntity.z);
      Vec3 eyePos = player.getEyePosition(partialTick);
      Vec3 beamDir = hitPos.subtract(eyePos).normalize();
      double yaw = Math.toDegrees(Math.atan2(beamDir.x, beamDir.z));
      double pitch = Math.toDegrees(Math.asin(-beamDir.y));
      poseStack.mulPose(Axis.YP.rotationDegrees((float)yaw));
      poseStack.mulPose(Axis.XP.rotationDegrees((float)pitch));
      float rot = ((float)ticks + partialTick) * 1.0F;
      poseStack.mulPose(Axis.YP.rotationDegrees(rot % 360.0F));
      VertexConsumer consumer = bufferSource.getBuffer(RenderType.lightning());
      renderBeamGeometry(poseStack, consumer, beamLength, beamWidth);
      poseStack.popPose();
   }

   public static void renderAll(PoseStack poseStack, float partialTick) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level != null && mc.player != null) {
         if (mc.options.getCameraType().isFirstPerson()) {
            AbstractClientPlayer player = mc.player;
            int id = player.getId();
            if (LaserEyeClientHandler.hasVisibleBeam(id)) {
               float beamValue = LaserEyeClientHandler.getBeamValue(id, partialTick);
               if (!(beamValue <= 0.0F)) {
                  Vec3 hitPos = LaserEyeClientHandler.getHitPosition(id);
                  if (hitPos != null) {
                     Vec3 cameraPos = mc.gameRenderer.getMainCamera().getPosition();
                     BufferSource bufferSource = mc.renderBuffers().bufferSource();
                     float headYaw = Mth.lerp(partialTick, player.yHeadRotO, player.yHeadRot);
                     float headPitch = Mth.lerp(partialTick, player.xRotO, player.getXRot());
                     Vec3 eyePos = getDynamicEyeBase(player, partialTick, headYaw, headPitch);
                     Vec3 beamDir = hitPos.subtract(eyePos).normalize();
                     double fullDistance = eyePos.distanceTo(hitPos);
                     float beamLength = (float)(fullDistance * (double)beamValue);
                     double yawRad = Math.toRadians((double)headYaw);
                     Vec3 right = new Vec3(Math.cos(yawRad), 0.0, Math.sin(yawRad));
                     double sideOffset = getDynamicEyeSideOffset(player);
                     Vec3 rightStart = eyePos.add(right.scale(sideOffset));
                     Vec3 rightEnd = rightStart.add(beamDir.scale((double)beamLength));
                     Vec3 leftStart = eyePos.add(right.scale(-sideOffset));
                     Vec3 leftEnd = leftStart.add(beamDir.scale((double)beamLength));
                     int ticks = player.tickCount;
                     float beamWidth = getBeamWidth();
                     LaserEyeRenderer.BeamPalette palette = getPlayerBeamPalette(player);
                     renderWorldSpaceBeam(poseStack, bufferSource, cameraPos, rightStart, rightEnd, ticks, partialTick, beamWidth, palette);
                     renderWorldSpaceBeam(poseStack, bufferSource, cameraPos, leftStart, leftEnd, ticks, partialTick, beamWidth, palette);
                     bufferSource.endBatch(RenderType.lightning());
                  }
               }
            }
         }
      }
   }

   private static void renderWorldSpaceBeam(
      PoseStack poseStack, BufferSource bufferSource, Vec3 cameraPos, Vec3 start, Vec3 end, int ticks, float partialTick, float beamWidth
   ) {
      renderWorldSpaceBeam(poseStack, bufferSource, cameraPos, start, end, ticks, partialTick, beamWidth, DEFAULT_BEAM);
   }

   private static void renderWorldSpaceBeam(
      PoseStack poseStack,
      BufferSource bufferSource,
      Vec3 cameraPos,
      Vec3 start,
      Vec3 end,
      int ticks,
      float partialTick,
      float beamWidth,
      LaserEyeRenderer.BeamPalette palette
   ) {
      float length = (float)start.distanceTo(end);
      if (!(length < 0.01F)) {
         Vec3 relStart = start.subtract(cameraPos);
         poseStack.pushPose();
         poseStack.translate(relStart.x, relStart.y, relStart.z);
         Vec3 direction = end.subtract(start).normalize();
         double yaw = Math.toDegrees(Math.atan2(direction.x, direction.z));
         double pitch = Math.toDegrees(Math.asin(-direction.y));
         poseStack.mulPose(Axis.YP.rotationDegrees((float)yaw));
         poseStack.mulPose(Axis.XP.rotationDegrees((float)pitch));
         poseStack.mulPose(Axis.XP.rotationDegrees(90.0F));
         float rot = ((float)ticks + partialTick) * 1.0F;
         poseStack.mulPose(Axis.YP.rotationDegrees(rot % 360.0F));
         VertexConsumer consumer = bufferSource.getBuffer(RenderType.lightning());
         renderBeamGeometry(poseStack, consumer, length, beamWidth, palette);
         poseStack.popPose();
      }
   }

   private static LaserEyeRenderer.BeamPalette getPlayerBeamPalette(AbstractClientPlayer player) {
      return isTemporaryLaserEye(player) ? TEMPORARY_YELLOW_BEAM : DEFAULT_BEAM;
   }

   private static boolean isTemporaryLaserEye(AbstractClientPlayer player) {
      String laserEyeId = LaserEyeSkill.ID.toString();
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null && mc.player.getId() == player.getId()) {
         try {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            return data.isTemporarySkill(laserEyeId);
         } catch (Exception var4) {
            return false;
         }
      } else {
         return ClientSkillStateCache.isTemporarySkill(player.getId(), laserEyeId);
      }
   }

   private static void renderBeamGeometry(PoseStack poseStack, VertexConsumer consumer, float beamLength, float beamWidth) {
      renderBeamGeometry(poseStack, consumer, beamLength, beamWidth, DEFAULT_BEAM);
   }

   private static void renderBeamGeometry(PoseStack poseStack, VertexConsumer consumer, float beamLength, float beamWidth, LaserEyeRenderer.BeamPalette palette) {
      float halfW = beamWidth / 2.0F;
      AABB coreBox = new AABB((double)(-halfW), 0.0, (double)(-halfW), (double)halfW, (double)beamLength, (double)halfW);
      renderFilledBox(poseStack, consumer, coreBox, palette.coreR(), palette.coreG(), palette.coreB(), palette.coreAlpha());

      for (int i = 1; i <= 3; i++) {
         float expansion = (float)i * 0.5F * 0.0625F * (beamWidth / 0.04375F);
         AABB bloomBox = coreBox.inflate((double)expansion, 0.0, (double)expansion);
         float alpha = palette.glowAlpha() / (float)i;
         renderFilledBox(poseStack, consumer, bloomBox, palette.glowR(), palette.glowG(), palette.glowB(), alpha);
      }
   }

   private static Vec3 getDynamicEyeBase(LivingEntity entity, float partialTick, float headYaw, float headPitch) {
      return LaserEyeGeometry.getDynamicEyeBase(entity, partialTick);
   }

   private static double getDynamicEyeSideOffset(LivingEntity entity) {
      return LaserEyeGeometry.getDynamicEyeSideOffset(entity);
   }

   private static void renderFilledBox(PoseStack poseStack, VertexConsumer vc, AABB box, float red, float green, float blue, float alpha) {
      Matrix4f matrix = poseStack.last().pose();
      int light = 15728640;
      float x0 = (float)box.minX;
      float y0 = (float)box.minY;
      float z0 = (float)box.minZ;
      float x1 = (float)box.maxX;
      float y1 = (float)box.maxY;
      float z1 = (float)box.maxZ;
      vc.addVertex(matrix, x0, y1, z0).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x0, y1, z1).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x1, y1, z1).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x1, y1, z0).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x0, y0, z0).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x1, y0, z0).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x1, y0, z1).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x0, y0, z1).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x0, y0, z0).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x0, y1, z0).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x1, y1, z0).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x1, y0, z0).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x0, y0, z1).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x1, y0, z1).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x1, y1, z1).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x0, y1, z1).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x1, y0, z0).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x1, y1, z0).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x1, y1, z1).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x1, y0, z1).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x0, y0, z0).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x0, y0, z1).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x0, y1, z1).setColor(red, green, blue, alpha).setLight(light);
      vc.addVertex(matrix, x0, y1, z0).setColor(red, green, blue, alpha).setLight(light);
   }

   private static record BeamPalette(float coreR, float coreG, float coreB, float coreAlpha, float glowR, float glowG, float glowB, float glowAlpha) {
   }
}
