package com.invfix.vpower.client.gui.overlay;

import java.util.Locale;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw.Layer;
import net.minecraft.client.player.LocalPlayer;

public final class TempVSideEffectOverlay {
   private static final int PANEL_WIDTH = 78;
   private static final int PANEL_HEIGHT = 22;
   private static final int BAR_WIDTH = 64;
   private static final int BAR_HEIGHT = 4;
   private static final int OVERFLOW_THRESHOLD = 100;
   private static final int LOAD_PER_INJECTION = 35;
   private static final int MAX_SIDE_EFFECT_LOAD = 150;
   public static final Layer HUD_TEMP_V_SIDE_EFFECT = (guiGraphics, deltaTracker) -> {
      Minecraft minecraft = Minecraft.getInstance();
      LocalPlayer player = minecraft.player;
      if (player != null && !player.isSpectator()) {
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         if (!data.hasTemporarySkills()) {
            long gameTime = player.level().getGameTime();
            int withdrawalTicks = data.getTemporaryVWithdrawalRemainingTicks(gameTime);
            boolean withdrawal = withdrawalTicks > 0;
            boolean overloaded = data.isTemporaryVOverloaded();
            if (withdrawal || overloaded) {
               if (withdrawal) {
                  renderVignette(guiGraphics, minecraft, player, data);
               }

               if (!minecraft.options.hideGui) {
                  renderPanel(guiGraphics, minecraft, player, data, withdrawalTicks, withdrawal, overloaded);
               }

               renderEyeBlackoutFlash(guiGraphics, minecraft, player, data, withdrawal);
            }
         }
      }
   };

   private TempVSideEffectOverlay() {
   }

   private static void renderVignette(GuiGraphics graphics, Minecraft minecraft, LocalPlayer player, SkillData data) {
      int width = minecraft.getWindow().getGuiScaledWidth();
      int height = minecraft.getWindow().getGuiScaledHeight();
      float severity = sideEffectSeverity(data);
      float pulse = (float)((Math.sin((double)((float)player.tickCount * 0.18F)) + 1.0) * 0.5);
      int baseAlpha = 54 + Math.round(severity * 92.0F) + Math.round(pulse * (18.0F + severity * 28.0F));
      int edge = Math.max(18, Math.round((float)Math.min(width, height) * (0.1F + severity * 0.12F)));

      for (int i = 0; i < 5; i++) {
         int strip = Math.max(2, edge / 5);
         int inset = i * strip;
         int alpha = Math.max(18, baseAlpha - i * 22);
         int color = alpha << 24;
         graphics.fill(0, inset, width, inset + strip, color);
         graphics.fill(0, height - inset - strip, width, height - inset, color);
         graphics.fill(inset, 0, inset + strip, height, color);
         graphics.fill(width - inset - strip, 0, width - inset, height, color);
      }
   }

   private static void renderEyeBlackoutFlash(GuiGraphics graphics, Minecraft minecraft, LocalPlayer player, SkillData data, boolean withdrawal) {
      int width = minecraft.getWindow().getGuiScaledWidth();
      int height = minecraft.getWindow().getGuiScaledHeight();
      float severity = sideEffectSeverity(data);
      int cycleTicks = Math.max(55, Math.round(128.0F - severity * 54.0F));
      int phase = Math.floorMod(player.tickCount + player.getId() * 17, cycleTicks);
      int flashTicks = Math.max(1, Math.round(1.0F + severity * 3.0F));
      if (phase < flashTicks) {
         float fade = 1.0F - (float)phase / (float)flashTicks;
         float modeStrength = withdrawal ? 1.0F : 0.65F;
         int alpha = Math.round((110.0F + severity * 120.0F) * fade * modeStrength);
         alpha = Math.max(0, Math.min(235, alpha));
         if (alpha > 0) {
            graphics.fill(0, 0, width, height, alpha << 24);
         }
      }
   }

   private static void renderPanel(
      GuiGraphics graphics, Minecraft minecraft, LocalPlayer player, SkillData data, int withdrawalTicks, boolean withdrawal, boolean overloaded
   ) {
      int screenWidth = minecraft.getWindow().getGuiScaledWidth();
      int screenHeight = minecraft.getWindow().getGuiScaledHeight();
      int hotbarRight = screenWidth / 2 + 91;
      int x = Math.min(screenWidth - 78 - 4, hotbarRight + 7);
      int y = screenHeight - 23;
      if (x <= hotbarRight) {
         y -= 24;
      }

      y = Math.max(4, y);
      int load = data.getTemporaryVLoad();
      int duration = Math.max(1, data.getTemporaryVWithdrawalDurationTicks());
      float ratio = withdrawal
         ? Math.max(0.0F, Math.min(1.0F, (float)withdrawalTicks / (float)duration))
         : Math.max(0.0F, Math.min(1.0F, (float)load / 100.0F));
      int fillWidth = Math.round(64.0F * ratio);
      int accent = withdrawal ? -51128 : (overloaded ? -38118 : -11930);
      graphics.fill(x, y, x + 78, y + 22, -1157101814);
      graphics.fill(x, y, x + 78, y + 1, -11919320);
      graphics.fill(x, y + 22 - 1, x + 78, y + 22, -15202293);
      graphics.fill(x, y, x + 1, y + 22, accent);
      String label = "VLOAD";
      String value = withdrawal ? formatTime(withdrawalTicks) : Math.min(999, load) + "%";
      drawScaledString(graphics, minecraft.font, label, x + 7, y + 4, -19528, 0.72F);
      drawScaledString(graphics, minecraft.font, value, x + 45, y + 4, -1, 0.72F);
      int barX = x + 7;
      int barY = y + 15;
      graphics.fill(barX, barY, barX + 64, barY + 4, 1711276032);
      if (fillWidth > 0) {
         graphics.fill(barX, barY, barX + fillWidth, barY + 4, accent);
         graphics.fill(barX, barY, barX + fillWidth, barY + 1, -12076);
      }
   }

   private static String formatTime(int ticks) {
      int totalSeconds = Math.max(0, (ticks + 19) / 20);
      int minutes = totalSeconds / 60;
      int seconds = totalSeconds % 60;
      return String.format(Locale.ROOT, "%02d:%02d", minutes, seconds);
   }

   private static float sideEffectSeverity(SkillData data) {
      int load = Math.max(35, data.getTemporaryVLoad());
      return Math.max(0.23333333F, Math.min(1.0F, (float)load / 150.0F));
   }

   private static void drawScaledString(GuiGraphics graphics, Font font, String text, int x, int y, int color, float scale) {
      graphics.pose().pushPose();
      graphics.pose().scale(scale, scale, 1.0F);
      graphics.drawString(font, text, Math.round((float)x / scale), Math.round((float)y / scale), color, false);
      graphics.pose().popPose();
   }
}
