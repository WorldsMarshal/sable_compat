package com.invfix.vpower.client.lasereye;

import com.invfix.vpower.registry.ModSounds;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class LaserEyeLoopSound extends AbstractTickableSoundInstance {
   private final LivingEntity entity;
   private boolean shouldStop = false;

   public LaserEyeLoopSound(LivingEntity entity) {
      super((SoundEvent)ModSounds.LASER_EYE.get(), entity instanceof Player ? SoundSource.PLAYERS : SoundSource.HOSTILE, SoundInstance.createUnseededRandom());
      this.entity = entity;
      this.looping = true;
      this.delay = 0;
      this.volume = 0.8F;
      this.pitch = 1.0F;
      this.x = entity.getX();
      this.y = entity.getY();
      this.z = entity.getZ();
   }

   public void tick() {
      if (this.shouldStop) {
         this.stop();
      } else if (this.entity.isAlive() && !this.entity.isRemoved()) {
         boolean active = false;
         if (this.entity instanceof Player player) {
            active = LaserEyeClientHandler.isLaserActive(player);
         }

         if (!active) {
            this.stop();
         } else {
            this.x = this.entity.getX();
            this.y = this.entity.getY();
            this.z = this.entity.getZ();
         }
      } else {
         this.stop();
      }
   }

   public void markStopped() {
      this.shouldStop = true;
   }
}
