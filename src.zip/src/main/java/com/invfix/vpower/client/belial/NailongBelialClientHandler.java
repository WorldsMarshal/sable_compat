package com.invfix.vpower.client.belial;

import com.mojang.blaze3d.vertex.PoseStack;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.VPower;
import com.invfix.vpower.client.ClientSkillStateCache;
import com.invfix.vpower.client.animation.AnimationHelper;
import com.invfix.vpower.client.animation.ModAnimations;
import com.invfix.vpower.client.fp.BelialArmGeoRenderer;
import com.invfix.vpower.client.invisibility.InvisibilityRenderHelper;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.NailongBelialSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.HumanoidArm;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderArmEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public final class NailongBelialClientHandler {
   private static final String SKILL_ID = NailongBelialSkill.ID.toString();
   private static final int TRANSFORM_ANIMATION_TICKS = 30;
   private static final Map<Integer, Boolean> LAST_ACTIVE = new ConcurrentHashMap<>();
   private static final Map<Integer, Integer> TRANSFORM_TICKS = new ConcurrentHashMap<>();
   private static final BelialArmGeoRenderer ARM_RENDERER = new BelialArmGeoRenderer();

   private NailongBelialClientHandler() {
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level != null && !mc.isPaused()) {
         Set<Integer> seen = new HashSet<>();

         for (AbstractClientPlayer player : mc.level.players()) {
            int entityId = player.getId();
            seen.add(entityId);
            boolean active = isSkillActive(player);
            Boolean previous = LAST_ACTIVE.put(entityId, active);
            if (active && previous != null && !previous) {
               TRANSFORM_TICKS.put(entityId, 30);
               AnimationHelper.playAnimationWithFade(player, ModAnimations.NAILONG_BELIAL_TRANSFORM, 2, false, true);
            }

            if (!active) {
               TRANSFORM_TICKS.remove(entityId);
            } else {
               TRANSFORM_TICKS.computeIfPresent(entityId, (id, ticks) -> ticks > 1 ? ticks - 1 : null);
            }
         }

         LAST_ACTIVE.keySet().removeIf(id -> !seen.contains(id));
         TRANSFORM_TICKS.keySet().removeIf(id -> !seen.contains(id));
      } else {
         LAST_ACTIVE.clear();
         TRANSFORM_TICKS.clear();
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public static void onRenderArm(RenderArmEvent event) {
      AbstractClientPlayer partialTick = event.getPlayer();
      if (partialTick instanceof AbstractClientPlayer && isSkillActive(partialTick)) {
         if (InvisibilityRenderHelper.shouldHideBody(partialTick)) {
            event.setCanceled(true);
         } else {
            float partialTickx = mcPartialTick();
            if (isTransforming(partialTick)) {
               renderFirstPersonTransformer(
                  event.getPoseStack(), event.getMultiBufferSource(), event.getPackedLight(), partialTickx, partialTick, event.getArm()
               );
            } else {
               if (isTransformed(partialTick)) {
                  event.setCanceled(true);
                  renderFirstPersonArm(event.getPoseStack(), event.getMultiBufferSource(), event.getPackedLight(), partialTickx, partialTick, event.getArm());
               }
            }
         }
      }
   }

   public static void renderFirstPersonArm(
      PoseStack poseStack, MultiBufferSource buffer, int packedLight, float partialTick, AbstractClientPlayer player, HumanoidArm arm
   ) {
      if (player != null && poseStack != null && buffer != null && isTransformed(player) && !InvisibilityRenderHelper.shouldHideBody(player)) {
         try {
            ARM_RENDERER.renderBodyArm(poseStack, buffer, packedLight, partialTick, player, arm);
         } catch (Exception var7) {
            VPower.LOGGER.error("[NailongBelial] First person arm render failed", var7);
         }
      }
   }

   public static void renderFirstPersonTransformer(
      PoseStack poseStack, MultiBufferSource buffer, int packedLight, float partialTick, AbstractClientPlayer player, HumanoidArm arm
   ) {
      if (player != null && poseStack != null && buffer != null && isTransforming(player) && !InvisibilityRenderHelper.shouldHideBody(player)) {
         try {
            ARM_RENDERER.renderTransformer(poseStack, buffer, packedLight, partialTick, player, arm);
         } catch (Exception var7) {
            VPower.LOGGER.error("[NailongBelial] First person transformer render failed", var7);
         }
      }
   }

   private static float mcPartialTick() {
      return Minecraft.getInstance().getTimer().getGameTimeDeltaPartialTick(true);
   }

   public static boolean isTransformed(AbstractClientPlayer player) {
      return isSkillActive(player) && !isTransforming(player);
   }

   public static boolean isSkillActive(AbstractClientPlayer player) {
      if (player != null && !player.isSpectator() && player.isAlive()) {
         try {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            if (data.hasSkill(SKILL_ID) && data.isSkillActive(SKILL_ID)) {
               return true;
            }
         } catch (Exception var2) {
         }

         return ClientSkillStateCache.isSkillActive(player.getId(), SKILL_ID);
      } else {
         return false;
      }
   }

   public static boolean shouldRenderBody(AbstractClientPlayer player) {
      return isTransformed(player) && !InvisibilityRenderHelper.shouldHideBody(player);
   }

   public static boolean shouldRenderTransformer(AbstractClientPlayer player) {
      return isTransforming(player);
   }

   public static boolean isTransforming(AbstractClientPlayer player) {
      return player != null && TRANSFORM_TICKS.getOrDefault(player.getId(), 0) > 0;
   }
}
