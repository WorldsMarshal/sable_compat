package com.invfix.vpower.client.afterimage;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public class AfterimageClientEvents {
   @SubscribeEvent
   public static void onClientTick(Post event) {
      AfterimageManager.tick();
   }

   @SubscribeEvent
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      if (event.getStage() == Stage.AFTER_TRANSLUCENT_BLOCKS) {
         float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
         AfterimageRenderer.renderAll(event.getPoseStack(), partialTick);
      }
   }
}
