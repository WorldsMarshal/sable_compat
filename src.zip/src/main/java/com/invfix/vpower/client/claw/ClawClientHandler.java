package com.invfix.vpower.client.claw;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.client.ClientSkillStateCache;
import com.invfix.vpower.client.invisibility.InvisibilityRenderHelper;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.DiamondClawsExtensionSkill;
import com.invfix.vpower.skill.skills.DiamondClawsSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderArmEvent;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public final class ClawClientHandler {
   private static final String CLAWS_ID = DiamondClawsSkill.ID.toString();
   private static final String EXTENSION_ID = DiamondClawsExtensionSkill.ID.toString();
   private static final float ANIMATION_TICKS = 10.0F;
   private static final Map<Integer, ClawClientHandler.ToggleState> STATES = new ConcurrentHashMap<>();
   private static final ClawFirstPersonRenderer FIRST_PERSON_RENDERER = new ClawFirstPersonRenderer();

   private ClawClientHandler() {
   }

   @SubscribeEvent
   public static void onRenderArm(RenderArmEvent event) {
      AbstractClientPlayer mc = event.getPlayer();
      if (mc instanceof AbstractClientPlayer && shouldRender(mc)) {
         if (hasUsableHand(mc, event.getArm())) {
            Minecraft mcx = Minecraft.getInstance();
            if (mcx.player != null && mcx.player.getUUID().equals(mc.getUUID()) && mcx.options.getCameraType().isFirstPerson()) {
               if (mcx.getEntityRenderDispatcher().getRenderer(mc) instanceof PlayerRenderer playerRenderer) {
                  float partialTick = mcx.getTimer().getGameTimeDeltaPartialTick(true);
                  FIRST_PERSON_RENDERER.renderArm(
                     event.getPoseStack(),
                     event.getMultiBufferSource(),
                     event.getPackedLight(),
                     partialTick,
                     mc,
                     (PlayerModel<AbstractClientPlayer>)playerRenderer.getModel(),
                     event.getArm()
                  );
               }
            }
         }
      }
   }

   public static boolean shouldRender(LivingEntity entity) {
      return entity != null && !entity.isSpectator() && !entity.isInvisible() && !InvisibilityRenderHelper.shouldHideBody(entity)
         ? hasClaws(entity) && (hasUsableHand(entity, HumanoidArm.RIGHT) || hasUsableHand(entity, HumanoidArm.LEFT))
         : false;
   }

   public static boolean hasClaws(LivingEntity entity) {
      if (entity == null) {
         return false;
      } else {
         try {
            SkillData data = (SkillData)entity.getData(ModSkillAttachments.SKILL_DATA.get());
            if (data.hasSkill(CLAWS_ID)) {
               return true;
            }
         } catch (Exception var2) {
         }

         return ClientSkillStateCache.hasSkill(entity.getId(), CLAWS_ID);
      }
   }

   public static boolean isExtended(LivingEntity entity) {
      if (entity == null) {
         return false;
      } else {
         try {
            SkillData data = (SkillData)entity.getData(ModSkillAttachments.SKILL_DATA.get());
            if (data.hasSkill(EXTENSION_ID)) {
               return data.isSkillActive(EXTENSION_ID);
            }
         } catch (Exception var2) {
         }

         return ClientSkillStateCache.isSkillActive(entity.getId(), EXTENSION_ID);
      }
   }

   public static boolean hasUsableHand(LivingEntity entity, HumanoidArm arm) {
      if (entity != null && arm != null) {
         try {
            FleshRegenData data = (FleshRegenData)entity.getData(ModAttachments.FLESH_REGEN.get());
            String key = arm == HumanoidArm.RIGHT ? "Right.Hand" : "Left.Hand";
            return data.getScore(key) != 0;
         } catch (Exception var4) {
            return true;
         }
      } else {
         return false;
      }
   }

   public static float getExtensionProgress(LivingEntity entity, float partialTick) {
      if (entity == null) {
         return 0.0F;
      } else {
         boolean targetActive = isExtended(entity);
         float renderTick = (float)entity.tickCount + partialTick;
         ClawClientHandler.ToggleState state = STATES.computeIfAbsent(
            entity.getId(), ignored -> new ClawClientHandler.ToggleState(targetActive ? 1.0F : 0.0F, targetActive, renderTick)
         );
         return state.update(targetActive, renderTick);
      }
   }

   public static boolean isSlim(LivingEntity entity) {
      if (entity instanceof AbstractClientPlayer player && player.getSkin().model().id().equals("slim")) {
         return true;
      }

      return false;
   }

   private static final class ToggleState {
      private boolean targetActive;
      private float startProgress;
      private float currentProgress;
      private float startTick;

      private ToggleState(float initialProgress, boolean targetActive, float startTick) {
         this.targetActive = targetActive;
         this.startProgress = initialProgress;
         this.currentProgress = initialProgress;
         this.startTick = startTick;
      }

      private float update(boolean newTargetActive, float renderTick) {
         if (newTargetActive != this.targetActive) {
            this.currentProgress = this.evaluate(renderTick);
            this.startProgress = this.currentProgress;
            this.targetActive = newTargetActive;
            this.startTick = renderTick;
         }

         this.currentProgress = this.evaluate(renderTick);
         return this.currentProgress;
      }

      private float evaluate(float renderTick) {
         float target = this.targetActive ? 1.0F : 0.0F;
         float elapsed = Mth.clamp((renderTick - this.startTick) / 10.0F, 0.0F, 1.0F);
         return Mth.lerp(elapsed, this.startProgress, target);
      }
   }
}
