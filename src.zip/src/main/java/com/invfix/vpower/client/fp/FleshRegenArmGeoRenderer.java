package com.invfix.vpower.client.fp;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.client.dynamictexture.FleshRegenTextureManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;
import software.bernie.geckolib.animation.state.BoneSnapshot;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoObjectRenderer;

public class FleshRegenArmGeoRenderer extends GeoObjectRenderer<FleshRegenArmState> {
   private final FleshRegenArmGeoModel geoModel = (FleshRegenArmGeoModel)this.model;
   private AbstractClientPlayer currentPlayer;

   public FleshRegenArmGeoRenderer() {
      super(new FleshRegenArmGeoModel());
   }

   public void renderArm(
      PoseStack poseStack,
      MultiBufferSource buffer,
      int packedLight,
      float partialTick,
      AbstractClientPlayer player,
      PlayerModel<AbstractClientPlayer> playerModel,
      HumanoidArm arm
   ) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null && mc.player.getUUID().equals(player.getUUID())) {
         if (mc.options.getCameraType().isFirstPerson()) {
            this.currentPlayer = player;
            FleshRegenData data = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
            if (arm == HumanoidArm.RIGHT) {
               int rightArmValue = data.getScore("Right.Arm");
               int rightHandValue = data.getScore("Right.Hand");
               boolean isSlim = this.isSlimModel(player);
               poseStack.pushPose();
               poseStack.translate(0.0F, 1.5F, 0.0F);
               poseStack.scale(-1.0F, -1.0F, 1.0F);
               if (rightArmValue >= 0 && rightArmValue <= 17) {
                  this.renderRightArmLayers(poseStack, buffer, packedLight, partialTick, rightArmValue, isSlim, playerModel.rightArm);
               } else if (rightArmValue == 18 && rightHandValue >= 0 && rightHandValue <= 11) {
                  ResourceLocation armTexture = FleshRegenTextureManager.getRightArmTexture(18);
                  if (armTexture != null) {
                     String fleshGeo = isSlim ? "flesh_regen_right_arm_flesh_slim.geo.json" : "flesh_regen_right_arm_flesh.geo.json";
                     this.renderSingleGeo(poseStack, buffer, packedLight, partialTick, fleshGeo, armTexture, playerModel.rightArm);
                  }

                  String skinGeo = isSlim ? "flesh_regen_right_arm_skin_slim.geo.json" : "flesh_regen_right_arm_skin.geo.json";
                  this.renderSingleGeo(poseStack, buffer, packedLight, partialTick, skinGeo, this.getPlayerSkinTexture(), playerModel.rightArm);
               } else if (rightArmValue == -1 && rightHandValue >= 0 && rightHandValue <= 11) {
                  ResourceLocation armTexture = FleshRegenTextureManager.getRightArmTexture(18);
                  if (armTexture != null) {
                     String fleshGeo = isSlim ? "flesh_regen_right_arm_flesh_slim.geo.json" : "flesh_regen_right_arm_flesh.geo.json";
                     this.renderSingleGeo(poseStack, buffer, packedLight, partialTick, fleshGeo, armTexture, playerModel.rightArm);
                  }

                  String skinGeo = isSlim ? "flesh_regen_right_arm_skin_slim.geo.json" : "flesh_regen_right_arm_skin.geo.json";
                  this.renderSingleGeo(poseStack, buffer, packedLight, partialTick, skinGeo, this.getPlayerSkinTexture(), playerModel.rightArm);
               }

               if (rightHandValue >= 0 && rightHandValue <= 11) {
                  this.renderRightHandLayers(poseStack, buffer, packedLight, partialTick, rightHandValue, isSlim, playerModel.rightArm);
               }

               poseStack.popPose();
            }
         }
      }
   }

   private void renderRightArmLayers(
      PoseStack poseStack, MultiBufferSource buffer, int packedLight, float partialTick, int armValue, boolean isSlim, ModelPart armPart
   ) {
      ResourceLocation armTexture = FleshRegenTextureManager.getRightArmTexture(armValue);
      if (FleshRegenTextureManager.shouldRenderRightArmBone(armValue) && armTexture != null) {
         String boneGeo = isSlim ? "flesh_regen_right_arm_bone_slim.geo.json" : "flesh_regen_right_arm_bone.geo.json";
         this.renderSingleGeo(poseStack, buffer, packedLight, partialTick, boneGeo, armTexture, armPart);
      }

      if (FleshRegenTextureManager.shouldRenderRightArmFlesh(armValue) && armTexture != null) {
         String fleshGeo = isSlim ? "flesh_regen_right_arm_flesh_slim.geo.json" : "flesh_regen_right_arm_flesh.geo.json";
         this.renderSingleGeo(poseStack, buffer, packedLight, partialTick, fleshGeo, armTexture, armPart);
      }

      if (FleshRegenTextureManager.shouldRenderRightArmSkin(armValue)) {
         ResourceLocation skinTexture = this.getPlayerSkinTexture();
         if (skinTexture != null) {
            String skinGeo = isSlim ? "flesh_regen_right_arm_skin_slim.geo.json" : "flesh_regen_right_arm_skin.geo.json";
            this.renderSingleGeo(poseStack, buffer, packedLight, partialTick, skinGeo, skinTexture, armPart);
         }
      }
   }

   private void renderRightHandLayers(
      PoseStack poseStack, MultiBufferSource buffer, int packedLight, float partialTick, int handValue, boolean isSlim, ModelPart armPart
   ) {
      ResourceLocation handTexture = FleshRegenTextureManager.getRightHandTexture(handValue);
      if (FleshRegenTextureManager.shouldRenderRightHandBone(handValue) && handTexture != null) {
         String boneGeo = isSlim ? "flesh_regen_right_hand_bone_slim.geo.json" : "flesh_regen_right_hand_bone.geo.json";
         this.renderSingleGeo(poseStack, buffer, packedLight, partialTick, boneGeo, handTexture, armPart);
      }

      if (FleshRegenTextureManager.shouldRenderRightHandFlesh(handValue) && handTexture != null) {
         String fleshGeo = isSlim ? "flesh_regen_right_hand_flesh_slim.geo.json" : "flesh_regen_right_hand_flesh.geo.json";
         this.renderSingleGeo(poseStack, buffer, packedLight, partialTick, fleshGeo, handTexture, armPart);
      }

      if (FleshRegenTextureManager.shouldRenderRightHandSkin(handValue)) {
         ResourceLocation skinTexture = this.getPlayerSkinTexture();
         if (skinTexture != null) {
            String skinGeo = isSlim ? "flesh_regen_right_hand_skin_slim.geo.json" : "flesh_regen_right_hand_skin.geo.json";
            this.renderSingleGeo(poseStack, buffer, packedLight, partialTick, skinGeo, skinTexture, armPart);
         }
      }
   }

   private void renderSingleGeo(
      PoseStack poseStack, MultiBufferSource buffer, int packedLight, float partialTick, String geoFile, ResourceLocation texture, ModelPart armPart
   ) {
      this.geoModel.setCurrentGeoFile(geoFile);
      FleshRegenArmState state = new FleshRegenArmState();
      ResourceLocation modelRL = this.geoModel.getModelResource(state);
      BakedGeoModel bakedModel = this.getGeoModel().getBakedModel(modelRL);
      GeoBone rightArmBone = (GeoBone)this.getGeoModel().getBone("right_arm").orElse(null);
      if (rightArmBone != null && armPart != null) {
         this.syncModelPartToBone(armPart, rightArmBone);
      }

      RenderType type = RenderType.entityTranslucent(texture);
      VertexConsumer vc = buffer.getBuffer(type);
      if (rightArmBone != null) {
         this.renderRecursively(poseStack, state, rightArmBone, type, buffer, vc, false, partialTick, packedLight, OverlayTexture.NO_OVERLAY, -1);
      }
   }

   private void syncModelPartToBone(ModelPart from, GeoBone to) {
      if (from != null && to != null) {
         BoneSnapshot snapshot = to.getInitialSnapshot();
         to.setRotX(snapshot.getRotX());
         to.setRotY(snapshot.getRotY());
         to.setRotZ(snapshot.getRotZ());
         to.setPosX(0.0F);
         to.setPosY(0.0F);
         to.setPosZ(0.0F);
         to.setHidden(false);
      }
   }

   private ResourceLocation getPlayerSkinTexture() {
      return this.currentPlayer != null
         ? Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(this.currentPlayer).getTextureLocation(this.currentPlayer)
         : null;
   }

   private boolean isSlimModel(AbstractClientPlayer player) {
      return player.getSkin().model().id().equals("slim");
   }
}
