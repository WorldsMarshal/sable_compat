package com.invfix.vpower.client.animation;

import com.invfix.vpower.network.InjectVPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent.Pre;
import net.neoforged.neoforge.client.event.InputEvent.InteractionKeyMappingTriggered;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public class SyringeAnimationHandler {
   private static final int START_ANIM_TICKS = 6;
   private static final int INJECT_COMPLETE_TICKS = 40;
   private static boolean isPlaying = false;
   private static int animTick = 0;
   private static boolean injected = false;
   private static boolean holdingServer = false;
   private static String activeSyringeType = null;

   @SubscribeEvent
   public static void onUseInput(InteractionKeyMappingTriggered event) {
      if (event.isUseItem()) {
         Minecraft mc = Minecraft.getInstance();
         if (mc.player != null) {
            if (InjectVPacket.syringeTypeFromStack(mc.player.getMainHandItem()) != null) {
               event.setCanceled(true);
               event.setSwingHand(false);
            }
         }
      }
   }

   @SubscribeEvent
   public static void onClientTick(Pre event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null && mc.level != null && !mc.isPaused()) {
         LocalPlayer player = mc.player;
         ItemStack mainHandItem = player.getMainHandItem();
         String syringeType = InjectVPacket.syringeTypeFromStack(mainHandItem);
         boolean holdingSyringeUse = syringeType != null && mc.options.keyUse.isDown();
         if (!holdingSyringeUse) {
            reset(player);
         } else {
            if (isPlaying && syringeType.equals(activeSyringeType)) {
               animTick++;
            } else {
               start(player, syringeType);
            }

            holdingServer = true;
            PacketDistributor.sendToServer(new InjectVPacket(syringeType, "self_hold"), new CustomPacketPayload[0]);
            if (animTick == 6) {
               AnimationHelper.playAnimationWithFade(player, ModAnimations.INJECT_V_ON, 2, true, true);
            }

            if (animTick == 40 && !injected) {
               injected = true;
               AnimationHelper.playAnimationWithFade(player, ModAnimations.INJECT_V_UP, 2, false, true);
            }
         }
      } else {
         reset(mc.player);
      }
   }

   private static void start(LocalPlayer player, String syringeType) {
      AnimationHelper.playAnimationWithFade(player, ModAnimations.INJECT_V_START, 2, false, true);
      isPlaying = true;
      animTick = 0;
      injected = false;
      activeSyringeType = syringeType;
   }

   private static void reset(LocalPlayer player) {
      if (holdingServer && player != null) {
         String syringeType = activeSyringeType == null ? "" : activeSyringeType;
         PacketDistributor.sendToServer(new InjectVPacket(syringeType, "self_release"), new CustomPacketPayload[0]);
      }

      if (isPlaying && player != null) {
         AnimationHelper.stopAnimation(player, 5);
      }

      isPlaying = false;
      animTick = 0;
      injected = false;
      holdingServer = false;
      activeSyringeType = null;
   }
}
