package com.invfix.vpower.client.renderer.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Optional;
import com.invfix.vpower.client.fashionegg.EggShellClientHandler;
import com.invfix.vpower.client.invisibility.InvisibilityRenderHelper;
import com.invfix.vpower.client.toad.ToadClientHandler;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager.ControllerRegistrar;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoObjectRenderer;
import software.bernie.geckolib.util.GeckoLibUtil;

public class ToadBodyLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
   private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/custom/supertoad233/hm.png");
   private final ToadBodyLayer.ToadRenderer renderer = new ToadBodyLayer.ToadRenderer();

   public ToadBodyLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
      super(parent);
   }

   public void render(
      PoseStack poseStack,
      MultiBufferSource bufferSource,
      int packedLight,
      AbstractClientPlayer player,
      float limbSwing,
      float limbSwingAmount,
      float partialTick,
      float ageInTicks,
      float netHeadYaw,
      float headPitch
   ) {
      if (shouldRender(player)) {
         this.renderer.setPlayerModel((PlayerModel<AbstractClientPlayer>)this.getParentModel());
         this.renderer.renderOnPlayer(poseStack, bufferSource, packedLight, partialTick);
      }
   }

   private static boolean shouldRender(AbstractClientPlayer player) {
      return player != null
            && !player.isSpectator()
            && !player.isInvisible()
            && !InvisibilityRenderHelper.shouldHideBody(player)
            && !EggShellClientHandler.shouldHideBody(player)
         ? ToadClientHandler.hasToad(player)
         : false;
   }

   private static enum BodyPart {
      HEAD,
      BODY,
      RIGHT_ARM,
      LEFT_ARM,
      RIGHT_LEG,
      LEFT_LEG;
   }

   private static final class ToadAnimatable implements GeoAnimatable {
      private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

      public void registerControllers(ControllerRegistrar controllers) {
      }

      public AnimatableInstanceCache getAnimatableInstanceCache() {
         return this.cache;
      }

      public double getTick(Object object) {
         return 0.0;
      }
   }

   private static final class ToadModel extends GeoModel<ToadBodyLayer.ToadAnimatable> {
      public ResourceLocation getModelResource(ToadBodyLayer.ToadAnimatable animatable) {
         return ResourceLocation.fromNamespaceAndPath("theboysmod", "geo/custom/supertoad233/hm.geo.json");
      }

      public ResourceLocation getTextureResource(ToadBodyLayer.ToadAnimatable animatable) {
         return ToadBodyLayer.TEXTURE;
      }

      public ResourceLocation getAnimationResource(ToadBodyLayer.ToadAnimatable animatable) {
         return null;
      }
   }

   private static final class ToadRenderer extends GeoObjectRenderer<ToadBodyLayer.ToadAnimatable> {
      private static final ToadBodyLayer.ToadAnimatable INSTANCE = new ToadBodyLayer.ToadAnimatable();
      private static final float MODEL_Y_OFFSET = -1.5F;
      private static final float ARM_POS_X_OFFSET = 5.0F;
      private static final float ARM_POS_Y_OFFSET = 2.0F;
      private static final float LEG_POS_X_OFFSET = 2.0F;
      private static final float LEG_POS_Y_OFFSET = 12.0F;
      private PlayerModel<AbstractClientPlayer> playerModel;

      private ToadRenderer() {
         super(new ToadBodyLayer.ToadModel());
      }

      private void setPlayerModel(PlayerModel<AbstractClientPlayer> playerModel) {
         this.playerModel = playerModel;
      }

      private void renderOnPlayer(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick) {
         RenderType renderType = RenderType.entityTranslucent(ToadBodyLayer.TEXTURE);
         this.render(poseStack, INSTANCE, bufferSource, renderType, null, packedLight, partialTick);
      }

      public void preRender(
         PoseStack poseStack,
         ToadBodyLayer.ToadAnimatable animatable,
         BakedGeoModel model,
         @Nullable MultiBufferSource bufferSource,
         @Nullable VertexConsumer buffer,
         boolean isReRender,
         float partialTick,
         int packedLight,
         int packedOverlay,
         int colour
      ) {
         this.objectRenderTranslations = new Matrix4f(poseStack.last().pose());
         this.syncPlayerBones(model);
      }

      public void actuallyRender(
         PoseStack poseStack,
         ToadBodyLayer.ToadAnimatable animatable,
         BakedGeoModel model,
         @Nullable RenderType renderType,
         MultiBufferSource bufferSource,
         @Nullable VertexConsumer buffer,
         boolean isReRender,
         float partialTick,
         int packedLight,
         int packedOverlay,
         int colour
      ) {
         poseStack.pushPose();
         poseStack.scale(-1.0F, -1.0F, 1.0F);
         poseStack.translate(0.0F, -1.5F, 0.0F);
         poseStack.translate(0.0F, 0.01F, 0.0F);
         this.modelRenderTranslations = new Matrix4f(poseStack.last().pose());

         for (GeoBone bone : model.topLevelBones()) {
            this.renderRecursively(poseStack, animatable, bone, renderType, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, colour);
         }

         poseStack.popPose();
      }

      private void syncPlayerBones(BakedGeoModel model) {
         if (this.playerModel != null) {
            syncBone(model, this.playerModel.body, "body", ToadBodyLayer.BodyPart.BODY);
            syncBone(model, this.playerModel.head, "head", ToadBodyLayer.BodyPart.HEAD);
            syncBone(model, this.playerModel.rightArm, "right_arm", ToadBodyLayer.BodyPart.RIGHT_ARM);
            syncBone(model, this.playerModel.leftArm, "left_arm", ToadBodyLayer.BodyPart.LEFT_ARM);
            syncBone(model, this.playerModel.rightLeg, "right_leg", ToadBodyLayer.BodyPart.RIGHT_LEG);
            syncBone(model, this.playerModel.leftLeg, "left_leg", ToadBodyLayer.BodyPart.LEFT_LEG);
         }
      }

      private static void syncBone(BakedGeoModel model, ModelPart part, String boneName, ToadBodyLayer.BodyPart bodyPart) {
         Optional<GeoBone> optionalBone = model.getBone(boneName);
         if (!optionalBone.isEmpty()) {
            GeoBone bone = optionalBone.get();
            float x = part.x;
            float y = -part.y;
            float z = part.z;
            switch (bodyPart) {
               case BODY:
                  x = 0.0F;
                  break;
               case RIGHT_ARM:
                  x += 5.0F;
                  y += 2.0F;
                  break;
               case LEFT_ARM:
                  x -= 5.0F;
                  y += 2.0F;
                  break;
               case RIGHT_LEG:
                  x += 2.0F;
                  y += 12.0F;
                  break;
               case LEFT_LEG:
                  x -= 2.0F;
                  y += 12.0F;
            }

            bone.setPosX(x);
            bone.setPosY(y);
            bone.setPosZ(z);
            bone.setRotX(-part.xRot);
            bone.setRotY(-part.yRot);
            bone.setRotZ(part.zRot);
            bone.setScaleX(part.xScale);
            bone.setScaleY(part.yScale);
            bone.setScaleZ(part.zScale);
         }
      }
   }
}
