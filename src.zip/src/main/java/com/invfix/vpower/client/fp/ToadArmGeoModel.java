package com.invfix.vpower.client.fp;

import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class ToadArmGeoModel extends GeoModel<ToadArmState> {
   static final ResourceLocation MODEL = ResourceLocation.fromNamespaceAndPath("theboysmod", "geo/custom/supertoad233/hm.geo.json");
   static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/custom/supertoad233/hm.png");

   public ResourceLocation getModelResource(ToadArmState animatable) {
      return MODEL;
   }

   public ResourceLocation getTextureResource(ToadArmState animatable) {
      return TEXTURE;
   }

   public ResourceLocation getAnimationResource(ToadArmState animatable) {
      return null;
   }
}
