package com.invfix.vpower.client.fp;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.HumanoidArm;
import software.bernie.geckolib.animation.state.BoneSnapshot;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoObjectRenderer;

public class ToadArmGeoRenderer extends GeoObjectRenderer<ToadArmState> {
   private static final ToadArmState STATE = new ToadArmState();

   public ToadArmGeoRenderer() {
      super(new ToadArmGeoModel());
   }

   public void renderArm(
      PoseStack poseStack,
      MultiBufferSource buffer,
      int packedLight,
      float partialTick,
      AbstractClientPlayer player,
      PlayerModel<AbstractClientPlayer> playerModel,
      HumanoidArm arm
   ) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null && mc.player.getUUID().equals(player.getUUID()) && mc.options.getCameraType().isFirstPerson()) {
         this.getGeoModel().getBakedModel(ToadArmGeoModel.MODEL);
         GeoBone target = (GeoBone)this.getGeoModel().getBone(arm == HumanoidArm.RIGHT ? "right_arm" : "left_arm").orElse(null);
         if (target != null) {
            syncArmBone(target);
            resetParents(target);
            poseStack.pushPose();
            poseStack.translate(0.0F, 1.5F, 0.0F);
            poseStack.scale(-1.0F, -1.0F, 1.0F);
            RenderType renderType = RenderType.entityTranslucent(ToadArmGeoModel.TEXTURE);
            VertexConsumer vertexConsumer = buffer.getBuffer(renderType);
            this.renderRecursively(poseStack, STATE, target, renderType, buffer, vertexConsumer, false, partialTick, packedLight, OverlayTexture.NO_OVERLAY, -1);
            poseStack.popPose();
         }
      }
   }

   private static void syncArmBone(GeoBone target) {
      BoneSnapshot snapshot = target.getInitialSnapshot();
      target.setRotX(snapshot.getRotX());
      target.setRotY(snapshot.getRotY());
      target.setRotZ(snapshot.getRotZ());
      target.setPosX(0.0F);
      target.setPosY(0.0F);
      target.setPosZ(0.0F);
      target.setScaleX(snapshot.getScaleX());
      target.setScaleY(snapshot.getScaleY());
      target.setScaleZ(snapshot.getScaleZ());
      target.setHidden(false);
   }

   private static void resetParents(GeoBone bone) {
      for (GeoBone parent = bone.getParent(); parent != null; parent = parent.getParent()) {
         BoneSnapshot snapshot = parent.getInitialSnapshot();
         parent.setRotX(snapshot.getRotX());
         parent.setRotY(snapshot.getRotY());
         parent.setRotZ(snapshot.getRotZ());
         parent.setPosX(0.0F);
         parent.setPosY(0.0F);
         parent.setPosZ(0.0F);
         parent.setScaleX(snapshot.getScaleX());
         parent.setScaleY(snapshot.getScaleY());
         parent.setScaleZ(snapshot.getScaleZ());
         parent.setHidden(false);
      }
   }
}
