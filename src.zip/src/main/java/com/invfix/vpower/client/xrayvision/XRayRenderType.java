package com.invfix.vpower.client.xrayvision;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import java.util.Optional;
import com.invfix.vpower.mixin.client.XRayCompositeRenderTypeAccessor;
import com.invfix.vpower.mixin.client.XRayCompositeStateAccessor;
import com.invfix.vpower.mixin.client.XRayTextureStateAccessor;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.RenderStateShard.EmptyTextureStateShard;
import net.minecraft.client.renderer.RenderStateShard.TextureStateShard;
import net.minecraft.client.renderer.RenderType.CompositeState;
import net.minecraft.resources.ResourceLocation;

public class XRayRenderType extends RenderStateShard {
   private static final ResourceLocation WHITE_TEXTURE = ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/misc/white.png");
   public static final RenderType XRAY_ENTITY = createXRayEntity(WHITE_TEXTURE);

   public static RenderType entity(RenderType original) {
      return XRAY_ENTITY;
   }

   public static boolean shouldUseOutlineOnly(RenderType original) {
      Optional<ResourceLocation> texture = resolveTexture(original);
      String name = original.name;
      String path = texture.<String>map(ResourceLocation::getPath).orElse("");
      return name.contains("item")
         || name.contains("glint")
         || name.contains("sheet")
         || path.startsWith("textures/atlas/")
         || path.startsWith("textures/item/")
         || path.contains("/item/")
         || path.startsWith("textures/models/cape/");
   }

   public static Optional<RenderType> outline(RenderType original) {
      Optional<RenderType> outline = original.outline();
      return outline.isPresent() ? outline : resolveTexture(original).map(RenderType::outline);
   }

   public static Optional<ResourceLocation> resolveTexture(RenderType original) {
      if (original instanceof XRayCompositeRenderTypeAccessor compositeAccessor) {
         try {
            CompositeState state = compositeAccessor.theboysmod$getState();
            XRayCompositeStateAccessor stateAccessor = (XRayCompositeStateAccessor)(Object)state;
            EmptyTextureStateShard textureState = stateAccessor.theboysmod$getTextureState();
            XRayTextureStateAccessor textureAccessor = (XRayTextureStateAccessor)(Object)textureState;
            return textureAccessor.theboysmod$cutoutTexture();
         } catch (RuntimeException var6) {
            return Optional.empty();
         }
      } else {
         return Optional.empty();
      }
   }

   private static RenderType createXRayEntity(ResourceLocation texture) {
      return RenderType.create(
         "theboysmod_xray_entity",
         DefaultVertexFormat.NEW_ENTITY,
         Mode.QUADS,
         1536,
         false,
         true,
         CompositeState.builder()
            .setShaderState(RENDERTYPE_ENTITY_TRANSLUCENT_EMISSIVE_SHADER)
            .setTextureState(new TextureStateShard(texture, false, false))
            .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
            .setDepthTestState(NO_DEPTH_TEST)
            .setCullState(NO_CULL)
            .setLightmapState(LIGHTMAP)
            .setOverlayState(OVERLAY)
            .setWriteMaskState(COLOR_WRITE)
            .createCompositeState(false)
      );
   }

   private XRayRenderType() {
      super(null, null, null);
   }
}
