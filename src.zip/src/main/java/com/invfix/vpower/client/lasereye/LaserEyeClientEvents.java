package com.invfix.vpower.client.lasereye;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public class LaserEyeClientEvents {
   @SubscribeEvent
   public static void onClientTick(Post event) {
      LaserEyeClientHandler.clientTick();
   }

   @SubscribeEvent
   public static void onRenderPlayerPost(net.neoforged.neoforge.client.event.RenderPlayerEvent.Post event) {
      LaserEyeRenderer.renderInPlayerEvent(event);
   }

   @SubscribeEvent
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      if (event.getStage() == Stage.AFTER_TRANSLUCENT_BLOCKS) {
         float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
         LaserEyeRenderer.renderAll(event.getPoseStack(), partialTick);
         LaserEyeRenderer.renderAllRemotePlayers(event.getPoseStack(), partialTick);
      }
   }
}
