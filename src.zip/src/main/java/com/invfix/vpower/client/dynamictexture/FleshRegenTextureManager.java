package com.invfix.vpower.client.dynamictexture;

import com.mojang.blaze3d.platform.NativeImage;
import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import com.invfix.vpower.VPower;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import org.jetbrains.annotations.Nullable;

public class FleshRegenTextureManager {
   private static final Map<String, ResourceLocation> cachedTextures = new HashMap<>();
   private static final String BASE_PATH = "textures/models/flesh_regen/body_layer.png";

   @Nullable
   public static ResourceLocation getHeadTexture(int headValue) {
      return headValue >= 0 && headValue <= 16
         ? getDynamicTexture("textures/models/flesh_regen/body_layer.png", "textures/alpha_mask/flesh_regen/head/head_", headValue)
         : null;
   }

   public static boolean shouldRenderHeadBone(int headValue) {
      return headValue >= 0 && headValue < 10;
   }

   public static boolean shouldRenderHeadFlesh(int headValue) {
      return headValue >= 0 && headValue < 16;
   }

   public static boolean shouldRenderHeadSkin(int headValue) {
      return headValue >= 10 && headValue <= 16;
   }

   public static boolean shouldHidePlayerHead(int headValue) {
      return headValue >= 0 && headValue <= 16;
   }

   public static ResourceLocation getHeadBoneTexture(int headValue) {
      return getHeadTexture(headValue);
   }

   public static ResourceLocation getHeadFleshTexture(int headValue) {
      return getHeadTexture(headValue);
   }

   @Nullable
   public static ResourceLocation getBodyTexture(int bodyValue) {
      return bodyValue >= 0 && bodyValue <= 19
         ? getDynamicTexture("textures/models/flesh_regen/body_layer.png", "textures/alpha_mask/flesh_regen/chest/chest_", bodyValue)
         : null;
   }

   public static boolean shouldRenderBodyBone(int bodyValue) {
      return bodyValue >= 0 && bodyValue < 13;
   }

   public static boolean shouldRenderBodyFlesh(int bodyValue) {
      return bodyValue >= 0 && bodyValue < 19;
   }

   public static boolean shouldRenderBodySkin(int bodyValue) {
      return bodyValue >= 13 && bodyValue <= 19;
   }

   public static boolean shouldHidePlayerBody(int bodyValue) {
      return bodyValue >= 0 && bodyValue <= 19;
   }

   @Nullable
   public static ResourceLocation getRightArmTexture(int armValue) {
      return armValue >= 0 && armValue < 18
         ? getDynamicTexture("textures/models/flesh_regen/body_layer.png", "textures/alpha_mask/flesh_regen/arms/arms_", armValue)
         : null;
   }

   public static boolean shouldRenderRightArmBone(int armValue) {
      return armValue >= 0 && armValue < 11;
   }

   public static boolean shouldRenderRightArmFlesh(int armValue) {
      return armValue >= 0 && armValue < 18;
   }

   public static boolean shouldRenderRightArmSkin(int armValue) {
      return armValue >= 11 && armValue <= 17;
   }

   public static boolean shouldHidePlayerRightArm(int armValue) {
      return armValue >= 0 && armValue <= 17;
   }

   @Nullable
   public static ResourceLocation getRightHandTexture(int handValue) {
      return handValue >= 0 && handValue <= 11
         ? getDynamicTexture("textures/models/flesh_regen/body_layer.png", "textures/alpha_mask/flesh_regen/hands/hands_", handValue)
         : null;
   }

   public static boolean shouldRenderRightHandBone(int handValue) {
      return handValue >= 0 && handValue < 7;
   }

   public static boolean shouldRenderRightHandFlesh(int handValue) {
      return handValue >= 0 && handValue < 11;
   }

   public static boolean shouldRenderRightHandSkin(int handValue) {
      return handValue >= 7 && handValue <= 11;
   }

   public static boolean shouldHidePlayerRightHand(int handValue) {
      return handValue >= 0 && handValue <= 11;
   }

   @Nullable
   public static ResourceLocation getLeftArmTexture(int armValue) {
      return armValue >= 0 && armValue < 18
         ? getDynamicTexture("textures/models/flesh_regen/body_layer.png", "textures/alpha_mask/flesh_regen/arms/arms_", armValue)
         : null;
   }

   public static boolean shouldRenderLeftArmBone(int armValue) {
      return armValue >= 0 && armValue < 11;
   }

   public static boolean shouldRenderLeftArmFlesh(int armValue) {
      return armValue >= 0 && armValue < 18;
   }

   public static boolean shouldRenderLeftArmSkin(int armValue) {
      return armValue >= 11 && armValue <= 17;
   }

   public static boolean shouldHidePlayerLeftArm(int armValue) {
      return armValue >= 0 && armValue <= 17;
   }

   @Nullable
   public static ResourceLocation getLeftHandTexture(int handValue) {
      return handValue >= 0 && handValue <= 11
         ? getDynamicTexture("textures/models/flesh_regen/body_layer.png", "textures/alpha_mask/flesh_regen/hands/hands_", handValue)
         : null;
   }

   public static boolean shouldRenderLeftHandBone(int handValue) {
      return handValue >= 0 && handValue < 7;
   }

   public static boolean shouldRenderLeftHandFlesh(int handValue) {
      return handValue >= 0 && handValue < 11;
   }

   public static boolean shouldRenderLeftHandSkin(int handValue) {
      return handValue >= 7 && handValue <= 11;
   }

   public static boolean shouldHidePlayerLeftHand(int handValue) {
      return handValue >= 0 && handValue <= 11;
   }

   @Nullable
   public static ResourceLocation getLegsTexture(int legsValue) {
      return legsValue >= 0 && legsValue < 20
         ? getDynamicTexture("textures/models/flesh_regen/body_layer.png", "textures/alpha_mask/flesh_regen/legs/legs_", legsValue)
         : null;
   }

   public static boolean shouldRenderLegsBone(int legsValue) {
      return legsValue >= 0 && legsValue < 12;
   }

   public static boolean shouldRenderLegsFlesh(int legsValue) {
      return legsValue >= 0 && legsValue < 20;
   }

   public static boolean shouldRenderLegsSkin(int legsValue) {
      return legsValue >= 12 && legsValue <= 19;
   }

   public static boolean shouldHidePlayerLegs(int legsValue) {
      return legsValue >= 0 && legsValue <= 19;
   }

   @Nullable
   public static ResourceLocation getFeetTexture(int feetValue) {
      return feetValue >= 0 && feetValue <= 10
         ? getDynamicTexture("textures/models/flesh_regen/body_layer.png", "textures/alpha_mask/flesh_regen/feet/feet_", feetValue)
         : null;
   }

   public static boolean shouldRenderFeetBone(int feetValue) {
      return feetValue >= 0 && feetValue < 5;
   }

   public static boolean shouldRenderFeetFlesh(int feetValue) {
      return feetValue >= 0 && feetValue < 10;
   }

   public static boolean shouldRenderFeetSkin(int feetValue) {
      return feetValue >= 5 && feetValue <= 10;
   }

   public static boolean shouldHidePlayerFeet(int feetValue) {
      return feetValue >= 0 && feetValue <= 10;
   }

   public static ResourceLocation getDynamicTexture(String basePath, String maskPath, int frameIndex) {
      String cacheKey = basePath + "_" + maskPath + "_" + frameIndex;
      if (cachedTextures.containsKey(cacheKey)) {
         return cachedTextures.get(cacheKey);
      } else {
         try {
            ResourceLocation baseLocation = ResourceLocation.fromNamespaceAndPath("theboysmod", basePath);
            ResourceLocation maskLocation = ResourceLocation.fromNamespaceAndPath("theboysmod", maskPath + frameIndex + ".png");
            ResourceLocation dynamicLocation = createMaskedTexture(baseLocation, maskLocation, cacheKey);
            if (dynamicLocation != null) {
               cachedTextures.put(cacheKey, dynamicLocation);
               return dynamicLocation;
            }
         } catch (Exception var7) {
            VPower.LOGGER.error("Failed to create dynamic texture: {}", cacheKey, var7);
         }

         return ResourceLocation.fromNamespaceAndPath("theboysmod", basePath);
      }
   }

   @Nullable
   private static ResourceLocation createMaskedTexture(ResourceLocation baseLocation, ResourceLocation maskLocation, String cacheKey) {
      ResourceManager resourceManager = Minecraft.getInstance().getResourceManager();

      try {
         NativeImage baseImage = loadImage(resourceManager, baseLocation);
         if (baseImage == null) {
            VPower.LOGGER.warn("Base image not found: {}", baseLocation);
            return null;
         } else {
            NativeImage maskImage = loadImage(resourceManager, maskLocation);
            if (maskImage == null) {
               VPower.LOGGER.warn("Mask image not found: {}", maskLocation);
               baseImage.close();
               return null;
            } else {
               applyAlphaMask(baseImage, maskImage);
               maskImage.close();
               DynamicTexture dynamicTexture = new DynamicTexture(baseImage);
               ResourceLocation dynamicLocation = ResourceLocation.fromNamespaceAndPath("theboysmod", "dynamic/flesh_" + Math.abs(cacheKey.hashCode()));
               Minecraft.getInstance().getTextureManager().register(dynamicLocation, dynamicTexture);
               return dynamicLocation;
            }
         }
      } catch (Exception var8) {
         VPower.LOGGER.error("Error creating masked texture", var8);
         return null;
      }
   }

   @Nullable
   private static NativeImage loadImage(ResourceManager resourceManager, ResourceLocation location) {
      try {
         Optional<Resource> resource = resourceManager.getResource(location);
         if (resource.isEmpty()) {
            return null;
         } else {
            NativeImage var4;
            try (InputStream stream = resource.get().open()) {
               var4 = NativeImage.read(stream);
            }

            return var4;
         }
      } catch (IOException var8) {
         VPower.LOGGER.warn("Failed to load image: {}", location);
         return null;
      }
   }

   private static void applyAlphaMask(NativeImage texture, NativeImage overlay) {
      for (int y = 0; y < overlay.getHeight(); y++) {
         for (int x = 0; x < overlay.getWidth(); x++) {
            int pixelOrig = texture.getPixelRGBA(x, y);
            int pixelMask = overlay.getPixelRGBA(x, y);
            if (pixelOrig != 0) {
               Color colorMask = new Color(pixelMask, true);
               Color colorOrig = new Color(pixelOrig, true);
               float brightness = (float)(colorMask.getRed() + colorMask.getGreen() + colorMask.getBlue()) / 3.0F / 255.0F;
               float showFactor = 1.0F - brightness;
               float maskAlpha = (float)colorMask.getAlpha() / 255.0F;
               float factor = showFactor * maskAlpha;
               int newAlpha = (int)((float)colorOrig.getAlpha() * factor);
               Color newColor = new Color(colorOrig.getRed(), colorOrig.getGreen(), colorOrig.getBlue(), newAlpha);
               texture.setPixelRGBA(x, y, newColor.getRGB());
            }
         }
      }
   }

   public static void clearCache() {
      cachedTextures.clear();
   }

   public static ResourceLocation getBodyPartTexture(String bodyPart, int nbtValue) {
      String maskPath = "textures/alpha_mask/flesh_regen/" + bodyPart + "/" + bodyPart + "_";
      return getDynamicTexture("textures/models/flesh_regen/body_layer.png", maskPath, nbtValue);
   }
}
