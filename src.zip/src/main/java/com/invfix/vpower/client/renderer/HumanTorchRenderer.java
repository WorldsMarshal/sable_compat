package com.invfix.vpower.client.renderer;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import java.util.Optional;
import java.util.function.Function;
import com.invfix.vpower.client.dynamictexture.HumanTorchTextureManager;
import net.minecraft.Util;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.RenderStateShard.TextureStateShard;
import net.minecraft.client.renderer.RenderType.CompositeState;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager.ControllerRegistrar;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoObjectRenderer;
import software.bernie.geckolib.util.GeckoLibUtil;

public class HumanTorchRenderer extends GeoObjectRenderer<HumanTorchRenderer.VirtualHumanTorch> {
   public static final float MODEL_Y_OFFSET = -1.5F;
   private static final Function<ResourceLocation, RenderType> TRANSLUCENT_NO_DEPTH = Util.memoize(
      texture -> {
         CompositeState state = CompositeState.builder()
            .setShaderState(RenderStateShard.RENDERTYPE_ENTITY_TRANSLUCENT_SHADER)
            .setTextureState(new TextureStateShard(texture, false, false))
            .setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY)
            .setCullState(RenderStateShard.NO_CULL)
            .setLightmapState(RenderStateShard.LIGHTMAP)
            .setOverlayState(RenderStateShard.OVERLAY)
            .setWriteMaskState(RenderStateShard.COLOR_WRITE)
            .createCompositeState(true);
         return RenderType.create("theboysmod:entity_translucent_no_depth", DefaultVertexFormat.NEW_ENTITY, Mode.QUADS, 256, true, true, state);
      }
   );
   private static final Function<ResourceLocation, RenderType> TRANSLUCENT_NO_DEPTH_TEST = Util.memoize(
      texture -> {
         CompositeState state = CompositeState.builder()
            .setShaderState(RenderStateShard.RENDERTYPE_ENTITY_TRANSLUCENT_SHADER)
            .setTextureState(new TextureStateShard(texture, false, false))
            .setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY)
            .setCullState(RenderStateShard.NO_CULL)
            .setLightmapState(RenderStateShard.LIGHTMAP)
            .setOverlayState(RenderStateShard.OVERLAY)
            .setDepthTestState(RenderStateShard.NO_DEPTH_TEST)
            .setWriteMaskState(RenderStateShard.COLOR_WRITE)
            .createCompositeState(true);
         return RenderType.create("theboysmod:entity_no_depth_test", DefaultVertexFormat.NEW_ENTITY, Mode.QUADS, 256, true, true, state);
      }
   );
   public static final float HEAD_POS_X_SCALE = 1.0F;
   public static final float HEAD_POS_Y_OFFSET = 0.0F;
   public static final float HEAD_POS_Z_OFFSET = 0.0F;
   public static final float BODY_POS_X_SCALE = 0.0F;
   public static final float BODY_POS_Y_OFFSET = 0.0F;
   public static final float BODY_POS_Z_OFFSET = 0.0F;
   public static final float ARM_POS_X_SCALE = 1.0F;
   public static final float ARM_POS_X_OFFSET = 5.0F;
   public static final float ARM_POS_Y_OFFSET = 2.0F;
   public static final float ARM_POS_Z_OFFSET = 0.0F;
   public static final float LEG_POS_X_SCALE = 1.0F;
   public static final float LEG_POS_X_OFFSET = 2.0F;
   public static final float LEG_POS_Y_OFFSET = 12.0F;
   public static final float LEG_POS_Z_OFFSET = 0.0F;
   private PlayerModel<AbstractClientPlayer> currentPlayerModel;
   private HumanoidModel<?> currentHumanoidModel;
   private LivingEntity currentEntity;
   private static final HumanTorchRenderer.VirtualHumanTorch VIRTUAL_INSTANCE = new HumanTorchRenderer.VirtualHumanTorch();

   public static RenderType getTranslucent(ResourceLocation texture) {
      return TRANSLUCENT_NO_DEPTH.apply(texture);
   }

   public static RenderType getTranslucentNoDepthTest(ResourceLocation texture) {
      return TRANSLUCENT_NO_DEPTH_TEST.apply(texture);
   }

   public HumanTorchRenderer() {
      super(new HumanTorchRenderer.HumanTorchGeoModel());
   }

   public void setPlayerModel(PlayerModel<AbstractClientPlayer> model) {
      this.currentPlayerModel = model;
      this.currentHumanoidModel = model;
   }

   public void setHumanoidModel(HumanoidModel<?> model) {
      this.currentHumanoidModel = model;
   }

   public void renderHumanTorch(LivingEntity entity, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int timerValue) {
      if (entity != null && !entity.isSpectator() && this.currentHumanoidModel != null) {
         this.currentEntity = entity;
         if (HumanTorchTextureManager.shouldRenderBody(timerValue)) {
            ResourceLocation texture = HumanTorchTextureManager.getTexture(timerValue);
            if (texture != null) {
               boolean slim = false;
               if (entity instanceof AbstractClientPlayer clientPlayer) {
                  slim = clientPlayer.getSkin().model().id().equals("slim");
               }

               String geoFile = slim ? "human_torch_body_slim.geo.json" : "human_torch_body.geo.json";
               ((HumanTorchRenderer.HumanTorchGeoModel)this.model).setCurrentGeoFile(geoFile);
               RenderType renderType = TRANSLUCENT_NO_DEPTH.apply(texture);
               this.render(poseStack, VIRTUAL_INSTANCE, bufferSource, renderType, null, packedLight, partialTick);
            }
         }
      }
   }

   public void preRender(
      PoseStack poseStack,
      HumanTorchRenderer.VirtualHumanTorch animatable,
      BakedGeoModel model,
      @Nullable MultiBufferSource bufferSource,
      @Nullable VertexConsumer buffer,
      boolean isReRender,
      float partialTick,
      int packedLight,
      int packedOverlay,
      int colour
   ) {
      this.objectRenderTranslations = new Matrix4f(poseStack.last().pose());
      this.setupBoneMatching(model);
   }

   public void actuallyRender(
      PoseStack poseStack,
      HumanTorchRenderer.VirtualHumanTorch animatable,
      BakedGeoModel model,
      @Nullable RenderType renderType,
      MultiBufferSource bufferSource,
      @Nullable VertexConsumer buffer,
      boolean isReRender,
      float partialTick,
      int packedLight,
      int packedOverlay,
      int colour
   ) {
      poseStack.pushPose();
      boolean isPlayer = this.currentEntity instanceof Player;
      if (isPlayer) {
         poseStack.scale(-1.0F, -1.0F, 1.0F);
         poseStack.translate(0.0F, -1.5F, 0.0F);
      } else {
         poseStack.scale(1.0F, -1.0F, 1.0F);
         poseStack.translate(0.0F, -1.5F, 0.0F);
      }

      poseStack.translate(0.0F, 0.01F, 0.0F);
      this.modelRenderTranslations = new Matrix4f(poseStack.last().pose());
      int glowLight = 15728880;

      for (GeoBone bone : model.topLevelBones()) {
         this.renderRecursively(poseStack, animatable, bone, renderType, bufferSource, buffer, isReRender, partialTick, glowLight, packedOverlay, colour);
      }

      poseStack.popPose();
   }

   private void setupBoneMatching(BakedGeoModel model) {
      HumanoidModel<?> modelToUse = (HumanoidModel<?>)(this.currentPlayerModel != null ? this.currentPlayerModel : this.currentHumanoidModel);
      if (modelToUse != null) {
         this.matchBonePart(model, modelToUse.head, "armorHead", "head");
         this.matchBonePart(model, modelToUse.body, "armorBody", "body");
         this.matchBonePart(model, modelToUse.rightArm, "armorRightArm", "right_arm");
         this.matchBonePart(model, modelToUse.leftArm, "armorLeftArm", "left_arm");
         this.matchBonePart(model, modelToUse.rightLeg, "armorRightLeg", "right_leg");
         this.matchBonePart(model, modelToUse.leftLeg, "armorLeftLeg", "left_leg");
      }
   }

   private void matchBonePart(BakedGeoModel model, ModelPart part, String boneName, String partType) {
      Optional<GeoBone> optionalBone = model.getBone(boneName);
      if (!optionalBone.isEmpty()) {
         GeoBone bone = optionalBone.get();
         boolean isPlayer = this.currentEntity instanceof Player;
         float yRotSign = isPlayer ? -1.0F : 1.0F;
         float zRotSign = isPlayer ? 1.0F : -1.0F;
         switch (partType) {
            case "head":
               bone.setPosX(part.x * 1.0F);
               bone.setPosY(-part.y + 0.0F);
               bone.setPosZ(part.z + 0.0F);
               bone.setRotX(-part.xRot);
               bone.setRotY(yRotSign * part.yRot);
               bone.setRotZ(zRotSign * part.zRot);
               break;
            case "body":
               bone.setPosX(part.x * 0.0F);
               bone.setPosY(-part.y + 0.0F);
               bone.setPosZ(part.z + 0.0F);
               bone.setRotX(-part.xRot);
               bone.setRotY(yRotSign * part.yRot);
               bone.setRotZ(zRotSign * part.zRot);
               break;
            case "right_arm":
            case "left_arm":
               float armXCalc = part.x * 1.0F;
               armXCalc += "right_arm".equals(partType) ? 5.0F : -5.0F;
               bone.setPosX(armXCalc);
               bone.setPosY(-part.y + 2.0F);
               bone.setPosZ(part.z + 0.0F);
               bone.setRotX(-part.xRot);
               bone.setRotY(yRotSign * part.yRot);
               bone.setRotZ(zRotSign * part.zRot);
               break;
            case "right_leg":
            case "left_leg":
               float legXCalc = part.x * 1.0F;
               legXCalc += "right_leg".equals(partType) ? 2.0F : -2.0F;
               bone.setPosX(legXCalc);
               bone.setPosY(-part.y + 12.0F);
               bone.setPosZ(part.z + 0.0F);
               bone.setRotX(-part.xRot);
               bone.setRotY(yRotSign * part.yRot);
               bone.setRotZ(zRotSign * part.zRot);
               break;
            default:
               bone.setPosX(-part.x);
               bone.setPosY(-part.y);
               bone.setPosZ(part.z);
               bone.setRotX(-part.xRot);
               bone.setRotY(yRotSign * part.yRot);
               bone.setRotZ(zRotSign * part.zRot);
         }
      }
   }

   private static class HumanTorchGeoModel extends GeoModel<HumanTorchRenderer.VirtualHumanTorch> {
      private String currentGeoFile = "human_torch_body.geo.json";

      public void setCurrentGeoFile(String geoFile) {
         this.currentGeoFile = geoFile;
      }

      public ResourceLocation getModelResource(HumanTorchRenderer.VirtualHumanTorch animatable) {
         return ResourceLocation.fromNamespaceAndPath("theboysmod", "geo/human_torch/" + this.currentGeoFile);
      }

      public ResourceLocation getTextureResource(HumanTorchRenderer.VirtualHumanTorch animatable) {
         return ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/models/human_torch/human_torch_body.png");
      }

      public ResourceLocation getAnimationResource(HumanTorchRenderer.VirtualHumanTorch animatable) {
         return null;
      }
   }

   public static class VirtualHumanTorch implements GeoAnimatable {
      private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

      public void registerControllers(ControllerRegistrar controllers) {
      }

      public AnimatableInstanceCache getAnimatableInstanceCache() {
         return this.cache;
      }

      public double getTick(Object object) {
         return 0.0;
      }
   }
}
