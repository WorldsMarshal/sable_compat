package com.invfix.vpower.client.fp;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager.ControllerRegistrar;
import software.bernie.geckolib.animation.state.BoneSnapshot;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoObjectRenderer;
import software.bernie.geckolib.util.GeckoLibUtil;

public class BelialArmGeoRenderer {
   private static final ResourceLocation BODY_MODEL = ResourceLocation.fromNamespaceAndPath("theboysmod", "geo/transform/nailong_belial/long_belial.geo.json");
   private static final ResourceLocation BODY_TEXTURE = ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/transform/nailong_belial/long_belial.png");
   private static final ResourceLocation TRANSFORMER_MODEL = ResourceLocation.fromNamespaceAndPath(
      "theboysmod", "geo/transformer/ultraman_belial/normal/belial_transformer.geo.json"
   );
   private static final ResourceLocation TRANSFORMER_TEXTURE = ResourceLocation.fromNamespaceAndPath(
      "theboysmod", "textures/transformer/ultraman_belial/normal/belial_transformer.png"
   );
   private final BelialArmGeoRenderer.SingleArmRenderer bodyRenderer = new BelialArmGeoRenderer.SingleArmRenderer(
      new BelialArmGeoRenderer.StaticArmModel(BODY_MODEL, BODY_TEXTURE), BODY_MODEL, BODY_TEXTURE
   );
   private final BelialArmGeoRenderer.SingleArmRenderer transformerRenderer = new BelialArmGeoRenderer.SingleArmRenderer(
      new BelialArmGeoRenderer.StaticArmModel(TRANSFORMER_MODEL, TRANSFORMER_TEXTURE), TRANSFORMER_MODEL, TRANSFORMER_TEXTURE
   );

   public void renderBodyArm(PoseStack poseStack, MultiBufferSource buffer, int packedLight, float partialTick, AbstractClientPlayer player, HumanoidArm arm) {
      if (isLocalFirstPerson(player)) {
         this.bodyRenderer.renderArmBone(poseStack, buffer, packedLight, partialTick, arm == HumanoidArm.RIGHT ? "right_arm" : "left_arm");
      }
   }

   public void renderTransformer(
      PoseStack poseStack, MultiBufferSource buffer, int packedLight, float partialTick, AbstractClientPlayer player, HumanoidArm arm
   ) {
      if (arm == HumanoidArm.RIGHT && isLocalFirstPerson(player)) {
         this.transformerRenderer.renderArmBone(poseStack, buffer, packedLight, partialTick, "right_arm");
      }
   }

   private static boolean isLocalFirstPerson(AbstractClientPlayer player) {
      Minecraft mc = Minecraft.getInstance();
      return player != null && mc.player != null && mc.player.getUUID().equals(player.getUUID()) && mc.options.getCameraType().isFirstPerson();
   }

   private static final class BelialArmState implements GeoAnimatable {
      private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

      public void registerControllers(ControllerRegistrar controllers) {
      }

      public AnimatableInstanceCache getAnimatableInstanceCache() {
         return this.cache;
      }

      public double getTick(Object object) {
         return 0.0;
      }
   }

   private static final class SingleArmRenderer extends GeoObjectRenderer<BelialArmGeoRenderer.BelialArmState> {
      private static final BelialArmGeoRenderer.BelialArmState STATE = new BelialArmGeoRenderer.BelialArmState();
      private final ResourceLocation modelLocation;
      private final ResourceLocation textureLocation;

      private SingleArmRenderer(GeoModel<BelialArmGeoRenderer.BelialArmState> model, ResourceLocation modelLocation, ResourceLocation textureLocation) {
         super(model);
         this.modelLocation = modelLocation;
         this.textureLocation = textureLocation;
      }

      private void renderArmBone(PoseStack poseStack, MultiBufferSource buffer, int packedLight, float partialTick, String boneName) {
         this.getGeoModel().getBakedModel(this.modelLocation);
         GeoBone target = (GeoBone)this.getGeoModel().getBone(boneName).orElse(null);
         if (target != null) {
            resetBone(target);
            resetParents(target);
            poseStack.pushPose();
            poseStack.translate(0.0F, 1.5F, 0.0F);
            poseStack.scale(-1.0F, -1.0F, 1.0F);
            RenderType renderType = RenderType.entityTranslucent(this.textureLocation);
            VertexConsumer vertexConsumer = buffer.getBuffer(renderType);
            this.renderRecursively(poseStack, STATE, target, renderType, buffer, vertexConsumer, false, partialTick, packedLight, OverlayTexture.NO_OVERLAY, -1);
            poseStack.popPose();
         }
      }

      private static void resetBone(GeoBone bone) {
         BoneSnapshot snapshot = bone.getInitialSnapshot();
         bone.setRotX(snapshot.getRotX());
         bone.setRotY(snapshot.getRotY());
         bone.setRotZ(snapshot.getRotZ());
         bone.setPosX(0.0F);
         bone.setPosY(0.0F);
         bone.setPosZ(0.0F);
         bone.setScaleX(snapshot.getScaleX());
         bone.setScaleY(snapshot.getScaleY());
         bone.setScaleZ(snapshot.getScaleZ());
         bone.setHidden(false);
      }

      private static void resetParents(GeoBone bone) {
         for (GeoBone parent = bone.getParent(); parent != null; parent = parent.getParent()) {
            resetBone(parent);
         }
      }
   }

   private static final class StaticArmModel extends GeoModel<BelialArmGeoRenderer.BelialArmState> {
      private final ResourceLocation model;
      private final ResourceLocation texture;

      private StaticArmModel(ResourceLocation model, ResourceLocation texture) {
         this.model = model;
         this.texture = texture;
      }

      public ResourceLocation getModelResource(BelialArmGeoRenderer.BelialArmState animatable) {
         return this.model;
      }

      public ResourceLocation getTextureResource(BelialArmGeoRenderer.BelialArmState animatable) {
         return this.texture;
      }

      public ResourceLocation getAnimationResource(BelialArmGeoRenderer.BelialArmState animatable) {
         return null;
      }
   }
}
