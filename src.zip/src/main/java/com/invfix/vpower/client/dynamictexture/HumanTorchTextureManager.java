package com.invfix.vpower.client.dynamictexture;

import com.mojang.blaze3d.platform.NativeImage;
import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import com.invfix.vpower.VPower;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import org.jetbrains.annotations.Nullable;

public class HumanTorchTextureManager {
   private static final Map<String, ResourceLocation> cachedTextures = new HashMap<>();
   private static final String BASE_PATH = "textures/models/human_torch/human_torch_body.png";
   private static final String MASK_PREFIX = "textures/alpha_mask/human_torch_body/human_torch_body_";
   private static final int MAX_FRAME = 17;

   @Nullable
   public static ResourceLocation getTexture(int frameIndex) {
      return frameIndex >= 0 && frameIndex <= 17
         ? getDynamicTexture("textures/models/human_torch/human_torch_body.png", "textures/alpha_mask/human_torch_body/human_torch_body_", frameIndex)
         : null;
   }

   public static boolean shouldRenderBody(int timerValue) {
      return timerValue > 0 && timerValue <= 17;
   }

   public static boolean shouldHidePlayerOverlay(int timerValue) {
      return timerValue >= 16;
   }

   public static boolean isFullyTransformed(int timerValue) {
      return timerValue >= 17;
   }

   private static ResourceLocation getDynamicTexture(String basePath, String maskPath, int frameIndex) {
      String cacheKey = basePath + "_" + maskPath + "_" + frameIndex;
      if (cachedTextures.containsKey(cacheKey)) {
         return cachedTextures.get(cacheKey);
      } else {
         try {
            ResourceLocation baseLocation = ResourceLocation.fromNamespaceAndPath("theboysmod", basePath);
            ResourceLocation maskLocation = ResourceLocation.fromNamespaceAndPath("theboysmod", maskPath + frameIndex + ".png");
            ResourceLocation dynamicLocation = createMaskedTexture(baseLocation, maskLocation, cacheKey);
            if (dynamicLocation != null) {
               cachedTextures.put(cacheKey, dynamicLocation);
               return dynamicLocation;
            }
         } catch (Exception var7) {
            VPower.LOGGER.error("Failed to create HumanTorch dynamic texture: {}", cacheKey, var7);
         }

         return ResourceLocation.fromNamespaceAndPath("theboysmod", basePath);
      }
   }

   @Nullable
   private static ResourceLocation createMaskedTexture(ResourceLocation baseLocation, ResourceLocation maskLocation, String cacheKey) {
      ResourceManager resourceManager = Minecraft.getInstance().getResourceManager();

      try {
         NativeImage baseImage = loadImage(resourceManager, baseLocation);
         if (baseImage == null) {
            VPower.LOGGER.warn("HumanTorch base image not found: {}", baseLocation);
            return null;
         } else {
            NativeImage maskImage = loadImage(resourceManager, maskLocation);
            if (maskImage == null) {
               VPower.LOGGER.warn("HumanTorch mask image not found: {}", maskLocation);
               baseImage.close();
               return null;
            } else {
               applyAlphaMask(baseImage, maskImage);
               maskImage.close();
               DynamicTexture dynamicTexture = new DynamicTexture(baseImage);
               ResourceLocation dynamicLocation = ResourceLocation.fromNamespaceAndPath("theboysmod", "dynamic/human_torch_" + Math.abs(cacheKey.hashCode()));
               Minecraft.getInstance().getTextureManager().register(dynamicLocation, dynamicTexture);
               return dynamicLocation;
            }
         }
      } catch (Exception var8) {
         VPower.LOGGER.error("Error creating HumanTorch masked texture", var8);
         return null;
      }
   }

   @Nullable
   private static NativeImage loadImage(ResourceManager resourceManager, ResourceLocation location) {
      try {
         Optional<Resource> resource = resourceManager.getResource(location);
         if (resource.isEmpty()) {
            return null;
         } else {
            NativeImage var4;
            try (InputStream stream = resource.get().open()) {
               var4 = NativeImage.read(stream);
            }

            return var4;
         }
      } catch (IOException var8) {
         VPower.LOGGER.warn("Failed to load HumanTorch image: {}", location);
         return null;
      }
   }

   private static void applyAlphaMask(NativeImage texture, NativeImage overlay) {
      for (int y = 0; y < overlay.getHeight(); y++) {
         for (int x = 0; x < overlay.getWidth(); x++) {
            int pixelOrig = texture.getPixelRGBA(x, y);
            int pixelMask = overlay.getPixelRGBA(x, y);
            if (pixelOrig != 0) {
               Color colorMask = new Color(pixelMask, true);
               Color colorOrig = new Color(pixelOrig, true);
               float brightness = (float)(colorMask.getRed() + colorMask.getGreen() + colorMask.getBlue()) / 3.0F / 255.0F;
               float showFactor = 1.0F - brightness;
               float maskAlpha = (float)colorMask.getAlpha() / 255.0F;
               float factor = showFactor * maskAlpha;
               int newAlpha = (int)((float)colorOrig.getAlpha() * factor);
               Color newColor = new Color(colorOrig.getRed(), colorOrig.getGreen(), colorOrig.getBlue(), newAlpha);
               texture.setPixelRGBA(x, y, newColor.getRGB());
            }
         }
      }
   }

   public static void clearCache() {
      cachedTextures.clear();
   }
}
