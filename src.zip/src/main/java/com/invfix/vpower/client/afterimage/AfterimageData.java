package com.invfix.vpower.client.afterimage;

import net.minecraft.world.phys.Vec3;

public class AfterimageData {
   public final Vec3 position;
   public final Vec3 positionOld;
   public final float yBodyRot;
   public final float yBodyRotO;
   public final float yHeadRot;
   public final float yHeadRotO;
   public final float xRot;
   public final float xRotO;
   public final float limbSwingPos;
   public final float limbSwingSpeed;
   public final boolean isFallFlying;
   public final Vec3 velocity;
   public final long createTick;

   public AfterimageData(
      Vec3 position,
      Vec3 positionOld,
      float yBodyRot,
      float yBodyRotO,
      float yHeadRot,
      float yHeadRotO,
      float xRot,
      float xRotO,
      float limbSwingPos,
      float limbSwingSpeed,
      boolean isFallFlying,
      Vec3 velocity,
      long createTick
   ) {
      this.position = position;
      this.positionOld = positionOld;
      this.yBodyRot = yBodyRot;
      this.yBodyRotO = yBodyRotO;
      this.yHeadRot = yHeadRot;
      this.yHeadRotO = yHeadRotO;
      this.xRot = xRot;
      this.xRotO = xRotO;
      this.limbSwingPos = limbSwingPos;
      this.limbSwingSpeed = limbSwingSpeed;
      this.isFallFlying = isFallFlying;
      this.velocity = velocity;
      this.createTick = createTick;
   }

   public float getAlpha(long currentTick, int maxLifeTicks) {
      long age = currentTick - this.createTick;
      return age >= (long)maxLifeTicks ? 0.0F : 1.0F - (float)age / (float)maxLifeTicks;
   }

   public boolean isExpired(long currentTick, int maxLifeTicks) {
      return currentTick - this.createTick >= (long)maxLifeTicks;
   }
}
