package com.invfix.vpower.client;

import com.invfix.vpower.VPower;
import com.invfix.vpower.network.GrabPacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.GrabSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent.Pre;
import net.neoforged.neoforge.client.event.InputEvent.InteractionKeyMappingTriggered;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public class GrabClientTickHandler {
   private static final String GRAB_ID = GrabSkill.ID.toString();

   @SubscribeEvent
   public static void onClientTick(Pre event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null && mc.level != null && !mc.isPaused()) {
         LocalPlayer player = mc.player;

         try {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            if (!data.hasSkill(GRAB_ID) || !data.isSkillActive(GRAB_ID)) {
               return;
            }

            if (GrabClientState.isGrabbing(player.getId())) {
               PacketDistributor.sendToServer(new GrabPacket(GrabPacket.Action.HOLD_TICK), new CustomPacketPayload[0]);
            }
         } catch (Throwable var4) {
         }
      }
   }

   @SubscribeEvent
   public static void onClickInput(InteractionKeyMappingTriggered event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         LocalPlayer player = mc.player;
         if (event.isUseItem()) {
            try {
               if (!GrabClientState.isGrabbing(player.getId())) {
                  return;
               }

               SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
               if (!data.hasSkill(GRAB_ID) || !data.isSkillActive(GRAB_ID)) {
                  return;
               }

               event.setCanceled(true);
               event.setSwingHand(false);
               PacketDistributor.sendToServer(new GrabPacket(GrabPacket.Action.THROW), new CustomPacketPayload[0]);
               GrabClientState.clearGrabbing(player.getId());
               data.setSkillActive(GRAB_ID, false);
               VPower.LOGGER.debug("[Grab] Right-click throw triggered");
            } catch (Throwable var4) {
            }
         }
      }
   }
}
