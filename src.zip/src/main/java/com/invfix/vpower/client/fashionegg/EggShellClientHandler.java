package com.invfix.vpower.client.fashionegg;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.client.ClientSkillStateCache;
import com.invfix.vpower.client.animation.AnimationHelper;
import com.invfix.vpower.client.animation.ModAnimations;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.EggShellSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderArmEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public final class EggShellClientHandler {
   private static final String EGG_SHELL_ID = EggShellSkill.ID.toString();
   private static final String SHRINK_ON_PATH = ModAnimations.SHRINK_ON.getPath();
   private static final String SHRINK_RETREAT_PATH = ModAnimations.SHRINK_RETREAT.getPath();
   private static final int START_TICKS = 15;
   private static final int RETREAT_RESTORE_TICKS = 0;
   private static final int RETREAT_TICKS = 15;
   private static final float LOCAL_ROLL_STEP = 22.0F;
   private static final float REMOTE_ROLL_SPEED_SCALE = 10.0F;
   private static final Map<Integer, EggShellClientHandler.ShellState> STATES = new ConcurrentHashMap<>();

   private EggShellClientHandler() {
   }

   @SubscribeEvent
   public static void onClientTick(Post event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level != null && !mc.isPaused()) {
         Set<Integer> presentIds = new HashSet<>();

         for (AbstractClientPlayer player : mc.level.players()) {
            presentIds.add(player.getId());
            tickPlayer(player);
         }

         STATES.keySet().removeIf(id -> !presentIds.contains(id));
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public static void onRenderArm(RenderArmEvent event) {
      AbstractClientPlayer var2 = event.getPlayer();
      if (var2 instanceof AbstractClientPlayer && shouldHideBody(var2)) {
         event.setCanceled(true);
      }
   }

   public static boolean shouldHideBody(AbstractClientPlayer player) {
      EggShellClientHandler.ShellState state = STATES.get(player.getId());
      return state != null && state.hideBody;
   }

   public static boolean shouldRenderEggHead(AbstractClientPlayer player) {
      EggShellClientHandler.ShellState state = STATES.get(player.getId());
      return state != null && state.phase != EggShellClientHandler.Phase.NONE || wantsActive(player);
   }

   public static float getBodyRollDegrees(AbstractClientPlayer player, float partialTick) {
      EggShellClientHandler.ShellState state = STATES.get(player.getId());
      return state != null && state.hideBody ? Mth.lerp(partialTick, state.prevRollDegrees, state.rollDegrees) : 0.0F;
   }

   private static void tickPlayer(AbstractClientPlayer player) {
      boolean desiredActive = wantsActive(player);
      EggShellClientHandler.ShellState state = STATES.get(player.getId());
      if (state == null) {
         if (!desiredActive) {
            return;
         }

         state = new EggShellClientHandler.ShellState();
         STATES.put(player.getId(), state);
         startEntering(player, state);
      } else if (desiredActive && state.phase == EggShellClientHandler.Phase.EXITING) {
         startEntering(player, state);
      } else if (!desiredActive && (state.phase == EggShellClientHandler.Phase.ENTERING || state.phase == EggShellClientHandler.Phase.ACTIVE)) {
         startExiting(player, state);
      }

      switch (state.phase) {
         case NONE:
            STATES.remove(player.getId());
            break;
         case ENTERING:
            tickEntering(player, state);
            break;
         case ACTIVE:
            tickActive(player, state);
            break;
         case EXITING:
            tickExiting(player, state);
      }
   }

   private static void startEntering(AbstractClientPlayer player, EggShellClientHandler.ShellState state) {
      state.phase = EggShellClientHandler.Phase.ENTERING;
      state.ticks = -1;
      state.hideBody = false;
      AnimationHelper.playAnimationWithFade(player, ModAnimations.SHRINK_START, 2, false, true);
   }

   private static void tickEntering(AbstractClientPlayer player, EggShellClientHandler.ShellState state) {
      state.ticks++;
      if (state.ticks >= 15) {
         state.phase = EggShellClientHandler.Phase.ACTIVE;
         state.ticks = 0;
         state.hideBody = true;
         state.prevRollDegrees = state.rollDegrees;
         AnimationHelper.playAnimationWithFade(player, ModAnimations.SHRINK_ON, 1, true, true);
      }
   }

   private static void tickActive(AbstractClientPlayer player, EggShellClientHandler.ShellState state) {
      state.hideBody = true;
      protectOnAnimation(player);
      tickBodyRoll(player, state);
   }

   private static void startExiting(AbstractClientPlayer player, EggShellClientHandler.ShellState state) {
      state.phase = EggShellClientHandler.Phase.EXITING;
      state.ticks = -1;
      state.hideBody = false;
      AnimationHelper.playAnimationWithFade(player, ModAnimations.SHRINK_RETREAT, 1, false, true);
   }

   private static void tickExiting(AbstractClientPlayer player, EggShellClientHandler.ShellState state) {
      state.ticks++;
      if (state.ticks >= 0) {
         state.hideBody = false;
      }

      if (state.ticks >= 15) {
         if (SHRINK_RETREAT_PATH.equals(AnimationHelper.getCurrentAnimation(player))) {
            AnimationHelper.stopAnimation(player, 2);
         }

         state.phase = EggShellClientHandler.Phase.NONE;
         STATES.remove(player.getId());
      }
   }

   private static void protectOnAnimation(AbstractClientPlayer player) {
      if (!SHRINK_ON_PATH.equals(AnimationHelper.getCurrentAnimation(player))) {
         AnimationHelper.playAnimationWithFade(player, ModAnimations.SHRINK_ON, 1, true, true);
      }
   }

   private static void tickBodyRoll(AbstractClientPlayer player, EggShellClientHandler.ShellState state) {
      state.prevRollDegrees = state.rollDegrees;
      float forward = getForwardInput(player);
      if (!(Math.abs(forward) < 0.01F)) {
         state.rollDegrees -= forward * 22.0F;
      }
   }

   private static float getForwardInput(AbstractClientPlayer player) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null && mc.player.getId() == player.getId() && player instanceof LocalPlayer localPlayer) {
         float direction = localPlayer.input.up ? 1.0F : (localPlayer.input.down ? -1.0F : 0.0F);
         if (direction == 0.0F) {
            return 0.0F;
         } else {
            float speedFactor = Mth.clamp((float)localPlayer.getDeltaMovement().horizontalDistance() * 10.0F, 0.75F, 3.0F);
            if (localPlayer.isSprinting()) {
               speedFactor *= 1.35F;
            }

            return direction * speedFactor;
         }
      } else {
         Vec3 movement = player.getDeltaMovement();
         if (movement.horizontalDistanceSqr() < 1.0E-4) {
            return 0.0F;
         } else {
            Vec3 forward = Vec3.directionFromRotation(0.0F, player.yBodyRot).normalize();
            double projected = movement.x * forward.x + movement.z * forward.z;
            return Mth.clamp((float)projected * 10.0F, -3.0F, 3.0F);
         }
      }
   }

   private static boolean wantsActive(AbstractClientPlayer player) {
      Minecraft mc = Minecraft.getInstance();
      boolean isLocalPlayer = mc.player != null && mc.player.getId() == player.getId();
      if (!isLocalPlayer) {
         return ClientSkillStateCache.isSkillActive(player.getId(), EGG_SHELL_ID);
      } else {
         try {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            return data.hasSkill(EGG_SHELL_ID) && data.isSkillActive(EGG_SHELL_ID);
         } catch (Exception var4) {
            return false;
         }
      }
   }

   private static enum Phase {
      NONE,
      ENTERING,
      ACTIVE,
      EXITING;
   }

   private static final class ShellState {
      private EggShellClientHandler.Phase phase = EggShellClientHandler.Phase.NONE;
      private int ticks;
      private boolean hideBody;
      private float prevRollDegrees;
      private float rollDegrees;
   }
}
