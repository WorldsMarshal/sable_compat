package com.invfix.vpower.client;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ClientSkillStateCache {
   private static final Map<Integer, Map<String, Boolean>> playerSkillStates = new ConcurrentHashMap<>();
   private static final Map<Integer, Set<String>> playerOwnedSkills = new ConcurrentHashMap<>();
   private static final Map<Integer, Set<String>> playerTemporarySkills = new ConcurrentHashMap<>();

   public static void updatePlayerStates(int entityId, Map<String, Boolean> states) {
      playerSkillStates.put(entityId, new ConcurrentHashMap<>(states == null ? Map.of() : states));
   }

   public static void updatePlayerStates(int entityId, Map<String, Boolean> states, Set<String> ownedSkills) {
      updatePlayerStates(entityId, states);
      updatePlayerSkills(entityId, ownedSkills);
   }

   public static void updatePlayerStates(int entityId, Map<String, Boolean> states, Set<String> ownedSkills, Set<String> temporarySkills) {
      updatePlayerStates(entityId, states, ownedSkills);
      updateTemporarySkills(entityId, temporarySkills);
   }

   public static void updatePlayerSkills(int entityId, Set<String> ownedSkills) {
      playerOwnedSkills.put(entityId, ConcurrentHashMap.newKeySet());
      if (ownedSkills != null) {
         playerOwnedSkills.get(entityId).addAll(ownedSkills);
      }
   }

   public static void updateTemporarySkills(int entityId, Set<String> temporarySkills) {
      playerTemporarySkills.put(entityId, ConcurrentHashMap.newKeySet());
      if (temporarySkills != null) {
         playerTemporarySkills.get(entityId).addAll(temporarySkills);
      }
   }

   public static boolean isSkillActive(int entityId, String skillId) {
      Map<String, Boolean> states = playerSkillStates.get(entityId);
      return states == null ? false : states.getOrDefault(skillId, false);
   }

   public static boolean hasSkill(int entityId, String skillId) {
      Set<String> skills = playerOwnedSkills.get(entityId);
      return skills != null && skills.contains(skillId);
   }

   public static boolean hasKnownSkills(int entityId) {
      return playerOwnedSkills.containsKey(entityId);
   }

   public static boolean isTemporarySkill(int entityId, String skillId) {
      Set<String> skills = playerTemporarySkills.get(entityId);
      return skills != null && skills.contains(skillId);
   }

   public static void clearPlayer(int entityId) {
      playerSkillStates.remove(entityId);
      playerOwnedSkills.remove(entityId);
      playerTemporarySkills.remove(entityId);
   }

   public static void clearAll() {
      playerSkillStates.clear();
      playerOwnedSkills.clear();
      playerTemporarySkills.clear();
   }
}
