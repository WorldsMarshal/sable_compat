package com.invfix.vpower.client.claw;

import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class ClawGeoModel extends GeoModel<ClawState> {
   public static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/models/claw/claw.png");
   public static final ResourceLocation ANIMATION = ResourceLocation.fromNamespaceAndPath("theboysmod", "animations/claw.animation.json");
   private boolean slim;

   public void setSlim(boolean slim) {
      this.slim = slim;
   }

   public ResourceLocation getModelResource(ClawState animatable) {
      return ResourceLocation.fromNamespaceAndPath("theboysmod", this.slim ? "geo/claw/claw_slim.geo.json" : "geo/claw/claw.geo.json");
   }

   public ResourceLocation getTextureResource(ClawState animatable) {
      return TEXTURE;
   }

   public ResourceLocation getAnimationResource(ClawState animatable) {
      return ANIMATION;
   }
}
