package com.invfix.vpower.client.gui.overlay;

import java.util.Locale;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw.Layer;
import net.minecraft.client.player.LocalPlayer;

public final class TemporaryVTimerOverlay {
   private static final int WIDTH = 78;
   private static final int HEIGHT = 22;
   private static final int BAR_WIDTH = 64;
   private static final int BAR_HEIGHT = 4;
   public static final Layer HUD_TEMPORARY_V = (guiGraphics, deltaTracker) -> {
      Minecraft minecraft = Minecraft.getInstance();
      LocalPlayer player = minecraft.player;
      if (player != null && !minecraft.options.hideGui && !player.isSpectator()) {
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         if (data.hasTemporarySkills()) {
            int remainingTicks = data.getTemporarySkillRemainingTicks(player.level().getGameTime());
            if (remainingTicks > 0) {
               render(guiGraphics, minecraft, player, data, remainingTicks);
            }
         }
      }
   };

   private TemporaryVTimerOverlay() {
   }

   private static void render(GuiGraphics graphics, Minecraft minecraft, LocalPlayer player, SkillData data, int remainingTicks) {
      int screenWidth = minecraft.getWindow().getGuiScaledWidth();
      int screenHeight = minecraft.getWindow().getGuiScaledHeight();
      int hotbarRight = screenWidth / 2 + 91;
      int x = Math.min(screenWidth - 78 - 4, hotbarRight + 7);
      int y = screenHeight - 23;
      if (x <= hotbarRight) {
         y -= 24;
      }

      y = Math.max(4, y);
      int duration = Math.max(1, data.getTemporarySkillDurationTicks());
      float ratio = Math.max(0.0F, Math.min(1.0F, (float)remainingTicks / (float)duration));
      int fillWidth = Math.round(64.0F * ratio);
      graphics.fill(x, y, x + 78, y + 22, -1442510836);
      graphics.fill(x, y, x + 78, y + 1, -12891582);
      graphics.fill(x, y + 22 - 1, x + 78, y + 22, -15721964);
      graphics.fill(x, y, x + 1, y + 22, -12324755);
      drawScaledString(graphics, minecraft.font, "TEMP V", x + 7, y + 4, -4587575, 0.72F);
      drawScaledString(graphics, minecraft.font, formatTime(remainingTicks), x + 45, y + 4, -1, 0.72F);
      int barX = x + 7;
      int barY = y + 15;
      graphics.fill(barX, barY, barX + 64, barY + 4, 1711276032);
      if (fillWidth > 0) {
         graphics.fill(barX, barY, barX + fillWidth, barY + 4, -14096294);
         graphics.fill(barX, barY, barX + fillWidth, barY + 1, -7077971);
      }
   }

   private static String formatTime(int ticks) {
      int totalSeconds = Math.max(0, (ticks + 19) / 20);
      int minutes = totalSeconds / 60;
      int seconds = totalSeconds % 60;
      return String.format(Locale.ROOT, "%02d:%02d", minutes, seconds);
   }

   private static void drawScaledString(GuiGraphics graphics, Font font, String text, int x, int y, int color, float scale) {
      graphics.pose().pushPose();
      graphics.pose().scale(scale, scale, 1.0F);
      graphics.drawString(font, text, Math.round((float)x / scale), Math.round((float)y / scale), color, false);
      graphics.pose().popPose();
   }
}
