package com.invfix.vpower.client.invisibility;

import net.minecraft.world.entity.LivingEntity;

/**
 * Невидимость навыком Invisibility (The Boys). Сам навык в V не перенесён (его не дают ни Compound V, ни Temp V),
 * поэтому тело из-за него не прячется никогда; проверки в рендере способностей оставлены как в моде.
 */
public final class InvisibilityRenderHelper {

    private InvisibilityRenderHelper() {}

    public static boolean shouldHideBody(LivingEntity entity) {
        return false;
    }

    public static boolean isInvisibilitySkillActive(LivingEntity entity) {
        return false;
    }
}
