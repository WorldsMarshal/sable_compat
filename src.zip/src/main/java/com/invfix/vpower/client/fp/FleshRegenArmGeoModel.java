package com.invfix.vpower.client.fp;

import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class FleshRegenArmGeoModel extends GeoModel<FleshRegenArmState> {
   private String currentGeoFile = "flesh_regen_right_arm_bone.geo.json";

   public void setCurrentGeoFile(String geoFile) {
      this.currentGeoFile = geoFile;
   }

   public ResourceLocation getModelResource(FleshRegenArmState animatable) {
      return ResourceLocation.fromNamespaceAndPath("theboysmod", "geo/flesh_regen/" + this.currentGeoFile);
   }

   public ResourceLocation getTextureResource(FleshRegenArmState animatable) {
      return ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/models/flesh_regen/body_layer.png");
   }

   public ResourceLocation getAnimationResource(FleshRegenArmState animatable) {
      return null;
   }
}
