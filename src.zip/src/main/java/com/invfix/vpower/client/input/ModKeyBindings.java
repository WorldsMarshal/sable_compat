package com.invfix.vpower.client.input;

import com.mojang.blaze3d.platform.InputConstants.Type;
import net.minecraft.client.KeyMapping;
import net.neoforged.neoforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

/**
 * Клавиши V. Навыки — на клавишах способностей Invincible (VSlots); панель, пресеты и клавиша полёта The Boys не
 * переносятся. Регулировка силы: зажать и крутить колесо (с зажатой клавишей способности — сила этого навыка).
 * По умолчанию J: R The Boys занят сменой ряда способностей Invincible (и Portal Gun), левый Alt — Threatening Mode.
 */
public class ModKeyBindings {
   public static final String KEY_CATEGORY = "key.categories.theboysmod";
   public static final KeyMapping ADJUST_DAMAGE = new KeyMapping(
      "key.theboysmod.adjust_damage", KeyConflictContext.IN_GAME, Type.KEYSYM, GLFW.GLFW_KEY_J, KEY_CATEGORY
   );
}
