package com.invfix.vpower.client.input;

import com.invfix.vpower.skill.VAbilities;
import net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import javax.annotation.Nullable;

/**
 * Слоты навыков V — слоты способностей Invincible: клавиши ABILITY_1..5, навык — по строке слота текущего ряда
 * (AbilityRow). Вместо панели и шести клавиш The Boys (SkillBarManager, Z X C V B N).
 */
@OnlyIn(Dist.CLIENT)
public final class VSlots {

    public static final int COUNT = 5;

    private VSlots() {}

    @Nullable
    public static KeyMapping key(int slot) {
        return switch (slot) {
            case 0 -> InvincibleIncModKeyMappings.ABILITY_1;
            case 1 -> InvincibleIncModKeyMappings.ABILITY_2;
            case 2 -> InvincibleIncModKeyMappings.ABILITY_3;
            case 3 -> InvincibleIncModKeyMappings.ABILITY_4;
            case 4 -> InvincibleIncModKeyMappings.ABILITY_5;
            default -> null;
        };
    }

    public static boolean down(int slot) {
        KeyMapping key = key(slot);
        return key != null && key.isDown();
    }

    /** Навык V в слоте текущего ряда; null — пусто или не навык V. */
    @Nullable
    public static String skillId(int slot) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) return null;
        InvincibleIncModVariables.PlayerVariables v =
                (InvincibleIncModVariables.PlayerVariables) player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        boolean row1 = v.AbilityRow == 1.0;
        String name = switch (slot) {
            case 0 -> row1 ? v.AbilitySlot1 : v.AbilitySlot1_row2;
            case 1 -> row1 ? v.AbilitySlot2 : v.AbilitySlot2_row2;
            case 2 -> row1 ? v.AbilitySlot3 : v.AbilitySlot3_row2;
            case 3 -> row1 ? v.AbilitySlot4 : v.AbilitySlot4_row2;
            case 4 -> row1 ? v.AbilitySlot5 : v.AbilitySlot5_row2;
            default -> null;
        };
        return VAbilities.skillId(name);
    }

    /** Слот текущего ряда с навыком, иначе -1. */
    public static int find(String skillId) {
        for (int i = 0; i < COUNT; i++) {
            if (skillId.equals(skillId(i))) return i;
        }
        return -1;
    }
}
