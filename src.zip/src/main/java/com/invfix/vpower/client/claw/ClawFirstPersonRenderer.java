package com.invfix.vpower.client.claw;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.HumanoidArm;
import software.bernie.geckolib.animation.state.BoneSnapshot;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoObjectRenderer;

public class ClawFirstPersonRenderer extends GeoObjectRenderer<ClawState> {
   private static final ClawState STATE = new ClawState();
   private final ClawGeoModel clawModel = (ClawGeoModel)this.model;

   public ClawFirstPersonRenderer() {
      super(new ClawGeoModel());
   }

   public void renderArm(
      PoseStack poseStack,
      MultiBufferSource buffer,
      int packedLight,
      float partialTick,
      AbstractClientPlayer player,
      PlayerModel<AbstractClientPlayer> playerModel,
      HumanoidArm arm
   ) {
      if (player != null && playerModel != null && arm != null) {
         this.clawModel.setSlim(ClawClientHandler.isSlim(player));
         this.getGeoModel().getBakedModel(this.clawModel.getModelResource(STATE));
         String armBoneName = arm == HumanoidArm.RIGHT ? "right_arm" : "left_arm";
         GeoBone armBone = (GeoBone)this.getGeoModel().getBone(armBoneName).orElse(null);
         if (armBone != null) {
            resetArmBone(armBone);
            this.applyClawProgress(player, partialTick);
            poseStack.pushPose();
            poseStack.translate(0.0F, 1.5F, 0.0F);
            poseStack.scale(-1.0F, -1.0F, 1.0F);
            RenderType renderType = RenderType.entityTranslucent(ClawGeoModel.TEXTURE);
            VertexConsumer vertexConsumer = buffer.getBuffer(renderType);
            this.renderRecursively(
               poseStack, STATE, armBone, renderType, buffer, vertexConsumer, false, partialTick, packedLight, OverlayTexture.NO_OVERLAY, -1
            );
            poseStack.popPose();
         }
      }
   }

   private static void resetArmBone(GeoBone armBone) {
      BoneSnapshot snapshot = armBone.getInitialSnapshot();
      armBone.setRotX(snapshot.getRotX());
      armBone.setRotY(snapshot.getRotY());
      armBone.setRotZ(snapshot.getRotZ());
      armBone.setPosX(0.0F);
      armBone.setPosY(0.0F);
      armBone.setPosZ(0.0F);
      armBone.setScaleX(snapshot.getScaleX());
      armBone.setScaleY(snapshot.getScaleY());
      armBone.setScaleZ(snapshot.getScaleZ());
      armBone.setHidden(true);
      armBone.setChildrenHidden(false);
   }

   private void applyClawProgress(AbstractClientPlayer player, float partialTick) {
      float progress = ClawClientHandler.getExtensionProgress(player, partialTick);
      this.applyClawOffset("claws", 1.0F - progress);
      this.applyClawOffset("claws2", progress - 1.0F);
   }

   private void applyClawOffset(String boneName, float xOffset) {
      GeoBone bone = (GeoBone)this.getGeoModel().getBone(boneName).orElse(null);
      if (bone != null) {
         BoneSnapshot snapshot = bone.getInitialSnapshot();
         float retract = Math.abs(xOffset);
         bone.setHidden(false);
         bone.setChildrenHidden(false);
         bone.setPosX(xOffset);
         bone.setPosY(retract * 6.0F);
         bone.setPosZ(0.0F);
         bone.setRotX(snapshot.getRotX());
         bone.setRotY(snapshot.getRotY());
         bone.setRotZ(snapshot.getRotZ());
         bone.setScaleX(snapshot.getScaleX());
         bone.setScaleY(snapshot.getScaleY());
         bone.setScaleZ(snapshot.getScaleZ());
      }
   }
}
