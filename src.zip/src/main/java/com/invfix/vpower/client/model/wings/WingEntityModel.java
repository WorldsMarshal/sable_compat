package com.invfix.vpower.client.model.wings;

import com.google.common.collect.ImmutableList;
import com.invfix.vpower.client.animation.AnimationHelper;
import com.invfix.vpower.client.flight.WingFlightClientHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.AgeableListModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

public class WingEntityModel<T extends LivingEntity> extends AgeableListModel<T> {
   public final ModelPart rightWing;
   public final ModelPart leftWing;
   public WingEntityModel.State state = WingEntityModel.State.IDLE;

   public WingEntityModel(ModelPart root) {
      this.rightWing = root.getChild("rightWing");
      this.leftWing = root.getChild("leftWing");
   }

   public static MeshDefinition getModelData() {
      MeshDefinition modelData = new MeshDefinition();
      PartDefinition modelPartData = modelData.getRoot();
      modelPartData.addOrReplaceChild("rightWing", CubeListBuilder.create(), PartPose.offset(0.0F, 5.0F, 0.0F));
      modelPartData.addOrReplaceChild("leftWing", CubeListBuilder.create(), PartPose.offset(0.0F, 5.0F, 0.0F));
      return modelData;
   }

   public void setupAnim(T entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
      this.state = WingEntityModel.State.IDLE;
      float a = 0.125F;
      float b = 0.1F;
      float k = 0.4F;
      float l = -0.5F;
      float m = -1.0F;
      float n = 0.0F;
      boolean flightPose = entity.isFallFlying();
      boolean hoveringPose = false;

      if (entity instanceof AbstractClientPlayer player) {
         Minecraft mc = Minecraft.getInstance();
         boolean isLocalPlayer = mc.player != null && player.getId() == mc.player.getId();
         if (isLocalPlayer) {
            boolean wingHovering = WingFlightClientHandler.isWingHovering();
            boolean wingFlying = WingFlightClientHandler.isWingFlying();
            if (!wingHovering && !wingFlying) {
               boolean cachedHovering = WingFlightClientHandler.isRemoteWingHovering(player.getId());
               boolean cachedFlying = WingFlightClientHandler.isRemoteWingActive(player.getId());
               if (!player.onGround() && (cachedHovering || cachedFlying)) {
                  wingHovering = cachedHovering;
                  wingFlying = cachedFlying;
               }

               if (!player.onGround() && isWingHoverAnimationActive(player)) {
                  wingHovering = true;
                  wingFlying = true;
               }
            }

            if (wingHovering || wingFlying) {
               flightPose = true;
               hoveringPose = wingHovering;
            }
         } else {
            boolean remoteWingHovering = WingFlightClientHandler.isRemoteWingHovering(player.getId());
            boolean remoteWingActive = WingFlightClientHandler.isRemoteWingActive(player.getId());
            if (!player.onGround() && isWingHoverAnimationActive(player)) {
               remoteWingActive = true;
               remoteWingHovering = true;
            }

            if (!player.onGround() && (remoteWingActive || remoteWingHovering)) {
               flightPose = true;
               hoveringPose = remoteWingHovering;
            }
         }
      }

      if (!(entity instanceof AbstractClientPlayer) && !entity.onGround() && entity.isNoGravity()) {
         flightPose = true;
         hoveringPose = entity.getDeltaMovement().horizontalDistanceSqr() < 0.004;
      }

      if (flightPose) {
         Vec3 vec3d = entity.getDeltaMovement();
         if (hoveringPose) {
            this.state = WingEntityModel.State.HOVERING;
            boolean advancing = entity.zza > 0.0F || vec3d.horizontalDistanceSqr() > 0.003;
            if (advancing) {
               a = 0.4F;
               b = 0.95F;
               k = 0.45F;
               l = -1.15F;
            } else {
               a = 0.25F;
               b = 0.6F;
               k = 0.52F;
               l = -0.95F;
            }
         } else {
            this.state = WingEntityModel.State.FLYING;
            float o = 1.0F;
            if (vec3d.y < 0.0) {
               Vec3 vec3d2 = vec3d.normalize();
               o = 1.0F - (float)Math.pow(-vec3d2.y, 1.5);
            }

            k = o * 0.35F + (1.0F - o) * k;
            l = o * -1.6F + (0.3F - o) * l;
            boolean advancing = entity.zza > 0.0F || vec3d.horizontalDistanceSqr() > 0.02;
            if (advancing) {
               a = 0.4F;
               b = 1.0F;
            } else {
               a = 0.3F;
               b = 0.55F;
            }
         }
      } else if (entity.isCrouching()) {
         this.state = WingEntityModel.State.CROUCHING;
         k = 0.7F;
         m = 0.0F;
         n = 0.09F;
      }

      if (this.state == WingEntityModel.State.FLYING || this.state == WingEntityModel.State.HOVERING) {
         k += Mth.sin((float)entity.tickCount * a) * b;
      }

      this.leftWing.x = 7.0F;
      this.leftWing.y = m;
      if (entity instanceof AbstractClientPlayer playerx) {
         playerx.elytraRotX = playerx.elytraRotX + (k - playerx.elytraRotX) * 0.1F;
         playerx.elytraRotY = playerx.elytraRotY + (n - playerx.elytraRotY) * 0.1F;
         playerx.elytraRotZ = playerx.elytraRotZ + (l - playerx.elytraRotZ) * 0.1F;
         this.leftWing.xRot = playerx.elytraRotX;
         this.leftWing.yRot = playerx.elytraRotY;
         this.leftWing.zRot = playerx.elytraRotZ;
      } else {
         this.leftWing.xRot = k;
         this.leftWing.zRot = l;
         this.leftWing.yRot = n;
      }

      this.rightWing.x = -this.leftWing.x;
      this.rightWing.yRot = -this.leftWing.yRot;
      this.rightWing.y = this.leftWing.y;
      this.rightWing.xRot = this.leftWing.xRot;
      this.rightWing.zRot = -this.leftWing.zRot;
   }

   protected Iterable<ModelPart> headParts() {
      return ImmutableList.of();
   }

   protected Iterable<ModelPart> bodyParts() {
      return ImmutableList.of(this.rightWing, this.leftWing);
   }

   private static boolean isWingHoverAnimationActive(AbstractClientPlayer player) {
      String currentAnimation = AnimationHelper.getCurrentAnimation(player);
      return currentAnimation != null && AnimationHelper.isPlayingAnimation(player)
         ? "wings_hover.start".equals(currentAnimation) || "wings_hover.on".equals(currentAnimation)
         : false;
   }

   public static enum State {
      IDLE,
      HOVERING,
      CROUCHING,
      FLYING;
   }
}
