package com.invfix.vpower.client.xrayvision;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.OutlineBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent.Pre;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public class XRayVisionRenderer {
   private static boolean isInsideXRayRendering = false;
   private static int tick = 0;
   private static int prevTick = 0;
   private static final int MAX_TICKS = 10;

   public static boolean shouldRender() {
      return tick > 0;
   }

   public static boolean isInsideXRayRendering() {
      return isInsideXRayRendering;
   }

   @SubscribeEvent
   public static void onClientTick(Pre event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null && mc.level != null) {
         prevTick = tick;
         if (XRayVisionClientHandler.isActive()) {
            if (tick < 10) {
               tick++;
            }
         } else {
            if (tick > 0) {
               tick -= 2;
            }

            if (tick < 0) {
               tick = 0;
            }
         }
      }
   }

   @SubscribeEvent
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      if (event.getStage() == Stage.AFTER_ENTITIES) {
         renderOutlineOnlyPass(event);
      } else if (event.getStage() == Stage.AFTER_TRANSLUCENT_BLOCKS) {
         if (shouldRender() && !isInsideXRayRendering) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.level != null) {
               float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
               float progress = getProgress(partialTick);
               if (!(progress <= 0.0F)) {
                  BufferSource bufferSource = mc.renderBuffers().bufferSource();
                  Set<RenderType> xrayRenderTypes = new HashSet<>();
                  isInsideXRayRendering = true;

                  try {
                     for (Entity entity : mc.level.entitiesForRendering()) {
                        if (XRayVisionClientHandler.shouldEntityGlow(entity)) {
                           renderXRayEntity(mc, bufferSource, xrayRenderTypes, entity, partialTick, progress);
                        }
                     }
                  } finally {
                     isInsideXRayRendering = false;
                     flushXRayBuffers(bufferSource, xrayRenderTypes);
                  }
               }
            }
         }
      }
   }

   private static void renderXRayEntity(
      Minecraft mc, BufferSource bufferSource, Set<RenderType> xrayRenderTypes, Entity entity, float partialTick, float progress
   ) {
      int alpha = calculateAlpha(mc, entity, progress);
      if (alpha > 0) {
         Vec3 camera = mc.gameRenderer.getMainCamera().getPosition();
         double x = Mth.lerp((double)partialTick, entity.xOld, entity.getX()) - camera.x;
         double y = Mth.lerp((double)partialTick, entity.yOld, entity.getY()) - camera.y;
         double z = Mth.lerp((double)partialTick, entity.zOld, entity.getZ()) - camera.z;
         float yaw = Mth.lerp(partialTick, entity.yRotO, entity.getYRot());
         EntityRenderDispatcher dispatcher = mc.getEntityRenderDispatcher();
         EntityRenderer<? super Entity> renderer = dispatcher.getRenderer(entity);
         MultiBufferSource xraySource = originalType -> {
            if (XRayRenderType.shouldUseOutlineOnly(originalType)) {
               return DiscardingVertexConsumer.INSTANCE;
            } else {
               RenderType xrayType = XRayRenderType.entity(originalType);
               xrayRenderTypes.add(xrayType);
               VertexConsumer real = bufferSource.getBuffer(xrayType);
               return new WhiteVertexConsumer(real, alpha);
            }
         };

         try {
            Vec3 offset = renderer.getRenderOffset(entity, partialTick);
            PoseStack poseStack = new PoseStack();
            poseStack.translate(x + offset.x(), y + offset.y(), z + offset.z());
            renderer.render(entity, yaw, partialTick, poseStack, xraySource, 15728880);
         } catch (RuntimeException var20) {
         }
      }
   }

   private static void renderOutlineOnlyPass(RenderLevelStageEvent event) {
      if (shouldRender() && !isInsideXRayRendering) {
         Minecraft mc = Minecraft.getInstance();
         if (mc.player != null && mc.level != null) {
            float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
            float progress = getProgress(partialTick);
            if (!(progress <= 0.0F)) {
               boolean requestedOutline = false;
               OutlineBufferSource outlineSource = mc.renderBuffers().outlineBufferSource();
               EntityRenderDispatcher dispatcher = mc.getEntityRenderDispatcher();
               isInsideXRayRendering = true;

               try {
                  for (Entity entity : mc.level.entitiesForRendering()) {
                     if (XRayVisionClientHandler.shouldEntityGlow(entity)) {
                        int alpha = calculateAlpha(mc, entity, progress);
                        if (alpha > 0) {
                           Vec3 camera = mc.gameRenderer.getMainCamera().getPosition();
                           double x = Mth.lerp((double)partialTick, entity.xOld, entity.getX()) - camera.x;
                           double y = Mth.lerp((double)partialTick, entity.yOld, entity.getY()) - camera.y;
                           double z = Mth.lerp((double)partialTick, entity.zOld, entity.getZ()) - camera.z;
                           float yaw = Mth.lerp(partialTick, entity.yRotO, entity.getYRot());
                           EntityRenderer<? super Entity> renderer = dispatcher.getRenderer(entity);
                           boolean[] usedOutline = new boolean[]{false};
                           outlineSource.setColor(255, 255, 255, alpha);
                           MultiBufferSource outlineOnlySource = originalType -> {
                              if (!XRayRenderType.shouldUseOutlineOnly(originalType)) {
                                 return DiscardingVertexConsumer.INSTANCE;
                              } else {
                                 Optional<RenderType> outlineType = XRayRenderType.outline(originalType);
                                 if (outlineType.isEmpty()) {
                                    return DiscardingVertexConsumer.INSTANCE;
                                 } else {
                                    usedOutline[0] = true;
                                    return outlineSource.getBuffer(outlineType.get());
                                 }
                              }
                           };

                           try {
                              Vec3 offset = renderer.getRenderOffset(entity, partialTick);
                              PoseStack poseStack = new PoseStack();
                              poseStack.translate(x + offset.x(), y + offset.y(), z + offset.z());
                              renderer.render(entity, yaw, partialTick, poseStack, outlineOnlySource, 15728880);
                              requestedOutline |= usedOutline[0];
                           } catch (RuntimeException var26) {
                           }
                        }
                     }
                  }
               } finally {
                  isInsideXRayRendering = false;
               }

               if (requestedOutline) {
                  mc.levelRenderer.requestOutlineEffect();
               }
            }
         }
      }
   }

   private static int calculateAlpha(Minecraft mc, Entity entity, float progress) {
      double range = Math.max(1.0, XRayVisionClientHandler.getCurrentRange(mc));
      double dist = (double)mc.player.distanceTo(entity);
      float distFactor = 1.0F - (float)Math.min(1.0, dist / range);
      return Mth.clamp((int)(distFactor * 180.0F * progress + 40.0F * progress), 0, 220);
   }

   private static void flushXRayBuffers(BufferSource bufferSource, Set<RenderType> xrayRenderTypes) {
      if (!xrayRenderTypes.isEmpty()) {
         RenderSystem.disableDepthTest();
         RenderSystem.depthMask(false);

         try {
            for (RenderType renderType : xrayRenderTypes) {
               bufferSource.endBatch(renderType);
            }
         } finally {
            RenderSystem.depthMask(true);
            RenderSystem.enableDepthTest();
            RenderSystem.depthFunc(515);
         }
      }
   }

   private static float getProgress(float partialTick) {
      float p = ((float)tick + (float)(tick - prevTick) * partialTick) / 10.0F;
      return Mth.clamp(p, 0.0F, 1.0F);
   }

   public static void reset() {
      tick = 0;
      prevTick = 0;
   }
}
