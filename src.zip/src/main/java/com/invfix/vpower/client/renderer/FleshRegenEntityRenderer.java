package com.invfix.vpower.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.client.dynamictexture.FleshRegenTextureManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager.ControllerRegistrar;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoObjectRenderer;
import software.bernie.geckolib.util.GeckoLibUtil;

public class FleshRegenEntityRenderer extends GeoObjectRenderer<FleshRegenEntityRenderer.VirtualFleshRegen> {
   public static final float MODEL_Y_OFFSET = -1.5F;
   public static final float HEAD_POS_X_SCALE = 1.0F;
   public static final float HEAD_POS_Y_OFFSET = 0.0F;
   public static final float HEAD_POS_Z_OFFSET = 0.0F;
   public static final float BODY_POS_X_SCALE = 0.0F;
   public static final float BODY_POS_Y_OFFSET = 0.0F;
   public static final float BODY_POS_Z_OFFSET = 0.0F;
   public static final float ARM_POS_X_SCALE = 1.0F;
   public static final float ARM_POS_X_OFFSET = 5.0F;
   public static final float ARM_POS_Y_OFFSET = 2.0F;
   public static final float ARM_POS_Z_OFFSET = 0.0F;
   public static final float LEG_POS_X_SCALE = 1.0F;
   public static final float LEG_POS_X_OFFSET = 2.0F;
   public static final float LEG_POS_Y_OFFSET = 12.0F;
   public static final float LEG_POS_Z_OFFSET = 0.0F;
   private static final Map<String, FleshRegenEntityRenderer.PartConfig> PART_CONFIGS = new HashMap<>();
   private PlayerModel<AbstractClientPlayer> currentPlayerModel;
   private HumanoidModel<?> currentHumanoidModel;
   private Player currentPlayer;
   private LivingEntity currentEntity;
   private ResourceLocation currentSkinTexture;
   private boolean isSlim = false;
   private boolean usePlayerBoneRotationSigns = false;
   private boolean swapHumanoidLimbSides = false;
   private boolean usePlayerGeoTransform = false;
   private int debugCounter = 0;
   private static final FleshRegenEntityRenderer.VirtualFleshRegen VIRTUAL_INSTANCE = new FleshRegenEntityRenderer.VirtualFleshRegen();
   private BakedGeoModel currentBakedModel;
   private boolean skipHeadBoneSync = false;

   private static void registerPart(String partName, String geoFile, String boneName, String maskPrefix, int maxScore) {
      PART_CONFIGS.put(partName, new FleshRegenEntityRenderer.PartConfig(geoFile, boneName, maskPrefix, maxScore));
   }

   public FleshRegenEntityRenderer() {
      super(new FleshRegenEntityRenderer.FleshRegenGeoModel());
   }

   public void setPlayerModel(PlayerModel<AbstractClientPlayer> model) {
      this.currentPlayerModel = model;
      this.currentHumanoidModel = model;
      this.usePlayerBoneRotationSigns = true;
      this.swapHumanoidLimbSides = false;
      this.usePlayerGeoTransform = true;
   }

   public void setHumanoidModel(HumanoidModel<?> model, boolean slim) {
      this.setHumanoidModel(model, slim, false);
   }

   public void setHumanoidModel(HumanoidModel<?> model, boolean slim, boolean usePlayerBoneRotationSigns) {
      this.setHumanoidModel(model, slim, usePlayerBoneRotationSigns, false);
   }

   public void setHumanoidModel(HumanoidModel<?> model, boolean slim, boolean usePlayerBoneRotationSigns, boolean swapHumanoidLimbSides) {
      this.setHumanoidModel(model, slim, usePlayerBoneRotationSigns, swapHumanoidLimbSides, false);
   }

   public void setHumanoidModel(
      HumanoidModel<?> model, boolean slim, boolean usePlayerBoneRotationSigns, boolean swapHumanoidLimbSides, boolean usePlayerGeoTransform
   ) {
      this.currentPlayerModel = null;
      this.currentPlayer = null;
      this.currentHumanoidModel = model;
      this.isSlim = slim;
      this.usePlayerBoneRotationSigns = usePlayerBoneRotationSigns;
      this.swapHumanoidLimbSides = swapHumanoidLimbSides;
      this.usePlayerGeoTransform = usePlayerGeoTransform;
   }

   public void setSkinTexture(ResourceLocation texture) {
      this.currentSkinTexture = texture;
   }

   public void renderFleshRegenOnEntity(
      LivingEntity entity, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, ResourceLocation skinTexture
   ) {
      if (entity != null && !entity.isSpectator() && this.currentHumanoidModel != null) {
         this.currentEntity = entity;
         this.currentSkinTexture = skinTexture;
         if (entity instanceof Player player) {
            this.currentPlayer = player;
            this.renderFleshRegenOnPlayer(player, poseStack, bufferSource, packedLight, partialTick);
         } else {
            FleshRegenData data = (FleshRegenData)entity.getData(ModAttachments.FLESH_REGEN.get());
            this.renderFleshRegenWithData(data, poseStack, bufferSource, packedLight, partialTick);
         }
      }
   }

   private void renderFleshRegenWithData(FleshRegenData data, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick) {
      int headValue = data.getScore("Head");
      if (headValue >= 0 && headValue <= 17) {
         this.renderHeadGeoForEntity(poseStack, bufferSource, packedLight, partialTick, headValue);
      }

      int bodyValue = data.getScore("Body");
      if (bodyValue >= 0 && bodyValue <= 19) {
         this.renderBodyGeoForEntity(poseStack, bufferSource, packedLight, partialTick, bodyValue);
      }

      int rightArmValue = data.getScore("Right.Arm");
      int rightHandValue = data.getScore("Right.Hand");
      int leftArmValue = data.getScore("Left.Arm");
      int leftHandValue = data.getScore("Left.Hand");
      if (rightArmValue >= 0 && rightArmValue <= 17) {
         this.renderRightArmGeoForEntity(poseStack, bufferSource, packedLight, partialTick, rightArmValue);
      }

      if (rightHandValue >= 0 && rightHandValue <= 11) {
         this.renderRightHandGeoForEntity(poseStack, bufferSource, packedLight, partialTick, rightHandValue);
      }

      if (leftArmValue >= 0 && leftArmValue <= 17) {
         this.renderLeftArmGeoForEntity(poseStack, bufferSource, packedLight, partialTick, leftArmValue);
      }

      if (leftHandValue >= 0 && leftHandValue <= 11) {
         this.renderLeftHandGeoForEntity(poseStack, bufferSource, packedLight, partialTick, leftHandValue);
      }

      int rightLegValue = data.getScore("Right.Leg");
      int rightFeetValue = data.getScore("Right.Feet");
      int leftLegValue = data.getScore("Left.Leg");
      int leftFeetValue = data.getScore("Left.Feet");
      if (rightLegValue >= 0 && rightLegValue <= 19) {
         this.renderRightLegGeoForEntity(poseStack, bufferSource, packedLight, partialTick, rightLegValue);
      }

      if (rightFeetValue >= 0 && rightFeetValue <= 10) {
         this.renderRightFeetGeoForEntity(poseStack, bufferSource, packedLight, partialTick, rightFeetValue);
      }

      if (leftLegValue >= 0 && leftLegValue <= 19) {
         this.renderLeftLegGeoForEntity(poseStack, bufferSource, packedLight, partialTick, leftLegValue);
      }

      if (leftFeetValue >= 0 && leftFeetValue <= 10) {
         this.renderLeftFeetGeoForEntity(poseStack, bufferSource, packedLight, partialTick, leftFeetValue);
      }
   }

   private void renderHeadGeoForEntity(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int headValue) {
      ResourceLocation headTexture = FleshRegenTextureManager.getHeadTexture(headValue);
      if (FleshRegenTextureManager.shouldRenderHeadBone(headValue) && headTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_head_bone.geo.json", headTexture);
      }

      if (FleshRegenTextureManager.shouldRenderHeadFlesh(headValue) && headTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_head_flesh.geo.json", headTexture);
      }

      if (FleshRegenTextureManager.shouldRenderHeadSkin(headValue) && this.currentSkinTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_head_skin.geo.json", this.currentSkinTexture);
      }
   }

   private void renderBodyGeoForEntity(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int bodyValue) {
      ResourceLocation bodyTexture = FleshRegenTextureManager.getBodyTexture(bodyValue);
      if (FleshRegenTextureManager.shouldRenderBodyBone(bodyValue) && bodyTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_body_bone.geo.json", bodyTexture);
      }

      if (FleshRegenTextureManager.shouldRenderBodyFlesh(bodyValue) && bodyTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_body_flesh.geo.json", bodyTexture);
      }

      if (FleshRegenTextureManager.shouldRenderBodySkin(bodyValue) && this.currentSkinTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_body_skin.geo.json", this.currentSkinTexture);
      }
   }

   private void renderRightArmGeoForEntity(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int armValue) {
      ResourceLocation armTexture = FleshRegenTextureManager.getRightArmTexture(armValue);
      if (FleshRegenTextureManager.shouldRenderRightArmBone(armValue) && armTexture != null) {
         String boneGeo = this.isSlim ? "flesh_regen_right_arm_bone_slim.geo.json" : "flesh_regen_right_arm_bone.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, boneGeo, armTexture);
      }

      if (FleshRegenTextureManager.shouldRenderRightArmFlesh(armValue) && armTexture != null) {
         String fleshGeo = this.isSlim ? "flesh_regen_right_arm_flesh_slim.geo.json" : "flesh_regen_right_arm_flesh.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, fleshGeo, armTexture);
      }

      if (FleshRegenTextureManager.shouldRenderRightArmSkin(armValue) && this.currentSkinTexture != null) {
         String skinGeo = this.isSlim ? "flesh_regen_right_arm_skin_slim.geo.json" : "flesh_regen_right_arm_skin.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, skinGeo, this.currentSkinTexture);
      }
   }

   private void renderRightHandGeoForEntity(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int handValue) {
      ResourceLocation handTexture = FleshRegenTextureManager.getRightHandTexture(handValue);
      if (FleshRegenTextureManager.shouldRenderRightHandBone(handValue) && handTexture != null) {
         String boneGeo = this.isSlim ? "flesh_regen_right_hand_bone_slim.geo.json" : "flesh_regen_right_hand_bone.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, boneGeo, handTexture);
      }

      if (FleshRegenTextureManager.shouldRenderRightHandFlesh(handValue) && handTexture != null) {
         String fleshGeo = this.isSlim ? "flesh_regen_right_hand_flesh_slim.geo.json" : "flesh_regen_right_hand_flesh.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, fleshGeo, handTexture);
      }

      if (FleshRegenTextureManager.shouldRenderRightHandSkin(handValue) && this.currentSkinTexture != null) {
         String skinGeo = this.isSlim ? "flesh_regen_right_hand_skin_slim.geo.json" : "flesh_regen_right_hand_skin.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, skinGeo, this.currentSkinTexture);
      }
   }

   private void renderLeftArmGeoForEntity(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int armValue) {
      ResourceLocation armTexture = FleshRegenTextureManager.getLeftArmTexture(armValue);
      if (FleshRegenTextureManager.shouldRenderLeftArmBone(armValue) && armTexture != null) {
         String boneGeo = this.isSlim ? "flesh_regen_left_arm_bone_slim.geo.json" : "flesh_regen_left_arm_bone.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, boneGeo, armTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLeftArmFlesh(armValue) && armTexture != null) {
         String fleshGeo = this.isSlim ? "flesh_regen_left_arm_flesh_slim.geo.json" : "flesh_regen_left_arm_flesh.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, fleshGeo, armTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLeftArmSkin(armValue) && this.currentSkinTexture != null) {
         String skinGeo = this.isSlim ? "flesh_regen_left_arm_skin_slim.geo.json" : "flesh_regen_left_arm_skin.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, skinGeo, this.currentSkinTexture);
      }
   }

   private void renderLeftHandGeoForEntity(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int handValue) {
      ResourceLocation handTexture = FleshRegenTextureManager.getLeftHandTexture(handValue);
      if (FleshRegenTextureManager.shouldRenderLeftHandBone(handValue) && handTexture != null) {
         String boneGeo = this.isSlim ? "flesh_regen_left_hand_bone_slim.geo.json" : "flesh_regen_left_hand_bone.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, boneGeo, handTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLeftHandFlesh(handValue) && handTexture != null) {
         String fleshGeo = this.isSlim ? "flesh_regen_left_hand_flesh_slim.geo.json" : "flesh_regen_left_hand_flesh.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, fleshGeo, handTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLeftHandSkin(handValue) && this.currentSkinTexture != null) {
         String skinGeo = this.isSlim ? "flesh_regen_left_hand_skin_slim.geo.json" : "flesh_regen_left_hand_skin.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, skinGeo, this.currentSkinTexture);
      }
   }

   private void renderRightLegGeoForEntity(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int legValue) {
      ResourceLocation legTexture = FleshRegenTextureManager.getLegsTexture(legValue);
      if (FleshRegenTextureManager.shouldRenderLegsBone(legValue) && legTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_leg_bone.geo.json", legTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLegsFlesh(legValue) && legTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_leg_flesh.geo.json", legTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLegsSkin(legValue) && this.currentSkinTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_leg_skin.geo.json", this.currentSkinTexture);
      }
   }

   private void renderRightFeetGeoForEntity(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int feetValue) {
      ResourceLocation feetTexture = FleshRegenTextureManager.getFeetTexture(feetValue);
      if (FleshRegenTextureManager.shouldRenderFeetBone(feetValue) && feetTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_feet_bone.geo.json", feetTexture);
      }

      if (FleshRegenTextureManager.shouldRenderFeetFlesh(feetValue) && feetTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_feet_flesh.geo.json", feetTexture);
      }

      if (FleshRegenTextureManager.shouldRenderFeetSkin(feetValue) && this.currentSkinTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_feet_skin.geo.json", this.currentSkinTexture);
      }
   }

   private void renderLeftLegGeoForEntity(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int legValue) {
      ResourceLocation legTexture = FleshRegenTextureManager.getLegsTexture(legValue);
      if (FleshRegenTextureManager.shouldRenderLegsBone(legValue) && legTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_leg_bone.geo.json", legTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLegsFlesh(legValue) && legTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_leg_flesh.geo.json", legTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLegsSkin(legValue) && this.currentSkinTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_leg_skin.geo.json", this.currentSkinTexture);
      }
   }

   private void renderLeftFeetGeoForEntity(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int feetValue) {
      ResourceLocation feetTexture = FleshRegenTextureManager.getFeetTexture(feetValue);
      if (FleshRegenTextureManager.shouldRenderFeetBone(feetValue) && feetTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_feet_bone.geo.json", feetTexture);
      }

      if (FleshRegenTextureManager.shouldRenderFeetFlesh(feetValue) && feetTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_feet_flesh.geo.json", feetTexture);
      }

      if (FleshRegenTextureManager.shouldRenderFeetSkin(feetValue) && this.currentSkinTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_feet_skin.geo.json", this.currentSkinTexture);
      }
   }

   public void renderFleshRegenOnPlayer(Player player, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick) {
      if (player != null && !player.isSpectator() && this.currentPlayerModel != null) {
         this.currentPlayer = player;
         this.currentEntity = player;
         FleshRegenData data = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
         int headValue = data.getScore("Head");
         if (headValue >= 0 && headValue <= 17) {
            this.renderHeadGeo(poseStack, bufferSource, packedLight, partialTick, headValue);
         }

         int bodyValue = data.getScore("Body");
         if (bodyValue >= 0 && bodyValue <= 19) {
            this.renderBodyGeo(poseStack, bufferSource, packedLight, partialTick, bodyValue);
         }

         int rightArmValue = data.getScore("Right.Arm");
         int rightHandValue = data.getScore("Right.Hand");
         if (rightArmValue >= 0 && rightArmValue <= 17) {
            this.renderRightArmGeo(poseStack, bufferSource, packedLight, partialTick, rightArmValue);
         } else if (rightArmValue == 18 && rightHandValue >= 0 && rightHandValue <= 11) {
            ResourceLocation armTexture = FleshRegenTextureManager.getRightArmTexture(18);
            if (armTexture != null) {
               String fleshGeo = this.isSlimModel() ? "flesh_regen_right_arm_flesh_slim.geo.json" : "flesh_regen_right_arm_flesh.geo.json";
               this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, fleshGeo, armTexture);
            }

            ResourceLocation skinTexture = this.getPlayerSkinTexture();
            if (skinTexture != null) {
               String armSkinGeo = this.isSlimModel() ? "flesh_regen_right_arm_skin_slim.geo.json" : "flesh_regen_right_arm_skin.geo.json";
               this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, armSkinGeo, skinTexture);
            }
         } else if (rightArmValue == -1 && rightHandValue >= 0 && rightHandValue <= 11) {
            ResourceLocation armTexturex = FleshRegenTextureManager.getRightArmTexture(18);
            if (armTexturex != null) {
               String fleshGeo = this.isSlimModel() ? "flesh_regen_right_arm_flesh_slim.geo.json" : "flesh_regen_right_arm_flesh.geo.json";
               this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, fleshGeo, armTexturex);
            }

            ResourceLocation skinTexture = this.getPlayerSkinTexture();
            if (skinTexture != null) {
               String armSkinGeo = this.isSlimModel() ? "flesh_regen_right_arm_skin_slim.geo.json" : "flesh_regen_right_arm_skin.geo.json";
               this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, armSkinGeo, skinTexture);
            }
         }

         if (rightHandValue >= 0 && rightHandValue <= 11) {
            this.renderRightHandGeo(poseStack, bufferSource, packedLight, partialTick, rightHandValue);
         }

         int leftArmValue = data.getScore("Left.Arm");
         int leftHandValue = data.getScore("Left.Hand");
         if (leftArmValue >= 0 && leftArmValue <= 17) {
            this.renderLeftArmGeo(poseStack, bufferSource, packedLight, partialTick, leftArmValue);
         } else if (leftArmValue == 18 && leftHandValue >= 0 && leftHandValue <= 11) {
            ResourceLocation armTexturexx = FleshRegenTextureManager.getLeftArmTexture(18);
            if (armTexturexx != null) {
               String fleshGeo = this.isSlimModel() ? "flesh_regen_left_arm_flesh_slim.geo.json" : "flesh_regen_left_arm_flesh.geo.json";
               this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, fleshGeo, armTexturexx);
            }

            ResourceLocation skinTexture = this.getPlayerSkinTexture();
            if (skinTexture != null) {
               String armSkinGeo = this.isSlimModel() ? "flesh_regen_left_arm_skin_slim.geo.json" : "flesh_regen_left_arm_skin.geo.json";
               this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, armSkinGeo, skinTexture);
            }
         } else if (leftArmValue == -1 && leftHandValue >= 0 && leftHandValue <= 11) {
            ResourceLocation armTexturexxx = FleshRegenTextureManager.getLeftArmTexture(18);
            if (armTexturexxx != null) {
               String fleshGeo = this.isSlimModel() ? "flesh_regen_left_arm_flesh_slim.geo.json" : "flesh_regen_left_arm_flesh.geo.json";
               this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, fleshGeo, armTexturexxx);
            }

            ResourceLocation skinTexture = this.getPlayerSkinTexture();
            if (skinTexture != null) {
               String armSkinGeo = this.isSlimModel() ? "flesh_regen_left_arm_skin_slim.geo.json" : "flesh_regen_left_arm_skin.geo.json";
               this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, armSkinGeo, skinTexture);
            }
         }

         if (leftHandValue >= 0 && leftHandValue <= 11) {
            this.renderLeftHandGeo(poseStack, bufferSource, packedLight, partialTick, leftHandValue);
         }

         int rightLegValue = data.getScore("Right.Leg");
         int rightFeetValue = data.getScore("Right.Feet");
         if (rightLegValue >= 0 && rightLegValue <= 19) {
            this.renderRightLegGeo(poseStack, bufferSource, packedLight, partialTick, rightLegValue);
         } else if (rightLegValue == 20 && rightFeetValue >= 0 && rightFeetValue <= 10) {
            ResourceLocation legTexture = FleshRegenTextureManager.getLegsTexture(20);
            if (legTexture != null) {
               this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_leg_flesh.geo.json", legTexture);
            }

            ResourceLocation skinTexture = this.getPlayerSkinTexture();
            if (skinTexture != null) {
               this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_leg_skin.geo.json", skinTexture);
            }
         }

         if (rightFeetValue >= 0 && rightFeetValue <= 10) {
            this.renderRightFeetGeo(poseStack, bufferSource, packedLight, partialTick, rightFeetValue);
         }

         int leftLegValue = data.getScore("Left.Leg");
         int leftFeetValue = data.getScore("Left.Feet");
         if (leftLegValue >= 0 && leftLegValue <= 19) {
            this.renderLeftLegGeo(poseStack, bufferSource, packedLight, partialTick, leftLegValue);
         } else if (leftLegValue == 20 && leftFeetValue >= 0 && leftFeetValue <= 10) {
            ResourceLocation legTexturex = FleshRegenTextureManager.getLegsTexture(20);
            if (legTexturex != null) {
               this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_leg_flesh.geo.json", legTexturex);
            }

            ResourceLocation skinTexture = this.getPlayerSkinTexture();
            if (skinTexture != null) {
               this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_leg_skin.geo.json", skinTexture);
            }
         }

         if (leftFeetValue >= 0 && leftFeetValue <= 10) {
            this.renderLeftFeetGeo(poseStack, bufferSource, packedLight, partialTick, leftFeetValue);
         }
      }
   }

   private ResourceLocation getPlayerSkinTexture() {
      return this.currentPlayer != null
         ? Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(this.currentPlayer).getTextureLocation(this.currentPlayer)
         : null;
   }

   private boolean isSlimModel() {
      return this.currentPlayer instanceof AbstractClientPlayer clientPlayer ? clientPlayer.getSkin().model().id().equals("slim") : false;
   }

   private void renderHeadGeo(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int headValue) {
      ResourceLocation headTexture = FleshRegenTextureManager.getHeadTexture(headValue);
      poseStack.pushPose();
      if (this.currentPlayerModel != null) {
         this.currentPlayerModel.head.translateAndRotate(poseStack);
      }

      this.skipHeadBoneSync = true;

      try {
         if (FleshRegenTextureManager.shouldRenderHeadBone(headValue) && headTexture != null) {
            this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_head_bone.geo.json", headTexture);
         }

         if (FleshRegenTextureManager.shouldRenderHeadFlesh(headValue) && headTexture != null) {
            this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_head_flesh.geo.json", headTexture);
         }

         if (FleshRegenTextureManager.shouldRenderHeadSkin(headValue)) {
            ResourceLocation skinTexture = this.getPlayerSkinTexture();
            if (skinTexture != null) {
               this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_head_skin.geo.json", skinTexture);
            }
         }
      } finally {
         this.skipHeadBoneSync = false;
      }

      poseStack.popPose();
   }

   private void renderBodyGeo(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int bodyValue) {
      ResourceLocation bodyTexture = FleshRegenTextureManager.getBodyTexture(bodyValue);
      if (FleshRegenTextureManager.shouldRenderBodyBone(bodyValue) && bodyTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_body_bone.geo.json", bodyTexture);
      }

      if (FleshRegenTextureManager.shouldRenderBodyFlesh(bodyValue) && bodyTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_body_flesh.geo.json", bodyTexture);
      }

      if (FleshRegenTextureManager.shouldRenderBodySkin(bodyValue)) {
         ResourceLocation skinTexture = this.getPlayerSkinTexture();
         if (skinTexture != null) {
            this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_body_skin.geo.json", skinTexture);
         }
      }
   }

   private void renderRightArmGeo(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int armValue) {
      ResourceLocation armTexture = FleshRegenTextureManager.getRightArmTexture(armValue);
      if (FleshRegenTextureManager.shouldRenderRightArmBone(armValue) && armTexture != null) {
         String boneGeo = this.isSlimModel() ? "flesh_regen_right_arm_bone_slim.geo.json" : "flesh_regen_right_arm_bone.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, boneGeo, armTexture);
      }

      if (FleshRegenTextureManager.shouldRenderRightArmFlesh(armValue) && armTexture != null) {
         String fleshGeo = this.isSlimModel() ? "flesh_regen_right_arm_flesh_slim.geo.json" : "flesh_regen_right_arm_flesh.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, fleshGeo, armTexture);
      }

      if (FleshRegenTextureManager.shouldRenderRightArmSkin(armValue)) {
         ResourceLocation skinTexture = this.getPlayerSkinTexture();
         if (skinTexture != null) {
            String skinGeo = this.isSlimModel() ? "flesh_regen_right_arm_skin_slim.geo.json" : "flesh_regen_right_arm_skin.geo.json";
            this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, skinGeo, skinTexture);
         }
      }
   }

   private void renderRightHandGeo(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int handValue) {
      ResourceLocation handTexture = FleshRegenTextureManager.getRightHandTexture(handValue);
      if (FleshRegenTextureManager.shouldRenderRightHandBone(handValue) && handTexture != null) {
         String boneGeo = this.isSlimModel() ? "flesh_regen_right_hand_bone_slim.geo.json" : "flesh_regen_right_hand_bone.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, boneGeo, handTexture);
      }

      if (FleshRegenTextureManager.shouldRenderRightHandFlesh(handValue) && handTexture != null) {
         String fleshGeo = this.isSlimModel() ? "flesh_regen_right_hand_flesh_slim.geo.json" : "flesh_regen_right_hand_flesh.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, fleshGeo, handTexture);
      }

      if (FleshRegenTextureManager.shouldRenderRightHandSkin(handValue)) {
         ResourceLocation skinTexture = this.getPlayerSkinTexture();
         if (skinTexture != null) {
            String skinGeo = this.isSlimModel() ? "flesh_regen_right_hand_skin_slim.geo.json" : "flesh_regen_right_hand_skin.geo.json";
            this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, skinGeo, skinTexture);
         }
      }
   }

   private void renderLeftArmGeo(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int armValue) {
      ResourceLocation armTexture = FleshRegenTextureManager.getLeftArmTexture(armValue);
      if (FleshRegenTextureManager.shouldRenderLeftArmBone(armValue) && armTexture != null) {
         String boneGeo = this.isSlimModel() ? "flesh_regen_left_arm_bone_slim.geo.json" : "flesh_regen_left_arm_bone.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, boneGeo, armTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLeftArmFlesh(armValue) && armTexture != null) {
         String fleshGeo = this.isSlimModel() ? "flesh_regen_left_arm_flesh_slim.geo.json" : "flesh_regen_left_arm_flesh.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, fleshGeo, armTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLeftArmSkin(armValue)) {
         ResourceLocation skinTexture = this.getPlayerSkinTexture();
         if (skinTexture != null) {
            String skinGeo = this.isSlimModel() ? "flesh_regen_left_arm_skin_slim.geo.json" : "flesh_regen_left_arm_skin.geo.json";
            this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, skinGeo, skinTexture);
         }
      }
   }

   private void renderLeftHandGeo(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int handValue) {
      ResourceLocation handTexture = FleshRegenTextureManager.getLeftHandTexture(handValue);
      if (FleshRegenTextureManager.shouldRenderLeftHandBone(handValue) && handTexture != null) {
         String boneGeo = this.isSlimModel() ? "flesh_regen_left_hand_bone_slim.geo.json" : "flesh_regen_left_hand_bone.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, boneGeo, handTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLeftHandFlesh(handValue) && handTexture != null) {
         String fleshGeo = this.isSlimModel() ? "flesh_regen_left_hand_flesh_slim.geo.json" : "flesh_regen_left_hand_flesh.geo.json";
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, fleshGeo, handTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLeftHandSkin(handValue)) {
         ResourceLocation skinTexture = this.getPlayerSkinTexture();
         if (skinTexture != null) {
            String skinGeo = this.isSlimModel() ? "flesh_regen_left_hand_skin_slim.geo.json" : "flesh_regen_left_hand_skin.geo.json";
            this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, skinGeo, skinTexture);
         }
      }
   }

   private void renderRightLegGeo(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int legValue) {
      ResourceLocation legTexture = FleshRegenTextureManager.getLegsTexture(legValue);
      if (FleshRegenTextureManager.shouldRenderLegsBone(legValue) && legTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_leg_bone.geo.json", legTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLegsFlesh(legValue) && legTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_leg_flesh.geo.json", legTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLegsSkin(legValue)) {
         ResourceLocation skinTexture = this.getPlayerSkinTexture();
         if (skinTexture != null) {
            this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_leg_skin.geo.json", skinTexture);
         }
      }
   }

   private void renderLeftLegGeo(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int legValue) {
      ResourceLocation legTexture = FleshRegenTextureManager.getLegsTexture(legValue);
      if (FleshRegenTextureManager.shouldRenderLegsBone(legValue) && legTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_leg_bone.geo.json", legTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLegsFlesh(legValue) && legTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_leg_flesh.geo.json", legTexture);
      }

      if (FleshRegenTextureManager.shouldRenderLegsSkin(legValue)) {
         ResourceLocation skinTexture = this.getPlayerSkinTexture();
         if (skinTexture != null) {
            this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_leg_skin.geo.json", skinTexture);
         }
      }
   }

   private void renderRightFeetGeo(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int feetValue) {
      ResourceLocation feetTexture = FleshRegenTextureManager.getFeetTexture(feetValue);
      if (FleshRegenTextureManager.shouldRenderFeetBone(feetValue) && feetTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_feet_bone.geo.json", feetTexture);
      }

      if (FleshRegenTextureManager.shouldRenderFeetFlesh(feetValue) && feetTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_feet_flesh.geo.json", feetTexture);
      }

      if (FleshRegenTextureManager.shouldRenderFeetSkin(feetValue)) {
         ResourceLocation skinTexture = this.getPlayerSkinTexture();
         if (skinTexture != null) {
            this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_right_feet_skin.geo.json", skinTexture);
         }
      }
   }

   private void renderLeftFeetGeo(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, int feetValue) {
      ResourceLocation feetTexture = FleshRegenTextureManager.getFeetTexture(feetValue);
      if (FleshRegenTextureManager.shouldRenderFeetBone(feetValue) && feetTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_feet_bone.geo.json", feetTexture);
      }

      if (FleshRegenTextureManager.shouldRenderFeetFlesh(feetValue) && feetTexture != null) {
         this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_feet_flesh.geo.json", feetTexture);
      }

      if (FleshRegenTextureManager.shouldRenderFeetSkin(feetValue)) {
         ResourceLocation skinTexture = this.getPlayerSkinTexture();
         if (skinTexture != null) {
            this.renderSingleGeo(poseStack, bufferSource, packedLight, partialTick, "flesh_regen_left_feet_skin.geo.json", skinTexture);
         }
      }
   }

   private void renderSingleGeo(
      PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, float partialTick, String geoFile, ResourceLocation texture
   ) {
      ((FleshRegenEntityRenderer.FleshRegenGeoModel)this.model).setCurrentGeoFile(geoFile);
      RenderType renderType = RenderType.entityTranslucent(texture);
      this.render(poseStack, VIRTUAL_INSTANCE, bufferSource, renderType, null, packedLight, partialTick);
   }

   public void preRender(
      PoseStack poseStack,
      FleshRegenEntityRenderer.VirtualFleshRegen animatable,
      BakedGeoModel model,
      @Nullable MultiBufferSource bufferSource,
      @Nullable VertexConsumer buffer,
      boolean isReRender,
      float partialTick,
      int packedLight,
      int packedOverlay,
      int colour
   ) {
      this.objectRenderTranslations = new Matrix4f(poseStack.last().pose());
      this.setupBoneMatching(model);
   }

   public void actuallyRender(
      PoseStack poseStack,
      FleshRegenEntityRenderer.VirtualFleshRegen animatable,
      BakedGeoModel model,
      @Nullable RenderType renderType,
      MultiBufferSource bufferSource,
      @Nullable VertexConsumer buffer,
      boolean isReRender,
      float partialTick,
      int packedLight,
      int packedOverlay,
      int colour
   ) {
      poseStack.pushPose();
      boolean isPlayer = this.currentEntity instanceof Player;
      if (!isPlayer && !this.usePlayerGeoTransform) {
         poseStack.scale(1.0F, -1.0F, 1.0F);
         poseStack.translate(0.0F, -1.5F, 0.0F);
      } else {
         poseStack.scale(-1.0F, -1.0F, 1.0F);
         poseStack.translate(0.0F, -1.5F, 0.0F);
      }

      poseStack.translate(0.0F, 0.01F, 0.0F);
      this.modelRenderTranslations = new Matrix4f(poseStack.last().pose());

      for (GeoBone bone : model.topLevelBones()) {
         this.renderRecursively(poseStack, animatable, bone, renderType, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, colour);
      }

      poseStack.popPose();
   }

   private void setupBoneMatching(BakedGeoModel model) {
      HumanoidModel<?> modelToUse = (HumanoidModel<?>)(this.currentPlayerModel != null ? this.currentPlayerModel : this.currentHumanoidModel);
      if (modelToUse != null) {
         if (!this.skipHeadBoneSync) {
            this.matchHumanoidModelPart(model, modelToUse.head, "head");
         } else {
            Optional<GeoBone> headOpt = model.getBone("head");
            if (headOpt.isPresent()) {
               GeoBone hb = headOpt.get();
               hb.setPosX(0.0F);
               hb.setPosY(0.0F);
               hb.setPosZ(0.0F);
               hb.setRotX(0.0F);
               hb.setRotY(0.0F);
               hb.setRotZ(0.0F);
            }
         }

         this.matchHumanoidModelPart(model, modelToUse.body, "body");
         this.matchHumanoidModelPart(model, this.swapHumanoidLimbSides ? modelToUse.leftArm : modelToUse.rightArm, "right_arm");
         this.matchHumanoidModelPart(model, this.swapHumanoidLimbSides ? modelToUse.rightArm : modelToUse.leftArm, "left_arm");
         this.matchHumanoidModelPart(model, this.swapHumanoidLimbSides ? modelToUse.leftLeg : modelToUse.rightLeg, "right_leg");
         this.matchHumanoidModelPart(model, this.swapHumanoidLimbSides ? modelToUse.rightLeg : modelToUse.leftLeg, "left_leg");
      }
   }

   private void matchHumanoidModelPart(BakedGeoModel model, ModelPart part, String boneName) {
      Optional<GeoBone> optionalBone = model.getBone(boneName);
      if (!optionalBone.isEmpty()) {
         GeoBone bone = optionalBone.get();
         boolean usePlayerSigns = this.currentEntity instanceof Player || this.usePlayerBoneRotationSigns;
         float yRotSign = usePlayerSigns ? -1.0F : 1.0F;
         float zRotSign = usePlayerSigns ? 1.0F : -1.0F;
         switch (boneName) {
            case "head":
               bone.setPosX(part.x * 1.0F);
               bone.setPosY(-part.y + 0.0F);
               bone.setPosZ(part.z + 0.0F);
               bone.setRotX(-part.xRot);
               bone.setRotY(yRotSign * part.yRot);
               bone.setRotZ(zRotSign * part.zRot);
               break;
            case "body":
               bone.setPosX(part.x * 0.0F);
               bone.setPosY(-part.y + 0.0F);
               bone.setPosZ(part.z + 0.0F);
               bone.setRotX(-part.xRot);
               bone.setRotY(yRotSign * part.yRot);
               bone.setRotZ(zRotSign * part.zRot);
               break;
            case "right_arm":
            case "left_arm":
               float armXCalc = part.x * 1.0F;
               armXCalc += "right_arm".equals(boneName) ? 5.0F : -5.0F;
               bone.setPosX(armXCalc);
               bone.setPosY(-part.y + 2.0F);
               bone.setPosZ(part.z + 0.0F);
               bone.setRotX(-part.xRot);
               bone.setRotY(yRotSign * part.yRot);
               bone.setRotZ(zRotSign * part.zRot);
               break;
            case "right_leg":
            case "left_leg":
               float legXCalc = part.x * 1.0F;
               legXCalc += "right_leg".equals(boneName) ? 2.0F : -2.0F;
               bone.setPosX(legXCalc);
               bone.setPosY(-part.y + 12.0F);
               bone.setPosZ(part.z + 0.0F);
               bone.setRotX(-part.xRot);
               bone.setRotY(yRotSign * part.yRot);
               bone.setRotZ(zRotSign * part.zRot);
               break;
            default:
               bone.setPosX(-part.x);
               bone.setPosY(-part.y);
               bone.setPosZ(part.z);
               bone.setRotX(-part.xRot);
               bone.setRotY(yRotSign * part.yRot);
               bone.setRotZ(zRotSign * part.zRot);
         }
      }
   }

   static {
      registerPart("Head", "flesh_regen_head_flesh.geo.json", "head", "head/head_", 17);
      registerPart("Body", "flesh_regen_body_flesh.geo.json", "body", "", 20);
      registerPart("Right.Arm", "flesh_regen_arm_right_flesh.geo.json", "right_arm", "arms/arms_", 18);
      registerPart("Left.Arm", "flesh_regen_arm_left_flesh.geo.json", "left_arm", "arms/arms_", 18);
      registerPart("Right.Hand", "flesh_regen_hand_right_flesh.geo.json", "right_arm", "hands/hands_", 12);
      registerPart("Left.Hand", "flesh_regen_hand_left_flesh.geo.json", "left_arm", "hands/hands_", 12);
      registerPart("Legs", "flesh_regen_legs_flesh.geo.json", "right_leg", "legs/legs_", 20);
      registerPart("Feet", "flesh_regen_feet_flesh.geo.json", "right_leg", "feet/feet_", 11);
   }

   private static class FleshRegenGeoModel extends GeoModel<FleshRegenEntityRenderer.VirtualFleshRegen> {
      private String currentGeoFile = "flesh_regen_head_flesh.geo.json";

      public void setCurrentGeoFile(String geoFile) {
         this.currentGeoFile = geoFile;
      }

      public ResourceLocation getModelResource(FleshRegenEntityRenderer.VirtualFleshRegen animatable) {
         return ResourceLocation.fromNamespaceAndPath("theboysmod", "geo/flesh_regen/" + this.currentGeoFile);
      }

      public ResourceLocation getTextureResource(FleshRegenEntityRenderer.VirtualFleshRegen animatable) {
         return ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/models/flesh_regen/body_layer.png");
      }

      public ResourceLocation getAnimationResource(FleshRegenEntityRenderer.VirtualFleshRegen animatable) {
         return null;
      }
   }

   private static class PartConfig {
      final String geoFile;
      final String boneName;
      final String maskPrefix;
      final int maxScore;

      PartConfig(String geoFile, String boneName, String maskPrefix, int maxScore) {
         this.geoFile = geoFile;
         this.boneName = boneName;
         this.maskPrefix = maskPrefix;
         this.maxScore = maxScore;
      }
   }

   public static class VirtualFleshRegen implements GeoAnimatable {
      private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

      public void registerControllers(ControllerRegistrar controllers) {
      }

      public AnimatableInstanceCache getAnimatableInstanceCache() {
         return this.cache;
      }

      public double getTick(Object object) {
         return 0.0;
      }
   }
}
