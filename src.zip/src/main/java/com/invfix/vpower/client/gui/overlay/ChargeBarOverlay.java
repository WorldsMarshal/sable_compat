package com.invfix.vpower.client.gui.overlay;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw.Layer;

public final class ChargeBarOverlay {
   private static final int CHARGE_BAR_WIDTH = 16;
   private static final int CHARGE_BAR_HEIGHT = 2;
   private static final long HELD_TIMEOUT_MS = 150L;
   private static final long TIMED_DISPLAY_MS = 1500L;
   private static float heldProgress = 0.0F;
   private static int heldColor = -1;
   private static long heldEndTime = 0L;
   private static float timedProgress = 0.0F;
   private static int timedColor = -1;
   private static long timedEndTime = 0L;
   public static final Layer HUD_CHARGE_BAR = (guiGraphics, deltaTracker) -> {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft.player != null && !minecraft.options.hideGui && !minecraft.player.isSpectator()) {
         long now = System.currentTimeMillis();
         if (now <= heldEndTime) {
            renderChargeBar(guiGraphics, guiGraphics.guiWidth(), guiGraphics.guiHeight(), heldProgress, heldColor);
         } else {
            if (now <= timedEndTime) {
               renderChargeBar(guiGraphics, guiGraphics.guiWidth(), guiGraphics.guiHeight(), timedProgress, timedColor);
            }
         }
      }
   };

   private ChargeBarOverlay() {
   }

   public static void showHeld(float progress, int baseColor) {
      heldProgress = clamp01(progress);
      heldColor = baseColor;
      heldEndTime = System.currentTimeMillis() + 150L;
   }

   public static void clearHeld() {
      heldEndTime = 0L;
   }

   public static void showTimed(float progress, int baseColor) {
      timedProgress = clamp01(progress);
      timedColor = baseColor;
      timedEndTime = System.currentTimeMillis() + 1500L;
   }

   private static void renderChargeBar(GuiGraphics guiGraphics, int screenWidth, int screenHeight, float chargeProgress, int baseColor) {
      int centerX = screenWidth / 2;
      int centerY = screenHeight / 2;
      int barX = centerX - 8;
      int barY = centerY + 10;
      guiGraphics.fill(barX - 1, barY - 1, barX + 16 + 1, barY + 2 + 1, Integer.MIN_VALUE);
      int fillWidth = (int)(16.0F * chargeProgress);
      if (fillWidth > 0) {
         int color = baseColor;
         if (chargeProgress >= 1.0F) {
            int tick = (int)(System.currentTimeMillis() / 100L);
            color = tick % 2 == 0 ? -256 : -13312;
         }

         guiGraphics.fill(barX, barY, barX + fillWidth, barY + 2, color);
      }
   }

   private static float clamp01(float value) {
      return Math.max(0.0F, Math.min(1.0F, value));
   }
}
