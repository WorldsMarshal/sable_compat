package com.invfix.vpower.client;

import com.invfix.heatvision.client.HeatVisionRenderer;
import com.invfix.vpower.VPower;
import com.invfix.vpower.client.animation.ModAnimations;
import com.invfix.vpower.client.event.ClientFleshRegenArmRenderEvents;
import com.invfix.vpower.client.flight.FlightClientHandler;
import com.invfix.vpower.client.flight.WingFlightClientHandler;
import com.invfix.vpower.client.gui.overlay.ChargeBarOverlay;
import com.invfix.vpower.client.gui.overlay.TempVSideEffectOverlay;
import com.invfix.vpower.client.gui.overlay.TemporaryVTimerOverlay;
import com.invfix.vpower.client.gui.overlay.XRayVisionOverlay;
import com.invfix.vpower.client.input.KeyInputHandler;
import com.invfix.vpower.client.input.ModKeyBindings;
import com.invfix.vpower.client.model.wings.FeatheredWingsModel;
import com.invfix.vpower.client.model.wings.WingsModels;
import com.invfix.vpower.client.particle.BloodParticle;
import com.invfix.vpower.client.particle.ClapParticle;
import com.invfix.vpower.client.renderer.FireBlastRenderer;
import com.invfix.vpower.client.renderer.VisualFallingBlockRenderer;
import com.invfix.vpower.client.renderer.WaterSprayRenderer;
import com.invfix.vpower.client.renderer.layer.FashionEggHeadLayer;
import com.invfix.vpower.client.renderer.layer.FlightWingsLayer;
import com.invfix.vpower.client.renderer.layer.NailongBelialBodyLayer;
import com.invfix.vpower.client.renderer.layer.SoundWaveHeadLayer;
import com.invfix.vpower.client.renderer.layer.ToadBodyLayer;
import com.invfix.vpower.entity.ModEntities;
import com.invfix.vpower.registry.ModParticles;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.LaserEyeSkill;
import net.minecraft.client.Minecraft;
import dev.kosmx.playerAnim.api.layered.IAnimation;
import dev.kosmx.playerAnim.api.layered.ModifierLayer;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationFactory;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;

/**
 * Клиентская регистрация V — из theboysModClient и SkillBarClientEvents The Boys, без NPC, костюмов, плаща, мебели,
 * телефона, одухотворения и панели навыков (её место заняли слоты способностей Invincible).
 */
public final class VPowerClient {

    private static final ModelLayerLocation SOUND_WAVE_HEAD_LAYER =
            new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(VPower.MODID, "sound_wave_head"), "main");

    private VPowerClient() {}

    private static final String LASER_EYE = LaserEyeSkill.ID.toString();

    /**
     * Свечение глаз Heat Vision (HeatVisionRenderer) у лазерных глаз V: пока навык активен (клавиша зажата) — даже
     * в Playful mode, где сам луч погашен.
     */
    private static boolean laserEyeGlowing(AbstractClientPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && player.getId() == mc.player.getId()) {
            SkillData data = player.getData(ModSkillAttachments.SKILL_DATA.get());
            return data.hasSkill(LASER_EYE) && data.isSkillActive(LASER_EYE);
        }
        return ClientSkillStateCache.isSkillActive(player.getId(), LASER_EYE);
    }

    @EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {

        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {
            ClientFleshRegenArmRenderEvents.register();
            KeyInputHandler.register();
            PlayerAnimationFactory.ANIMATION_DATA_FACTORY.registerFactory(ModAnimations.ANIMATION_RESOURCE, 1000,
                    player -> new ModifierLayer<IAnimation>());
            event.enqueueWork(() -> HeatVisionRenderer.addGlowSource(VPowerClient::laserEyeGlowing));
        }

        @SubscribeEvent
        public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
            event.register(ModKeyBindings.ADJUST_DAMAGE);
        }

        @SubscribeEvent
        public static void onRegisterGuiLayers(RegisterGuiLayersEvent event) {
            event.registerBelow(VanillaGuiLayers.CROSSHAIR, id("xray_vision_filter"), XRayVisionOverlay.HUD_XRAY_VISION_FILTER);
            event.registerAbove(VanillaGuiLayers.HOTBAR, id("temporary_v_timer"), TemporaryVTimerOverlay.HUD_TEMPORARY_V);
            event.registerAboveAll(id("temp_v_side_effect"), TempVSideEffectOverlay.HUD_TEMP_V_SIDE_EFFECT);
            event.registerAboveAll(id("charge_bar"), ChargeBarOverlay.HUD_CHARGE_BAR);
            event.registerAbove(VanillaGuiLayers.PLAYER_HEALTH, id("shield_bar"), ShieldBarOverlay.HUD_SHIELD);
        }

        @SubscribeEvent
        public static void onRegisterParticles(RegisterParticleProvidersEvent event) {
            event.registerSpriteSet(ModParticles.CLAP.get(), ClapParticle.Provider::new);
            event.registerSpriteSet(ModParticles.BLOOD.get(), BloodParticle.Provider::new);
        }

        @SubscribeEvent
        public static void onRegisterLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
            event.registerLayerDefinition(WingsModels.FEATHERED, FeatheredWingsModel::getLayerDefinition);
            event.registerLayerDefinition(SOUND_WAVE_HEAD_LAYER,
                    () -> LayerDefinition.create(PlayerModel.createMesh(new CubeDeformation(0.025F), false), 64, 64));
        }

        @SubscribeEvent
        public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(ModEntities.FIRE_BLAST_PROJECTILE.get(), FireBlastRenderer::new);
            event.registerEntityRenderer(ModEntities.WATER_SPRAY.get(), WaterSprayRenderer::new);
            event.registerEntityRenderer(ModEntities.VISUAL_FALLING_BLOCK.get(), VisualFallingBlockRenderer::new);
        }

        @SubscribeEvent
        public static void onAddLayers(EntityRenderersEvent.AddLayers event) {
            for (PlayerSkin.Model skin : event.getSkins()) {
                try {
                    if (!(event.getSkin(skin) instanceof PlayerRenderer renderer)) continue;
                    renderer.addLayer(new FlightWingsLayer<>(renderer, event.getEntityModels()));
                    PlayerModel<AbstractClientPlayer> head = new PlayerModel<>(event.getEntityModels().bakeLayer(SOUND_WAVE_HEAD_LAYER), false);
                    renderer.addLayer(new SoundWaveHeadLayer(renderer, head));
                    renderer.addLayer(new FashionEggHeadLayer(renderer));
                    renderer.addLayer(new ToadBodyLayer(renderer));
                    renderer.addLayer(new NailongBelialBodyLayer(renderer));
                } catch (Exception e) {
                    VPower.LOGGER.warn("Failed to add V render layers for skin type: {}", skin, e);
                }
            }
        }

        private static ResourceLocation id(String path) {
            return ResourceLocation.fromNamespaceAndPath(VPower.MODID, path);
        }
    }

    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
    public static final class GameBus {

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            ClientSkillStateCache.clearAll();
            FlightClientHandler.clearRemoteCache();
            WingFlightClientHandler.clearRemoteCache();
        }
    }
}
