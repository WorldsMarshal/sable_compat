package com.invfix.vpower.client;

import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLivingEvent.Post;
import net.neoforged.neoforge.client.event.RenderLivingEvent.Pre;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public class FleshRegenBodyPartHandler {
   private static int debugCounter = 0;

   @SubscribeEvent
   public static void onRenderLivingPre(Pre<?, ?> event) {
      if (event.getEntity() instanceof AbstractClientPlayer player) {
         if (event.getRenderer().getModel() instanceof PlayerModel<?> playerModel) {
            FleshRegenData var5 = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
            hidePartIfNeeded(playerModel.head, playerModel.hat, "Head", var5);
            hidePartIfNeeded(playerModel.body, playerModel.jacket, "Body", var5);
            hidePartIfNeeded(playerModel.rightArm, playerModel.rightSleeve, "Right.Arm", var5);
            hidePartIfNeeded(playerModel.leftArm, playerModel.leftSleeve, "Left.Arm", var5);
            hidePartIfNeeded(playerModel.rightArm, playerModel.rightSleeve, "Right.Hand", var5);
            hidePartIfNeeded(playerModel.leftArm, playerModel.leftSleeve, "Left.Hand", var5);
            hidePartIfNeeded(playerModel.rightLeg, playerModel.rightPants, "Right.Leg", var5);
            hidePartIfNeeded(playerModel.leftLeg, playerModel.leftPants, "Left.Leg", var5);
            hidePartIfNeeded(playerModel.rightLeg, playerModel.rightPants, "Right.Feet", var5);
            hidePartIfNeeded(playerModel.leftLeg, playerModel.leftPants, "Left.Feet", var5);
         }
      }
   }

   @SubscribeEvent
   public static void onRenderLivingPost(Post<?, ?> event) {
      if (event.getEntity() instanceof AbstractClientPlayer player) {
         if (event.getRenderer().getModel() instanceof PlayerModel<?> playerModel) {
            playerModel.head.visible = true;
            playerModel.hat.visible = true;
            playerModel.body.visible = true;
            playerModel.jacket.visible = true;
            playerModel.rightArm.visible = true;
            playerModel.rightSleeve.visible = true;
            playerModel.leftArm.visible = true;
            playerModel.leftSleeve.visible = true;
            playerModel.rightLeg.visible = true;
            playerModel.rightPants.visible = true;
            playerModel.leftLeg.visible = true;
            playerModel.leftPants.visible = true;
         }
      }
   }

   private static void hidePartIfNeeded(ModelPart main, ModelPart overlay, String partName, FleshRegenData data) {
      if (data.shouldHide(partName)) {
         main.visible = false;
         if (overlay != null) {
            overlay.visible = false;
         }
      }
   }
}
