package com.invfix.vpower.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.invfix.vpower.VPower;
import com.invfix.vpower.client.dynamictexture.HumanTorchTextureManager;
import com.invfix.vpower.client.invisibility.InvisibilityRenderHelper;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderArmEvent;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public class FireArmRenderer {
   @SubscribeEvent
   public static void onRenderArm(RenderArmEvent event) {
      AbstractClientPlayer mc = event.getPlayer();
      if (mc instanceof AbstractClientPlayer) {
         AbstractClientPlayer player = mc;
         Minecraft mcx = Minecraft.getInstance();
         boolean firstPerson = mcx.player != null && mcx.player.getUUID().equals(mc.getUUID()) && mcx.options.getCameraType().isFirstPerson();
         if (firstPerson) {
            if (InvisibilityRenderHelper.shouldHideBody(mc)) {
               event.setCanceled(true);
            } else {
               try {
                  SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
                  int fireTimer = skillData.getFireTimer();
                  if (fireTimer <= 0 || !HumanTorchTextureManager.shouldRenderBody(fireTimer)) {
                     return;
                  }

                  ResourceLocation texture = HumanTorchTextureManager.getTexture(fireTimer);
                  if (texture == null) {
                     return;
                  }

                  if (!(mcx.getEntityRenderDispatcher().getRenderer(player) instanceof PlayerRenderer playerRenderer)) {
                     return;
                  }

                  event.setCanceled(true);
                  PoseStack poseStack = event.getPoseStack();
                  MultiBufferSource buffer = event.getMultiBufferSource();
                  HumanoidArm arm = event.getArm();
                  PlayerModel<AbstractClientPlayer> model = (PlayerModel<AbstractClientPlayer>)playerRenderer.getModel();
                  model.attackTime = 0.0F;
                  model.crouching = false;
                  model.swimAmount = 0.0F;
                  RenderType renderType = HumanTorchRenderer.getTranslucentNoDepthTest(texture);
                  VertexConsumer vertexConsumer = buffer.getBuffer(renderType);
                  int color = -50331649;
                  if (arm == HumanoidArm.RIGHT) {
                     model.rightArm.xRot = 0.0F;
                     model.rightArm.render(poseStack, vertexConsumer, 15728880, OverlayTexture.NO_OVERLAY, color);
                     model.rightSleeve.render(poseStack, vertexConsumer, 15728880, OverlayTexture.NO_OVERLAY, color);
                  } else {
                     model.leftArm.xRot = 0.0F;
                     model.leftArm.render(poseStack, vertexConsumer, 15728880, OverlayTexture.NO_OVERLAY, color);
                     model.leftSleeve.render(poseStack, vertexConsumer, 15728880, OverlayTexture.NO_OVERLAY, color);
                  }
               } catch (Exception var16) {
                  VPower.LOGGER.error("[FireArm] FP render error", var16);
               }
            }
         }
      }
   }
}
