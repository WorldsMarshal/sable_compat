package com.invfix.vpower.client.event;

import com.mojang.blaze3d.vertex.PoseStack;
import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.client.belial.NailongBelialClientHandler;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderPlayerEvent.Post;
import net.neoforged.neoforge.client.event.RenderPlayerEvent.Pre;

@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
public class ClientPlayerModelEvents {
   private static final double FEETLESS_Y_OFFSET = -0.3;
   private static final double LEGLESS_Y_OFFSET = -0.9;
   private static final double BODYLESS_Y_OFFSET = -1.4;

   @SubscribeEvent
   public static void onRenderPlayerPre(Pre event) {
      Player player = event.getEntity();

      FleshRegenData data;
      try {
         data = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
      } catch (Exception var12) {
         return;
      }

      PlayerModel<AbstractClientPlayer> model = (PlayerModel<AbstractClientPlayer>)event.getRenderer().getModel();
      if (player instanceof AbstractClientPlayer clientPlayer && NailongBelialClientHandler.isTransformed(clientPlayer)) {
         hideAll(model);
         return;
      }

      int bodyScore = data.getScore("Body");
      int rightLegScore = data.getScore("Right.Leg");
      int leftLegScore = data.getScore("Left.Leg");
      int rightFeetScore = data.getScore("Right.Feet");
      int leftFeetScore = data.getScore("Left.Feet");
      double yOffset = 0.0;
      if (player.isPassenger()) {
         if (bodyScore == 0) {
            yOffset = -0.9;
         }
      } else if (bodyScore == 0) {
         yOffset = -1.4;
      } else if (rightLegScore == 0 && leftLegScore == 0) {
         yOffset = -0.9;
      } else if (rightFeetScore == 0 && leftFeetScore == 0) {
         yOffset = -0.3;
      }

      if (yOffset != 0.0) {
         PoseStack poseStack = event.getPoseStack();
         poseStack.translate(0.0, yOffset, 0.0);
      }

      if (data.shouldHide("Head")) {
         model.head.visible = false;
         model.hat.visible = false;
      }

      if (data.shouldHide("Body")) {
         model.body.visible = false;
         model.jacket.visible = false;
      }

      if (data.shouldHide("Right.Arm")) {
         model.rightArm.visible = false;
         model.rightSleeve.visible = false;
      }

      if (data.shouldHide("Left.Arm")) {
         model.leftArm.visible = false;
         model.leftSleeve.visible = false;
      }

      if (data.shouldHide("Right.Leg")) {
         model.rightLeg.visible = false;
         model.rightPants.visible = false;
      }

      if (data.shouldHide("Left.Leg")) {
         model.leftLeg.visible = false;
         model.leftPants.visible = false;
      }
   }

   @SubscribeEvent
   public static void onRenderPlayerPost(Post event) {
      PlayerModel<AbstractClientPlayer> model = (PlayerModel<AbstractClientPlayer>)event.getRenderer().getModel();
      model.head.visible = true;
      model.hat.visible = true;
      model.body.visible = true;
      model.jacket.visible = true;
      model.rightArm.visible = true;
      model.rightSleeve.visible = true;
      model.leftArm.visible = true;
      model.leftSleeve.visible = true;
      model.rightLeg.visible = true;
      model.rightPants.visible = true;
      model.leftLeg.visible = true;
      model.leftPants.visible = true;
   }

   private static void hideAll(PlayerModel<AbstractClientPlayer> model) {
      model.head.visible = false;
      model.hat.visible = false;
      model.body.visible = false;
      model.jacket.visible = false;
      model.rightArm.visible = false;
      model.rightSleeve.visible = false;
      model.leftArm.visible = false;
      model.leftSleeve.visible = false;
      model.rightLeg.visible = false;
      model.rightPants.visible = false;
      model.leftLeg.visible = false;
      model.leftPants.visible = false;
   }
}
