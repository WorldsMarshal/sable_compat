package com.invfix.vpower.client.animation;

import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
import dev.kosmx.playerAnim.api.layered.IAnimation;
import dev.kosmx.playerAnim.api.layered.KeyframeAnimationPlayer;
import dev.kosmx.playerAnim.api.layered.ModifierLayer;
import dev.kosmx.playerAnim.api.layered.modifier.AbstractFadeModifier;
import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
import dev.kosmx.playerAnim.core.util.Ease;
import dev.kosmx.playerAnim.core.util.Vec3f;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationRegistry;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.NotNull;

public class AnimationHelper {
   private static final Map<Integer, String> playerAnimations = new ConcurrentHashMap<>();

   public static void playMeditation(Player player) {
      playAnimationWithFade(player, ModAnimations.MEDITATION_UP, 2, false);
   }

   public static void stopMeditation(Player player) {
      stopAnimation(player, 5);
   }

   public static void playAnimationWithFade(Player player, ResourceLocation resourceLocation, int fadeInTicks, boolean loop, boolean firstPerson, float speed) {
      playAnimationInternal(player, resourceLocation, fadeInTicks, loop, firstPerson, speed);
   }

   public static void playAnimationWithFade(Player player, ResourceLocation resourceLocation, int fadeInTicks, boolean loop, boolean firstPerson) {
      playAnimationInternal(player, resourceLocation, fadeInTicks, loop, firstPerson, 1.0F);
   }

   public static void playAnimationWithFade(Player player, ResourceLocation resourceLocation, int fadeInTicks, boolean loop) {
      playAnimationInternal(player, resourceLocation, fadeInTicks, loop, false, 1.0F);
   }

   private static void playAnimationInternal(
      final Player player, final ResourceLocation resourceLocation, int fadeInTicks, boolean loop, boolean firstPerson, final float speed
   ) {
      if (player instanceof AbstractClientPlayer clientPlayer) {
         if (PlayerAnimationRegistry.getAnimation(resourceLocation) instanceof KeyframeAnimation keyframeAnimation) {
            ModifierLayer<IAnimation> playerAnimationData = (ModifierLayer<IAnimation>)PlayerAnimationAccess.getPlayerAssociatedData(clientPlayer)
               .get(ModAnimations.ANIMATION_RESOURCE);
            if (playerAnimationData != null) {
               final int endTick = keyframeAnimation.endTick;
               final KeyframeAnimationPlayer animationPlayer;
               if (loop) {
                  animationPlayer = new KeyframeAnimationPlayer(keyframeAnimation) {
                     private float accumulator = 0.0F;

                     public void tick() {
                        this.accumulator = this.accumulator + speed;

                        while (this.accumulator >= 1.0F) {
                           this.accumulator--;
                           super.tick();

                           try {
                              Field field = KeyframeAnimationPlayer.class.getDeclaredField("currentTick");
                              field.setAccessible(true);
                              int currentTick = field.getInt(this);
                              if (currentTick >= endTick) {
                                 field.setInt(this, 0);
                              }
                           } catch (Exception var3) {
                           }
                        }
                     }

                     public boolean isActive() {
                        return true;
                     }
                  };
               } else {
                  animationPlayer = new KeyframeAnimationPlayer(keyframeAnimation) {
                     private boolean switched = false;
                     private float accumulator = 0.0F;

                     public void tick() {
                        this.accumulator = this.accumulator + speed;

                        while (this.accumulator >= 1.0F) {
                           this.accumulator--;
                           super.tick();
                        }

                        if (!this.switched
                           && (resourceLocation.equals(ModAnimations.MEDITATION_UP) || resourceLocation.equals(ModAnimations.WINGS_HOVER_START))) {
                           try {
                              Field field = KeyframeAnimationPlayer.class.getDeclaredField("currentTick");
                              field.setAccessible(true);
                              int currentTick = field.getInt(this);
                              if (currentTick >= endTick - 2) {
                                 this.switched = true;
                                 if (resourceLocation.equals(ModAnimations.MEDITATION_UP)) {
                                    AnimationHelper.playAnimationWithFade(player, ModAnimations.MEDITATION_ON, 3, true);
                                 } else if (resourceLocation.equals(ModAnimations.WINGS_HOVER_START)) {
                                    AnimationHelper.playAnimationWithFade(player, ModAnimations.WINGS_HOVER_ON, 2, true, false);
                                 }
                              }
                           } catch (Exception var3) {
                           }
                        }
                     }
                  };
               }

               if (firstPerson) {
                  animationPlayer.setFirstPersonConfiguration(new FirstPersonConfiguration().setShowRightArm(true).setShowLeftArm(true));
                  animationPlayer.setFirstPersonMode(FirstPersonMode.THIRD_PERSON_MODEL);
               }

               IAnimation wrappedPlayer = (IAnimation)(firstPerson ? new IAnimation() {
                  public boolean isActive() {
                     return animationPlayer.isActive();
                  }

                  public void tick() {
                     animationPlayer.tick();
                  }

                  public void setupAnim(float tickDelta) {
                     animationPlayer.setupAnim(tickDelta);
                  }

                  @NotNull
                  public Vec3f get3DTransform(@NotNull String modelName, @NotNull TransformType type, float tickDelta, @NotNull Vec3f value0) {
                     return animationPlayer.get3DTransform(modelName, type, tickDelta, value0);
                  }

                  @NotNull
                  public FirstPersonMode getFirstPersonMode(float tickDelta) {
                     return Minecraft.getInstance().screen != null ? FirstPersonMode.DISABLED : FirstPersonMode.THIRD_PERSON_MODEL;
                  }

                  @NotNull
                  public FirstPersonConfiguration getFirstPersonConfiguration(float tickDelta) {
                     return animationPlayer.getFirstPersonConfiguration(tickDelta);
                  }
               } : animationPlayer);
               playerAnimationData.replaceAnimationWithFade(AbstractFadeModifier.standardFadeIn(fadeInTicks, Ease.INOUTSINE), wrappedPlayer, !loop);
               playerAnimations.put(player.getId(), resourceLocation.getPath());
            }
         }
      }
   }

   public static void stopAnimation(Player player, int fadeOutTicks) {
      if (player instanceof AbstractClientPlayer clientPlayer) {
         ModifierLayer<IAnimation> playerAnimationData = (ModifierLayer<IAnimation>)PlayerAnimationAccess.getPlayerAssociatedData(clientPlayer)
            .get(ModAnimations.ANIMATION_RESOURCE);
         if (playerAnimationData != null) {
            playerAnimationData.replaceAnimationWithFade(AbstractFadeModifier.standardFadeIn(fadeOutTicks, Ease.INOUTSINE), null, true);
            playerAnimations.remove(player.getId());
         }
      }
   }

   public static void playAnimationFirstFrame(Player player, ResourceLocation resourceLocation, boolean firstPerson) {
      if (player instanceof AbstractClientPlayer clientPlayer) {
         if (PlayerAnimationRegistry.getAnimation(resourceLocation) instanceof KeyframeAnimation keyframeAnimation) {
            ModifierLayer<IAnimation> playerAnimationData = (ModifierLayer<IAnimation>)PlayerAnimationAccess.getPlayerAssociatedData(clientPlayer)
               .get(ModAnimations.ANIMATION_RESOURCE);
            if (playerAnimationData != null) {
               KeyframeAnimationPlayer animationPlayer = new KeyframeAnimationPlayer(keyframeAnimation) {
                  public void tick() {
                  }

                  public boolean isActive() {
                     return true;
                  }

                  public void setupAnim(float partialTicks) {
                     super.setupAnim(0.0F);
                  }
               };
               if (firstPerson) {
                  animationPlayer.setFirstPersonConfiguration(new FirstPersonConfiguration().setShowRightArm(true).setShowLeftArm(true));
                  animationPlayer.setFirstPersonMode(FirstPersonMode.THIRD_PERSON_MODEL);
               }

               playerAnimationData.setAnimation(animationPlayer);
               playerAnimations.put(player.getId(), resourceLocation.getPath());
            }
         }
      }
   }

   public static boolean isMeditating(Player player) {
      String anim = playerAnimations.get(player.getId());
      return anim != null && anim.contains("meditation");
   }

   public static String getCurrentAnimation(Player player) {
      return playerAnimations.get(player.getId());
   }

   public static boolean isPlayingAnimation(Player player) {
      if (player instanceof AbstractClientPlayer clientPlayer) {
         try {
            ModifierLayer<IAnimation> playerAnimationData = (ModifierLayer<IAnimation>)PlayerAnimationAccess.getPlayerAssociatedData(clientPlayer)
               .get(ModAnimations.ANIMATION_RESOURCE);
            return playerAnimationData != null && playerAnimationData.isActive();
         } catch (Exception var3) {
            return false;
         }
      } else {
         return false;
      }
   }
}
