package com.invfix.vpower.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.invfix.vpower.entity.projectile.WaterSprayEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.inventory.InventoryMenu;
import org.joml.Matrix4f;

public class WaterSprayRenderer extends EntityRenderer<WaterSprayEntity> {
   private static final ResourceLocation WATER_STILL = ResourceLocation.withDefaultNamespace("block/water_still");
   private static final float SEGMENT_LENGTH = 0.75F;
   private static final float STREAM_HALF_WIDTH = 0.06F;

   public WaterSprayRenderer(Context context) {
      super(context);
   }

   public void render(WaterSprayEntity entity, float yaw, float partialTicks, PoseStack poseStack, MultiBufferSource bufferSource, int light) {
      float range = entity.getEffectiveRange();
      if (!(range <= 0.05F)) {
         poseStack.pushPose();
         rotateToOwnerLook(entity, partialTicks, poseStack);
         VertexConsumer consumer = bufferSource.getBuffer(RenderType.translucentMovingBlock());
         TextureAtlasSprite sprite = (TextureAtlasSprite)Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(WATER_STILL);
         int color = BiomeColors.getAverageWaterColor(entity.level(), entity.blockPosition());
         float r = (float)(color >> 16 & 0xFF) / 255.0F;
         float g = (float)(color >> 8 & 0xFF) / 255.0F;
         float b = (float)(color & 0xFF) / 255.0F;
         float alpha = 0.86F;
         int packedLight = Math.max(light, 15728880);
         float rendered = 0.0F;
         int segment = 0;

         for (float spin = ((float)entity.tickCount + partialTicks) * 12.0F; rendered < range; segment++) {
            float length = Math.min(0.75F, range - rendered);
            float taper = Mth.clamp(1.0F - rendered / Math.max(1.0F, range) * 0.35F, 0.65F, 1.0F);
            poseStack.pushPose();
            poseStack.translate(0.0F, 0.0F, rendered);
            poseStack.mulPose(Axis.ZP.rotationDegrees(spin + (float)segment * 38.0F));
            drawWaterCuboid(consumer, poseStack.last().pose(), sprite, 0.06F * taper, length, r, g, b, alpha, packedLight);
            poseStack.popPose();
            rendered += length;
         }

         poseStack.popPose();
         super.render(entity, yaw, partialTicks, poseStack, bufferSource, light);
      }
   }

   private static void rotateToOwnerLook(WaterSprayEntity entity, float partialTicks, PoseStack poseStack) {
      Entity owner = entity.getOwner();
      float renderYaw = owner == null ? Mth.rotLerp(partialTicks, entity.yRotO, entity.getYRot()) : Mth.rotLerp(partialTicks, owner.yRotO, owner.getYRot());
      float renderPitch = owner == null ? Mth.lerp(partialTicks, entity.xRotO, entity.getXRot()) : Mth.lerp(partialTicks, owner.xRotO, owner.getXRot());
      poseStack.mulPose(Axis.YP.rotationDegrees(-renderYaw));
      poseStack.mulPose(Axis.XP.rotationDegrees(renderPitch));
   }

   private static void drawWaterCuboid(
      VertexConsumer consumer, Matrix4f pose, TextureAtlasSprite sprite, float halfWidth, float length, float r, float g, float b, float alpha, int light
   ) {
      float x0 = -halfWidth;
      float y0 = -halfWidth;
      float z0 = 0.0F;
      float u0 = sprite.getU0();
      float u1 = sprite.getU1();
      float v0 = sprite.getV0();
      float v1 = sprite.getV1();
      drawQuad(consumer, pose, x0, y0, z0, halfWidth, y0, z0, halfWidth, y0, length, x0, y0, length, u0, v0, u1, v1, r, g, b, alpha, light, 0.0F, -1.0F, 0.0F);
      drawQuad(
         consumer,
         pose,
         x0,
         halfWidth,
         length,
         halfWidth,
         halfWidth,
         length,
         halfWidth,
         halfWidth,
         z0,
         x0,
         halfWidth,
         z0,
         u0,
         v0,
         u1,
         v1,
         r,
         g,
         b,
         alpha,
         light,
         0.0F,
         1.0F,
         0.0F
      );
      drawQuad(consumer, pose, x0, halfWidth, z0, x0, y0, z0, x0, y0, length, x0, halfWidth, length, u0, v0, u1, v1, r, g, b, alpha, light, -1.0F, 0.0F, 0.0F);
      drawQuad(
         consumer,
         pose,
         halfWidth,
         y0,
         z0,
         halfWidth,
         halfWidth,
         z0,
         halfWidth,
         halfWidth,
         length,
         halfWidth,
         y0,
         length,
         u0,
         v0,
         u1,
         v1,
         r,
         g,
         b,
         alpha,
         light,
         1.0F,
         0.0F,
         0.0F
      );
      drawQuad(
         consumer, pose, x0, halfWidth, z0, halfWidth, halfWidth, z0, halfWidth, y0, z0, x0, y0, z0, u0, v0, u1, v1, r, g, b, alpha, light, 0.0F, 0.0F, -1.0F
      );
      drawQuad(
         consumer,
         pose,
         x0,
         y0,
         length,
         halfWidth,
         y0,
         length,
         halfWidth,
         halfWidth,
         length,
         x0,
         halfWidth,
         length,
         u0,
         v0,
         u1,
         v1,
         r,
         g,
         b,
         alpha,
         light,
         0.0F,
         0.0F,
         1.0F
      );
   }

   private static void drawQuad(
      VertexConsumer consumer,
      Matrix4f pose,
      float x1,
      float y1,
      float z1,
      float x2,
      float y2,
      float z2,
      float x3,
      float y3,
      float z3,
      float x4,
      float y4,
      float z4,
      float u0,
      float v0,
      float u1,
      float v1,
      float r,
      float g,
      float b,
      float alpha,
      int light,
      float nx,
      float ny,
      float nz
   ) {
      consumer.addVertex(pose, x1, y1, z1).setColor(r, g, b, alpha).setUv(u0, v0).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(nx, ny, nz);
      consumer.addVertex(pose, x2, y2, z2).setColor(r, g, b, alpha).setUv(u1, v0).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(nx, ny, nz);
      consumer.addVertex(pose, x3, y3, z3).setColor(r, g, b, alpha).setUv(u1, v1).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(nx, ny, nz);
      consumer.addVertex(pose, x4, y4, z4).setColor(r, g, b, alpha).setUv(u0, v1).setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(nx, ny, nz);
   }

   public ResourceLocation getTextureLocation(WaterSprayEntity entity) {
      return InventoryMenu.BLOCK_ATLAS;
   }
}
