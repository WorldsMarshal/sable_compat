package com.invfix.vpower.entity.effect;

import com.invfix.vpower.entity.ModEntities;
import com.invfix.vpower.mixin.accessor.FallingBlockEntityAccessor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class VisualFallingBlockEntity extends FallingBlockEntity {
   private int maxAge = 200;
   private double originalY;
   private boolean particlesOnImpact;

   public VisualFallingBlockEntity(EntityType<? extends VisualFallingBlockEntity> entityType, Level level) {
      super(entityType, level);
   }

   public VisualFallingBlockEntity(Level level, double x, double y, double z, BlockState state) {
      this(level, x, y, z, state, 200);
   }

   public VisualFallingBlockEntity(Level level, double x, double y, double z, BlockState state, int maxAge) {
      this(level, x, y, z, state, maxAge, false);
   }

   public VisualFallingBlockEntity(Level level, double x, double y, double z, BlockState state, int maxAge, boolean particlesOnImpact) {
      this((EntityType<? extends VisualFallingBlockEntity>)ModEntities.VISUAL_FALLING_BLOCK.get(), level);
      this.originalY = y;
      this.maxAge = maxAge;
      this.particlesOnImpact = particlesOnImpact;
      this.blocksBuilding = false;
      ((FallingBlockEntityAccessor)this).theboysmod$setBlockState(state);
      this.setPos(x + 0.5, y, z + 0.5);
      this.xo = x;
      this.yo = y;
      this.zo = z;
      this.setStartPos(BlockPos.containing(x, y, z));
      this.dropItem = false;
      this.disableDrop();
   }

   public void setOnGround(boolean onGround) {
   }

   public boolean onGround() {
      return this.tickCount > 1 && this.getDeltaMovement().lengthSqr() < 0.001F;
   }

   public void tick() {
      boolean landed = this.onGround();
      if (!this.getBlockState().isAir() && !landed && this.tickCount <= this.maxAge) {
         this.move(MoverType.SELF, this.getDeltaMovement());
         if (!this.isNoGravity() && !landed) {
            this.setDeltaMovement(this.getDeltaMovement().add(0.0, -0.08, 0.0));
         }
      } else {
         if (landed) {
            this.callOnBrokenAfterFall(this.level().getBlockState(this.blockPosition().below()).getBlock(), this.blockPosition());
         }

         this.discard();
      }
   }

   protected void readAdditionalSaveData(CompoundTag tag) {
      super.readAdditionalSaveData(tag);
      this.dropItem = false;
      this.disableDrop();
      if (tag.contains("VisualMaxAge")) {
         this.maxAge = tag.getInt("VisualMaxAge");
      }

      if (tag.contains("VisualOriginalY")) {
         this.originalY = tag.getDouble("VisualOriginalY");
      }

      if (tag.contains("VisualParticlesOnImpact")) {
         this.particlesOnImpact = tag.getBoolean("VisualParticlesOnImpact");
      }
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
      super.addAdditionalSaveData(tag);
      tag.putInt("VisualMaxAge", this.maxAge);
      tag.putDouble("VisualOriginalY", this.originalY);
      tag.putBoolean("VisualParticlesOnImpact", this.particlesOnImpact);
   }

   public boolean isPickable() {
      return false;
   }

   public void callOnBrokenAfterFall(Block block, BlockPos pos) {
      if (!this.level().isClientSide && this.particlesOnImpact && !this.getBlockState().isAir() && this.level() instanceof ServerLevel serverLevel) {
         serverLevel.sendParticles(
            new BlockParticleOption(ParticleTypes.BLOCK, this.getBlockState()), this.getX(), this.getY(), this.getZ(), 25, 0.25, 0.25, 0.25, 0.04
         );
      }
   }

   public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource source) {
      return false;
   }
}
