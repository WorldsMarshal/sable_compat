package com.invfix.vpower.entity;

import com.invfix.vpower.entity.effect.VisualFallingBlockEntity;
import com.invfix.vpower.entity.projectile.FireBlastProjectile;
import com.invfix.vpower.entity.projectile.WaterSprayEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityType.Builder;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Сущности способностей V (id — theboysmod, как в The Boys): снаряд Fire Blast, струя Spray Water, обломки Stomp. */
public class ModEntities {
   public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(Registries.ENTITY_TYPE, "theboysmod");
   public static final DeferredHolder<EntityType<?>, EntityType<FireBlastProjectile>> FIRE_BLAST_PROJECTILE = ENTITY_TYPES.register(
      "fire_blast_projectile",
      () -> Builder.<FireBlastProjectile>of(FireBlastProjectile::new, MobCategory.MISC).sized(0.1F, 0.1F).clientTrackingRange(64).updateInterval(1).build("fire_blast_projectile")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<WaterSprayEntity>> WATER_SPRAY = ENTITY_TYPES.register(
      "water_spray", () -> Builder.<WaterSprayEntity>of(WaterSprayEntity::new, MobCategory.MISC).sized(0.1F, 0.1F).clientTrackingRange(64).updateInterval(1).build("water_spray")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<VisualFallingBlockEntity>> VISUAL_FALLING_BLOCK = ENTITY_TYPES.register(
      "visual_falling_block",
      () -> Builder.<VisualFallingBlockEntity>of(VisualFallingBlockEntity::new, MobCategory.MISC)
            .sized(0.98F, 0.98F)
            .clientTrackingRange(32)
            .updateInterval(1)
            .build("visual_falling_block")
   );
}
