package com.invfix.vpower.entity.projectile;

import com.invfix.vpower.entity.ModEntities;
import com.invfix.vpower.util.VBlocks;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.SprayWaterSkill;
import com.invfix.vpower.util.IntangibilityUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public class WaterSprayEntity extends Projectile {
   private static final EntityDataAccessor<Float> EFFECTIVE_RANGE = SynchedEntityData.defineId(WaterSprayEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Integer> STREAM_SIDE = SynchedEntityData.defineId(WaterSprayEntity.class, EntityDataSerializers.INT);
   private static final int FAILSAFE_EXPIRE_TIME = 400;
   private static final float RANGE = 14.0F;
   private static final float DAMAGE_PER_HIT = 1.2F;
   private static final int DAMAGE_INTERVAL = 3;
   private static final double STREAM_RADIUS = 0.25;
   private static final double CHEST_SIDE_OFFSET = 0.14;
   private static final double CHEST_FORWARD_OFFSET = 0.42;
   private static final double CHEST_HEIGHT_RATIO = 0.68;
   private static final double EXTINGUISH_STEP = 0.55;
   private static final int[][] EXTINGUISH_OFFSETS = new int[][]{{0, 0, 0}, {1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};

   public WaterSprayEntity(EntityType<? extends WaterSprayEntity> entityType, Level level) {
      super(entityType, level);
      this.noPhysics = true;
      this.blocksBuilding = false;
      this.setNoGravity(true);
   }

   public WaterSprayEntity(Level level, LivingEntity owner) {
      this((EntityType<? extends WaterSprayEntity>)ModEntities.WATER_SPRAY.get(), level);
      this.setOwner(owner);
   }

   public WaterSprayEntity(Level level, LivingEntity owner, int side) {
      this(level, owner);
      this.setStreamSide(side);
   }

   protected void defineSynchedData(Builder builder) {
      builder.define(EFFECTIVE_RANGE, 14.0F);
      builder.define(STREAM_SIDE, 1);
   }

   public float getEffectiveRange() {
      return (Float)this.entityData.get(EFFECTIVE_RANGE);
   }

   public void setEffectiveRange(float range) {
      this.entityData.set(EFFECTIVE_RANGE, Math.max(0.3F, Math.min(14.0F, range)));
   }

   public int getStreamSide() {
      return this.entityData.get(STREAM_SIDE) < 0 ? -1 : 1;
   }

   public void setStreamSide(int side) {
      this.entityData.set(STREAM_SIDE, side < 0 ? -1 : 1);
   }

   public boolean shouldBeSaved() {
      return false;
   }

   public boolean shouldRenderAtSqrDistance(double distance) {
      return distance < 4096.0;
   }

   public void tick() {
      super.tick();
      if (this.tickCount > 400) {
         this.discard();
      } else {
         Entity owner = this.getOwner();
         if (owner instanceof LivingEntity livingOwner && livingOwner.isAlive()) {
            this.syncFromOwner(livingOwner);
            if (!this.level().isClientSide) {
               if (!this.isOwnerStillSpraying(owner)) {
                  this.discard();
                  return;
               }

               this.updateServerEffects(livingOwner);
            }

            return;
         }

         if (!this.level().isClientSide) {
            this.discard();
         }
      }
   }

   public void syncFromOwner() {
      if (this.getOwner() instanceof LivingEntity livingOwner) {
         this.syncFromOwner(livingOwner);
      }
   }

   private void syncFromOwner(LivingEntity owner) {
      Vec3 look = owner.getLookAngle().normalize();
      Vec3 origin = getStreamOrigin(owner, look, this.getStreamSide());
      this.setPos(origin.x, origin.y, origin.z);
      this.setYRot(owner.getYRot());
      this.setXRot(owner.getXRot());
      this.yRotO = this.getYRot();
      this.xRotO = this.getXRot();
   }

   private static Vec3 getStreamOrigin(LivingEntity owner, Vec3 look, int side) {
      Vec3 horizontalLook = new Vec3(look.x, 0.0, look.z);
      if (horizontalLook.lengthSqr() < 1.0E-4) {
         double yawRad = Math.toRadians((double)owner.getYRot());
         horizontalLook = new Vec3(-Math.sin(yawRad), 0.0, Math.cos(yawRad));
      } else {
         horizontalLook = horizontalLook.normalize();
      }

      Vec3 right = new Vec3(-horizontalLook.z, 0.0, horizontalLook.x).normalize();
      double chestY = owner.getY() + (double)owner.getBbHeight() * 0.68;
      return new Vec3(owner.getX(), chestY, owner.getZ()).add(horizontalLook.scale(0.42)).add(right.scale(0.14 * (double)side));
   }

   private boolean isOwnerStillSpraying(Entity owner) {
      if (!(owner instanceof Player player)) {
         return false;
      } else {
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         return data.hasSkill(SprayWaterSkill.ID.toString()) && data.isSkillActive(SprayWaterSkill.ID.toString());
      }
   }

   private void updateServerEffects(LivingEntity owner) {
      if (this.level() instanceof ServerLevel level) {
         Vec3 var7 = owner.getLookAngle().normalize();
         Vec3 origin = getStreamOrigin(owner, var7, this.getStreamSide());
         float range = this.computeEffectiveRange(owner, origin, var7);
         this.setEffectiveRange(range);
         Vec3 end = origin.add(var7.scale((double)range));
         if (this.tickCount % 2 == 0 && this.extinguishAlongStream(level, origin, end)) {
            level.playSound(
               null, this.getX(), this.getY(), this.getZ(), SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 0.35F, 1.25F + this.random.nextFloat() * 0.25F
            );
         }

         if (this.tickCount % 4 == 0) {
            level.sendParticles(ParticleTypes.SPLASH, end.x, end.y, end.z, 4, 0.18, 0.18, 0.18, 0.02);
         }

         if (this.tickCount % 12 == 0) {
            level.playSound(
               null, this.getX(), this.getY(), this.getZ(), SoundEvents.PLAYER_SPLASH, SoundSource.PLAYERS, 0.35F, 0.75F + this.random.nextFloat() * 0.25F
            );
         }

         if (this.tickCount % 3 == 0) {
            this.damageEntities(owner, origin, end, var7);
         }
      }
   }

   private float computeEffectiveRange(LivingEntity owner, Vec3 origin, Vec3 look) {
      Vec3 end = origin.add(look.scale(14.0));
      HitResult hit = this.level().clip(new ClipContext(origin, end, Block.COLLIDER, Fluid.NONE, owner));
      return hit.getType() == Type.MISS ? 14.0F : (float)Math.max(0.3, origin.distanceTo(hit.getLocation()));
   }

   private void damageEntities(LivingEntity owner, Vec3 origin, Vec3 end, Vec3 look) {
      if (owner instanceof ServerPlayer player) {
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         float damage = 1.2F * ((float)data.getDamageMultiplier(SprayWaterSkill.ID.toString()) / 100.0F);
         AABB searchBox = new AABB(
               Math.min(origin.x, end.x),
               Math.min(origin.y, end.y),
               Math.min(origin.z, end.z),
               Math.max(origin.x, end.x),
               Math.max(origin.y, end.y),
               Math.max(origin.z, end.z)
            )
            .inflate(0.25);

         for (Entity entity : this.level()
            .getEntities(
               this,
               searchBox,
               entityx -> {
                  if (entityx instanceof LivingEntity living
                     && living != owner
                     && living.isAlive()
                     && !IntangibilityUtil.isIntangible(living)
                     && !living.isSpectator()) {
                     return true;
                  }

                  return false;
               }
            )) {
            if (entity instanceof LivingEntity) {
               LivingEntity target = (LivingEntity)entity;
               if (!IntangibilityUtil.isIntangible(target) && !target.getBoundingBox().inflate(0.125).clip(origin, end).isEmpty()) {
                  target.invulnerableTime = 0;
                  target.hurtTime = 0;
                  if (target.isOnFire() || target.getRemainingFireTicks() > 0) {
                     target.clearFire();
                     target.setRemainingFireTicks(0);
                     this.level()
                        .playSound(
                           null,
                           target.getX(),
                           target.getY(),
                           target.getZ(),
                           SoundEvents.GENERIC_EXTINGUISH_FIRE,
                           SoundSource.PLAYERS,
                           0.45F,
                           1.1F + this.random.nextFloat() * 0.2F
                        );
                  }

                  target.hurt(player.damageSources().playerAttack(player), damage);
                  Vec3 push = look.scale(0.45);
                  target.push(push.x, 0.12 + Math.max(0.0, push.y * 0.35), push.z);
                  target.hurtMarked = true;
               }
            }
         }
      }
   }

   private boolean extinguishAlongStream(ServerLevel level, Vec3 origin, Vec3 end) {
      Vec3 stream = end.subtract(origin);
      double distance = stream.length();
      if (distance < 0.05) {
         return false;
      } else {
         boolean extinguished = false;
         Vec3 direction = stream.scale(1.0 / distance);
         int steps = Math.max(1, (int)Math.ceil(distance / 0.55));

         for (int step = 0; step <= steps; step++) {
            double sampleDistance = Math.min(distance, (double)step * 0.55);
            BlockPos center = BlockPos.containing(origin.add(direction.scale(sampleDistance)));

            for (int[] offset : EXTINGUISH_OFFSETS) {
               extinguished |= extinguishBlock(level, center.offset(offset[0], offset[1], offset[2]));
            }
         }

         return extinguished;
      }
   }

   private static boolean extinguishBlock(ServerLevel level, BlockPos pos) {
      if (VBlocks.protectedLevel(level)) {
         return false;
      } else {
         BlockState state = level.getBlockState(pos);
         if (!state.is(Blocks.FIRE) && !state.is(Blocks.SOUL_FIRE)) {
            if ((state.is(Blocks.CAMPFIRE) || state.is(Blocks.SOUL_CAMPFIRE))
               && state.hasProperty(BlockStateProperties.LIT)
               && (Boolean)state.getValue(BlockStateProperties.LIT)) {
               level.setBlock(pos, (BlockState)state.setValue(BlockStateProperties.LIT, false), 11);
               return true;
            } else {
               return false;
            }
         } else {
            level.removeBlock(pos, false);
            return true;
         }
      }
   }

   protected void addAdditionalSaveData(CompoundTag compound) {
      super.addAdditionalSaveData(compound);
   }

   protected void readAdditionalSaveData(CompoundTag compound) {
      super.readAdditionalSaveData(compound);
   }
}
