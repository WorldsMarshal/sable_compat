package com.invfix.vpower.entity.projectile;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import com.invfix.vpower.entity.ModEntities;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.FireBlastSkill;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class FireBlastProjectile extends Projectile {
   private static final int FAILSAFE_EXPIRE_TIME = 400;
   private static final EntityDataAccessor<Float> EFFECTIVE_RANGE = SynchedEntityData.defineId(FireBlastProjectile.class, EntityDataSerializers.FLOAT);
   private int age;
   private List<Vec3> beamVectors;

   public FireBlastProjectile(EntityType<? extends FireBlastProjectile> entityType, Level level) {
      super(entityType, level);
      this.noPhysics = true;
      this.blocksBuilding = false;
   }

   public FireBlastProjectile(Level level, LivingEntity owner) {
      this((EntityType<? extends FireBlastProjectile>)ModEntities.FIRE_BLAST_PROJECTILE.get(), level);
      this.setOwner(owner);
   }

   protected void defineSynchedData(Builder pBuilder) {
      pBuilder.define(EFFECTIVE_RANGE, 10.0F);
   }

   public float getEffectiveRange() {
      return (Float)this.entityData.get(EFFECTIVE_RANGE);
   }

   public void setEffectiveRange(float range) {
      this.entityData.set(EFFECTIVE_RANGE, range);
   }

   public boolean isOnFire() {
      return false;
   }

   public boolean shouldBeSaved() {
      return false;
   }

   public boolean shouldRenderAtSqrDistance(double pDistance) {
      return pDistance < 4096.0;
   }

   public void generateFireBeams() {
      Random random = new Random();
      this.beamVectors = new ArrayList<>();
      Vec3 coreStart = new Vec3(0.0, 0.0, 0.0);
      int coreLength = random.nextInt(3) + 8;

      for (int core = 0; core < coreLength; core++) {
         Vec3 coreEnd = coreStart.add(0.0, 0.0, 1.2).add(randomVector(0.15F).multiply(1.5, 0.8, 1.5));
         this.beamVectors.add(coreStart);
         this.beamVectors.add(coreEnd);
         coreStart = coreEnd;
         if (random.nextFloat() < 0.3F) {
            int branchLen = random.nextInt(2) + 1;
            Vec3 branchStart = coreEnd;
            int dir = random.nextBoolean() ? 1 : -1;

            for (int b = 0; b < branchLen; b++) {
               Vec3 branchEnd = branchStart.add((double)dir * 0.4, 0.0, 0.5).add(randomVector(0.2F));
               this.beamVectors.add(branchStart);
               this.beamVectors.add(branchEnd);
               branchStart = branchEnd;
            }
         }
      }
   }

   public int getAge() {
      return this.age;
   }

   public static Vec3 randomVector(float radius) {
      double x = Math.random() * 2.0 * (double)radius - (double)radius;
      double y = Math.random() * 2.0 * (double)radius - (double)radius;
      double z = Math.random() * 2.0 * (double)radius - (double)radius;
      return new Vec3(x, y, z);
   }

   public List<Vec3> getBeamCache() {
      if (this.beamVectors == null) {
         this.generateFireBeams();
      }

      return this.beamVectors;
   }

   public void tick() {
      super.tick();
      if (++this.age > 400) {
         this.discard();
      } else {
         Entity owner = this.getOwner();
         if (owner != null && owner.isAlive()) {
            if (!this.level().isClientSide && owner instanceof Player player) {
               SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
               if (!skillData.isSkillActive(FireBlastSkill.ID.toString())) {
                  this.discard();
                  return;
               }
            }

            Vec3 ownerEyePos = owner.getEyePosition(1.0F).subtract(0.0, 0.8, 0.0);
            this.setPos(ownerEyePos);
            this.setXRot(owner.getXRot());
            this.setYRot(owner.getYRot());
            this.yRotO = this.getYRot();
            this.xRotO = this.getXRot();
         } else {
            this.discard();
         }
      }
   }

   protected void addAdditionalSaveData(CompoundTag pCompound) {
      super.addAdditionalSaveData(pCompound);
   }

   protected void readAdditionalSaveData(CompoundTag pCompound) {
      super.readAdditionalSaveData(pCompound);
   }
}
