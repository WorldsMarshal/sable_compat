package com.invfix.vpower.network;

import com.invfix.vpower.server.ScaleHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record ScaleSetPacket(float scale) implements CustomPacketPayload {
   public static final Type<ScaleSetPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "scale_set"));
   public static final StreamCodec<FriendlyByteBuf, ScaleSetPacket> STREAM_CODEC = StreamCodec.composite(
      ByteBufCodecs.FLOAT, ScaleSetPacket::scale, ScaleSetPacket::new
   );

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(ScaleSetPacket packet, IPayloadContext context) {
      context.enqueueWork(() -> {
         if (context.player() instanceof ServerPlayer player) {
            ScaleHandler.setTargetScale(player, packet.scale());
         }
      });
   }
}
