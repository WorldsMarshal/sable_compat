package com.invfix.vpower.network;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record SkillSyncPacket(CompoundTag data) implements CustomPacketPayload {
   public static final Type<SkillSyncPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "skill_sync"));
   public static final StreamCodec<FriendlyByteBuf, SkillSyncPacket> STREAM_CODEC = StreamCodec.of(SkillSyncPacket::encode, SkillSyncPacket::decode);

   public SkillSyncPacket(CompoundTag data) {
      data = data == null ? new CompoundTag() : data.copy();
      this.data = data;
   }

   private static void encode(FriendlyByteBuf buf, SkillSyncPacket packet) {
      buf.writeNbt(packet.data);
   }

   private static SkillSyncPacket decode(FriendlyByteBuf buf) {
      return new SkillSyncPacket(buf.readNbt());
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(SkillSyncPacket packet, IPayloadContext context) {
      context.enqueueWork(() -> VClientPackets.skillSync(packet));
   }

   public static void syncToClient(ServerPlayer player) {
      SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
      data.ensureChildSkills();
      SkillSyncPacket packet = new SkillSyncPacket(data.serializeNBT(player.registryAccess()));
      PacketDistributor.sendToPlayer(player, packet, new CustomPacketPayload[0]);
      SkillActiveSyncPacket.syncToWrappers(player);
   }
}
