package com.invfix.vpower.network;

import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.client.animation.ModAnimations;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.FlightSkill;
import com.invfix.vpower.skill.skills.WingsSkill;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record FlightPosePacket(FlightPosePacket.Action action) implements CustomPacketPayload {
   private static final String WINGS_SKILL_ID = WingsSkill.ID.toString();
   private static final String FLIGHT_SKILL_ID = FlightSkill.ID.toString();
   public static final Type<FlightPosePacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "flight_pose"));
   public static final StreamCodec<FriendlyByteBuf, FlightPosePacket> STREAM_CODEC = StreamCodec.of(FlightPosePacket::encode, FlightPosePacket::decode);

   private static void encode(FriendlyByteBuf buf, FlightPosePacket packet) {
      buf.writeEnum(packet.action);
   }

   private static FlightPosePacket decode(FriendlyByteBuf buf) {
      return new FlightPosePacket((FlightPosePacket.Action)buf.readEnum(FlightPosePacket.Action.class));
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(FlightPosePacket packet, IPayloadContext context) {
      context.enqueueWork(
         () -> {
            if (context.player() instanceof ServerPlayer player) {
               switch (packet.action) {
                  case START: {
                     boolean wingOnly = isWingOnlyFlight(player);
                     FlightPoseSyncPacket syncPacket = new FlightPoseSyncPacket(
                        player.getId(), wingOnly ? FlightPosePacket.Action.WINGS_START : FlightPosePacket.Action.START
                     );
                     PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, syncPacket, new CustomPacketPayload[0]);
                     PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                        player, new PlayerAnimationPlaySyncPacket(player.getId(), ModAnimations.FLIGHT_ON, true, 2, false), new CustomPacketPayload[0]
                     );
                     break;
                  }
                  case STOP: {
                     boolean wingOnly = isWingOnlyFlight(player);
                     FlightPoseSyncPacket syncPacket = new FlightPoseSyncPacket(
                        player.getId(), wingOnly ? FlightPosePacket.Action.WINGS_STOP : FlightPosePacket.Action.STOP
                     );
                     PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, syncPacket, new CustomPacketPayload[0]);
                     PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                        player, new PlayerAnimationStopSyncPacket(player.getId(), 3), new CustomPacketPayload[0]
                     );
                     break;
                  }
                  case START_HOVER:
                     if (isWingOnlyFlight(player)) {
                        PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                           player, new FlightPoseSyncPacket(player.getId(), FlightPosePacket.Action.WINGS_START_HOVER), new CustomPacketPayload[0]
                        );
                        PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                           player,
                           new PlayerAnimationPlaySyncPacket(player.getId(), ModAnimations.WINGS_HOVER_START, false, 2, false),
                           new CustomPacketPayload[0]
                        );
                     } else {
                        PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                           player, new PlayerAnimationPlaySyncPacket(player.getId(), ModAnimations.HOVER_ON, true, 3, false), new CustomPacketPayload[0]
                        );
                     }
                     break;
                  case STOP_HOVER:
                     if (isWingOnlyFlight(player)) {
                        PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                           player, new FlightPoseSyncPacket(player.getId(), FlightPosePacket.Action.WINGS_STOP_HOVER), new CustomPacketPayload[0]
                        );
                        PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                           player,
                           new PlayerAnimationPlaySyncPacket(player.getId(), ModAnimations.WINGS_HOVER_STOP, false, 2, false),
                           new CustomPacketPayload[0]
                        );
                     } else {
                        PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                           player, new PlayerAnimationStopSyncPacket(player.getId(), 3), new CustomPacketPayload[0]
                        );
                     }
                  case WINGS_START:
                  case WINGS_STOP:
                  case WINGS_START_HOVER:
                  case WINGS_STOP_HOVER:
               }
            }
         }
      );
   }

   private static boolean isWingOnlyFlight(ServerPlayer player) {
      try {
         SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         FleshRegenData fleshData = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
         boolean hasLegacyFlight = skillData.hasSkill(FLIGHT_SKILL_ID) || skillData.getFireTimer() > 0;
         boolean hasBody = fleshData.getScore("Body") != 0;
         return skillData.hasSkill(WINGS_SKILL_ID) && !hasLegacyFlight && hasBody;
      } catch (Exception var5) {
         return false;
      }
   }

   public static enum Action {
      START,
      STOP,
      START_HOVER,
      STOP_HOVER,
      WINGS_START,
      WINGS_STOP,
      WINGS_START_HOVER,
      WINGS_STOP_HOVER;
   }
}
