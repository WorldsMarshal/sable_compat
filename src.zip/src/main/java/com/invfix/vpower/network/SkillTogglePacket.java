package com.invfix.vpower.network;

import com.invfix.vpower.VPower;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.SkillRegistry;
import com.invfix.vpower.skill.base.Skill;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record SkillTogglePacket(int slotIndex, String skillId) implements CustomPacketPayload {
   public static final Type<SkillTogglePacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "skill_toggle"));
   public static final StreamCodec<FriendlyByteBuf, SkillTogglePacket> STREAM_CODEC = StreamCodec.of(SkillTogglePacket::encode, SkillTogglePacket::decode);

   private static void encode(FriendlyByteBuf buf, SkillTogglePacket packet) {
      buf.writeInt(packet.slotIndex);
      buf.writeUtf(packet.skillId);
   }

   private static SkillTogglePacket decode(FriendlyByteBuf buf) {
      return new SkillTogglePacket(buf.readInt(), buf.readUtf());
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   /** Переключить навык (вкл/выкл): клавиша способности или меню PWR. */
   public static void handle(SkillTogglePacket packet, IPayloadContext context) {
      context.enqueueWork(() -> {
         if (context.player() instanceof ServerPlayer player) {
            toggle(player, packet.skillId);
         }
      });
   }

   public static void toggle(ServerPlayer player, String skillId) {
      SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
      if (!skillData.hasSkill(skillId)) {
         VPower.LOGGER.debug("[SkillToggle] {} tried to toggle {} without having it", player.getName().getString(), skillId);
         return;
      }
      Skill skill = SkillRegistry.getSkill(skillId);
      boolean newState = !skillData.isSkillActive(skillId);
      skillData.setSkillActive(skillId, newState);
      VPower.LOGGER.debug("[SkillToggle] Skill {} toggled to: {}", skillId, newState);
      if (skill != null) {
         if (newState) {
            skill.trigger(player);
         } else {
            skill.untrigger(player);
         }
      }
      SkillActiveSyncPacket.syncToWrappers(player);
   }
}
