package com.invfix.vpower.network;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.function.IntConsumer;
import com.invfix.vpower.VPower;
import com.invfix.vpower.VRaces;
import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.registry.ModSounds;
import com.invfix.vpower.server.FleshRegenTickHandler;
import com.invfix.vpower.server.FleshStrengthHandler;
import com.invfix.vpower.server.TempVDebugDurationData;
import com.invfix.vpower.server.TempVFirstUseData;
import com.invfix.vpower.server.TempVSideEffectHandler;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.ModSkills;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.base.Skill;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record InjectVPacket(String syringeType, String action) implements CustomPacketPayload {
   public static final Type<InjectVPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "inject_v"));
   private static final Map<String, Skill> FIRST_TEMP_SKILLS = Map.of(
      "benniao_eric",
      ModSkills.WINGS,
      "mzaib",
      ModSkills.SOUND_WAVE,
      "supertoad233",
      ModSkills.TOAD,
      "ysj_field",
      ModSkills.WATER_DISPENSER,
      "fashionegg",
      ModSkills.CHICKEN_EGG_HEAD,
      "xiao_dai520",
      ModSkills.NAILONG_BELIAL
   );
   private static final Map<Item, Skill> TEMP_CATALYST_SKILLS = Map.of(
      Items.FEATHER,
      ModSkills.WINGS,
      Items.GOAT_HORN,
      ModSkills.SOUND_WAVE,
      Items.SLIME_BALL,
      ModSkills.TOAD,
      Items.WATER_BUCKET,
      ModSkills.WATER_DISPENSER,
      Items.EGG,
      ModSkills.CHICKEN_EGG_HEAD,
      Items.MILK_BUCKET,
      ModSkills.NAILONG_BELIAL
   );
   private static final int MAX_INJECTED_SKILL_LEVEL = 5;
   private static final int PERMANENT_PRIMARY_START_LEVEL = 3;
   private static final int TEMP_FULL_SKILL_LEVEL = 5;
   private static final int TEMP_NORMAL_WEIGHT = 100;
   private static final int TEMP_EXCLUSIVE_NON_OWNER_WEIGHT = 1;
   private static final int SELF_INJECT_TICKS = 50;
   private static final int SELF_PRICK_TICK = 45;
   private static final Set<String> EXCLUSIVE_TEMP_SKILL_IDS = Set.of(
      ModSkills.WINGS.getId().toString(),
      ModSkills.SOUND_WAVE.getId().toString(),
      ModSkills.TOAD.getId().toString(),
      ModSkills.WATER_DISPENSER.getId().toString(),
      ModSkills.CHICKEN_EGG_HEAD.getId().toString(),
      ModSkills.NAILONG_BELIAL.getId().toString()
   );
   private static final Set<String> INJECTABLE_SYRINGES = Set.of("compound_v_syringe", "compound_v_temp_syringe", "compound_v_remove_syringe");
   private static final Map<UUID, InjectVPacket.SelfInjectionState> SELF_INJECTIONS = new HashMap<>();
   public static final StreamCodec<FriendlyByteBuf, InjectVPacket> STREAM_CODEC = StreamCodec.of(InjectVPacket::encode, InjectVPacket::decode);

   private static void encode(FriendlyByteBuf buf, InjectVPacket packet) {
      buf.writeUtf(packet.syringeType);
      buf.writeUtf(packet.action);
   }

   private static InjectVPacket decode(FriendlyByteBuf buf) {
      return new InjectVPacket(buf.readUtf(), buf.readUtf());
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(InjectVPacket packet, IPayloadContext context) {
      context.enqueueWork(
         () -> {
            if (context.player() instanceof ServerPlayer player) {
               String action = packet.action == null ? "" : packet.action;
               if ("self_release".equals(action)) {
                  resetSelfInjection(player);
               } else {
                  String heldSyringeType = syringeTypeFromStack(player.getMainHandItem());
                  if (heldSyringeType != null && heldSyringeType.equals(packet.syringeType)) {
                     switch (action) {
                        case "prick":
                           applyPrickEffect(player);
                           break;
                        case "inject":
                           resetSelfInjection(player);
                           handleInject(player, heldSyringeType);
                           break;
                        case "self_hold":
                           handleSelfInjectionHold(player, heldSyringeType);
                           break;
                        default:
                           VPower.LOGGER.warn("[InjectV] Unknown action: {}", action);
                     }
                  } else {
                     resetSelfInjection(player);
                     VPower.LOGGER
                        .warn(
                           "[InjectV] Player {} syringe mismatch. held={}, packet={}",
                           new Object[]{player.getName().getString(), heldSyringeType, packet.syringeType}
                        );
                  }
               }
            }
         }
      );
   }

   private static void handleSelfInjectionHold(ServerPlayer player, String syringeType) {
      UUID playerId = player.getUUID();
      InjectVPacket.SelfInjectionState state = SELF_INJECTIONS.get(playerId);
      if (state == null || !state.syringeType.equals(syringeType)) {
         state = new InjectVPacket.SelfInjectionState(syringeType);
         SELF_INJECTIONS.put(playerId, state);
      }

      state.ticks++;
      if (!state.pricked && state.ticks >= 45) {
         state.pricked = true;
         applyPrickEffect(player);
      }

      if (state.ticks >= 50) {
         SELF_INJECTIONS.remove(playerId);
         handleInject(player, syringeType);
      }
   }

   private static void resetSelfInjection(ServerPlayer player) {
      SELF_INJECTIONS.remove(player.getUUID());
   }

   public static void applyPrickEffect(ServerPlayer player) {
      if (player.getHealth() > 1.0F) {
         player.hurt(player.damageSources().sweetBerryBush(), 0.1F);
      }

      player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.SWEET_BERRY_BUSH_PICK_BERRIES, SoundSource.PLAYERS, 1.0F, 1.0F);
   }

   public static String syringeTypeFromStack(ItemStack stack) {
      if (stack != null && !stack.isEmpty()) {
         String itemName = stack.getItemHolder().getRegisteredName();
         String prefix = "theboysmod:";
         if (!itemName.startsWith(prefix)) {
            return null;
         } else {
            String syringeType = itemName.substring(prefix.length());
            return INJECTABLE_SYRINGES.contains(syringeType) ? syringeType : null;
         }
      } else {
         return null;
      }
   }

   private static void handleInject(ServerPlayer player, String syringeType) {
      injectTarget(player, player, syringeType, player.getMainHandItem());
   }

   public static boolean injectTarget(ServerPlayer injector, ServerPlayer target, String syringeType, ItemStack syringeStack) {
      if (injector == null || target == null || syringeStack == null || syringeStack.isEmpty()) {
         return false;
      } else if (!INJECTABLE_SYRINGES.contains(syringeType)) {
         VPower.LOGGER.info("[InjectV] Unhandled syringe type: {}", syringeType);
         return false;
      } else {
         String heldSyringeType = syringeTypeFromStack(syringeStack);
         if (!syringeType.equals(heldSyringeType)) {
            VPower.LOGGER
               .warn(
                  "[InjectV] Syringe stack mismatch. injector={}, held={}, requested={}",
                  new Object[]{injector.getName().getString(), heldSyringeType, syringeType}
               );
            return false;
         } else {
            // расы Invincible: кому можно V, Born for V, Human (VRaces)
            Boolean raceResult = VRaces.beforeInject(injector, target, syringeType, syringeStack);
            if (raceResult != null) {
               return raceResult;
            }

            SkillData skillData = (SkillData)target.getData(ModSkillAttachments.SKILL_DATA.get());
            boolean hadFleshStrength = skillData.hasSkill(ModSkills.FLESH_STRENGTH.getId().toString());
            expireTemporaryIfNeeded(target, skillData);

            boolean consumed = switch (syringeType) {
               case "compound_v_syringe" -> handleRandomInject(target, skillData);
               case "compound_v_temp_syringe" -> handleTemporaryInject(target, skillData);
               case "compound_v_remove_syringe" -> handleRemove(target, skillData);
               default -> false;
            };
            if (!consumed) {
               return false;
            } else {
               if (canStartFleshRegeneration(syringeType)) {
                  startDamagedFleshRegeneration(target);
               }

               syringeStack.shrink(1);
               boolean fillFleshStrength = !hadFleshStrength && skillData.hasSkill(ModSkills.FLESH_STRENGTH.getId().toString());
               if (fillFleshStrength) {
                  skillData.setShieldHp(skillData.getMaxShieldHp());
               }

               FleshStrengthHandler.refreshHealthModifier(target, skillData, fillFleshStrength);
               SkillSyncPacket.syncToClient(target);
               return true;
            }
         }
      }
   }

   private static boolean handleRandomInject(ServerPlayer player, SkillData skillData) {
      if (skillData.hasTemporarySkills()) {
         player.sendSystemMessage(Component.literal("§eTemp V ещё действует — постоянный V не вколоть. Дождитесь конца или используйте средство удаления V."));
         return false;
      } else if (hasAnyPermanentSkill(skillData)) {
         return upgradePermanentSkill(player, skillData);
      } else {
         List<Skill> available = filterUnavailable(permanentPool(), skillData, false);
         if (available.isEmpty()) {
            player.sendSystemMessage(Component.literal("§eУ вас уже есть все постоянные способности."));
            return false;
         } else {
            Skill chosen = available.get(player.getRandom().nextInt(available.size()));
            String skillId = chosen.getId().toString();
            skillData.addSkill(skillId);
            applyPermanentInitialSkillLevel(player, skillData, skillId);
            player.sendSystemMessage(Component.literal("§aВы получили способность: ").append(chosen.getName()));
            VPower.LOGGER.info("[InjectV] Player {} gained skill: {}", player.getName().getString(), skillId);
            return true;
         }
      }
   }

   private static boolean handleTemporaryInject(ServerPlayer player, SkillData skillData) {
      if (player.getServer() == null) {
         return false;
      } else {
         long currentGameTime = player.getServer().overworld().getGameTime();
         if (skillData.hasTemporarySkills()) {
            int remainingTicks = skillData.getTemporarySkillRemainingTicks(currentGameTime);
            player.sendSystemMessage(Component.literal("§eTemp V ещё действует (осталось " + formatRemainingTime(remainingTicks) + "), повторный укол не продлит время."));
            return false;
         } else {
            TempVFirstUseData firstUseData = TempVFirstUseData.get(player.getServer());
            boolean firstUse = !firstUseData.hasUsed(player.getUUID());
            Skill firstUsePreset = firstUse ? FIRST_TEMP_SKILLS.get(normalizeName(player.getGameProfile().getName())) : null;
            Skill catalystPreset = findTemporaryCatalystSkill(player.getOffhandItem());
            Skill preset = firstUsePreset != null ? firstUsePreset : catalystPreset;
            Skill chosen = chooseTemporarySkill(player, skillData, preset);
            if (chosen == null) {
               player.sendSystemMessage(Component.literal("§eУ вас уже есть все способности, которые может дать Temp V."));
               return false;
            } else {
               int previousFleshStrengthLevel = skillData.getFleshStrengthLevel();
               int previousSuperStrengthLevel = skillData.getSuperStrengthLevel();
               Set<String> before = new HashSet<>(skillData.getAllSkills());
               String skillId = chosen.getId().toString();
               skillData.addSkill(ModSkills.FLESH_STRENGTH.getId().toString());
               skillData.addSkill(ModSkills.SUPER_STRENGTH.getId().toString());
               skillData.addSkill(skillId);
               skillData.setFleshStrengthLevel(5);
               skillData.setSuperStrengthLevel(5);
               applyTemporarySkillLevel(skillData, skillId);
               Set<String> temporaryAdded = new HashSet<>(skillData.getAllSkills());
               temporaryAdded.removeAll(before);
               if (temporaryAdded.isEmpty()) {
                  player.sendSystemMessage(Component.literal("§eЭта временная способность уже действует."));
                  return false;
               } else {
                  int durationTicks = TempVDebugDurationData.consumeDurationTicksForInjection(player.getServer());
                  long expireGameTime = currentGameTime + (long)durationTicks;
                  skillData.beginTemporarySkills(skillId, temporaryAdded, expireGameTime, durationTicks, previousFleshStrengthLevel, previousSuperStrengthLevel);
                  firstUseData.markUsed(player.getUUID());
                  TempVSideEffectHandler.onTemporaryVInjected(player, skillData, currentGameTime);
                  player.sendSystemMessage(
                     Component.literal("§aTemp V подействовал: ").append(chosen.getName()).append(Component.literal(" §7(" + formatRemainingTime(durationTicks) + ")"))
                  );
                  VPower.LOGGER.info("[InjectV] Player {} gained temporary skill: {}", player.getName().getString(), skillId);
                  return true;
               }
            }
         }
      }
   }

   private static Skill chooseTemporarySkill(ServerPlayer player, SkillData skillData, Skill preset) {
      if (preset != null && !ownsAsPermanent(skillData, preset)) {
         return preset;
      } else {
         List<Skill> available = filterUnavailable(temporaryPool(), skillData, true);
         return available.isEmpty() ? null : chooseWeightedTemporarySkill(player, available);
      }
   }

   private static Skill chooseWeightedTemporarySkill(ServerPlayer player, List<Skill> available) {
      int totalWeight = 0;

      for (Skill skill : available) {
         totalWeight += getTemporarySkillWeight(player, skill);
      }

      if (totalWeight <= 0) {
         return available.get(player.getRandom().nextInt(available.size()));
      } else {
         int roll = player.getRandom().nextInt(totalWeight);

         for (Skill skill : available) {
            roll -= getTemporarySkillWeight(player, skill);
            if (roll < 0) {
               return skill;
            }
         }

         return available.get(available.size() - 1);
      }
   }

   private static int getTemporarySkillWeight(ServerPlayer player, Skill skill) {
      if (!isExclusiveTemporarySkill(skill)) {
         return 100;
      } else {
         return isExclusiveSkillOwner(player, skill) ? 100 : 1;
      }
   }

   private static Skill findTemporaryCatalystSkill(ItemStack stack) {
      if (stack != null && !stack.isEmpty()) {
         for (Entry<Item, Skill> entry : TEMP_CATALYST_SKILLS.entrySet()) {
            if (stack.is(entry.getKey())) {
               return entry.getValue();
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private static boolean isExclusiveTemporarySkill(Skill skill) {
      return skill != null && EXCLUSIVE_TEMP_SKILL_IDS.contains(skill.getId().toString());
   }

   private static boolean isExclusiveSkillOwner(ServerPlayer player, Skill skill) {
      Skill ownerSkill = FIRST_TEMP_SKILLS.get(normalizeName(player.getGameProfile().getName()));
      return ownerSkill != null && skill != null && ownerSkill.getId().equals(skill.getId());
   }

   private static boolean handleRemove(ServerPlayer player, SkillData skillData) {
      TempVSideEffectHandler.clearSideEffects(player, skillData);
      skillData.clearSkills();
      player.sendSystemMessage(Component.literal("§cВсе ваши способности удалены."));
      VPower.LOGGER.info("[InjectV] Player {} skills cleared", player.getName().getString());
      return true;
   }

   private static boolean upgradePermanentSkill(ServerPlayer player, SkillData skillData) {
      if (tryUpgradePermanentLevel(
         player, ModSkills.LASER_EYE.getName(), skillData.getLaserEyeLevel(), skillData::setLaserEyeLevel, skillData.hasSkill(ModSkills.LASER_EYE.getId())
      )) {
         return true;
      } else if (tryUpgradePermanentLevel(player, ModSkills.SUPER_SPEED.getName(), skillData.getSuperSpeedLevel(), level -> {
         skillData.setSuperSpeedLevel(level);
         skillData.setSpeedAdjustment(100);
      }, skillData.hasSkill(ModSkills.SUPER_SPEED.getId()))) {
         return true;
      } else if (tryUpgradePermanentLevel(
         player,
         ModSkills.SUPER_STRENGTH.getName(),
         skillData.getSuperStrengthLevel(),
         skillData::setSuperStrengthLevel,
         skillData.hasSkill(ModSkills.SUPER_STRENGTH.getId())
      )) {
         return true;
      } else if (tryUpgradePermanentLevel(
         player,
         ModSkills.FLESH_STRENGTH.getName(),
         skillData.getFleshStrengthLevel(),
         skillData::setFleshStrengthLevel,
         skillData.hasSkill(ModSkills.FLESH_STRENGTH.getId())
      )) {
         return true;
      } else {
         if (hasLevelablePermanentSkill(skillData)) {
            player.sendSystemMessage(Component.literal("§eПостоянные способности уже на максимальном уровне."));
         } else {
            player.sendSystemMessage(Component.literal("§eПостоянную способность нельзя прокачать; чтобы сменить её, используйте средство удаления V."));
         }

         return false;
      }
   }

   private static boolean tryUpgradePermanentLevel(ServerPlayer player, Component skillName, int currentLevel, IntConsumer setter, boolean owned) {
      if (owned && currentLevel < 5) {
         int nextLevel = Math.min(5, currentLevel + 1);
         setter.accept(nextLevel);
         player.sendSystemMessage(Component.literal("§aV усилил: ").append(skillName).append(Component.literal(" §7" + currentLevel + " -> " + nextLevel)));
         return true;
      } else {
         return false;
      }
   }

   private static boolean hasLevelablePermanentSkill(SkillData skillData) {
      return skillData.hasSkill(ModSkills.LASER_EYE.getId())
         || skillData.hasSkill(ModSkills.SUPER_SPEED.getId())
         || skillData.hasSkill(ModSkills.SUPER_STRENGTH.getId())
         || skillData.hasSkill(ModSkills.FLESH_STRENGTH.getId());
   }

   private static void applyPermanentInitialSkillLevel(ServerPlayer player, SkillData skillData, String skillId) {
      if (skillId.equals(ModSkills.LASER_EYE.getId().toString())) {
         skillData.setLaserEyeLevel(3);
      } else if (skillId.equals(ModSkills.SUPER_SPEED.getId().toString())) {
         skillData.setSuperSpeedLevel(3);
         skillData.setSpeedAdjustment(100);
      } else if (skillId.equals(ModSkills.SUPER_STRENGTH.getId().toString())) {
         skillData.setSuperStrengthLevel(randomLevel(player, 2, 5));
      } else if (skillId.equals(ModSkills.FLESH_STRENGTH.getId().toString())) {
         skillData.setFleshStrengthLevel(randomLevel(player, 2, 5));
      }
   }

   private static void applyTemporarySkillLevel(SkillData skillData, String skillId) {
      if (skillId.equals(ModSkills.LASER_EYE.getId().toString())) {
         skillData.setLaserEyeLevel(5);
      } else if (skillId.equals(ModSkills.SUPER_SPEED.getId().toString())) {
         skillData.setSuperSpeedLevel(5);
         skillData.setSpeedAdjustment(100);
      } else if (skillId.equals(ModSkills.SUPER_STRENGTH.getId().toString())) {
         skillData.setSuperStrengthLevel(5);
      } else if (skillId.equals(ModSkills.FLESH_STRENGTH.getId().toString())) {
         skillData.setFleshStrengthLevel(5);
      }
   }

   private static int randomLevel(ServerPlayer player, int min, int max) {
      return min + player.getRandom().nextInt(max - min + 1);
   }

   private static List<Skill> filterUnavailable(List<Skill> pool, SkillData skillData, boolean allowCurrentTemporary) {
      List<Skill> available = new ArrayList<>();

      for (Skill skill : pool) {
         if (allowCurrentTemporary) {
            if (!ownsAsPermanent(skillData, skill)) {
               available.add(skill);
            }
         } else if (!skillData.hasSkill(skill.getId())) {
            available.add(skill);
         }
      }

      return available;
   }

   private static boolean ownsAsPermanent(SkillData skillData, Skill skill) {
      String skillId = skill.getId().toString();
      return skillData.hasSkill(skillId) && !skillData.isTemporarySkill(skillId);
   }

   private static boolean hasAnyPermanentSkill(SkillData skillData) {
      for (String skillId : skillData.getAllSkills()) {
         if (!skillData.isTemporarySkill(skillId)) {
            return true;
         }
      }

      return false;
   }

   private static void expireTemporaryIfNeeded(ServerPlayer player, SkillData skillData) {
      if (player.getServer() != null) {
         long gameTime = player.getServer().overworld().getGameTime();
         if (!skillData.expireTemporarySkills(gameTime)) {
            return;
         }

         TempVSideEffectHandler.onTemporaryVExpired(player, skillData, gameTime);
         FleshStrengthHandler.refreshHealthModifier(player, skillData);
         SkillSyncPacket.syncToClient(player);
      }
   }

   private static boolean canStartFleshRegeneration(String syringeType) {
      return "compound_v_syringe".equals(syringeType) || "compound_v_temp_syringe".equals(syringeType);
   }

   private static void startDamagedFleshRegeneration(ServerPlayer player) {
      FleshRegenData fleshData = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
      if (fleshData.startCompoundVRegeneration()) {
         FleshRegenTickHandler.syncToTracking(player);
         player.level()
            .playSound(
               null,
               player.getX(),
               player.getY(),
               player.getZ(),
               (SoundEvent)ModSounds.REGENERATION.get(),
               SoundSource.PLAYERS,
               1.0F,
               0.95F + player.getRandom().nextFloat() * 0.1F
            );
      }
   }

   private static List<Skill> permanentPool() {
      List<Skill> pool = new ArrayList<>();
      pool.add(ModSkills.FLESH_REGEN);
      pool.add(ModSkills.FLESH_STRENGTH);
      pool.add(ModSkills.FLIGHT);
      pool.add(ModSkills.LASER_EYE);
      pool.add(ModSkills.SUPER_STRENGTH);
      pool.add(ModSkills.SUPER_VISION);
      pool.add(ModSkills.SUPER_SPEED);
      pool.add(ModSkills.FIRE);
      pool.add(ModSkills.DIAMOND_CLAWS);
      pool.add(ModSkills.SIZE);
      return pool;
   }

   private static List<Skill> temporaryPool() {
      List<Skill> pool = new ArrayList<>();
      pool.add(ModSkills.FLESH_REGEN);
      pool.add(ModSkills.FLIGHT);
      pool.add(ModSkills.LASER_EYE);
      pool.add(ModSkills.SUPER_VISION);
      pool.add(ModSkills.SUPER_SPEED);
      pool.add(ModSkills.FIRE);
      pool.add(ModSkills.DIAMOND_CLAWS);
      pool.add(ModSkills.SIZE);
      pool.add(ModSkills.WINGS);
      pool.add(ModSkills.SOUND_WAVE);
      pool.add(ModSkills.TOAD);
      pool.add(ModSkills.WATER_DISPENSER);
      pool.add(ModSkills.CHICKEN_EGG_HEAD);
      pool.add(ModSkills.NAILONG_BELIAL);
      return pool;
   }

   private static String normalizeName(String name) {
      return name == null ? "" : name.toLowerCase(Locale.ROOT);
   }

   private static String formatRemainingTime(int ticks) {
      int totalSeconds = Math.max(0, (ticks + 19) / 20);
      int minutes = totalSeconds / 60;
      int seconds = totalSeconds % 60;
      return String.format(Locale.ROOT, "%02d:%02d", minutes, seconds);
   }

   private static final class SelfInjectionState {
      private final String syringeType;
      private int ticks;
      private boolean pricked;

      private SelfInjectionState(String syringeType) {
         this.syringeType = syringeType;
      }
   }
}
