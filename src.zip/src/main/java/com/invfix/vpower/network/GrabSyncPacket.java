package com.invfix.vpower.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record GrabSyncPacket(int playerId, int targetEntityId, boolean grabbing) implements CustomPacketPayload {
   public static final Type<GrabSyncPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "grab_sync"));
   public static final StreamCodec<FriendlyByteBuf, GrabSyncPacket> STREAM_CODEC = StreamCodec.of(GrabSyncPacket::encode, GrabSyncPacket::decode);

   private static void encode(FriendlyByteBuf buf, GrabSyncPacket packet) {
      buf.writeVarInt(packet.playerId);
      buf.writeVarInt(packet.targetEntityId);
      buf.writeBoolean(packet.grabbing);
   }

   private static GrabSyncPacket decode(FriendlyByteBuf buf) {
      return new GrabSyncPacket(buf.readVarInt(), buf.readVarInt(), buf.readBoolean());
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handleClient(GrabSyncPacket packet, IPayloadContext context) {
      context.enqueueWork(() -> VClientPackets.grab(packet));
   }
}
