package com.invfix.vpower.network;

import com.invfix.vpower.server.LaserEyeDamageHandler;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record LaserEyeHitPosSyncPacket(int entityId, double x, double y, double z) implements CustomPacketPayload {
   public static final Type<LaserEyeHitPosSyncPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "laser_eye_hit_pos_sync"));
   public static final StreamCodec<RegistryFriendlyByteBuf, LaserEyeHitPosSyncPacket> STREAM_CODEC = StreamCodec.of((buf, msg) -> {
      buf.writeVarInt(msg.entityId);
      buf.writeDouble(msg.x);
      buf.writeDouble(msg.y);
      buf.writeDouble(msg.z);
   }, buf -> new LaserEyeHitPosSyncPacket(buf.readVarInt(), buf.readDouble(), buf.readDouble(), buf.readDouble()));

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handleServer(LaserEyeHitPosSyncPacket packet, IPayloadContext context) {
      context.enqueueWork(() -> {
         if (context.player() instanceof ServerPlayer player) {
            LaserEyeDamageHandler.updateClientHitPos(player, new Vec3(packet.x, packet.y, packet.z));
         }
      });
   }

   public static void handleClient(LaserEyeHitPosSyncPacket packet, IPayloadContext context) {
      context.enqueueWork(() -> VClientPackets.laserEyeHitPos(packet));
   }

}
