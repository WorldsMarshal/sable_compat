package com.invfix.vpower.network;

import com.invfix.vpower.VPower;
import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.client.ClientSkillStateCache;
import com.invfix.vpower.client.GrabClientState;
import com.invfix.vpower.client.animation.AnimationHelper;
import com.invfix.vpower.client.flight.FlightClientHandler;
import com.invfix.vpower.client.flight.WingFlightClientHandler;
import com.invfix.vpower.client.lasereye.LaserEyeClientHandler;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Клиентские половины пакетов V. В The Boys они лежали прямо в классах пакетов и тянули net.minecraft.client.* —
 * на выделенном сервере классы пакетов не грузились. Здесь пакет только передаёт вызов (enqueueWork → метод этого
 * класса), а клиентский код — только в этом классе.
 */
@OnlyIn(Dist.CLIENT)
public final class VClientPackets {

    private VClientPackets() {}

    static void fireTimer(FireTimerSyncPacket packet) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null && mc.level.getEntity(packet.entityId()) instanceof Player player) {
            SkillData skillData = player.getData(ModSkillAttachments.SKILL_DATA.get());
            skillData.setFireTimer(packet.fireTimer());
        }
    }

    static void fleshRegen(FleshRegenSyncPacket packet) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null && mc.level.getEntity(packet.entityId()) instanceof LivingEntity livingEntity) {
            FleshRegenData data = livingEntity.getData(ModAttachments.FLESH_REGEN.get());
            data.copyFrom(packet.data());
            livingEntity.refreshDimensions();
        }
    }

    static void fleshStrength(FleshStrengthSyncPacket packet) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) return;
        SkillData data = player.getData(ModSkillAttachments.SKILL_DATA.get());
        data.setFleshStrengthLevel(packet.fleshStrengthLevel());
        data.setShieldHp(packet.shieldHp());
        data.setMaxShieldHp(packet.maxShieldHp());
        data.setDamageThreshold(packet.damageThreshold());
        data.setFleshDamageReduction(packet.damageReduction());
    }

    static void grab(GrabSyncPacket packet) {
        if (packet.grabbing()) {
            GrabClientState.setGrabbing(packet.playerId(), packet.targetEntityId());
        } else {
            GrabClientState.clearGrabbing(packet.playerId());
        }
    }

    static void laserEyeHitPos(LaserEyeHitPosSyncPacket packet) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        if (mc.player == null || mc.player.getId() != packet.entityId()) {
            LaserEyeClientHandler.setRemoteHitPos(packet.entityId(), new Vec3(packet.x(), packet.y(), packet.z()));
        }
    }

    static void skillSync(SkillSyncPacket packet) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) return;
        SkillData skillData = player.getData(ModSkillAttachments.SKILL_DATA.get());
        skillData.deserializeNBT(player.registryAccess(), packet.data());
        VPower.LOGGER.debug("[SkillSync] Synced full skill data to client");
    }

    static void skillActive(SkillActiveSyncPacket packet) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        ClientSkillStateCache.updatePlayerStates(packet.entityId(), packet.activeStates(), packet.ownedSkills(), packet.temporarySkills());
        boolean hasWings = packet.ownedSkills().contains("theboysmod:wings");
        if (!hasWings) WingFlightClientHandler.setRemoteWingKnown(packet.entityId(), false);
        if (!hasWings && !packet.ownedSkills().contains("theboysmod:fire")) FlightClientHandler.setRemoteFlying(packet.entityId(), false);
        if (mc.player != null && mc.player.getId() == packet.entityId()) {
            SkillData skillData = mc.player.getData(ModSkillAttachments.SKILL_DATA.get());
            skillData.setActiveStates(packet.activeStates());
        }
    }

    static void flightPose(FlightPoseSyncPacket packet) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        int id = packet.entityId();
        boolean isLocalPlayer = mc.player != null && mc.player.getId() == id;
        if (!(mc.level.getEntity(id) instanceof Player targetPlayer)) return;
        switch (packet.action()) {
            case START -> {
                FlightClientHandler.setRemoteFlying(id, true);
                WingFlightClientHandler.setRemoteWingState(id, false, false);
                if (!isLocalPlayer && !targetPlayer.isFallFlying()) targetPlayer.startFallFlying();
            }
            case STOP -> {
                FlightClientHandler.setRemoteFlying(id, false);
                WingFlightClientHandler.setRemoteWingState(id, false, false);
                if (!isLocalPlayer && targetPlayer.isFallFlying()) targetPlayer.stopFallFlying();
            }
            case START_HOVER, STOP_HOVER -> {
                FlightClientHandler.setRemoteFlying(id, false);
                if (!isLocalPlayer && targetPlayer.isFallFlying()) targetPlayer.stopFallFlying();
            }
            case WINGS_START -> {
                FlightClientHandler.setRemoteFlying(id, true);
                WingFlightClientHandler.setRemoteWingState(id, true, false);
                if (!isLocalPlayer && !targetPlayer.isFallFlying()) targetPlayer.startFallFlying();
            }
            case WINGS_STOP, WINGS_STOP_HOVER -> {
                FlightClientHandler.setRemoteFlying(id, false);
                WingFlightClientHandler.setRemoteWingState(id, false, false);
                if (!isLocalPlayer && targetPlayer.isFallFlying()) targetPlayer.stopFallFlying();
            }
            case WINGS_START_HOVER -> {
                FlightClientHandler.setRemoteFlying(id, false);
                WingFlightClientHandler.setRemoteWingState(id, true, true);
                if (!isLocalPlayer && targetPlayer.isFallFlying()) targetPlayer.stopFallFlying();
            }
        }
    }

    // ── анимации игроков (PlayerAnimator) ─────────────────────────────────────

    private static final Queue<PlayerAnimationPlaySyncPacket> PENDING = new ConcurrentLinkedQueue<>();
    /** Больше этого — самые старые отбрасываются (сущность так и не появилась). */
    private static final int PENDING_MAX = 64;

    private static void pend(PlayerAnimationPlaySyncPacket msg) {
        PENDING.add(msg);
        while (PENDING.size() > PENDING_MAX) PENDING.poll();
    }

    static void animationPlay(PlayerAnimationPlaySyncPacket msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            pend(msg);
        } else {
            applyOrQueue(mc.level, msg);
        }
    }

    private static void applyOrQueue(Level level, PlayerAnimationPlaySyncPacket msg) {
        Entity entity = level.getEntity(msg.entityId());
        if (!(entity instanceof Player player)) {
            pend(msg);
            return;
        }
        LocalPlayer local = Minecraft.getInstance().player;
        if (local != null && player.getUUID().equals(local.getUUID())) return;
        if (msg.firstFrameOnly()) {
            AnimationHelper.playAnimationFirstFrame(player, msg.animation(), false);
        } else {
            AnimationHelper.playAnimationWithFade(player, msg.animation(), msg.fadeInTicks(), msg.loop());
        }
    }

    static void animationStop(PlayerAnimationStopSyncPacket msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || !(mc.level.getEntity(msg.entityId()) instanceof Player player)) return;
        LocalPlayer local = mc.player;
        if (local != null && player.getUUID().equals(local.getUUID())) return;
        AnimationHelper.stopAnimation(player, msg.fadeOutTicks());
    }

    /** Анимации, пришедшие раньше сущности, — применяются, когда она появится (на каждом кадре). */
    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
    public static final class SyncHooks {
        @SubscribeEvent
        public static void onRenderStage(RenderLevelStageEvent event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null || PENDING.isEmpty()) return;
            int n = PENDING.size();
            for (int i = 0; i < n; i++) {
                PlayerAnimationPlaySyncPacket next = PENDING.poll();
                if (next == null) break;
                applyOrQueue(mc.level, next);
            }
        }
    }
}
