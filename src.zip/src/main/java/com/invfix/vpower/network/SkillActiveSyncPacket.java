package com.invfix.vpower.network;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record SkillActiveSyncPacket(int entityId, Map<String, Boolean> activeStates, Set<String> ownedSkills, Set<String> temporarySkills)
   implements CustomPacketPayload {
   public static final Type<SkillActiveSyncPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "skill_active_sync"));
   public static final StreamCodec<FriendlyByteBuf, SkillActiveSyncPacket> STREAM_CODEC = StreamCodec.of(
      SkillActiveSyncPacket::encode, SkillActiveSyncPacket::decode
   );

   public SkillActiveSyncPacket(int entityId, Map<String, Boolean> activeStates, Set<String> ownedSkills, Set<String> temporarySkills) {
      Map<String, Boolean> var5 = activeStates == null ? new HashMap() : new HashMap<>(activeStates);
      Set<String> var6 = ownedSkills == null ? new HashSet() : new HashSet<>(ownedSkills);
      Set<String> var7 = temporarySkills == null ? new HashSet() : new HashSet<>(temporarySkills);
      this.entityId = entityId;
      this.activeStates = var5;
      this.ownedSkills = var6;
      this.temporarySkills = var7;
   }

   private static void encode(FriendlyByteBuf buf, SkillActiveSyncPacket packet) {
      buf.writeInt(packet.entityId);
      buf.writeInt(packet.activeStates.size());

      for (Entry<String, Boolean> entry : packet.activeStates.entrySet()) {
         buf.writeUtf(entry.getKey());
         buf.writeBoolean(entry.getValue());
      }

      buf.writeInt(packet.ownedSkills.size());

      for (String skillId : packet.ownedSkills) {
         buf.writeUtf(skillId);
      }

      buf.writeInt(packet.temporarySkills.size());

      for (String skillId : packet.temporarySkills) {
         buf.writeUtf(skillId);
      }
   }

   private static SkillActiveSyncPacket decode(FriendlyByteBuf buf) {
      int entityId = buf.readInt();
      int size = buf.readInt();
      Map<String, Boolean> states = new HashMap<>();

      for (int i = 0; i < size; i++) {
         states.put(buf.readUtf(), buf.readBoolean());
      }

      int ownedSize = buf.readInt();
      Set<String> ownedSkills = new HashSet<>();

      for (int i = 0; i < ownedSize; i++) {
         ownedSkills.add(buf.readUtf());
      }

      Set<String> temporarySkills = new HashSet<>();
      if (buf.readableBytes() > 0) {
         int temporarySize = buf.readInt();

         for (int i = 0; i < temporarySize; i++) {
            temporarySkills.add(buf.readUtf());
         }
      }

      return new SkillActiveSyncPacket(entityId, states, ownedSkills, temporarySkills);
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(SkillActiveSyncPacket packet, IPayloadContext context) {
      context.enqueueWork(() -> VClientPackets.skillActive(packet));
   }

   public static void syncToClient(ServerPlayer player) {
      PacketDistributor.sendToPlayer(player, createPacket(player), new CustomPacketPayload[0]);
   }

   public static void syncToWrappers(ServerPlayer player) {
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, createPacket(player), new CustomPacketPayload[0]);
   }

   public static void syncToTracking(LivingEntity entity) {
      if (entity != null && !entity.level().isClientSide) {
         SkillActiveSyncPacket packet = createPacket(entity);
         if (entity instanceof ServerPlayer player) {
            PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, packet, new CustomPacketPayload[0]);
         } else {
            PacketDistributor.sendToPlayersTrackingEntity(entity, packet, new CustomPacketPayload[0]);
         }
      }
   }

   public static void syncStateToPlayer(ServerPlayer sourcePlayer, ServerPlayer receiver) {
      PacketDistributor.sendToPlayer(receiver, createPacket(sourcePlayer), new CustomPacketPayload[0]);
   }

   private static SkillActiveSyncPacket createPacket(ServerPlayer player) {
      return createPacket((LivingEntity)player);
   }

   private static SkillActiveSyncPacket createPacket(LivingEntity entity) {
      SkillData data = (SkillData)entity.getData(ModSkillAttachments.SKILL_DATA.get());
      data.ensureChildSkills();
      return new SkillActiveSyncPacket(entity.getId(), data.getActiveStates(), data.getAllSkills(), data.getTemporarySkills());
   }
}
