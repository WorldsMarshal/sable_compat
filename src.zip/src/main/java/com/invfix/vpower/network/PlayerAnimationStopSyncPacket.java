package com.invfix.vpower.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record PlayerAnimationStopSyncPacket(int entityId, int fadeOutTicks) implements CustomPacketPayload {
   public static final Type<PlayerAnimationStopSyncPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "player_animation_stop_sync"));
   public static final StreamCodec<RegistryFriendlyByteBuf, PlayerAnimationStopSyncPacket> STREAM_CODEC = StreamCodec.of((buf, msg) -> {
      buf.writeVarInt(msg.entityId);
      buf.writeVarInt(msg.fadeOutTicks);
   }, buf -> new PlayerAnimationStopSyncPacket(buf.readVarInt(), buf.readVarInt()));

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handleClient(PlayerAnimationStopSyncPacket msg, IPayloadContext context) {
      context.enqueueWork(() -> VClientPackets.animationStop(msg));
   }
}
