package com.invfix.vpower.network;

import com.invfix.vpower.server.GrabHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record GrabPacket(GrabPacket.Action action) implements CustomPacketPayload {
   public static final Type<GrabPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "grab_action"));
   public static final StreamCodec<FriendlyByteBuf, GrabPacket> STREAM_CODEC = StreamCodec.of(GrabPacket::encode, GrabPacket::decode);

   private static void encode(FriendlyByteBuf buf, GrabPacket packet) {
      buf.writeVarInt(packet.action.ordinal());
   }

   private static GrabPacket decode(FriendlyByteBuf buf) {
      return new GrabPacket(GrabPacket.Action.values()[buf.readVarInt()]);
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(GrabPacket packet, IPayloadContext context) {
      context.enqueueWork(() -> {
         if (context.player() instanceof ServerPlayer player) {
            switch (packet.action) {
               case GRAB:
                  GrabHandler.handleGrab(player);
                  break;
               case HOLD_TICK:
                  GrabHandler.handleHoldTick(player);
                  break;
               case THROW:
                  GrabHandler.handleThrow(player);
                  break;
               case RELEASE:
                  GrabHandler.handleRelease(player);
            }
         }
      });
   }

   public static enum Action {
      GRAB,
      HOLD_TICK,
      THROW,
      RELEASE;
   }
}
