package com.invfix.vpower.network;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record SkillDamageAdjustPacket(String skillId, int percentage) implements CustomPacketPayload {
   public static final Type<SkillDamageAdjustPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "skill_damage_adjust"));
   public static final StreamCodec<FriendlyByteBuf, SkillDamageAdjustPacket> STREAM_CODEC = StreamCodec.composite(
      ByteBufCodecs.STRING_UTF8, SkillDamageAdjustPacket::skillId, ByteBufCodecs.INT, SkillDamageAdjustPacket::percentage, SkillDamageAdjustPacket::new
   );

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(SkillDamageAdjustPacket packet, IPayloadContext context) {
      context.enqueueWork(() -> {
         Player player = context.player();
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         int clamped = Math.max(0, Math.min(100, packet.percentage()));
         if (packet.skillId().isEmpty()) {
            data.setMeleeDamageMultiplier(clamped);
         } else {
            data.setDamageMultiplier(packet.skillId(), clamped);
         }
      });
   }
}
