package com.invfix.vpower.network;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record SkillSetActivePacket(String skillId, boolean active) implements CustomPacketPayload {
   public static final Type<SkillSetActivePacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "skill_set_active"));
   public static final StreamCodec<FriendlyByteBuf, SkillSetActivePacket> STREAM_CODEC = StreamCodec.composite(
      ByteBufCodecs.STRING_UTF8, SkillSetActivePacket::skillId, ByteBufCodecs.BOOL, SkillSetActivePacket::active, SkillSetActivePacket::new
   );

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(SkillSetActivePacket packet, IPayloadContext context) {
      context.enqueueWork(() -> {
         Player player = context.player();
         if (player != null) {
            SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            if (skillData.hasSkill(packet.skillId)) {
               skillData.setSkillActive(packet.skillId, packet.active);
               if (player instanceof ServerPlayer serverPlayer) {
                  SkillActiveSyncPacket.syncToWrappers(serverPlayer);
               }
            }
         }
      });
   }

}
