package com.invfix.vpower.network;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record FleshStrengthSyncPacket(float shieldHp, float maxShieldHp, float damageThreshold, int damageReduction, int fleshStrengthLevel)
   implements CustomPacketPayload {
   public static final Type<FleshStrengthSyncPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "flesh_strength_sync"));
   public static final StreamCodec<FriendlyByteBuf, FleshStrengthSyncPacket> STREAM_CODEC = StreamCodec.of(
      FleshStrengthSyncPacket::encode, FleshStrengthSyncPacket::decode
   );

   private static void encode(FriendlyByteBuf buf, FleshStrengthSyncPacket p) {
      buf.writeFloat(p.shieldHp);
      buf.writeFloat(p.maxShieldHp);
      buf.writeFloat(p.damageThreshold);
      buf.writeInt(p.damageReduction);
      buf.writeInt(p.fleshStrengthLevel);
   }

   private static FleshStrengthSyncPacket decode(FriendlyByteBuf buf) {
      return new FleshStrengthSyncPacket(buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readInt(), buf.readInt());
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(FleshStrengthSyncPacket packet, IPayloadContext context) {
      context.enqueueWork(() -> VClientPackets.fleshStrength(packet));
   }

   public static void syncToClient(ServerPlayer player) {
      SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
      PacketDistributor.sendToPlayer(
         player,
         new FleshStrengthSyncPacket(
            data.getShieldHp(),
            data.getShieldHp() > data.getMaxShieldHp() ? data.getShieldHp() : data.getMaxShieldHp(),
            data.getDamageThreshold(),
            data.getFleshDamageReduction(),
            data.getFleshStrengthLevel()
         ),
         new CustomPacketPayload[0]
      );
   }
}
