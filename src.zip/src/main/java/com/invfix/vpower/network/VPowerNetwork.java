package com.invfix.vpower.network;

import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.DirectionalPayloadHandler;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Пакеты V (id — theboysmod:*, как в The Boys). Клиентские обработчики только передают вызов в VClientPackets —
 * классы пакетов грузятся и на выделенном сервере.
 */
public final class VPowerNetwork {

    private VPowerNetwork() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar r = event.registrar("1");
        r.playToClient(FleshRegenSyncPacket.TYPE, FleshRegenSyncPacket.STREAM_CODEC, FleshRegenSyncPacket::handle);
        r.playToServer(DetachPartPacket.TYPE, DetachPartPacket.STREAM_CODEC, DetachPartPacket::handle);
        r.playToClient(PlayerAnimationPlaySyncPacket.TYPE, PlayerAnimationPlaySyncPacket.STREAM_CODEC, PlayerAnimationPlaySyncPacket::handleClient);
        r.playToClient(PlayerAnimationStopSyncPacket.TYPE, PlayerAnimationStopSyncPacket.STREAM_CODEC, PlayerAnimationStopSyncPacket::handleClient);
        r.playToClient(SkillSyncPacket.TYPE, SkillSyncPacket.STREAM_CODEC, SkillSyncPacket::handle);
        r.playToServer(SkillTogglePacket.TYPE, SkillTogglePacket.STREAM_CODEC, SkillTogglePacket::handle);
        r.playToServer(SkillSetActivePacket.TYPE, SkillSetActivePacket.STREAM_CODEC, SkillSetActivePacket::handle);
        r.playToClient(SkillActiveSyncPacket.TYPE, SkillActiveSyncPacket.STREAM_CODEC, SkillActiveSyncPacket::handle);
        r.playToServer(FlightPosePacket.TYPE, FlightPosePacket.STREAM_CODEC, FlightPosePacket::handle);
        r.playToClient(FlightPoseSyncPacket.TYPE, FlightPoseSyncPacket.STREAM_CODEC, FlightPoseSyncPacket::handle);
        r.playToServer(SkillDamageAdjustPacket.TYPE, SkillDamageAdjustPacket.STREAM_CODEC, SkillDamageAdjustPacket::handle);
        r.playBidirectional(LaserEyeHitPosSyncPacket.TYPE, LaserEyeHitPosSyncPacket.STREAM_CODEC,
                new DirectionalPayloadHandler<>(LaserEyeHitPosSyncPacket::handleClient, LaserEyeHitPosSyncPacket::handleServer));
        r.playToClient(FleshStrengthSyncPacket.TYPE, FleshStrengthSyncPacket.STREAM_CODEC, FleshStrengthSyncPacket::handle);
        r.playToServer(GrabPacket.TYPE, GrabPacket.STREAM_CODEC, GrabPacket::handle);
        r.playToClient(GrabSyncPacket.TYPE, GrabSyncPacket.STREAM_CODEC, GrabSyncPacket::handleClient);
        r.playToServer(SpeedAdjustPacket.TYPE, SpeedAdjustPacket.STREAM_CODEC, SpeedAdjustPacket::handle);
        r.playToServer(ScaleSetPacket.TYPE, ScaleSetPacket.STREAM_CODEC, ScaleSetPacket::handle);
        r.playToServer(InjectVPacket.TYPE, InjectVPacket.STREAM_CODEC, InjectVPacket::handle);
        r.playToClient(FireTimerSyncPacket.TYPE, FireTimerSyncPacket.STREAM_CODEC, FireTimerSyncPacket::handle);
        r.playToServer(VSkillSelectPacket.TYPE, VSkillSelectPacket.STREAM_CODEC, VSkillSelectPacket::handle);
    }
}
