package com.invfix.vpower.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record PlayerAnimationPlaySyncPacket(int entityId, ResourceLocation animation, boolean loop, int fadeInTicks, boolean firstFrameOnly)
   implements CustomPacketPayload {
   public static final Type<PlayerAnimationPlaySyncPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "player_animation_play_sync"));
   public static final StreamCodec<RegistryFriendlyByteBuf, PlayerAnimationPlaySyncPacket> STREAM_CODEC = StreamCodec.of((buf, msg) -> {
      buf.writeVarInt(msg.entityId);
      buf.writeResourceLocation(msg.animation);
      buf.writeBoolean(msg.loop);
      buf.writeVarInt(msg.fadeInTicks);
      buf.writeBoolean(msg.firstFrameOnly);
   }, buf -> new PlayerAnimationPlaySyncPacket(buf.readVarInt(), buf.readResourceLocation(), buf.readBoolean(), buf.readVarInt(), buf.readBoolean()));

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handleClient(PlayerAnimationPlaySyncPacket msg, IPayloadContext context) {
      context.enqueueWork(() -> VClientPackets.animationPlay(msg));
   }

}
