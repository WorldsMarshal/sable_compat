package com.invfix.vpower.network;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record FireTimerSyncPacket(int entityId, int fireTimer) implements CustomPacketPayload {
   public static final Type<FireTimerSyncPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "fire_timer_sync"));
   public static final StreamCodec<FriendlyByteBuf, FireTimerSyncPacket> STREAM_CODEC = StreamCodec.of(FireTimerSyncPacket::encode, FireTimerSyncPacket::decode);

   private static void encode(FriendlyByteBuf buf, FireTimerSyncPacket packet) {
      buf.writeInt(packet.entityId);
      buf.writeInt(packet.fireTimer);
   }

   private static FireTimerSyncPacket decode(FriendlyByteBuf buf) {
      return new FireTimerSyncPacket(buf.readInt(), buf.readInt());
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(FireTimerSyncPacket packet, IPayloadContext context) {
      context.enqueueWork(() -> VClientPackets.fireTimer(packet));
   }

   public static void syncToWrappers(ServerPlayer player) {
      SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
      FireTimerSyncPacket packet = new FireTimerSyncPacket(player.getId(), data.getFireTimer());
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, packet, new CustomPacketPayload[0]);
   }
}
