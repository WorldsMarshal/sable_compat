package com.invfix.vpower.network;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record SpeedAdjustPacket(int speedPercentage) implements CustomPacketPayload {
   public static final Type<SpeedAdjustPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "speed_adjust"));
   public static final StreamCodec<FriendlyByteBuf, SpeedAdjustPacket> STREAM_CODEC = StreamCodec.composite(
      ByteBufCodecs.INT, SpeedAdjustPacket::speedPercentage, SpeedAdjustPacket::new
   );

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(SpeedAdjustPacket packet, IPayloadContext context) {
      context.enqueueWork(() -> {
         Player player = context.player();
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         data.setSpeedAdjustment(packet.speedPercentage());
      });
   }
}
