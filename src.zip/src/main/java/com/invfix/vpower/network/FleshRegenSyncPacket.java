package com.invfix.vpower.network;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record FleshRegenSyncPacket(int entityId, CompoundTag data) implements CustomPacketPayload {
   public static final Type<FleshRegenSyncPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "flesh_regen_sync"));
   public static final StreamCodec<FriendlyByteBuf, FleshRegenSyncPacket> STREAM_CODEC = StreamCodec.composite(
      ByteBufCodecs.VAR_INT, FleshRegenSyncPacket::entityId, ByteBufCodecs.COMPOUND_TAG, FleshRegenSyncPacket::data, FleshRegenSyncPacket::new
   );

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(FleshRegenSyncPacket packet, IPayloadContext context) {
      context.enqueueWork(() -> VClientPackets.fleshRegen(packet));
   }
}
