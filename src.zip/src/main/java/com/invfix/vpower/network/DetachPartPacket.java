package com.invfix.vpower.network;

import io.netty.buffer.ByteBuf;
import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.registry.ModDamageTypes;
import com.invfix.vpower.registry.ModParticles;
import com.invfix.vpower.registry.ModSounds;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record DetachPartPacket(String partKey) implements CustomPacketPayload {
   public static final Type<DetachPartPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "detach_part"));
   public static final StreamCodec<ByteBuf, DetachPartPacket> STREAM_CODEC = StreamCodec.composite(
      ByteBufCodecs.STRING_UTF8, DetachPartPacket::partKey, DetachPartPacket::new
   );

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(DetachPartPacket packet, IPayloadContext context) {
      context.enqueueWork(
         () -> {
            if (context.player() instanceof ServerPlayer player) {
               FleshRegenData data = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
               boolean boneDetachStage = isBoneDetachStage(data, packet.partKey);
               stripPart(data, packet.partKey);
               playDetachParticles(player, packet.partKey, boneDetachStage);
               player.level()
                  .playSound(null, player.getX(), player.getY(), player.getZ(), (SoundEvent)ModSounds.BLOOD_BOOM.get(), SoundSource.PLAYERS, 0.3F, 1.0F);
               SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
               boolean liukuActive = skillData.isSkillActive("theboysmod:flesh_regen");
               float damage = getPartDamage(packet.partKey);
               boolean isFatalPart = packet.partKey.equals("Head") || packet.partKey.equals("Body");
               ResourceKey<DamageType> damageTypeKey = ModDamageTypes.getForPart(packet.partKey);
               Registry<DamageType> registry = player.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE);
               DamageSource damageSource = new DamageSource(registry.getHolderOrThrow(damageTypeKey));
               if (isFatalPart && !liukuActive) {
                  PacketDistributor.sendToPlayer(player, new FleshRegenSyncPacket(player.getId(), data.toTag()), new CustomPacketPayload[0]);
                  float fatalDamage = player.getMaxHealth() + 1000.0F;
                  player.hurt(damageSource, fatalDamage);
                  return;
               }

               if (damage > 0.0F) {
                  player.hurt(damageSource, damage);
               }

               if (player.isDeadOrDying()) {
                  return;
               }

               int newScore = data.getScore(packet.partKey);
               if (newScore == 0) {
                  if (packet.partKey.equals("Head")) {
                     for (String part : FleshRegenData.PART_MAX_SCORES.keySet()) {
                        if (!part.equals("Head")) {
                           data.activatePart(part, 0);
                        }
                     }
                  } else if (packet.partKey.equals("Body")) {
                     for (String partx : FleshRegenData.PART_MAX_SCORES.keySet()) {
                        if (!partx.equals("Head") && !partx.equals("Body")) {
                           data.activatePart(partx, 0);
                        }
                     }
                  }
               }

               if (packet.partKey.equals("Right.Arm")) {
                  stripPart(data, "Right.Hand");
               } else if (packet.partKey.equals("Left.Arm")) {
                  stripPart(data, "Left.Hand");
               } else if (packet.partKey.equals("Right.Leg")) {
                  stripPart(data, "Right.Feet");
               } else if (packet.partKey.equals("Left.Leg")) {
                  stripPart(data, "Left.Feet");
               }

               data.normalizeLinkedPartScores();
               PacketDistributor.sendToPlayer(player, new FleshRegenSyncPacket(player.getId(), data.toTag()), new CustomPacketPayload[0]);
            }
         }
      );
   }

   private static boolean isBoneDetachStage(FleshRegenData data, String partKey) {
      int currentScore = data.getScore(partKey);
      int boneScore = FleshRegenData.PART_BONE_SCORES.getOrDefault(partKey, 0);
      if (currentScore < 0) {
         currentScore = FleshRegenData.PART_MAX_SCORES.getOrDefault(partKey, boneScore);
      }

      return currentScore <= boneScore;
   }

   private static void playDetachParticles(ServerPlayer player, String partKey, boolean boneDetachStage) {
      if (player.level() instanceof ServerLevel level) {
         Vec3 var5 = getBodyPartParticlePosition(player, partKey);
         if (boneDetachStage) {
            level.sendParticles(ParticleTypes.CLOUD, var5.x, var5.y, var5.z, 18, 0.1, 0.07, 0.1, 0.02);
            level.sendParticles(ParticleTypes.WHITE_ASH, var5.x, var5.y, var5.z, 14, 0.11, 0.06, 0.11, 0.01);
         } else {
            level.sendParticles(ModParticles.BLOOD.get(), var5.x, var5.y, var5.z, 24, 0.14, 0.08, 0.14, 0.08);
         }
      }
   }

   private static Vec3 getBodyPartParticlePosition(ServerPlayer player, String partKey) {
      Vec3 forward = player.getLookAngle();
      forward = new Vec3(forward.x, 0.0, forward.z);
      if (forward.lengthSqr() < 1.0E-4) {
         forward = new Vec3(0.0, 0.0, 1.0);
      }

      forward = forward.normalize();
      Vec3 right = new Vec3(-forward.z, 0.0, forward.x);
      double sideOffset = 0.0;
      double yOffset = (double)player.getBbHeight() * 0.58;
      double forwardOffset = 0.0;
      switch (partKey) {
         case "Head":
            yOffset = (double)player.getBbHeight() * 0.88;
            break;
         case "Body":
            yOffset = (double)player.getBbHeight() * 0.56;
            break;
         case "Right.Arm":
            sideOffset = -0.42;
            yOffset = (double)player.getBbHeight() * 0.64;
            forwardOffset = -0.03;
            break;
         case "Left.Arm":
            sideOffset = 0.42;
            yOffset = (double)player.getBbHeight() * 0.64;
            forwardOffset = -0.03;
            break;
         case "Right.Hand":
            sideOffset = -0.55;
            yOffset = (double)player.getBbHeight() * 0.44;
            forwardOffset = 0.05;
            break;
         case "Left.Hand":
            sideOffset = 0.55;
            yOffset = (double)player.getBbHeight() * 0.44;
            forwardOffset = 0.05;
            break;
         case "Right.Leg":
            sideOffset = -0.18;
            yOffset = (double)player.getBbHeight() * 0.3;
            break;
         case "Left.Leg":
            sideOffset = 0.18;
            yOffset = (double)player.getBbHeight() * 0.3;
            break;
         case "Right.Feet":
            sideOffset = -0.18;
            yOffset = 0.1;
            forwardOffset = 0.06;
            break;
         case "Left.Feet":
            sideOffset = 0.18;
            yOffset = 0.1;
            forwardOffset = 0.06;
      }

      return player.position().add(right.scale(sideOffset)).add(forward.scale(forwardOffset)).add(0.0, yOffset, 0.0);
   }

   private static void stripPart(FleshRegenData data, String partKey) {
      int currentScore = data.getScore(partKey);
      int boneScore = FleshRegenData.PART_BONE_SCORES.getOrDefault(partKey, 0);
      if (currentScore < 0) {
         currentScore = FleshRegenData.PART_MAX_SCORES.getOrDefault(partKey, boneScore);
      }

      if (currentScore > boneScore) {
         data.activatePart(partKey, boneScore);
      } else {
         data.activatePart(partKey, 0);
      }
   }

   private static float getPartDamage(String partKey) {
      return switch (partKey) {
         case "Head" -> 40.0F;
         case "Body" -> 30.0F;
         case "Right.Arm", "Left.Arm", "Right.Leg", "Left.Leg" -> 8.0F;
         case "Right.Hand", "Left.Hand", "Right.Feet", "Left.Feet" -> 4.0F;
         default -> 0.0F;
      };
   }
}
