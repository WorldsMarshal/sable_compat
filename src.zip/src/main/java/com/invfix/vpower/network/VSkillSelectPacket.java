package com.invfix.vpower.network;

import com.invfix.vpower.VPowerMenu;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Клиент → сервер: кнопка способности V во вкладке PWR (VPowerMenu.select). */
public record VSkillSelectPacket(String skillId) implements CustomPacketPayload {
    public static final Type<VSkillSelectPacket> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "v_skill_select"));
    public static final StreamCodec<FriendlyByteBuf, VSkillSelectPacket> STREAM_CODEC =
            StreamCodec.of((buf, p) -> buf.writeUtf(p.skillId), buf -> new VSkillSelectPacket(buf.readUtf()));

    @Override
    public Type<VSkillSelectPacket> type() {
        return TYPE;
    }

    public static void handle(VSkillSelectPacket packet, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) VPowerMenu.select(player, packet.skillId);
        });
    }
}
