package com.invfix.vpower.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record FlightPoseSyncPacket(int entityId, FlightPosePacket.Action action) implements CustomPacketPayload {
   public static final Type<FlightPoseSyncPacket> TYPE = new Type(ResourceLocation.fromNamespaceAndPath("theboysmod", "flight_pose_sync"));
   public static final StreamCodec<FriendlyByteBuf, FlightPoseSyncPacket> STREAM_CODEC = StreamCodec.of(
      FlightPoseSyncPacket::encode, FlightPoseSyncPacket::decode
   );

   private static void encode(FriendlyByteBuf buf, FlightPoseSyncPacket packet) {
      buf.writeVarInt(packet.entityId);
      buf.writeEnum(packet.action);
   }

   private static FlightPoseSyncPacket decode(FriendlyByteBuf buf) {
      return new FlightPoseSyncPacket(buf.readVarInt(), (FlightPosePacket.Action)buf.readEnum(FlightPosePacket.Action.class));
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public static void handle(FlightPoseSyncPacket packet, IPayloadContext context) {
      context.enqueueWork(() -> VClientPackets.flightPose(packet));
   }
}
