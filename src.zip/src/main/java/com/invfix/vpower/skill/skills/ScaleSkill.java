package com.invfix.vpower.skill.skills;

import com.invfix.vpower.skill.base.Skill;
import com.invfix.vpower.skill.base.SkillType;
import net.minecraft.resources.ResourceLocation;

public class ScaleSkill extends Skill {
   public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "scale");

   @Override
   public ResourceLocation getId() {
      return ID;
   }

   @Override
   public SkillType getType() {
      return SkillType.CHANNELED;
   }

   @Override
   public boolean requiresMastery() {
      return false;
   }
}
