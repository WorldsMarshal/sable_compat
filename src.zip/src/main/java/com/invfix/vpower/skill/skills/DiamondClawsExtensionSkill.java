package com.invfix.vpower.skill.skills;

import com.invfix.vpower.skill.base.Skill;
import com.invfix.vpower.skill.base.SkillType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;

public class DiamondClawsExtensionSkill extends Skill {
   public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "diamond_claws_extension");

   @Override
   public ResourceLocation getId() {
      return ID;
   }

   @Override
   public SkillType getType() {
      return SkillType.TOGGLE;
   }

   @Override
   public boolean requiresMastery() {
      return false;
   }

   @Override
   public void trigger(LivingEntity owner) {
      if (owner instanceof ServerPlayer player && player.getHealth() > 1.0F) {
         player.hurt(player.damageSources().sweetBerryBush(), 0.1F);
      }
   }

   @Override
   public ResourceLocation getIcon() {
      return ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/models/claw/claw.png");
   }
}
