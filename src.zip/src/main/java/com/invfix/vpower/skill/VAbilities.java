package com.invfix.vpower.skill;

import com.invfix.vpower.skill.base.Skill;
import com.invfix.vpower.skill.base.SkillType;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Навыки V в слотах способностей Invincible (AbilitySlot1..5 / _row2). В слот кладётся имя навыка, как у способностей
 * Invincible: {@link #PREFIX} + английское название (из en_us The Boys); по нему клавиша способности находит навык.
 * Оверлей Invincible показывает строку слота как есть. В слот ставятся только навыки с действием (ACTIVE, TOGGLE,
 * CHANNELED) — пассивные работают сами.
 */
public final class VAbilities {

    /** Цвет навыков V в слотах — у способностей Invincible и наших такого нет. */
    public static final String PREFIX = "§3§l";

    private static final Map<String, String> NAMES = new LinkedHashMap<>();
    private static final Map<String, String> BY_SLOT = new HashMap<>();
    private static final Map<String, String> ENGLISH = new HashMap<>();

    static {
        name("laser_eye", "Heat Vision");
        name("xray_vision", "X-Ray Vision");
        name("super_strength", "Super Strength");
        name("stomp", "Stomp");
        name("grab", "Grab");
        name("super_jump", "Super Jump");
        name("speed", "Speed");
        name("fire_energy", "Fire Energy");
        name("fire_blast", "Fire Blast");
        name("diamond_claws_extension", "Extend Diamond Claws");
        name("scale", "Scale");
        name("sound_wave_attack", "Sound Wave Attack");
        name("spray_water", "Spray Water");
        name("egg_shell", "Eggshell");
        name("nailong_belial", "Nailong Belial");
        // пассивные — только название (в слот не ставятся)
        passive("flesh_regen", "Regeneration");
        passive("flesh_strength", "Flesh Strength");
        passive("flight", "Flight");
        passive("wings", "Wings");
        passive("super_vision", "Super Vision");
        passive("super_speed", "Super Speed");
        passive("fire", "Fire");
        passive("sound_wave", "Sound Wave");
        passive("water_dispenser", "Water Dispenser");
        passive("chicken_egg_head", "Chicken Egg Head");
        passive("toad", "Toad");
        passive("diamond_claws", "Diamond Claws");
        passive("size", "Size");
    }

    private VAbilities() {}

    private static void name(String path, String english) {
        String id = "theboysmod:" + path;
        String slot = PREFIX + english;
        NAMES.put(id, slot);
        BY_SLOT.put(slot, id);
        ENGLISH.put(id, english);
    }

    private static void passive(String path, String english) {
        ENGLISH.put("theboysmod:" + path, english);
    }

    /** Английское название (en_us The Boys) — для строк, которые сервер пишет игроку как есть. */
    public static String english(String skillId) {
        return ENGLISH.getOrDefault(skillId, skillId);
    }

    /** Строка слота для навыка (null — навык в слот не ставится). */
    @Nullable
    public static String slotName(String skillId) {
        return NAMES.get(skillId);
    }

    /** Навык V по строке слота (null — в слоте не навык V). */
    @Nullable
    public static String skillId(@Nullable String slotName) {
        return slotName == null ? null : BY_SLOT.get(slotName);
    }

    /** Навык ставится в слот: есть действие и известно имя. */
    public static boolean assignable(Skill skill) {
        return skill.getType() != SkillType.PASSIVE && NAMES.containsKey(skill.getId().toString());
    }
}
