package com.invfix.vpower.skill.skills;

import com.invfix.vpower.skill.base.Skill;
import com.invfix.vpower.skill.base.SkillType;
import net.minecraft.resources.ResourceLocation;

public class EggShellSkill extends Skill {
   public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "egg_shell");

   @Override
   public ResourceLocation getId() {
      return ID;
   }

   @Override
   public SkillType getType() {
      return SkillType.TOGGLE;
   }

   @Override
   public boolean requiresMastery() {
      return false;
   }

   @Override
   public ResourceLocation getIcon() {
      return ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/custom/fashionegg/fashionegg.png");
   }
}
