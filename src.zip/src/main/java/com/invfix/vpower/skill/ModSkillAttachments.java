package com.invfix.vpower.skill;

import java.util.function.Supplier;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

public class ModSkillAttachments {
   public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS = DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, "theboysmod");
   public static final Supplier<AttachmentType<SkillData>> SKILL_DATA = ATTACHMENTS.register(
      "skill_data", () -> AttachmentType.serializable(SkillData::new).build()
   );
   public static final Supplier<AttachmentType<SkillEnergyData>> SKILL_ENERGY = ATTACHMENTS.register(
      "skill_energy", () -> AttachmentType.serializable(SkillEnergyData::new).build()
   );
}
