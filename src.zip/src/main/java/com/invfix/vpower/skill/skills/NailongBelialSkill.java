package com.invfix.vpower.skill.skills;

import com.invfix.vpower.registry.ModSounds;
import com.invfix.vpower.skill.base.Skill;
import com.invfix.vpower.skill.base.SkillType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;

public class NailongBelialSkill extends Skill {
   public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "nailong_belial");

   @Override
   public ResourceLocation getId() {
      return ID;
   }

   @Override
   public SkillType getType() {
      return SkillType.TOGGLE;
   }

   @Override
   public boolean requiresMastery() {
      return false;
   }

   @Override
   public void trigger(LivingEntity owner) {
      if (owner != null && !owner.level().isClientSide) {
         owner.level()
            .playSound(null, owner.getX(), owner.getY(), owner.getZ(), (SoundEvent)ModSounds.NAILONG_BELIAL_TRANSFORM.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
      }
   }

   @Override
   public ResourceLocation getIcon() {
      return ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/transform/nailong_belial/long_belial.png");
   }
}
