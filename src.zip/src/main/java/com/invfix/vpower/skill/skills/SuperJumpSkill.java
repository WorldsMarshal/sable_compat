package com.invfix.vpower.skill.skills;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.client.animation.ModAnimations;
import com.invfix.vpower.network.PlayerAnimationPlaySyncPacket;
import com.invfix.vpower.network.PlayerAnimationStopSyncPacket;
import com.invfix.vpower.network.SkillActiveSyncPacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.base.Skill;
import com.invfix.vpower.skill.base.SkillType;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

public class SuperJumpSkill extends Skill {
   public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "super_jump");
   private static final int START_ANIMATION_TICKS = 5;
   private static final int MAX_CHARGE_TICKS = 60;
   private static final int RELEASE_ANIMATION_TICKS = 40;
   private static final int FALL_PROTECTION_TICKS = 220;
   private static final double MAX_VERTICAL_VELOCITY = 4.4;
   private static final double MAX_HORIZONTAL_VELOCITY = 8.5;
   private static final double CHARGE_MOVEMENT_SLOWDOWN = -0.65;
   private static final ResourceLocation CHARGE_SLOWDOWN_MODIFIER_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "super_jump_charge_slowdown");
   private static final Map<UUID, Integer> ACTIVE_TICKS = new ConcurrentHashMap<>();
   private static final Map<UUID, Integer> RELEASE_ANIMATION = new ConcurrentHashMap<>();
   private static final Map<UUID, SuperJumpSkill.FallProtectionState> FALL_PROTECTION = new ConcurrentHashMap<>();

   @Override
   public ResourceLocation getId() {
      return ID;
   }

   @Override
   public SkillType getType() {
      return SkillType.CHANNELED;
   }

   @Override
   public boolean requiresMastery() {
      return false;
   }

   public static void serverTick(ServerLevel level) {
      for (ServerPlayer player : level.players()) {
         try {
            tickPlayer(player, level);
         } catch (Exception var4) {
         }
      }
   }

   private static void tickPlayer(ServerPlayer player, ServerLevel level) {
      UUID playerId = player.getUUID();
      tickReleaseAnimation(player, playerId);
      tickFallProtection(player, playerId);
      SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
      boolean active = player.isAlive() && data.hasSkill(ID.toString()) && data.isSkillActive(ID.toString());
      applyChargeSlowdown(player, active);
      if (!active) {
         stopChargingIfNeeded(player, playerId, level, data);
      } else {
         RELEASE_ANIMATION.remove(playerId);
         int activeTicks = ACTIVE_TICKS.getOrDefault(playerId, -1);
         if (activeTicks < 0) {
            if (!player.onGround() || player.isSpectator()) {
               forceDeactivate(player, data);
               return;
            }

            activeTicks = 0;
            broadcastAnimation(player, ModAnimations.SUPER_JUMP_START, false, 2);
         }

         if (activeTicks == 5) {
            broadcastAnimation(player, ModAnimations.SUPER_JUMP_ON, true, 2);
         }

         ACTIVE_TICKS.put(playerId, activeTicks + 1);
      }
   }

   private static void stopChargingIfNeeded(ServerPlayer player, UUID playerId, ServerLevel level, SkillData data) {
      Integer previousTicks = ACTIVE_TICKS.remove(playerId);
      if (previousTicks != null) {
         broadcastAnimation(player, ModAnimations.SUPER_JUMP_UP, true, 2);
         RELEASE_ANIMATION.put(playerId, 40);
         if (player.isAlive() && previousTicks > 0) {
            launchPlayer(player, level, data, previousTicks);
         }
      }
   }

   private static void launchPlayer(ServerPlayer player, ServerLevel level, SkillData data, int chargeTicks) {
      StompSkill.releaseRingShockwaveSilently(player, level);
      Vec3 launchVelocity = computeLaunchVelocity(player, data, chargeTicks);
      player.setDeltaMovement(launchVelocity);
      player.hasImpulse = true;
      player.hurtMarked = true;
      player.connection.send(new ClientboundSetEntityMotionPacket(player));
      player.fallDistance = 0.0F;
      UUID playerId = player.getUUID();
      FALL_PROTECTION.put(playerId, new SuperJumpSkill.FallProtectionState(220, false));
      float progress = getChargeProgress(chargeTicks);
      if (!player.isCreative() && !player.isSpectator()) {
         player.getFoodData().addExhaustion(0.45F + progress * 0.75F);
      }

      level.playSound(
         null,
         player.getX(),
         player.getY(),
         player.getZ(),
         SoundEvents.GENERIC_EXPLODE,
         SoundSource.PLAYERS,
         0.35F + progress * 0.35F,
         1.35F + progress * 0.25F
      );
   }

   private static Vec3 computeLaunchVelocity(ServerPlayer player, SkillData data, int chargeTicks) {
      int level = Mth.clamp(data.getSuperStrengthLevel(), 1, 5);
      double levelProgress = (double)(level - 1) / 4.0;
      double chargeFactor = 0.35 + 0.65 * (double)getChargeProgress(chargeTicks);
      double skillAdjustment = Mth.clamp((double)data.getDamageMultiplier(ID.toString()) / 100.0, 0.0, 1.0);
      double meleeAdjustment = Mth.clamp((double)data.getMeleeDamageMultiplier() / 100.0, 0.0, 1.0);
      double powerFactor = 0.75 + skillAdjustment * 0.35 + meleeAdjustment * 0.35;
      Vec3 look = player.getLookAngle().normalize();
      Vec3 horizontalDirection = new Vec3(look.x, 0.0, look.z);
      double horizontalAim = horizontalDirection.length();
      if (horizontalAim < 1.0E-4) {
         horizontalDirection = forwardFromYaw(player);
      } else {
         horizontalDirection = horizontalDirection.scale(1.0 / horizontalAim);
      }

      double aimUp = Mth.clamp((look.y + 0.2) / 1.2, 0.0, 1.0);
      double horizontalAimFactor = Mth.clamp(horizontalAim + 0.2, 0.35, 1.0);
      double verticalVelocity = Mth.lerp(levelProgress, 1.2, 2.85) * chargeFactor * powerFactor * (0.85 + aimUp * 0.28);
      double horizontalVelocity = Mth.lerp(levelProgress, 2.25, 5.25) * chargeFactor * powerFactor * horizontalAimFactor;
      verticalVelocity = Mth.clamp(verticalVelocity, 0.35, 4.4);
      horizontalVelocity = Mth.clamp(horizontalVelocity, 0.25, 8.5);
      Vec3 current = player.getDeltaMovement();
      return new Vec3(
         horizontalDirection.x * horizontalVelocity + current.x * 0.15,
         Math.max(current.y, verticalVelocity),
         horizontalDirection.z * horizontalVelocity + current.z * 0.15
      );
   }

   private static Vec3 forwardFromYaw(ServerPlayer player) {
      float radians = player.getYRot() * (float) (Math.PI / 180.0);
      return new Vec3((double)(-Mth.sin(radians)), 0.0, (double)Mth.cos(radians)).normalize();
   }

   private static float getChargeProgress(int activeTicks) {
      return Mth.clamp((float)activeTicks / 60.0F, 0.0F, 1.0F);
   }

   private static void tickReleaseAnimation(ServerPlayer player, UUID playerId) {
      Integer ticksLeft = RELEASE_ANIMATION.get(playerId);
      if (ticksLeft != null) {
         if (ticksLeft > 0 && player.isAlive()) {
            RELEASE_ANIMATION.put(playerId, ticksLeft - 1);
         } else {
            RELEASE_ANIMATION.remove(playerId);
            PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new PlayerAnimationStopSyncPacket(player.getId(), 2), new CustomPacketPayload[0]);
         }
      }
   }

   private static void tickFallProtection(ServerPlayer player, UUID playerId) {
      SuperJumpSkill.FallProtectionState state = FALL_PROTECTION.get(playerId);
      if (state != null) {
         player.fallDistance = 0.0F;
         if (player.isAlive() && state.ticksLeft() > 0) {
            boolean leftGround = state.leftGround() || !player.onGround();
            if (leftGround && player.onGround()) {
               FALL_PROTECTION.remove(playerId);
            } else {
               FALL_PROTECTION.put(playerId, new SuperJumpSkill.FallProtectionState(state.ticksLeft() - 1, leftGround));
            }
         } else {
            FALL_PROTECTION.remove(playerId);
         }
      }
   }

   public static boolean cancelFallDamage(ServerPlayer player) {
      if (player != null && FALL_PROTECTION.containsKey(player.getUUID())) {
         player.fallDistance = 0.0F;
         FALL_PROTECTION.remove(player.getUUID());
         return true;
      } else {
         return false;
      }
   }

   private static void applyChargeSlowdown(ServerPlayer player, boolean active) {
      AttributeInstance movementSpeed = player.getAttribute(Attributes.MOVEMENT_SPEED);
      if (movementSpeed != null) {
         AttributeModifier existing = movementSpeed.getModifier(CHARGE_SLOWDOWN_MODIFIER_ID);
         if (active) {
            if (existing == null || Math.abs(existing.amount() - -0.65) > 1.0E-4) {
               movementSpeed.removeModifier(CHARGE_SLOWDOWN_MODIFIER_ID);
               movementSpeed.addTransientModifier(new AttributeModifier(CHARGE_SLOWDOWN_MODIFIER_ID, -0.65, Operation.ADD_MULTIPLIED_TOTAL));
            }
         } else if (existing != null) {
            movementSpeed.removeModifier(CHARGE_SLOWDOWN_MODIFIER_ID);
         }
      }
   }

   private static void forceDeactivate(ServerPlayer player, SkillData data) {
      if (data.isSkillActive(ID.toString())) {
         ACTIVE_TICKS.remove(player.getUUID());
         data.setSkillActive(ID.toString(), false);
         SkillActiveSyncPacket.syncToWrappers(player);
      }
   }

   private static void broadcastAnimation(ServerPlayer player, ResourceLocation animation, boolean loop, int fadeTicks) {
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(
         player, new PlayerAnimationPlaySyncPacket(player.getId(), animation, loop, fadeTicks, false), new CustomPacketPayload[0]
      );
   }

   private static record FallProtectionState(int ticksLeft, boolean leftGround) {
   }
}
