package com.invfix.vpower.skill.skills;

import java.util.Optional;
import com.invfix.vpower.util.VBlocks;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.base.Skill;
import com.invfix.vpower.skill.base.SkillType;
import com.invfix.vpower.util.IntangibilityUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public class FireBlastSkill extends Skill {
   public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "fire_blast");
   private static final float DAMAGE_PER_HIT = 7.0F;
   private static final float RANGE = 12.0F;
   private static final int FIRE_DURATION_SECONDS = 8;
   private static final float PROJECTILE_SPEED = 1.5F;

   @Override
   public ResourceLocation getId() {
      return ID;
   }

   @Override
   public SkillType getType() {
      return SkillType.CHANNELED;
   }

   @Override
   public boolean requiresMastery() {
      return false;
   }

   public static void serverTick(ServerLevel level) {
      String skillId = ID.toString();

      for (ServerPlayer player : level.players()) {
         try {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            if (data.hasSkill(skillId) && data.isSkillActive(skillId)) {
               tickPlayer(player, level);
            }
         } catch (Exception var5) {
         }
      }
   }

   private static void tickPlayer(ServerPlayer player, ServerLevel level) {
      Vec3 lookVec = player.getLookAngle();
      Vec3 eyePos = player.getEyePosition();
      Vec3 rayEnd = eyePos.add(lookVec.scale(12.0));
      HitResult blockHit = level.clip(new ClipContext(eyePos, rayEnd, Block.COLLIDER, Fluid.NONE, player));
      float effectiveRange = 12.0F;
      if (blockHit.getType() != Type.MISS) {
         effectiveRange = (float)Math.max(0.5, eyePos.distanceTo(blockHit.getLocation()));
      }

      spawnFlameStream(player, level, eyePos, lookVec, effectiveRange);
      if (player.tickCount % 10 == 0) {
         level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.FIRE_AMBIENT, SoundSource.PLAYERS, 1.0F, 1.0F);
      }

      if (player.tickCount % 3 == 0) {
         processEntities(player, level, eyePos, lookVec, effectiveRange);
      }

      if (!VBlocks.protectedLevel(level) && blockHit.getType() == Type.BLOCK && player.tickCount % 5 == 0) {
         BlockHitResult bhr = (BlockHitResult)blockHit;
         BlockPos hitBlockPos = bhr.getBlockPos();
         BlockPos firePos = hitBlockPos.relative(bhr.getDirection());
         BlockState hitState = level.getBlockState(hitBlockPos);
         net.minecraft.world.level.block.Block hitBlock = hitState.getBlock();
         transformBlock(level, hitBlockPos, hitBlock);
         if (hitBlock == Blocks.TNT) {
            level.setBlockAndUpdate(hitBlockPos, Blocks.AIR.defaultBlockState());
            PrimedTnt tnt = new PrimedTnt(level, (double)hitBlockPos.getX() + 0.5, (double)hitBlockPos.getY(), (double)hitBlockPos.getZ() + 0.5, player);
            level.addFreshEntity(tnt);
         }

         if (level.isEmptyBlock(firePos)) {
            level.setBlockAndUpdate(firePos, Blocks.FIRE.defaultBlockState());
         }

         Vec3 hitLoc = blockHit.getLocation();
         level.sendParticles(ParticleTypes.LAVA, hitLoc.x, hitLoc.y, hitLoc.z, 3, 0.3, 0.3, 0.3, 0.02);
      }
   }

   private static void spawnFlameStream(ServerPlayer player, ServerLevel level, Vec3 origin, Vec3 direction, float effectiveRange) {
      Vec3 rightOffset = new Vec3(-direction.z, 0.0, direction.x).normalize().scale(0.4);
      Vec3 start = origin.add(rightOffset).add(direction.scale(0.3)).subtract(0.0, 0.2, 0.0);
      int clusterCount = Math.max(1, (int)(effectiveRange / 1.5F));

      for (int i = 0; i < clusterCount; i++) {
         float dist = 1.5F * ((float)i + 0.5F);
         if (dist > effectiveRange) {
            break;
         }

         Vec3 pos = start.add(direction.scale((double)dist));
         float spreadFactor = 0.15F + dist / effectiveRange * 0.1F;
         level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 8, (double)spreadFactor, (double)spreadFactor, (double)spreadFactor, 0.02);
         if (i % 2 == 0) {
            level.sendParticles(
               ParticleTypes.SMOKE, pos.x, pos.y, pos.z, 1, (double)spreadFactor * 1.2, (double)spreadFactor * 1.2, (double)spreadFactor * 1.2, 0.01
            );
         }
      }
   }

   private static void processEntities(ServerPlayer owner, ServerLevel level, Vec3 origin, Vec3 direction, float effectiveRange) {
      Vec3 rayEnd = origin.add(direction.scale((double)effectiveRange));
      SkillData skillData = (SkillData)owner.getData(ModSkillAttachments.SKILL_DATA.get());
      float multiplier = (float)skillData.getDamageMultiplier(ID.toString()) / 100.0F;
      float finalDamage = 7.0F * multiplier;
      double expand = 1.0;
      AABB rayBox = new AABB(
         Math.min(origin.x, rayEnd.x) - expand,
         Math.min(origin.y, rayEnd.y) - expand,
         Math.min(origin.z, rayEnd.z) - expand,
         Math.max(origin.x, rayEnd.x) + expand,
         Math.max(origin.y, rayEnd.y) + expand,
         Math.max(origin.z, rayEnd.z) + expand
      );

      for (Entity entity : level.getEntities(
         owner, rayBox, e -> (e instanceof LivingEntity || e instanceof PrimedTnt) && !e.isSpectator() && !IntangibilityUtil.isIntangible(e)
      )) {
         Vec3 hitPos = rayIntersectsAABB(origin, rayEnd, entity.getBoundingBox());
         if (hitPos != null) {
            if (entity instanceof Creeper creeper) {
               creeper.ignite();
               creeper.setRemainingFireTicks(160);
            } else if (entity instanceof PrimedTnt) {
               PrimedTnt tnt = (PrimedTnt)entity;
               if (tnt.getFuse() > 10) {
                  tnt.setFuse(10);
               }
            } else if (entity instanceof LivingEntity) {
               LivingEntity target = (LivingEntity)entity;
               if (target != owner && !IntangibilityUtil.isIntangible(target)) {
                  target.invulnerableTime = 0;
                  target.hurtTime = 0;
                  target.hurt(level.damageSources().onFire(), finalDamage);
                  target.setRemainingFireTicks(160);
                  Vec3 knockback = direction.scale(0.15);
                  target.push(knockback.x, knockback.y * 0.3, knockback.z);
               }
            }
         }
      }
   }

   private static Vec3 rayIntersectsAABB(Vec3 start, Vec3 end, AABB box) {
      Optional<Vec3> clip = box.clip(start, end);
      if (clip.isPresent()) {
         return clip.get();
      } else {
         return box.contains(start) ? start : null;
      }
   }

   private static void transformBlock(ServerLevel level, BlockPos pos, net.minecraft.world.level.block.Block block) {
      if (!VBlocks.protectedLevel(level)) {
         if (block == Blocks.ICE || block == Blocks.PACKED_ICE || block == Blocks.BLUE_ICE) {
            level.setBlockAndUpdate(pos, Blocks.WATER.defaultBlockState());
         } else if (block == Blocks.SNOW || block == Blocks.SNOW_BLOCK || block == Blocks.POWDER_SNOW) {
            level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
         } else if (block == Blocks.FROSTED_ICE) {
            level.setBlockAndUpdate(pos, Blocks.WATER.defaultBlockState());
         } else if (block == Blocks.COBBLESTONE) {
            level.setBlockAndUpdate(pos, Blocks.SMOOTH_STONE.defaultBlockState());
         } else if (block == Blocks.SAND) {
            level.setBlockAndUpdate(pos, Blocks.GLASS.defaultBlockState());
         } else if (block == Blocks.RED_SAND) {
            level.setBlockAndUpdate(pos, Blocks.GLASS.defaultBlockState());
         } else if (block == Blocks.CLAY) {
            level.setBlockAndUpdate(pos, Blocks.TERRACOTTA.defaultBlockState());
         } else if (block == Blocks.WET_SPONGE) {
            level.setBlockAndUpdate(pos, Blocks.SPONGE.defaultBlockState());
         } else if (block == Blocks.STONE_BRICKS) {
            level.setBlockAndUpdate(pos, Blocks.CRACKED_STONE_BRICKS.defaultBlockState());
         } else if (block == Blocks.COBBLED_DEEPSLATE) {
            level.setBlockAndUpdate(pos, Blocks.DEEPSLATE.defaultBlockState());
         } else if (block == Blocks.NETHER_BRICKS) {
            level.setBlockAndUpdate(pos, Blocks.CRACKED_NETHER_BRICKS.defaultBlockState());
         } else {
            if (block == Blocks.WATER) {
               level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
            }
         }
      }
   }
}
