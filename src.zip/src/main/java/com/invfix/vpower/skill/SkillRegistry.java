package com.invfix.vpower.skill;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import com.invfix.vpower.skill.base.Skill;
import net.minecraft.resources.ResourceLocation;

public class SkillRegistry {
   private static final Map<ResourceLocation, Skill> SKILLS = new LinkedHashMap<>();

   public static <T extends Skill> T register(T skill) {
      ResourceLocation id = skill.getId();
      SKILLS.put(id, skill);
      return skill;
   }

   @Nullable
   public static Skill getSkill(ResourceLocation id) {
      return SKILLS.get(id);
   }

   @Nullable
   public static Skill getSkill(String id) {
      try {
         ResourceLocation loc = ResourceLocation.parse(id);
         Skill skill = SKILLS.get(loc);
         if (skill != null) {
            return skill;
         } else if (loc.getNamespace().equals("minecraft")) {
            ResourceLocation modLoc = ResourceLocation.fromNamespaceAndPath("theboysmod", loc.getPath());
            return SKILLS.get(modLoc);
         } else {
            return null;
         }
      } catch (Exception var4) {
         return null;
      }
   }

   @Nullable
   public static ResourceLocation getKey(Skill skill) {
      return skill != null ? skill.getId() : null;
   }

   public static Collection<Skill> getAllSkills() {
      return Collections.unmodifiableCollection(SKILLS.values());
   }

   public static Set<ResourceLocation> getAllIds() {
      return Collections.unmodifiableSet(SKILLS.keySet());
   }

   public static boolean isRegistered(ResourceLocation id) {
      return SKILLS.containsKey(id);
   }

   public static int getSkillCount() {
      return SKILLS.size();
   }
}
