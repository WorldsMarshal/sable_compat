package com.invfix.vpower.skill.skills;

import com.invfix.vpower.skill.base.Skill;
import com.invfix.vpower.skill.base.SkillType;
import net.minecraft.resources.ResourceLocation;

public class DiamondClawsSkill extends Skill {
   public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "diamond_claws");

   @Override
   public ResourceLocation getId() {
      return ID;
   }

   @Override
   public SkillType getType() {
      return SkillType.PASSIVE;
   }

   @Override
   public boolean requiresMastery() {
      return false;
   }

   @Override
   public ResourceLocation getIcon() {
      return ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/models/claw/claw.png");
   }
}
