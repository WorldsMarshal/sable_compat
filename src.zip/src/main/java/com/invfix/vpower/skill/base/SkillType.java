package com.invfix.vpower.skill.base;

public enum SkillType {
   ACTIVE,
   TOGGLE,
   PASSIVE,
   CHANNELED;
}
