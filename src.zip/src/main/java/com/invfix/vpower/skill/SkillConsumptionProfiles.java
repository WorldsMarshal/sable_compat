package com.invfix.vpower.skill;

import java.util.Map;
import com.invfix.vpower.skill.skills.FireBlastSkill;
import com.invfix.vpower.skill.skills.FireEnergySkill;
import com.invfix.vpower.skill.skills.GrabSkill;
import com.invfix.vpower.skill.skills.LaserEyeSkill;
import com.invfix.vpower.skill.skills.SoundWaveAttackSkill;
import com.invfix.vpower.skill.skills.SpeedSkill;
import com.invfix.vpower.skill.skills.SprayWaterSkill;
import com.invfix.vpower.skill.skills.SuperJumpSkill;
import com.invfix.vpower.skill.skills.WingsSkill;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodData;

public final class SkillConsumptionProfiles {
   public static final SkillConsumptionProfiles.Profile LASER_EYE = new SkillConsumptionProfiles.Profile(2, 5, 1.0F);
   public static final SkillConsumptionProfiles.Profile FIRE_BLAST = new SkillConsumptionProfiles.Profile(2, 10, 0.5F);
   public static final SkillConsumptionProfiles.Profile SOUND_WAVE_ATTACK = new SkillConsumptionProfiles.Profile(2, 10, 0.45F);
   public static final SkillConsumptionProfiles.Profile SUPER_JUMP = new SkillConsumptionProfiles.Profile(2, 10, 0.25F);
   public static final SkillConsumptionProfiles.Profile SPRAY_WATER = new SkillConsumptionProfiles.Profile(1, 10, 0.25F);
   public static final SkillConsumptionProfiles.Profile FIRE_ENERGY = new SkillConsumptionProfiles.Profile(3, 20, 0.3F);
   public static final SkillConsumptionProfiles.Profile GRAB = new SkillConsumptionProfiles.Profile(3, 10, 0.4F);
   public static final SkillConsumptionProfiles.Profile SPEED = new SkillConsumptionProfiles.Profile(3, 10, 0.35F);
   public static final SkillConsumptionProfiles.Profile WINGS = new SkillConsumptionProfiles.Profile(6, 20, 0.03F);
   private static final Map<String, SkillConsumptionProfiles.Profile> PROFILES = Map.of(
      LaserEyeSkill.ID.toString(),
      LASER_EYE,
      FireBlastSkill.ID.toString(),
      FIRE_BLAST,
      SoundWaveAttackSkill.ID.toString(),
      SOUND_WAVE_ATTACK,
      SuperJumpSkill.ID.toString(),
      SUPER_JUMP,
      SprayWaterSkill.ID.toString(),
      SPRAY_WATER,
      FireEnergySkill.ID.toString(),
      FIRE_ENERGY,
      GrabSkill.ID.toString(),
      GRAB,
      SpeedSkill.ID.toString(),
      SPEED,
      WingsSkill.ID.toString(),
      WINGS
   );

   private SkillConsumptionProfiles() {
   }

   public static SkillConsumptionProfiles.Profile get(String skillId) {
      return PROFILES.get(skillId);
   }

   public static double getExhaustionPerSecond(SkillConsumptionProfiles.Profile profile) {
      return profile == null ? 0.0 : (double)profile.exhaustionPerInterval() * 20.0 / (double)profile.intervalTicks();
   }

   public static double getSecondsPerFoodPoint(SkillConsumptionProfiles.Profile profile) {
      double exhaustionPerSecond = getExhaustionPerSecond(profile);
      return exhaustionPerSecond <= 1.0E-6 ? Double.POSITIVE_INFINITY : 4.0 / exhaustionPerSecond;
   }

   public static boolean canCurrentlySustain(Player player, SkillConsumptionProfiles.Profile profile) {
      return player != null && profile != null && player.getFoodData().getFoodLevel() > profile.minFoodLevel();
   }

   public static double estimateContinuousUseSeconds(Player player, SkillConsumptionProfiles.Profile profile) {
      if (player == null || profile == null) {
         return Double.NaN;
      } else if (!player.isCreative() && !player.isSpectator()) {
         FoodData foodData = player.getFoodData();
         double foodBudget = (double)Math.max(0, foodData.getFoodLevel() - profile.minFoodLevel());
         double saturationBudget = (double)Math.max(0.0F, foodData.getSaturationLevel());
         double exhaustionBudget = (foodBudget + saturationBudget) * 4.0;
         double exhaustionPerSecond = getExhaustionPerSecond(profile);
         return exhaustionPerSecond <= 1.0E-6 ? Double.POSITIVE_INFINITY : exhaustionBudget / exhaustionPerSecond;
      } else {
         return Double.POSITIVE_INFINITY;
      }
   }

   public static record Profile(int minFoodLevel, int intervalTicks, float exhaustionPerInterval) {
      public Profile(int minFoodLevel, int intervalTicks, float exhaustionPerInterval) {
         minFoodLevel = Math.max(0, minFoodLevel);
         intervalTicks = Math.max(1, intervalTicks);
         exhaustionPerInterval = Math.max(0.0F, exhaustionPerInterval);
         this.minFoodLevel = minFoodLevel;
         this.intervalTicks = intervalTicks;
         this.exhaustionPerInterval = exhaustionPerInterval;
      }
   }
}
