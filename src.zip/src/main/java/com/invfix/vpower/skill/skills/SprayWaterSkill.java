package com.invfix.vpower.skill.skills;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.entity.projectile.WaterSprayEntity;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.base.Skill;
import com.invfix.vpower.skill.base.SkillType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

public class SprayWaterSkill extends Skill {
   public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "spray_water");
   private static final Map<UUID, Integer> ACTIVE_LEFT_STREAMS = new ConcurrentHashMap<>();
   private static final Map<UUID, Integer> ACTIVE_RIGHT_STREAMS = new ConcurrentHashMap<>();

   @Override
   public ResourceLocation getId() {
      return ID;
   }

   @Override
   public SkillType getType() {
      return SkillType.CHANNELED;
   }

   @Override
   public boolean requiresMastery() {
      return false;
   }

   public static void serverTick(ServerLevel level) {
      for (ServerPlayer player : level.players()) {
         try {
            tickPlayer(level, player);
         } catch (Exception var4) {
         }
      }
   }

   private static void tickPlayer(ServerLevel level, ServerPlayer player) {
      UUID playerId = player.getUUID();
      SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
      boolean active = player.isAlive() && data.hasSkill(ID.toString()) && data.isSkillActive(ID.toString());
      if (!active) {
         discardStream(level, playerId, ACTIVE_LEFT_STREAMS);
         discardStream(level, playerId, ACTIVE_RIGHT_STREAMS);
      } else {
         tickStream(level, player, playerId, -1, ACTIVE_LEFT_STREAMS);
         tickStream(level, player, playerId, 1, ACTIVE_RIGHT_STREAMS);
      }
   }

   private static void tickStream(ServerLevel level, ServerPlayer player, UUID playerId, int side, Map<UUID, Integer> activeStreams) {
      if (getStream(level, playerId, activeStreams) instanceof WaterSprayEntity spray && !spray.isRemoved()) {
         spray.setOwner(player);
         spray.setStreamSide(side);
         spray.syncFromOwner();
         return;
      }

      WaterSprayEntity spray = new WaterSprayEntity(level, player, side);
      spray.syncFromOwner();
      if (level.addFreshEntity(spray)) {
         activeStreams.put(playerId, spray.getId());
      }
   }

   private static Entity getStream(ServerLevel level, UUID playerId, Map<UUID, Integer> activeStreams) {
      Integer entityId = activeStreams.get(playerId);
      return entityId == null ? null : level.getEntity(entityId);
   }

   private static void discardStream(ServerLevel level, UUID playerId, Map<UUID, Integer> activeStreams) {
      Entity existing = getStream(level, playerId, activeStreams);
      if (existing != null && !existing.isRemoved()) {
         existing.discard();
      }

      activeStreams.remove(playerId);
   }
}
