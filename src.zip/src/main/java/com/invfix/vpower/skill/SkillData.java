package com.invfix.vpower.skill;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import com.invfix.vpower.skill.base.Skill;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.common.util.INBTSerializable;

public class SkillData implements INBTSerializable<CompoundTag> {
   public static final float MIN_PLAYER_SCALE = 0.1F;
   public static final float MAX_PLAYER_SCALE = 4.0F;
   public static final int TEMPORARY_V_DURATION_TICKS = 28800;
   public static final String FLESH_REGEN = "theboysmod:flesh_regen";
   public static final String FLIGHT = "theboysmod:flight";
   public static final String INTANGIBILITY = "theboysmod:intangibility";
   public static final String SPIRITUALIZATION = "theboysmod:spiritualization";
   public static final String INVISIBILITY = "theboysmod:invisibility";
   private final Set<String> skills = new HashSet<>();
   private final Set<String> temporarySkills = new HashSet<>();
   private long temporarySkillExpireGameTime = -1L;
   private int temporarySkillDurationTicks = 0;
   private String temporaryRootSkillId = "";
   private int temporaryPreviousFleshStrengthLevel = -1;
   private int temporaryPreviousSuperStrengthLevel = -1;
   private int temporaryVLoad = 0;
   private long temporaryVWithdrawalEndGameTime = -1L;
   private int temporaryVWithdrawalDurationTicks = 0;
   private long temporaryVLastLoadDecayGameTime = -1L;
   private boolean temporaryVOverloaded = false;
   private final Map<String, Boolean> activeStates = new HashMap<>();
   private final Map<String, Integer> damageMultipliers = new HashMap<>();
   private int meleeDamageMultiplier = 100;
   private int fleshStrengthLevel = 1;
   private float damageThreshold = 1.0F;
   private int fleshDamageReduction = 0;
   private float shieldHp = 50.0F;
   private float maxShieldHp = 50.0F;
   private long lastDamageTime = -1L;
   private int laserEyeLevel = 1;
   private float laserEyeBaseDamage = 1.0F;
   private int superStrengthLevel = 1;
   private float basePunchDamage = 5.0F;
   private int superSpeedLevel = 1;
   private float baseSpeedBoost = 0.03F;
   private int speedAdjustment = 50;
   private float targetScale = 1.0F;
   private int fireTimer = -1;
   private int vibrateTimer = 0;
   private int prevVibrateTimer = 0;

   public boolean hasSkill(String skillId) {
      return this.skills.contains(skillId);
   }

   public boolean hasSkill(ResourceLocation skillId) {
      return skillId != null && this.skills.contains(skillId.toString());
   }

   public void addSkill(String skillId) {
      if (skillId != null && !skillId.isBlank()) {
         if (!this.skills.contains(skillId)) {
            this.skills.add(skillId);
         } else if (this.temporarySkills.remove(skillId) && this.temporarySkills.isEmpty()) {
            this.clearTemporaryMetadata();
         }

         Skill skill = SkillRegistry.getSkill(skillId);
         if (skill != null) {
            if (skill.getParent() != null) {
               String parentId = skill.getParent().getId().toString();
               if (!this.skills.contains(parentId)) {
                  this.addSkill(parentId);
               }
            }

            for (Skill child : skill.getChildren()) {
               String childId = child.getId().toString();
               if (!this.skills.contains(childId)) {
                  this.addSkill(childId);
               }
            }
         }
      }
   }

   public void addSkillDirect(String skillId) {
      this.skills.add(skillId);
   }

   public boolean ensureChildSkills() {
      Set<String> toAdd = new HashSet<>();
      Set<String> temporaryToAdd = new HashSet<>();

      for (String skillId : new HashSet<>(this.skills)) {
         Skill skill = SkillRegistry.getSkill(skillId);
         if (skill != null) {
            for (Skill child : skill.getChildren()) {
               String childId = child.getId().toString();
               if (!this.skills.contains(childId)) {
                  toAdd.add(childId);
                  if (this.temporarySkills.contains(skillId)) {
                     temporaryToAdd.add(childId);
                  }
               }
            }
         }
      }

      if (toAdd.isEmpty()) {
         return false;
      } else {
         for (String skillIdx : toAdd) {
            this.addSkill(skillIdx);
         }

         this.temporarySkills.addAll(temporaryToAdd);
         return true;
      }
   }

   public void removeSkill(String skillId) {
      this.skills.remove(skillId);
      this.activeStates.remove(skillId);
      this.temporarySkills.remove(skillId);
      if (this.temporarySkills.isEmpty()) {
         this.clearTemporaryMetadata();
      }
   }

   public Set<String> getAllSkills() {
      return Collections.unmodifiableSet(this.skills);
   }

   public boolean isTemporarySkill(String skillId) {
      return skillId != null && this.temporarySkills.contains(skillId);
   }

   public Set<String> getTemporarySkills() {
      return Collections.unmodifiableSet(this.temporarySkills);
   }

   public boolean hasTemporarySkills() {
      return !this.temporarySkills.isEmpty() && this.temporarySkillExpireGameTime > 0L;
   }

   public String getTemporaryRootSkillId() {
      return this.temporaryRootSkillId;
   }

   public int getTemporarySkillDurationTicks() {
      return this.temporarySkillDurationTicks;
   }

   public int getTemporarySkillRemainingTicks(long gameTime) {
      if (!this.hasTemporarySkills()) {
         return 0;
      } else {
         long remaining = this.temporarySkillExpireGameTime - gameTime;
         return remaining <= 0L ? 0 : (int)Math.min(2147483647L, remaining);
      }
   }

   public boolean setTemporarySkillRemainingTicks(long gameTime, int remainingTicks) {
      if (!this.hasTemporarySkills()) {
         return false;
      } else {
         int clampedTicks = Math.max(1, remainingTicks);
         this.temporarySkillExpireGameTime = gameTime + (long)clampedTicks;
         this.temporarySkillDurationTicks = clampedTicks;
         return true;
      }
   }

   public void beginTemporarySkills(
      String rootSkillId, Set<String> skillIds, long expireGameTime, int durationTicks, int previousFleshStrengthLevel, int previousSuperStrengthLevel
   ) {
      this.temporarySkills.clear();
      if (skillIds != null) {
         for (String skillId : skillIds) {
            if (skillId != null && !skillId.isBlank()) {
               this.temporarySkills.add(skillId);
            }
         }
      }

      if (this.temporarySkills.isEmpty()) {
         this.clearTemporaryMetadata();
      } else {
         this.temporaryRootSkillId = rootSkillId == null ? "" : rootSkillId;
         this.temporarySkillExpireGameTime = expireGameTime;
         this.temporarySkillDurationTicks = Math.max(1, durationTicks);
         this.temporaryPreviousFleshStrengthLevel = Math.max(1, previousFleshStrengthLevel);
         this.temporaryPreviousSuperStrengthLevel = Math.max(1, previousSuperStrengthLevel);
      }
   }

   public Set<String> clearTemporarySkills() {
      Set<String> removed = new HashSet<>(this.temporarySkills);

      for (String skillId : removed) {
         this.skills.remove(skillId);
         this.activeStates.remove(skillId);
      }

      if (this.temporaryPreviousFleshStrengthLevel > 0) {
         this.setFleshStrengthLevel(this.temporaryPreviousFleshStrengthLevel);
      }

      if (this.temporaryPreviousSuperStrengthLevel > 0) {
         this.setSuperStrengthLevel(this.temporaryPreviousSuperStrengthLevel);
      }

      this.temporarySkills.clear();
      this.clearTemporaryMetadata();
      return removed;
   }

   public boolean expireTemporarySkills(long gameTime) {
      return this.hasTemporarySkills() && gameTime >= this.temporarySkillExpireGameTime ? !this.clearTemporarySkills().isEmpty() : false;
   }

   public int getTemporaryVLoad() {
      return this.temporaryVLoad;
   }

   public void setTemporaryVLoad(int load) {
      this.temporaryVLoad = this.clampTemporaryVLoad(load);
   }

   public int addTemporaryVLoad(int amount) {
      this.temporaryVLoad = this.clampTemporaryVLoad(this.temporaryVLoad + amount);
      return this.temporaryVLoad;
   }

   public boolean hasTemporaryVWithdrawal() {
      return this.temporaryVWithdrawalEndGameTime > 0L;
   }

   public boolean isTemporaryVWithdrawalActive(long gameTime) {
      return this.temporaryVWithdrawalEndGameTime > gameTime;
   }

   public int getTemporaryVWithdrawalRemainingTicks(long gameTime) {
      if (!this.hasTemporaryVWithdrawal()) {
         return 0;
      } else {
         long remaining = this.temporaryVWithdrawalEndGameTime - gameTime;
         return remaining <= 0L ? 0 : (int)Math.min(2147483647L, remaining);
      }
   }

   public int getTemporaryVWithdrawalDurationTicks() {
      return this.temporaryVWithdrawalDurationTicks;
   }

   public void beginTemporaryVWithdrawal(long gameTime, int durationTicks) {
      this.temporaryVWithdrawalDurationTicks = Math.max(1, durationTicks);
      this.temporaryVWithdrawalEndGameTime = gameTime + (long)this.temporaryVWithdrawalDurationTicks;
   }

   public void clearTemporaryVWithdrawal() {
      this.temporaryVWithdrawalEndGameTime = -1L;
      this.temporaryVWithdrawalDurationTicks = 0;
   }

   public long getTemporaryVLastLoadDecayGameTime() {
      return this.temporaryVLastLoadDecayGameTime;
   }

   public void setTemporaryVLastLoadDecayGameTime(long gameTime) {
      this.temporaryVLastLoadDecayGameTime = gameTime;
   }

   public boolean isTemporaryVOverloaded() {
      return this.temporaryVOverloaded;
   }

   public void setTemporaryVOverloaded(boolean overloaded) {
      this.temporaryVOverloaded = overloaded;
   }

   public void clearTemporaryVSideEffects() {
      this.temporaryVLoad = 0;
      this.temporaryVWithdrawalEndGameTime = -1L;
      this.temporaryVWithdrawalDurationTicks = 0;
      this.temporaryVLastLoadDecayGameTime = -1L;
      this.temporaryVOverloaded = false;
   }

   public void clearSkills() {
      this.skills.clear();
      this.activeStates.clear();
      this.temporarySkills.clear();
      this.clearTemporaryMetadata();
      this.clearTemporaryVSideEffects();
   }

   private void clearTemporaryMetadata() {
      this.temporarySkillExpireGameTime = -1L;
      this.temporarySkillDurationTicks = 0;
      this.temporaryRootSkillId = "";
      this.temporaryPreviousFleshStrengthLevel = -1;
      this.temporaryPreviousSuperStrengthLevel = -1;
   }

   private int clampTemporaryVLoad(int load) {
      return Math.max(0, Math.min(150, load));
   }

   public boolean isSkillActive(String skillId) {
      return this.activeStates.getOrDefault(skillId, false);
   }

   public void setSkillActive(String skillId, boolean active) {
      this.activeStates.put(skillId, active);
   }

   public Map<String, Boolean> getActiveStates() {
      return new HashMap<>(this.activeStates);
   }

   public void setActiveStates(Map<String, Boolean> states) {
      this.activeStates.clear();
      this.activeStates.putAll(states);
   }

   public Set<String> getActiveSkills() {
      Set<String> activeSet = new HashSet<>();

      for (Entry<String, Boolean> entry : this.activeStates.entrySet()) {
         if (entry.getValue()) {
            activeSet.add(entry.getKey());
         }
      }

      return activeSet;
   }

   public int getDamageMultiplier(String skillId) {
      return this.damageMultipliers.getOrDefault(skillId, 100);
   }

   public void setDamageMultiplier(String skillId, int percentage) {
      this.damageMultipliers.put(skillId, Math.max(0, Math.min(200, percentage)));
   }

   public int getMeleeDamageMultiplier() {
      return this.meleeDamageMultiplier;
   }

   public void setMeleeDamageMultiplier(int percentage) {
      this.meleeDamageMultiplier = Math.max(0, Math.min(100, percentage));
   }

   public Map<String, Integer> getDamageMultipliers() {
      return new HashMap<>(this.damageMultipliers);
   }

   public void setDamageMultipliers(Map<String, Integer> multipliers) {
      this.damageMultipliers.clear();
      this.damageMultipliers.putAll(multipliers);
   }

   public float getDamageThreshold() {
      return this.damageThreshold;
   }

   public void setDamageThreshold(float v) {
      this.damageThreshold = Math.max(0.0F, v);
   }

   public int getFleshDamageReduction() {
      return this.fleshDamageReduction;
   }

   public void setFleshDamageReduction(int v) {
      this.fleshDamageReduction = Math.max(0, Math.min(100, v));
   }

   public float getShieldHp() {
      return this.shieldHp;
   }

   public void setShieldHp(float v) {
      this.shieldHp = Math.max(0.0F, Math.min(this.maxShieldHp, v));
   }

   public float getMaxShieldHp() {
      return this.maxShieldHp;
   }

   public void setMaxShieldHp(float v) {
      this.maxShieldHp = Math.max(0.0F, v);
      if (this.shieldHp > this.maxShieldHp) {
         this.shieldHp = this.maxShieldHp;
      }
   }

   public long getLastDamageTime() {
      return this.lastDamageTime;
   }

   public void setLastDamageTime(long t) {
      this.lastDamageTime = t;
   }

   public int getFleshStrengthLevel() {
      return this.fleshStrengthLevel;
   }

   public void setFleshStrengthLevel(int level) {
      this.fleshStrengthLevel = Math.max(1, Math.min(5, level));
      switch (this.fleshStrengthLevel) {
         case 1:
            this.damageThreshold = 1.0F;
            this.fleshDamageReduction = 0;
            this.maxShieldHp = 50.0F;
            break;
         case 2:
            this.damageThreshold = 3.0F;
            this.fleshDamageReduction = 0;
            this.maxShieldHp = 100.0F;
            break;
         case 3:
            this.damageThreshold = 6.0F;
            this.fleshDamageReduction = 0;
            this.maxShieldHp = 180.0F;
            break;
         case 4:
            this.damageThreshold = 10.0F;
            this.fleshDamageReduction = 0;
            this.maxShieldHp = 300.0F;
            break;
         case 5:
            this.damageThreshold = 18.0F;
            this.fleshDamageReduction = 0;
            this.maxShieldHp = 500.0F;
      }

      this.shieldHp = this.maxShieldHp;
   }

   public int getLaserEyeLevel() {
      return this.laserEyeLevel;
   }

   public float getLaserEyeBaseDamage() {
      return Math.min(this.laserEyeBaseDamage, 20.0F);
   }

   public void setLaserEyeLevel(int level) {
      this.laserEyeLevel = Math.max(1, Math.min(5, level));
      switch (this.laserEyeLevel) {
         case 1:
            this.laserEyeBaseDamage = 5.0F;
            break;
         case 2:
            this.laserEyeBaseDamage = 7.0F;
            break;
         case 3:
            this.laserEyeBaseDamage = 10.0F;
            break;
         case 4:
            this.laserEyeBaseDamage = 13.0F;
            break;
         case 5:
            this.laserEyeBaseDamage = 20.0F;
      }
   }

   public int getSuperStrengthLevel() {
      return this.superStrengthLevel;
   }

   public float getBasePunchDamage() {
      return this.basePunchDamage;
   }

   public void setSuperStrengthLevel(int level) {
      this.superStrengthLevel = Math.max(1, Math.min(5, level));
      switch (this.superStrengthLevel) {
         case 1:
            this.basePunchDamage = 5.0F;
            break;
         case 2:
            this.basePunchDamage = 10.0F;
            break;
         case 3:
            this.basePunchDamage = 20.0F;
            break;
         case 4:
            this.basePunchDamage = 35.0F;
            break;
         case 5:
            this.basePunchDamage = 60.0F;
      }
   }

   public int getSuperSpeedLevel() {
      return this.superSpeedLevel;
   }

   public float getBaseSpeedBoost() {
      return this.baseSpeedBoost;
   }

   public int getSpeedAdjustment() {
      return this.speedAdjustment;
   }

   public void setSpeedAdjustment(int value) {
      this.speedAdjustment = Math.max(0, Math.min(100, value));
   }

   public float getTargetScale() {
      return this.targetScale;
   }

   public void setTargetScale(float scale) {
      this.targetScale = clampPlayerScale(scale);
   }

   public static float clampPlayerScale(float scale) {
      return !Float.isNaN(scale) && !Float.isInfinite(scale) ? Math.max(0.1F, Math.min(4.0F, scale)) : 1.0F;
   }

   public float getEffectiveSpeedBoost() {
      return this.baseSpeedBoost * ((float)this.speedAdjustment / 100.0F);
   }

   public void setSuperSpeedLevel(int level) {
      this.superSpeedLevel = Math.max(1, Math.min(5, level));
      switch (this.superSpeedLevel) {
         case 1:
            this.baseSpeedBoost = 0.06F;
            break;
         case 2:
            this.baseSpeedBoost = 0.12F;
            break;
         case 3:
            this.baseSpeedBoost = 0.3F;
            break;
         case 4:
            this.baseSpeedBoost = 0.5F;
            break;
         case 5:
            this.baseSpeedBoost = 0.9F;
      }
   }

   public int getFireTimer() {
      return this.fireTimer;
   }

   public void setFireTimer(int value) {
      this.fireTimer = Math.max(-1, Math.min(17, value));
   }

   public void tickFireTimer(boolean fireEnergyActive) {
      if (fireEnergyActive) {
         if (this.fireTimer < 17) {
            this.fireTimer++;
         }
      } else if (this.fireTimer > -1) {
         this.fireTimer--;
      }
   }

   public int getVibrateTimer() {
      return this.vibrateTimer;
   }

   public int getPrevVibrateTimer() {
      return this.prevVibrateTimer;
   }

   public void setVibrateTimer(int value) {
      this.vibrateTimer = Math.max(0, Math.min(10, value));
   }

   public void tickVibrateTimer(boolean active) {
      this.prevVibrateTimer = this.vibrateTimer;
      if (active) {
         if (this.vibrateTimer < 10) {
            this.vibrateTimer++;
         }
      } else if (this.vibrateTimer > 0) {
         this.vibrateTimer--;
      }
   }

   public float applyFleshStrength(float rawDamage) {
      if (rawDamage <= this.damageThreshold) {
         return 0.0F;
      } else if (this.shieldHp <= 0.0F) {
         return rawDamage;
      } else if (rawDamage <= this.shieldHp) {
         this.shieldHp -= rawDamage;
         return 0.0F;
      } else {
         float penetrating = rawDamage - this.shieldHp;
         this.shieldHp = 0.0F;
         return penetrating;
      }
   }

   public boolean hasFleshRegen() {
      return this.hasSkill("theboysmod:flesh_regen");
   }

   public static boolean hasSkill(Player player, String skillId) {
      return ((SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get())).hasSkill(skillId);
   }

   public static void addSkill(Player player, String skillId) {
      ((SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get())).addSkill(skillId);
   }

   public static void removeSkill(Player player, String skillId) {
      ((SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get())).removeSkill(skillId);
   }

   public CompoundTag serializeNBT(Provider provider) {
      CompoundTag tag = new CompoundTag();
      ListTag skillList = new ListTag();

      for (String skill : this.skills) {
         skillList.add(StringTag.valueOf(skill));
      }

      tag.put("skills", skillList);
      ListTag temporarySkillList = new ListTag();

      for (String skill : this.temporarySkills) {
         temporarySkillList.add(StringTag.valueOf(skill));
      }

      tag.put("temporarySkills", temporarySkillList);
      tag.putLong("temporarySkillExpireGameTime", this.temporarySkillExpireGameTime);
      tag.putInt("temporarySkillDurationTicks", this.temporarySkillDurationTicks);
      tag.putString("temporaryRootSkillId", this.temporaryRootSkillId == null ? "" : this.temporaryRootSkillId);
      tag.putInt("temporaryPreviousFleshStrengthLevel", this.temporaryPreviousFleshStrengthLevel);
      tag.putInt("temporaryPreviousSuperStrengthLevel", this.temporaryPreviousSuperStrengthLevel);
      tag.putInt("temporaryVLoad", this.temporaryVLoad);
      tag.putLong("temporaryVWithdrawalEndGameTime", this.temporaryVWithdrawalEndGameTime);
      tag.putInt("temporaryVWithdrawalDurationTicks", this.temporaryVWithdrawalDurationTicks);
      tag.putLong("temporaryVLastLoadDecayGameTime", this.temporaryVLastLoadDecayGameTime);
      tag.putBoolean("temporaryVOverloaded", this.temporaryVOverloaded);
      CompoundTag activeTag = new CompoundTag();

      for (Entry<String, Boolean> entry : this.activeStates.entrySet()) {
         activeTag.putBoolean(entry.getKey(), entry.getValue());
      }

      tag.put("activeStates", activeTag);
      CompoundTag multiplierTag = new CompoundTag();

      for (Entry<String, Integer> entry : this.damageMultipliers.entrySet()) {
         multiplierTag.putInt(entry.getKey(), entry.getValue());
      }

      tag.put("damageMultipliers", multiplierTag);
      tag.putInt("meleeDamageMultiplier", this.meleeDamageMultiplier);
      tag.putFloat("damageThreshold", this.damageThreshold);
      tag.putInt("fleshDamageReduction", this.fleshDamageReduction);
      tag.putFloat("shieldHp", this.shieldHp);
      tag.putFloat("maxShieldHp", this.maxShieldHp);
      tag.putInt("fleshStrengthLevel", this.fleshStrengthLevel);
      tag.putLong("lastDamageTime", this.lastDamageTime);
      tag.putInt("laserEyeLevel", this.laserEyeLevel);
      tag.putFloat("laserEyeBaseDamage", this.laserEyeBaseDamage);
      tag.putInt("superStrengthLevel", this.superStrengthLevel);
      tag.putFloat("basePunchDamage", this.basePunchDamage);
      tag.putInt("superSpeedLevel", this.superSpeedLevel);
      tag.putFloat("baseSpeedBoost", this.baseSpeedBoost);
      tag.putInt("speedAdjustment", this.speedAdjustment);
      tag.putFloat("targetScale", this.targetScale);
      tag.putInt("fireTimer", this.fireTimer);
      tag.putInt("vibrateTimer", this.vibrateTimer);
      return tag;
   }

   public void deserializeNBT(Provider provider, CompoundTag tag) {
      this.skills.clear();
      if (tag.contains("skills", 9)) {
         ListTag skillList = tag.getList("skills", 8);

         for (int i = 0; i < skillList.size(); i++) {
            this.skills.add(skillList.getString(i));
         }
      }

      this.temporarySkills.clear();
      if (tag.contains("temporarySkills", 9)) {
         ListTag temporarySkillList = tag.getList("temporarySkills", 8);

         for (int i = 0; i < temporarySkillList.size(); i++) {
            String skillId = temporarySkillList.getString(i);
            if (this.skills.contains(skillId)) {
               this.temporarySkills.add(skillId);
            }
         }
      }

      this.temporarySkillExpireGameTime = tag.contains("temporarySkillExpireGameTime") ? tag.getLong("temporarySkillExpireGameTime") : -1L;
      this.temporarySkillDurationTicks = tag.contains("temporarySkillDurationTicks") ? tag.getInt("temporarySkillDurationTicks") : 0;
      this.temporaryRootSkillId = tag.contains("temporaryRootSkillId") ? tag.getString("temporaryRootSkillId") : "";
      this.temporaryPreviousFleshStrengthLevel = tag.contains("temporaryPreviousFleshStrengthLevel") ? tag.getInt("temporaryPreviousFleshStrengthLevel") : -1;
      this.temporaryPreviousSuperStrengthLevel = tag.contains("temporaryPreviousSuperStrengthLevel") ? tag.getInt("temporaryPreviousSuperStrengthLevel") : -1;
      this.temporaryVLoad = tag.contains("temporaryVLoad") ? this.clampTemporaryVLoad(tag.getInt("temporaryVLoad")) : 0;
      this.temporaryVWithdrawalEndGameTime = tag.contains("temporaryVWithdrawalEndGameTime") ? tag.getLong("temporaryVWithdrawalEndGameTime") : -1L;
      this.temporaryVWithdrawalDurationTicks = tag.contains("temporaryVWithdrawalDurationTicks")
         ? Math.max(0, tag.getInt("temporaryVWithdrawalDurationTicks"))
         : 0;
      this.temporaryVLastLoadDecayGameTime = tag.contains("temporaryVLastLoadDecayGameTime") ? tag.getLong("temporaryVLastLoadDecayGameTime") : -1L;
      this.temporaryVOverloaded = tag.contains("temporaryVOverloaded") && tag.getBoolean("temporaryVOverloaded");
      if (this.temporarySkills.isEmpty()) {
         this.clearTemporaryMetadata();
      }

      this.activeStates.clear();
      if (tag.contains("activeStates", 10)) {
         CompoundTag activeTag = tag.getCompound("activeStates");

         for (String key : activeTag.getAllKeys()) {
            this.activeStates.put(key, activeTag.getBoolean(key));
         }
      }

      this.damageMultipliers.clear();
      if (tag.contains("damageMultipliers", 10)) {
         CompoundTag multiplierTag = tag.getCompound("damageMultipliers");

         for (String key : multiplierTag.getAllKeys()) {
            this.damageMultipliers.put(key, multiplierTag.getInt(key));
         }
      }

      if (tag.contains("meleeDamageMultiplier")) {
         this.meleeDamageMultiplier = tag.getInt("meleeDamageMultiplier");
      }

      if (tag.contains("damageThreshold")) {
         this.damageThreshold = tag.getFloat("damageThreshold");
      }

      if (tag.contains("fleshDamageReduction")) {
         this.fleshDamageReduction = tag.getInt("fleshDamageReduction");
      }

      if (tag.contains("shieldHp")) {
         this.shieldHp = tag.getFloat("shieldHp");
      }

      if (tag.contains("maxShieldHp")) {
         this.maxShieldHp = tag.getFloat("maxShieldHp");
      }

      if (tag.contains("fleshStrengthLevel")) {
         this.fleshStrengthLevel = tag.getInt("fleshStrengthLevel");
      }

      if (tag.contains("lastDamageTime")) {
         this.lastDamageTime = tag.getLong("lastDamageTime");
      }

      if (tag.contains("laserEyeLevel")) {
         this.setLaserEyeLevel(tag.getInt("laserEyeLevel"));
      }

      if (tag.contains("superStrengthLevel")) {
         this.setSuperStrengthLevel(tag.getInt("superStrengthLevel"));
      }

      if (tag.contains("superSpeedLevel")) {
         this.setSuperSpeedLevel(tag.getInt("superSpeedLevel"));
      }

      if (tag.contains("speedAdjustment")) {
         this.speedAdjustment = tag.getInt("speedAdjustment");
      }

      if (tag.contains("targetScale")) {
         this.targetScale = clampPlayerScale(tag.getFloat("targetScale"));
      }

      if (tag.contains("fireTimer")) {
         this.fireTimer = tag.getInt("fireTimer");
      }

      if (tag.contains("vibrateTimer")) {
         this.vibrateTimer = tag.getInt("vibrateTimer");
      }

      this.ensureChildSkills();
   }
}
