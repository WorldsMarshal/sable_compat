package com.invfix.vpower.skill.skills;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.client.animation.ModAnimations;
import com.invfix.vpower.entity.effect.VisualFallingBlockEntity;
import com.invfix.vpower.network.PlayerAnimationPlaySyncPacket;
import com.invfix.vpower.registry.ModDamageSources;
import com.invfix.vpower.util.VBlocks;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.base.Skill;
import com.invfix.vpower.skill.base.SkillType;
import com.invfix.vpower.util.IntangibilityUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

public class StompSkill extends Skill {
   public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "stomp");
   private static final ResourceLocation ICON = ResourceLocation.fromNamespaceAndPath("theboysmod", "textures/gui/punch.png");
   public static final int WINDUP_TICKS = 11;
   public static final int COOLDOWN_TICKS = 26;
   private static final int LINEAR_MAX_STEPS = 7;
   private static final double LINEAR_STEP_DISTANCE = 1.15;
   private static final double LINEAR_BASE_RADIUS = 1.15;
   private static final double LINEAR_RADIUS_GROWTH = 0.22;
   private static final double LINEAR_IMPACT_RADIUS = 2.25;
   private static final double IMPACT_RADIUS_RATIO = 0.34;
   private static final double RING_THICKNESS_RATIO = 0.17;
   private static final double RING_STEP_DISTANCE = 0.95;
   private static final double BLOCK_ARC_LENGTH = 0.82;
   private static final double PARTICLE_ARC_LENGTH = 1.25;
   private static final double VERTICAL_REACH = 1.8;
   private static final double NPC_RING_DISTANCE = 3.25;
   private static final float IMPACT_EDGE_DAMAGE_MULTIPLIER = 0.62F;
   private static final float WAVE_EDGE_DAMAGE_MULTIPLIER = 0.35F;
   private static final Map<UUID, StompSkill.PendingCast> PENDING_CASTS = new ConcurrentHashMap<>();
   private static final Map<UUID, StompSkill.ActiveWave> ACTIVE_WAVES = new ConcurrentHashMap<>();
   private static final Map<UUID, Long> NEXT_CAST_TICK = new ConcurrentHashMap<>();

   @Override
   public ResourceLocation getId() {
      return ID;
   }

   @Override
   public SkillType getType() {
      return SkillType.ACTIVE;
   }

   @Override
   public boolean requiresMastery() {
      return false;
   }

   @Override
   public int getCooldown() {
      return 26;
   }

   @Override
   public ResourceLocation getIcon() {
      return ICON;
   }

   @Override
   public void trigger(LivingEntity owner) {
      if (owner.level() instanceof ServerLevel level) {
         SkillData data = (SkillData)owner.getData(ModSkillAttachments.SKILL_DATA.get());
         data.setSkillActive(ID.toString(), false);
         if (canCast(owner)) {
            UUID playerId = owner.getUUID();
            long gameTime = level.getGameTime();
            if (gameTime >= NEXT_CAST_TICK.getOrDefault(playerId, 0L) && !PENDING_CASTS.containsKey(playerId) && !ACTIVE_WAVES.containsKey(playerId)) {
               StompSkill.CastMode mode = resolveMode(owner);
               Vec3 direction = getHorizontalLook(owner);
               PENDING_CASTS.put(playerId, new StompSkill.PendingCast(level.dimension(), mode, direction, 11));
               NEXT_CAST_TICK.put(playerId, gameTime + 26L);
               playCastAnimation(owner);
               level.playSound(null, owner.getX(), owner.getY(), owner.getZ(), SoundEvents.PLAYER_ATTACK_STRONG, getSoundSource(owner), 0.9F, 0.55F);
            }
         }
      }
   }

   public static boolean isWindingUp(LivingEntity owner) {
      return owner != null && PENDING_CASTS.containsKey(owner.getUUID());
   }

   public static void serverTick(ServerLevel level) {
      for (Entry<UUID, StompSkill.PendingCast> entry : PENDING_CASTS.entrySet()) {
         StompSkill.PendingCast pending = entry.getValue();
         if (pending.levelKey.equals(level.dimension())) {
            try {
               tickPendingCast(entry.getKey(), pending, level);
            } catch (Exception var6) {
               PENDING_CASTS.remove(entry.getKey(), pending);
               ACTIVE_WAVES.remove(entry.getKey());
            }
         }
      }

      for (Entry<UUID, StompSkill.ActiveWave> entryx : ACTIVE_WAVES.entrySet()) {
         StompSkill.ActiveWave wave = entryx.getValue();
         if (wave.levelKey().equals(level.dimension())) {
            try {
               tickActiveWave(entryx.getKey(), wave, level);
            } catch (Exception var5) {
               ACTIVE_WAVES.remove(entryx.getKey(), wave);
            }
         }
      }
   }

   private static void tickPendingCast(UUID entityId, StompSkill.PendingCast pending, ServerLevel level) {
      LivingEntity owner = getCastOwner(level, entityId);
      if (owner != null && owner.isAlive()) {
         pending.ticksRemaining--;
         if (pending.ticksRemaining <= 0) {
            PENDING_CASTS.remove(entityId, pending);
            releaseShockwave(owner, level, pending.mode, pending.direction, true, true);
         }
      } else {
         PENDING_CASTS.remove(entityId, pending);
         ACTIVE_WAVES.remove(entityId);
      }
   }

   private static void tickActiveWave(UUID entityId, StompSkill.ActiveWave wave, ServerLevel level) {
      LivingEntity owner = getCastOwner(level, entityId);
      if (owner == null || !owner.isAlive() || !wave.tick(owner, level)) {
         ACTIVE_WAVES.remove(entityId, wave);
      }
   }

   private static LivingEntity getCastOwner(ServerLevel level, UUID entityId) {
      return level.getEntity(entityId) instanceof LivingEntity living ? living : null;
   }

   private static boolean canCast(LivingEntity owner) {
      if (owner.isAlive() && !owner.isPassenger() && owner.onGround() && !owner.isInWater() && !owner.isInLava()) {
         if (owner instanceof Player player && player.isSpectator()) {
            return false;
         }

         return true;
      } else {
         return false;
      }
   }

   private static StompSkill.CastMode resolveMode(LivingEntity owner) {
      if (owner instanceof Player player) {
         return player.isShiftKeyDown() ? StompSkill.CastMode.RING : StompSkill.CastMode.LINEAR;
      } else {
         if (owner instanceof PathfinderMob mob) {
            LivingEntity target = mob.getTarget();
            if (target != null && target.isAlive() && (double)owner.distanceTo(target) <= 3.25) {
               return StompSkill.CastMode.RING;
            }
         }

         return StompSkill.CastMode.LINEAR;
      }
   }

   private static SoundSource getSoundSource(LivingEntity owner) {
      return owner instanceof Player ? SoundSource.PLAYERS : SoundSource.HOSTILE;
   }

   private static void playCastAnimation(LivingEntity owner) {
      owner.swing(InteractionHand.MAIN_HAND);

      if (owner instanceof ServerPlayer player) {
         PacketDistributor.sendToPlayersTrackingEntityAndSelf(
            player, new PlayerAnimationPlaySyncPacket(player.getId(), ModAnimations.STOMP, false, 1, false), new CustomPacketPayload[0]
         );
      }
   }

   public static void releaseRingShockwaveSilently(LivingEntity owner, ServerLevel level) {
      if (owner != null && level != null && owner.isAlive()) {
         releaseShockwave(owner, level, StompSkill.CastMode.RING, getHorizontalLook(owner), false, false);
      }
   }

   private static void releaseShockwave(LivingEntity owner, ServerLevel level, StompSkill.CastMode mode, Vec3 direction, boolean playSounds, boolean dealDamage) {
      Vec3 origin = findGroundPosition(level, owner.position().add(0.0, 0.2, 0.0));
      SkillData data = (SkillData)owner.getData(ModSkillAttachments.SKILL_DATA.get());
      if (mode == StompSkill.CastMode.RING) {
         double maxRadius = getScaledMaxRadius(data);
         double impactRadius = getImpactRadius(maxRadius);
         double ringThickness = getRingThickness(maxRadius);
         StompSkill.RingWaveState wave = new StompSkill.RingWaveState(level.dimension(), origin, impactRadius, maxRadius, ringThickness, dealDamage);
         spawnImpactBurst(level, origin, Math.max(impactRadius, 0.55));
         spawnRingTremorBlocks(level, origin, impactRadius, Math.max(ringThickness * 0.75, 0.55), wave.launchedBlocks);
         if (dealDamage) {
            damageRingImpact(owner, level, origin, data, impactRadius, ringThickness, wave.hitEntityIds);
         }

         if (wave.hasExpansion()) {
            ACTIVE_WAVES.put(owner.getUUID(), wave);
         }
      } else {
         Vec3 castDirection = direction.lengthSqr() < 1.0E-4 ? getHorizontalLook(owner) : direction.normalize();
         StompSkill.LineWaveState wavex = new StompSkill.LineWaveState(level.dimension(), origin.add(castDirection.scale(0.8)), castDirection, dealDamage);
         ACTIVE_WAVES.put(owner.getUUID(), wavex);
         spawnImpactBurst(level, origin, 2.25);
         spawnLinearImpactTremorBlocks(level, origin, castDirection, wavex.launchedBlocks);
         if (dealDamage) {
            damageLinearImpact(owner, level, origin, data, wavex.hitEntityIds);
         }
      }

      if (playSounds) {
         level.playSound(null, origin.x, origin.y, origin.z, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), getSoundSource(owner), 0.7F, 0.85F);
         level.playSound(null, origin.x, origin.y, origin.z, SoundEvents.PLAYER_ATTACK_SWEEP, getSoundSource(owner), 0.8F, 0.6F);
      }
   }

   private static void damageRingImpact(
      LivingEntity owner, ServerLevel level, Vec3 origin, SkillData data, double impactRadius, double ringThickness, Set<Integer> hitEntityIds
   ) {
      if (!(impactRadius <= 0.0)) {
         double radius = impactRadius + ringThickness * 0.35;
         AABB box = new AABB(origin.x - radius, origin.y - 1.0, origin.z - radius, origin.x + radius, origin.y + 2.0, origin.z + radius);
         float baseDamage = getBaseDamage(data) * 0.95F * getTotalDamageMultiplier(data);
         float knockback = getKnockbackStrength(data) * 0.8F * getKnockbackScale(data);

         for (LivingEntity target : level.getEntitiesOfClass(
            LivingEntity.class, box, entity -> isValidTarget(owner, entity) && !hitEntityIds.contains(entity.getId())
         )) {
            Vec3 center = target.position().add(0.0, (double)target.getBbHeight() * 0.5, 0.0);
            if (!(Math.abs(center.y - origin.y) > 1.8 + (double)target.getBbHeight() * 0.5)) {
               double distance = horizontalDistance(center, origin);
               if (!(distance > radius + (double)target.getBbWidth() * 0.5)) {
                  hitEntityIds.add(target.getId());
                  float damage = applyDamageFalloff(baseDamage, distance, radius, 0.62F);
                  hurtAndKnockback(owner, target, center.subtract(origin), damage, knockback);
               }
            }
         }
      }
   }

   private static void damageLinearImpact(LivingEntity owner, ServerLevel level, Vec3 origin, SkillData data, Set<Integer> hitEntityIds) {
      AABB box = new AABB(origin.x - 2.25, origin.y - 1.0, origin.z - 2.25, origin.x + 2.25, origin.y + 2.0, origin.z + 2.25);
      float baseDamage = getBaseDamage(data) * 0.95F * getTotalDamageMultiplier(data);
      float knockback = getKnockbackStrength(data) * 0.9F * getKnockbackScale(data);

      for (LivingEntity target : level.getEntitiesOfClass(
         LivingEntity.class, box, entity -> isValidTarget(owner, entity) && !hitEntityIds.contains(entity.getId())
      )) {
         Vec3 center = target.position().add(0.0, (double)target.getBbHeight() * 0.5, 0.0);
         if (!(Math.abs(center.y - origin.y) > 1.8 + (double)target.getBbHeight() * 0.5)) {
            double distance = horizontalDistance(center, origin);
            if (!(distance > 2.25 + (double)target.getBbWidth() * 0.5)) {
               hitEntityIds.add(target.getId());
               float damage = applyDamageFalloff(baseDamage, distance, 2.25, 0.62F);
               hurtAndKnockback(owner, target, center.subtract(origin), damage, knockback);
            }
         }
      }
   }

   private static void spawnImpactBurst(ServerLevel level, Vec3 origin, double radius) {
      if (!(radius <= 0.0)) {
         BlockState groundState = getGroundState(level, origin);
         if (!groundState.isAir()) {
            level.sendParticles(
               new BlockParticleOption(ParticleTypes.BLOCK, groundState), origin.x, origin.y + 0.1, origin.z, 26, radius * 0.45, 0.2, radius * 0.45, 0.06
            );
         }

         level.sendParticles(ParticleTypes.CLOUD, origin.x, origin.y + 0.15, origin.z, 18, radius * 0.35, 0.12, radius * 0.35, 0.05);
      }
   }

   private static void spawnLinearImpactTremorBlocks(ServerLevel level, Vec3 origin, Vec3 direction, Set<Long> launchedBlocks) {
      Vec3 orth = new Vec3(-direction.z, 0.0, direction.x).normalize();
      int count = 5;

      for (int i = 0; i < count; i++) {
         double offset = count == 1 ? 0.0 : Mth.lerp((double)i / (double)(count - 1), -1.4, 1.4);
         Vec3 sample = origin.add(direction.scale(0.9)).add(orth.scale(offset));
         BlockPos blockPos = BlockPos.containing(findGroundPosition(level, sample)).below();
         createTremorBlock(level, blockPos, 0.38F + level.random.nextFloat() * 0.16F, launchedBlocks);
      }
   }

   private static void spawnLinearStepParticles(ServerLevel level, Vec3 position, double radius) {
      BlockState groundState = getGroundState(level, position);
      if (!groundState.isAir()) {
         level.sendParticles(
            new BlockParticleOption(ParticleTypes.BLOCK, groundState), position.x, position.y + 0.08, position.z, 10, radius * 0.3, 0.08, radius * 0.3, 0.04
         );
      }

      level.sendParticles(ParticleTypes.CLOUD, position.x, position.y + 0.1, position.z, 8, radius * 0.22, 0.04, radius * 0.22, 0.03);
   }

   private static void spawnLinearStepTremorBlocks(ServerLevel level, Vec3 center, Vec3 direction, double radius, Set<Long> launchedBlocks) {
      Vec3 orth = new Vec3(-direction.z, 0.0, direction.x).normalize();
      int count = Math.max(2, Mth.ceil(radius * 2.2));
      double halfWidth = Math.max(0.8, radius * 0.9);

      for (int i = 0; i < count; i++) {
         double offset = count == 1 ? 0.0 : Mth.lerp((double)i / (double)(count - 1), -halfWidth, halfWidth);
         Vec3 sample = center.add(orth.scale(offset));
         BlockPos blockPos = BlockPos.containing(findGroundPosition(level, sample)).below();
         createTremorBlock(level, blockPos, 0.28F + level.random.nextFloat() * 0.14F, launchedBlocks);
      }
   }

   private static void spawnRingParticles(ServerLevel level, Vec3 origin, double radius, double ringThickness) {
      if (!(radius <= 0.0)) {
         int samples = Math.max(8, Mth.ceil((Math.PI * 2) * Math.max(radius, 0.6) / 1.25));

         for (int i = 0; i < samples; i++) {
            double angle = (Math.PI * 2) * (double)i / (double)samples;
            Vec3 sample = origin.add(Math.cos(angle) * radius, 0.0, Math.sin(angle) * radius);
            Vec3 groundSample = findGroundPosition(level, sample);
            BlockState groundState = getGroundState(level, groundSample);
            if (!groundState.isAir()) {
               level.sendParticles(
                  new BlockParticleOption(ParticleTypes.BLOCK, groundState),
                  groundSample.x,
                  groundSample.y + 0.08,
                  groundSample.z,
                  1,
                  ringThickness * 0.12,
                  0.05,
                  ringThickness * 0.12,
                  0.01
               );
            }

            if ((i & 1) == 0) {
               level.sendParticles(ParticleTypes.CLOUD, groundSample.x, groundSample.y + 0.12, groundSample.z, 1, 0.1, 0.03, 0.1, 0.01);
            }
         }
      }
   }

   private static void spawnRingTremorBlocks(ServerLevel level, Vec3 origin, double radius, double ringThickness, Set<Long> launchedBlocks) {
      if (!(radius <= 0.0) && !(ringThickness <= 0.0)) {
         int lanes = Mth.clamp(Mth.ceil(ringThickness / 0.75), 1, 3);
         int samples = Math.max(10, Mth.ceil((Math.PI * 2) * Math.max(radius, 0.6) / 0.82));

         for (int lane = 0; lane < lanes; lane++) {
            double laneOffset = lanes == 1 ? 0.0 : Mth.lerp((double)lane / (double)(lanes - 1), -ringThickness * 0.45, ringThickness * 0.45);
            double laneRadius = Math.max(0.35, radius + laneOffset);

            for (int i = 0; i < samples; i++) {
               double angle = (Math.PI * 2) * (double)i / (double)samples;
               Vec3 sample = origin.add(Math.cos(angle) * laneRadius, 0.0, Math.sin(angle) * laneRadius);
               BlockPos blockPos = BlockPos.containing(findGroundPosition(level, sample)).below();
               createTremorBlock(level, blockPos, 0.28F + level.random.nextFloat() * 0.16F, launchedBlocks);
            }
         }
      }
   }

   private static void createTremorBlock(ServerLevel level, BlockPos blockPos, float impulseStrength, Set<Long> launchedBlocks) {
      if (!VBlocks.protectedLevel(level)) {
         BlockState state = level.getBlockState(blockPos);
         if (!state.isAir() && state.getFluidState().isEmpty()) {
            if (launchedBlocks.add(blockPos.asLong())) {
               boolean freeAbove = level.getBlockState(blockPos.above()).isAir();
               boolean freeTwoAbove = level.getBlockState(blockPos.above().above()).isAir();
               if (freeAbove || freeTwoAbove) {
                  spawnTremorBlockEntity(level, blockPos, state, impulseStrength);
                  if (!freeAbove) {
                     BlockState upperState = level.getBlockState(blockPos.above());
                     if (!upperState.isAir() && upperState.getFluidState().isEmpty()) {
                        spawnTremorBlockEntity(level, blockPos.above(), upperState, impulseStrength);
                     }
                  }
               }
            }
         }
      }
   }

   private static void spawnTremorBlockEntity(ServerLevel level, BlockPos blockPos, BlockState state, float impulseStrength) {
      VisualFallingBlockEntity entity = new VisualFallingBlockEntity(
         level, (double)blockPos.getX(), (double)blockPos.getY(), (double)blockPos.getZ(), state, 10
      );
      entity.setDeltaMovement(0.0, (double)impulseStrength, 0.0);
      level.addFreshEntity(entity);
   }

   private static Vec3 findGroundPosition(ServerLevel level, Vec3 candidate) {
      BlockPos base = BlockPos.containing(candidate.x, candidate.y, candidate.z);

      for (int dy = 2; dy >= -6; dy--) {
         BlockPos feetPos = base.offset(0, dy, 0);
         BlockPos headPos = feetPos.above();
         BlockPos groundPos = feetPos.below();
         if (level.getBlockState(feetPos).isAir() && level.getBlockState(headPos).isAir() && level.getBlockState(groundPos).blocksMotion()) {
            return new Vec3(candidate.x, (double)feetPos.getY(), candidate.z);
         }
      }

      return new Vec3(candidate.x, candidate.y, candidate.z);
   }

   private static BlockState getGroundState(ServerLevel level, Vec3 position) {
      BlockPos groundPos = BlockPos.containing(position.x, position.y - 0.2, position.z);
      BlockState state = level.getBlockState(groundPos);
      return !state.isAir() ? state : level.getBlockState(groundPos.below());
   }

   private static Vec3 getHorizontalLook(LivingEntity owner) {
      Vec3 look = owner.getLookAngle();
      Vec3 horizontal = new Vec3(look.x, 0.0, look.z);
      if (horizontal.lengthSqr() < 1.0E-4) {
         float yawRadians = owner.getYRot() * (float) (Math.PI / 180.0);
         horizontal = new Vec3((double)(-Mth.sin(yawRadians)), 0.0, (double)Mth.cos(yawRadians));
      }

      return horizontal.normalize();
   }

   private static float getBaseDamage(SkillData data) {
      return switch (data.getSuperStrengthLevel()) {
         case 1 -> 8.0F;
         case 2 -> 14.0F;
         case 3 -> 22.0F;
         case 4 -> 34.0F;
         default -> 48.0F;
      };
   }

   private static float getKnockbackStrength(SkillData data) {
      return switch (data.getSuperStrengthLevel()) {
         case 1 -> 0.9F;
         case 2 -> 1.05F;
         case 3 -> 1.2F;
         case 4 -> 1.35F;
         default -> 1.55F;
      };
   }

   private static double getBaseMaxRadius(SkillData data) {
      return switch (data.getSuperStrengthLevel()) {
         case 1 -> 2.8;
         case 2 -> 4.0;
         case 3 -> 5.2;
         case 4 -> 6.5;
         default -> 8.0;
      };
   }

   private static double getScaledMaxRadius(SkillData data) {
      return getBaseMaxRadius(data) * (double)getPowerScale(data);
   }

   private static double getImpactRadius(double maxRadius) {
      return maxRadius <= 0.0 ? 0.0 : Math.min(maxRadius, Math.max(0.65, maxRadius * 0.34));
   }

   private static double getRingThickness(double maxRadius) {
      return maxRadius <= 0.0 ? 0.0 : Math.min(maxRadius + 0.25, Math.max(0.65, maxRadius * 0.17 + 0.3));
   }

   private static int getRingStepCount(double impactRadius, double maxRadius) {
      double travelDistance = Math.max(0.0, maxRadius - impactRadius);
      return travelDistance <= 0.0 ? 0 : Mth.clamp(Mth.ceil(travelDistance / 0.95), 1, 10);
   }

   private static float getDamageMultiplier(SkillData data) {
      return (float)data.getDamageMultiplier(ID.toString()) / 100.0F;
   }

   private static float getPowerScale(SkillData data) {
      return (float)data.getMeleeDamageMultiplier() / 100.0F;
   }

   private static float getTotalDamageMultiplier(SkillData data) {
      return getDamageMultiplier(data) * getPowerScale(data);
   }

   private static float applyDamageFalloff(float baseDamage, double distance, double maxDistance, float edgeMultiplier) {
      if (maxDistance <= 0.0) {
         return baseDamage;
      } else {
         double progress = Mth.clamp(distance / maxDistance, 0.0, 1.0);
         float multiplier = (float)Mth.lerp(progress, 1.0, (double)edgeMultiplier);
         return Math.max(1.0F, baseDamage * multiplier);
      }
   }

   private static float getKnockbackScale(SkillData data) {
      float powerScale = getPowerScale(data);
      return powerScale <= 0.0F ? 0.0F : Math.max(0.35F, powerScale);
   }

   private static boolean isValidTarget(LivingEntity owner, LivingEntity target) {
      if (target == owner || !target.isAlive() || target.isRemoved()) {
         return false;
      } else if (IntangibilityUtil.isIntangible(target)) {
         return false;
      } else {
         if (target instanceof Player player && (player.isCreative() || player.isSpectator())) {
            return false;
         }

         return !owner.isAlliedTo(target);
      }
   }

   private static double horizontalDistance(Vec3 a, Vec3 b) {
      double dx = a.x - b.x;
      double dz = a.z - b.z;
      return Math.sqrt(dx * dx + dz * dz);
   }

   private static double distanceToSegment(Vec3 point, Vec3 start, Vec3 end) {
      Vec3 segment = end.subtract(start);
      double lengthSqr = segment.lengthSqr();
      if (lengthSqr < 1.0E-6) {
         return point.distanceTo(start);
      } else {
         double t = point.subtract(start).dot(segment) / lengthSqr;
         t = Mth.clamp(t, 0.0, 1.0);
         Vec3 closest = start.add(segment.scale(t));
         return point.distanceTo(closest);
      }
   }

   private static void damageRingStep(
      LivingEntity owner, ServerLevel level, Vec3 origin, double previousRadius, double currentRadius, double ringThickness, Set<Integer> hitEntityIds
   ) {
      SkillData data = (SkillData)owner.getData(ModSkillAttachments.SKILL_DATA.get());
      double innerRadius = Math.max(0.0, previousRadius - ringThickness);
      double outerRadius = currentRadius + ringThickness;
      AABB box = new AABB(origin.x - outerRadius, origin.y - 1.0, origin.z - outerRadius, origin.x + outerRadius, origin.y + 2.0, origin.z + outerRadius);
      float baseDamage = getBaseDamage(data) * getTotalDamageMultiplier(data);
      double maxRadius = getScaledMaxRadius(data);
      float knockback = getKnockbackStrength(data) * getKnockbackScale(data);

      for (LivingEntity target : level.getEntitiesOfClass(
         LivingEntity.class, box, entity -> isValidTarget(owner, entity) && !hitEntityIds.contains(entity.getId())
      )) {
         Vec3 center = target.position().add(0.0, (double)target.getBbHeight() * 0.5, 0.0);
         if (!(Math.abs(center.y - origin.y) > 1.8 + (double)target.getBbHeight() * 0.5)) {
            double distance = horizontalDistance(center, origin);
            if (!(distance < innerRadius - (double)target.getBbWidth() * 0.5) && !(distance > outerRadius + (double)target.getBbWidth() * 0.5)) {
               hitEntityIds.add(target.getId());
               float damage = applyDamageFalloff(baseDamage, distance, maxRadius, 0.35F);
               hurtAndKnockback(owner, target, center.subtract(origin), damage, knockback);
            }
         }
      }
   }

   private static void damageLinearStep(
      LivingEntity owner, ServerLevel level, Vec3 origin, Vec3 segmentStart, Vec3 segmentEnd, double radius, Set<Integer> hitEntityIds
   ) {
      SkillData data = (SkillData)owner.getData(ModSkillAttachments.SKILL_DATA.get());
      Vec3 min = new Vec3(Math.min(segmentStart.x, segmentEnd.x), Math.min(segmentStart.y, segmentEnd.y), Math.min(segmentStart.z, segmentEnd.z));
      Vec3 max = new Vec3(Math.max(segmentStart.x, segmentEnd.x), Math.max(segmentStart.y, segmentEnd.y), Math.max(segmentStart.z, segmentEnd.z));
      AABB box = new AABB(min, max).inflate(radius, 1.8, radius);
      float baseDamage = getBaseDamage(data) * getTotalDamageMultiplier(data);
      double maxFalloffDistance = 8.049999999999999;
      float knockback = getKnockbackStrength(data) * getKnockbackScale(data);

      for (LivingEntity target : level.getEntitiesOfClass(
         LivingEntity.class, box, entity -> isValidTarget(owner, entity) && !hitEntityIds.contains(entity.getId())
      )) {
         Vec3 center = target.position().add(0.0, (double)target.getBbHeight() * 0.5, 0.0);
         if (!(Math.abs(center.y - segmentEnd.y) > 1.8 + (double)target.getBbHeight() * 0.5)) {
            double maxDistance = radius + (double)target.getBbWidth() * 0.5;
            if (!(distanceToSegment(center, segmentStart, segmentEnd) > maxDistance)) {
               hitEntityIds.add(target.getId());
               double distanceFromOrigin = horizontalDistance(center, origin);
               float damage = applyDamageFalloff(baseDamage, distanceFromOrigin, maxFalloffDistance, 0.35F);
               hurtAndKnockback(owner, target, center.subtract(segmentEnd), damage, knockback);
            }
         }
      }
   }

   private static void hurtAndKnockback(LivingEntity owner, LivingEntity target, Vec3 pushDirection, float damage, float knockbackStrength) {
      Vec3 horizontal = new Vec3(pushDirection.x, 0.0, pushDirection.z);
      if (horizontal.lengthSqr() < 1.0E-4) {
         horizontal = getHorizontalLook(owner);
      } else {
         horizontal = horizontal.normalize();
      }

      target.invulnerableTime = 0;
      target.hurtTime = 0;
      target.hurt(ModDamageSources.of(owner.level()).stomp(owner), damage);
      target.push(horizontal.x * (double)knockbackStrength, 0.22 + (double)knockbackStrength * 0.08, horizontal.z * (double)knockbackStrength);
      target.hurtMarked = true;
   }

   private interface ActiveWave {
      ResourceKey<Level> levelKey();

      boolean tick(LivingEntity var1, ServerLevel var2);
   }

   private static enum CastMode {
      LINEAR,
      RING;
   }

   private static final class LineWaveState implements StompSkill.ActiveWave {
      private final ResourceKey<Level> levelKey;
      private final Vec3 origin;
      private final Vec3 direction;
      private final boolean dealDamage;
      private final Set<Integer> hitEntityIds = new HashSet<>();
      private final Set<Long> launchedBlocks = new HashSet<>();
      private Vec3 previousPosition;
      private int step;

      private LineWaveState(ResourceKey<Level> levelKey, Vec3 origin, Vec3 direction, boolean dealDamage) {
         this.levelKey = levelKey;
         this.origin = origin;
         this.previousPosition = origin;
         this.direction = direction;
         this.dealDamage = dealDamage;
      }

      @Override
      public ResourceKey<Level> levelKey() {
         return this.levelKey;
      }

      @Override
      public boolean tick(LivingEntity owner, ServerLevel level) {
         if (this.step >= 7) {
            return false;
         } else {
            this.step++;
            double travelDistance = (double)this.step * 1.15;
            Vec3 targetPosition = this.previousPosition.add(this.direction.scale(1.15));
            Vec3 groundPosition = StompSkill.findGroundPosition(level, targetPosition);
            double radius = 1.15 + (double)(this.step - 1) * 0.22;
            StompSkill.spawnLinearStepParticles(level, groundPosition, radius);
            StompSkill.spawnLinearStepTremorBlocks(level, groundPosition, this.direction, radius, this.launchedBlocks);
            if (this.dealDamage) {
               StompSkill.damageLinearStep(owner, level, this.origin, this.previousPosition, groundPosition, radius, this.hitEntityIds);
            }

            this.previousPosition = groundPosition;
            return travelDistance < 8.050999999999998;
         }
      }
   }

   private static final class PendingCast {
      private final ResourceKey<Level> levelKey;
      private final StompSkill.CastMode mode;
      private final Vec3 direction;
      private int ticksRemaining;

      private PendingCast(ResourceKey<Level> levelKey, StompSkill.CastMode mode, Vec3 direction, int ticksRemaining) {
         this.levelKey = levelKey;
         this.mode = mode;
         this.direction = direction;
         this.ticksRemaining = ticksRemaining;
      }
   }

   private static final class RingWaveState implements StompSkill.ActiveWave {
      private final ResourceKey<Level> levelKey;
      private final Vec3 origin;
      private final double impactRadius;
      private final double maxRadius;
      private final double ringThickness;
      private final boolean dealDamage;
      private final int stepCount;
      private final Set<Integer> hitEntityIds = new HashSet<>();
      private final Set<Long> launchedBlocks = new HashSet<>();
      private double currentRadius;
      private int step;

      private RingWaveState(ResourceKey<Level> levelKey, Vec3 origin, double impactRadius, double maxRadius, double ringThickness, boolean dealDamage) {
         this.levelKey = levelKey;
         this.origin = origin;
         this.impactRadius = impactRadius;
         this.currentRadius = impactRadius;
         this.maxRadius = maxRadius;
         this.ringThickness = ringThickness;
         this.dealDamage = dealDamage;
         this.stepCount = StompSkill.getRingStepCount(impactRadius, maxRadius);
      }

      private boolean hasExpansion() {
         return this.stepCount > 0;
      }

      @Override
      public ResourceKey<Level> levelKey() {
         return this.levelKey;
      }

      @Override
      public boolean tick(LivingEntity owner, ServerLevel level) {
         if (this.step >= this.stepCount) {
            return false;
         } else {
            this.step++;
            double previousRadius = this.currentRadius;
            this.currentRadius = this.impactRadius + (this.maxRadius - this.impactRadius) * ((double)this.step / (double)this.stepCount);
            StompSkill.spawnRingParticles(level, this.origin, this.currentRadius, this.ringThickness);
            StompSkill.spawnRingTremorBlocks(level, this.origin, this.currentRadius, this.ringThickness, this.launchedBlocks);
            if (this.dealDamage) {
               StompSkill.damageRingStep(owner, level, this.origin, previousRadius, this.currentRadius, this.ringThickness, this.hitEntityIds);
            }

            return this.step < this.stepCount;
         }
      }
   }
}
