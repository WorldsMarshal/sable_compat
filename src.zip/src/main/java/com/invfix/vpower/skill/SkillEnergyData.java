package com.invfix.vpower.skill;

import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.common.util.INBTSerializable;

public class SkillEnergyData implements INBTSerializable<CompoundTag> {
   public static final float DEFAULT_MAX_ENERGY = 20.0F;
   private float energy = 20.0F;
   private float maxEnergy = 20.0F;

   public float getEnergy() {
      return this.energy;
   }

   public void setEnergy(float value) {
      this.energy = clamp(value, 0.0F, this.maxEnergy);
   }

   public float getMaxEnergy() {
      return this.maxEnergy;
   }

   public void setMaxEnergy(float value) {
      this.maxEnergy = Math.max(1.0F, value);
      this.energy = clamp(this.energy, 0.0F, this.maxEnergy);
   }

   public float getMissingEnergy() {
      return this.maxEnergy - this.energy;
   }

   public boolean consume(float amount) {
      if (amount <= 0.0F) {
         return true;
      } else if (this.energy + 1.0E-4F < amount) {
         return false;
      } else {
         this.energy = Math.max(0.0F, this.energy - amount);
         return true;
      }
   }

   public void refill(float amount) {
      if (!(amount <= 0.0F)) {
         this.energy = Math.min(this.maxEnergy, this.energy + amount);
      }
   }

   private static float clamp(float value, float min, float max) {
      return Math.max(min, Math.min(max, value));
   }

   public CompoundTag serializeNBT(Provider provider) {
      CompoundTag tag = new CompoundTag();
      tag.putFloat("energy", this.energy);
      tag.putFloat("maxEnergy", this.maxEnergy);
      return tag;
   }

   public void deserializeNBT(Provider provider, CompoundTag tag) {
      if (tag.contains("maxEnergy")) {
         this.maxEnergy = Math.max(1.0F, tag.getFloat("maxEnergy"));
      } else {
         this.maxEnergy = 20.0F;
      }

      if (tag.contains("energy")) {
         this.energy = clamp(tag.getFloat("energy"), 0.0F, this.maxEnergy);
      } else {
         this.energy = this.maxEnergy;
      }
   }
}
