package com.invfix.vpower.skill.base;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import org.jetbrains.annotations.Nullable;

public abstract class Skill {
   private Skill parent;
   private final List<Skill> children = new ArrayList<>();

   public void setParent(Skill parent) {
      this.parent = parent;
   }

   public Skill getParent() {
      return this.parent;
   }

   public void addChild(Skill child) {
      if (child != null) {
         this.children.add(child);
         child.setParent(this);
      }
   }

   public List<Skill> getChildren() {
      return Collections.unmodifiableList(this.children);
   }

   public abstract ResourceLocation getId();

   public Component getName() {
      ResourceLocation id = this.getId();
      return Component.translatable("skill." + id.getNamespace() + "." + id.getPath());
   }

   public Component getDescription() {
      ResourceLocation id = this.getId();
      return Component.translatable("skill." + id.getNamespace() + "." + id.getPath() + ".desc");
   }

   public abstract SkillType getType();

   public int getMaxMastery() {
      return 100;
   }

   public int getMasteryGainPerTick() {
      return 1;
   }

   public boolean requiresMastery() {
      return this.getType() == SkillType.ACTIVE;
   }

   public int getCooldown() {
      return 0;
   }

   public boolean isChannelingType() {
      return false;
   }

   public boolean canUse(LivingEntity owner) {
      return true;
   }

   public Component getFailureReason(LivingEntity owner) {
      return null;
   }

   public void trigger(LivingEntity owner) {
   }

   public void untrigger(LivingEntity owner) {
   }

   public void run(LivingEntity owner) {
   }

   public boolean isPassiveEnabled() {
      return true;
   }

   public boolean shouldTrigger(PathfinderMob owner, @Nullable LivingEntity target) {
      return false;
   }

   public ResourceLocation getIcon() {
      ResourceLocation id = this.getId();
      return ResourceLocation.fromNamespaceAndPath(id.getNamespace(), "textures/skill/" + id.getPath() + ".png");
   }

   @Override
   public boolean equals(Object obj) {
      if (this == obj) {
         return true;
      } else if (obj != null && this.getClass() == obj.getClass()) {
         Skill skill = (Skill)obj;
         return this.getId().equals(skill.getId());
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return this.getId().hashCode();
   }
}
