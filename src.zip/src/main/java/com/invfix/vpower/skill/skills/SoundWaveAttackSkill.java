package com.invfix.vpower.skill.skills;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.client.animation.ModAnimations;
import com.invfix.vpower.network.PlayerAnimationPlaySyncPacket;
import com.invfix.vpower.registry.ModParticles;
import com.invfix.vpower.registry.ModSounds;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.base.Skill;
import com.invfix.vpower.skill.base.SkillType;
import com.invfix.vpower.util.IntangibilityUtil;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

public class SoundWaveAttackSkill extends Skill {
   public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "sound_wave_attack");
   private static final int START_ANIMATION_TICKS = 60;
   private static final int MIN_RELEASE_TICKS = 4;
   private static final int MAX_CHARGE_TICKS = 100;
   private static final int RELEASE_ANIMATION_TICKS = 10;
   private static final int RELEASE_PARTICLE_INTERVAL = 2;
   private static final double RANGE = 18.0;
   private static final double BASE_RADIUS = 1.0;
   private static final double RADIUS_PER_BLOCK = 0.18;
   private static final float DAMAGE_PER_HIT = 12.0F;
   private static final float MIN_CHARGE_DAMAGE_MULTIPLIER = 0.35F;
   private static final float MAX_CHARGE_DAMAGE_MULTIPLIER = 2.0F;
   private static final double KNOCKBACK_STRENGTH = 1.35;
   private static final double CHARGE_MOVEMENT_SLOWDOWN = -0.8;
   private static final ResourceLocation CHARGE_SLOWDOWN_MODIFIER_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "sound_wave_charge_slowdown");
   private static final Map<UUID, Integer> ACTIVE_TICKS = new ConcurrentHashMap<>();
   private static final Map<UUID, SoundWaveAttackSkill.ReleaseState> RELEASE_STATES = new ConcurrentHashMap<>();

   @Override
   public ResourceLocation getId() {
      return ID;
   }

   @Override
   public SkillType getType() {
      return SkillType.CHANNELED;
   }

   @Override
   public boolean requiresMastery() {
      return false;
   }

   public static void serverTick(ServerLevel level) {
      for (ServerPlayer player : level.players()) {
         try {
            tickPlayer(player, level);
         } catch (Exception var4) {
         }
      }
   }

   private static void tickPlayer(ServerPlayer player, ServerLevel level) {
      UUID playerId = player.getUUID();
      SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
      boolean active = player.isAlive() && data.hasSkill(ID.toString()) && data.isSkillActive(ID.toString());
      applyChargeSlowdown(player, active);
      if (!active) {
         stopIfNeeded(player, playerId, level, data);
         tickRelease(player, level, playerId);
      } else {
         RELEASE_STATES.remove(playerId);
         int activeTicks = ACTIVE_TICKS.getOrDefault(playerId, -1);
         if (activeTicks < 0) {
            activeTicks = 0;
            broadcastAnimation(player, ModAnimations.SOUND_WAVES_START, false, 2);
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.WARDEN_SONIC_CHARGE, SoundSource.PLAYERS, 0.9F, 1.0F);
         }

         if (activeTicks == 60) {
            broadcastAnimation(player, ModAnimations.SOUND_WAVES_ON, true, 2);
         }

         ACTIVE_TICKS.put(playerId, activeTicks + 1);
      }
   }

   private static void applyChargeSlowdown(ServerPlayer player, boolean active) {
      AttributeInstance movementSpeed = player.getAttribute(Attributes.MOVEMENT_SPEED);
      if (movementSpeed != null) {
         AttributeModifier existing = movementSpeed.getModifier(CHARGE_SLOWDOWN_MODIFIER_ID);
         if (active) {
            if (existing == null || Math.abs(existing.amount() - -0.8) > 1.0E-4) {
               movementSpeed.removeModifier(CHARGE_SLOWDOWN_MODIFIER_ID);
               movementSpeed.addTransientModifier(new AttributeModifier(CHARGE_SLOWDOWN_MODIFIER_ID, -0.8, Operation.ADD_MULTIPLIED_TOTAL));
            }
         } else if (existing != null) {
            movementSpeed.removeModifier(CHARGE_SLOWDOWN_MODIFIER_ID);
         }
      }
   }

   private static void stopIfNeeded(ServerPlayer player, UUID playerId, ServerLevel level, SkillData data) {
      Integer previousTicks = ACTIVE_TICKS.remove(playerId);
      if (previousTicks != null) {
         broadcastAnimation(player, ModAnimations.SOUND_WAVES_UP, false, 2);
         if (player.isAlive() && previousTicks >= 4) {
            beginRelease(player, playerId, level, data, previousTicks);
         }
      }
   }

   private static void beginRelease(ServerPlayer player, UUID playerId, ServerLevel level, SkillData data, int previousTicks) {
      Vec3 direction = player.getLookAngle().normalize();
      Vec3 origin = player.getEyePosition().add(direction.scale(0.7)).subtract(0.0, 0.2, 0.0);
      float chargeMultiplier = getChargeMultiplier(previousTicks);
      float chargeProgress = getChargeProgress(previousTicks);
      RELEASE_STATES.put(playerId, new SoundWaveAttackSkill.ReleaseState(origin, direction, chargeMultiplier, 0));
      damageCone(player, level, origin, direction, data, chargeMultiplier);
      level.playSound(
         null,
         player.getX(),
         player.getY(),
         player.getZ(),
         (SoundEvent)ModSounds.SOUND_WAVES_UP.get(),
         SoundSource.PLAYERS,
         0.75F + chargeProgress * 0.35F,
         1.1F - chargeProgress * 0.25F
      );
   }

   private static float getChargeProgress(int activeTicks) {
      return Math.max(0.0F, Math.min(1.0F, (float)activeTicks / 100.0F));
   }

   private static float getChargeMultiplier(int activeTicks) {
      float progress = getChargeProgress(activeTicks);
      return 0.35F + 1.65F * progress;
   }

   private static void tickRelease(ServerPlayer player, ServerLevel level, UUID playerId) {
      SoundWaveAttackSkill.ReleaseState state = RELEASE_STATES.get(playerId);
      if (state != null) {
         if (state.ticks() < 10 && player.isAlive()) {
            if (state.ticks() % 2 == 0) {
               double progress = (double)state.ticks() / 10.0;
               Vec3 pos = state.origin().add(state.direction().scale(1.0 + 18.0 * progress));
               spawnSoundWaveParticle(level, pos, state.direction(), 0.75 + progress * 0.5);
            }

            RELEASE_STATES.put(playerId, new SoundWaveAttackSkill.ReleaseState(state.origin(), state.direction(), state.chargeMultiplier(), state.ticks() + 1));
         } else {
            RELEASE_STATES.remove(playerId);
         }
      }
   }

   private static void broadcastAnimation(ServerPlayer player, ResourceLocation animation, boolean loop, int fadeTicks) {
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(
         player, new PlayerAnimationPlaySyncPacket(player.getId(), animation, loop, fadeTicks, false), new CustomPacketPayload[0]
      );
   }

   private static void spawnSoundWaveParticle(ServerLevel level, Vec3 origin, Vec3 direction, double speed) {
      level.sendParticles(ModParticles.CLAP.get(), origin.x, origin.y, origin.z, 0, direction.x, direction.y, direction.z, speed);
   }

   private static void damageCone(ServerPlayer owner, ServerLevel level, Vec3 origin, Vec3 direction, SkillData data, float chargeMultiplier) {
      Vec3 end = origin.add(direction.scale(18.0));
      AABB box = new AABB(
            Math.min(origin.x, end.x),
            Math.min(origin.y, end.y),
            Math.min(origin.z, end.z),
            Math.max(origin.x, end.x),
            Math.max(origin.y, end.y),
            Math.max(origin.z, end.z)
         )
         .inflate(4.24);
      List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, box, targetx -> isValidTarget(owner, targetx));
      float multiplier = (float)data.getDamageMultiplier(ID.toString()) / 100.0F;
      float damage = 12.0F * multiplier * chargeMultiplier;

      for (LivingEntity target : targets) {
         Vec3 center = target.position().add(0.0, (double)target.getBbHeight() * 0.5, 0.0);
         Vec3 toTarget = center.subtract(origin);
         double projected = toTarget.dot(direction);
         if (!(projected < 0.0) && !(projected > 18.0)) {
            Vec3 closestPoint = origin.add(direction.scale(projected));
            double allowedRadius = 1.0 + projected * 0.18;
            if (!(center.distanceTo(closestPoint) > allowedRadius + (double)target.getBbWidth() * 0.5)) {
               target.invulnerableTime = 0;
               target.hurtTime = 0;
               target.hurt(owner.damageSources().playerAttack(owner), damage);
               Vec3 knockback = direction.scale(1.35 * (double)Math.max(0.5F, chargeMultiplier));
               target.push(knockback.x, 0.25, knockback.z);
               target.hurtMarked = true;
            }
         }
      }
   }

   private static boolean isValidTarget(ServerPlayer owner, LivingEntity target) {
      if (target == owner || !target.isAlive() || target.isRemoved()) {
         return false;
      } else if (IntangibilityUtil.isIntangible(target)) {
         return false;
      } else {
         if (target instanceof Player player && (player.isCreative() || player.isSpectator())) {
            return false;
         }

         return !owner.isAlliedTo(target);
      }
   }

   private static record ReleaseState(Vec3 origin, Vec3 direction, float chargeMultiplier, int ticks) {
   }
}
