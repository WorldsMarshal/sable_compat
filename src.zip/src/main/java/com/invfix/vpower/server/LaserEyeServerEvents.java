package com.invfix.vpower.server;

import com.invfix.vpower.skill.skills.FireBlastSkill;
import com.invfix.vpower.skill.skills.SoundWaveAttackSkill;
import com.invfix.vpower.skill.skills.SprayWaterSkill;
import com.invfix.vpower.skill.skills.StompSkill;
import com.invfix.vpower.skill.skills.SuperJumpSkill;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent.Post;

@EventBusSubscriber(
   modid = "sable_compat"
)
public class LaserEyeServerEvents {
   @SubscribeEvent
   public static void onLevelTick(Post event) {
      if (event.getLevel() instanceof ServerLevel serverLevel) {
         SkillResourceConsumptionHandler.serverTick(serverLevel);
         LaserEyeDamageHandler.serverTick(serverLevel);
         FireBlastSkill.serverTick(serverLevel);
         SoundWaveAttackSkill.serverTick(serverLevel);
         SuperJumpSkill.serverTick(serverLevel);
         SprayWaterSkill.serverTick(serverLevel);
         StompSkill.serverTick(serverLevel);
         GrabHandler.tickLandingDamage();
         SuperSpeedHandler.serverTick(serverLevel);
         ScaleHandler.serverTick(serverLevel);
         SpeedImpactHandler.serverTick(serverLevel);
         WingFlightServerHandler.serverTick(serverLevel);
      }
   }

   @SubscribeEvent
   public static void onLivingFall(LivingFallEvent event) {
      if (event.getEntity() instanceof ServerPlayer player && SuperJumpSkill.cancelFallDamage(player)) {
         event.setCanceled(true);
      }
   }
}
