package com.invfix.vpower.server;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedData.Factory;

public class TempVFirstUseData extends SavedData {
   private static final String DATA_KEY = "theboysmod_temp_v_first_use";
   private static final String USED_PLAYERS_KEY = "UsedPlayers";
   private final Set<UUID> usedPlayers = new LinkedHashSet<>();

   public boolean hasUsed(UUID playerId) {
      return playerId != null && this.usedPlayers.contains(playerId);
   }

   public void markUsed(UUID playerId) {
      if (playerId != null && this.usedPlayers.add(playerId)) {
         this.setDirty();
      }
   }

   public static TempVFirstUseData get(MinecraftServer server) {
      return (TempVFirstUseData)server.overworld()
         .getDataStorage()
         .computeIfAbsent(new Factory<TempVFirstUseData>(TempVFirstUseData::new, TempVFirstUseData::load, DataFixTypes.LEVEL), "theboysmod_temp_v_first_use");
   }

   public static TempVFirstUseData load(CompoundTag tag, Provider provider) {
      TempVFirstUseData data = new TempVFirstUseData();
      ListTag list = tag.getList("UsedPlayers", 8);

      for (int index = 0; index < list.size(); index++) {
         try {
            data.usedPlayers.add(UUID.fromString(list.getString(index)));
         } catch (IllegalArgumentException var6) {
         }
      }

      return data;
   }

   public CompoundTag save(CompoundTag tag, Provider provider) {
      ListTag list = new ListTag();

      for (UUID playerId : this.usedPlayers) {
         list.add(StringTag.valueOf(playerId.toString()));
      }

      tag.put("UsedPlayers", list);
      return tag;
   }
}
