package com.invfix.vpower.server;

import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillConsumptionProfiles;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.FlightSkill;
import com.invfix.vpower.skill.skills.WingsSkill;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;

@EventBusSubscriber(
   modid = "sable_compat"
)
public final class WingFlightServerHandler {
   private static final SkillConsumptionProfiles.Profile PROFILE = SkillConsumptionProfiles.WINGS;
   private static final String SKILL_ID = WingsSkill.ID.toString();
   private static final String LEGACY_FLIGHT_ID = FlightSkill.ID.toString();

   private WingFlightServerHandler() {
   }

   public static void serverTick(ServerLevel level) {
      for (ServerPlayer player : level.players()) {
         try {
            if (hasWingOnlyFlight(player)) {
               player.fallDistance = 0.0F;
               if (player.isFallFlying()) {
                  if (player.onGround() || player.isInWater() || player.isUnderWater() || player.isShiftKeyDown()) {
                     player.stopFallFlying();
                     player.fallDistance = 0.0F;
                  } else if (!player.isCreative()) {
                     if (player.getFoodData().getFoodLevel() <= PROFILE.minFoodLevel()) {
                        player.stopFallFlying();
                        player.fallDistance = 0.0F;
                     } else if (player.zza > 0.0F && player.tickCount % PROFILE.intervalTicks() == 0) {
                        player.getFoodData().addExhaustion(PROFILE.exhaustionPerInterval());
                     }
                  }
               }
            }
         } catch (Exception var4) {
         }
      }
   }

   @SubscribeEvent
   public static void onLivingFall(LivingFallEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         if (hasWingOnlyFlight(player)) {
            player.fallDistance = 0.0F;
            event.setCanceled(true);
         }
      }
   }

   private static boolean hasWingOnlyFlight(ServerPlayer player) {
      try {
         SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         FleshRegenData fleshData = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
         boolean hasLegacyFlight = skillData.hasSkill(LEGACY_FLIGHT_ID) || skillData.getFireTimer() > 0;
         boolean hasBody = fleshData.getScore("Body") != 0;
         return skillData.hasSkill(SKILL_ID) && !hasLegacyFlight && hasBody;
      } catch (Exception var5) {
         return false;
      }
   }
}
