package com.invfix.vpower.server;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent.Pre;

@EventBusSubscriber
public class FireAttackHandler {
   @SubscribeEvent
   public static void onLivingDamage(Pre event) {
      if (event.getSource().getEntity() instanceof Player player) {
         SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         if (skillData.getFireTimer() > 0) {
            LivingEntity target = event.getEntity();
            if (!target.fireImmune()) {
               target.setRemainingFireTicks(100);
            }

            if (target instanceof Creeper creeper) {
               creeper.ignite();
            }
         }
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public static void onIncomingDamage(LivingIncomingDamageEvent event) {
      if (event.getEntity() instanceof Player player) {
         if (!player.level().isClientSide) {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            if (data.getFireTimer() > 0) {
               DamageSource source = event.getSource();
               if (source.is(DamageTypeTags.IS_FIRE)
                  || source.is(DamageTypes.LAVA)
                  || source.is(DamageTypes.HOT_FLOOR)
                  || source.is(DamageTypes.IN_FIRE)
                  || source.is(DamageTypes.ON_FIRE)) {
                  event.setCanceled(true);
                  if (player.isOnFire()) {
                     player.clearFire();
                  }
               }
            }
         }
      }
   }
}
