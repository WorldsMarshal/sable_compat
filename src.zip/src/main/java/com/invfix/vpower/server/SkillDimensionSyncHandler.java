package com.invfix.vpower.server;

import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.network.FireTimerSyncPacket;
import com.invfix.vpower.network.FleshRegenSyncPacket;
import com.invfix.vpower.network.FleshStrengthSyncPacket;
import com.invfix.vpower.network.SkillActiveSyncPacket;
import com.invfix.vpower.network.SkillSyncPacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.Clone;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerChangedDimensionEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
   modid = "sable_compat"
)
public class SkillDimensionSyncHandler {
   @SubscribeEvent
   public static void onPlayerChangedDimension(PlayerChangedDimensionEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         player.getServer().execute(() -> syncAfterWorldTransfer(player));
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGH
   )
   public static void onPlayerClone(Clone event) {
      if (!event.isWasDeath() && event.getEntity() instanceof ServerPlayer newPlayer && event.getOriginal() instanceof ServerPlayer oldPlayer) {
         copySkillData(oldPlayer, newPlayer);
         copyFleshData(oldPlayer, newPlayer);
         newPlayer.getServer().execute(() -> syncAfterWorldTransfer(newPlayer));
      }
   }

   private static void copySkillData(ServerPlayer oldPlayer, ServerPlayer newPlayer) {
      SkillData oldSkillData = (SkillData)oldPlayer.getData(ModSkillAttachments.SKILL_DATA.get());
      SkillData newSkillData = (SkillData)newPlayer.getData(ModSkillAttachments.SKILL_DATA.get());
      CompoundTag nbt = oldSkillData.serializeNBT(oldPlayer.registryAccess());
      newSkillData.deserializeNBT(newPlayer.registryAccess(), nbt);
   }

   private static void copyFleshData(ServerPlayer oldPlayer, ServerPlayer newPlayer) {
      FleshRegenData oldData = (FleshRegenData)oldPlayer.getData(ModAttachments.FLESH_REGEN.get());
      FleshRegenData newData = (FleshRegenData)newPlayer.getData(ModAttachments.FLESH_REGEN.get());
      newData.copyFrom(oldData.toTag());
   }

   private static void syncAfterWorldTransfer(ServerPlayer player) {
      SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
      skillData.ensureChildSkills();
      FleshStrengthHandler.refreshHealthModifier(player, skillData);
      FleshRegenTickHandler.syncToClient(player);
      SkillSyncPacket.syncToClient(player);
      SkillActiveSyncPacket.syncToClient(player);
      FleshStrengthSyncPacket.syncToClient(player);
      FireTimerSyncPacket.syncToWrappers(player);
      syncOtherPlayersTo(player);
   }

   private static void syncOtherPlayersTo(ServerPlayer receiver) {
      for (ServerPlayer otherPlayer : receiver.serverLevel().players()) {
         if (otherPlayer != receiver) {
            FleshRegenData otherFlesh = (FleshRegenData)otherPlayer.getData(ModAttachments.FLESH_REGEN.get());
            PacketDistributor.sendToPlayer(receiver, new FleshRegenSyncPacket(otherPlayer.getId(), otherFlesh.toTag()), new CustomPacketPayload[0]);
            SkillActiveSyncPacket.syncStateToPlayer(otherPlayer, receiver);
            SkillData otherSkill = (SkillData)otherPlayer.getData(ModSkillAttachments.SKILL_DATA.get());
            PacketDistributor.sendToPlayer(receiver, new FireTimerSyncPacket(otherPlayer.getId(), otherSkill.getFireTimer()), new CustomPacketPayload[0]);
         }
      }
   }

   private SkillDimensionSyncHandler() {
   }
}
