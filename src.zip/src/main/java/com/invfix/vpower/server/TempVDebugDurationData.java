package com.invfix.vpower.server;

import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedData.Factory;

public class TempVDebugDurationData extends SavedData {
   private static final String DATA_KEY = "theboysmod_temp_v_debug_duration";
   private static final String LEGACY_OVERRIDE_TICKS_KEY = "OverrideTicks";
   private static final String NEXT_TICKS_KEY = "NextTicks";
   private static final String PERSISTENT_OVERRIDE_TICKS_KEY = "PersistentOverrideTicks";
   private int nextTicks = -1;
   private int persistentOverrideTicks = -1;

   public static TempVDebugDurationData get(MinecraftServer server) {
      return (TempVDebugDurationData)server.overworld()
         .getDataStorage()
         .computeIfAbsent(new Factory<TempVDebugDurationData>(TempVDebugDurationData::new, TempVDebugDurationData::load, DataFixTypes.LEVEL), "theboysmod_temp_v_debug_duration");
   }

   public static int consumeDurationTicksForInjection(MinecraftServer server) {
      return server == null ? 28800 : get(server).consumeDurationTicksForInjection();
   }

   public int consumeDurationTicksForInjection() {
      if (this.hasNextDuration()) {
         int ticks = this.nextTicks;
         this.nextTicks = -1;
         this.setDirty();
         return ticks;
      } else {
         return this.getEffectiveDurationTicks();
      }
   }

   public int getEffectiveDurationTicks() {
      if (this.hasNextDuration()) {
         return this.nextTicks;
      } else {
         return this.hasPersistentOverride() ? this.persistentOverrideTicks : 28800;
      }
   }

   public boolean hasNextDuration() {
      return this.nextTicks > 0;
   }

   public int getNextTicks() {
      return this.nextTicks;
   }

   public void setNextTicks(int ticks) {
      int clamped = clampDurationTicks(ticks);
      if (this.nextTicks != clamped) {
         this.nextTicks = clamped;
         this.setDirty();
      }
   }

   public void clearNextTicks() {
      if (this.nextTicks != -1) {
         this.nextTicks = -1;
         this.setDirty();
      }
   }

   public boolean hasPersistentOverride() {
      return this.persistentOverrideTicks > 0;
   }

   public int getPersistentOverrideTicks() {
      return this.persistentOverrideTicks;
   }

   public void setPersistentOverrideTicks(int ticks) {
      int clamped = clampDurationTicks(ticks);
      if (this.persistentOverrideTicks != clamped) {
         this.persistentOverrideTicks = clamped;
         this.setDirty();
      }
   }

   public void clearPersistentOverride() {
      if (this.persistentOverrideTicks != -1) {
         this.persistentOverrideTicks = -1;
         this.setDirty();
      }
   }

   public void clearAllOverrides() {
      boolean changed = this.nextTicks != -1 || this.persistentOverrideTicks != -1;
      this.nextTicks = -1;
      this.persistentOverrideTicks = -1;
      if (changed) {
         this.setDirty();
      }
   }

   public static int clampDurationTicks(int ticks) {
      return Math.max(1, Math.min(1728000, ticks));
   }

   public static TempVDebugDurationData load(CompoundTag tag, Provider provider) {
      TempVDebugDurationData data = new TempVDebugDurationData();
      int legacyTicks = tag.contains("OverrideTicks") ? tag.getInt("OverrideTicks") : -1;
      data.nextTicks = tag.contains("NextTicks") ? tag.getInt("NextTicks") : legacyTicks;
      data.persistentOverrideTicks = tag.contains("PersistentOverrideTicks") ? tag.getInt("PersistentOverrideTicks") : -1;
      data.nextTicks = normalizeDurationTicks(data.nextTicks);
      data.persistentOverrideTicks = normalizeDurationTicks(data.persistentOverrideTicks);
      return data;
   }

   public CompoundTag save(CompoundTag tag, Provider provider) {
      tag.putInt("NextTicks", this.nextTicks);
      tag.putInt("PersistentOverrideTicks", this.persistentOverrideTicks);
      return tag;
   }

   private static int normalizeDurationTicks(int ticks) {
      return ticks > 0 ? clampDurationTicks(ticks) : -1;
   }
}
