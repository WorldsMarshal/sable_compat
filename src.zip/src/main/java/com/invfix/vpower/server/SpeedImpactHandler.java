package com.invfix.vpower.server;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.registry.ModParticles;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.FlightSkill;
import com.invfix.vpower.skill.skills.SpeedSkill;
import com.invfix.vpower.util.IntangibilityUtil;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;

@EventBusSubscriber(
   modid = "sable_compat"
)
public class SpeedImpactHandler {
   private static final String SPEED_SKILL_ID = SpeedSkill.ID.toString();
   private static final String FLIGHT_SKILL_ID = FlightSkill.ID.toString();
   public static volatile boolean SPEED_IMPACT_ACTIVE = false;
   private static final double HIT_RADIUS = 0.6;
   private static final double MIN_MOVEMENT = 0.1;
   private static final float DAMAGE_MULTIPLIER = 30.0F;
   private static final float MIN_DAMAGE = 8.0F;
   private static final float MAX_DAMAGE = 100.0F;
   private static final float FALLBACK_BLOOD_BURST_DAMAGE = 48.0F;
   private static final int HIT_COOLDOWN = 10;
   private static final Map<Integer, Vec3> PREV_POSITIONS = new ConcurrentHashMap<>();
   private static final Map<Integer, Map<Integer, Long>> HIT_COOLDOWNS = new ConcurrentHashMap<>();
   private static final Map<Integer, Double> ENTITY_SPEEDS = new ConcurrentHashMap<>();
   private static final Map<Integer, SpeedImpactHandler.PendingBloodBurst> PENDING_BLOOD_BURSTS = new ConcurrentHashMap<>();
   private static long tickCounter = 0L;

   public static void serverTick(ServerLevel level) {
      tickCounter++;
      PENDING_BLOOD_BURSTS.entrySet().removeIf(entry -> entry.getValue().expireTick() < tickCounter);

      for (ServerPlayer player : level.players()) {
         int playerId = player.getId();
         Vec3 currentPos = player.position();

         try {
            Vec3 prevPos = PREV_POSITIONS.get(playerId);
            PREV_POSITIONS.put(playerId, currentPos);
            if (prevPos != null) {
               double dx = currentPos.x - prevPos.x;
               double dy = currentPos.y - prevPos.y;
               double dz = currentPos.z - prevPos.z;
               double horizontalDist = Math.sqrt(dx * dx + dz * dz);
               double totalDist = Math.sqrt(dx * dx + dy * dy + dz * dz);
               ENTITY_SPEEDS.put(playerId, horizontalDist);
               SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
               boolean shouldDamage = false;
               boolean speedImpact = false;
               float damage = 0.0F;
               if (data.hasSkill(SPEED_SKILL_ID)
                  && data.isSkillActive(SPEED_SKILL_ID)
                  && data.getSpeedAdjustment() > 0
                  && player.isSprinting()
                  && horizontalDist > 0.1) {
                  double speedAttr = player.getAttributeValue(Attributes.MOVEMENT_SPEED);
                  damage = (float)(speedAttr * 30.0);
                  shouldDamage = true;
                  speedImpact = true;
               }

               if (data.hasSkill(FLIGHT_SKILL_ID) && data.isSkillActive(FLIGHT_SKILL_ID) && totalDist > 0.1) {
                  float flyDamage = (float)(totalDist * 200.0);
                  damage = Math.max(damage, flyDamage);
                  shouldDamage = true;
               }

               if (shouldDamage) {
                  damage = Math.max(8.0F, Math.min(100.0F, damage));
                  AABB hitBox = player.getBoundingBox().inflate(0.6);
                  List<Entity> entities = level.getEntities(player, hitBox, e -> e instanceof LivingEntity && e.isAlive() && e != player);
                  if (!entities.isEmpty()) {
                     Map<Integer, Long> playerCooldowns = HIT_COOLDOWNS.computeIfAbsent(playerId, k -> new ConcurrentHashMap<>());
                     Vec3 moveDir = new Vec3(dx, dy, dz).normalize();

                     for (Entity entity : entities) {
                        int entityId = entity.getId();
                        long lastHit = playerCooldowns.getOrDefault(entityId, 0L);
                        if (tickCounter - lastHit >= 10L) {
                           if (entity instanceof ServerPlayer) {
                              ServerPlayer otherPlayer = (ServerPlayer)entity;
                              SkillData otherData = (SkillData)otherPlayer.getData(ModSkillAttachments.SKILL_DATA.get());
                              if (otherData.hasSkill(SPEED_SKILL_ID)
                                 && otherData.isSkillActive(SPEED_SKILL_ID)
                                 && otherData.getSpeedAdjustment() > 0
                                 && isEntityMovingFast(otherPlayer.getId())
                                 && otherData.getSuperSpeedLevel() >= data.getSuperSpeedLevel()) {
                                 continue;
                              }
                           }


                           LivingEntity living = (LivingEntity)entity;
                           if (!IntangibilityUtil.isIntangible(living)) {
                              SPEED_IMPACT_ACTIVE = true;

                              boolean hurtApplied;
                              try {
                                 hurtApplied = living.hurt(player.damageSources().playerAttack(player), damage);
                              } finally {
                                 SPEED_IMPACT_ACTIVE = false;
                              }

                              if (speedImpact && hurtApplied) {
                                 queueBloodBurst(living, moveDir, damage);
                              }

                              living.setDeltaMovement(living.getDeltaMovement().add(moveDir.x * 1.5, 0.3, moveDir.z * 1.5));
                              living.hurtMarked = true;
                              playerCooldowns.put(entityId, tickCounter);
                           }
                        }
                     }

                     playerCooldowns.entrySet().removeIf(entry -> tickCounter - entry.getValue() > 100L);
                  }
               }
            }
         } catch (Exception var44) {
         }
      }

      if (tickCounter % 200L == 0L) {
         HIT_COOLDOWNS.entrySet().removeIf(entry -> entry.getValue().isEmpty());
         PREV_POSITIONS.keySet().removeIf(id -> level.players().stream().noneMatch(p -> p.getId() == id));
      }

   }

   private static boolean isEntityMovingFast(int entityId) {
      Double speed = ENTITY_SPEEDS.get(entityId);
      return speed != null && speed >= 0.1;
   }

   @SubscribeEvent
   public static void onLivingDeath(LivingDeathEvent event) {
      if (event.getEntity().level() instanceof ServerLevel level) {
         SpeedImpactHandler.PendingBloodBurst pending = PENDING_BLOOD_BURSTS.remove(event.getEntity().getId());
         if (pending != null) {
            spawnBloodBurst(level, event.getEntity(), pending.moveDir(), pending.damage());
         }
      }
   }

   public static void queueBloodBurst(LivingEntity target, Vec3 moveDir, float damage) {
      if (target.level() instanceof ServerLevel level) {
         PENDING_BLOOD_BURSTS.put(target.getId(), new SpeedImpactHandler.PendingBloodBurst(moveDir, damage, tickCounter + 4L));
         if (target.isDeadOrDying() || !target.isAlive() || target.getHealth() <= 0.0F) {
            PENDING_BLOOD_BURSTS.remove(target.getId());
            spawnBloodBurst(level, target, moveDir, damage);
         }
      }
   }



   private static void spawnBloodBurst(ServerLevel level, LivingEntity target, Vec3 moveDir, float damage) {
      Vec3 forward = moveDir.lengthSqr() > 1.0E-4 ? moveDir.normalize() : Vec3.ZERO;
      Vec3 side = forward.lengthSqr() > 1.0E-4 ? new Vec3(-forward.z, 0.0, forward.x) : Vec3.ZERO;
      int count = Mth.clamp(Mth.ceil(damage * 1.15F), 36, 96);
      double halfWidth = Math.max(0.22, (double)target.getBbWidth() * 0.6);
      double baseY = target.getY() + Math.max(0.35, (double)target.getBbHeight() * 0.5);

      for (int i = 0; i < count; i++) {
         double px = target.getX() + (level.random.nextDouble() - 0.5) * halfWidth;
         double py = baseY + (level.random.nextDouble() - 0.5) * (double)target.getBbHeight() * 0.35;
         double pz = target.getZ() + (level.random.nextDouble() - 0.5) * halfWidth;
         double vx = (level.random.nextDouble() - 0.5) * 0.16;
         double vy = 0.12 + level.random.nextDouble() * 0.24;
         double vz = (level.random.nextDouble() - 0.5) * 0.16;
         if (forward.lengthSqr() > 1.0E-4) {
            double forwardSpeed = 0.22 + level.random.nextDouble() * 0.36;
            double sideSpeed = (level.random.nextDouble() - 0.5) * 0.3;
            vx += forward.x * forwardSpeed + side.x * sideSpeed;
            vz += forward.z * forwardSpeed + side.z * sideSpeed;
         }

         level.sendParticles(ModParticles.BLOOD.get(), px, py, pz, 0, vx, vy, vz, 1.0);
      }
   }

   private static record PendingBloodBurst(Vec3 moveDir, float damage, long expireTick) {
   }
}
