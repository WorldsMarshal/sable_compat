package com.invfix.vpower.server;

import com.invfix.vpower.network.FleshStrengthSyncPacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.FleshStrengthSkill;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent.Pre;

@EventBusSubscriber(
   modid = "sable_compat"
)
public class FleshStrengthHandler {
   private static final String SKILL_ID = FleshStrengthSkill.ID.toString();
   private static final ResourceLocation HEALTH_MODIFIER_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "flesh_strength_hp");

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public static void onIncomingDamage(LivingIncomingDamageEvent event) {
      if (event.getEntity() instanceof Player player) {
         if (!player.level().isClientSide) {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            if (data.hasSkill(SKILL_ID)) {
               int level = data.getFleshStrengthLevel();
               DamageSource source = event.getSource();
               if (level >= 2 && isFireDamage(source)) {
                  event.setCanceled(true);
                  if (player.isOnFire()) {
                     player.clearFire();
                  }
               } else if (level >= 3 && source.is(DamageTypeTags.IS_PROJECTILE)) {
                  Entity projectile = source.getDirectEntity();
                  if (projectile != null) {
                     Vec3 motion = projectile.getDeltaMovement();
                     projectile.setDeltaMovement(motion.scale(-1.2));
                     player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 1.0F, 1.5F);
                     if (player.level() instanceof ServerLevel serverLevel) {
                        serverLevel.sendParticles(ParticleTypes.CRIT, projectile.getX(), projectile.getY(), projectile.getZ(), 5, 0.1, 0.1, 0.1, 0.2);
                     }
                  }

                  event.setCanceled(true);
               }
            }
         }
      }
   }

   private static boolean isFireDamage(DamageSource source) {
      return source.is(DamageTypeTags.IS_FIRE)
         || source.is(DamageTypes.LAVA)
         || source.is(DamageTypes.HOT_FLOOR)
         || source.is(DamageTypes.IN_FIRE)
         || source.is(DamageTypes.ON_FIRE);
   }

   @SubscribeEvent(
      priority = EventPriority.NORMAL
   )
   public static void onLivingDamage(Pre event) {
      if (event.getEntity() instanceof Player player) {
         if (!player.level().isClientSide) {
            if (!event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
               SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
               if (data.hasSkill(SKILL_ID)) {
                  float incoming = event.getNewDamage();
                  if (!(incoming <= 0.0F)) {
                     if (incoming <= data.getDamageThreshold()) {
                        event.setNewDamage(0.0F);
                     } else {
                        if (player instanceof ServerPlayer serverPlayer) {
                           FleshStrengthSyncPacket.syncToClient(serverPlayer);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public static void applyHealthModifier(ServerPlayer player, float extraHp) {
      if (player != null) {
         setHealthModifier(player, extraHp, false);
         if (Float.isNaN(extraHp)) {
            AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
            if (attr != null) {
               attr.removeModifier(HEALTH_MODIFIER_ID);
               if (extraHp > 0.0F) {
                  attr.addPermanentModifier(new AttributeModifier(HEALTH_MODIFIER_ID, (double)extraHp, Operation.ADD_VALUE));
                  if (!(player.getHealth() < player.getMaxHealth())) {
                     player.setHealth(player.getMaxHealth());
                  }
               }
            }
         }
      }
   }

   public static void applyHealthModifier(ServerPlayer player, float extraHp, boolean fillHealth) {
      if (player != null) {
         setHealthModifier(player, extraHp, fillHealth);
      }
   }

   public static void removeHealthModifier(ServerPlayer player) {
      if (player != null) {
         clearHealthModifier(player);
         if (player.tickCount == Integer.MIN_VALUE) {
            AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
            if (attr != null) {
               attr.removeModifier(HEALTH_MODIFIER_ID);
               if (player.getHealth() <= player.getMaxHealth()) {
                  return;
               }

               if (player.getHealth() > player.getMaxHealth()) {
                  player.setHealth(player.getMaxHealth());
               }
            }
         }
      }
   }

   private static void setHealthModifier(ServerPlayer player, float extraHp, boolean fillHealth) {
      AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
      if (attr != null) {
         attr.removeModifier(HEALTH_MODIFIER_ID);
         if (extraHp > 0.0F) {
            attr.addPermanentModifier(new AttributeModifier(HEALTH_MODIFIER_ID, (double)extraHp, Operation.ADD_VALUE));
         }

         if (fillHealth && extraHp > 0.0F) {
            player.setHealth(player.getMaxHealth());
         } else if (player.getHealth() > player.getMaxHealth()) {
            player.setHealth(player.getMaxHealth());
         }
      }
   }

   private static void clearHealthModifier(ServerPlayer player) {
      AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
      if (attr != null) {
         attr.removeModifier(HEALTH_MODIFIER_ID);
         if (player.getHealth() > player.getMaxHealth()) {
            player.setHealth(player.getMaxHealth());
         }
      }
   }

   public static void refreshHealthModifier(ServerPlayer player, SkillData data) {
      refreshHealthModifier(player, data, false);
   }

   public static void refreshHealthModifier(ServerPlayer player, SkillData data, boolean fillHealth) {
      if (player != null) {
         if (data != null && data.hasSkill(SKILL_ID)) {
            applyHealthModifier(player, data.getMaxShieldHp(), fillHealth);
         } else {
            removeHealthModifier(player);
         }

         forceSync(player);
      }
   }

   public static void forceSync(ServerPlayer player) {
      FleshStrengthSyncPacket.syncToClient(player);
   }
}
