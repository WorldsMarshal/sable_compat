package com.invfix.vpower.server;

import com.invfix.threatmode.ThreatModeState;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.network.LaserEyeHitPosSyncPacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.LaserEyeSkill;
import com.invfix.vpower.util.IntangibilityUtil;
import com.invfix.vpower.util.LaserEyeGeometry;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.neoforged.neoforge.network.PacketDistributor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LaserEyeDamageHandler {
   private static final Logger LOGGER = LoggerFactory.getLogger(LaserEyeDamageHandler.class);
   private static final String LASER_EYE_ID = LaserEyeSkill.ID.toString();
   private static final int DAMAGE_INTERVAL = 5;
   private static final int FIRE_SECONDS = 2;
   private static final int CLIENT_HITPOS_TTL = 4;
   private static final int VISUAL_SYNC_INTERVAL = 2;
   private static final float MAX_DISTANCE = 500.0F;
   private static final float HIT_RADIUS = 0.5F;
   private static final float BEAM_EXTEND_SPEED = 0.15F;
   private static final Map<UUID, Integer> LASER_ACTIVE_TICKS = new ConcurrentHashMap<>();
   private static final Map<UUID, LaserEyeDamageHandler.SyncedHitPos> CLIENT_HIT_POSITIONS = new ConcurrentHashMap<>();

   private LaserEyeDamageHandler() {
   }

   public static void serverTick(ServerLevel level) {
      for (ServerPlayer player : level.players()) {
         try {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            if (data.hasSkill(LASER_EYE_ID) && data.isSkillActive(LASER_EYE_ID)) {
               int activeTicks = LASER_ACTIVE_TICKS.getOrDefault(player.getUUID(), 0) + 1;
               LASER_ACTIVE_TICKS.put(player.getUUID(), activeTicks);
               if (activeTicks == 1 || player.tickCount % 2 == 0) {
                  syncVisualBeam(player);
               }

               if (player.tickCount % 5 == 0) {
                  processLaserDamage(player, activeTicks);
               }
            } else {
               LASER_ACTIVE_TICKS.remove(player.getUUID());
               CLIENT_HIT_POSITIONS.remove(player.getUUID());
            }
         } catch (Exception var5) {
         }
      }
   }

   private static void syncVisualBeam(ServerPlayer player) {
      // Playful mode (клавиша Threatening/Playful, ThreatModeState): глаза светятся, луча для других нет
      if (ThreatModeState.isHeld(player)) {
         return;
      }
      Vec3 eyePos = LaserEyeGeometry.getDynamicEyeBase(player, 1.0F);
      Vec3 lookVec = player.getLookAngle();
      Vec3 actualEnd = resolveBeamEnd(player, eyePos, lookVec);
      LaserEyeHitPosSyncPacket packet = new LaserEyeHitPosSyncPacket(player.getId(), actualEnd.x, actualEnd.y, actualEnd.z);
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, packet, new CustomPacketPayload[0]);
   }

   public static void updateClientHitPos(ServerPlayer player, Vec3 hitPos) {
      if (player != null && hitPos != null) {
         CLIENT_HIT_POSITIONS.put(player.getUUID(), new LaserEyeDamageHandler.SyncedHitPos(hitPos, player.level().getGameTime() + 4L));
      }
   }

   private static void processLaserDamage(ServerPlayer player, int activeTicks) {
      // Playful mode: без урона (как у Heat Vision)
      if (ThreatModeState.isHeld(player)) {
         return;
      }
      Vec3 eyePos = LaserEyeGeometry.getDynamicEyeBase(player, 1.0F);
      Vec3 lookVec = player.getLookAngle();
      Vec3 actualEnd = resolveBeamEnd(player, eyePos, lookVec);
      Vec3 beamVector = actualEnd.subtract(eyePos);
      double fullDistance = beamVector.length();
      if (!(fullDistance < 1.0E-4)) {
         Vec3 beamDir = beamVector.scale(1.0 / fullDistance);
         float beamValue = Math.min((float)activeTicks * 0.15F, 1.0F);
         double currentBeamReach = fullDistance * (double)beamValue;
         Vec3 currentBeamEnd = eyePos.add(beamDir.scale(currentBeamReach));
         AABB searchBox = LaserEyeGeometry.createBeamSearchBox(eyePos, currentBeamEnd, 0.5);
         List<Entity> entities = player.level()
            .getEntities(
               player,
               searchBox,
               entityx -> entityx instanceof LivingEntity && entityx != player && entityx.isAlive() && !IntangibilityUtil.isIntangible(entityx)
            );
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         float baseDamage = data.getLaserEyeBaseDamage();
         float multiplier = (float)data.getDamageMultiplier(LASER_EYE_ID) / 100.0F;
         float actualDamage = Math.min(baseDamage * multiplier, 20.0F);

         for (Entity entity : entities) {
            if (entity instanceof LivingEntity) {
               LivingEntity living = (LivingEntity)entity;
               if (!IntangibilityUtil.isIntangible(living)) {
                  Vec3 hitPoint = LaserEyeGeometry.clipInflatedBox(eyePos, currentBeamEnd, living.getBoundingBox(), 0.5);
                  if (hitPoint != null) {
                     if (player.tickCount % 20 == 0) {
                        LOGGER.info(
                           "[LaserDmg] player={} level={} baseDmg={} multiplier={}% actualDmg={} beamReach={}/{} target={}",
                           new Object[]{
                              player.getName().getString(),
                              data.getLaserEyeLevel(),
                              baseDamage,
                              (int)(multiplier * 100.0F),
                              actualDamage,
                              String.format("%.1f", currentBeamReach),
                              String.format("%.1f", fullDistance),
                              living.getName().getString()
                           }
                        );
                     }

                     living.invulnerableTime = 0;
                     living.hurtTime = 0;
                     living.hurt(player.damageSources().playerAttack(player), actualDamage);
                     living.igniteForSeconds(2.0F);
                  }
               }
            }
         }

         burnItemEntities(player, eyePos, currentBeamEnd, searchBox);
      }
   }

   private static void burnItemEntities(ServerPlayer player, Vec3 origin, Vec3 currentBeamEnd, AABB searchBox) {
      for (ItemEntity item : player.level()
         .getEntitiesOfClass(ItemEntity.class, searchBox, itemx -> !itemx.isRemoved() && !itemx.getItem().isEmpty() && !itemx.fireImmune())) {
         Vec3 hitPoint = LaserEyeGeometry.clipInflatedBox(origin, currentBeamEnd, item.getBoundingBox(), 0.5);
         if (hitPoint != null) {
            item.setRemainingFireTicks(40);
            player.level()
               .playSound(
                  null,
                  item.getX(),
                  item.getY(),
                  item.getZ(),
                  SoundEvents.GENERIC_BURN,
                  SoundSource.NEUTRAL,
                  0.45F,
                  1.7F + player.getRandom().nextFloat() * 0.25F
               );
            item.discard();
         }
      }
   }

   private static Vec3 resolveBeamEnd(ServerPlayer player, Vec3 origin, Vec3 lookVec) {
      Vec3 fallbackEnd = clipToBlock(player, origin, lookVec);
      LaserEyeDamageHandler.SyncedHitPos synced = CLIENT_HIT_POSITIONS.get(player.getUUID());
      if (synced == null) {
         return fallbackEnd;
      } else if (player.level().getGameTime() > synced.expireGameTime()) {
         CLIENT_HIT_POSITIONS.remove(player.getUUID());
         return fallbackEnd;
      } else {
         Vec3 toSynced = synced.hitPos().subtract(origin);
         double distance = toSynced.length();
         if (!(distance < 0.05) && !(distance > 501.0)) {
            Vec3 normalizedLook = lookVec.lengthSqr() > 1.0E-6 ? lookVec.normalize() : Vec3.ZERO;
            Vec3 syncedDir = toSynced.scale(1.0 / distance);
            return normalizedLook != Vec3.ZERO && syncedDir.dot(normalizedLook) < 0.7 ? fallbackEnd : synced.hitPos();
         } else {
            return fallbackEnd;
         }
      }
   }

   private static Vec3 clipToBlock(ServerPlayer player, Vec3 origin, Vec3 lookVec) {
      Vec3 endPos = origin.add(lookVec.scale(500.0));
      BlockHitResult blockHit = player.level().clip(new ClipContext(origin, endPos, Block.COLLIDER, Fluid.NONE, player));
      return blockHit.getType() != Type.MISS ? blockHit.getLocation() : endPos;
   }

   private static record SyncedHitPos(Vec3 hitPos, long expireGameTime) {
   }
}
