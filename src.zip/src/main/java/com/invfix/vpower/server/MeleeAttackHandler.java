package com.invfix.vpower.server;

import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.DiamondClawsExtensionSkill;
import com.invfix.vpower.skill.skills.DiamondClawsSkill;
import com.invfix.vpower.skill.skills.LaserEyeSkill;
import com.invfix.vpower.skill.skills.SuperStrengthSkill;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

@EventBusSubscriber(
   modid = "sable_compat"
)
public class MeleeAttackHandler {
   private static final String SUPER_STRENGTH_ID = SuperStrengthSkill.ID.toString();
   private static final String DIAMOND_CLAWS_ID = DiamondClawsSkill.ID.toString();
   private static final String DIAMOND_CLAWS_EXTENSION_ID = DiamondClawsExtensionSkill.ID.toString();
   private static final float DIAMOND_CLAWS_BASE_DAMAGE_BONUS = 6.0F;

   @SubscribeEvent(
      priority = EventPriority.HIGH
   )
   public static void onIncomingDamage(LivingIncomingDamageEvent event) {
      try {
         DamageSource source = event.getSource();
         if (!(source.getEntity() instanceof LivingEntity attacker)) {
            return;
         }

         if (source.getDirectEntity() != attacker) {
            return;
         }

         SkillData data = (SkillData)attacker.getData(ModSkillAttachments.SKILL_DATA.get());
         String laserEyeId = LaserEyeSkill.ID.toString();
         if (data.hasSkill(laserEyeId) && attacker instanceof Player && data.isSkillActive(laserEyeId)) {
            return;
         }

         if (SpeedImpactHandler.SPEED_IMPACT_ACTIVE) {
            return;
         }

         if (EggShellServerHandler.EGG_SHELL_IMPACT_ACTIVE) {
            return;
         }

         int pct = data.getMeleeDamageMultiplier();
         float multiplier = (float)pct / 100.0F;
         float baseDamage = data.hasSkill(SUPER_STRENGTH_ID) ? data.getBasePunchDamage() : event.getAmount();
         if (hasExtendedClaws(attacker, data)) {
            int strengthLevel = data.hasSkill(SUPER_STRENGTH_ID) ? data.getSuperStrengthLevel() : 0;
            baseDamage += 6.0F + (float)strengthLevel * 2.0F;
         }

         if (data.hasSkill(SUPER_STRENGTH_ID) || pct != 100 || baseDamage != event.getAmount()) {
            event.setAmount(baseDamage * multiplier);
         }
      } catch (Exception var10) {
      }
   }

   private static boolean hasExtendedClaws(LivingEntity attacker, SkillData data) {
      return attacker instanceof Player player
         ? DiamondClawsMiningHandler.hasExtendedClaws(player)
         : data.hasSkill(DIAMOND_CLAWS_ID)
            && data.hasSkill(DIAMOND_CLAWS_EXTENSION_ID)
            && data.isSkillActive(DIAMOND_CLAWS_EXTENSION_ID)
            && hasUsableClawHand(attacker);
   }

   private static boolean hasUsableClawHand(LivingEntity entity) {
      try {
         FleshRegenData fleshData = (FleshRegenData)entity.getData(ModAttachments.FLESH_REGEN.get());
         return fleshData.getScore("Right.Hand") != 0 || fleshData.getScore("Left.Hand") != 0;
      } catch (Exception var2) {
         return true;
      }
   }
}
