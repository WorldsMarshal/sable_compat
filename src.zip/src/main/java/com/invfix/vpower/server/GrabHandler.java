package com.invfix.vpower.server;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import com.invfix.vpower.VPower;
import com.invfix.vpower.network.GrabSyncPacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.GrabSkill;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

public class GrabHandler {
   private static final String GRAB_ID = GrabSkill.ID.toString();
   private static final Map<UUID, Integer> GRABBED_ENTITIES = new ConcurrentHashMap<>();
   private static final List<GrabHandler.ThrownTracker> THROWN_TRACKING = new CopyOnWriteArrayList<>();

   public static void handleGrab(ServerPlayer player) {
      SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
      if (data.hasSkill(GRAB_ID)) {
         if (!GRABBED_ENTITIES.containsKey(player.getUUID())) {
            double reachDistance = player.entityInteractionRange() + 1.0;
            Vec3 eyePos = player.getEyePosition();
            Vec3 lookVec = player.getLookAngle();
            Vec3 endPos = eyePos.add(lookVec.scale(reachDistance));
            double searchRadius = 2.0;
            AABB searchBox = new AABB(
               Math.min(eyePos.x, endPos.x) - searchRadius,
               Math.min(eyePos.y, endPos.y) - searchRadius,
               Math.min(eyePos.z, endPos.z) - searchRadius,
               Math.max(eyePos.x, endPos.x) + searchRadius,
               Math.max(eyePos.y, endPos.y) + searchRadius,
               Math.max(eyePos.z, endPos.z) + searchRadius
            );
            List<LivingEntity> potentialTargets = player.level()
               .getEntitiesOfClass(LivingEntity.class, searchBox, entityx -> entityx != player && entityx.isAlive());
            LivingEntity target = null;
            double closestDistance = Double.MAX_VALUE;

            for (LivingEntity entity : potentialTargets) {
               AABB entityBox = entity.getBoundingBox().inflate(0.3);
               Optional<Vec3> hitResult = entityBox.clip(eyePos, endPos);
               if (hitResult.isPresent()) {
                  double dist = eyePos.distanceToSqr(hitResult.get());
                  if (dist < closestDistance) {
                     closestDistance = dist;
                     target = entity;
                  }
               }
            }

            if (target != null) {
               GRABBED_ENTITIES.put(player.getUUID(), target.getId());
               teleportEntityToHand(player, target);
               PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                  player, new GrabSyncPacket(player.getId(), target.getId(), true), new CustomPacketPayload[0]
               );
               player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.PLAYER_ATTACK_WEAK, SoundSource.PLAYERS, 1.0F, 0.6F);
               VPower.LOGGER.debug("[Grab] {} grabbed entity: {}", player.getGameProfile().getName(), target.getName().getString());
            }
         }
      }
   }

   public static void handleHoldTick(ServerPlayer player) {
      Integer entityId = GRABBED_ENTITIES.get(player.getUUID());
      if (entityId != null) {
         Entity entity = player.level().getEntity(entityId);
         if (entity != null && entity.isAlive()) {
            teleportEntityToHand(player, entity);
            entity.setDeltaMovement(Vec3.ZERO);
            entity.fallDistance = 0.0F;
            if (entity instanceof LivingEntity living) {
               living.hurtTime = 0;
            }
         } else {
            handleRelease(player);
         }
      }
   }

   public static void handleThrow(ServerPlayer player) {
      Integer entityId = GRABBED_ENTITIES.remove(player.getUUID());
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(
         player, new GrabSyncPacket(player.getId(), entityId != null ? entityId : -1, false), new CustomPacketPayload[0]
      );
      if (entityId != null) {
         Entity entity = player.level().getEntity(entityId);
         if (entity != null && entity.isAlive()) {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            float grabMultiplier = (float)data.getDamageMultiplier(GrabSkill.ID.toString()) / 100.0F;
            Vec3 lookVec = player.getLookAngle();
            double throwSpeed = 2.5 * (double)grabMultiplier;
            entity.setDeltaMovement(lookVec.scale(throwSpeed));
            entity.hurtMarked = true;
            if (player.level() instanceof ServerLevel serverLevel) {
               THROWN_TRACKING.add(new GrabHandler.ThrownTracker(entity.getId(), player.getId(), serverLevel, serverLevel.getGameTime(), grabMultiplier));
            }

            player.level().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1.0F, 0.8F);
            VPower.LOGGER.debug("[Grab] {} threw entity", player.getGameProfile().getName());
         }
      }
   }

   public static void handleRelease(ServerPlayer player) {
      Integer entityId = GRABBED_ENTITIES.remove(player.getUUID());
      PacketDistributor.sendToPlayersTrackingEntityAndSelf(
         player, new GrabSyncPacket(player.getId(), entityId != null ? entityId : -1, false), new CustomPacketPayload[0]
      );
      if (entityId != null) {
         Entity entity = player.level().getEntity(entityId);
         if (entity != null) {
            entity.setDeltaMovement(0.0, -0.1, 0.0);
            entity.hurtMarked = true;
         }

         VPower.LOGGER.debug("[Grab] {} gently released entity", player.getGameProfile().getName());
      }
   }

   private static void teleportEntityToHand(ServerPlayer player, Entity entity) {
      Vec3 eyePos = player.getEyePosition();
      Vec3 lookVec = player.getLookAngle();
      Vec3 handPos = eyePos.add(lookVec.scale(1.5));
      entity.teleportTo(handPos.x, handPos.y - (double)entity.getBbHeight() * 0.5, handPos.z);
      entity.setDeltaMovement(Vec3.ZERO);
      entity.fallDistance = 0.0F;
   }

   public static void tickLandingDamage() {
      THROWN_TRACKING.removeIf(tracker -> {
         Entity entity = tracker.level.getEntity(tracker.entityId);
         if (entity != null && !entity.isRemoved()) {
            long elapsed = tracker.level.getGameTime() - tracker.throwTick;
            if (elapsed > 100L) {
               return true;
            } else if (elapsed < 3L) {
               return false;
            } else if (!entity.onGround() && !entity.isInWater()) {
               return false;
            } else {
               if (entity instanceof LivingEntity living) {
                  Entity thrower = tracker.level.getEntity(tracker.throwerId);
                  living.invulnerableTime = 0;
                  living.hurtTime = 0;
                  if (thrower instanceof ServerPlayer sp) {
                     living.hurt(sp.damageSources().playerAttack(sp), 20.0F * tracker.damageMultiplier);
                  } else {
                     living.hurt(tracker.level.damageSources().fall(), 20.0F * tracker.damageMultiplier);
                  }
               }

               double x = entity.getX();
               double y = entity.getY();
               double z = entity.getZ();
               float w = entity.getBbWidth();
               tracker.level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y + 0.2, z, 30, (double)w * 1.5, 0.4, (double)w * 1.5, 0.06);
               tracker.level.sendParticles(ParticleTypes.CLOUD, x, y + 0.3, z, 20, (double)w, 0.5, (double)w, 0.04);
               tracker.level.playSound(null, x, y, z, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), SoundSource.PLAYERS, 0.4F, 0.8F);
               return true;
            }
         } else {
            return true;
         }
      });
   }

   public static boolean isGrabbing(UUID playerId) {
      return GRABBED_ENTITIES.containsKey(playerId);
   }

   public static Integer getGrabbedEntityId(UUID playerId) {
      return GRABBED_ENTITIES.get(playerId);
   }

   public static void onPlayerLogout(ServerPlayer player) {
      GRABBED_ENTITIES.remove(player.getUUID());
   }

   private static record ThrownTracker(int entityId, int throwerId, ServerLevel level, long throwTick, float damageMultiplier) {
   }
}
