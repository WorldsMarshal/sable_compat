package com.invfix.vpower.server;

import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent.LeftClickBlock;
import net.neoforged.neoforge.event.tick.PlayerTickEvent.Post;

@EventBusSubscriber(
   modid = "sable_compat"
)
public class BodyPartRestrictionHandler {
   private static final double FEETLESS_SPEED_REDUCTION = 0.6;
   private static final double LEGLESS_SPEED_REDUCTION = 0.95;
   private static final ResourceLocation FEETLESS_SPEED_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "feetless_speed");
   private static final ResourceLocation LEGLESS_SPEED_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "legless_speed");
   private static final ResourceLocation LEGLESS_JUMP_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "legless_jump");

   @SubscribeEvent
   public static void onPlayerTick(Post event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         if (player.tickCount % 10 == 0) {
            applyBodyPartRestrictions(player);
         }
      }
   }

   public static void applyBodyPartRestrictions(LivingEntity living) {
      FleshRegenData data;
      try {
         data = (FleshRegenData)living.getData(ModAttachments.FLESH_REGEN.get());
      } catch (Exception var3) {
         return;
      }

      applyBodyPartRestrictions(living, data);
   }

   public static void applyBodyPartRestrictions(LivingEntity living, FleshRegenData data) {
      int rightFeetScore = data.getScore("Right.Feet");
      int leftFeetScore = data.getScore("Left.Feet");
      int rightLegScore = data.getScore("Right.Leg");
      int leftLegScore = data.getScore("Left.Leg");
      boolean noFeet = rightFeetScore == 0 && leftFeetScore == 0;
      boolean noLegs = rightLegScore == 0 && leftLegScore == 0;
      AttributeInstance speedAttr = living.getAttribute(Attributes.MOVEMENT_SPEED);
      AttributeInstance jumpAttr = living.getAttribute(Attributes.JUMP_STRENGTH);
      if (noLegs) {
         if (speedAttr != null && speedAttr.getModifier(LEGLESS_SPEED_ID) == null) {
            speedAttr.addTransientModifier(new AttributeModifier(LEGLESS_SPEED_ID, -0.95, Operation.ADD_MULTIPLIED_TOTAL));
         }

         if (jumpAttr != null && jumpAttr.getModifier(LEGLESS_JUMP_ID) == null) {
            jumpAttr.addTransientModifier(new AttributeModifier(LEGLESS_JUMP_ID, -1.0, Operation.ADD_MULTIPLIED_TOTAL));
         }

         if (speedAttr != null) {
            speedAttr.removeModifier(FEETLESS_SPEED_ID);
         }
      } else if (noFeet) {
         if (speedAttr != null && speedAttr.getModifier(FEETLESS_SPEED_ID) == null) {
            speedAttr.addTransientModifier(new AttributeModifier(FEETLESS_SPEED_ID, -0.6, Operation.ADD_MULTIPLIED_TOTAL));
         }

         if (speedAttr != null) {
            speedAttr.removeModifier(LEGLESS_SPEED_ID);
         }

         if (jumpAttr != null) {
            jumpAttr.removeModifier(LEGLESS_JUMP_ID);
         }
      } else {
         if (speedAttr != null) {
            speedAttr.removeModifier(FEETLESS_SPEED_ID);
            speedAttr.removeModifier(LEGLESS_SPEED_ID);
         }

         if (jumpAttr != null) {
            jumpAttr.removeModifier(LEGLESS_JUMP_ID);
         }
      }
   }

   @SubscribeEvent
   public static void onLeftClickBlock(LeftClickBlock event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         FleshRegenData data = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
         int rightHandScore = data.getScore("Right.Hand");
         int leftHandScore = data.getScore("Left.Hand");
         if (rightHandScore == 0 && leftHandScore == 0) {
            event.setCanceled(true);
         }
      }
   }
}
