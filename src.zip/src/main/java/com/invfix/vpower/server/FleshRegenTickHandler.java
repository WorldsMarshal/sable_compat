package com.invfix.vpower.server;

import com.invfix.vpower.util.VBlocks;
import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.network.FireTimerSyncPacket;
import com.invfix.vpower.network.FleshRegenSyncPacket;
import com.invfix.vpower.network.SkillActiveSyncPacket;
import com.invfix.vpower.network.SkillSyncPacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.FireEnergySkill;
import com.invfix.vpower.skill.skills.FireSkill;
import com.invfix.vpower.skill.skills.FleshRegenSkill;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.MinecartTNT;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.Clone;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerRespawnEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.StartTracking;
import net.neoforged.neoforge.event.tick.PlayerTickEvent.Post;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
   modid = "sable_compat"
)
public class FleshRegenTickHandler {
   private static final int ARM_BONE_COMPLETE = 5;
   private static final int NPC_REGEN_RATE_DIVISOR = 5;
   private static final String[] PRIORITY_ORDER = new String[]{
      "Head", "Body", "Right.Arm", "Right.Hand", "Left.Arm", "Left.Hand", "Right.Leg", "Right.Feet", "Left.Leg", "Left.Feet"
   };

   @SubscribeEvent
   public static void onPlayerTick(Post event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         if (player.tickCount % 1 == 0) {
            FleshRegenData data = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
            boolean changed = data.normalizeLinkedPartScores();
            int rightArmScore = data.getScore("Right.Arm");
            int leftArmScore = data.getScore("Left.Arm");
            int rightLegScore = data.getScore("Right.Leg");
            int leftLegScore = data.getScore("Left.Leg");
            SkillData playerSkillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            boolean activeFleshRegen = playerSkillData.hasSkill(FleshRegenSkill.ID) && playerSkillData.isSkillActive(FleshRegenSkill.ID.toString());
            boolean compoundVRegeneration = data.isCompoundVRegenerationActive();
            if (activeFleshRegen || compoundVRegeneration) {
               String[] priorityOrder = new String[]{
                  "Head", "Body", "Right.Arm", "Right.Hand", "Left.Arm", "Left.Hand", "Right.Leg", "Right.Feet", "Left.Leg", "Left.Feet"
               };
               int regenPct = activeFleshRegen ? playerSkillData.getDamageMultiplier(FleshRegenSkill.ID.toString()) : 100;
               if (regenPct > 0) {
                  boolean doRegen;
                  int regenIncrement;
                  if (regenPct <= 100) {
                     int period = Math.max(1, (int)Math.ceil(100.0 / (double)regenPct));
                     doRegen = player.tickCount % period == 0;
                     regenIncrement = 1;
                  } else {
                     doRegen = true;
                     regenIncrement = Math.min(2, regenPct / 100);
                  }

                  if (doRegen) {
                     for (String partName : priorityOrder) {
                        if (FleshRegenData.PART_MAX_SCORES.containsKey(partName)) {
                           int score = data.getScore(partName);
                           int maxScore = data.getEffectiveMaxScore(partName);
                           if ((
                                 partName.equals("Right.Hand")
                                    ? rightArmScore >= FleshRegenData.getChildReadyScore("Right.Arm")
                                    : (
                                       partName.equals("Left.Hand")
                                          ? leftArmScore >= FleshRegenData.getChildReadyScore("Left.Arm")
                                          : (
                                             partName.equals("Right.Feet")
                                                ? rightLegScore >= FleshRegenData.getChildReadyScore("Right.Leg")
                                                : !partName.equals("Left.Feet") || leftLegScore >= FleshRegenData.getChildReadyScore("Left.Leg")
                                          )
                                    )
                              )
                              && score >= 0
                              && score < maxScore) {
                              data.setScore(partName, Math.min(maxScore, score + regenIncrement));
                              changed = true;
                           }
                        }
                     }
                  }

                  if (player.getHealth() < player.getMaxHealth()) {
                     float actualHeal = 0.5F * ((float)regenPct / 100.0F);
                     player.heal(actualHeal);
                  }
               }
            }

            changed |= data.normalizeLinkedPartScores();
            if (data.isCompoundVRegenerationActive() && !data.hasDamagedParts()) {
               data.clearCompoundVRegeneration();
               changed = true;
            }

            int rightHandScore = data.getScore("Right.Hand");
            if (rightHandScore >= 0 && rightHandScore < 12 && !player.getMainHandItem().isEmpty()) {
               player.drop(player.getMainHandItem().copy(), false);
               player.getMainHandItem().setCount(0);
            }

            int leftHandScore = data.getScore("Left.Hand");
            if (leftHandScore >= 0 && leftHandScore < 12 && !player.getOffhandItem().isEmpty()) {
               player.drop(player.getOffhandItem().copy(), false);
               player.getOffhandItem().setCount(0);
            }

            if (changed) {
               player.refreshDimensions();
               BodyPartRestrictionHandler.applyBodyPartRestrictions(player, data);
               syncToClient(player);
            }

            if (player.tickCount % 20 == 0) {
               syncToClient(player);
            }

            SkillData fireSkillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            String fireEnergyId = FireEnergySkill.ID.toString();
            boolean hasFireSkill = fireSkillData.hasSkill(FireSkill.ID);
            boolean fireEnergyActive = hasFireSkill && fireSkillData.isSkillActive(fireEnergyId);
            int oldFireTimer = fireSkillData.getFireTimer();
            fireSkillData.tickFireTimer(fireEnergyActive);
            int newFireTimer = fireSkillData.getFireTimer();
            if (fireEnergyActive && newFireTimer > 0) {
               if (player.isOnFire()) {
                  player.clearFire();
               }

               if (player.tickCount % 5 == 0) {
                  Level world = player.level();
                  BlockPos center = player.blockPosition();
                  int range = 2;
                  boolean placedFire = false;

                  for (int x = -range; x <= range; x++) {
                     for (int y = -1; y <= range; y++) {
                        for (int z = -range; z <= range; z++) {
                           BlockPos pos = center.offset(x, y, z);
                           BlockState state = world.getBlockState(pos);
                           Block block = state.getBlock();
                           if (block instanceof LiquidBlock
                              || block == Blocks.ICE
                              || block == Blocks.PACKED_ICE
                              || block == Blocks.FROSTED_ICE
                              || block == Blocks.SNOW
                              || block == Blocks.SNOW_BLOCK) {
                              setBlockIfMutable(world, pos, Blocks.AIR.defaultBlockState(), 3);
                           } else if (block == Blocks.SAND || block == Blocks.RED_SAND) {
                              setBlockIfMutable(world, pos, Blocks.GLASS.defaultBlockState(), 3);
                           } else if (block == Blocks.COBBLESTONE) {
                              setBlockIfMutable(world, pos, Blocks.STONE.defaultBlockState(), 3);
                           } else if (block == Blocks.TNT) {
                              setBlockIfMutable(world, pos, Blocks.AIR.defaultBlockState(), 3);
                              PrimedTnt tnt = new PrimedTnt(world, (double)pos.getX() + 0.5, (double)pos.getY(), (double)pos.getZ() + 0.5, player);
                              world.addFreshEntity(tnt);
                              world.playSound(null, tnt.getX(), tnt.getY(), tnt.getZ(), SoundEvents.TNT_PRIMED, SoundSource.BLOCKS, 1.0F, 1.0F);
                           } else if (!placedFire
                              && state.isAir()
                              && world.getBlockState(pos.below()).isSolidRender(world, pos.below())
                              && world.random.nextFloat() < 0.01F) {
                              setBlockIfMutable(world, pos, Blocks.FIRE.defaultBlockState(), 3);
                              placedFire = true;
                           }
                        }
                     }
                  }

                  AABB hitBox = player.getBoundingBox().inflate(1.5);

                  for (Entity e : world.getEntities(player, hitBox)) {
                     if (e instanceof LivingEntity && !e.fireImmune()) {
                        e.setRemainingFireTicks(100);
                        if (e instanceof Creeper creeper) {
                           creeper.ignite();
                        }
                     } else if (e instanceof MinecartTNT tntCart) {
                        tntCart.primeFuse();
                     }
                  }

                  for (int dx = -2; dx <= 2; dx++) {
                     for (int dy = -1; dy <= 3; dy++) {
                        for (int dz = -2; dz <= 2; dz++) {
                           BlockPos checkPos = center.offset(dx, dy, dz);
                           if (world.getBlockState(checkPos).getBlock() == Blocks.LIGHT) {
                              setBlockIfMutable(world, checkPos, Blocks.AIR.defaultBlockState(), 3);
                           }
                        }
                     }
                  }

                  BlockPos lightPos = center.above();
                  if (world.getBlockState(lightPos).isAir()) {
                     setBlockIfMutable(world, lightPos, Blocks.LIGHT.defaultBlockState(), 3);
                  }
               }
            }

            if (!fireEnergyActive && oldFireTimer > 0 && newFireTimer == 0) {
               Level world = player.level();
               BlockPos center = player.blockPosition();

               for (int dx = -3; dx <= 3; dx++) {
                  for (int dy = -1; dy <= 4; dy++) {
                     for (int dzx = -3; dzx <= 3; dzx++) {
                        BlockPos checkPos = center.offset(dx, dy, dzx);
                        if (world.getBlockState(checkPos).getBlock() == Blocks.LIGHT) {
                           setBlockIfMutable(world, checkPos, Blocks.AIR.defaultBlockState(), 3);
                        }
                     }
                  }
               }
            }

            if (oldFireTimer != newFireTimer) {
               FireTimerSyncPacket.syncToWrappers(player);
            }
         }
      }
   }

   private static boolean setBlockIfMutable(Level world, BlockPos pos, BlockState state, int flags) {
      return VBlocks.protectedLevel(world) ? false : world.setBlock(pos, state, flags);
   }

   /** Данные Flesh Regen игрока — ему и всем игрокам в его измерении (как команда /fleshregen в The Boys). */
   public static void syncToClient(ServerPlayer player) {
      FleshRegenData data = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
      FleshRegenSyncPacket packet = new FleshRegenSyncPacket(player.getId(), data.toTag());
      PacketDistributor.sendToPlayer(player, packet, new CustomPacketPayload[0]);

      for (ServerPlayer other : player.serverLevel().players()) {
         if (other != player) {
            PacketDistributor.sendToPlayer(other, packet, new CustomPacketPayload[0]);
         }
      }
   }

   public static boolean tickFleshRegen(LivingEntity living) {
      FleshRegenData data = (FleshRegenData)living.getData(ModAttachments.FLESH_REGEN.get());
      SkillData skillData = (SkillData)living.getData(ModSkillAttachments.SKILL_DATA.get());
      return tickFleshRegen(living, data, skillData);
   }

   public static boolean hasActiveFleshRegen(LivingEntity living) {
      SkillData skillData = (SkillData)living.getData(ModSkillAttachments.SKILL_DATA.get());
      return skillData.hasSkill(FleshRegenSkill.ID) && skillData.isSkillActive(FleshRegenSkill.ID.toString());
   }

   public static void syncToTracking(LivingEntity living) {
      if (living.level() instanceof ServerLevel) {
         FleshRegenSyncPacket packet = new FleshRegenSyncPacket(living.getId(), ((FleshRegenData)living.getData(ModAttachments.FLESH_REGEN.get())).toTag());
         if (living instanceof ServerPlayer player) {
            PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, packet, new CustomPacketPayload[0]);
         } else {
            PacketDistributor.sendToPlayersTrackingEntity(living, packet, new CustomPacketPayload[0]);
         }
      }
   }

   private static boolean tickFleshRegen(LivingEntity living, FleshRegenData data, SkillData skillData) {
      boolean changed = data.normalizeLinkedPartScores();
      boolean activeFleshRegen = skillData.hasSkill(FleshRegenSkill.ID) && skillData.isSkillActive(FleshRegenSkill.ID.toString());
      boolean compoundVRegeneration = data.isCompoundVRegenerationActive();
      if (!activeFleshRegen && !compoundVRegeneration) {
         return finishFleshRegenTick(living, data, changed);
      } else {
         int baseRegenPct = activeFleshRegen ? skillData.getDamageMultiplier(FleshRegenSkill.ID.toString()) : 100;
         int regenPct = getEffectiveRegenPct(living, baseRegenPct);
         if (regenPct <= 0) {
            return finishFleshRegenTick(living, data, changed);
         } else {
            boolean doRegen;
            int regenIncrement;
            if (regenPct <= 100) {
               int period = Math.max(1, (int)Math.ceil(100.0 / (double)regenPct));
               doRegen = living.tickCount % period == 0;
               regenIncrement = 1;
            } else {
               doRegen = true;
               regenIncrement = Math.min(2, regenPct / 100);
            }

            if (doRegen) {
               int rightArmScore = data.getScore("Right.Arm");
               int leftArmScore = data.getScore("Left.Arm");
               int rightLegScore = data.getScore("Right.Leg");
               int leftLegScore = data.getScore("Left.Leg");

               for (String partName : PRIORITY_ORDER) {
                  if (FleshRegenData.PART_MAX_SCORES.containsKey(partName)) {
                     int maxScore = data.getEffectiveMaxScore(partName);
                     if ((!"Right.Hand".equals(partName) || rightArmScore >= FleshRegenData.getChildReadyScore("Right.Arm"))
                        && (!"Left.Hand".equals(partName) || leftArmScore >= FleshRegenData.getChildReadyScore("Left.Arm"))
                        && (!"Right.Feet".equals(partName) || rightLegScore >= FleshRegenData.getChildReadyScore("Right.Leg"))
                        && (!"Left.Feet".equals(partName) || leftLegScore >= FleshRegenData.getChildReadyScore("Left.Leg"))) {
                        int score = data.getScore(partName);
                        if (score >= 0 && score < maxScore) {
                           data.setScore(partName, Math.min(maxScore, score + regenIncrement));
                           changed = true;
                        }
                     }
                  }
               }
            }

            changed |= data.normalizeLinkedPartScores();
            if (data.isCompoundVRegenerationActive() && !data.hasDamagedParts()) {
               data.clearCompoundVRegeneration();
               changed = true;
            }

            if (living.getHealth() < living.getMaxHealth() && (living instanceof Player || doRegen)) {
               float actualHeal = 0.5F * ((float)regenPct / 100.0F);
               living.heal(actualHeal);
            }

            return finishFleshRegenTick(living, data, changed);
         }
      }
   }

   private static boolean finishFleshRegenTick(LivingEntity living, FleshRegenData data, boolean changed) {
      if (changed) {
         living.refreshDimensions();
      }

      BodyPartRestrictionHandler.applyBodyPartRestrictions(living, data);
      return changed;
   }

   private static int getEffectiveRegenPct(LivingEntity living, int regenPct) {
      return living instanceof Player ? regenPct : Math.max(1, regenPct / 5);
   }

   @SubscribeEvent
   public static void onPlayerLoggedIn(PlayerLoggedInEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         player.getServer().execute(() -> {
            syncToClient(player);
            SkillSyncPacket.syncToClient(player);
            SkillActiveSyncPacket.syncToClient(player);
            SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            FleshStrengthHandler.refreshHealthModifier(player, skillData);

            for (ServerPlayer otherPlayer : player.serverLevel().players()) {
               if (otherPlayer != player) {
                  FleshRegenData otherData = (FleshRegenData)otherPlayer.getData(ModAttachments.FLESH_REGEN.get());
                  FleshRegenSyncPacket otherPacket = new FleshRegenSyncPacket(otherPlayer.getId(), otherData.toTag());
                  PacketDistributor.sendToPlayer(player, otherPacket, new CustomPacketPayload[0]);
                  SkillActiveSyncPacket.syncStateToPlayer(otherPlayer, player);
               }
            }
         });
      }
   }

   @SubscribeEvent
   public static void onStartTracking(StartTracking event) {
      if (event.getEntity() instanceof ServerPlayer watcher && event.getTarget() instanceof ServerPlayer target) {
         SkillActiveSyncPacket.syncStateToPlayer(target, watcher);
      }
   }

   @SubscribeEvent
   public static void onLivingDeath(LivingDeathEvent event) {
      if (!event.getEntity().level().isClientSide) {
         LivingEntity skillData = event.getEntity();
         if (skillData instanceof LivingEntity && !(skillData instanceof ServerPlayer) && hasActiveFleshRegen(skillData)) {
            event.setCanceled(true);
            skillData.setHealth(1.0F);
         } else {
            if (event.getEntity() instanceof ServerPlayer player) {
               SkillData skillDatax = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
               String skillId = FleshRegenSkill.ID.toString();
               if (skillDatax.hasSkill(skillId) && skillDatax.isSkillActive(skillId)) {
                  event.setCanceled(true);
                  player.setHealth(1.0F);
               }
            }
         }
      }
   }

   @SubscribeEvent
   public static void onPlayerClone(Clone event) {
      if (event.isWasDeath() && event.getEntity() instanceof ServerPlayer newPlayer && event.getOriginal() instanceof ServerPlayer oldPlayer) {
         SkillData oldSkillData = (SkillData)oldPlayer.getData(ModSkillAttachments.SKILL_DATA.get());
         SkillData newSkillData = (SkillData)newPlayer.getData(ModSkillAttachments.SKILL_DATA.get());
         CompoundTag nbt = oldSkillData.serializeNBT(oldPlayer.registryAccess());
         newSkillData.deserializeNBT(newPlayer.registryAccess(), nbt);
         deactivateActiveSkills(newSkillData);
         newSkillData.setShieldHp(newSkillData.getMaxShieldHp());
         FleshRegenData newData = (FleshRegenData)newPlayer.getData(ModAttachments.FLESH_REGEN.get());

         for (String part : FleshRegenData.PART_MAX_SCORES.keySet()) {
            int maxScore = FleshRegenData.PART_MAX_SCORES.get(part);
            newData.activatePart(part, maxScore);
         }
      }
   }

   @SubscribeEvent
   public static void onPlayerRespawn(PlayerRespawnEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         player.getServer().execute(() -> {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            FleshStrengthHandler.refreshHealthModifier(player, data);
            SkillSyncPacket.syncToClient(player);
            SkillActiveSyncPacket.syncToClient(player);
         });
      }
   }

   private static void deactivateActiveSkills(SkillData skillData) {
      if (skillData != null) {
         for (String skillId : skillData.getActiveSkills()) {
            skillData.setSkillActive(skillId, false);
         }
      }
   }
}
