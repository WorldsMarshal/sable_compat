package com.invfix.vpower.server;

import com.invfix.vpower.network.SkillActiveSyncPacket;
import com.invfix.vpower.network.SkillSyncPacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.ScaleSkill;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;

public final class ScaleHandler {
   private static final String SCALE_ID = ScaleSkill.ID.toString();
   private static final ResourceLocation SCALE_MODIFIER_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "size_scale");
   private static final ResourceLocation SPEED_MODIFIER_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "size_movement_speed");
   private static final ResourceLocation ENTITY_RANGE_MODIFIER_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "size_entity_range");
   private static final ResourceLocation BLOCK_RANGE_MODIFIER_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "size_block_range");
   private static final ResourceLocation STEP_HEIGHT_MODIFIER_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "size_step_height");
   private static final float DEFAULT_SCALE = 1.0F;
   private static final float MAX_SCALE_STEP = 0.12F;

   private ScaleHandler() {
   }

   public static void serverTick(ServerLevel level) {
      for (ServerPlayer player : level.players()) {
         try {
            tickEntity(player);
         } catch (Exception var4) {
         }
      }
   }

   public static void setTargetScale(ServerPlayer player, float requestedScale) {
      setTargetScale((LivingEntity)player, requestedScale);
   }

   public static void setTargetScale(LivingEntity entity, float requestedScale) {
      SkillData data = (SkillData)entity.getData(ModSkillAttachments.SKILL_DATA.get());
      if (data.hasSkill(ScaleSkill.ID)) {
         data.setTargetScale(requestedScale);
         data.setSkillActive(SCALE_ID, false);
         if (entity instanceof ServerPlayer player) {
            SkillSyncPacket.syncToClient(player);
         } else {
            SkillActiveSyncPacket.syncToTracking(entity);
         }
      }
   }

   public static void tickEntity(LivingEntity entity) {
      SkillData data = (SkillData)entity.getData(ModSkillAttachments.SKILL_DATA.get());
      boolean canScale = data.hasSkill(ScaleSkill.ID);
      float targetScale = canScale ? data.getTargetScale() : 1.0F;
      float currentScale = getCurrentScale(entity);
      float nextScale = approach(currentScale, targetScale);
      applyScaleAttributes(entity, nextScale);
      if (Math.abs(nextScale - currentScale) > 0.001F) {
         entity.refreshDimensions();
      }
   }

   private static float getCurrentScale(LivingEntity entity) {
      AttributeInstance scale = entity.getAttribute(Attributes.SCALE);
      return scale == null ? 1.0F : SkillData.clampPlayerScale((float)scale.getValue());
   }

   private static float approach(float current, float target) {
      target = SkillData.clampPlayerScale(target);
      float diff = target - current;
      if (Math.abs(diff) <= 0.002F) {
         return target;
      } else {
         float step = Math.min(Math.abs(diff), 0.12F);
         return current + Math.copySign(step, diff);
      }
   }

   private static void applyScaleAttributes(LivingEntity entity, float scale) {
      double scaleAmount = (double)(scale - 1.0F);
      applyModifier(entity, Attributes.SCALE, SCALE_MODIFIER_ID, scaleAmount, Operation.ADD_MULTIPLIED_BASE);
      applyModifier(entity, Attributes.MOVEMENT_SPEED, SPEED_MODIFIER_ID, scaleAmount, Operation.ADD_MULTIPLIED_BASE);
      applyModifier(entity, Attributes.ENTITY_INTERACTION_RANGE, ENTITY_RANGE_MODIFIER_ID, scaleAmount, Operation.ADD_MULTIPLIED_BASE);
      applyModifier(entity, Attributes.BLOCK_INTERACTION_RANGE, BLOCK_RANGE_MODIFIER_ID, scaleAmount, Operation.ADD_MULTIPLIED_BASE);
      applyStepHeightModifier(entity, scale);
   }

   private static void applyStepHeightModifier(LivingEntity entity, float scale) {
      AttributeInstance attr = entity.getAttribute(Attributes.STEP_HEIGHT);
      if (attr != null) {
         double base = attr.getBaseValue();
         double scaledStepHeight = base * (double)scale;
         double targetStepHeight = scale > 1.0F ? Math.max(1.0, scaledStepHeight) : scaledStepHeight;
         applyModifier(entity, Attributes.STEP_HEIGHT, STEP_HEIGHT_MODIFIER_ID, targetStepHeight - base, Operation.ADD_VALUE);
      }
   }

   private static void applyModifier(LivingEntity entity, Holder<Attribute> attribute, ResourceLocation modifierId, double amount, Operation operation) {
      AttributeInstance attr = entity.getAttribute(attribute);
      if (attr != null) {
         AttributeModifier existing = attr.getModifier(modifierId);
         if (Math.abs(amount) <= 1.0E-4) {
            if (existing != null) {
               attr.removeModifier(modifierId);
            }
         } else {
            if (existing == null || existing.operation() != operation || Math.abs(existing.amount() - amount) > 1.0E-4) {
               attr.removeModifier(modifierId);
               attr.addTransientModifier(new AttributeModifier(modifierId, amount, operation));
            }
         }
      }
   }
}
