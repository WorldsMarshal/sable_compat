package com.invfix.vpower.server;

import com.invfix.vpower.VRaces;
import com.invfix.vpower.network.InjectVPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent.RightClickBlock;

@EventBusSubscriber(
   modid = "sable_compat"
)
public class SyringeAttackInjectionHandler {
   @SubscribeEvent(
      priority = EventPriority.HIGH
   )
   public static void onRightClickBlock(RightClickBlock event) {
      Player player = event.getEntity();
      ItemStack stack = event.getItemStack();
      if (InjectVPacket.syringeTypeFromStack(stack) != null) {
         player.startUsingItem(event.getHand());
         event.setCancellationResult(InteractionResult.CONSUME);
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public static void onAttackEntity(AttackEntityEvent event) {
      if (event.getEntity() instanceof ServerPlayer injector) {
         ItemStack stack = injector.getMainHandItem();
         String syringeType = InjectVPacket.syringeTypeFromStack(stack);
         if (syringeType != null) {
            if (event.getTarget() instanceof ServerPlayer target && injector != target) {
               // V колется только человеческой ДНК получателя (VRaces): удар гасится, шприц цел
               String msg = VRaces.blockMessage(target, stack);
               if (msg != null) {
                  injector.displayClientMessage(Component.literal(msg), true);
                  event.setCanceled(true);
                  return;
               }

               InjectVPacket.applyPrickEffect(target);
               InjectVPacket.injectTarget(injector, target, syringeType, stack);
               event.setCanceled(true);
               return;
            }

         }
      }
   }

}
