package com.invfix.vpower.server;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.registry.ModSounds;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.SpeedSkill;
import net.minecraft.core.Holder;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;

public class SuperSpeedHandler {
   private static final String SPEED_SKILL_ID = SpeedSkill.ID.toString();
   private static final ResourceLocation SPEED_MODIFIER_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "super_speed_boost");
   private static final ResourceLocation STEP_HEIGHT_MODIFIER_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "super_speed_step");
   private static final ResourceLocation GRAVITY_MODIFIER_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "super_speed_gravity");
   private static final ResourceLocation FALL_MODIFIER_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "super_speed_fall");
   private static final double STEP_HEIGHT_BOOST = 7.375;
   private static final double GRAVITY_BOOST = 2.0;
   private static final double FALL_DISTANCE_BOOST = 100.0;
   private static final Map<Integer, Boolean> WAS_SPEED_SPRINTING = new ConcurrentHashMap<>();
   private static final Map<Integer, Integer> SPRINT_TICK_COUNTER = new ConcurrentHashMap<>();
   private static final int RUNNING_SOUND_INTERVAL = 20;

   public static void serverTick(ServerLevel level) {
      for (ServerPlayer player : level.players()) {
         try {
            SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
            int playerId = player.getId();
            boolean hasSkill = data.hasSkill(SPEED_SKILL_ID);
            boolean isActive = hasSkill && data.isSkillActive(SPEED_SKILL_ID);
            boolean isSprinting = player.isSprinting();
            AttributeInstance speedAttr = player.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speedAttr != null) {
               if (isActive) {
                  float boost = data.getEffectiveSpeedBoost();
                  AttributeModifier existing = speedAttr.getModifier(SPEED_MODIFIER_ID);
                  if (existing == null || Math.abs(existing.amount() - (double)boost) > 1.0E-4) {
                     speedAttr.removeModifier(SPEED_MODIFIER_ID);
                     if (boost > 0.0F) {
                        speedAttr.addTransientModifier(new AttributeModifier(SPEED_MODIFIER_ID, (double)boost, Operation.ADD_VALUE));
                     }
                  }
               } else {
                  speedAttr.removeModifier(SPEED_MODIFIER_ID);
               }
            }

            boolean sprintEffects = isActive && isSprinting && data.getSpeedAdjustment() > 0;
            applyOrRemove(player, Attributes.STEP_HEIGHT, STEP_HEIGHT_MODIFIER_ID, sprintEffects, 7.375);
            applyOrRemove(player, Attributes.GRAVITY, GRAVITY_MODIFIER_ID, sprintEffects, 2.0);
            applyOrRemove(player, Attributes.SAFE_FALL_DISTANCE, FALL_MODIFIER_ID, sprintEffects, 100.0);
            boolean wasSpeedSprinting = WAS_SPEED_SPRINTING.getOrDefault(playerId, false);
            if (sprintEffects) {
               if (!wasSpeedSprinting) {
                  level.playSound(null, player.getX(), player.getY(), player.getZ(), (SoundEvent)ModSounds.EVASION.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
                  SPRINT_TICK_COUNTER.put(playerId, 0);
               }

               int counter = SPRINT_TICK_COUNTER.getOrDefault(playerId, 0) + 1;
               if (counter >= 20) {
                  level.playSound(null, player.getX(), player.getY(), player.getZ(), (SoundEvent)ModSounds.SPEED_RUNNING.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
                  counter = 0;
               }

               SPRINT_TICK_COUNTER.put(playerId, counter);
            } else if (wasSpeedSprinting) {
               SPRINT_TICK_COUNTER.remove(playerId);
               player.connection.send(new ClientboundStopSoundPacket(((SoundEvent)ModSounds.SPEED_RUNNING.get()).getLocation(), SoundSource.PLAYERS));
               player.connection.send(new ClientboundStopSoundPacket(((SoundEvent)ModSounds.EVASION.get()).getLocation(), SoundSource.PLAYERS));
            }

            WAS_SPEED_SPRINTING.put(playerId, sprintEffects);
         } catch (Exception var12) {
         }
      }
   }

   private static void applyOrRemove(ServerPlayer player, Holder<Attribute> attribute, ResourceLocation modifierId, boolean shouldApply, double amount) {
      AttributeInstance attr = player.getAttribute(attribute);
      if (attr != null) {
         if (shouldApply) {
            if (attr.getModifier(modifierId) == null) {
               attr.addTransientModifier(new AttributeModifier(modifierId, amount, Operation.ADD_VALUE));
            }
         } else if (attr.getModifier(modifierId) != null) {
            attr.removeModifier(modifierId);
         }
      }
   }
}
