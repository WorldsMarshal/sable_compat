package com.invfix.vpower.server;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.ToadSkill;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent.Post;

@EventBusSubscriber(
   modid = "sable_compat"
)
public final class ToadDimensionsHandler {
   private static final String TOAD_ID = ToadSkill.ID.toString();
   private static final Map<UUID, Boolean> LAST_TOAD_STATE = new ConcurrentHashMap<>();

   private ToadDimensionsHandler() {
   }

   @SubscribeEvent
   public static void onPlayerTick(Post event) {
      Player player = event.getEntity();
      boolean hasToad = hasToad(player);
      UUID uuid = player.getUUID();
      Boolean previous = LAST_TOAD_STATE.put(uuid, hasToad);
      if (previous == null && hasToad || previous != null && previous != hasToad) {
         player.refreshDimensions();
      }
   }

   @SubscribeEvent
   public static void onPlayerLoggedOut(PlayerLoggedOutEvent event) {
      LAST_TOAD_STATE.remove(event.getEntity().getUUID());
   }

   private static boolean hasToad(Player player) {
      try {
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         return data.hasSkill(TOAD_ID);
      } catch (Exception var2) {
         return false;
      }
   }
}
