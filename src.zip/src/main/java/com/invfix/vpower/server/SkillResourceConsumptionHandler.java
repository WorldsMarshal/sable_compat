package com.invfix.vpower.server;

import com.invfix.vpower.network.SkillActiveSyncPacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillConsumptionProfiles;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.FireBlastSkill;
import com.invfix.vpower.skill.skills.FireEnergySkill;
import com.invfix.vpower.skill.skills.GrabSkill;
import com.invfix.vpower.skill.skills.LaserEyeSkill;
import com.invfix.vpower.skill.skills.SoundWaveAttackSkill;
import com.invfix.vpower.skill.skills.SpeedSkill;
import com.invfix.vpower.skill.skills.SprayWaterSkill;
import com.invfix.vpower.skill.skills.SuperJumpSkill;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

public final class SkillResourceConsumptionHandler {
   private static final String LASER_EYE_ID = LaserEyeSkill.ID.toString();
   private static final String FIRE_BLAST_ID = FireBlastSkill.ID.toString();
   private static final String SOUND_WAVE_ATTACK_ID = SoundWaveAttackSkill.ID.toString();
   private static final String SUPER_JUMP_ID = SuperJumpSkill.ID.toString();
   private static final String SPRAY_WATER_ID = SprayWaterSkill.ID.toString();
   private static final String FIRE_ENERGY_ID = FireEnergySkill.ID.toString();
   private static final String GRAB_ID = GrabSkill.ID.toString();
   private static final String SPEED_ID = SpeedSkill.ID.toString();
   private static final SkillConsumptionProfiles.Profile LASER_PROFILE = SkillConsumptionProfiles.LASER_EYE;
   private static final SkillConsumptionProfiles.Profile FIRE_BLAST_PROFILE = SkillConsumptionProfiles.FIRE_BLAST;
   private static final SkillConsumptionProfiles.Profile SOUND_WAVE_ATTACK_PROFILE = SkillConsumptionProfiles.SOUND_WAVE_ATTACK;
   private static final SkillConsumptionProfiles.Profile SUPER_JUMP_PROFILE = SkillConsumptionProfiles.SUPER_JUMP;
   private static final SkillConsumptionProfiles.Profile SPRAY_WATER_PROFILE = SkillConsumptionProfiles.SPRAY_WATER;
   private static final SkillConsumptionProfiles.Profile FIRE_ENERGY_PROFILE = SkillConsumptionProfiles.FIRE_ENERGY;
   private static final SkillConsumptionProfiles.Profile GRAB_PROFILE = SkillConsumptionProfiles.GRAB;
   private static final SkillConsumptionProfiles.Profile SPEED_PROFILE = SkillConsumptionProfiles.SPEED;
   private static final double SPEED_MIN_MOVEMENT = 0.08;

   private SkillResourceConsumptionHandler() {
   }

   public static void serverTick(ServerLevel level) {
      for (ServerPlayer player : level.players()) {
         try {
            tickPlayer(player);
         } catch (Exception var4) {
         }
      }
   }

   private static void tickPlayer(ServerPlayer player) {
      if (!player.isCreative() && !player.isSpectator()) {
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         Vec3 delta = player.getDeltaMovement();
         double horizontalSpeed = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
         sustainSkill(player, data, LASER_EYE_ID, data.hasSkill(LASER_EYE_ID) && data.isSkillActive(LASER_EYE_ID), LASER_PROFILE);
         sustainSkill(player, data, FIRE_BLAST_ID, data.hasSkill(FIRE_BLAST_ID) && data.isSkillActive(FIRE_BLAST_ID), FIRE_BLAST_PROFILE);
         sustainSkill(
            player, data, SOUND_WAVE_ATTACK_ID, data.hasSkill(SOUND_WAVE_ATTACK_ID) && data.isSkillActive(SOUND_WAVE_ATTACK_ID), SOUND_WAVE_ATTACK_PROFILE
         );
         sustainSkill(player, data, SUPER_JUMP_ID, data.hasSkill(SUPER_JUMP_ID) && data.isSkillActive(SUPER_JUMP_ID), SUPER_JUMP_PROFILE);
         sustainSkill(player, data, SPRAY_WATER_ID, data.hasSkill(SPRAY_WATER_ID) && data.isSkillActive(SPRAY_WATER_ID), SPRAY_WATER_PROFILE);
         sustainSkill(player, data, FIRE_ENERGY_ID, data.hasSkill(FIRE_ENERGY_ID) && data.isSkillActive(FIRE_ENERGY_ID), FIRE_ENERGY_PROFILE);
         boolean grabbing = data.hasSkill(GRAB_ID) && data.isSkillActive(GRAB_ID) && GrabHandler.isGrabbing(player.getUUID());
         if (!sustainSkill(player, data, GRAB_ID, grabbing, GRAB_PROFILE)) {
            GrabHandler.handleRelease(player);
         }

         boolean usingSpeed = data.hasSkill(SPEED_ID) && data.isSkillActive(SPEED_ID) && data.getSpeedAdjustment() > 0 && horizontalSpeed > 0.08;
         sustainSkill(player, data, SPEED_ID, usingSpeed, SPEED_PROFILE);
      }
   }

   private static boolean sustainSkill(ServerPlayer player, SkillData data, String skillId, boolean shouldConsume, SkillConsumptionProfiles.Profile profile) {
      if (!shouldConsume) {
         return true;
      } else if (player.getFoodData().getFoodLevel() <= profile.minFoodLevel()) {
         forceDeactivateSkill(player, data, skillId);
         return false;
      } else {
         if (player.tickCount % profile.intervalTicks() == 0) {
            player.getFoodData().addExhaustion(profile.exhaustionPerInterval());
         }

         return true;
      }
   }

   private static void forceDeactivateSkill(ServerPlayer player, SkillData data, String skillId) {
      if (data.isSkillActive(skillId)) {
         data.setSkillActive(skillId, false);
         SkillActiveSyncPacket.syncToWrappers(player);
      }
   }
}
