package com.invfix.vpower.server;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.SuperVisionSkill;
import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.MobEffectEvent.Applicable;
import net.neoforged.neoforge.event.entity.living.MobEffectEvent.Applicable.Result;

@EventBusSubscriber(
   modid = "sable_compat"
)
public class SuperVisionImmunityHandler {
   private static final String SUPER_VISION_ID = SuperVisionSkill.ID.toString();

   @SubscribeEvent
   public static void onEffectApplicable(Applicable event) {
      if (event.getEntity() instanceof Player player) {
         Holder<MobEffect> effect = event.getEffectInstance().getEffect();
         if (effect == MobEffects.DARKNESS || effect == MobEffects.BLINDNESS) {
            try {
               SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
               if (data.hasSkill(SUPER_VISION_ID)) {
                  event.setResult(Result.DO_NOT_APPLY);
               }
            } catch (Exception var4) {
            }
         }
      }
   }
}
