package com.invfix.vpower.server;

import com.invfix.vpower.VRaces;
import com.invfix.vpower.network.SkillSyncPacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.BreakSpeed;
import net.neoforged.neoforge.event.tick.PlayerTickEvent.Post;

@EventBusSubscriber(
   modid = "sable_compat"
)
public final class TempVSideEffectHandler {
   private static final int LOAD_PER_INJECTION = 35;
   private static final int LOAD_WARNING_THRESHOLD = 70;
   private static final int LOAD_OVERFLOW_THRESHOLD = 100;
   private static final int LOAD_DECAY_INTERVAL_TICKS = 600;
   private static final int WITHDRAWAL_BASE_TICKS = 600;
   private static final int WITHDRAWAL_TICKS_PER_LOAD = 20;
   private static final int WITHDRAWAL_MAX_TICKS = 3600;
   private static final ResourceLocation WITHDRAWAL_HEALTH_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "temp_v_withdrawal_health");
   private static final ResourceLocation OVERLOAD_HEALTH_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "temp_v_overload_health");
   private static final ResourceLocation WITHDRAWAL_SPEED_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "temp_v_withdrawal_speed");
   private static final ResourceLocation OVERLOAD_SPEED_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "temp_v_overload_speed");
   private static final ResourceLocation WITHDRAWAL_ATTACK_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "temp_v_withdrawal_attack");
   private static final ResourceLocation OVERLOAD_ATTACK_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "temp_v_overload_attack");
   private static final int MAX_SIDE_EFFECT_LOAD = 150;
   private static final double WITHDRAWAL_HEALTH_MIN_REDUCTION = 0.18;
   private static final double WITHDRAWAL_HEALTH_MAX_REDUCTION = 0.5;
   private static final double OVERLOAD_HEALTH_MIN_REDUCTION = 0.1;
   private static final double OVERLOAD_HEALTH_MAX_REDUCTION = 0.35;
   private static final double WITHDRAWAL_SPEED_MIN_REDUCTION = 0.18;
   private static final double WITHDRAWAL_SPEED_MAX_REDUCTION = 0.55;
   private static final double OVERLOAD_SPEED_MIN_REDUCTION = 0.06;
   private static final double OVERLOAD_SPEED_MAX_REDUCTION = 0.25;
   private static final double WITHDRAWAL_ATTACK_MIN_REDUCTION = 0.15;
   private static final double WITHDRAWAL_ATTACK_MAX_REDUCTION = 0.55;
   private static final double OVERLOAD_ATTACK_MIN_REDUCTION = 0.08;
   private static final double OVERLOAD_ATTACK_MAX_REDUCTION = 0.3;

   private TempVSideEffectHandler() {
   }

   @SubscribeEvent
   public static void onPlayerTick(Post event) {
      if (event.getEntity() instanceof ServerPlayer player && player.getServer() != null) {
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         long gameTime = player.getServer().overworld().getGameTime();
         boolean withdrawalActive = data.isTemporaryVWithdrawalActive(gameTime);
         boolean changed = false;
         if (data.hasTemporaryVWithdrawal() && !withdrawalActive) {
            data.clearTemporaryVWithdrawal();
            data.setTemporaryVLastLoadDecayGameTime(gameTime);
            changed = true;
            player.sendSystemMessage(Component.literal("§aЛомка от Temp V прошла."));
         }

         changed |= tickVLoadDecay(data, gameTime);
         if (withdrawalActive) {
            float severity = sideEffectSeverity(data);
            player.setSprinting(false);
            applyWithdrawalCosts(player, severity);
            setAttributeModifier(player, Attributes.MAX_HEALTH, WITHDRAWAL_HEALTH_ID, negativeReduction(0.18, 0.5, severity));
            setAttributeModifier(player, Attributes.MOVEMENT_SPEED, WITHDRAWAL_SPEED_ID, negativeReduction(0.18, 0.55, severity));
            setAttributeModifier(player, Attributes.ATTACK_DAMAGE, WITHDRAWAL_ATTACK_ID, negativeReduction(0.15, 0.55, severity));
         } else {
            removeAttributeModifier(player, Attributes.MAX_HEALTH, WITHDRAWAL_HEALTH_ID);
            removeAttributeModifier(player, Attributes.MOVEMENT_SPEED, WITHDRAWAL_SPEED_ID);
            removeAttributeModifier(player, Attributes.ATTACK_DAMAGE, WITHDRAWAL_ATTACK_ID);
         }

         if (data.isTemporaryVOverloaded()) {
            float severity = sideEffectSeverity(data);
            applyOverloadCosts(player, severity);
            setAttributeModifier(player, Attributes.MAX_HEALTH, OVERLOAD_HEALTH_ID, negativeReduction(0.1, 0.35, severity));
            setAttributeModifier(player, Attributes.MOVEMENT_SPEED, OVERLOAD_SPEED_ID, negativeReduction(0.06, 0.25, severity));
            setAttributeModifier(player, Attributes.ATTACK_DAMAGE, OVERLOAD_ATTACK_ID, negativeReduction(0.08, 0.3, severity));
         } else {
            removeAttributeModifier(player, Attributes.MAX_HEALTH, OVERLOAD_HEALTH_ID);
            removeAttributeModifier(player, Attributes.MOVEMENT_SPEED, OVERLOAD_SPEED_ID);
            removeAttributeModifier(player, Attributes.ATTACK_DAMAGE, OVERLOAD_ATTACK_ID);
         }

         if (changed) {
            SkillSyncPacket.syncToClient(player);
         }

         return;
      }
   }

   public static void onTemporaryVInjected(ServerPlayer player, SkillData data, long gameTime) {
      // Born for V не копит V-load и не уходит в передоз
      if (player != null && data != null && !VRaces.bornForV(player)) {
         if (data.hasTemporaryVWithdrawal()) {
            data.clearTemporaryVWithdrawal();
            removeWithdrawalModifiers(player);
         }

         int load = data.addTemporaryVLoad(35);
         data.setTemporaryVLastLoadDecayGameTime(gameTime);
         if (load >= 100) {
            if (!data.isTemporaryVOverloaded()) {
               data.setTemporaryVOverloaded(true);
               player.sendSystemMessage(Component.literal("§4VLoad переполнен: побочные эффекты закреплены навсегда — снять их может только средство удаления V."));
            } else {
               player.sendSystemMessage(Component.literal("§4VLoad переполнен: побочные эффекты останутся, пока их не снимет средство удаления V."));
            }
         } else if (load >= 70) {
            player.sendSystemMessage(Component.literal("§eVLoad " + load + "/100: ещё уколы Temp V грозят переполнением."));
         } else {
            player.sendSystemMessage(Component.literal("§6VLoad " + load + "/100."));
         }
      }
   }

   public static void onTemporaryVExpired(ServerPlayer player, SkillData data, long gameTime) {
      // у Born for V ломка не начинается
      if (player != null && data != null && !VRaces.bornForV(player)) {
         int load = Math.max(35, data.getTemporaryVLoad());
         int withdrawalTicks = Math.min(3600, 600 + load * 20);
         data.beginTemporaryVWithdrawal(gameTime, withdrawalTicks);
         data.setTemporaryVLastLoadDecayGameTime(gameTime);
         player.sendSystemMessage(Component.literal("§cДействие Temp V закончилось, началась ломка: " + formatDuration(withdrawalTicks) + "."));
         float severity = sideEffectSeverity(data);
         float healthRetention = 1.0F - lerp(0.2F, 0.45F, severity);
         player.setHealth(Math.max(1.0F, player.getHealth() * healthRetention));
         applyWithdrawalCosts(player, severity);
         setAttributeModifier(player, Attributes.MAX_HEALTH, WITHDRAWAL_HEALTH_ID, negativeReduction(0.18, 0.5, severity));
         setAttributeModifier(player, Attributes.MOVEMENT_SPEED, WITHDRAWAL_SPEED_ID, negativeReduction(0.18, 0.55, severity));
         setAttributeModifier(player, Attributes.ATTACK_DAMAGE, WITHDRAWAL_ATTACK_ID, negativeReduction(0.15, 0.55, severity));
      }

      // Human: после Temp V — Critical Poisoning
      if (player != null) {
         VRaces.onTempVExpired(player);
      }
   }

   public static void clearSideEffects(ServerPlayer player, SkillData data) {
      if (data != null) {
         data.clearTemporaryVSideEffects();
      }

      if (player != null) {
         removeWithdrawalModifiers(player);
         removeOverloadModifiers(player);
      }
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public static void onBreakSpeed(BreakSpeed event) {
      Player player = event.getEntity();
      BlockState state = event.getState();
      if (player != null && state != null && !state.isAir()) {
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         long gameTime = player.level().getGameTime();
         float multiplier = 1.0F;
         if (data.isTemporaryVWithdrawalActive(gameTime)) {
            multiplier *= withdrawalBreakSpeedMultiplier(data);
         }

         if (data.isTemporaryVOverloaded()) {
            multiplier *= overloadBreakSpeedMultiplier(data);
         }

         if (multiplier < 0.999F) {
            event.setNewSpeed(Math.max(0.05F, event.getNewSpeed() * multiplier));
         }
      }
   }

   private static boolean tickVLoadDecay(SkillData data, long gameTime) {
      if (data == null) {
         return false;
      } else if (!data.hasTemporarySkills() && !data.hasTemporaryVWithdrawal() && !data.isTemporaryVWithdrawalActive(gameTime)) {
         int load = data.getTemporaryVLoad();
         if (load <= 0) {
            return false;
         } else {
            long lastDecay = data.getTemporaryVLastLoadDecayGameTime();
            if (lastDecay > 0L && gameTime >= lastDecay) {
               long elapsed = gameTime - lastDecay;
               if (elapsed < 600L) {
                  return false;
               } else {
                  int steps = (int)Math.min((long)load, elapsed / 600L);
                  data.setTemporaryVLoad(load - steps);
                  data.setTemporaryVLastLoadDecayGameTime(lastDecay + (long)steps * 600L);
                  return true;
               }
            } else {
               data.setTemporaryVLastLoadDecayGameTime(gameTime);
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private static void applyWithdrawalCosts(ServerPlayer player, float severity) {
      if (player.tickCount % 20 == 0) {
         player.getFoodData().addExhaustion(lerp(0.12F, 0.5F, severity));
      }
   }

   private static void applyOverloadCosts(ServerPlayer player, float severity) {
      if (player.tickCount % 80 == 0) {
         player.getFoodData().addExhaustion(lerp(0.05F, 0.23F, severity));
      }
   }

   private static float sideEffectSeverity(SkillData data) {
      int load = Math.max(35, data.getTemporaryVLoad());
      return Math.max(0.23333333F, Math.min(1.0F, (float)load / 150.0F));
   }

   private static double negativeReduction(double minReduction, double maxReduction, float severity) {
      return -lerp(minReduction, maxReduction, (double)severity);
   }

   private static float withdrawalBreakSpeedMultiplier(SkillData data) {
      return Math.max(0.35F, 1.0F - lerp(0.2F, 0.65F, sideEffectSeverity(data)));
   }

   private static float overloadBreakSpeedMultiplier(SkillData data) {
      return Math.max(0.7F, 1.0F - lerp(0.08F, 0.3F, sideEffectSeverity(data)));
   }

   private static float lerp(float min, float max, float amount) {
      return min + (max - min) * amount;
   }

   private static double lerp(double min, double max, double amount) {
      return min + (max - min) * amount;
   }

   private static void setAttributeModifier(ServerPlayer player, Holder<Attribute> attribute, ResourceLocation modifierId, double amount) {
      AttributeInstance attr = player.getAttribute(attribute);
      if (attr != null) {
         AttributeModifier existing = attr.getModifier(modifierId);
         if (existing == null || existing.operation() != Operation.ADD_MULTIPLIED_TOTAL || Math.abs(existing.amount() - amount) > 1.0E-4) {
            attr.removeModifier(modifierId);
            attr.addTransientModifier(new AttributeModifier(modifierId, amount, Operation.ADD_MULTIPLIED_TOTAL));
         }

         if (player.getHealth() > player.getMaxHealth()) {
            player.setHealth(player.getMaxHealth());
         }
      }
   }

   private static void removeAttributeModifier(ServerPlayer player, Holder<Attribute> attribute, ResourceLocation modifierId) {
      AttributeInstance attr = player.getAttribute(attribute);
      if (attr != null) {
         if (attr.getModifier(modifierId) != null) {
            attr.removeModifier(modifierId);
         }

         if (player.getHealth() > player.getMaxHealth()) {
            player.setHealth(player.getMaxHealth());
         }
      }
   }

   private static void removeWithdrawalModifiers(ServerPlayer player) {
      removeAttributeModifier(player, Attributes.MAX_HEALTH, WITHDRAWAL_HEALTH_ID);
      removeAttributeModifier(player, Attributes.MOVEMENT_SPEED, WITHDRAWAL_SPEED_ID);
      removeAttributeModifier(player, Attributes.ATTACK_DAMAGE, WITHDRAWAL_ATTACK_ID);
   }

   private static void removeOverloadModifiers(ServerPlayer player) {
      removeAttributeModifier(player, Attributes.MAX_HEALTH, OVERLOAD_HEALTH_ID);
      removeAttributeModifier(player, Attributes.MOVEMENT_SPEED, OVERLOAD_SPEED_ID);
      removeAttributeModifier(player, Attributes.ATTACK_DAMAGE, OVERLOAD_ATTACK_ID);
   }

   private static String formatDuration(int ticks) {
      int totalSeconds = Math.max(0, (ticks + 19) / 20);
      int minutes = totalSeconds / 60;
      int seconds = totalSeconds % 60;
      return String.format("%02d:%02d", minutes, seconds);
   }
}
