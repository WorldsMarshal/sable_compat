package com.invfix.vpower.server;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.ToadSkill;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.animal.frog.Frog;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent.Post;

@EventBusSubscriber(
   modid = "sable_compat"
)
public final class ToadFrogCompanionHandler {
   private static final String TOAD_ID = ToadSkill.ID.toString();
   private static final String OWNER_TAG = "theboysmod_toad_owner";
   private static final double COMMAND_RANGE = 48.0;
   private static final double FOLLOW_START_DISTANCE = 8.0;
   private static final double TELEPORT_BACK_DISTANCE = 40.0;
   private static final double ATTACK_RANGE = 1.65;
   private static final double FOLLOW_SPEED = 1.05;
   private static final double ATTACK_SPEED = 1.35;
   private static final float FROG_DAMAGE = 3.0F;
   private static final int SUMMON_COOLDOWN_TICKS = 8;
   private static final int ATTACK_COOLDOWN_TICKS = 18;
   private static final Map<UUID, Boolean> WAS_CROUCHING = new ConcurrentHashMap<>();
   private static final Map<UUID, Integer> SUMMON_COOLDOWNS = new ConcurrentHashMap<>();
   private static final Map<UUID, UUID> FROG_TARGETS = new ConcurrentHashMap<>();
   private static final Map<UUID, Long> FROG_ATTACK_TIMES = new ConcurrentHashMap<>();

   private ToadFrogCompanionHandler() {
   }

   @SubscribeEvent
   public static void onPlayerTick(Post event) {
      if (event.getEntity() instanceof ServerPlayer player && !player.level().isClientSide) {
         UUID playerId = player.getUUID();
         boolean hasToad = hasToad(player);
         boolean crouching = player.isShiftKeyDown();
         boolean wasCrouching = WAS_CROUCHING.getOrDefault(playerId, false);
         WAS_CROUCHING.put(playerId, crouching);
         int cooldown = Math.max(0, SUMMON_COOLDOWNS.getOrDefault(playerId, 0) - 1);
         if (cooldown > 0) {
            SUMMON_COOLDOWNS.put(playerId, cooldown);
         } else {
            SUMMON_COOLDOWNS.remove(playerId);
         }

         if (hasToad && crouching && !wasCrouching && cooldown <= 0) {
            summonOwnedFrog(player);
            SUMMON_COOLDOWNS.put(playerId, 8);
         }

         if (hasToad) {
            tickOwnedFrogs(player);
         }

         return;
      }
   }

   @SubscribeEvent
   public static void onIncomingDamage(LivingIncomingDamageEvent event) {
      Entity sourceEntity = event.getSource().getEntity();
      Entity directEntity = event.getSource().getDirectEntity();
      LivingEntity victim = event.getEntity();
      if (sourceEntity instanceof ServerPlayer owner && hasToad(owner) && victim != owner) {
         commandOwnedFrogs(owner, victim);
      }

      if (victim instanceof ServerPlayer owner && hasToad(owner)) {
         LivingEntity attacker = sourceEntity instanceof LivingEntity livingx ? livingx : (directEntity instanceof LivingEntity living ? living : null);
         if (attacker != null && attacker != owner && !isOwnedFrogOf(attacker, owner.getUUID())) {
            commandOwnedFrogs(owner, attacker);
         }
      }
   }

   @SubscribeEvent
   public static void onPlayerLoggedOut(PlayerLoggedOutEvent event) {
      UUID uuid = event.getEntity().getUUID();
      WAS_CROUCHING.remove(uuid);
      SUMMON_COOLDOWNS.remove(uuid);
   }

   private static void summonOwnedFrog(ServerPlayer owner) {
      ServerLevel level = owner.serverLevel();
      Frog frog = (Frog)EntityType.FROG.create(level);
      if (frog != null) {
         Vec3 look = owner.getLookAngle();
         Vec3 spawnPos = owner.position().add(look.x * 0.9, 0.0, look.z * 0.9);
         frog.moveTo(spawnPos.x, owner.getY(), spawnPos.z, owner.getYRot(), 0.0F);
         DifficultyInstance difficulty = level.getCurrentDifficultyAt(frog.blockPosition());
         frog.finalizeSpawn(level, difficulty, MobSpawnType.TRIGGERED, null);
         frog.getPersistentData().putUUID("theboysmod_toad_owner", owner.getUUID());
         frog.setPersistenceRequired();
         if (level.addFreshEntity(frog)) {
            level.playSound(null, frog.getX(), frog.getY(), frog.getZ(), SoundEvents.FROG_AMBIENT, SoundSource.NEUTRAL, 0.9F, 1.0F);
         }
      }
   }

   private static void commandOwnedFrogs(ServerPlayer owner, LivingEntity target) {
      if (isValidTarget(owner, target)) {
         for (Frog frog : getOwnedFrogs(owner)) {
            FROG_TARGETS.put(frog.getUUID(), target.getUUID());
            frog.getNavigation().moveTo(target, 1.35);
            frog.getLookControl().setLookAt(target, 80.0F, 80.0F);
         }
      }
   }

   private static void tickOwnedFrogs(ServerPlayer owner) {
      long gameTime = owner.serverLevel().getGameTime();

      for (Frog frog : getOwnedFrogs(owner)) {
         if (!frog.isAlive()) {
            clearFrogRuntimeState(frog.getUUID());
         } else if (frog.distanceToSqr(owner) > 1600.0) {
            frog.moveTo(owner.getX(), owner.getY(), owner.getZ(), owner.getYRot(), 0.0F);
            frog.getNavigation().stop();
            clearFrogRuntimeState(frog.getUUID());
         } else {
            LivingEntity target = resolveTarget(owner.serverLevel(), frog);
            if (target != null && isValidTarget(owner, target)) {
               tickAttackTarget(frog, target, gameTime);
            } else {
               clearFrogRuntimeState(frog.getUUID());
               tickFollowOwner(frog, owner);
            }
         }
      }
   }

   private static void tickAttackTarget(Frog frog, LivingEntity target, long gameTime) {
      frog.getLookControl().setLookAt(target, 80.0F, 80.0F);
      double distanceSqr = frog.distanceToSqr(target);
      if (distanceSqr > 2.7224999999999997) {
         frog.getNavigation().moveTo(target, 1.35);
      } else {
         frog.getNavigation().stop();
         long lastAttack = FROG_ATTACK_TIMES.getOrDefault(frog.getUUID(), -1000L);
         if (gameTime - lastAttack >= 18L) {
            if (target.hurt(frog.damageSources().mobAttack(frog), 3.0F)) {
               Vec3 push = target.position().subtract(frog.position()).normalize().scale(0.25);
               target.setDeltaMovement(target.getDeltaMovement().add(push.x, 0.08, push.z));
               target.hurtMarked = true;
               frog.setTongueTarget(target);
               FROG_ATTACK_TIMES.put(frog.getUUID(), gameTime);
            }
         }
      }
   }

   private static void tickFollowOwner(Frog frog, ServerPlayer owner) {
      if (frog.distanceToSqr(owner) > 64.0) {
         frog.getNavigation().moveTo(owner, 1.05);
         frog.getLookControl().setLookAt(owner, 50.0F, 50.0F);
      }
   }

   private static LivingEntity resolveTarget(ServerLevel level, Frog frog) {
      UUID targetId = FROG_TARGETS.get(frog.getUUID());
      if (targetId == null) {
         return null;
      } else {
         if (level.getEntity(targetId) instanceof LivingEntity living && living.isAlive()) {
            return living;
         }

         return null;
      }
   }

   private static List<Frog> getOwnedFrogs(ServerPlayer owner) {
      AABB box = owner.getBoundingBox().inflate(48.0);
      UUID ownerId = owner.getUUID();
      return owner.serverLevel().getEntitiesOfClass(Frog.class, box, frog -> frog.isAlive() && isOwnedFrogOf(frog, ownerId));
   }

   private static boolean isValidTarget(ServerPlayer owner, LivingEntity target) {
      if (target != null && target.isAlive() && target != owner && !target.isSpectator()) {
         if (target instanceof Player player && player.isCreative()) {
            return false;
         }

         return !isOwnedFrogOf(target, owner.getUUID());
      } else {
         return false;
      }
   }

   private static boolean isOwnedFrogOf(Entity entity, UUID ownerId) {
      return entity instanceof Frog frog ? readOwner(frog).map(ownerId::equals).orElse(false) : false;
   }

   private static Optional<UUID> readOwner(Frog frog) {
      try {
         if (frog.getPersistentData().hasUUID("theboysmod_toad_owner")) {
            return Optional.of(frog.getPersistentData().getUUID("theboysmod_toad_owner"));
         }
      } catch (Exception var2) {
      }

      return Optional.empty();
   }

   private static boolean hasToad(Player player) {
      try {
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         return data.hasSkill(TOAD_ID);
      } catch (Exception var2) {
         return false;
      }
   }

   private static void clearFrogRuntimeState(UUID frogId) {
      FROG_TARGETS.remove(frogId);
      FROG_ATTACK_TIMES.remove(frogId);
   }
}
