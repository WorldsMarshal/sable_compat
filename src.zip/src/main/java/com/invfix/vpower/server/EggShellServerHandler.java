package com.invfix.vpower.server;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.EggShellSkill;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent.Pre;
import net.neoforged.neoforge.event.tick.PlayerTickEvent.Post;

@EventBusSubscriber(
   modid = "sable_compat"
)
public final class EggShellServerHandler {
   private static final String EGG_SHELL_ID = EggShellSkill.ID.toString();
   private static final ResourceLocation EGG_SHELL_STEP_ID = ResourceLocation.fromNamespaceAndPath("theboysmod", "egg_shell_step");
   private static final int ON_DELAY_TICKS = 15;
   private static final int HIT_COOLDOWN_TICKS = 10;
   private static final double MIN_ROLL_MOVEMENT = 0.035;
   private static final double HIT_RADIUS = 0.45;
   private static final double STEP_HEIGHT_BOOST = 1.0;
   private static final float ROLL_DAMAGE = 3.0F;
   private static final float CODE_RESISTANCE_REDUCTION = 0.2F;
   private static final float CODE_ARMOR_REDUCTION = 0.2F;
   private static final float TOTAL_DAMAGE_MULTIPLIER = 0.040000003F;
   public static volatile boolean EGG_SHELL_IMPACT_ACTIVE = false;
   private static final Map<Integer, Integer> ACTIVE_TICKS = new ConcurrentHashMap<>();
   private static final Map<Integer, Vec3> PREV_POSITIONS = new ConcurrentHashMap<>();
   private static final Map<Integer, Map<Integer, Long>> HIT_COOLDOWNS = new ConcurrentHashMap<>();

   private EggShellServerHandler() {
   }

   @SubscribeEvent
   public static void onPlayerTick(Post event) {
      if (event.getEntity() instanceof ServerPlayer player && !player.level().isClientSide) {
         int playerId = player.getId();
         if (!isEggShellToggled(player)) {
            ACTIVE_TICKS.remove(playerId);
            PREV_POSITIONS.remove(playerId);
            HIT_COOLDOWNS.remove(playerId);
            applyOrRemoveStepHeight(player, false);
            return;
         }

         int activeTicks = ACTIVE_TICKS.merge(playerId, 1, Integer::sum);
         boolean shellOn = activeTicks >= 15;
         applyOrRemoveStepHeight(player, shellOn);
         Vec3 currentPos = player.position();
         Vec3 prevPos = PREV_POSITIONS.put(playerId, currentPos);
         if (shellOn && prevPos != null) {
            double dx = currentPos.x - prevPos.x;
            double dz = currentPos.z - prevPos.z;
            double horizontalMovement = Math.sqrt(dx * dx + dz * dz);
            if (horizontalMovement < 0.035) {
               return;
            }

            damageRolledEntities(player, new Vec3(dx, 0.0, dz), player.level().getGameTime());
            return;
         }

         return;
      }
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public static void onLivingDamage(Pre event) {
      if (!(event.getEntity() instanceof ServerPlayer player) || player.level().isClientSide) {
         return;
      }

      if (isEggShellOn(player)) {
         if (!event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            float damage = event.getNewDamage();
            if (!(damage <= 0.0F)) {
               event.setNewDamage(damage * 0.040000003F);
            }
         }
      }
   }

   public static boolean isEggShellOn(ServerPlayer player) {
      return ACTIVE_TICKS.getOrDefault(player.getId(), 0) >= 15 && isEggShellToggled(player);
   }

   private static boolean isEggShellToggled(ServerPlayer player) {
      try {
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         return data.hasSkill(EGG_SHELL_ID) && data.isSkillActive(EGG_SHELL_ID);
      } catch (Exception var2) {
         return false;
      }
   }

   private static void applyOrRemoveStepHeight(ServerPlayer player, boolean shouldApply) {
      AttributeInstance stepHeight = player.getAttribute(Attributes.STEP_HEIGHT);
      if (stepHeight != null) {
         if (shouldApply) {
            if (stepHeight.getModifier(EGG_SHELL_STEP_ID) == null) {
               stepHeight.addTransientModifier(new AttributeModifier(EGG_SHELL_STEP_ID, 1.0, Operation.ADD_VALUE));
            }
         } else if (stepHeight.getModifier(EGG_SHELL_STEP_ID) != null) {
            stepHeight.removeModifier(EGG_SHELL_STEP_ID);
         }
      }
   }

   private static void damageRolledEntities(ServerPlayer player, Vec3 movement, long gameTime) {
      AABB hitBox = player.getBoundingBox().inflate(0.45, 0.15, 0.45);
      List<Entity> entities = player.serverLevel().getEntities(player, hitBox, entityx -> {
         if (entityx instanceof LivingEntity living && living.isAlive() && entityx != player && canDamageTarget(entityx)) {
            return true;
         }

         return false;
      });
      if (!entities.isEmpty()) {
         Map<Integer, Long> cooldowns = HIT_COOLDOWNS.computeIfAbsent(player.getId(), id -> new ConcurrentHashMap<>());
         Vec3 push = movement.normalize();

         for (Entity entity : entities) {
            long lastHit = cooldowns.getOrDefault(entity.getId(), -10L);
            if (gameTime - lastHit >= 10L) {
               LivingEntity target = (LivingEntity)entity;
               EGG_SHELL_IMPACT_ACTIVE = true;

               try {
                  target.hurt(player.damageSources().playerAttack(player), 3.0F);
               } finally {
                  EGG_SHELL_IMPACT_ACTIVE = false;
               }

               target.setDeltaMovement(target.getDeltaMovement().add(push.x * 0.7, 0.12, push.z * 0.7));
               target.hurtMarked = true;
               cooldowns.put(entity.getId(), gameTime);
            }
         }

         cooldowns.entrySet().removeIf(entry -> gameTime - entry.getValue() > 200L);
      }
   }

   private static boolean canDamageTarget(Entity entity) {
      return !(entity instanceof Player player) ? true : !player.isCreative() && !player.isSpectator();
   }
}
