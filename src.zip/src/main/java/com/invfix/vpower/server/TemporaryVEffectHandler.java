package com.invfix.vpower.server;

import com.invfix.vpower.VPower;
import com.invfix.vpower.network.SkillSyncPacket;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent.Post;

@EventBusSubscriber(
   modid = "sable_compat"
)
public class TemporaryVEffectHandler {
   @SubscribeEvent
   public static void onPlayerTick(Post event) {
      if (event.getEntity() instanceof ServerPlayer player && player.getServer() != null) {
         SkillData skillData = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         if (!skillData.hasTemporarySkills()) {
            return;
         }

         long gameTime = player.getServer().overworld().getGameTime();
         if (!skillData.expireTemporarySkills(gameTime)) {
            return;
         }

         TempVSideEffectHandler.onTemporaryVExpired(player, skillData, gameTime);
         FleshStrengthHandler.refreshHealthModifier(player, skillData);
         SkillSyncPacket.syncToClient(player);
         VPower.LOGGER.info("[TempV] Player {} temporary skills expired", player.getName().getString());
         return;
      }
   }
}
