package com.invfix.vpower.server;

import com.invfix.vpower.attachment.FleshRegenData;
import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.skills.DiamondClawsExtensionSkill;
import com.invfix.vpower.skill.skills.DiamondClawsSkill;
import com.invfix.vpower.skill.skills.SuperStrengthSkill;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.BreakSpeed;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.HarvestCheck;

@EventBusSubscriber(
   modid = "sable_compat"
)
public final class DiamondClawsMiningHandler {
   private static final String CLAWS_ID = DiamondClawsSkill.ID.toString();
   private static final String EXTENSION_ID = DiamondClawsExtensionSkill.ID.toString();
   private static final String SUPER_STRENGTH_ID = SuperStrengthSkill.ID.toString();
   private static final ItemStack NETHERITE_PICKAXE = Items.NETHERITE_PICKAXE.getDefaultInstance();

   private DiamondClawsMiningHandler() {
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public static void onHarvestCheck(HarvestCheck event) {
      Player player = event.getEntity();
      BlockState state = event.getTargetBlock();
      if (!event.canHarvest() && canUseNetheriteHands(player) && state != null && !state.isAir()) {
         if (NETHERITE_PICKAXE.isCorrectToolForDrops(state)) {
            event.setCanHarvest(true);
         }
      }
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public static void onBreakSpeed(BreakSpeed event) {
      Player player = event.getEntity();
      BlockState state = event.getState();
      if (canUseNetheriteHands(player) && state != null && !state.isAir() && !(event.getOriginalSpeed() <= 0.0F)) {
         float netheriteSpeed = NETHERITE_PICKAXE.getDestroySpeed(state);
         if (!(netheriteSpeed <= 1.0F)) {
            event.setNewSpeed(Math.max(event.getNewSpeed(), netheriteSpeed * event.getOriginalSpeed()));
         }
      }
   }

   public static boolean canUseNetheriteHands(Player player) {
      if (player != null && !player.isSpectator() && player.getMainHandItem().isEmpty()) {
         SkillData data = (SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get());
         return (hasExtendedClaws(data) || hasSuperStrengthMining(data)) && hasUsableMainHand(player);
      } else {
         return false;
      }
   }

   public static boolean hasExtendedClaws(Player player) {
      return player != null && player.getMainHandItem().isEmpty() && hasUsableMainHand(player)
         ? hasExtendedClaws((SkillData)player.getData(ModSkillAttachments.SKILL_DATA.get()))
         : false;
   }

   private static boolean hasExtendedClaws(SkillData data) {
      return data.hasSkill(CLAWS_ID) && data.hasSkill(EXTENSION_ID) && data.isSkillActive(EXTENSION_ID);
   }

   private static boolean hasSuperStrengthMining(SkillData data) {
      return data.hasSkill(SUPER_STRENGTH_ID) && data.getSuperStrengthLevel() >= 3;
   }

   public static boolean hasUsableMainHand(Player player) {
      try {
         FleshRegenData fleshData = (FleshRegenData)player.getData(ModAttachments.FLESH_REGEN.get());
         HumanoidArm mainArm = player.getMainArm();
         String key = mainArm == HumanoidArm.LEFT ? "Left.Hand" : "Right.Hand";
         return fleshData.getScore(key) != 0;
      } catch (Exception var4) {
         return true;
      }
   }
}
