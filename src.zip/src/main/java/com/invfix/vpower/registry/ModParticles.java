package com.invfix.vpower.registry;

import java.util.function.Supplier;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.Registries;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModParticles {
   public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(Registries.PARTICLE_TYPE, "theboysmod");
   public static final Supplier<SimpleParticleType> CLAP = PARTICLES.register("clap", () -> new SimpleParticleType(false));
   public static final Supplier<SimpleParticleType> BLOOD = PARTICLES.register("blood", () -> new SimpleParticleType(false));

   public static void register(IEventBus bus) {
      PARTICLES.register(bus);
   }
}
