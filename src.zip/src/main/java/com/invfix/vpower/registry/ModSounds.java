package com.invfix.vpower.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModSounds {
   public static final DeferredRegister<SoundEvent> SOUND_EVENTS = DeferredRegister.create(Registries.SOUND_EVENT, "theboysmod");
   public static final DeferredHolder<SoundEvent, SoundEvent> BLOOD_BOOM = SOUND_EVENTS.register(
      "blood_boom", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("theboysmod", "blood_boom"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> REGENERATION = SOUND_EVENTS.register(
      "regeneration", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("theboysmod", "regeneration"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> LASER_EYE = SOUND_EVENTS.register(
      "laser_eye", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("theboysmod", "laser_eye"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> LASER_EYE_START = SOUND_EVENTS.register(
      "laser_eye_start", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("theboysmod", "laser_eye_start"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> LASER_EYE_END = SOUND_EVENTS.register(
      "laser_eye_end", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("theboysmod", "laser_eye_end"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> EVASION = SOUND_EVENTS.register(
      "evasion", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("theboysmod", "evasion"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> SPEED_RUNNING = SOUND_EVENTS.register(
      "speed_running", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("theboysmod", "speed_running"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> SOUND_WAVES_UP = SOUND_EVENTS.register(
      "sound_waves_up", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("theboysmod", "sound_waves_up"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> NAILONG_BELIAL_TRANSFORM = SOUND_EVENTS.register(
      "nailong_belial_transform", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("theboysmod", "nailong_belial_transform"))
   );

   public static void register(IEventBus eventBus) {
      SOUND_EVENTS.register(eventBus);
   }
}
