package com.invfix.vpower.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageType;

public class ModDamageTypes {
   public static final ResourceKey<DamageType> DETACH_HEAD = ResourceKey.create(
      Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("theboysmod", "detach_head")
   );
   public static final ResourceKey<DamageType> DETACH_BODY = ResourceKey.create(
      Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("theboysmod", "detach_body")
   );
   public static final ResourceKey<DamageType> DETACH_RIGHT_ARM = ResourceKey.create(
      Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("theboysmod", "detach_right_arm")
   );
   public static final ResourceKey<DamageType> DETACH_LEFT_ARM = ResourceKey.create(
      Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("theboysmod", "detach_left_arm")
   );
   public static final ResourceKey<DamageType> DETACH_RIGHT_HAND = ResourceKey.create(
      Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("theboysmod", "detach_right_hand")
   );
   public static final ResourceKey<DamageType> DETACH_LEFT_HAND = ResourceKey.create(
      Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("theboysmod", "detach_left_hand")
   );
   public static final ResourceKey<DamageType> DETACH_RIGHT_LEG = ResourceKey.create(
      Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("theboysmod", "detach_right_leg")
   );
   public static final ResourceKey<DamageType> DETACH_LEFT_LEG = ResourceKey.create(
      Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("theboysmod", "detach_left_leg")
   );
   public static final ResourceKey<DamageType> DETACH_RIGHT_FEET = ResourceKey.create(
      Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("theboysmod", "detach_right_feet")
   );
   public static final ResourceKey<DamageType> DETACH_LEFT_FEET = ResourceKey.create(
      Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("theboysmod", "detach_left_feet")
   );
   public static final ResourceKey<DamageType> DEVOUR = ResourceKey.create(
      Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("theboysmod", "devour")
   );
   public static final ResourceKey<DamageType> THUNDER = ResourceKey.create(
      Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("theboysmod", "thunder")
   );
   public static final ResourceKey<DamageType> STOMP = ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath("theboysmod", "stomp"));

   public static ResourceKey<DamageType> getForPart(String partKey) {
      return switch (partKey) {
         case "Head" -> DETACH_HEAD;
         case "Body" -> DETACH_BODY;
         case "Right.Arm" -> DETACH_RIGHT_ARM;
         case "Left.Arm" -> DETACH_LEFT_ARM;
         case "Right.Hand" -> DETACH_RIGHT_HAND;
         case "Left.Hand" -> DETACH_LEFT_HAND;
         case "Right.Leg" -> DETACH_RIGHT_LEG;
         case "Left.Leg" -> DETACH_LEFT_LEG;
         case "Right.Feet" -> DETACH_RIGHT_FEET;
         case "Left.Feet" -> DETACH_LEFT_FEET;
         default -> DETACH_BODY;
      };
   }
}
