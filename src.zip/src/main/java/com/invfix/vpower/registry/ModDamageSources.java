package com.invfix.vpower.registry;

import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class ModDamageSources {
   private final RegistryAccess registryAccess;

   public ModDamageSources(RegistryAccess registryAccess) {
      this.registryAccess = registryAccess;
   }

   public static ModDamageSources of(Level level) {
      return new ModDamageSources(level.registryAccess());
   }

   public static ModDamageSources of(RegistryAccess registryAccess) {
      return new ModDamageSources(registryAccess);
   }

   public DamageSource devour(@Nullable Entity attacker) {
      return new DamageSource(this.registryAccess.registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ModDamageTypes.DEVOUR), attacker);
   }

   public DamageSource thunder(@Nullable Entity attacker) {
      return new DamageSource(this.registryAccess.registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ModDamageTypes.THUNDER), attacker);
   }

   public DamageSource stomp(@Nullable Entity attacker) {
      return new DamageSource(this.registryAccess.registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ModDamageTypes.STOMP), null, attacker);
   }
}
