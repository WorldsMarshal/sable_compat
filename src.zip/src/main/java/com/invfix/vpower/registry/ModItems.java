package com.invfix.vpower.registry;

import com.invfix.vpower.item.SyringeItem;
import com.invfix.vpower.item.TooltipItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredRegister.Items;

/**
 * Предметы препарата V. Id — под неймспейсом theboysmod, как были в The Boys: шприцы и колбы в мирах и сундуках
 * переживают удаление мода (ассеты — assets/theboysmod/...).
 */
public class ModItems {
   public static final Items ITEMS = DeferredRegister.createItems("theboysmod");
   public static final DeferredItem<Item> SYRINGE = ITEMS.register("syringe", () -> new Item(new Properties().stacksTo(1)));
   public static final DeferredItem<Item> COMPOUND_V = ITEMS.register("compound_v", () -> new TooltipItem(new Properties().stacksTo(1).rarity(Rarity.EPIC)));
   public static final DeferredItem<Item> COMPOUND_V_SYRINGE = ITEMS.register(
      "compound_v_syringe", () -> new SyringeItem(new Properties().stacksTo(1).rarity(Rarity.EPIC))
   );
   public static final DeferredItem<Item> COMPOUND_V_TEMP = ITEMS.register(
      "compound_v_temp", () -> new TooltipItem(new Properties().stacksTo(1).rarity(Rarity.EPIC))
   );
   public static final DeferredItem<Item> COMPOUND_V_TEMP_SYRINGE = ITEMS.register(
      "compound_v_temp_syringe", () -> new SyringeItem(new Properties().stacksTo(1).rarity(Rarity.EPIC))
   );
   public static final DeferredItem<Item> COMPOUND_V_REMOVE = ITEMS.register(
      "compound_v_remove", () -> new TooltipItem(new Properties().stacksTo(1).rarity(Rarity.EPIC))
   );
   public static final DeferredItem<Item> COMPOUND_V_REMOVE_SYRINGE = ITEMS.register(
      "compound_v_remove_syringe", () -> new SyringeItem(new Properties().stacksTo(1).rarity(Rarity.EPIC))
   );
}
