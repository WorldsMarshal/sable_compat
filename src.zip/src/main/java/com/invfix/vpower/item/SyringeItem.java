package com.invfix.vpower.item;

import com.invfix.vpower.VRaces;
import com.invfix.vpower.network.InjectVPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class SyringeItem extends TooltipItem {
   private static final int USE_DURATION_TICKS = 50;
   private static final int PRICK_TICK = 45;

   public SyringeItem(Properties properties) {
      super(properties);
   }

   public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
      ItemStack stack = player.getItemInHand(hand);
      if (InjectVPacket.syringeTypeFromStack(stack) == null) {
         return InteractionResultHolder.pass(stack);
      } else if (this.raceBlocked(level, player, stack)) {
         return InteractionResultHolder.pass(stack);
      } else {
         player.startUsingItem(hand);
         return InteractionResultHolder.consume(stack);
      }
   }

   public InteractionResult useOn(UseOnContext context) {
      Player player = context.getPlayer();
      if (player == null || this.raceBlocked(context.getLevel(), player, context.getItemInHand())) {
         return InteractionResult.PASS;
      } else {
         player.startUsingItem(context.getHand());
         return InteractionResult.CONSUME;
      }
   }

   /** Себе V можно колоть только с человеческой ДНК (VRaces) — иначе отказ до начала, шприц цел. */
   private boolean raceBlocked(Level level, Player player, ItemStack stack) {
      String msg = VRaces.blockMessage(player, stack);
      if (msg == null) {
         return false;
      }
      if (!level.isClientSide) {
         player.displayClientMessage(Component.literal(msg), true);
      }
      return true;
   }

   public UseAnim getUseAnimation(ItemStack stack) {
      return UseAnim.NONE;
   }

   public int getUseDuration(ItemStack stack, LivingEntity entity) {
      return 50;
   }

   public void onUseTick(Level level, LivingEntity livingEntity, ItemStack stack, int remainingUseDuration) {
      if (!level.isClientSide && livingEntity instanceof ServerPlayer player) {
         int usedTicks = this.getUseDuration(stack, livingEntity) - remainingUseDuration;
         if (usedTicks == 45) {
            InjectVPacket.applyPrickEffect(player);
         }
      }
   }

   public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity livingEntity) {
      if (!level.isClientSide && livingEntity instanceof ServerPlayer player) {
         String syringeType = InjectVPacket.syringeTypeFromStack(stack);
         if (syringeType != null) {
            InjectVPacket.injectTarget(player, player, syringeType, stack);
         }
      }

      return stack;
   }
}
