package com.invfix.vpower;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.skills.FlightSkill;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;

/**
 * Навык Flight (The Boys) — это полёт Invincible: для FlightOnOff и проверки в тике игрока навык считается
 * пассивкой «Flight» (VFlightMixins). Скорость полёта без прокачки: предел {@link #CAP} (Born for V —
 * {@link #CAP_BORN_FOR_V}), вместо родного trueSpeed / 2. Если у игрока есть и родная пассивка Flight —
 * работает родной полёт с родным пределом.
 */
public final class VFlight {

    public static final double CAP = 2.0;
    public static final double CAP_BORN_FOR_V = 3.0;

    private static final String FLIGHT = FlightSkill.ID.toString();

    private VFlight() {}

    /** Навык Flight — без урона от падения (в The Boys защита была только у крыльев; раньше — FlightFallHandler). */
    @EventBusSubscriber(modid = "sable_compat")
    public static final class Fall {
        @SubscribeEvent
        public static void onLivingFall(LivingFallEvent event) {
            if (event.getEntity() instanceof ServerPlayer player && has(player)) {
                player.fallDistance = 0.0F;
                event.setCanceled(true);
            }
        }
    }

    /** Есть навык Flight (постоянный или от Temp V). */
    public static boolean has(Entity entity) {
        if (!(entity instanceof Player player)) return false;
        try {
            return player.getData(ModSkillAttachments.SKILL_DATA.get()).hasSkill(FLIGHT);
        } catch (Throwable t) {
            return false;
        }
    }

    /** Родная пассивка Flight Invincible (раса или сила) — те же 8 полей, что проверяет FlightOnOffProcedure. */
    public static boolean nativeFlight(InvincibleIncModVariables.PlayerVariables v) {
        return "Flight".equals(v.racePassive1) || "Flight".equals(v.racePassive2)
                || "Flight".equals(v.racePassive3) || "Flight".equals(v.racePassive4)
                || "Flight".equals(v.power_Passive1) || "Flight".equals(v.power_Passive2)
                || "Flight".equals(v.power_Passive3) || "Flight".equals(v.power_Passive4);
    }

    /** Предел скорости полёта из V: перед расчётом полёта и перед сменой скорости клавишей. */
    public static void capSpeed(Entity entity) {
        if (!(entity instanceof Player player) || !has(player)) return;
        InvincibleIncModVariables.PlayerVariables v =
                (InvincibleIncModVariables.PlayerVariables) player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        if (nativeFlight(v)) return;
        double cap = VRaces.bornForV(player) ? CAP_BORN_FOR_V : CAP;
        boolean changed = false;
        if (v.flightspeedmax != cap) {
            v.flightspeedmax = cap;
            changed = true;
        }
        if (v.flightSpeed > cap) {
            v.flightSpeed = cap;
            changed = true;
        }
        if (changed) v.markSyncDirty();
    }
}
