package com.invfix.vpower;

import com.invfix.humanlike.HumanLikeRaces;
import com.invfix.theboys.CompoundVRegistry;
import com.invfix.vpower.network.SkillSyncPacket;
import com.invfix.vpower.server.FleshStrengthHandler;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.ModSkills;
import com.invfix.vpower.skill.SkillData;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import javax.annotation.Nullable;
import java.util.Set;

/**
 * Препарат V и расы Invincible (раньше — миксины в The Boys: SyringeRaceRule, HumanCompoundV, BornForVPowers).
 *  - Compound V и Temp V — только для человеческой ДНК ПОЛУЧАТЕЛЯ: Human, Human(Born for V), Human(Predisposition
 *    to V), Human-Viltrumite. Остальным — «… was created for human DNA.», шприц цел.
 *  - Born for V: Compound V — набор Хоумлендера сразу на максимуме (Super Strength 5, Heat Vision 5, Flesh
 *    Strength 5, Flight, Super Vision); побочки Temp V (ломка, передоз) на него не действуют.
 *  - Human (§f§lHuman): первый Compound V — 90% смерть, 5% тошнота и отравление на 20 минут, 5% — способность;
 *    под отравлением — смерть. Когда способность уже есть, укол идёт на прокачку без броска. Temp V под Critical
 *    Poisoning не колется; когда Temp V заканчивается — Critical Poisoning на 20 минут.
 *  - Predisposition, Human-Viltrumite (и Human при успехе) — как в The Boys: одна случайная способность из пула,
 *    повторные уколы её докачивают.
 */
public final class VRaces {

    public static final String HUMAN = "§f§lHuman";

    private static final Set<String> HUMAN_DNA = Set.of(
            HUMAN,
            "§lHuman",
            "Human",
            "§f§lHuman-Viltrumite",
            HumanLikeRaces.BORN_FOR_V,
            HumanLikeRaces.PREDISPOSITION);

    private static final int TWENTY_MINUTES = 20 * 60 * 20;
    private static final float COMPOUND_V_LETHAL_DAMAGE = 80.0F;
    private static final float COMPOUND_V_SICK_DAMAGE = 18.0F;
    /** Бросок 0..99: [0, 90) — смерть, [90, 95) — отравление, [95, 100) — способность. */
    private static final int CHANCE_DEATH = 90;
    private static final int CHANCE_SICK = 95;

    private VRaces() {}

    @Nullable
    public static String race(@Nullable Player player) {
        if (player == null) return null;
        try {
            return ((InvincibleIncModVariables.PlayerVariables) player.getData(InvincibleIncModVariables.PLAYER_VARIABLES)).Race;
        } catch (Throwable t) {
            return null;
        }
    }

    public static boolean humanDna(@Nullable Player player) {
        String race = race(player);
        return race != null && HUMAN_DNA.contains(race);
    }

    public static boolean bornForV(@Nullable Player player) {
        return HumanLikeRaces.BORN_FOR_V.equals(race(player));
    }

    public static boolean human(@Nullable Player player) {
        return HUMAN.equals(race(player));
    }

    /** "Compound V" / "Temp V", или null — не шприц с V (например, средство удаления). */
    @Nullable
    private static String vLabel(@Nullable ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;
        String id = stack.getItemHolder().getRegisteredName();
        if ("theboysmod:compound_v_syringe".equals(id)) return "Compound V";
        if ("theboysmod:compound_v_temp_syringe".equals(id)) return "Temp V";
        return null;
    }

    /** Сообщение отказа, если получателю нельзя этот шприц (не человеческая ДНК); иначе null. */
    @Nullable
    public static String blockMessage(@Nullable Player recipient, @Nullable ItemStack stack) {
        String label = vLabel(stack);
        if (label == null || recipient == null || humanDna(recipient)) return null;
        return label + " was created for human DNA.";
    }

    /**
     * Перед инъекцией (InjectVPacket.injectTarget). null — дальше штатная механика The Boys; иначе — её результат
     * (true — шприц потрачен).
     */
    @Nullable
    public static Boolean beforeInject(ServerPlayer injector, ServerPlayer target, String syringeType, ItemStack syringe) {
        String msg = blockMessage(target, syringe);
        if (msg != null) {
            if (injector != null) injector.displayClientMessage(Component.literal(msg), true);
            return false;
        }
        if ("compound_v_syringe".equals(syringeType) && bornForV(target)) {
            int result = grantHomelanderKit(target);
            if (result == KIT_DEFER) return null;
            if (result == KIT_GRANTED) {
                syringe.shrink(1);
                return true;
            }
            return false;
        }
        if (!human(target)) return null;
        SkillData data = target.getData(ModSkillAttachments.SKILL_DATA.get());
        return switch (syringeType) {
            case "compound_v_syringe" -> {
                // способность уже прижилась — укол только на прокачку, без броска
                if (hasPermanentSkill(data)) yield null;
                yield humanCompoundV(target, syringe) ? Boolean.FALSE : null;
            }
            case "compound_v_temp_syringe" -> humanTempVBlocked(target) ? Boolean.FALSE : null;
            default -> null;
        };
    }

    // ── Human ────────────────────────────────────────────────────────────────

    /** true — укол обработан здесь (смерть или отравление, шприц потрачен); false — успех, штатная выдача. */
    private static boolean humanCompoundV(ServerPlayer target, ItemStack syringe) {
        if (target.hasEffect(MobEffects.POISON)) {
            killByV(target, syringe);
            target.sendSystemMessage(Component.literal("§4Your body was too weak to take V now."));
            return true;
        }
        int roll = target.getRandom().nextInt(100);
        if (roll < CHANCE_DEATH) {
            killByV(target, syringe);
            target.sendSystemMessage(Component.literal("§4The body rejected V. You're fucked."));
            return true;
        }
        if (roll < CHANCE_SICK) {
            syringe.shrink(1);
            target.hurt(target.damageSources().magic(), COMPOUND_V_SICK_DAMAGE);
            target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, TWENTY_MINUTES, 0, false, true, true));
            target.addEffect(new MobEffectInstance(MobEffects.POISON, TWENTY_MINUTES, 0, false, true, true));
            target.sendSystemMessage(Component.literal("§6The body rejected V. Blood is gushing from your ass."));
            return true;
        }
        return false;
    }

    private static boolean humanTempVBlocked(ServerPlayer target) {
        if (!target.hasEffect(CompoundVRegistry.CRITICAL_POISONING)) return false;
        target.sendSystemMessage(Component.literal("§4\nYou are not healthy enough to take Temp V."));
        return true;
    }

    /** Temp V закончился (любой путь): Human — Critical Poisoning на 20 минут. */
    public static void onTempVExpired(ServerPlayer target) {
        if (!human(target)) return;
        target.addEffect(new MobEffectInstance(CompoundVRegistry.CRITICAL_POISONING, TWENTY_MINUTES, 0, false, true, true));
        target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, TWENTY_MINUTES, 0, false, true, true));
        target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, TWENTY_MINUTES, 0, false, true, true));
        target.addEffect(new MobEffectInstance(MobEffects.POISON, TWENTY_MINUTES, 0, false, true, true));
        target.sendSystemMessage(Component.literal("§4Temp V has disintegrated."));
    }

    private static void killByV(ServerPlayer target, ItemStack syringe) {
        syringe.shrink(1);
        target.hurt(target.damageSources().magic(), COMPOUND_V_LETHAL_DAMAGE);
    }

    /**
     * Compound V прижился (для V-бонуса капов humanlike-рас, HumanCapsMixin): есть хотя бы одна постоянная
     * способность V — временные от Temp V не в счёт. Снял V средством удаления — бонус снимается.
     */
    public static boolean compoundVActive(Entity entity) {
        if (!(entity instanceof ServerPlayer player)) return false;
        try {
            return hasPermanentSkill(player.getData(ModSkillAttachments.SKILL_DATA.get()));
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean hasPermanentSkill(SkillData data) {
        for (String id : data.getAllSkills()) {
            if (!data.isTemporarySkill(id)) return true;
        }
        return false;
    }

    // ── Born for V ───────────────────────────────────────────────────────────

    /** Под Temp V — перманентный V не колется, отвечает штатная механика. */
    private static final int KIT_DEFER = 0;
    /** Силы выданы или докачаны — шприц тратится. */
    private static final int KIT_GRANTED = 1;
    /** Всё уже на максимуме — шприц цел. */
    private static final int KIT_MAXED = 2;

    private static int grantHomelanderKit(ServerPlayer target) {
        SkillData data = target.getData(ModSkillAttachments.SKILL_DATA.get());
        if (data.hasTemporarySkills()) return KIT_DEFER;

        String fleshStrength = ModSkills.FLESH_STRENGTH.getId().toString();
        boolean hadFleshStrength = data.hasSkill(fleshStrength);
        boolean changed = false;
        changed |= ensureSkill(data, ModSkills.SUPER_STRENGTH.getId().toString());
        changed |= ensureSkill(data, ModSkills.LASER_EYE.getId().toString());
        changed |= ensureSkill(data, fleshStrength);
        changed |= ensureSkill(data, ModSkills.FLIGHT.getId().toString());
        changed |= ensureSkill(data, ModSkills.SUPER_VISION.getId().toString());
        if (data.getSuperStrengthLevel() < 5) { data.setSuperStrengthLevel(5); changed = true; }
        if (data.getLaserEyeLevel() < 5) { data.setLaserEyeLevel(5); changed = true; }
        if (data.getFleshStrengthLevel() < 5) { data.setFleshStrengthLevel(5); changed = true; }
        if (!changed) return KIT_MAXED;

        // при первой выдаче Flesh Strength щит заполняется (как при штатной инъекции)
        boolean fill = !hadFleshStrength && data.hasSkill(fleshStrength);
        if (fill) data.setShieldHp(data.getMaxShieldHp());
        FleshStrengthHandler.refreshHealthModifier(target, data, fill);
        SkillSyncPacket.syncToClient(target);
        return KIT_GRANTED;
    }

    private static boolean ensureSkill(SkillData data, String id) {
        if (data.hasSkill(id)) return false;
        data.addSkill(id);
        return true;
    }
}
