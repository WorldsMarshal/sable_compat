package com.invfix.vpower.attachment;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.common.util.INBTSerializable;

public class FleshRegenData implements INBTSerializable<CompoundTag> {
   private final Map<String, Integer> partScores = new HashMap<>();
   private boolean compoundVRegenerationActive;
   public static final Map<String, Integer> PART_MAX_SCORES = new HashMap<>();
   public static final Map<String, Integer> PART_BONE_SCORES = new HashMap<>();
   public static final Map<String, String> CHILD_TO_PARENT = new HashMap<>();
   public static final Map<String, Integer> PARENT_CHILD_READY_SCORES = new HashMap<>();

   public FleshRegenData() {
      for (String part : PART_MAX_SCORES.keySet()) {
         this.partScores.put(part, -1);
      }
   }

   public int getScore(String partName) {
      return this.partScores.getOrDefault(partName, -1);
   }

   public void setScore(String partName, int score) {
      this.partScores.put(partName, score);
   }

   public static int getChildReadyScore(String parentPart) {
      return PARENT_CHILD_READY_SCORES.getOrDefault(parentPart, PART_MAX_SCORES.getOrDefault(parentPart, 0));
   }

   public int getEffectiveMaxScore(String partName) {
      int maxScore = PART_MAX_SCORES.getOrDefault(partName, 17);
      String childPart = getChildForParent(partName);
      return childPart != null && this.isIncomplete(childPart) ? getChildReadyScore(partName) : maxScore;
   }

   public boolean normalizeLinkedPartScores() {
      boolean changed = false;
      changed |= this.normalizeLinkedPair("Right.Arm", "Right.Hand");
      changed |= this.normalizeLinkedPair("Left.Arm", "Left.Hand");
      changed |= this.normalizeLinkedPair("Right.Leg", "Right.Feet");
      return changed | this.normalizeLinkedPair("Left.Leg", "Left.Feet");
   }

   private boolean normalizeLinkedPair(String parentPart, String childPart) {
      int parentScore = this.getScore(parentPart);
      int parentMax = PART_MAX_SCORES.getOrDefault(parentPart, 0);
      int readyScore = getChildReadyScore(parentPart);
      if (this.isIncomplete(childPart)) {
         if (parentScore != -1 && parentScore < parentMax) {
            return false;
         } else {
            this.setScore(parentPart, readyScore);
            return true;
         }
      } else if (parentScore == readyScore) {
         this.setScore(parentPart, parentMax);
         return true;
      } else {
         return false;
      }
   }

   private boolean isIncomplete(String partName) {
      int score = this.getScore(partName);
      int maxScore = PART_MAX_SCORES.getOrDefault(partName, 0);
      return score >= 0 && score < maxScore;
   }

   private static String getChildForParent(String parentPart) {
      for (Entry<String, String> entry : CHILD_TO_PARENT.entrySet()) {
         if (entry.getValue().equals(parentPart)) {
            return entry.getKey();
         }
      }

      return null;
   }

   public boolean shouldHide(String partName) {
      int score = this.getScore(partName);
      int maxScore = PART_MAX_SCORES.getOrDefault(partName, 17);
      if (score >= 0 && score < maxScore) {
         return true;
      } else {
         if (partName.equals("Right.Arm")) {
            int handScore = this.getScore("Right.Hand");
            if (handScore >= 0 && handScore < 12) {
               return true;
            }
         } else if (partName.equals("Left.Arm")) {
            int handScore = this.getScore("Left.Hand");
            if (handScore >= 0 && handScore < 12) {
               return true;
            }
         } else if (partName.equals("Right.Leg")) {
            int feetScore = this.getScore("Right.Feet");
            if (feetScore >= 0 && feetScore < 11) {
               return true;
            }
         } else if (partName.equals("Left.Leg")) {
            int feetScore = this.getScore("Left.Feet");
            if (feetScore >= 0 && feetScore < 11) {
               return true;
            }
         }

         return false;
      }
   }

   public boolean shouldRenderFlesh(String partName) {
      int score = this.getScore(partName);
      int maxScore = PART_MAX_SCORES.getOrDefault(partName, 17);
      return score > 0 && score < maxScore;
   }

   public void tick() {
      for (String partName : PART_MAX_SCORES.keySet()) {
         int score = this.getScore(partName);
         int maxScore = this.getEffectiveMaxScore(partName);
         if (score >= 0 && score < maxScore) {
            this.setScore(partName, score + 1);
         }
      }
   }

   public void resetAll() {
      for (String part : PART_MAX_SCORES.keySet()) {
         this.partScores.put(part, 0);
      }
   }

   public boolean hasDamagedParts() {
      for (String part : PART_MAX_SCORES.keySet()) {
         int score = this.getScore(part);
         int maxScore = this.getEffectiveMaxScore(part);
         if (score >= 0 && score < maxScore) {
            return true;
         }
      }

      return false;
   }

   public boolean startCompoundVRegeneration() {
      if (!this.hasDamagedParts()) {
         return false;
      } else {
         this.compoundVRegenerationActive = true;
         return true;
      }
   }

   public boolean isCompoundVRegenerationActive() {
      return this.compoundVRegenerationActive;
   }

   public void clearCompoundVRegeneration() {
      this.compoundVRegenerationActive = false;
   }

   public void activatePart(String partName, int score) {
      if (PART_MAX_SCORES.containsKey(partName)) {
         this.setScore(partName, Math.max(0, score));
      }
   }

   public CompoundTag serializeNBT(Provider provider) {
      CompoundTag tag = new CompoundTag();
      tag.putBoolean("CompoundVRegenerationActive", this.compoundVRegenerationActive);

      for (Entry<String, Integer> entry : this.partScores.entrySet()) {
         tag.putInt(entry.getKey(), entry.getValue());
      }

      return tag;
   }

   public void deserializeNBT(Provider provider, CompoundTag tag) {
      this.compoundVRegenerationActive = tag.getBoolean("CompoundVRegenerationActive");

      for (String part : PART_MAX_SCORES.keySet()) {
         if (tag.contains(part)) {
            this.partScores.put(part, tag.getInt(part));
         }
      }
   }

   public void copyFrom(CompoundTag tag) {
      this.compoundVRegenerationActive = tag.getBoolean("CompoundVRegenerationActive");

      for (String part : PART_MAX_SCORES.keySet()) {
         if (tag.contains(part)) {
            this.partScores.put(part, tag.getInt(part));
         }
      }
   }

   public CompoundTag toTag() {
      CompoundTag tag = new CompoundTag();
      tag.putBoolean("CompoundVRegenerationActive", this.compoundVRegenerationActive);

      for (Entry<String, Integer> entry : this.partScores.entrySet()) {
         tag.putInt(entry.getKey(), entry.getValue());
      }

      return tag;
   }

   static {
      PART_MAX_SCORES.put("Head", 17);
      PART_MAX_SCORES.put("Body", 20);
      PART_MAX_SCORES.put("Right.Arm", 18);
      PART_MAX_SCORES.put("Left.Arm", 18);
      PART_MAX_SCORES.put("Right.Hand", 12);
      PART_MAX_SCORES.put("Left.Hand", 12);
      PART_MAX_SCORES.put("Right.Leg", 20);
      PART_MAX_SCORES.put("Left.Leg", 20);
      PART_MAX_SCORES.put("Right.Feet", 11);
      PART_MAX_SCORES.put("Left.Feet", 11);
      PART_BONE_SCORES.put("Head", 4);
      PART_BONE_SCORES.put("Body", 7);
      PART_BONE_SCORES.put("Right.Arm", 5);
      PART_BONE_SCORES.put("Left.Arm", 5);
      PART_BONE_SCORES.put("Right.Hand", 3);
      PART_BONE_SCORES.put("Left.Hand", 3);
      PART_BONE_SCORES.put("Right.Leg", 5);
      PART_BONE_SCORES.put("Left.Leg", 5);
      PART_BONE_SCORES.put("Right.Feet", 2);
      PART_BONE_SCORES.put("Left.Feet", 2);
      CHILD_TO_PARENT.put("Right.Hand", "Right.Arm");
      CHILD_TO_PARENT.put("Left.Hand", "Left.Arm");
      CHILD_TO_PARENT.put("Right.Feet", "Right.Leg");
      CHILD_TO_PARENT.put("Left.Feet", "Left.Leg");
      PARENT_CHILD_READY_SCORES.put("Right.Arm", 17);
      PARENT_CHILD_READY_SCORES.put("Left.Arm", 17);
      PARENT_CHILD_READY_SCORES.put("Right.Leg", 19);
      PARENT_CHILD_READY_SCORES.put("Left.Leg", 19);
   }
}
