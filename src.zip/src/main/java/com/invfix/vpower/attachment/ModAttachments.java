package com.invfix.vpower.attachment;

import java.util.function.Supplier;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

public class ModAttachments {
   public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS = DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, "theboysmod");
   public static final Supplier<AttachmentType<FleshRegenData>> FLESH_REGEN = ATTACHMENTS.register(
      "flesh_regen", () -> AttachmentType.serializable(FleshRegenData::new).build()
   );
}
