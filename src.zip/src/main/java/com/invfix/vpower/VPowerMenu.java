package com.invfix.vpower;

import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.SkillData;
import com.invfix.vpower.skill.SkillRegistry;
import com.invfix.vpower.skill.VAbilities;
import com.invfix.vpower.skill.base.Skill;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * Вкладка PWR со способностями V в меню способностей Invincible.
 *  - У рас V без своей вкладки PWR (Human, Human(Predisposition to V), Human(Born for V) — пока у них нет силы
 *    Invincible, Power = "None") PWR открывает лист меню Вильтрумитов, но только со способностями V
 *    (OpenAbilityMenuPowersProcedureMixin, AbilitiesMenuPowerViltrumiteScreenMixin).
 *  - У Human-Viltrumite и людей с силой Invincible (Super Speed, Atomic, Tech Jacket) способности V добавляются в их
 *    родную вкладку PWR.
 * Кнопка способности с действием выбирает её (AbilitySet), дальше — как у родных: кнопка слота кладёт её в слот.
 * Пассивные — только показываются (работают сами).
 */
public final class VPowerMenu {

    private static final String HUMAN_VILTRUMITE = "§f§lHuman-Viltrumite";

    private VPowerMenu() {}

    /** PWR — свой лист со способностями V (раса V без своей вкладки PWR и без силы Invincible). */
    public static boolean ownPwr(Player player) {
        if (!VRaces.humanDna(player) || HUMAN_VILTRUMITE.equals(VRaces.race(player))) return false;
        try {
            return "None".equals(((InvincibleIncModVariables.PlayerVariables) player.getData(InvincibleIncModVariables.PLAYER_VARIABLES)).Power);
        } catch (Throwable t) {
            return false;
        }
    }

    /** Способности V игрока в порядке реестра (как в The Boys): сначала с действием, потом пассивные. */
    public static List<Skill> skills(Player player) {
        SkillData data = player.getData(ModSkillAttachments.SKILL_DATA.get());
        List<Skill> active = new ArrayList<>(), passive = new ArrayList<>();
        for (Skill skill : SkillRegistry.getAllSkills()) {
            if (!data.hasSkill(skill.getId())) continue;
            (VAbilities.assignable(skill) ? active : passive).add(skill);
        }
        active.addAll(passive);
        return active;
    }

    /** Кнопка способности V в меню: выбрать её для слота (как AbilitySet…Procedure Invincible). */
    public static void select(ServerPlayer player, String skillId) {
        SkillData data = player.getData(ModSkillAttachments.SKILL_DATA.get());
        Skill skill = SkillRegistry.getSkill(skillId);
        if (skill == null || !data.hasSkill(skillId)) return;
        InvincibleIncModVariables.PlayerVariables vars =
                (InvincibleIncModVariables.PlayerVariables) player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        String name = VAbilities.slotName(skillId);
        if (name != null && VAbilities.assignable(skill)) {
            vars.AbilitySet = name;
            vars.abilityDescription = name + " §7| V | " + switch (skill.getType()) {
                case ACTIVE -> "нажатие";
                case TOGGLE -> "нажатие — вкл/выкл";
                case CHANNELED -> "удерживать клавишу";
                case PASSIVE -> "";
            };
        } else {
            vars.AbilitySet = "None";
            vars.abilityDescription = VAbilities.PREFIX + VAbilities.english(skillId) +" §7| V | пассивная — работает сама";
        }
        vars.markSyncDirty();
    }
}
