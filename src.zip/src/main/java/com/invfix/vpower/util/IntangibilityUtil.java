package com.invfix.vpower.util;

import com.invfix.vpower.skill.SkillData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Бестелесность навыками Intangibility / Spiritualization (The Boys). Сами навыки в V не перенесены (их не дают ни
 * Compound V, ни Temp V): бестелесных нет, проверки в коде способностей оставлены как в моде.
 */
public final class IntangibilityUtil {

    public static final String SKILL_ID = "theboysmod:intangibility";
    public static final String SPIRITUALIZATION_ID = "theboysmod:spiritualization";

    private IntangibilityUtil() {}

    public static boolean isIntangible(Entity entity) {
        return false;
    }

    public static boolean hasAnyIntangibleSkillActive(SkillData data) {
        return false;
    }

    public static boolean shouldIgnoreEntityCollision(Entity first, Entity second) {
        return false;
    }

    public static boolean canPhaseThrough(BlockState state) {
        return !state.is(Blocks.BEDROCK);
    }
}
