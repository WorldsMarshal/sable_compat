package com.invfix.vpower.util;

import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public final class LaserEyeGeometry {
   private static final double MIN_FORWARD_OFFSET = 0.015;
   private static final double MAX_FORWARD_OFFSET = 0.04;
   private static final double MIN_EYE_RELATIVE_HEIGHT_FACTOR = 0.35;
   private static final double MAX_EYE_RELATIVE_HEIGHT_FACTOR = 0.9;

   private LaserEyeGeometry() {
   }

   public static Vec3 getDynamicEyeBase(LivingEntity entity, float partialTick) {
      Vec3 eye = entity.getEyePosition(partialTick);
      double eyeRel = eye.y - entity.getY();
      double minEyeRel = (double)entity.getBbHeight() * 0.35;
      double maxEyeRel = (double)entity.getBbHeight() * 0.9;
      if (eyeRel < minEyeRel) {
         eye = eye.add(0.0, minEyeRel - eyeRel, 0.0);
      } else if (eyeRel > maxEyeRel) {
         eye = eye.add(0.0, maxEyeRel - eyeRel, 0.0);
      }

      Vec3 lookDir = entity.getViewVector(partialTick);
      if (lookDir.lengthSqr() < 1.0E-6) {
         lookDir = entity.getLookAngle();
      }

      if (lookDir.lengthSqr() > 1.0E-6) {
         double forward = Mth.clamp((double)entity.getBbWidth() * 0.06, 0.015, 0.04);
         eye = eye.add(lookDir.normalize().scale(forward));
      }

      return eye;
   }

   public static Vec3 getSupeEyeBase(LivingEntity entity, float partialTick) {
      return getDynamicEyeBase(entity, partialTick).add(0.0, Math.max(0.08, (double)entity.getBbHeight() * 0.1), 0.0);
   }

   public static double getDynamicEyeSideOffset(LivingEntity entity) {
      return Mth.clamp((double)entity.getBbWidth() * 0.12, 0.05, 0.1);
   }

   public static LaserEyeGeometry.TraceResult traceBeam(
      LivingEntity shooter, Vec3 origin, Vec3 direction, double maxDistance, double hitInflation, Predicate<LivingEntity> extraFilter
   ) {
      if (!(direction.lengthSqr() < 1.0E-6) && !(maxDistance <= 0.0)) {
         Vec3 normalizedDir = direction.normalize();
         Vec3 maxEnd = origin.add(normalizedDir.scale(maxDistance));
         BlockHitResult blockHit = shooter.level().clip(new ClipContext(origin, maxEnd, Block.COLLIDER, Fluid.NONE, shooter));
         double closestDistance = maxDistance;
         Vec3 closestHit = maxEnd;
         if (blockHit.getType() != Type.MISS) {
            closestHit = blockHit.getLocation();
            closestDistance = origin.distanceTo(closestHit);
         }

         double closestDistanceSqr = closestDistance * closestDistance;
         LivingEntity closestEntity = null;
         Vec3 traceEnd = origin.add(normalizedDir.scale(closestDistance));
         AABB searchBox = createBeamSearchBox(origin, traceEnd, hitInflation);

         for (LivingEntity target : shooter.level()
            .getEntitiesOfClass(
               LivingEntity.class,
               searchBox,
               entity -> entity != shooter && entity.isAlive() && !IntangibilityUtil.isIntangible(entity) && extraFilter.test(entity)
            )) {
            Vec3 hit = clipInflatedBox(origin, traceEnd, target.getBoundingBox(), hitInflation);
            if (hit != null) {
               double distanceSqr = origin.distanceToSqr(hit);
               if (distanceSqr < closestDistanceSqr) {
                  closestDistanceSqr = distanceSqr;
                  closestDistance = Math.sqrt(distanceSqr);
                  closestHit = hit;
                  closestEntity = target;
               }
            }
         }

         return new LaserEyeGeometry.TraceResult(closestHit, closestDistance, closestEntity);
      } else {
         return new LaserEyeGeometry.TraceResult(origin, 0.0, null);
      }
   }

   public static Vec3 clipInflatedBox(Vec3 start, Vec3 end, AABB box, double inflation) {
      AABB inflated = box.inflate(inflation);
      Optional<Vec3> clip = inflated.clip(start, end);
      if (clip.isPresent()) {
         return clip.get();
      } else {
         return inflated.contains(start) ? start : null;
      }
   }

   public static AABB createBeamSearchBox(Vec3 start, Vec3 end, double inflation) {
      return new AABB(
         Math.min(start.x, end.x) - inflation,
         Math.min(start.y, end.y) - inflation,
         Math.min(start.z, end.z) - inflation,
         Math.max(start.x, end.x) + inflation,
         Math.max(start.y, end.y) + inflation,
         Math.max(start.z, end.z) + inflation
      );
   }

   public static record TraceResult(Vec3 hitPos, double distance, LivingEntity entity) {
   }
}
