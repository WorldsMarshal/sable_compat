package com.invfix.vpower.util;

import net.mcreator.invincibleinc.init.InvincibleIncModGameRules;
import net.minecraft.world.level.Level;

/**
 * Разрушение блоков способностями V. В The Boys блоки не трогались только в зданиях Vought; здесь — как у остальных
 * способностей мода: только при включённом правиле invincibleBlockDestruction.
 */
public final class VBlocks {

    private VBlocks() {}

    /** Блоки здесь трогать нельзя. */
    public static boolean protectedLevel(Level level) {
        try {
            return !level.getGameRules().getBoolean(InvincibleIncModGameRules.INVINCIBLE_BLOCK_DESTRUCTION);
        } catch (Exception e) {
            return false;
        }
    }
}
