package com.invfix.vpower.util;

import java.util.Optional;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

public final class BloodBurstBodyPartGeometry {
   public static final double TARGET_RANGE = 24.0;
   private static final double SELECTION_BOX_INFLATE = 0.055;
   private static final double EPSILON = 1.0E-7;

   private BloodBurstBodyPartGeometry() {
   }

   public static Vec3 getBodyPartCenter(LivingEntity target, String partKey) {
      return getBodyPartCenter(target.position(), getBodyYaw(target), (double)target.getBbWidth(), (double)target.getBbHeight(), partKey);
   }

   public static Vec3 getBodyPartCenter(Vec3 base, float yawDegrees, double width, double height, String partKey) {
      BloodBurstBodyPartGeometry.PartBox box = getBodyPartBox(width, height, partKey);
      float yaw = yawDegrees * (float) (Math.PI / 180.0);
      Vec3 right = new Vec3((double)Mth.cos(yaw), 0.0, (double)Mth.sin(yaw));
      Vec3 forward = new Vec3((double)(-Mth.sin(yaw)), 0.0, (double)Mth.cos(yaw));
      return base.add(right.scale(box.centerX())).add(forward.scale(box.centerZ())).add(0.0, box.centerY(), 0.0);
   }

   public static BloodBurstBodyPartGeometry.PartBox getBodyPartBox(double entityWidth, double entityHeight, String partKey) {
      double width = Math.max(entityWidth, 0.45);
      double height = Math.max(entityHeight, 1.0);

      return switch (partKey) {
         case "Body" -> new BloodBurstBodyPartGeometry.PartBox(0.0, height * 0.55, 0.0, width * 0.36, height * 0.2, width * 0.24);
         case "Right.Arm" -> new BloodBurstBodyPartGeometry.PartBox(-width * 0.58, height * 0.55, 0.0, width * 0.15, height * 0.22, width * 0.15);
         case "Left.Arm" -> new BloodBurstBodyPartGeometry.PartBox(width * 0.58, height * 0.55, 0.0, width * 0.15, height * 0.22, width * 0.15);
         case "Right.Hand" -> new BloodBurstBodyPartGeometry.PartBox(-width * 0.66, height * 0.32, 0.0, width * 0.13, height * 0.1, width * 0.13);
         case "Left.Hand" -> new BloodBurstBodyPartGeometry.PartBox(width * 0.66, height * 0.32, 0.0, width * 0.13, height * 0.1, width * 0.13);
         case "Right.Leg" -> new BloodBurstBodyPartGeometry.PartBox(-width * 0.22, height * 0.28, 0.0, width * 0.14, height * 0.2, width * 0.14);
         case "Left.Leg" -> new BloodBurstBodyPartGeometry.PartBox(width * 0.22, height * 0.28, 0.0, width * 0.14, height * 0.2, width * 0.14);
         case "Right.Feet" -> new BloodBurstBodyPartGeometry.PartBox(-width * 0.22, height * 0.06, width * 0.18, width * 0.16, height * 0.07, width * 0.22);
         case "Left.Feet" -> new BloodBurstBodyPartGeometry.PartBox(width * 0.22, height * 0.06, width * 0.18, width * 0.16, height * 0.07, width * 0.22);
         default -> new BloodBurstBodyPartGeometry.PartBox(0.0, height * 0.86, width * 0.18, width * 0.34, height * 0.12, width * 0.34);
      };
   }

   public static Optional<String> findLookedBodyPart(LivingEntity target, Vec3 start, Vec3 look, String[] partKeys) {
      if (target != null && partKeys != null && partKeys.length != 0 && !(look.lengthSqr() < 1.0E-7)) {
         Vec3 direction = look.normalize();
         BloodBurstBodyPartGeometry.LocalRay ray = toLocalRay(target, start, direction);
         double width = (double)target.getBbWidth();
         double height = (double)target.getBbHeight();
         String bestPart = null;
         double bestDistance = 24.0;

         for (String partKey : partKeys) {
            BloodBurstBodyPartGeometry.PartBox box = getBodyPartBox(width, height, partKey);
            double distance = rayBoxDistance(ray, box, 0.055, 24.0);
            if (!Double.isNaN(distance) && distance < bestDistance) {
               bestDistance = distance;
               bestPart = partKey;
            }
         }

         return bestPart != null ? Optional.of(bestPart) : findNearestBodyPartOnRay(ray, width, height, partKeys);
      } else {
         return Optional.empty();
      }
   }

   private static BloodBurstBodyPartGeometry.LocalRay toLocalRay(LivingEntity target, Vec3 start, Vec3 direction) {
      float yaw = getBodyYaw(target) * (float) (Math.PI / 180.0);
      Vec3 right = new Vec3((double)Mth.cos(yaw), 0.0, (double)Mth.sin(yaw));
      Vec3 forward = new Vec3((double)(-Mth.sin(yaw)), 0.0, (double)Mth.cos(yaw));
      Vec3 originDelta = start.subtract(target.position());
      return new BloodBurstBodyPartGeometry.LocalRay(
         originDelta.dot(right), originDelta.y, originDelta.dot(forward), direction.dot(right), direction.y, direction.dot(forward)
      );
   }

   private static float getBodyYaw(LivingEntity target) {
      return target.yBodyRot;
   }

   private static double rayBoxDistance(BloodBurstBodyPartGeometry.LocalRay ray, BloodBurstBodyPartGeometry.PartBox box, double inflate, double maxDistance) {
      double tMin = 0.0;
      double tMax = maxDistance;
      double[] origin = new double[]{ray.originX(), ray.originY(), ray.originZ()};
      double[] direction = new double[]{ray.directionX(), ray.directionY(), ray.directionZ()};
      double[] min = new double[]{box.minX() - inflate, box.minY() - inflate, box.minZ() - inflate};
      double[] max = new double[]{box.maxX() + inflate, box.maxY() + inflate, box.maxZ() + inflate};

      for (int i = 0; i < 3; i++) {
         if (Math.abs(direction[i]) < 1.0E-7) {
            if (origin[i] < min[i] || origin[i] > max[i]) {
               return Double.NaN;
            }
         } else {
            double t1 = (min[i] - origin[i]) / direction[i];
            double t2 = (max[i] - origin[i]) / direction[i];
            if (t1 > t2) {
               double temp = t1;
               t1 = t2;
               t2 = temp;
            }

            tMin = Math.max(tMin, t1);
            tMax = Math.min(tMax, t2);
            if (tMin > tMax) {
               return Double.NaN;
            }
         }
      }

      return tMin <= maxDistance ? tMin : Double.NaN;
   }

   private static Optional<String> findNearestBodyPartOnRay(BloodBurstBodyPartGeometry.LocalRay ray, double width, double height, String[] partKeys) {
      String bestPart = null;
      double bestScore = Double.MAX_VALUE;

      for (String partKey : partKeys) {
         BloodBurstBodyPartGeometry.PartBox box = getBodyPartBox(width, height, partKey);
         double toCenterX = box.centerX() - ray.originX();
         double toCenterY = box.centerY() - ray.originY();
         double toCenterZ = box.centerZ() - ray.originZ();
         double projected = toCenterX * ray.directionX() + toCenterY * ray.directionY() + toCenterZ * ray.directionZ();
         if (!(projected < 0.0) && !(projected > 24.0)) {
            double closestX = ray.originX() + ray.directionX() * projected;
            double closestY = ray.originY() + ray.directionY() * projected;
            double closestZ = ray.originZ() + ray.directionZ() * projected;
            double dx = box.centerX() - closestX;
            double dy = box.centerY() - closestY;
            double dz = box.centerZ() - closestZ;
            double distanceSqr = dx * dx + dy * dy + dz * dz;
            double radius = Math.max(box.halfX(), Math.max(box.halfY(), box.halfZ())) + 0.055;
            if (distanceSqr <= radius * radius && distanceSqr < bestScore) {
               bestScore = distanceSqr;
               bestPart = partKey;
            }
         }
      }

      return bestPart == null ? Optional.empty() : Optional.of(bestPart);
   }

   private static record LocalRay(double originX, double originY, double originZ, double directionX, double directionY, double directionZ) {
   }

   public static record PartBox(double centerX, double centerY, double centerZ, double halfX, double halfY, double halfZ) {
      public double minX() {
         return this.centerX - this.halfX;
      }

      public double minY() {
         return this.centerY - this.halfY;
      }

      public double minZ() {
         return this.centerZ - this.halfZ;
      }

      public double maxX() {
         return this.centerX + this.halfX;
      }

      public double maxY() {
         return this.centerY + this.halfY;
      }

      public double maxZ() {
         return this.centerZ + this.halfZ;
      }
   }
}
