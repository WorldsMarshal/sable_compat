package com.invfix.vpower;

import com.invfix.vpower.attachment.ModAttachments;
import com.invfix.vpower.entity.ModEntities;
import com.invfix.vpower.network.VPowerNetwork;
import com.invfix.vpower.registry.ModItems;
import com.invfix.vpower.registry.ModParticles;
import com.invfix.vpower.registry.ModSounds;
import com.invfix.vpower.skill.ModSkillAttachments;
import com.invfix.vpower.skill.ModSkills;
import com.mojang.logging.LogUtils;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import org.slf4j.Logger;

/**
 * Препарат V и способности V — перенос из мода The Boys (theboysmod 1.0.0.1, BenNiao_Eric, MIT) в sable_compat.
 *
 * Из мода взяты только препарат V (шприцы, колбы, инъекция, Temp V, удаление) и способности, которые он даёт, —
 * со всей их механикой, рендером, звуками и анимациями. Реестровые id и ресурсы остались под неймспейсом
 * {@link #MODID} ("theboysmod"): предметы в мирах и данные игроков (вложения skill_data, skill_energy, flesh_regen)
 * переживают удаление мода. Вместе с самим The Boys мод не грузится (incompatible в neoforge.mods.toml).
 *
 * Способности — в меню PWR Invincible (VPowerMenu), на клавишах способностей Invincible (VPowerKeys).
 */
public final class VPower {

    /** Неймспейс реестров и ресурсов (как у The Boys). */
    public static final String MODID = "theboysmod";
    public static final Logger LOGGER = LogUtils.getLogger();

    private VPower() {}

    /** Из конструктора мода (InvincibleFix). */
    public static void register(IEventBus modBus) {
        ModItems.ITEMS.register(modBus);
        ModSounds.register(modBus);
        ModParticles.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModAttachments.ATTACHMENTS.register(modBus);
        ModSkillAttachments.ATTACHMENTS.register(modBus);
        modBus.addListener(VPower::onCommonSetup);
        modBus.addListener(VPowerNetwork::register);
        modBus.addListener(VPower::onCreativeTabs);
    }

    private static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(ModSkills::registerAll);
    }

    /** Шприцы и колбы — во вкладке «Ингредиенты». */
    private static void onCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() != CreativeModeTabs.INGREDIENTS) return;
        event.accept(ModItems.SYRINGE);
        event.accept(ModItems.COMPOUND_V);
        event.accept(ModItems.COMPOUND_V_SYRINGE);
        event.accept(ModItems.COMPOUND_V_TEMP);
        event.accept(ModItems.COMPOUND_V_TEMP_SYRINGE);
        event.accept(ModItems.COMPOUND_V_REMOVE);
        event.accept(ModItems.COMPOUND_V_REMOVE_SYRINGE);
    }
}
