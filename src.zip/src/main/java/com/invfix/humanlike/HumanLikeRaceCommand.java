package com.invfix.humanlike;

import com.mojang.brigadier.Command;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.procedures.ClearAbilitiesProcedure;
import net.mcreator.invincibleinc.procedures.ClearPassiveProcedure;
import net.mcreator.invincibleinc.procedures.FullResetProcedure;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * Dev-команды для назначения себе человекоподобных рас (только OP, permission 2):
 *
 *   /setrace born_for_v      → §a§lHuman(Born for V)
 *   /setrace predisposition  → §e§lHuman(Predisposition to V)
 *
 * Ставит чистое «человеческое» состояние (Power/racePower = "None",
 * расовый множитель статов = 0.0 как у §f§lHuman) и, как {@code /altrumite},
 * сбрасывает абилки/пассивки для чистого свитча расы.
 *
 * Силы Compound V (через The Boys) команда НЕ выдаёт — это отдельная механика
 * инъекции; команда лишь меняет расу.
 */
@EventBusSubscriber(modid = "sable_compat")
public class HumanLikeRaceCommand {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("setrace")
                        .requires(s -> s.hasPermission(2)) // только OP
                        .then(Commands.literal("born_for_v")
                                .executes(ctx -> apply(ctx.getSource(),
                                        HumanLikeRaces.BORN_FOR_V, "Human(Born for V)")))
                        .then(Commands.literal("predisposition")
                                .executes(ctx -> apply(ctx.getSource(),
                                        HumanLikeRaces.PREDISPOSITION, "Human(Predisposition to V)")))
        );
    }

    private static int apply(net.minecraft.commands.CommandSourceStack source,
                             String race, String displayName) {
        if (source.getEntity() instanceof ServerPlayer player) {
            applyHumanLikeRace(player, race);
            source.sendSuccess(
                    () -> Component.literal("§aРаса установлена: " + displayName), false);
            return Command.SINGLE_SUCCESS;
        }
        source.sendFailure(Component.literal("§cКоманда доступна только игроку."));
        return 0;
    }

    /** Ставит человекоподобную расу и приводит статы к «человеческому» состоянию. */
    public static void applyHumanLikeRace(ServerPlayer player, String race) {
        InvincibleIncModVariables.PlayerVariables vars =
                player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        vars.Race = race;
        vars.Power = "None";
        vars.racePower = "None";
        // Как у §f§lHuman — без скрытого расового бонуса (миксин тоже форсит 0.0).
        vars.RaceStatMultiplier = 0.0;
        vars.markSyncDirty();

        try { ClearAbilitiesProcedure.execute(player); } catch (Exception ignored) {}
        try { ClearPassiveProcedure.execute(player); } catch (Exception ignored) {}
        try { FullResetProcedure.execute(player.level(), player); } catch (Exception ignored) {}
    }
}