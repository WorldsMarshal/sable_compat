package com.invfix.humanlike;

/**
 * Две новые расы-«затычки», механически ИДЕНТИЧНЫЕ обычному Human.
 *
 * Пока что они отличаются от Human только названием и цветом — все капы,
 * множители xp, расовый множитель статов и пассивки зеркалят §f§lHuman.
 * Когда дойдём до их собственной механики, расхождения будут добавляться
 * точечно через проверку {@link #isHumanLike(String)}.
 *
 *   Human(Born for V)            — §a (зелёный)
 *   Human(Predisposition to V)   — §e (жёлтый)
 *
 * Строки расы хранятся как готовые отображаемые литералы (см. ShowRaceProcedure,
 * который просто возвращает vars.Race), поэтому цветовой код встроен прямо в имя.
 *
 * Поля объявлены compile-time константами — это позволяет использовать их
 * как метки case в switch (RaceCapsUtil, XpGiveProcedureMixin).
 */
public final class HumanLikeRaces {
    private HumanLikeRaces() {}

    /** Зелёный (§a). Шанс выпадения 10%. */
    public static final String BORN_FOR_V     = "\u00a7a\u00a7lHuman(Born for V)";
    /** Жёлтый (§e). Шанс выпадения 50% (бросок монеты с обычным Human). */
    public static final String PREDISPOSITION = "\u00a7e\u00a7lHuman(Predisposition to V)";

    public static boolean isHumanLike(String race) {
        return BORN_FOR_V.equals(race) || PREDISPOSITION.equals(race);
    }
}