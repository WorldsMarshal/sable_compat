package com.invfix.cyberware;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.fluids.BaseFlowingFluid;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/**
 * Жидкость «фоторезист» (photoresist) — светочувствительный полимер ветки
 * наноэлектроники (фаза 5a). Делается смешиванием листа пластика (tfmg) с
 * растворителем (вода), наносится спаутом (create:filling) на окислённую
 * пластину, превращая её в покрытую (вход литографа на A8).
 *
 * Регистрация и клиентский рендер — точная копия рабочего паттерна
 * {@link CompositeFluids}: вода как текстура + янтарный тон в {@link PhotoresistFluidType}.
 */
public final class NanoFluids {

    public static final DeferredRegister<FluidType> FLUID_TYPES =
            DeferredRegister.create(NeoForgeRegistries.Keys.FLUID_TYPES, "sable_compat");
    public static final DeferredRegister<Fluid> FLUIDS =
            DeferredRegister.create(Registries.FLUID, "sable_compat");
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks("sable_compat");
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("sable_compat");

    public static final DeferredHolder<FluidType, FluidType> PHOTORESIST_TYPE =
            FLUID_TYPES.register("photoresist",
                    () -> new PhotoresistFluidType(FluidType.Properties.create()
                            .density(1100).viscosity(2500).temperature(320)
                            .canSwim(true).canDrown(true).canExtinguish(true),
                            0xFFC8932E));

    public static final DeferredHolder<Fluid, BaseFlowingFluid.Source> PHOTORESIST =
            FLUIDS.register("photoresist", () -> new BaseFlowingFluid.Source(makeProps()));
    public static final DeferredHolder<Fluid, BaseFlowingFluid.Flowing> PHOTORESIST_FLOWING =
            FLUIDS.register("photoresist_flowing", () -> new BaseFlowingFluid.Flowing(makeProps()));

    public static final DeferredBlock<LiquidBlock> PHOTORESIST_BLOCK =
            BLOCKS.register("photoresist",
                    () -> new LiquidBlock(PHOTORESIST.get(),
                            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_ORANGE)
                                    .noCollission().strength(100.0F).noLootTable().liquid().replaceable()));

    public static final DeferredItem<Item> PHOTORESIST_BUCKET =
            ITEMS.register("photoresist_bucket",
                    () -> new BucketItem(PHOTORESIST.get(),
                            new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)));

    // --- Травитель (etchant): кислота для проявки+травления экспонированной пластины (A9) ---
    public static final DeferredHolder<FluidType, FluidType> ETCHANT_TYPE =
            FLUID_TYPES.register("etchant",
                    () -> new PhotoresistFluidType(FluidType.Properties.create()
                            .density(1200).viscosity(1500).temperature(300)
                            .canSwim(true).canDrown(true).canExtinguish(true),
                            0xFF7FE04A));
    public static final DeferredHolder<Fluid, BaseFlowingFluid.Source> ETCHANT =
            FLUIDS.register("etchant", () -> new BaseFlowingFluid.Source(makePropsEtchant()));
    public static final DeferredHolder<Fluid, BaseFlowingFluid.Flowing> ETCHANT_FLOWING =
            FLUIDS.register("etchant_flowing", () -> new BaseFlowingFluid.Flowing(makePropsEtchant()));
    public static final DeferredBlock<LiquidBlock> ETCHANT_BLOCK =
            BLOCKS.register("etchant",
                    () -> new LiquidBlock(ETCHANT.get(),
                            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GREEN)
                                    .noCollission().strength(100.0F).noLootTable().liquid().replaceable()));
    public static final DeferredItem<Item> ETCHANT_BUCKET =
            ITEMS.register("etchant_bucket",
                    () -> new BucketItem(ETCHANT.get(),
                            new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)));

    private static BaseFlowingFluid.Properties makeProps() {
        return new BaseFlowingFluid.Properties(
                PHOTORESIST_TYPE, PHOTORESIST, PHOTORESIST_FLOWING)
                .block(PHOTORESIST_BLOCK)
                .bucket(PHOTORESIST_BUCKET);
    }

    // --- Криофлюс (cryo_flux): криогенный реагент синтеза ультрания (супертех) ---
    public static final DeferredHolder<FluidType, FluidType> CRYO_FLUX_TYPE =
            FLUID_TYPES.register("cryo_flux",
                    () -> new PhotoresistFluidType(FluidType.Properties.create()
                            .density(900).viscosity(800).temperature(120)
                            .canSwim(true).canDrown(true).canExtinguish(true),
                            0xFF6FD8F0));
    public static final DeferredHolder<Fluid, BaseFlowingFluid.Source> CRYO_FLUX =
            FLUIDS.register("cryo_flux", () -> new BaseFlowingFluid.Source(makePropsCryo()));
    public static final DeferredHolder<Fluid, BaseFlowingFluid.Flowing> CRYO_FLUX_FLOWING =
            FLUIDS.register("cryo_flux_flowing", () -> new BaseFlowingFluid.Flowing(makePropsCryo()));
    public static final DeferredBlock<LiquidBlock> CRYO_FLUX_BLOCK =
            BLOCKS.register("cryo_flux",
                    () -> new LiquidBlock(CRYO_FLUX.get(),
                            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_LIGHT_BLUE)
                                    .noCollission().strength(100.0F).noLootTable().liquid().replaceable()));
    public static final DeferredItem<Item> CRYO_FLUX_BUCKET =
            ITEMS.register("cryo_flux_bucket",
                    () -> new BucketItem(CRYO_FLUX.get(),
                            new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)));

    private static BaseFlowingFluid.Properties makePropsEtchant() {
        return new BaseFlowingFluid.Properties(ETCHANT_TYPE, ETCHANT, ETCHANT_FLOWING)
                .block(ETCHANT_BLOCK)
                .bucket(ETCHANT_BUCKET);
    }

    private static BaseFlowingFluid.Properties makePropsCryo() {
        return new BaseFlowingFluid.Properties(CRYO_FLUX_TYPE, CRYO_FLUX, CRYO_FLUX_FLOWING)
                .block(CRYO_FLUX_BLOCK)
                .bucket(CRYO_FLUX_BUCKET);
    }

    private NanoFluids() {}

    public static void register(IEventBus bus) {
        FLUID_TYPES.register(bus);
        FLUIDS.register(bus);
        BLOCKS.register(bus);
        ITEMS.register(bus);
    }

    /**
     * Свой {@link FluidType} с клиентским рендером через {@code initializeClient}
     * (канонический способ для NeoForge 1.21.1, как в tfmg/CompositeFluids).
     * Server-safe: клиентский интерфейс грузится только на клиенте.
     */
    public static final class PhotoresistFluidType extends FluidType {
        private static final ResourceLocation STILL = ResourceLocation.withDefaultNamespace("block/water_still");
        private static final ResourceLocation FLOW = ResourceLocation.withDefaultNamespace("block/water_flow");
        private final int tint;

        public PhotoresistFluidType(Properties properties, int tint) {
            super(properties);
            this.tint = tint;
        }

        @Override
        @SuppressWarnings({"unchecked", "rawtypes"})
        public void initializeClient(java.util.function.Consumer consumer) {
            consumer.accept(new net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions() {
                @Override
                public ResourceLocation getStillTexture() {
                    return STILL;
                }

                @Override
                public ResourceLocation getFlowingTexture() {
                    return FLOW;
                }

                @Override
                public int getTintColor() {
                    return PhotoresistFluidType.this.tint;
                }
            });
        }
    }
}
