package com.invfix.cyberware;

import com.invfix.cybercompat.CyberBonusBridge;
import com.perigrine3.createcybernetics.api.CyberwareSlot;
import com.perigrine3.createcybernetics.api.ICyberwareItem;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;
import java.util.Set;

/**
 * Сердце наномашин (фаза 10). Слот HEART, 0 человечности, 0 энергии, БЕЗ гейта —
 * ставится даже в полностью безимплантового человека. Крафт использует Наномашины
 * Gen4 (нежизнеспособный рой — топливо Сердца).
 *
 * Пассивно: +40 капы HP (атрибут) + кибер-капы Invincible через мост
 * ({@code HumanCapsMixin}): Durability 30, DTstat 40 — щит наномашин.
 *
 * <b>Nanomachines Unleashed</b> — СПОСОБНОСТЬ, включаемая игроком (клавиша →
 * {@code UnleashedTogglePacket} → тумблер моста). Пока включена и Сердце активно:
 * урон ×2 (атрибут, множитель итога) и усиленный щит (Durability 50, DTstat 80 —
 * уровень Born for V). Атрибут держится тиком Сердца и снимается сам при
 * выключении способности или извлечении Сердца.
 */
public class NanoHeartItem extends Item implements ICyberwareItem {

    private static final ResourceLocation HP_ID =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "nano_heart_health");
    private static final ResourceLocation UNLEASHED_ID =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "nano_heart_unleashed");

    public NanoHeartItem(Properties props) {
        super(props.stacksTo(1));
    }

    @Override
    public int getHumanityCost() { return 0; }

    @Override
    public Set<CyberwareSlot> getSupportedSlots() { return Set.of(CyberwareSlot.HEART); }

    @Override
    public int getEnergyUsedPerTick(LivingEntity entity, ItemStack installedStack, CyberwareSlot slot) {
        return 0;
    }

    @Override
    public boolean requiresEnergyToFunction(LivingEntity entity, ItemStack installedStack, CyberwareSlot slot) {
        return false;
    }

    // Сердце буквально замещает биологическое — как ориг. MechanicalHeartItem
    // (true + Set.of(HEART)).
    @Override
    public boolean replacesOrgan() { return true; }

    @Override
    public Set<CyberwareSlot> getReplacedOrgans() { return Set.of(CyberwareSlot.HEART); }

    @Override
    public void onInstalled(LivingEntity entity) {
        AttributeInstance hp = entity.getAttribute(Attributes.MAX_HEALTH);
        if (hp != null) {
            hp.removeModifier(HP_ID);
            hp.addPermanentModifier(new AttributeModifier(HP_ID, 40.0D, AttributeModifier.Operation.ADD_VALUE));
        }
    }

    @Override
    public void onRemoved(LivingEntity entity) {
        AttributeInstance hp = entity.getAttribute(Attributes.MAX_HEALTH);
        if (hp != null) hp.removeModifier(HP_ID);
        AttributeInstance dmg = entity.getAttribute(Attributes.ATTACK_DAMAGE);
        if (dmg != null) dmg.removeModifier(UNLEASHED_ID);
    }

    @Override
    public void onTick(LivingEntity entity) {
        if (entity.level().isClientSide) return;
        CyberBonusBridge.pingHeart(entity);

        // Unleashed: держим x2-урон, пока способность включена и Сердце активно.
        AttributeInstance dmg = entity.getAttribute(Attributes.ATTACK_DAMAGE);
        if (dmg == null) return;
        boolean unleashed = CyberBonusBridge.isUnleashed(entity);
        boolean has = dmg.getModifier(UNLEASHED_ID) != null;
        if (unleashed && !has) {
            dmg.addPermanentModifier(new AttributeModifier(UNLEASHED_ID, 1.0D,
                    AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        } else if (!unleashed && has) {
            dmg.removeModifier(UNLEASHED_ID);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.sable_compat.nano_heart").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.sable_compat.nano_heart_unleashed").withStyle(ChatFormatting.RED));
        tooltip.add(Component.translatable("tooltip.sable_compat.conversion_implant").withStyle(ChatFormatting.GOLD));
    }
}
