package com.invfix.cyberware;

import com.perigrine3.createcybernetics.api.CyberwareSlot;
import com.perigrine3.createcybernetics.api.ICyberwareItem;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;
import java.util.Set;

/**
 * Универсальный имплант — улучшенная копия ванильного импланта cyberware:
 * эффекты минимум ×2 от оригинала, БЕЗ минусов оригинала, 0 человечности,
 * 0 энергии. Крафт — только на сверхвысокоточном станке (precision tier 2).
 * Установка требует Наномашины Gen2 в мозге.
 *
 * Класс data-driven: набор атрибутных модификаторов + опциональное перманентное
 * ночное зрение задаются при регистрации в {@link CyberwareItems}.
 */
public class UniversalImplantItem extends Item implements ICyberwareItem {

    /** Атрибутный модификатор импланта. */
    public record Mod(Holder<Attribute> attribute, double amount, AttributeModifier.Operation op) {
        public static Mod add(Holder<Attribute> attribute, double amount) {
            return new Mod(attribute, amount, AttributeModifier.Operation.ADD_VALUE);
        }
    }

    private final String id;
    private final Set<CyberwareSlot> slots;
    private final List<Mod> mods;
    private final boolean nightVision;
    private final String footerKey;
    private final Set<CyberwareSlot> replacedOrgans;

    public UniversalImplantItem(Properties props, String id, Set<CyberwareSlot> slots,
                                List<Mod> mods, boolean nightVision) {
        this(props, id, slots, mods, nightVision, "universal_implant", Set.of());
    }

    public UniversalImplantItem(Properties props, String id, Set<CyberwareSlot> slots,
                                List<Mod> mods, boolean nightVision, String footerKey) {
        this(props, id, slots, mods, nightVision, footerKey, Set.of());
    }

    /**
     * @param replacedOrgans слоты, которые имплант ЗАМЕЩАЕТ (как ориг. ICyberwareItem.
     *                       getReplacedOrgans/replacesOrgan) — пусто, если это чистая
     *                       аугментация без замены органа (как большинство апгрейдов).
     */
    public UniversalImplantItem(Properties props, String id, Set<CyberwareSlot> slots,
                                List<Mod> mods, boolean nightVision, String footerKey,
                                Set<CyberwareSlot> replacedOrgans) {
        super(props.stacksTo(1));
        this.id = id;
        this.slots = slots;
        this.mods = mods;
        this.nightVision = nightVision;
        this.footerKey = footerKey;
        this.replacedOrgans = replacedOrgans;
    }

    @Override
    public boolean replacesOrgan() { return !replacedOrgans.isEmpty(); }

    @Override
    public Set<CyberwareSlot> getReplacedOrgans() { return replacedOrgans; }

    @Override
    public int getHumanityCost() { return 0; }

    @Override
    public Set<CyberwareSlot> getSupportedSlots() { return slots; }

    @Override
    public int getEnergyUsedPerTick(LivingEntity entity, ItemStack installedStack, CyberwareSlot slot) {
        return 0;
    }

    @Override
    public boolean requiresEnergyToFunction(LivingEntity entity, ItemStack installedStack, CyberwareSlot slot) {
        return false;
    }

    @Override
    public void onInstalled(LivingEntity entity) {
        for (int i = 0; i < mods.size(); i++) {
            Mod m = mods.get(i);
            AttributeInstance inst = entity.getAttribute(m.attribute());
            if (inst == null) continue;
            ResourceLocation rl = ResourceLocation.fromNamespaceAndPath("sable_compat", id + "_" + i);
            inst.removeModifier(rl);
            inst.addPermanentModifier(new AttributeModifier(rl, m.amount(), m.op()));
        }
    }

    @Override
    public void onRemoved(LivingEntity entity) {
        for (int i = 0; i < mods.size(); i++) {
            Mod m = mods.get(i);
            AttributeInstance inst = entity.getAttribute(m.attribute());
            if (inst != null) inst.removeModifier(ResourceLocation.fromNamespaceAndPath("sable_compat", id + "_" + i));
        }
    }

    @Override
    public void onTick(LivingEntity entity) {
        if (entity.level().isClientSide) return;
        boolean active = CompositeMk2.gen2Active(entity);

        // Гейт Gen2 функциональный: бонусы висят только при активном Gen2
        // (проверка установки в createcybernetics работает лишь внутри слота,
        // кросс-слотовый гейт на установке невозможен).
        if (!mods.isEmpty() && entity.level().getGameTime() % 20 == 0) {
            Mod first = mods.get(0);
            AttributeInstance inst0 = entity.getAttribute(first.attribute());
            boolean applied = inst0 != null && inst0.getModifier(
                    ResourceLocation.fromNamespaceAndPath("sable_compat", id + "_0")) != null;
            if (active && !applied) {
                onInstalled(entity);
                CompositeMk2.refreshCaps(entity);
            } else if (!active && applied) {
                onRemoved(entity);
                CompositeMk2.notifySuspended(entity);
                CompositeMk2.refreshCaps(entity);
            }
        }

        if (nightVision && active && entity.level().getGameTime() % 200 == 0) {
            // 500 тиков с рефрешем каждые 200 — без мигания на границе действия
            entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 500, 0, true, false, false));
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.sable_compat." + id).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.sable_compat." + footerKey).withStyle(ChatFormatting.GOLD));
    }
}
