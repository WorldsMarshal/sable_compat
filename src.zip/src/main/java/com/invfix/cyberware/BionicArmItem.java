package com.invfix.cyberware;

import com.perigrine3.createcybernetics.api.CyberwareSlot;
import com.perigrine3.createcybernetics.item.cyberware.arm.CyberarmItem;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;

/**
 * Бионическая рука (Metal Gear) — улучшенный аналог
 * {@code createcybernetics:basecyberware_leftarm/rightarm}.
 *
 * Отличия от базового кибер-протеза:
 *  - не потребляет энергию и работает вечно ({@link #getEnergyUsedPerTick} = 0,
 *    {@link #requiresEnergyToFunction} = false);
 *  - сила втрое выше: базовая рука даёт +0.5 к урону на руку (и +0.5 за вторую),
 *    здесь — +1.5 на руку, т.е. одна рука = +1.5 (×3 от 0.5), две = +3.0 (×3 от 1.0).
 *
 * Внешний вид на игроке (осветлённая модель) задаётся системой скина
 * createcybernetics; интеграция в неё — через теги (см. data/createcybernetics/
 * tags/item/*). Класс наследует весь прочий функционал базовой кибер-руки.
 *
 * ВАЖНО: компилируется только при наличии createcybernetics в classpath
 * (compileOnly), а регистрируется только если мод загружен (см. CyberwareItems).
 */
public class BionicArmItem extends CyberarmItem {

    private final String sideKey;

    public BionicArmItem(Properties props, int humanityCost, CyberwareSlot side) {
        super(props, humanityCost, side);
        this.sideKey = side == CyberwareSlot.LARM ? "left" : "right";
    }

    @Override
    public int getEnergyUsedPerTick(LivingEntity entity, ItemStack installedStack, CyberwareSlot slot) {
        return 0;
    }

    @Override
    public boolean requiresEnergyToFunction(LivingEntity entity, ItemStack installedStack, CyberwareSlot slot) {
        return false;
    }

    @Override
    public void onInstalled(LivingEntity entity) {
        applyModifier(entity, Attributes.ATTACK_DAMAGE, "bionic_arm_damage_" + sideKey, 21.5D);
        applyModifier(entity, Attributes.BLOCK_BREAK_SPEED, "bionic_arm_break_" + sideKey, 2.35D);
    }

    @Override
    public void onRemoved(LivingEntity entity) {
        removeModifier(entity, Attributes.ATTACK_DAMAGE, "bionic_arm_damage_" + sideKey);
        removeModifier(entity, Attributes.BLOCK_BREAK_SPEED, "bionic_arm_break_" + sideKey);
    }

    static void applyModifier(LivingEntity entity, Holder<Attribute> attribute, String path, double amount) {
        AttributeInstance inst = entity.getAttribute(attribute);
        if (inst == null) {
            return;
        }
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath("sable_compat", path);
        inst.removeModifier(id);
        inst.addPermanentModifier(new AttributeModifier(id, amount, AttributeModifier.Operation.ADD_VALUE));
    }

    static void removeModifier(LivingEntity entity, Holder<Attribute> attribute, String path) {
        AttributeInstance inst = entity.getAttribute(attribute);
        if (inst != null) {
            inst.removeModifier(ResourceLocation.fromNamespaceAndPath("sable_compat", path));
        }
    }
}
