package com.invfix.cyberware;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.ArrayList;
import java.util.List;

/**
 * Предметы ветки кибер-протезов (Metal Gear), этап «cyberware».
 *
 * Регистрируются под неймспейсом {@code sable_compat} → ассеты в
 * {@code assets/sable_compat/...}. Используются в рецептах, гейченных по
 * наличию create / createcybernetics / createbigcannons / tfmg / powergrid /
 * createaddition (в зависимости от ингредиентов рецепта).
 *
 * Фаза 1 (фундамент): композитный слиток/самородок/пластина Mk1.
 * Последующие предметы (Mk2, печатная плата, микроэлектроника, сервопривод,
 * ладонь, протезы) добавляются сюда же по мере реализации фаз.
 *
 * Подключается из {@link com.invfix.InvincibleFix} через {@link #register(IEventBus)}.
 */
public final class CompositeItems {

    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems("sable_compat");

    private static final List<DeferredItem<Item>> TAB_ENTRIES = new ArrayList<>();

    private static DeferredItem<Item> simple(String name) {
        DeferredItem<Item> item = ITEMS.registerSimpleItem(name, new Item.Properties());
        TAB_ENTRIES.add(item);
        return item;
    }

    // --- Фаза 1: композит Mk1 ---
    public static final DeferredItem<Item> COMPOSITE_INGOT_MK1 = simple("composite_ingot_mk1");
    public static final DeferredItem<Item> COMPOSITE_NUGGET_MK1 = simple("composite_nugget_mk1");
    public static final DeferredItem<Item> COMPOSITE_PLATE_MK1 = simple("composite_plate_mk1");

    // --- Фаза 2: композит Mk2 ---
    public static final DeferredItem<Item> COMPOSITE_INGOT_MK2 = simple("composite_ingot_mk2");
    public static final DeferredItem<Item> COMPOSITE_NUGGET_MK2 = simple("composite_nugget_mk2");
    public static final DeferredItem<Item> COMPOSITE_PLATE_MK2 = simple("composite_plate_mk2");

    // --- Фаза 3: электроника и узлы ---
    public static final DeferredItem<Item> PRINTED_CIRCUIT_BOARD = simple("printed_circuit_board");
    public static final DeferredItem<Item> MICROELECTRONICS_COMPONENTS = simple("microelectronics_components");
    public static final DeferredItem<Item> MILITARY_SERVO = simple("military_servo");
    /** Высокоточные оружейные компоненты — затворные группы/УСМ, только высокоточный станок (E2+). */
    public static final DeferredItem<Item> PRECISION_GUN_PARTS = simple("precision_gun_parts");
    public static final DeferredItem<Item> COMPOSITE_PALM_MK1 = simple("composite_palm_mk1");

    // --- Фаза 5a: наноэлектроника, цепочка ДО литографа ---
    // Реалистичный цикл производства чипа: кремнезём → кремний-сырец →
    // поликристалл → монокристалл-слиток → пластина → окисление → фоторезист.
    // Заканчивается покрытой пластиной (coated_wafer) — это вход литографа (A8).
    public static final DeferredItem<Item> SILICA = simple("silica");
    public static final DeferredItem<Item> RAW_SILICON = simple("raw_silicon");
    public static final DeferredItem<Item> POLYSILICON = simple("polysilicon");
    public static final DeferredItem<Item> MONO_SILICON_INGOT = simple("mono_silicon_ingot");
    public static final DeferredItem<Item> SILICON_WAFER = simple("silicon_wafer");
    public static final DeferredItem<Item> OXIDIZED_WAFER = simple("oxidized_wafer");
    public static final DeferredItem<Item> COATED_WAFER = simple("coated_wafer");
    // Выход литографа (A8): экспонированная пластина.
    public static final DeferredItem<Item> EXPOSED_WAFER = simple("exposed_wafer");
    // Боковые компоненты (нужны позже на A11 — нанопроцессор):
    public static final DeferredItem<Item> NANO_WIRING = simple("nano_wiring");
    public static final DeferredItem<Item> NANO_SUBSTRATE = simple("nano_substrate");

    // --- Фаза 5b: пост-литография (A9→A11), от экспонированной пластины к нанопроцессору ---
    // A9: проявка+травление кислотой → A10: легирование (диффузия примесей) →
    // A11: нарезка пластины на кристаллы → корпусирование в нанопроцессор.
    public static final DeferredItem<Item> ETCHED_WAFER = simple("etched_wafer");
    public static final DeferredItem<Item> DOPED_WAFER = simple("doped_wafer");
    public static final DeferredItem<Item> NANOPROCESSOR_DIE = simple("nanoprocessor_die");
    public static final DeferredItem<Item> NANOPROCESSOR = simple("nanoprocessor");

    // --- Фаза 6a: процессоры-компоненты и yield-бутстрап ---
    // Микропроцессор — простой чип (аналог ранних ИС), гейт высокоточного станка и
    // контроллера литографа. На мех.сборщике собирается «нетестированный» вариант,
    // из которого микропроцессор выбивается тестом с шансом ~10% (create:cutting);
    // на высокоточном станке — надёжно (тир-эксклюзивный рецепт sable_compat:precision).
    public static final DeferredItem<Item> UNTESTED_MICROPROCESSOR = simple("untested_microprocessor");
    public static final DeferredItem<Item> MICROPROCESSOR = simple("microprocessor");

    // --- Супертех: сверхпроводящий ультраний (фиктивный стабильный сверхпроводник) ---
    // Синтез: криофлюс + незеритовый лом + золото + редстоун (супернагрев, смешивание)
    // → нестабильный ультраний → стабилизация на сверхвысокоточном станке (tier 2).
    public static final DeferredItem<Item> UNSTABLE_ULTRANIUM = simple("unstable_ultranium");
    public static final DeferredItem<Item> SUPERCONDUCTING_ULTRANIUM = simple("superconducting_ultranium");
    // Узел протезов уровня Райдена (MGR) — тир-2 эксклюзив, кормовой компонент фазы 7.
    public static final DeferredItem<Item> SUPERCONDUCTING_SERVO_NODE = simple("superconducting_servo_node");
    // Синтетический незеритовый обломок — химический синтез (аналог HPHT), конвертится 1:1.
    public static final DeferredItem<Item> SYNTHETIC_NETHERITE_SCRAP = simple("synthetic_netherite_scrap");
    // Синтетический кристалл — гидротермальный рост в гипербарической печи (автоклав):
    // кремнезём + затравка-кварц + вода (как в реальном гидротермальном росте
    // синтетического кварца). Замена аметиста (тег c:gems/amethyst + конверсия 1:1) —
    // затравка намеренно НЕ аметист, иначе получилась бы циклическая зависимость.
    public static final DeferredItem<Item> SYNTHETIC_CRYSTAL = simple("synthetic_crystal");
    // Наномашины Gen4 — не носятся, только компонент крафта Сердца (фаза 10).
    public static final DeferredItem<Item> NANOMACHINES_GEN4 = simple("nanomachines_gen4");

    /** Мем-неймспейс: id предмета — not_yuri:fox_milk. */
    public static final DeferredRegister.Items NOT_YURI_ITEMS =
            DeferredRegister.createItems("not_yuri");

    /** «Лисье молоко» — рофл-предмет (см. com.invfix.item.FoxMilkItem). Стак 1, остаток — ведро. */
    public static final DeferredItem<Item> FOX_MILK =
            NOT_YURI_ITEMS.register("fox_milk", () -> new com.invfix.item.FoxMilkItem(
                    new Item.Properties().stacksTo(1)
                            .craftRemainder(net.minecraft.world.item.Items.BUCKET)));

    private CompositeItems() {}

    public static void register(IEventBus modEventBus) {
        ITEMS.register(modEventBus);
        NOT_YURI_ITEMS.register(modEventBus);
        modEventBus.addListener(CompositeItems::onBuildCreativeTabs);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            for (DeferredItem<Item> item : TAB_ENTRIES) {
                event.accept(item);
            }
        }
        if (event.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
            event.accept(FOX_MILK);
        }
    }
}
