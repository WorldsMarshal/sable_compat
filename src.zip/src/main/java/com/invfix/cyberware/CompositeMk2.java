package com.invfix.cyberware;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Общая логика протезов Composite Bionic Mk2.
 *
 * Стак-эффект сытости ОБЩИЙ на игрока: +2 еды раз в 60 тиков независимо от числа
 * установленных Mk2 (гейт по времени через WeakHashMap, все четыре протеза
 * дёргают один и тот же счётчик).
 */
final class CompositeMk2 {

    static final int ENERGY_PER_TICK = 4;   // отдача в энергосистему cyberware, на протез
    static final double HEALTH_BONUS = 10.0D; // +10 капы HP на протез

    private static final Map<LivingEntity, Long> LAST_FED = new WeakHashMap<>();

    private CompositeMk2() {}

    static void sharedFeedTick(LivingEntity entity) {
        if (!(entity instanceof Player player) || player.level().isClientSide) return;
        long now = player.level().getGameTime();
        Long last = LAST_FED.get(player);
        if (last != null && now - last < 60) return;
        LAST_FED.put(player, now);
        var food = player.getFoodData();
        if (food.getFoodLevel() < 20) {
            food.setFoodLevel(Math.min(20, food.getFoodLevel() + 2));
        }
    }

    /** Активен ли гейт Gen2 (пинги NanomachinesItem gen2 через мост). */
    static boolean gen2Active(net.minecraft.world.entity.LivingEntity e) {
        return com.invfix.cybercompat.CyberBonusBridge.isGen2Active(e);
    }

    /** Actionbar-уведомление при приостановке импланта (на переходе, не спам). */
    static void notifySuspended(net.minecraft.world.entity.LivingEntity e) {
        if (e instanceof net.minecraft.world.entity.player.Player p) {
            p.displayClientMessage(net.minecraft.network.chat.Component.translatable(
                    "message.sable_compat.gen2_required"), true);
        }
    }

    /** Пересчёт глобальных капов скорости/прыжка на переходе гейта Gen2. */
    static void refreshCaps(net.minecraft.world.entity.LivingEntity e) {
        if (e instanceof net.minecraft.world.entity.player.Player p) {
            AttributeCaps.refresh(p);
        }
    }
}
