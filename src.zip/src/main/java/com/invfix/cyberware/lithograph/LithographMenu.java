package com.invfix.cyberware.lithograph;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.neoforge.items.ItemStackHandler;
import net.neoforged.neoforge.items.SlotItemHandler;

public class LithographMenu extends AbstractContainerMenu {

    private final LithographControllerBlockEntity be;
    private final ContainerData data;

    // Серверный конструктор.
    public LithographMenu(int id, Inventory inv, LithographControllerBlockEntity be) {
        super(LithographRegistry.LITHOGRAPH_MENU.get(), id);
        this.be = be;
        this.data = be.getData();
        ItemStackHandler items = be.getItems();

        // Вход (0).
        this.addSlot(new SlotItemHandler(items, 0, 56, 35));
        // Выход (1) — только машина кладёт сюда.
        this.addSlot(new SlotItemHandler(items, 1, 116, 35) {
            @Override
            public boolean mayPlace(ItemStack stack) { return false; }
        });

        addPlayerInventory(inv);
        addDataSlots(this.data);
    }

    // Клиентский конструктор.
    public LithographMenu(int id, Inventory inv, RegistryFriendlyByteBuf buf) {
        this(id, inv, resolve(buf.readBlockPos()));
    }

    private static LithographControllerBlockEntity resolve(BlockPos pos) {
        BlockEntity be = Minecraft.getInstance().level.getBlockEntity(pos);
        return be instanceof LithographControllerBlockEntity c ? c : null;
    }

    private void addPlayerInventory(Inventory inv) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inv, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inv, col, 8 + col * 18, 142));
        }
    }

    // --- синхронизированные значения для экрана ---
    public int getProgress() { return data.get(0); }
    public int getMaxProgress() { return data.get(1); }
    public int getEnergy() { return data.get(2); }
    public int getMaxEnergy() { return data.get(3); }
    public boolean isFormed() { return data.get(4) != 0; }

    private static final int MACHINE_SLOTS = 2;
    private static final int INV_START = MACHINE_SLOTS;
    private static final int INV_END = MACHINE_SLOTS + 36;

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            if (index < MACHINE_SLOTS) {
                // из машины → в инвентарь
                if (!this.moveItemStackTo(stack, INV_START, INV_END, true)) return ItemStack.EMPTY;
            } else {
                // из инвентаря → во вход (если подходит)
                if (!LithographControllerBlockEntity.resultFor(stack).isEmpty()) {
                    if (!this.moveItemStackTo(stack, 0, 1, false)) return ItemStack.EMPTY;
                } else {
                    return ItemStack.EMPTY;
                }
            }
            if (stack.isEmpty()) slot.set(ItemStack.EMPTY);
            else slot.setChanged();
            if (stack.getCount() == result.getCount()) return ItemStack.EMPTY;
            slot.onTake(player, stack);
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        return be != null && !be.isRemoved()
                && player.distanceToSqr(be.getBlockPos().getX() + 0.5,
                be.getBlockPos().getY() + 0.5, be.getBlockPos().getZ() + 0.5) <= 64.0;
    }
}
