package com.invfix.cyberware.lithograph;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Реестр литографа (первая блочная инфраструктура мода).
 *
 * Блоки:
 *  - {@code auto_electronics} — «Блок авторегулирующейся электроники», наполнение
 *    структуры (интерьер 3×3×6). Крафт на мех. сборщике, 2 шт. за раз.
 *  - {@code lithograph_controller} — контроллер с интерфейсом, ставится на длинную
 *    стену структуры лицом к игроку. Крафт ~2× сложнее наполнителя.
 *
 * Структура (валидация в {@link LithographMultiblock}): полый короб 5(Ш)×5(В)×8(Д).
 * Рёбра — minecraft:iron_block, стены — dndecor:industrial_plating_block,
 * наполнение — auto_electronics. Питание — FE из powergrid Device Connector,
 * который толкает энергию в receive-only буфер контроллера (~8 кВт ≈ 80k FE/тик).
 */
public final class LithographRegistry {

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks("sable_compat");
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("sable_compat");
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, "sable_compat");
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, "sable_compat");

    // --- Блоки ---
    public static final DeferredBlock<Block> AUTO_ELECTRONICS =
            BLOCKS.registerBlock("auto_electronics", Block::new,
                    BlockBehaviour.Properties.of().mapColor(MapColor.METAL)
                            .strength(4.0F, 8.0F).requiresCorrectToolForDrops().sound(SoundType.NETHERITE_BLOCK));

    public static final DeferredBlock<LithographControllerBlock> LITHOGRAPH_CONTROLLER =
            BLOCKS.registerBlock("lithograph_controller", LithographControllerBlock::new,
                    BlockBehaviour.Properties.of().mapColor(MapColor.METAL)
                            .strength(5.0F, 10.0F).requiresCorrectToolForDrops().sound(SoundType.NETHERITE_BLOCK));

    // Энергоприёмник переехал в общий com.invfix.cyberware.machines.MachineRegistry
    // (блок power_input) — используется всеми машинами, не только литографом.

    // --- BlockItem'ы ---
    public static final DeferredItem<BlockItem> AUTO_ELECTRONICS_ITEM =
            ITEMS.registerSimpleBlockItem("auto_electronics", AUTO_ELECTRONICS);
    public static final DeferredItem<BlockItem> LITHOGRAPH_CONTROLLER_ITEM =
            ITEMS.registerSimpleBlockItem("lithograph_controller", LITHOGRAPH_CONTROLLER);

    // --- BlockEntity ---
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<LithographControllerBlockEntity>> CONTROLLER_BE =
            BLOCK_ENTITIES.register("lithograph_controller",
                    () -> BlockEntityType.Builder.of(LithographControllerBlockEntity::new, LITHOGRAPH_CONTROLLER.get()).build(null));

    // --- Menu ---
    public static final DeferredHolder<MenuType<?>, MenuType<LithographMenu>> LITHOGRAPH_MENU =
            MENUS.register("lithograph",
                    () -> IMenuTypeExtension.create((windowId, inv, buf) -> new LithographMenu(windowId, inv, buf)));

    private LithographRegistry() {}

    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
        MENUS.register(modEventBus);
        modEventBus.addListener(LithographRegistry::onBuildCreativeTabs);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(AUTO_ELECTRONICS_ITEM);
            event.accept(LITHOGRAPH_CONTROLLER_ITEM);
        }
    }
}
