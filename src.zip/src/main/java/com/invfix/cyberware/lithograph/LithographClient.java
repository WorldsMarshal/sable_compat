package com.invfix.cyberware.lithograph;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/**
 * Клиентская регистрация экрана литографа. Вызывается ТОЛЬКО на клиенте
 * (из {@code InvincibleFix} под проверкой dist), поэтому клиентские классы
 * не попадают в загрузчик выделенного сервера.
 */
public final class LithographClient {
    private LithographClient() {}

    public static void init(IEventBus modEventBus) {
        modEventBus.addListener(LithographClient::onRegisterScreens);
    }

    private static void onRegisterScreens(RegisterMenuScreensEvent event) {
        event.register(LithographRegistry.LITHOGRAPH_MENU.get(), LithographScreen::new);
    }
}
