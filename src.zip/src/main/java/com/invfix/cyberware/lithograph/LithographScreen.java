package com.invfix.cyberware.lithograph;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

import java.util.List;

public class LithographScreen extends AbstractContainerScreen<LithographMenu> {

    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/gui/lithograph/lithograph_gui.png");

    // геометрия наложений (в координатах фона)
    private static final int ARROW_X = 80, ARROW_Y = 38, ARROW_W = 20, ARROW_H = 6;
    private static final int BAR_X = 11, BAR_Y = 19, BAR_W = 10, BAR_H = 51;

    public LithographScreen(LithographMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = 166;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = this.leftPos, y = this.topPos;
        g.blit(TEXTURE, x, y, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);

        // шкала прогресса (зелёная заливка стрелки)
        int maxP = this.menu.getMaxProgress();
        if (maxP > 0 && this.menu.getProgress() > 0) {
            int w = (int) (ARROW_W * (this.menu.getProgress() / (float) maxP));
            g.fill(x + ARROW_X, y + ARROW_Y, x + ARROW_X + w, y + ARROW_Y + ARROW_H, 0xFF49C25A);
        }

        // шкала энергии (снизу вверх)
        int maxE = this.menu.getMaxEnergy();
        if (maxE > 0) {
            int h = (int) (BAR_H * (this.menu.getEnergy() / (float) maxE));
            g.fill(x + BAR_X, y + BAR_Y + (BAR_H - h), x + BAR_X + BAR_W, y + BAR_Y + BAR_H, 0xFFE0B000);
        }

        // индикатор «структура не собрана»
        if (!this.menu.isFormed()) {
            g.fill(x + ARROW_X, y + ARROW_Y, x + ARROW_X + ARROW_W, y + ARROW_Y + ARROW_H, 0x66FF4040);
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g, mouseX, mouseY, partialTick);
        super.render(g, mouseX, mouseY, partialTick);

        // подсказка по энергии при наведении на шкалу
        int x = this.leftPos, y = this.topPos;
        if (mouseX >= x + BAR_X && mouseX <= x + BAR_X + BAR_W
                && mouseY >= y + BAR_Y && mouseY <= y + BAR_Y + BAR_H) {
            String status = !this.menu.isFormed()
                    ? "message.sable_compat.lithograph.invalid"
                    : (this.menu.getMaxEnergy() <= 0
                        ? "message.sable_compat.lithograph.no_power"
                        : "message.sable_compat.lithograph.formed");
            g.renderTooltip(this.font, List.of(
                    Component.literal(this.menu.getEnergy() + " / " + this.menu.getMaxEnergy() + " J"),
                    Component.translatable(status)
            ), java.util.Optional.empty(), mouseX, mouseY);
        }
        this.renderTooltip(g, mouseX, mouseY);
    }
}
