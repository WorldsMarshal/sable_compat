package com.invfix.cyberware.lithograph;

import com.invfix.cyberware.CompositeItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.items.ItemStackHandler;
import org.jetbrains.annotations.Nullable;

/**
 * BlockEntity контроллера литографа.
 *
 * Энергия берётся из общего блока-Энергоприёмника (power_input), встроенного в центр
 * короткой стены структуры. Контроллер находит его при валидации и стабильно снимает
 * {@link #CONSUME_PER_TICK} FE/тик во время работы. Сам приёмник заряжается игроком из
 * сети powergrid через Device Connector (FE-приёмник открыт только для device_connector).
 *
 * Рецепт пока зашит (coated_wafer → exposed_wafer, шаг A8); список расширяется в
 * {@link #resultFor(ItemStack)}.
 */
public class LithographControllerBlockEntity extends BlockEntity
        implements MenuProvider, com.invfix.cyberware.machines.IMachineItemSink {

    public static final int CONSUME_PER_TICK = 1880; // FE/тик во время работы (тюнится)
    public static final int MAX_PROGRESS = 3200;     // 15 c при стабильном питании
    private static final int REVALIDATE_INTERVAL = 40;

    private static final int SLOT_INPUT = 0;
    private static final int SLOT_OUTPUT = 1;

    private final ItemStackHandler items = new ItemStackHandler(2) {
        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return slot == SLOT_INPUT && !resultFor(stack).isEmpty();
        }
        @Override
        protected void onContentsChanged(int slot) { setChanged(); }
    };

    private int progress = 0;
    private boolean formed = false;
    @Nullable private BlockPos powerPos = null;

    // [0]=progress [1]=max [2]=energy(FE) [3]=capacity(FE) [4]=formed
    private final SimpleContainerData data = new SimpleContainerData(5);

    public LithographControllerBlockEntity(BlockPos pos, BlockState state) {
        super(LithographRegistry.CONTROLLER_BE.get(), pos, state);
        data.set(1, MAX_PROGRESS);
    }

    /** Зашитые превращения литографа. */
    public static ItemStack resultFor(ItemStack input) {
        if (input.isEmpty()) return ItemStack.EMPTY;
        Item in = input.getItem();
        if (in == CompositeItems.COATED_WAFER.get()) {
            return new ItemStack(CompositeItems.EXPOSED_WAFER.get());
        }
        return ItemStack.EMPTY;
    }

    public boolean revalidate() {
        if (level == null) { formed = false; powerPos = null; return false; }
        LithographMultiblock.Result r = LithographMultiblock.validate(level, worldPosition,
                getBlockState().getValue(LithographControllerBlock.FACING));
        boolean changed = (r.formed() != formed);
        formed = r.formed();
        powerPos = r.powerPos();
        if (changed) setChanged();
        return formed;
    }

    @Nullable
    private com.invfix.cyberware.machines.PowerInputBlockEntity powerBE() {
        if (level == null || powerPos == null) return null;
        BlockEntity be = level.getBlockEntity(powerPos);
        return be instanceof com.invfix.cyberware.machines.PowerInputBlockEntity p ? p : null;
    }

    /** Create-шлюз ({@code machine_item_port}) толкает сюда предметы из воронок. */
    @Override
    public ItemStack insertToMachine(ItemStack stack, boolean simulate) {
        if (stack.isEmpty()) return stack;
        if (resultFor(stack).isEmpty()) return stack; // не сырьё литографа — не принимаем
        return items.insertItem(SLOT_INPUT, stack, simulate);
    }

    /** Для вынимания шлюзом: вход+выход литографа (в т.ч. готовая exposed_wafer). */
    @Override
    public net.neoforged.neoforge.items.IItemHandler getExtractHandler() {
        return items;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, LithographControllerBlockEntity be) {
        if (level.isClientSide) return;

        if ((level.getGameTime() % REVALIDATE_INTERVAL) == 0L) be.revalidate();

        com.invfix.cyberware.machines.PowerInputBlockEntity power = be.powerBE();
        int energy = power != null ? power.getStored() : 0;
        int capacity = power != null ? power.getCapacity() : 0;

        boolean working = false;
        if (be.formed && power != null) {
            ItemStack input = be.items.getStackInSlot(SLOT_INPUT);
            ItemStack result = resultFor(input);
            if (!result.isEmpty()) {
                ItemStack out = be.items.getStackInSlot(SLOT_OUTPUT);
                boolean outputOk = out.isEmpty()
                        || (ItemStack.isSameItemSameComponents(out, result)
                            && out.getCount() + result.getCount() <= out.getMaxStackSize());
                if (outputOk && power.consume(CONSUME_PER_TICK)) {
                    working = true;
                    be.progress++;
                    if (be.progress >= MAX_PROGRESS) {
                        be.progress = 0;
                        be.items.extractItem(SLOT_INPUT, 1, false);
                        if (out.isEmpty()) be.items.setStackInSlot(SLOT_OUTPUT, result.copy());
                        else out.grow(result.getCount());
                    }
                    be.setChanged();
                }
            }
        }
        if (!working && be.progress != 0) { be.progress = 0; be.setChanged(); }

        be.data.set(0, be.progress);
        be.data.set(2, energy);
        be.data.set(3, capacity);
        be.data.set(4, be.formed ? 1 : 0);
    }

    public void dropContents(Level level, BlockPos pos) {
        SimpleContainer c = new SimpleContainer(items.getSlots());
        for (int i = 0; i < items.getSlots(); i++) c.setItem(i, items.getStackInSlot(i));
        Containers.dropContents(level, pos, c);
    }

    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, LithographRegistry.CONTROLLER_BE.get(),
                (be, side) -> be.items);
    }

    public ItemStackHandler getItems() { return items; }
    public ContainerData getData() { return data; }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Items", items.serializeNBT(registries));
        tag.putInt("Progress", progress);
        tag.putBoolean("Formed", formed);
        if (powerPos != null) {
            tag.putLong("Power", powerPos.asLong());
            tag.putBoolean("HasPower", true);
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (tag.contains("Items")) items.deserializeNBT(registries, tag.getCompound("Items"));
        progress = tag.getInt("Progress");
        formed = tag.getBoolean("Formed");
        powerPos = tag.getBoolean("HasPower") ? BlockPos.of(tag.getLong("Power")) : null;
        data.set(0, progress);
        data.set(4, formed ? 1 : 0);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.sable_compat.lithograph_controller");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new LithographMenu(id, inv, this);
    }
}
