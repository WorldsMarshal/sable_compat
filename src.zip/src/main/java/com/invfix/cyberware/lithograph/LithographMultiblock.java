package com.invfix.cyberware.lithograph;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

/**
 * Валидация структуры литографа.
 *
 * Полый короб 5(Ш)×5(В)×8(Д), оси относительно контроллера:
 *   into   = FACING.getOpposite()  — в глубину короба (Ш = 5)
 *   up     = UP                    — высота (В = 5)
 *   length = FACING.getClockWise() — длина (Д = 8); контроллер где-то в середине
 *                                    ДЛИННОЙ стены (5×8)
 *
 * Материалы: рёбра — iron_block; стены — dndecor:industrial_plating_block;
 * наполнение (3×3×6) — sable_compat:auto_electronics. В ЦЕНТРЕ короткой стены
 * (5×5) вместо промышленного железа ставится sable_compat:power_input (общий
 * Энергоприёмник машин) — из него литограф берёт ток. Контроллер занимает одну
 * стену-ячейку (не ребро) длинной грани.
 */
public final class LithographMultiblock {

    private static final int W = 5; // into  (ширина)
    private static final int H = 5; // up    (высота)
    private static final int L = 8; // length(длина)
    private static final int SCAN_CAP = 16;

    public record Result(boolean formed, @Nullable BlockPos powerPos) {
        public static final Result INVALID = new Result(false, null);
    }

    private LithographMultiblock() {}

    private static Block modBlock(String ns, String path) {
        return BuiltInRegistries.BLOCK.get(ResourceLocation.fromNamespaceAndPath(ns, path));
    }


    private static boolean isWallShell(BlockState st) {
        return st.is(Blocks.IRON_BLOCK)
                || st.is(modBlock("dndecor", "industrial_plating_block"))
                || st.is(LithographRegistry.LITHOGRAPH_CONTROLLER.get());
    }

    private static int scan(Level level, BlockPos from, Direction dir) {
        int n = 0;
        BlockPos.MutableBlockPos p = from.mutable();
        for (int i = 0; i < SCAN_CAP; i++) {
            p.move(dir);
            if (!isWallShell(level.getBlockState(p))) break;
            n++;
        }
        return n;
    }

    public static Result validate(Level level, BlockPos controllerPos, Direction facing) {
        if (!facing.getAxis().isHorizontal()) return Result.INVALID;

        Direction into = facing.getOpposite();
        Direction up = Direction.UP;
        Direction len = facing.getClockWise();

        // 1) Локализуем контроллер в ближней (длинной) стене.
        int upPos = scan(level, controllerPos, up);
        int upNeg = scan(level, controllerPos, up.getOpposite());
        int lenPos = scan(level, controllerPos, len);
        int lenNeg = scan(level, controllerPos, len.getOpposite());

        if (upPos + upNeg + 1 != H) return Result.INVALID;   // высота стены = 5
        if (lenPos + lenNeg + 1 != L) return Result.INVALID;  // длина стены = 8

        int ctrlHi = upNeg;
        int ctrlLi = lenNeg;
        if (ctrlHi == 0 || ctrlHi == H - 1 || ctrlLi == 0 || ctrlLi == L - 1) return Result.INVALID;

        BlockPos corner = controllerPos
                .relative(up.getOpposite(), upNeg)
                .relative(len.getOpposite(), lenNeg);

        Block iron = Blocks.IRON_BLOCK;
        Block industrial = modBlock("dndecor", "industrial_plating_block");
        Block electronics = LithographRegistry.AUTO_ELECTRONICS.get();
        Block powerInput = com.invfix.cyberware.machines.MachineRegistry.POWER_INPUT.get();

        BlockPos powerPos = null;
        BlockPos.MutableBlockPos cell = new BlockPos.MutableBlockPos();
        for (int di = 0; di < W; di++) {
            for (int hi = 0; hi < H; hi++) {
                for (int li = 0; li < L; li++) {
                    cell.set(corner);
                    cell.move(into, di);
                    cell.move(up, hi);
                    cell.move(len, li);

                    if (cell.equals(controllerPos)) continue; // контроллер на месте

                    int extremes = (di == 0 || di == W - 1 ? 1 : 0)
                            + (hi == 0 || hi == H - 1 ? 1 : 0)
                            + (li == 0 || li == L - 1 ? 1 : 0);

                    BlockState st = level.getBlockState(cell);
                    boolean shortWallCenter = (di == 2 && hi == 2 && (li == 0 || li == L - 1));

                    if (extremes == 0) {
                        if (!st.is(electronics)) return Result.INVALID;            // наполнение
                    } else if (extremes == 1) {
                        if (shortWallCenter && st.is(powerInput)) {
                            powerPos = cell.immutable();                            // энергоприёмник
                        } else if (!st.is(industrial)) {
                            return Result.INVALID;                                  // стена
                        }
                    } else {
                        if (!st.is(iron)) return Result.INVALID;                    // ребро
                    }
                }
            }
        }
        return new Result(true, powerPos);
    }
}
