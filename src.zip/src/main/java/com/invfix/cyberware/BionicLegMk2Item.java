package com.invfix.cyberware;

import com.perigrine3.createcybernetics.api.CyberwareSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;

/**
 * Гейт Gen2 — ФУНКЦИОНАЛЬНЫЙ (не установочный): API createcybernetics проверяет
 * requiresCyberware только внутри слота установки, поэтому кросс-слотовое условие
 * «Gen2 в мозге» на установке невыполнимо. Имплант ставится свободно, но бонусы
 * активны лишь пока Gen2 пингует мост; без него модификаторы снимаются тиком.
 *
 * Composite Bionic Mk2 — нога. ×6 от Mk1; +10 капы HP; отдаёт энергию в систему
 * cyberware; общий стак-эффект +2 сытости/60т. Требует Наномашины Gen2 в мозге.
 */
public class BionicLegMk2Item extends BionicLegItem {

    // ×6 от значений Mk1 (см. BionicLegItem.onInstalled) — правится константами.
    // Итог двух ног (+0.18 скорости / +0.9 прыжка) упирается в глобальные капы
    // AttributeCaps (0.28 / 0.85) — выше потолка бусты не действуют.
    static final double SPEED = 0.015D * 6;   // 0.09
    static final double JUMP = 0.075D * 6;    // 0.45

    private final String sideKey;

    public BionicLegMk2Item(Properties props, int humanityCost, CyberwareSlot side) {
        super(props, humanityCost, side);
        this.sideKey = side == CyberwareSlot.LLEG ? "left" : "right";
    }

    @Override
    public int getEnergyGeneratedPerTick(LivingEntity entity, ItemStack installedStack, CyberwareSlot slot) {
        return CompositeMk2.gen2Active(entity) ? CompositeMk2.ENERGY_PER_TICK : 0;
    }

    @Override
    public void onInstalled(LivingEntity entity) {
        BionicArmItem.applyModifier(entity, Attributes.MOVEMENT_SPEED, "mk2_leg_speed_" + sideKey, SPEED);
        BionicArmItem.applyModifier(entity, Attributes.JUMP_STRENGTH, "mk2_leg_jump_" + sideKey, JUMP);
        BionicArmItem.applyModifier(entity, Attributes.MAX_HEALTH, "mk2_leg_health_" + sideKey, CompositeMk2.HEALTH_BONUS);
    }

    @Override
    public void onRemoved(LivingEntity entity) {
        BionicArmItem.removeModifier(entity, Attributes.MOVEMENT_SPEED, "mk2_leg_speed_" + sideKey);
        BionicArmItem.removeModifier(entity, Attributes.JUMP_STRENGTH, "mk2_leg_jump_" + sideKey);
        BionicArmItem.removeModifier(entity, Attributes.MAX_HEALTH, "mk2_leg_health_" + sideKey);
    }

    @Override
    public void onTick(LivingEntity entity) {
        if (!entity.level().isClientSide && entity.level().getGameTime() % 20 == 0) {
            boolean active = CompositeMk2.gen2Active(entity);
            boolean applied = entity.getAttribute(Attributes.MOVEMENT_SPEED) != null
                    && entity.getAttribute(Attributes.MOVEMENT_SPEED).getModifier(
                        net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(
                            "sable_compat", "mk2_leg_speed_" + sideKey)) != null;
            if (active && !applied) {
                onInstalled(entity);
                CompositeMk2.refreshCaps(entity);
            } else if (!active && applied) {
                onRemoved(entity);
                CompositeMk2.notifySuspended(entity);
                CompositeMk2.refreshCaps(entity);
            }
        }
        if (CompositeMk2.gen2Active(entity)) CompositeMk2.sharedFeedTick(entity);
    }
}
