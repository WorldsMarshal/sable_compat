package com.invfix.cyberware;

import com.perigrine3.createcybernetics.api.CyberwareSlot;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.ArrayList;
import java.util.List;

/**
 * Регистрация бионических протезов (фаза 4). Вынесено в отдельный класс,
 * потому что эти предметы наследуют классы createcybernetics — класс грузится
 * и регистрируется ТОЛЬКО если createcybernetics присутствует (проверка в
 * {@link com.invfix.InvincibleFix}), иначе без мода был бы краш.
 */
public final class CyberwareItems {

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("sable_compat");
    private static final List<DeferredItem<? extends Item>> TAB_ENTRIES = new ArrayList<>();

    private static final int HUMANITY_COST = 1;

    public static final DeferredItem<BionicArmItem> BIONIC_LEFTARM = arm("bionic_leftarm", CyberwareSlot.LARM);
    public static final DeferredItem<BionicArmItem> BIONIC_RIGHTARM = arm("bionic_rightarm", CyberwareSlot.RARM);
    public static final DeferredItem<BionicLegItem> BIONIC_LEFTLEG = leg("bionic_leftleg", CyberwareSlot.LLEG);
    public static final DeferredItem<BionicLegItem> BIONIC_RIGHTLEG = leg("bionic_rightleg", CyberwareSlot.RLEG);

    // Наномашины поколений (фаза 6): Gen1/2 — BRAIN, Gen3 — MUSCLE.
    public static final DeferredItem<NanomachinesItem> NANOMACHINES_GEN1 = nano("nanomachines_gen1", 1);
    public static final DeferredItem<NanomachinesItem> NANOMACHINES_GEN2 = nano("nanomachines_gen2", 2);
    public static final DeferredItem<NanomachinesItem> NANOMACHINES_GEN3 = nano("nanomachines_gen3", 3);

    // Composite Bionic Mk2 (фаза 7): ×6 от Mk1, +10 HP каждый, энергия в систему
    // cyberware, общий стак-эффект сытости. Требуют Gen2 в мозге.
    public static final DeferredItem<BionicArmMk2Item> MK2_LEFTARM = armMk2("bionic_mk2_leftarm", CyberwareSlot.LARM);
    public static final DeferredItem<BionicArmMk2Item> MK2_RIGHTARM = armMk2("bionic_mk2_rightarm", CyberwareSlot.RARM);
    public static final DeferredItem<BionicLegMk2Item> MK2_LEFTLEG = legMk2("bionic_mk2_leftleg", CyberwareSlot.LLEG);
    public static final DeferredItem<BionicLegMk2Item> MK2_RIGHTLEG = legMk2("bionic_mk2_rightleg", CyberwareSlot.RLEG);

    private static DeferredItem<BionicArmMk2Item> armMk2(String name, CyberwareSlot side) {
        DeferredItem<BionicArmMk2Item> it = ITEMS.register(name,
                () -> new BionicArmMk2Item(new Item.Properties().stacksTo(1), HUMANITY_COST, side));
        TAB_ENTRIES.add(it);
        return it;
    }

    private static DeferredItem<BionicLegMk2Item> legMk2(String name, CyberwareSlot side) {
        DeferredItem<BionicLegMk2Item> it = ITEMS.register(name,
                () -> new BionicLegMk2Item(new Item.Properties().stacksTo(1), HUMANITY_COST, side));
        TAB_ENTRIES.add(it);
        return it;
    }

    // Универсальные импланты (фаза 7): копии полезных ванильных имплантов cyberware,
    // эффекты >=x2, БЕЗ минусов, 0 человечности, 0 энергии, гейт Gen2, крафт tier 2.
    public static final DeferredItem<UniversalImplantItem> U_SUBDERMAL = universal("universal_subdermal_armor",
            java.util.Set.of(CyberwareSlot.SKIN), b -> b
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR, 24.0D));
    public static final DeferredItem<UniversalImplantItem> U_SYNTHMUSCLE = universal("universal_synthmuscle",
            java.util.Set.of(CyberwareSlot.MUSCLE), b -> b
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE, 4.0D)
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_KNOCKBACK, 3.0D)
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE, 3.0D)
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.JUMP_STRENGTH, 0.2D),
            java.util.Set.of(CyberwareSlot.MUSCLE));
    public static final DeferredItem<UniversalImplantItem> U_BONELACING = universal("universal_bonelacing",
            java.util.Set.of(CyberwareSlot.BONE), b -> b
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 24.0D));
    public static final DeferredItem<UniversalImplantItem> U_BONEFLEX = universal("universal_boneflex",
            java.util.Set.of(CyberwareSlot.BONE), b -> b
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.SAFE_FALL_DISTANCE, 18.0D));
    public static final DeferredItem<UniversalImplantItem> U_LINEAR_FRAME = universal("universal_linear_frame",
            java.util.Set.of(CyberwareSlot.BONE), b -> b
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 16.0D)
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE, 2.0D)
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.BLOCK_BREAK_SPEED, 2.0D),
            java.util.Set.of(CyberwareSlot.BONE));
    public static final DeferredItem<UniversalImplantItem> U_HYPEROXY = universal("universal_hyperoxygenation",
            java.util.Set.of(CyberwareSlot.LUNGS), b -> b
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, 0.18D));
    public static final DeferredItem<UniversalImplantItem> U_OXYGEN = universal("universal_oxygen_tank",
            java.util.Set.of(CyberwareSlot.LUNGS), b -> b
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.OXYGEN_BONUS, 20.0D));
    public static final DeferredItem<UniversalImplantItem> U_PNEUMATIC_WRIST = universal("universal_pneumatic_wrist",
            java.util.Set.of(CyberwareSlot.RARM, CyberwareSlot.LARM), b -> b
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.BLOCK_INTERACTION_RANGE, 4.0D)
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.ENTITY_INTERACTION_RANGE, 4.0D)
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_KNOCKBACK, 2.0D));
    public static final DeferredItem<UniversalImplantItem> U_NIGHT_VISION = universalNV("universal_night_vision",
            java.util.Set.of(CyberwareSlot.EYES));

    // Сердце наномашин (фаза 10): HEART, 0 человечности, крафт с Gen4.
    // Пассив: +40 HP + кибер-щит Invincible (Dura 30 / DTstat 40 через мост).
    // Unleashed при паре с Gen3: урон x2 (90 -> 180) + щит уровня Born for V.
    public static final DeferredItem<NanoHeartItem> NANO_HEART = heart("nano_heart");

    private static DeferredItem<NanoHeartItem> heart(String name) {
        DeferredItem<NanoHeartItem> it = ITEMS.register(name,
                () -> new NanoHeartItem(new Item.Properties()));
        TAB_ENTRIES.add(it);
        return it;
    }

    // Полная конверсия (фаза 7): SKIN/BONE/MUSCLE-набор, 0 человечности, 0 энергии.
    // Визуал — торс через SkinModifier.body() при установленном CONVERSION_SKIN
    // (см. BionicSkinMixin); конечности — готовые ironplated из createcybernetics.
    public static final DeferredItem<UniversalImplantItem> CONVERSION_SKIN = conversion("conversion_skin",
            java.util.Set.of(CyberwareSlot.SKIN), b -> b
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR, 10.0D)
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS, 4.0D));
    public static final DeferredItem<UniversalImplantItem> CONVERSION_BONE = conversion("conversion_bone",
            java.util.Set.of(CyberwareSlot.BONE), b -> b
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 20.0D));
    public static final DeferredItem<UniversalImplantItem> CONVERSION_MUSCLE = conversion("conversion_muscle",
            java.util.Set.of(CyberwareSlot.MUSCLE), b -> b
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE, 2.0D)
                    .add(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, 0.1D));

    private static DeferredItem<UniversalImplantItem> conversion(String name, java.util.Set<CyberwareSlot> slots,
            java.util.function.Function<ModList, ModList> fn) {
        java.util.List<UniversalImplantItem.Mod> mods = fn.apply(new ModList()).list;
        DeferredItem<UniversalImplantItem> it = ITEMS.register(name,
                // Полная конверсия буквально ЗАМЕЩАЕТ свой орган (как ориг. LinearFrame/
                // SynthMuscle/MechanicalHeart -> true + Set.of(тот же слот)).
                () -> new UniversalImplantItem(new Item.Properties(), name, slots, mods, false,
                        "conversion_implant", slots));
        TAB_ENTRIES.add(it);
        return it;
    }

    /** Мини-билдер списка модификаторов. */
    private static final class ModList {
        final java.util.List<UniversalImplantItem.Mod> list = new java.util.ArrayList<>();
        ModList add(net.minecraft.core.Holder<net.minecraft.world.entity.ai.attributes.Attribute> a, double v) {
            list.add(UniversalImplantItem.Mod.add(a, v));
            return this;
        }
    }

    private static DeferredItem<UniversalImplantItem> universal(String name, java.util.Set<CyberwareSlot> slots,
            java.util.function.Function<ModList, ModList> fn) {
        return universal(name, slots, fn, java.util.Set.of());
    }

    /**
     * @param replacedOrgans слоты, которые копируемый ОРИГИНАЛ реально замещает
     *                       (сверено по декомпилу createcybernetics: synthmuscle ->
     *                       MUSCLE, linear_frame -> BONE; у остальных — пусто).
     */
    private static DeferredItem<UniversalImplantItem> universal(String name, java.util.Set<CyberwareSlot> slots,
            java.util.function.Function<ModList, ModList> fn, java.util.Set<CyberwareSlot> replacedOrgans) {
        java.util.List<UniversalImplantItem.Mod> mods = fn.apply(new ModList()).list;
        DeferredItem<UniversalImplantItem> it = ITEMS.register(name,
                () -> new UniversalImplantItem(new Item.Properties(), name, slots, mods, false,
                        "universal_implant", replacedOrgans));
        TAB_ENTRIES.add(it);
        return it;
    }

    private static DeferredItem<UniversalImplantItem> universalNV(String name, java.util.Set<CyberwareSlot> slots) {
        DeferredItem<UniversalImplantItem> it = ITEMS.register(name,
                () -> new UniversalImplantItem(new Item.Properties(), name, slots, java.util.List.of(), true));
        TAB_ENTRIES.add(it);
        return it;
    }

    private static DeferredItem<NanomachinesItem> nano(String name, int gen) {
        DeferredItem<NanomachinesItem> it = ITEMS.register(name,
                () -> new NanomachinesItem(new Item.Properties(), gen));
        TAB_ENTRIES.add(it);
        return it;
    }

    private static DeferredItem<BionicArmItem> arm(String name, CyberwareSlot side) {
        DeferredItem<BionicArmItem> it = ITEMS.register(name,
                () -> new BionicArmItem(new Item.Properties().stacksTo(1), HUMANITY_COST, side));
        TAB_ENTRIES.add(it);
        return it;
    }

    private static DeferredItem<BionicLegItem> leg(String name, CyberwareSlot side) {
        DeferredItem<BionicLegItem> it = ITEMS.register(name,
                () -> new BionicLegItem(new Item.Properties().stacksTo(1), HUMANITY_COST, side));
        TAB_ENTRIES.add(it);
        return it;
    }

    private CyberwareItems() {}

    public static void register(IEventBus modEventBus) {
        ITEMS.register(modEventBus);
        modEventBus.addListener(CyberwareItems::onBuildCreativeTabs);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            for (DeferredItem<? extends Item> item : TAB_ENTRIES) {
                event.accept(item);
            }
        }
    }
}
