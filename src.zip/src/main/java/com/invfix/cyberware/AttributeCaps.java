package com.invfix.cyberware;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

/**
 * Глобальные капы скорости и прыжка игрока — БЕЗ тикового пересчёта.
 *
 * Импланты складываются и могут разогнать MOVEMENT_SPEED / JUMP_STRENGTH до
 * неиграбельных значений. Кап — корректирующий transient ADD_VALUE-модификатор:
 * читаем итог атрибута без коррекции и, если он выше потолка, прижимаем ровно к
 * потолку; ниже потолка кап себя полностью снимает (ваниль — спринт, зелья — не
 * трогается, они под потолком).
 *
 * Пересчёт только по СОБЫТИЯМ (тикрейт не засоряем):
 *  - операция на столе/робохирурге (CyberwareSurgeryEvent → {@code
 *    com.invfix.cybercompat.SurgeryCapListener}, регистрируется при наличии
 *    createcybernetics);
 *  - смерть/клон и респаун (модификаторы копируются, transient-коррекция — нет);
 *  - вход в мир (перманентные модификаторы персистятся, коррекция — нет);
 *  - переходы гейта Gen2 в Mk2/универсалках (прямой вызов {@link #refresh}).
 */
@EventBusSubscriber(modid = "sable_compat")
public final class AttributeCaps {

    private static final double SPEED_CAP = 0.28D;
    private static final double JUMP_CAP = 0.85D;

    private static final ResourceLocation SPEED_CAP_ID =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "speed_cap");
    private static final ResourceLocation JUMP_CAP_ID =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "jump_cap");

    private AttributeCaps() {}

    /** Пересчитать капы для игрока (дёргается строго по событиям). */
    public static void refresh(Player player) {
        if (player.level().isClientSide) return;
        clamp(player.getAttribute(Attributes.MOVEMENT_SPEED), SPEED_CAP_ID, SPEED_CAP);
        clamp(player.getAttribute(Attributes.JUMP_STRENGTH), JUMP_CAP_ID, JUMP_CAP);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) { refresh(event.getEntity()); }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) { refresh(event.getEntity()); }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) { refresh(event.getEntity()); }

    private static void clamp(AttributeInstance inst, ResourceLocation id, double cap) {
        if (inst == null) return;
        inst.removeModifier(id);
        double raw = inst.getValue();
        if (raw > cap) {
            inst.addTransientModifier(new AttributeModifier(id, cap - raw, AttributeModifier.Operation.ADD_VALUE));
        }
    }
}
