package com.invfix.cyberware.compat;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import org.patryk3211.powergrid.electricity.deviceconnector.DeviceConnectorBlockEntity;
import org.patryk3211.powergrid.electricity.febridge.IFEBridgeHandler;
import org.patryk3211.powergrid.electricity.sim.ElectricWire;

/**
 * Высоковольтный адаптер устройств (HV Device Connector).
 *
 * Физика стокового адаптера powergrid: FE-буфер ограничен приложенным напряжением
 * (maxCharge = |U| × forgeEnergyPerVolt, по умолчанию 2 FE/В), т.е. на сети 100 В
 * потолок — 200 FE/т. Поднять пропуск можно только напряжением — либо строить
 * 1000-вольтовую магистраль, либо этим блоком: внутри стоит повышающий
 * преобразователь ×{@value #VOLTAGE_MULT}, эквивалентный подаче ×10 напряжения на
 * конвертер, т.е. до 2000 FE/т на стандартной 100-вольтовой сети.
 *
 * Реализация — пост-обработка после родительского цикла (charge → moveEnergy →
 * manageWire): дозаряжаем буфер той же честной физикой I²R (мощность реально
 * снимается с сети через конвертерное сопротивление, которое мы опускаем ниже
 * родительского клампа), поднимаем кап до HV-номинала и пушим второй раз.
 * Приватные поля родителя не трогаем — только публичный IFEBridgeHandler и
 * protected converterWire.
 */
public class HvDeviceConnectorBlockEntity extends DeviceConnectorBlockEntity {

    /** Кратность встроенного повышающего преобразователя. */
    public static final int VOLTAGE_MULT = 10;
    /** Нижний предел конвертерного сопротивления, Ом (защита решателя цепи). */
    private static final double MIN_RESISTANCE = 1.0;

    public HvDeviceConnectorBlockEntity(BlockPos pos, BlockState state) {
        super(PowergridExtras.HV_DEVICE_CONNECTOR_BE.get(), pos, state);
    }

    @Override
    public void tick() {
        super.tick(); // родительский bridge-цикл со стоковым капом

        if (level == null || level.isClientSide) return;
        if (proxyBehaviour == null || converterWire == null) return;
        IFEBridgeHandler handler = proxyBehaviour.getBridgeBehaviour();
        if (handler == null) return;

        ElectricWire wire = converterWire;
        double v = Math.abs(wire.potentialDifference());
        if (v <= 0.0) return;

        long hvCap = (long) (v * IFEBridgeHandler.voltToFE()) * VOLTAGE_MULT;

        // Дозарядка сверх стокового капа: та же I²R-физика, энергия честно
        // рассеивается на конвертере (нагрузка на сеть настоящая).
        double i = wire.current();
        long gain = (long) Math.floor(i * i * wire.getResistance() * IFEBridgeHandler.wattToFE());
        long amount = handler.getAmount();
        long charged = Math.min(amount + gain, hvCap);
        if (charged != amount) {
            handler.setAmount(charged);
            handler.setChanged();
        }

        // Второй пуш за тик — буфер HV-номинала уходит потребителю.
        handler.moveEnergy();

        // Подстройка сопротивления под недобор HV-капа (родительский manageWire
        // целится в стоковый кап и задирает R — перекрываем своим расчётом).
        long missing = hvCap - handler.getAmount();
        if (missing <= 0) {
            wire.setResistance(1000.0);
        } else {
            double targetWatts = missing / (double) IFEBridgeHandler.wattToFE();
            double r = v * v / targetWatts;
            wire.setResistance(Math.max(MIN_RESISTANCE, Math.min(r, 1000.0)));
        }
    }
}
