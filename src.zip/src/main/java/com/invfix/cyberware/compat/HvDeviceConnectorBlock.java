package com.invfix.cyberware.compat;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import org.patryk3211.powergrid.electricity.deviceconnector.DeviceConnectorBlock;

/**
 * HV-адаптер: блочная часть целиком родительская (терминалы, формы, canSurvive
 * с проверкой FE-соседа, приём проводов/шнуров) — свой только BE-тип.
 */
public class HvDeviceConnectorBlock extends DeviceConnectorBlock {

    public HvDeviceConnectorBlock(BlockBehaviour.Properties settings) {
        super(settings);
    }

    // getBlockEntityClass НЕ переопределяем: родительский DeviceConnectorBlockEntity.class
    // корректен для нашего сабкласса, а дженерики IBE инвариантны.
    @Override
    public BlockEntityType<? extends org.patryk3211.powergrid.electricity.deviceconnector.DeviceConnectorBlockEntity> getBlockEntityType() {
        return PowergridExtras.HV_DEVICE_CONNECTOR_BE.get();
    }
}
