package com.invfix.cyberware.compat;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import org.patryk3211.powergrid.electricity.wire.WireItem;

/**
 * Высоковольтный провод — расширение системы проводов powergrid.
 *
 * Провод powergrid — это {@link WireItem}, а его характеристики (макс. ток,
 * сопротивление, длина и т.д.) грузятся ДАННЫМИ из реестра-датапака
 * {@code powergrid:wire_types} по id предмета. Поэтому здесь регистрируется только
 * сам предмет, а спека лежит в
 * {@code data/sable_compat/powergrid/wire_types/hv_wire.json} (ток ×20 к медному,
 * сопротивление ниже — несёт мощность для литографа без перегрева/сгорания).
 *
 * ВАЖНО: класс ссылается на powergrid, поэтому регистрируется ТОЛЬКО когда powergrid
 * загружен — {@code InvincibleFix} вызывает {@link #register(IEventBus)} под проверкой
 * {@code ModList.isLoaded("powergrid")}, иначе класс не подгружается.
 */
public final class PowergridExtras {

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("sable_compat");

    public static final DeferredItem<WireItem> HV_WIRE =
            ITEMS.register("hv_wire", () -> new WireItem(new Item.Properties()));

    /**
     * Сверхпроводниковый провод — топ системы проводов powergrid. Спека (около-нулевое
     * сопротивление, огромный ток) — данными в
     * {@code data/sable_compat/powergrid/wire_types/superconducting_wire.json}.
     * Материал — сверхпроводящий ультраний (тир-2 супертех).
     */
    public static final DeferredItem<WireItem> SUPERCONDUCTING_WIRE =
            ITEMS.register("superconducting_wire", () -> new WireItem(new Item.Properties()));

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks("sable_compat");
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, "sable_compat");

    /**
     * Высоковольтный адаптер устройств — FE-мост со встроенным повышающим
     * преобразователем ×10 (см. {@link HvDeviceConnectorBlockEntity}): до 10-кратного
     * пропуска стокового device_connector на той же сети (100 В → до 2000 FE/т).
     */
    public static final DeferredBlock<HvDeviceConnectorBlock> HV_DEVICE_CONNECTOR =
            BLOCKS.registerBlock("hv_device_connector",
                    HvDeviceConnectorBlock::new,
                    BlockBehaviour.Properties.of().mapColor(MapColor.TERRACOTTA_RED)
                            .strength(2.0F, 4.0F).sound(SoundType.COPPER).noOcclusion());

    public static final DeferredItem<BlockItem> HV_DEVICE_CONNECTOR_ITEM =
            ITEMS.registerSimpleBlockItem("hv_device_connector", HV_DEVICE_CONNECTOR);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<HvDeviceConnectorBlockEntity>> HV_DEVICE_CONNECTOR_BE =
            BLOCK_ENTITIES.register("hv_device_connector",
                    () -> BlockEntityType.Builder.of(HvDeviceConnectorBlockEntity::new, HV_DEVICE_CONNECTOR.get()).build(null));

    private PowergridExtras() {}

    public static void register(IEventBus modEventBus) {
        ITEMS.register(modEventBus);
        BLOCKS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
        modEventBus.addListener(PowergridExtras::onBuildCreativeTabs);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept(HV_WIRE);
            event.accept(SUPERCONDUCTING_WIRE);
            event.accept(HV_DEVICE_CONNECTOR_ITEM);
        }
    }
}
