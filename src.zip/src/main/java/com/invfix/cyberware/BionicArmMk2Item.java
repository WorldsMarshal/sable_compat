package com.invfix.cyberware;

import com.perigrine3.createcybernetics.api.CyberwareSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;

/**
 * Гейт Gen2 — ФУНКЦИОНАЛЬНЫЙ (не установочный): API createcybernetics проверяет
 * requiresCyberware только внутри слота установки, поэтому кросс-слотовое условие
 * «Gen2 в мозге» на установке невыполнимо. Имплант ставится свободно, но бонусы
 * активны лишь пока Gen2 пингует мост; без него модификаторы снимаются тиком.
 *
 * Composite Bionic Mk2 — рука. ×6 от Mk1 по всем характеристикам; +10 капы HP;
 * отдаёт энергию в систему cyberware (контроллер сам собирает через
 * getEnergyGeneratedPerTick и раздаёт имплантам); общий стак-эффект +2 сытости/60т.
 * Установка требует Наномашины Gen2 в мозге.
 */
public class BionicArmMk2Item extends BionicArmItem {

    // ×6 от значений Mk1 (см. BionicArmItem.onInstalled) — правится константами.
    static final double DAMAGE = 21.5D * 6;        // 129.0
    static final double BREAK_SPEED = 2.35D * 6;   // 14.1

    private final String sideKey;

    public BionicArmMk2Item(Properties props, int humanityCost, CyberwareSlot side) {
        super(props, humanityCost, side);
        this.sideKey = side == CyberwareSlot.LARM ? "left" : "right";
    }

    @Override
    public int getEnergyGeneratedPerTick(LivingEntity entity, ItemStack installedStack, CyberwareSlot slot) {
        return CompositeMk2.gen2Active(entity) ? CompositeMk2.ENERGY_PER_TICK : 0;
    }

    @Override
    public void onInstalled(LivingEntity entity) {
        applyModifier(entity, Attributes.ATTACK_DAMAGE, "mk2_arm_damage_" + sideKey, DAMAGE);
        applyModifier(entity, Attributes.BLOCK_BREAK_SPEED, "mk2_arm_break_" + sideKey, BREAK_SPEED);
        applyModifier(entity, Attributes.MAX_HEALTH, "mk2_arm_health_" + sideKey, CompositeMk2.HEALTH_BONUS);
    }

    @Override
    public void onRemoved(LivingEntity entity) {
        removeModifier(entity, Attributes.ATTACK_DAMAGE, "mk2_arm_damage_" + sideKey);
        removeModifier(entity, Attributes.BLOCK_BREAK_SPEED, "mk2_arm_break_" + sideKey);
        removeModifier(entity, Attributes.MAX_HEALTH, "mk2_arm_health_" + sideKey);
    }

    @Override
    public void onTick(LivingEntity entity) {
        // Синхронизация бонусов с гейтом Gen2 (раз в 20 тиков, только на переходах).
        if (!entity.level().isClientSide && entity.level().getGameTime() % 20 == 0) {
            boolean active = CompositeMk2.gen2Active(entity);
            boolean applied = entity.getAttribute(Attributes.ATTACK_DAMAGE) != null
                    && entity.getAttribute(Attributes.ATTACK_DAMAGE).getModifier(
                        net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(
                            "sable_compat", "mk2_arm_damage_" + sideKey)) != null;
            if (active && !applied) {
                onInstalled(entity);
                CompositeMk2.refreshCaps(entity);
            } else if (!active && applied) {
                onRemoved(entity);
                CompositeMk2.notifySuspended(entity);
                CompositeMk2.refreshCaps(entity);
            }
        }
        if (CompositeMk2.gen2Active(entity)) CompositeMk2.sharedFeedTick(entity);
    }
}
