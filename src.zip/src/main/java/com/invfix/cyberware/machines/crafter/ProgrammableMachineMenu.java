package com.invfix.cyberware.machines.crafter;

import com.invfix.cyberware.machines.MachineRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.neoforge.items.ItemStackHandler;
import net.neoforged.neoforge.items.SlotItemHandler;

/**
 * Меню программируемого станка: 5×5 шаблон-призрак + буфер + выход + инвентарь игрока.
 * Кнопки: 0 — переключить авто/ручной, 1 — запросить один крафт (ручной),
 * 2 — следующий рецепт, если шаблону подходит несколько.
 */
public class ProgrammableMachineMenu extends AbstractContainerMenu {

    // геометрия (совпадает с фоном GUI)
    public static final int TX = 8,  TY = 18;   // шаблон 5×5
    public static final int OX = 148, OY = 28;  // выход
    public static final int BX = 8,  BY = 116;  // буфер 9×N
    public static final int PX = 8;
    public static final int INV_GAP = 12;       // зазор между буфером и инвентарём игрока

    private final ProgrammableMachineBlockEntity be;
    private final ContainerData data;
    private final int bufferSize;
    private final int gridWidth;
    private final int bufferRows;
    private final int pInvY, pHotY, imageHeight;

    public final int templateStart, bufferStart, outputIndex, invStart, invEnd;

    // серверный конструктор
    public ProgrammableMachineMenu(int id, Inventory inv, ProgrammableMachineBlockEntity be) {
        super(MachineRegistry.PROGRAMMABLE_MACHINE_MENU.get(), id);
        this.be = be;
        this.data = be.getData();
        this.bufferSize = be.getBuffer().getSlots();
        this.gridWidth = be.gridWidth();
        this.bufferRows = Math.max(1, bufferSize / 9);
        this.pInvY = BY + bufferRows * 18 + INV_GAP;
        this.pHotY = pInvY + 58;
        this.imageHeight = pHotY + 18 + 6;

        ItemStackHandler template = be.getTemplate();
        ItemStackHandler buffer = be.getBuffer();
        ItemStackHandler output = be.getOutput();

        // шаблон-призрак gridWidth×gridWidth
        for (int r = 0; r < gridWidth; r++)
            for (int c = 0; c < gridWidth; c++)
                this.addSlot(new GhostSlot(template, r * gridWidth + c, TX + c * 18, TY + r * 18));

        // буфер 9×(bufferSize/9)
        for (int r = 0; r < bufferRows; r++)
            for (int c = 0; c < 9; c++) {
                int i = r * 9 + c;
                if (i < bufferSize) this.addSlot(new SlotItemHandler(buffer, i, BX + c * 18, BY + r * 18));
            }

        // выход (только машина кладёт)
        this.addSlot(new SlotItemHandler(output, 0, OX, OY) {
            @Override public boolean mayPlace(ItemStack stack) { return false; }
        });

        templateStart = 0;
        bufferStart = gridWidth * gridWidth;
        outputIndex = bufferStart + bufferSize;
        invStart = outputIndex + 1;
        invEnd = invStart + 36;

        addPlayerInventory(inv);
        addDataSlots(this.data);
    }

    // клиентский конструктор
    public ProgrammableMachineMenu(int id, Inventory inv, RegistryFriendlyByteBuf buf) {
        this(id, inv, resolve(buf.readBlockPos()));
    }

    private static ProgrammableMachineBlockEntity resolve(BlockPos pos) {
        BlockEntity be = Minecraft.getInstance().level.getBlockEntity(pos);
        return be instanceof ProgrammableMachineBlockEntity c ? c : null;
    }

    public int getImageHeight() { return imageHeight; }
    public int getInvLabelY() { return pInvY - 12; }
    public int getBufferSize() { return bufferSize; }
    public int getGridWidth() { return gridWidth; }

    private void addPlayerInventory(Inventory inv) {
        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 9; c++)
                this.addSlot(new Slot(inv, c + r * 9 + 9, PX + c * 18, pInvY + r * 18));
        for (int c = 0; c < 9; c++)
            this.addSlot(new Slot(inv, c, PX + c * 18, pHotY));
    }

    // --- синхронизированные значения ---
    public int getProgress() { return data.get(0); }
    public int getMaxProgress() { return data.get(1); }
    public int getEnergy() { return data.get(2); }
    public int getMaxEnergy() { return data.get(3); }
    public boolean isAuto() { return data.get(4) != 0; }
    public int getStatus() { return data.get(5); }
    public int getFluidAmount() { return data.get(6); }
    /** Выбранный рецепт (с нуля) и сколько их подходит шаблону. */
    public int getRecipeIndex() { return data.get(7); }
    public int getRecipeCount() { return data.get(8); }

    /** Результат выбранного рецепта (только предмет, без количества); EMPTY — рецепта нет. */
    public ItemStack getRecipePreview() {
        int id = (data.get(9) & 0xFFFF) | ((data.get(10) & 0xFFFF) << 16);
        if (id == 0) return ItemStack.EMPTY;
        net.minecraft.world.item.Item item = net.minecraft.core.registries.BuiltInRegistries.ITEM.byId(id);
        return item == null ? ItemStack.EMPTY : new ItemStack(item);
    }
    public int getFluidCapacity() { return be != null ? be.fluidCapacity() : 0; }

    /** Реальный стек жидкости (тип+объём) с клиентского BE — для рендера текстуры в GUI. */
    public net.neoforged.neoforge.fluids.FluidStack getFluidStack() {
        if (be == null || be.getFluidTank() == null) return net.neoforged.neoforge.fluids.FluidStack.EMPTY;
        return be.getFluidTank().getFluid();
    }

    /** Ghost-слот шаблона: хранит образец (счёт 1), не отдаёт/не принимает реальные предметы. */
    private static class GhostSlot extends SlotItemHandler {
        GhostSlot(ItemStackHandler handler, int index, int x, int y) { super(handler, index, x, y); }
        @Override public boolean mayPlace(ItemStack stack) { return false; }
        @Override public boolean mayPickup(Player player) { return false; }
        @Override public int getMaxStackSize() { return 1; }
    }

    @Override
    public void clicked(int slotId, int button, ClickType type, Player player) {
        if (slotId >= 0 && slotId < this.slots.size() && this.slots.get(slotId) instanceof GhostSlot ghost) {
            if (type == ClickType.PICKUP || type == ClickType.PICKUP_ALL || type == ClickType.QUICK_MOVE) {
                ItemStack carried = getCarried();
                if (carried.isEmpty()) {
                    ghost.set(ItemStack.EMPTY);
                } else {
                    ItemStack g = carried.copy();
                    g.setCount(1);
                    ghost.set(g);
                }
            }
            return; // не трогаем несомое, не двигаем реальные предметы
        }
        super.clicked(slotId, button, type, player);
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (be == null) return false;
        if (id == 0) { be.setAuto(!be.isAuto()); return true; }
        if (id == 1) { be.armManual(); return true; }
        if (id == 2) { be.cycleRecipe(); return true; }
        return false;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            if (index < bufferStart) {
                return ItemStack.EMPTY; // шаблон-призрак не перемещается shift-кликом
            } else if (index == outputIndex || (index >= bufferStart && index < outputIndex)) {
                // из буфера/выхода → в инвентарь
                if (!this.moveItemStackTo(stack, invStart, invEnd, true)) return ItemStack.EMPTY;
            } else {
                // из инвентаря → в буфер
                if (!this.moveItemStackTo(stack, bufferStart, outputIndex, false)) return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) slot.set(ItemStack.EMPTY);
            else slot.setChanged();
            if (stack.getCount() == result.getCount()) return ItemStack.EMPTY;
            slot.onTake(player, stack);
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        return be != null && !be.isRemoved()
                && player.distanceToSqr(be.getBlockPos().getX() + 0.5,
                be.getBlockPos().getY() + 0.5, be.getBlockPos().getZ() + 0.5) <= 64.0;
    }
}
