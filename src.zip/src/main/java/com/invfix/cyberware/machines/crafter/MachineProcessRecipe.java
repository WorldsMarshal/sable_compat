package com.invfix.cyberware.machines.crafter;

import com.invfix.cyberware.machines.SableRecipes;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.ShapedRecipe;
import net.minecraft.world.item.crafting.ShapedRecipePattern;
import net.neoforged.neoforge.fluids.FluidStack;

import java.util.Optional;
import java.util.function.Supplier;

/**
 * Shaped-рецепт, эксклюзивный для конкретной машины: свой {@link RecipeType}
 * (kind = HYPERBARIC у гипербарической печи), поэтому
 * не виден ни верстаку, ни мех.сборщику, ни станкам E2/E3.
 *
 * Опционально требует жидкость из внутреннего танка машины (3000 mB):
 * {@code "fluid": "sable_compat:cryo_flux", "fluid_amount": 1000}. Сетка матчится
 * shaped-логикой, жидкость проверяет и списывает сама машина.
 *
 * JSON — обычный shaped, но {@code "type":"sable_compat:hyperbaric"} —
 * {@code "sable_compat:hyperbaric"}; жидкостные поля опциональны.
 */
public class MachineProcessRecipe extends ShapedRecipe {

    public enum Kind { HYPERBARIC }

    private final Kind kind;
    private final Optional<ResourceLocation> fluidId;
    private final int fluidAmount;

    public MachineProcessRecipe(String group, CraftingBookCategory category,
                                ShapedRecipePattern pattern, ItemStack result, Kind kind,
                                Optional<ResourceLocation> fluidId, int fluidAmount) {
        super(group, category, pattern, result);
        this.kind = kind;
        this.fluidId = fluidId;
        this.fluidAmount = fluidAmount;
    }

    private static MachineProcessRecipe fromShaped(ShapedRecipe r, Kind kind,
                                                   Optional<ResourceLocation> fluidId, int fluidAmount) {
        ShapedRecipePattern pattern = new ShapedRecipePattern(
                r.getWidth(), r.getHeight(), r.getIngredients(), Optional.empty());
        return new MachineProcessRecipe(r.getGroup(), r.category(), pattern, r.getResultItem(null),
                kind, fluidId, fluidAmount);
    }

    public Optional<ResourceLocation> fluidId() { return fluidId; }
    public int fluidAmount() { return fluidAmount; }

    /** Требуемая жидкость как FluidStack (EMPTY, если рецепт безжидкостный). */
    public FluidStack requiredFluid() {
        if (fluidId.isEmpty() || fluidAmount <= 0) return FluidStack.EMPTY;
        var fluid = BuiltInRegistries.FLUID.get(fluidId.get());
        return new FluidStack(fluid, fluidAmount);
    }

    @Override
    public RecipeType<?> getType() {
        return SableRecipes.HYPERBARIC_TYPE.get();
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return SableRecipes.HYPERBARIC_SERIALIZER.get();
    }

    @Override
    public boolean isSpecial() { return true; }

    /** Сериализатор с фиксированным kind — по одному на тип. */
    public static class Serializer implements RecipeSerializer<MachineProcessRecipe> {
        private final MapCodec<MachineProcessRecipe> codec;
        private final StreamCodec<RegistryFriendlyByteBuf, MachineProcessRecipe> streamCodec;

        public Serializer(Kind kind) {
            this.codec = RecordCodecBuilder.mapCodec(inst -> inst.group(
                    RecipeSerializer.SHAPED_RECIPE.codec().forGetter(r -> r),
                    ResourceLocation.CODEC.optionalFieldOf("fluid").forGetter(MachineProcessRecipe::fluidId),
                    Codec.INT.optionalFieldOf("fluid_amount", 0).forGetter(MachineProcessRecipe::fluidAmount)
            ).apply(inst, (shaped, fid, famt) -> fromShaped(shaped, kind, fid, famt)));

            this.streamCodec = StreamCodec.composite(
                    ShapedRecipe.Serializer.STREAM_CODEC, r -> r,
                    ByteBufCodecs.optional(ResourceLocation.STREAM_CODEC), MachineProcessRecipe::fluidId,
                    ByteBufCodecs.VAR_INT, MachineProcessRecipe::fluidAmount,
                    (shaped, fid, famt) -> fromShaped(shaped, kind, fid, famt));
        }

        public static Supplier<Serializer> of(Kind kind) { return () -> new Serializer(kind); }

        @Override public MapCodec<MachineProcessRecipe> codec() { return codec; }
        @Override public StreamCodec<RegistryFriendlyByteBuf, MachineProcessRecipe> streamCodec() { return streamCodec; }
    }
}
