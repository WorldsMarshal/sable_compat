package com.invfix.cyberware.machines.crafter;

import com.invfix.cyberware.machines.MachineRegistry;
import com.invfix.cyberware.machines.SableRecipes;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Гипербарическая печь («печь сверхвысокого давления») — пост-супернагревный этап:
 * процессы, которым уже мало супернагрева Create (синтез нестабильного ультрания,
 * HPHT-алмаз из угольных блоков). Сетка 3×3, обвязка — форма из Create-чертежа
 * (surpress.nbt, ~11×12×11). Резолвит ТОЛЬКО рецепты типа {@code sable_compat:hyperbaric}.
 */
public class HyperbaricFurnaceBlockEntity extends ProgrammableMachineBlockEntity {

    public static final int CRAFT_TIME = 600;
    public static final int BUFFER = 36;
    public static final int ENERGY_PER_TICK = 1000;

    public HyperbaricFurnaceBlockEntity(BlockPos pos, BlockState state) {
        super(MachineRegistry.HYPERBARIC_FURNACE_BE.get(), pos, state);
    }

    @Override public int craftTime() { return CRAFT_TIME; }
    @Override public int bufferSize() { return BUFFER; }
    @Override public int energyPerTick() { return ENERGY_PER_TICK; }
    @Override public int tierLevel() { return 2; }
    @Override public int gridWidth() { return 3; }
    @Override public int fluidCapacity() { return 3000; }

    @Override
    protected NbtMultiblock.Result validateStructureImpl() {
        return NbtMultiblock.validate(getLevel(), getBlockPos(),
                MachineStructures.HYPERBARIC_PALETTE, MachineStructures.HYPERBARIC_CELLS);
    }

    /** Только гипербарические рецепты. */
    @Override
    protected void resolveRecipe(CraftingInput ci) {
        var found = getLevel().getRecipeManager()
                .getRecipeFor(SableRecipes.HYPERBARIC_TYPE.get(), ci, getLevel());
        if (found.isPresent()) {
            var r = found.get().value();
            cachedInput = ci;
            cachedRecipe = r;
            cachedResult = r.assemble(ci, getLevel().registryAccess());
            requiredFluid = r.requiredFluid();
        }
    }

    /** Звук — рёв пламени доменного пода + тяжёлые удары пресса (наковальня, низкий питч). */
    @Override
    public void playWorkSound(Level level, BlockPos pos, long gameTime) {
        if (gameTime % 20 == 0) {
            level.playSound(null, pos, SoundEvents.BLASTFURNACE_FIRE_CRACKLE, SoundSource.BLOCKS, 0.6F, 0.7F);
        }
        if (gameTime % 100 == 50) {
            level.playSound(null, pos, SoundEvents.ANVIL_LAND, SoundSource.BLOCKS, 0.35F, 0.5F);
        }
    }
}
