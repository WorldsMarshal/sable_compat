package com.invfix.cyberware.machines;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

/**
 * Блок Create-шлюза машин. Держит {@link MachineItemPortBlockEntity}: буфер, в
 * который пушат воронки Create, и тик-логику перекладки в ближайшую машину.
 */
public class MachineItemPortBlock extends Block implements EntityBlock {

    public MachineItemPortBlock(Properties props) {
        super(props);
    }

    @Override
    public @Nullable BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new MachineItemPortBlockEntity(pos, state);
    }

    @Override
    public @Nullable <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) return null;
        if (type != MachineRegistry.MACHINE_ITEM_PORT_BE.get()) return null;
        return (lvl, pos, st, be) -> MachineItemPortBlockEntity.serverTick(lvl, pos, st, (MachineItemPortBlockEntity) be);
    }
}
