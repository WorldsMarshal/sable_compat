package com.invfix.cyberware.machines.crafter;

import com.invfix.cyberware.machines.SableRecipes;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.ShapedRecipe;
import net.minecraft.world.item.crafting.ShapedRecipePattern;

import java.util.Optional;

/**
 * Тир-эксклюзивный рецепт станков. По сути shaped-рецепт с полем {@code tier}, но
 * СВОЕГО {@link RecipeType} — значит НЕ виден верстаку и мех.сборщику (они опрашивают
 * только {@code minecraft:crafting} / {@code create:mechanical_crafting}). Резолвится
 * только программируемым станком, если {@code tier <= уровень станка}. Так надёжные
 * рецепты (микропроцессор на высокоточном, детали Райдена на сверхвысокоточном и т.д.)
 * не «утекают» на верстак/мех.сборщик.
 *
 * <p>JSON — как у обычного shaped-рецепта, но {@code "type":"sable_compat:precision"}
 * и опциональное {@code "tier": N} (по умолчанию 1).
 */
public class PrecisionRecipe extends ShapedRecipe {

    private final int tier;
    private final float chance;

    public PrecisionRecipe(String group, CraftingBookCategory category, ShapedRecipePattern pattern, ItemStack result, int tier, float chance) {
        super(group, category, pattern, result);
        this.tier = tier;
        this.chance = chance;
    }

    public int tier() { return tier; }
    /** Шанс успеха на станке МИНИМАЛЬНОГО подходящего тира; на более высоком тире — 100%. */
    public float chance() { return chance; }

    private static PrecisionRecipe fromShaped(ShapedRecipe r, int tier, float chance) {
        ShapedRecipePattern pattern = new ShapedRecipePattern(
                r.getWidth(), r.getHeight(), r.getIngredients(), Optional.empty());
        return new PrecisionRecipe(r.getGroup(), r.category(), pattern, r.getResultItem(null), tier, chance);
    }

    @Override
    public RecipeType<?> getType() { return SableRecipes.PRECISION_TYPE.get(); }

    @Override
    public RecipeSerializer<?> getSerializer() { return SableRecipes.PRECISION_SERIALIZER.get(); }

    @Override
    public boolean isSpecial() { return true; } // не показываем в книге рецептов

    public static class Serializer implements RecipeSerializer<PrecisionRecipe> {
        public static final MapCodec<PrecisionRecipe> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
                RecipeSerializer.SHAPED_RECIPE.codec().forGetter(r -> r),
                Codec.INT.optionalFieldOf("tier", 1).forGetter(PrecisionRecipe::tier),
                Codec.FLOAT.optionalFieldOf("chance", 1.0F).forGetter(PrecisionRecipe::chance)
        ).apply(inst, PrecisionRecipe::fromShaped));

        public static final StreamCodec<RegistryFriendlyByteBuf, PrecisionRecipe> STREAM_CODEC =
                StreamCodec.composite(
                        ShapedRecipe.Serializer.STREAM_CODEC, r -> r,
                        ByteBufCodecs.VAR_INT, PrecisionRecipe::tier,
                        ByteBufCodecs.FLOAT, PrecisionRecipe::chance,
                        PrecisionRecipe::fromShaped);

        @Override public MapCodec<PrecisionRecipe> codec() { return CODEC; }
        @Override public StreamCodec<RegistryFriendlyByteBuf, PrecisionRecipe> streamCodec() { return STREAM_CODEC; }
    }
}
