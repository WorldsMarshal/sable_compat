package com.invfix.cyberware.machines;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

/** Блок жидкостного шлюза машин — трубы Create ↔ внутренний танк машины. */
public class MachineFluidPortBlock extends Block implements EntityBlock {

    public MachineFluidPortBlock(Properties props) {
        super(props);
    }

    @Override
    public @Nullable BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new MachineFluidPortBlockEntity(pos, state);
    }

    @Override
    public @Nullable <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) return null;
        if (type != MachineRegistry.MACHINE_FLUID_PORT_BE.get()) return null;
        return (lvl, pos, st, be) -> MachineFluidPortBlockEntity.serverTick(lvl, pos, st, (MachineFluidPortBlockEntity) be);
    }
}
