package com.invfix.cyberware.machines.crafter;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.material.Fluid;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.neoforge.fluids.FluidStack;

import java.util.List;

/**
 * Экран программируемой машины. У станков с жидкостным буфером (химсинтезатор,
 * гипербарическая печь — {@code fluidCapacity() > 0}) энергия и жидкость —
 * ДВА РАЗДЕЛЬНЫХ столбца: энергия остаётся плоским янтарным баром (как было),
 * жидкость — отдельный столбец правее, залитый НАСТОЯЩЕЙ текстурой той жидкости,
 * что сейчас в танке (still-текстура + тинт, как в мире), чтобы был понятен
 * состав с первого взгляда, а не только цифры.
 */
public class ProgrammableMachineScreen extends AbstractContainerScreen<ProgrammableMachineMenu> {

    private static final ResourceLocation TEXTURE_BASE =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/gui/machine/programmable_machine.png");
    private static final ResourceLocation TEXTURE_ULTRA =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/gui/machine/programmable_machine_ultra.png");
    private static final ResourceLocation TEXTURE_SMALL =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/gui/machine/programmable_machine_small.png");

    private static final int ARROW_X = 120, ARROW_Y = 31, ARROW_W = 22, ARROW_H = 6;
    // Энергия — правый столбец (как и раньше). Жидкость — отдельный столбец левее неё,
    // с зазором, чтобы визуально не путались.
    private static final int ENERGY_X = 160, BAR_Y = 18, BAR_W = 8, BAR_H = 90;
    private static final int FLUID_X = 104;

    private final ResourceLocation texture;
    private final boolean hasFluid;
    private Button modeButton;

    public ProgrammableMachineScreen(ProgrammableMachineMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = menu.getImageHeight();
        this.inventoryLabelY = menu.getInvLabelY();
        this.hasFluid = menu.getFluidCapacity() > 0;
        this.texture = menu.getGridWidth() == 3 ? TEXTURE_SMALL
                : (menu.getBufferSize() > 36 ? TEXTURE_ULTRA : TEXTURE_BASE);
    }

    @Override
    protected void init() {
        super.init();
        modeButton = Button.builder(modeLabel(), b -> sendButton(0))
                .bounds(this.leftPos + 100, this.topPos + 50, 56, 16).build();
        this.addRenderableWidget(modeButton);
        this.addRenderableWidget(Button.builder(Component.translatable("gui.sable_compat.machine.craft"), b -> sendButton(1))
                .bounds(this.leftPos + 100, this.topPos + 70, 56, 16).build());
    }

    private Component modeLabel() {
        return Component.translatable(this.menu.isAuto()
                ? "gui.sable_compat.machine.mode_auto" : "gui.sable_compat.machine.mode_manual");
    }

    private void sendButton(int id) {
        if (this.minecraft != null && this.minecraft.gameMode != null)
            this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, id);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = this.leftPos, y = this.topPos;
        g.blit(texture, x, y, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);

        int maxP = this.menu.getMaxProgress();
        if (maxP > 0 && this.menu.getProgress() > 0) {
            int w = (int) (ARROW_W * (this.menu.getProgress() / (float) maxP));
            g.fill(x + ARROW_X, y + ARROW_Y, x + ARROW_X + w, y + ARROW_Y + ARROW_H, 0xFF49C25A);
        }

        // Столбец энергии — плоская заливка, как было.
        int maxE = this.menu.getMaxEnergy();
        if (maxE > 0) {
            int h = (int) (BAR_H * (this.menu.getEnergy() / (float) maxE));
            g.fill(x + ENERGY_X, y + BAR_Y + (BAR_H - h), x + ENERGY_X + BAR_W, y + BAR_Y + BAR_H, 0xFFE0B000);
        }

        // Столбец жидкости — отдельно, залит текстурой самой жидкости.
        if (hasFluid) {
            renderFluidColumn(g, x + FLUID_X, y + BAR_Y);
        }
    }

    /**
     * Заливает столбец FLUID_X цветом текущей жидкости в танке, снизу вверх.
     *
     * Изначально пытался тайлить настоящую still-текстуру жидкости через
     * TextureAtlasSprite, но в этой версии GuiGraphics нет ни
     * {@code blit(атлас, x, y, w, h, TextureAtlasSprite)}, ни
     * {@code blitSprite(TextureAtlasSprite, ...)} (только
     * {@code blitSprite(ResourceLocation, ...)}, а это другой атлас — GUI-спрайты,
     * не блоки/жидкости) — оба варианта не скомпилировались. Гадать сигнатуру
     * дальше вслепую рискованно, поэтому заливаю ТОНОМ жидкости
     * ({@code IClientFluidTypeExtensions.getTintColor}) — тот же приём, что уже
     * работает для энергии, разные жидкости всё ещё узнаются по цвету.
     */
    private void renderFluidColumn(GuiGraphics g, int barX, int barY) {
        FluidStack stack = this.menu.getFluidStack();
        int capacity = this.menu.getFluidCapacity();
        if (stack.isEmpty() || capacity <= 0) return;

        Fluid fluid = stack.getFluid();
        IClientFluidTypeExtensions ext = IClientFluidTypeExtensions.of(fluid);
        int tint = ext.getTintColor(stack);
        int a = (tint >> 24) & 0xFF;
        if (a == 0) a = 0xFF; // многие жидкости не пишут альфу в тинт
        int argb = (a << 24) | (tint & 0xFFFFFF);

        int filled = (int) (BAR_H * (this.menu.getFluidAmount() / (float) capacity));
        if (filled <= 0) return;

        g.fill(barX, barY + (BAR_H - filled), barX + BAR_W, barY + BAR_H, argb);
    }


    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g, mouseX, mouseY, partialTick);
        if (modeButton != null) modeButton.setMessage(modeLabel());
        super.render(g, mouseX, mouseY, partialTick);

        int x = this.leftPos, y = this.topPos;
        // подсказка энергии (отдельно от жидкости)
        if (mouseX >= x + ENERGY_X && mouseX <= x + ENERGY_X + BAR_W && mouseY >= y + BAR_Y && mouseY <= y + BAR_Y + BAR_H) {
            g.renderTooltip(this.font, List.of(
                    Component.literal(this.menu.getEnergy() + " / " + this.menu.getMaxEnergy() + " FE"),
                    statusComponent()
            ), java.util.Optional.empty(), mouseX, mouseY);
        }
        // подсказка жидкости (отдельно от энергии, только если у машины есть танк)
        if (hasFluid && mouseX >= x + FLUID_X && mouseX <= x + FLUID_X + BAR_W && mouseY >= y + BAR_Y && mouseY <= y + BAR_Y + BAR_H) {
            FluidStack stack = this.menu.getFluidStack();
            Component name = stack.isEmpty()
                    ? Component.translatable("gui.sable_compat.machine.fluid_empty")
                    : stack.getHoverName();
            g.renderTooltip(this.font, List.of(
                    name,
                    Component.literal(this.menu.getFluidAmount() + " / " + this.menu.getFluidCapacity() + " mB")
            ), java.util.Optional.empty(), mouseX, mouseY);
        }
        // подсказка статуса над стрелкой
        if (mouseX >= x + ARROW_X && mouseX <= x + ARROW_X + ARROW_W && mouseY >= y + ARROW_Y - 4 && mouseY <= y + ARROW_Y + ARROW_H + 4) {
            g.renderTooltip(this.font, statusComponent(), mouseX, mouseY);
        }
        this.renderTooltip(g, mouseX, mouseY);
    }

    private Component statusComponent() {
        String key = switch (this.menu.getStatus()) {
            case ProgrammableMachineBlockEntity.ST_WORKING -> "gui.sable_compat.machine.working";
            case ProgrammableMachineBlockEntity.ST_NO_RECIPE -> "gui.sable_compat.machine.no_recipe";
            case ProgrammableMachineBlockEntity.ST_NO_POWER -> "gui.sable_compat.machine.no_power";
            case ProgrammableMachineBlockEntity.ST_NO_MATERIALS -> "gui.sable_compat.machine.no_materials";
            case ProgrammableMachineBlockEntity.ST_OUTPUT_FULL -> "gui.sable_compat.machine.output_full";
            case ProgrammableMachineBlockEntity.ST_NOT_FORMED -> "gui.sable_compat.machine.not_formed";
            default -> "gui.sable_compat.machine.idle";
        };
        return Component.translatable(key);
    }
}
