package com.invfix.cyberware.machines.crafter;

import com.invfix.cyberware.machines.MachineRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Сверхвысокоточный станок (E3). Время крафта 200 тиков, буфер 72 (2 инвентаря игрока),
 * потребление 1300 FE/тик. Тир 2 — 100% выход рецептов тира 1 и доступ к тир-2
 * эксклюзивам. Обвязка: короб Д10×Ш5×В5 из dndecor:dark_metal_plating.
 */
public class UltraPrecisionMachineBlockEntity extends ProgrammableMachineBlockEntity {

    public static final int CRAFT_TIME = 200;
    public static final int BUFFER = 72;
    public static final int ENERGY_PER_TICK = 1300;
    public static final int TIER = 2;
    public static final int LENGTH = 10;
    private static final ResourceLocation CASING =
            ResourceLocation.fromNamespaceAndPath("dndecor", "dark_metal_plating");

    public UltraPrecisionMachineBlockEntity(BlockPos pos, BlockState state) {
        super(MachineRegistry.ULTRA_PRECISION_MACHINE_BE.get(), pos, state);
    }

    @Override public int craftTime() { return CRAFT_TIME; }
    @Override public int bufferSize() { return BUFFER; }
    @Override public int energyPerTick() { return ENERGY_PER_TICK; }
    @Override public int tierLevel() { return TIER; }
    @Override public int gridWidth() { return 5; }

    @Override
    protected NbtMultiblock.Result validateStructureImpl() {
        var facing = getBlockState().getValue(ProgrammableMachineBlock.FACING);
        MachineMultiblock.Result r = MachineMultiblock.validate(
                getLevel(), getBlockPos(), facing, LENGTH, CASING, getBlockState().getBlock());
        return new NbtMultiblock.Result(r.formed(), r.powerPos(), r.ports(), java.util.List.of());
    }

    /**
     * Звук работы E3 — чистый высокотехнологичный гул: маячный резонанс + редкий
     * кристальный "пинг" аметиста (прецизионные сервоприводы, никакого скрежета).
     */
    @Override
    public void playWorkSound(Level level, BlockPos pos, long gameTime) {
        if (gameTime % 36 == 0) {
            level.playSound(null, pos, SoundEvents.BEACON_AMBIENT, SoundSource.BLOCKS, 0.5F, 1.5F);
        }
        if (gameTime % 90 == 30) {
            float pitch = 1.4F + level.getRandom().nextFloat() * 0.4F;
            level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 0.35F, pitch);
        }
    }
}
