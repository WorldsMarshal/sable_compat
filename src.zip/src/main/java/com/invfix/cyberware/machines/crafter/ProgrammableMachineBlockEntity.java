package com.invfix.cyberware.machines.crafter;

import com.invfix.cyberware.machines.IMachineItemSink;
import com.invfix.cyberware.machines.PowerInputBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.items.ItemStackHandler;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Общее ядро программируемого станка-автокрафтера (высокоточный/сверхвысокоточный).
 *
 * <p>Интерфейс — сетка-шаблон 5×5 (ghost): игрок кладёт «образец» рецепта, счёт/расход
 * не важны. Внутренний буфер (реальные предметы, заполняется игроком или Create-шлюзом
 * через {@link IMachineItemSink}). Резолв рецепта по шаблону идёт против ванильных
 * {@code crafting_shaped/shapeless} и Create {@code mechanical_crafting}. При наличии
 * материалов в буфере, энергии и места на выходе станок крафтит за фиксированное время
 * {@link #craftTime()} (ручной режим — один крафт по кнопке, авто — пока есть материалы).
 *
 * <p>Энергия берётся из соседнего {@link PowerInputBlockEntity} ({@code power_input}).
 * (Мультиблок-обвязка и анимация — следующий слой; ядро от них не зависит.)
 */
public abstract class ProgrammableMachineBlockEntity extends BlockEntity
        implements MenuProvider, IMachineItemSink {

    private static final int POWER_SCAN_INTERVAL = 20;

    // Статусы для GUI (data[5]).
    public static final int ST_IDLE = 0, ST_WORKING = 1, ST_NO_RECIPE = 2, ST_NO_POWER = 3, ST_NO_MATERIALS = 4, ST_OUTPUT_FULL = 5, ST_NOT_FORMED = 6;

    /** Шаблон-призрак gridWidth×gridWidth: только образцы (стек размера 1). */
    private final ItemStackHandler template;
    private final ItemStackHandler buffer;
    private final ItemStackHandler output = new ItemStackHandler(1) {
        @Override
        protected void onContentsChanged(int slot) { setChanged(); }
    };

    private int progress = 0;
    private boolean auto = false;       // false=ручной, true=авто
    private boolean manualArmed = false; // ручной: запросить один крафт
    private boolean recipeDirty = true;
    protected ItemStack cachedResult = ItemStack.EMPTY;
    protected float cachedChance = 1.0F;
    @Nullable protected CraftingInput cachedInput = null;
    @Nullable protected net.minecraft.world.item.crafting.Recipe<?> cachedRecipe = null;
    /** Требуемая рецептом жидкость (EMPTY — не нужна); заполняет resolveRecipe. */
    protected net.neoforged.neoforge.fluids.FluidStack requiredFluid = net.neoforged.neoforge.fluids.FluidStack.EMPTY;
    /** Жидкостный буфер (null, если fluidCapacity()==0). FluidTank сам гарантирует одну жидкость. */
    @Nullable protected final net.neoforged.neoforge.fluids.capability.templates.FluidTank fluidTank;
    @Nullable private BlockPos powerPos = null;
    private boolean formed = false;

    // [0]progress [1]maxProgress [2]energy [3]energyCap [4]mode(0/1) [5]status [6]fluid mB
    private final SimpleContainerData data = new SimpleContainerData(7);

    protected ProgrammableMachineBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
        this.template = new ItemStackHandler(gridWidth() * gridWidth()) {
            @Override
            protected void onContentsChanged(int slot) { recipeDirty = true; setChanged(); }
        };
        this.buffer = new ItemStackHandler(bufferSize()) {
            @Override
            protected void onContentsChanged(int slot) { setChanged(); }
        };
        this.fluidTank = fluidCapacity() > 0
                ? new net.neoforged.neoforge.fluids.capability.templates.FluidTank(fluidCapacity()) {
                    @Override
                    protected void onContentsChanged() {
                        setChanged();
                        // толкаем лёгкий пакет (только танк) клиентам — иначе GUI не увидит
                        // изменение жидкости до следующей перезагрузки чанка.
                        if (level != null && !level.isClientSide) {
                            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(),
                                    net.minecraft.world.level.block.Block.UPDATE_CLIENTS);
                        }
                    }
                }
                : null;
        data.set(1, craftTime());
    }

    // --- конфиг тира ---
    public abstract int craftTime();
    public abstract int bufferSize();
    public abstract int energyPerTick();
    /** Уровень тира (для будущего гейта тир-эксклюзивных рецептов). */
    public abstract int tierLevel();
    /** Ширина сетки-шаблона (5 у станков, 3 у синтезатора/печи). */
    public abstract int gridWidth();
    /** Ёмкость жидкостного буфера, mB (0 — буфера нет; 3000 у синтезатора/печи). */
    public int fluidCapacity() { return 0; }
    @Nullable public net.neoforged.neoforge.fluids.capability.templates.FluidTank getFluidTank() { return fluidTank; }
    /** Проверка обвязки конкретного тира (короб у E2/E3, NBT-форма у синтезатора/печи). */
    protected abstract NbtMultiblock.Result validateStructureImpl();
    /** Звук работы; вызывается каждый тик, пока идёт крафт — тир сам решает, когда играть. */
    public abstract void playWorkSound(Level level, BlockPos pos, long gameTime);

    /** Хук тир-ограничения. Пока разрешаем всё; позже — сверка с тиром рецепта. */
    protected boolean tierAllows(ItemStack result) { return true; }

    // --- доступ для меню ---
    public ItemStackHandler getTemplate() { return template; }
    public ItemStackHandler getBuffer() { return buffer; }
    public ItemStackHandler getOutput() { return output; }
    public ContainerData getData() { return data; }
    public boolean isAuto() { return auto; }

    public void setAuto(boolean value) { this.auto = value; data.set(4, value ? 1 : 0); setChanged(); }
    public void armManual() { this.manualArmed = true; setChanged(); }

    // --- Create-шлюз кормит буфер ---
    @Override
    public ItemStack insertToMachine(ItemStack stack, boolean simulate) {
        ItemStack remaining = stack;
        for (int i = 0; i < buffer.getSlots() && !remaining.isEmpty(); i++) {
            remaining = buffer.insertItem(i, remaining, simulate);
        }
        return remaining;
    }

    /** Для вынимания шлюзом: буфер + слот результата (как сундук). */
    @Override
    public net.neoforged.neoforge.items.IItemHandler getExtractHandler() {
        if (extractView == null) {
            extractView = new net.neoforged.neoforge.items.wrapper.CombinedInvWrapper(buffer, output);
        }
        return extractView;
    }
    private net.neoforged.neoforge.items.IItemHandler extractView;

    // --- обвязка (мультиблок) + питание ---
    public boolean isFormed() { return formed; }

    /** Проверяет обвязку и запоминает позицию power_input; привязывает шлюзы. */
    private void validateStructure() {
        if (level == null) return;
        NbtMultiblock.Result res = validateStructureImpl();
        formed = res.formed();
        powerPos = res.powerPos();
        if (formed) {
            for (BlockPos p : res.ports()) {
                if (level.getBlockEntity(p) instanceof com.invfix.cyberware.machines.MachineItemPortBlockEntity port) {
                    port.linkTo(worldPosition);
                }
            }
            for (BlockPos p : res.fluidPorts()) {
                if (level.getBlockEntity(p) instanceof com.invfix.cyberware.machines.MachineFluidPortBlockEntity port) {
                    port.linkTo(worldPosition);
                }
            }
        }
    }

    @Nullable
    private PowerInputBlockEntity power() {
        if (level == null || powerPos == null) return null;
        return level.getBlockEntity(powerPos) instanceof PowerInputBlockEntity p ? p : null;
    }

    // --- резолв рецепта по шаблону ---
    private void refreshRecipe() {
        recipeDirty = false;
        cachedResult = ItemStack.EMPTY;
        cachedChance = 1.0F;
        cachedInput = null;
        cachedRecipe = null;
        requiredFluid = net.neoforged.neoforge.fluids.FluidStack.EMPTY;
        if (level == null) return;

        int g = gridWidth();
        int minX = g, minY = g, maxX = -1, maxY = -1;
        for (int r = 0; r < g; r++) {
            for (int c = 0; c < g; c++) {
                if (!template.getStackInSlot(r * g + c).isEmpty()) {
                    if (c < minX) minX = c; if (c > maxX) maxX = c;
                    if (r < minY) minY = r; if (r > maxY) maxY = r;
                }
            }
        }
        if (maxX < 0) return; // пусто
        int w = maxX - minX + 1, h = maxY - minY + 1;
        List<ItemStack> trimmed = new ArrayList<>(w * h);
        for (int r = 0; r < h; r++)
            for (int c = 0; c < w; c++)
                trimmed.add(template.getStackInSlot((minY + r) * g + (minX + c)).copy());

        CraftingInput ci = CraftingInput.of(w, h, trimmed);
        resolveRecipe(ci);
    }

    /**
     * Резолв рецепта по обрезанному входу. Базовая реализация (станки E2/E3):
     * ваниль → Create mechanical (нативно) → precision с тиром. Специализированные
     * машины (синтезатор, гипербарическая печь) переопределяют и матчат ТОЛЬКО свой
     * тип рецептов.
     */
    protected void resolveRecipe(CraftingInput ci) {
        var vanillaHolder = level.getRecipeManager().getRecipeFor(RecipeType.CRAFTING, ci, level);
        if (vanillaHolder.isPresent()) {
            CraftingRecipe r = vanillaHolder.get().value();
            cachedInput = ci;
            cachedRecipe = r;
            cachedResult = r.assemble(ci, level.registryAccess());
            return;
        }

        // Create mechanical_crafting — резолвим НАТИВНО кодом Create. Их
        // MechanicalCraftingRecipe.matches требует именно MechanicalCraftingInput; строим его
        // через публичный API Create (GroupedItems.read(nbt) → calcStats() → MechanicalCraftingInput.of)
        // и отдаём в их find(). Так работают рецепты ЛЮБЫХ аддонов Create без ручной пересборки.
        // Create инвертирует Y в of(), поэтому раскладываем строку r на gridY = 4 - r (верх→низ).
        try {
            net.minecraft.nbt.CompoundTag gridTag = new net.minecraft.nbt.CompoundTag();
            net.minecraft.nbt.ListTag gridList = new net.minecraft.nbt.ListTag();
            int gw = gridWidth();
            for (int r = 0; r < gw; r++) {
                for (int c = 0; c < gw; c++) {
                    ItemStack s = template.getStackInSlot(r * gw + c);
                    if (s.isEmpty()) continue;
                    net.minecraft.nbt.CompoundTag e = new net.minecraft.nbt.CompoundTag();
                    e.putInt("x", c);
                    e.putInt("y", (gw - 1) - r);
                    e.put("item", s.saveOptional(level.registryAccess()));
                    gridList.add(e);
                }
            }
            gridTag.put("Grid", gridList);
            var grouped = com.simibubi.create.content.kinetics.crafter.RecipeGridHandler.GroupedItems
                    .read(gridTag, level.registryAccess());
            grouped.calcStats();
            var mci = com.simibubi.create.content.kinetics.crafter.MechanicalCraftingInput.of(grouped);
            java.util.Optional<?> found = com.simibubi.create.AllRecipeTypes.MECHANICAL_CRAFTING.find(mci, level);
            if (found.isPresent()) {
                Object recipe = ((net.minecraft.world.item.crafting.RecipeHolder<?>) found.get()).value();
                @SuppressWarnings({"rawtypes", "unchecked"})
                ItemStack out = ((net.minecraft.world.item.crafting.Recipe) recipe).assemble(mci, level.registryAccess());
                if (out != null && !out.isEmpty()) {
                    cachedInput = ci;
                    cachedRecipe = (net.minecraft.world.item.crafting.Recipe<?>) recipe;
                    cachedResult = out;
                    return;
                }
            }
        } catch (Throwable nativeFail) {
            // Фолбэк на случай смены внутреннего API Create: пересборка в ванильный ShapedRecipe
            // (матчит обычный CraftingInput; минус — без accept_mirrored).
            try {
                var mechType = com.simibubi.create.AllRecipeTypes.MECHANICAL_CRAFTING.getType();
                for (net.minecraft.world.item.crafting.RecipeHolder<?> holder : level.getRecipeManager().getRecipes()) {
                    if (holder.value().getType() != mechType) continue;
                    if (!(holder.value() instanceof net.minecraft.world.item.crafting.ShapedRecipe shaped)) continue;
                    net.minecraft.world.item.crafting.ShapedRecipe probe = new net.minecraft.world.item.crafting.ShapedRecipe(
                            shaped.getGroup(), shaped.category(),
                            new net.minecraft.world.item.crafting.ShapedRecipePattern(
                                    shaped.getWidth(), shaped.getHeight(), shaped.getIngredients(), Optional.empty()),
                            shaped.getResultItem(level.registryAccess()));
                    if (probe.matches(ci, level)) {
                        cachedInput = ci;
                        cachedRecipe = probe;
                        cachedResult = probe.assemble(ci, level.registryAccess());
                        return;
                    }
                }
            } catch (Throwable ignored) { /* Create отсутствует — остаёмся на ванили */ }
        }

        // Тир-эксклюзивные рецепты станка (sable_compat:precision) — только если тир подходит.
        var precision = level.getRecipeManager()
                .getRecipeFor(com.invfix.cyberware.machines.SableRecipes.PRECISION_TYPE.get(), ci, level);
        if (precision.isPresent() && precision.get().value().tier() <= tierLevel()) {
            var pr = precision.get().value();
            cachedInput = ci;
            cachedRecipe = pr;
            cachedResult = pr.assemble(ci, level.registryAccess());
            // на станке своего тира — заявленный шанс; на более высоком тире — 100%.
            cachedChance = tierLevel() > pr.tier() ? 1.0F : pr.chance();
        }
    }

    /** Сколько единиц предмета (по точному совпадению с образцами шаблона) требуется. */
    private List<ItemStack> requiredExamples() {
        List<ItemStack> req = new ArrayList<>();
        for (int i = 0; i < template.getSlots(); i++) {
            ItemStack s = template.getStackInSlot(i);
            if (!s.isEmpty()) req.add(s);
        }
        return req;
    }

    /** Есть ли в буфере по одному предмету на каждую заполненную ячейку шаблона. */
    private boolean bufferHasIngredients(List<ItemStack> required) {
        int[] used = new int[buffer.getSlots()];
        for (ItemStack need : required) {
            boolean found = false;
            for (int i = 0; i < buffer.getSlots(); i++) {
                ItemStack b = buffer.getStackInSlot(i);
                if (!b.isEmpty() && ItemStack.isSameItem(b, need) && b.getCount() - used[i] > 0) {
                    used[i]++; found = true; break;
                }
            }
            if (!found) return false;
        }
        return true;
    }

    /** Хватает ли в танке требуемой рецептом жидкости (тип + объём). */
    private boolean fluidSatisfied() {
        if (requiredFluid.isEmpty()) return true;
        if (fluidTank == null) return false;
        var inTank = fluidTank.getFluid();
        return !inTank.isEmpty()
                && net.neoforged.neoforge.fluids.FluidStack.isSameFluidSameComponents(inTank, requiredFluid)
                && inTank.getAmount() >= requiredFluid.getAmount();
    }

    private boolean outputAccepts(ItemStack result) {
        ItemStack out = output.getStackInSlot(0);
        if (out.isEmpty()) return true;
        return ItemStack.isSameItemSameComponents(out, result)
                && out.getCount() + result.getCount() <= out.getMaxStackSize();
    }

    private void doCraft(List<ItemStack> required, ItemStack result) {
        // списываем жидкость рецепта из танка
        if (!requiredFluid.isEmpty() && fluidTank != null) {
            fluidTank.drain(requiredFluid.copy(),
                    net.neoforged.neoforge.fluids.capability.IFluidHandler.FluidAction.EXECUTE);
        }
        // списываем по 1 на каждую заполненную ячейку
        for (ItemStack need : required) {
            for (int i = 0; i < buffer.getSlots(); i++) {
                ItemStack b = buffer.getStackInSlot(i);
                if (!b.isEmpty() && ItemStack.isSameItem(b, need)) {
                    buffer.extractItem(i, 1, false);
                    break;
                }
            }
        }
        // выдаём результат — с учётом шанса (yield). На провале материалы всё равно
        // потрачены (плата за низкий тир), результат не выпадает.
        boolean success = cachedChance >= 1.0F
                || (level != null && level.getRandom().nextFloat() < cachedChance);
        if (success) {
            ItemStack out = output.getStackInSlot(0);
            if (out.isEmpty()) output.setStackInSlot(0, result.copy());
            else out.grow(result.getCount());
        }

        // остатки рецепта (вёдра и т.п.) — в буфер, излишек выбросить
        if (cachedInput != null) {
            NonNullList<ItemStack> rem = remaindersOf(cachedInput);
            for (ItemStack r : rem) {
                if (r.isEmpty()) continue;
                ItemStack leftover = r.copy();
                for (int i = 0; i < buffer.getSlots() && !leftover.isEmpty(); i++)
                    leftover = buffer.insertItem(i, leftover, false);
                if (!leftover.isEmpty() && level != null)
                    Containers.dropItemStack(level, worldPosition.getX() + 0.5,
                            worldPosition.getY() + 1.0, worldPosition.getZ() + 0.5, leftover);
            }
        }
        setChanged();
    }

    /** Остатки (вёдра и т.п.) — от САМОГО совпавшего рецепта, любого типа. */
    @SuppressWarnings({"rawtypes", "unchecked"})
    private NonNullList<ItemStack> remaindersOf(CraftingInput ci) {
        if (cachedRecipe == null) return NonNullList.create();
        try {
            return ((net.minecraft.world.item.crafting.Recipe) cachedRecipe).getRemainingItems(ci);
        } catch (Throwable t) {
            return NonNullList.create();
        }
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, ProgrammableMachineBlockEntity be) {
        if (level.isClientSide) return;

        if ((level.getGameTime() % POWER_SCAN_INTERVAL) == 0L) be.validateStructure();
        if (be.recipeDirty) be.refreshRecipe();

        PowerInputBlockEntity power = be.power();
        int energy = power != null ? power.getStored() : 0;
        int cap = power != null ? power.getCapacity() : 0;

        int status = ST_IDLE;
        boolean progressed = false;

        ItemStack result = be.cachedResult;
        if (!be.formed) {
            status = ST_NOT_FORMED;
        } else if (result.isEmpty()) {
            status = be.hasAnyTemplate() ? ST_NO_RECIPE : ST_IDLE;
        } else if (!be.tierAllows(result)) {
            status = ST_NO_RECIPE;
        } else {
            List<ItemStack> required = be.requiredExamples();
            boolean wants = be.auto || be.manualArmed;
            if (!be.outputAccepts(result)) {
                status = ST_OUTPUT_FULL;
            } else if (!be.bufferHasIngredients(required) || !be.fluidSatisfied()) {
                status = ST_NO_MATERIALS;
            } else if (!wants) {
                status = ST_IDLE;
            } else if (power == null || energy < be.energyPerTick() || !power.consume(be.energyPerTick())) {
                status = ST_NO_POWER;
                // держим прогресс во время просадки питания
            } else {
                progressed = true;
                status = ST_WORKING;
                be.playWorkSound(level, pos, level.getGameTime());
                be.progress++;
                if (be.progress >= be.craftTime()) {
                    be.progress = 0;
                    be.doCraft(required, result);
                    if (!be.auto) be.manualArmed = false;
                }
            }
        }

        // сброс прогресса, если крафт не идёт и не пауза по питанию
        if (!progressed && status != ST_NO_POWER && be.progress != 0) {
            be.progress = 0;
            be.setChanged();
        }

        be.data.set(0, be.progress);
        be.data.set(1, be.craftTime());
        be.data.set(2, energy);
        be.data.set(3, cap);
        be.data.set(4, be.auto ? 1 : 0);
        be.data.set(5, status);
        be.data.set(6, be.fluidTank != null ? be.fluidTank.getFluidAmount() : 0);
    }

    private boolean hasAnyTemplate() {
        for (int i = 0; i < template.getSlots(); i++) if (!template.getStackInSlot(i).isEmpty()) return true;
        return false;
    }

    public void dropContents(Level level, BlockPos pos) {
        SimpleContainer c = new SimpleContainer(buffer.getSlots() + 1);
        for (int i = 0; i < buffer.getSlots(); i++) c.setItem(i, buffer.getStackInSlot(i));
        c.setItem(buffer.getSlots(), output.getStackInSlot(0));
        Containers.dropContents(level, pos, c);
        // шаблон (ghost) не выпадает
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Template", template.serializeNBT(registries));
        tag.put("Buffer", buffer.serializeNBT(registries));
        tag.put("Output", output.serializeNBT(registries));
        if (fluidTank != null) tag.put("Tank", fluidTank.writeToNBT(registries, new CompoundTag()));
        tag.putInt("Progress", progress);
        tag.putBoolean("Auto", auto);
        tag.putBoolean("Armed", manualArmed);
        if (powerPos != null) { tag.putLong("Power", powerPos.asLong()); tag.putBoolean("HasPower", true); }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (tag.contains("Template")) template.deserializeNBT(registries, tag.getCompound("Template"));
        if (tag.contains("Buffer")) buffer.deserializeNBT(registries, tag.getCompound("Buffer"));
        if (tag.contains("Output")) output.deserializeNBT(registries, tag.getCompound("Output"));
        if (fluidTank != null && tag.contains("Tank")) fluidTank.readFromNBT(registries, tag.getCompound("Tank"));
        progress = tag.getInt("Progress");
        auto = tag.getBoolean("Auto");
        manualArmed = tag.getBoolean("Armed");
        powerPos = tag.getBoolean("HasPower") ? BlockPos.of(tag.getLong("Power")) : null;
        recipeDirty = true;
        data.set(0, progress);
        data.set(1, craftTime());
        data.set(4, auto ? 1 : 0);
    }

    // --- клиентская синхронизация танка (для GUI: столбец жидкости с текстурой) ---
    // BE-данные (буфер/шаблон/прогресс) читаются клиентом через ContainerData меню,
    // но танк — прямой доступ к объекту FluidTank с клиентской стороны (для рендера
    // текстуры жидкости), поэтому синхронизируем его отдельным лёгким пакетом.
    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        CompoundTag tag = new CompoundTag();
        if (fluidTank != null) tag.put("Tank", fluidTank.writeToNBT(registries, new CompoundTag()));
        return tag;
    }

    @Override
    public void handleUpdateTag(CompoundTag tag, HolderLookup.Provider registries) {
        if (fluidTank != null && tag.contains("Tank")) fluidTank.readFromNBT(registries, tag.getCompound("Tank"));
    }

    @Override
    public net.minecraft.network.protocol.Packet<net.minecraft.network.protocol.game.ClientGamePacketListener> getUpdatePacket() {
        return net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public void onDataPacket(net.minecraft.network.Connection net,
                             net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket pkt,
                             HolderLookup.Provider registries) {
        CompoundTag tag = pkt.getTag();
        if (tag != null) handleUpdateTag(tag, registries);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable(getBlockState().getBlock().getDescriptionId());
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new ProgrammableMachineMenu(id, inv, this);
    }
}
