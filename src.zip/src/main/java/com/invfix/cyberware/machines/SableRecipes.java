package com.invfix.cyberware.machines;

import com.invfix.cyberware.machines.crafter.PrecisionRecipe;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

/** Реестр типов/сериализаторов рецептов машин (тир-эксклюзивный {@code precision}). */
public final class SableRecipes {

    public static final DeferredRegister<RecipeType<?>> RECIPE_TYPES =
            DeferredRegister.create(Registries.RECIPE_TYPE, "sable_compat");
    public static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS =
            DeferredRegister.create(Registries.RECIPE_SERIALIZER, "sable_compat");

    public static final Supplier<RecipeType<PrecisionRecipe>> PRECISION_TYPE =
            RECIPE_TYPES.register("precision", () -> new RecipeType<PrecisionRecipe>() {
                @Override public String toString() { return "sable_compat:precision"; }
            });

    public static final DeferredHolder<RecipeSerializer<?>, PrecisionRecipe.Serializer> PRECISION_SERIALIZER =
            RECIPE_SERIALIZERS.register("precision", PrecisionRecipe.Serializer::new);

    // --- Гипербарическая печь ---
    public static final Supplier<RecipeType<com.invfix.cyberware.machines.crafter.MachineProcessRecipe>> HYPERBARIC_TYPE =
            RECIPE_TYPES.register("hyperbaric", () -> new RecipeType<>() {
                @Override public String toString() { return "sable_compat:hyperbaric"; }
            });
    public static final DeferredHolder<RecipeSerializer<?>, com.invfix.cyberware.machines.crafter.MachineProcessRecipe.Serializer> HYPERBARIC_SERIALIZER =
            RECIPE_SERIALIZERS.register("hyperbaric",
                    com.invfix.cyberware.machines.crafter.MachineProcessRecipe.Serializer.of(
                            com.invfix.cyberware.machines.crafter.MachineProcessRecipe.Kind.HYPERBARIC));

    private SableRecipes() {}

    public static void register(IEventBus modEventBus) {
        RECIPE_TYPES.register(modEventBus);
        RECIPE_SERIALIZERS.register(modEventBus);
    }
}
