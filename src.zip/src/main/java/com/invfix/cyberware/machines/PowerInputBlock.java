package com.invfix.cyberware.machines;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

/**
 * Единый Энергоприёмник машин — куб с {@link PowerInputBlockEntity}.
 *
 * При смене соседей инвалидируем capability: FE-приёмник появляется/исчезает в
 * зависимости от того, стоит ли рядом {@code powergrid:device_connector}, поэтому
 * держатели кэша capability должны переспросить.
 */
public class PowerInputBlock extends Block implements EntityBlock {

    public PowerInputBlock(Properties props) {
        super(props);
    }

    @Override
    public @Nullable BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PowerInputBlockEntity(pos, state);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighborBlock,
                                   BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighborBlock, neighborPos, movedByPiston);
        if (!level.isClientSide) level.invalidateCapabilities(pos);
    }
}
