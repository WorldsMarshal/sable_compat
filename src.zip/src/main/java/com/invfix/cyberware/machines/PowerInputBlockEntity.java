package com.invfix.cyberware.machines;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.energy.EnergyStorage;

/**
 * Единый Энергоприёмник машин (литограф, высокоточный и сверхвысокоточный станки).
 *
 * Это Forge-Energy приёмник с буфером. Контроллер машины находит его в своей
 * структуре и стабильно снимает энергию по чуть-чуть каждый тик; заряжается он
 * из сети powergrid через Device Connector.
 *
 * <p><b>Критичное ограничение:</b> буфер выставляется как FE-capability
 * <i>только</i> со стороны, где к нему примыкает {@code powergrid:device_connector}.
 * Любой другой FE-источник (createaddition-кабели, чужие генераторы, воронки FE)
 * получит {@code null} и не сможет ни толкнуть, ни вытянуть энергию. Так убирается
 * возможность запитать машину «в обход» безопасного моста powergrid.
 */
public class PowerInputBlockEntity extends BlockEntity {

    public static final int CAPACITY = 200_000;
    public static final int MAX_RECEIVE = 20_000;

    private final Buffer energy = new Buffer(CAPACITY, MAX_RECEIVE);

    public PowerInputBlockEntity(BlockPos pos, BlockState state) {
        super(MachineRegistry.POWER_INPUT_BE.get(), pos, state);
    }

    public int getStored() { return energy.getEnergyStored(); }
    public int getCapacity() { return energy.getMaxEnergyStored(); }

    /** Снять amount FE, если хватает. true — если списано. */
    public boolean consume(int amount) {
        if (energy.getEnergyStored() < amount) return false;
        energy.take(amount);
        setChanged();
        return true;
    }

    /**
     * Регистрация FE-capability с проверкой соседа. NeoForge вызывает эту функцию с
     * {@code side} = гранью нашего блока, обращённой к запрашивающему. Device Connector
     * стоит ровно на {@code getBlockPos().relative(side)} и запрашивает нашу грань.
     *
     * <p>Отдаём буфер, если со стороны запроса:
     * <ul>
     *   <li>стоит {@code powergrid:device_connector} — штатное питание;</li>
     *   <li>пусто (воздух/заменяемый блок) — иначе Device Connector не пройдёт свою
     *       проверку {@code canSurvive} при установке: в момент проверки коннектора
     *       ещё нет, а ему нужно, чтобы у нас уже был FE-приёмник. Пустая грань сама
     *       энергию не толкает, так что это безопасно.</li>
     * </ul>
     * Любой другой реальный блок (createaddition-кабели, чужие FE-источники) получает
     * {@code null} и подключиться не сможет.
     */
    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, MachineRegistry.POWER_INPUT_BE.get(),
                (be, side) -> side != null ? be.energy : null);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", energy.getEnergyStored());
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        energy.set(tag.getInt("Energy"));
    }

    /** Receive-only FE-буфер с внутренним расходом. */
    public static final class Buffer extends EnergyStorage {
        public Buffer(int capacity, int maxReceive) { super(capacity, maxReceive, 0, 0); }
        public void take(int amount) { this.energy = Math.max(0, this.energy - amount); }
        public void set(int value) { this.energy = Math.max(0, Math.min(this.capacity, value)); }
    }
}
