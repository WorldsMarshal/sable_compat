package com.invfix.cyberware.machines.crafter;

import com.invfix.cyberware.machines.MachineRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Обвязка станков — закрытый короб (как у литографа), параметризуется по тиру:
 *
 *  - Высокоточный (E2):        Д7 × Ш5 × В5, корпус dndecor:industrial_plating_block
 *  - Сверхвысокоточный (E3):   Д10 × Ш5 × В5, корпус dndecor:dark_metal_plating
 *
 * Весь внешний корпус (рёбра и стены) — из одного блока обшивки. Наполнение интерьера
 * 3×3×(Д−2) — sable_compat:auto_electronics. Контроллер занимает одну ячейку ДЛИННОЙ
 * стены (не ребро), лицом наружу. В стене НАПРОТИВ контроллера, в среднем ряду по
 * высоте — 3 Шлюза предметов (sable_compat:machine_item_port) с одним блоком обшивки
 * между ними. В центре короткой (5×5) стены — power_input (либо обшивка: соберётся,
 * но без питания).
 */
public final class MachineMultiblock {

    public record Result(boolean formed, @Nullable BlockPos powerPos, List<BlockPos> ports) {
        static final Result INVALID = new Result(false, null, List.of());
    }

    private static final int W = 5; // глубина короба (от стены контроллера)
    private static final int H = 5;
    private static final int SCAN_CAP = 12;

    private MachineMultiblock() {}

    private static Block modBlock(String ns, String path) {
        return BuiltInRegistries.BLOCK.get(ResourceLocation.fromNamespaceAndPath(ns, path));
    }

    /** Позиции шлюзов вдоль длинной стены (индексы по длине): по 3, через один блок. */
    // Шлюзы не привязаны к фиксированным индексам: валидатор принимает тройку
    // {x, x+2, x+4} в ЛЮБОМ месте среднего ряда задней стены (см. validate).

    private static boolean isShell(BlockState st, Block casing, Block controller, Block port) {
        return st.is(casing) || st.is(controller) || st.is(port);
    }

    private static int scan(Level level, BlockPos from, Direction dir, Block casing, Block controller, Block port) {
        int n = 0;
        BlockPos.MutableBlockPos p = from.mutable();
        for (int i = 0; i < SCAN_CAP; i++) {
            p.move(dir);
            if (!isShell(level.getBlockState(p), casing, controller, port)) break;
            n++;
        }
        return n;
    }

    /**
     * @param length    длина короба (7 или 10)
     * @param casingId  id блока обшивки (dndecor:industrial_plating_block / dark_metal_plating)
     */
    public static Result validate(Level level, BlockPos controllerPos, Direction facing,
                                  int length, ResourceLocation casingId, Block controllerBlock) {
        if (!facing.getAxis().isHorizontal()) return Result.INVALID;

        Block casing = modBlock(casingId.getNamespace(), casingId.getPath());
        if (casing == Blocks.AIR) return Result.INVALID; // dndecor не загружен
        Block electronics = modBlock("sable_compat", "auto_electronics");
        Block port = MachineRegistry.MACHINE_ITEM_PORT.get();
        Block powerInput = MachineRegistry.POWER_INPUT.get();

        Direction into = facing.getOpposite();
        Direction up = Direction.UP;
        Direction len = facing.getClockWise();

        // 1) Локализуем контроллер в его (длинной) стене направленным сканом.
        int upPos = scan(level, controllerPos, up, casing, controllerBlock, port);
        int upNeg = scan(level, controllerPos, up.getOpposite(), casing, controllerBlock, port);
        int lenPos = scan(level, controllerPos, len, casing, controllerBlock, port);
        int lenNeg = scan(level, controllerPos, len.getOpposite(), casing, controllerBlock, port);

        if (upPos + upNeg + 1 != H) return Result.INVALID;
        if (lenPos + lenNeg + 1 != length) return Result.INVALID;

        int ctrlHi = upNeg;   // высота контроллера в стене (0..4)
        int ctrlLi = lenNeg;  // позиция по длине (0..length-1)
        if (ctrlHi == 0 || ctrlHi == H - 1 || ctrlLi == 0 || ctrlLi == length - 1) return Result.INVALID;

        // 2) Угол короба (li=0, hi=0, di=0 — плоскость контроллера).
        BlockPos corner = controllerPos
                .relative(up.getOpposite(), upNeg)
                .relative(len.getOpposite(), lenNeg);

        BlockPos powerPos = null;
        List<BlockPos> portPositions = new ArrayList<>(3);
        List<Integer> portLis = new ArrayList<>(3);

        BlockPos.MutableBlockPos cell = new BlockPos.MutableBlockPos();
        for (int li = 0; li < length; li++) {
            for (int di = 0; di < W; di++) {
                for (int hi = 0; hi < H; hi++) {
                    cell.set(corner).move(len, li).move(into, di).move(up, hi);
                    if (li == ctrlLi && di == 0 && hi == ctrlHi) continue; // контроллер

                    BlockState st = level.getBlockState(cell);
                    boolean interior = li > 0 && li < length - 1 && di > 0 && di < W - 1 && hi > 0 && hi < H - 1;

                    if (interior) {
                        if (!st.is(electronics)) return Result.INVALID;
                        continue;
                    }

                    // средний ряд стены напротив контроллера: тут допускаются шлюзы
                    boolean portRow = di == W - 1 && hi == 2 && li > 0 && li < length - 1;
                    if (portRow && st.is(port)) {
                        portPositions.add(cell.immutable());
                        portLis.add(li);
                        continue;
                    }

                    // питание: центр короткой стены (li = 0 или length-1, di = 2, hi = 2)
                    boolean powerCell = (li == 0 || li == length - 1) && di == 2 && hi == 2;
                    if (powerCell && st.is(powerInput)) {
                        powerPos = cell.immutable();
                        continue;
                    }

                    if (!st.is(casing)) return Result.INVALID;
                }
            }
        }

        // ровно 3 шлюза, через один блок: {x, x+2, x+4}
        if (portLis.size() != 3) return Result.INVALID;
        portLis.sort(Integer::compareTo);
        if (portLis.get(1) - portLis.get(0) != 2 || portLis.get(2) - portLis.get(1) != 2) return Result.INVALID;

        return new Result(true, powerPos, portPositions);
    }
}
