package com.invfix.cyberware.machines;

import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.IItemHandler;

/**
 * Реализуется BlockEntity'ями машин (литограф, станки), у которых есть внутренний
 * инвентарь. {@link MachineItemPortBlockEntity} (Create-шлюз) находит ближайший такой
 * приёмник и работает с ним в обе стороны: воронки Create кладут предметы внутрь и
 * вынимают их (в т.ч. из слота результата), с учётом фильтров воронки.
 */
public interface IMachineItemSink {

    /**
     * Поместить {@code stack} во внутренний инвентарь машины (через её логику приёма).
     * @return остаток, который не влез (или сам {@code stack}, если не принят).
     */
    ItemStack insertToMachine(ItemStack stack, boolean simulate);

    /**
     * Инвентарь машины, из которого Create-шлюз может ВЫНИМАТЬ предметы (буфер + слот
     * результата). Как у сундука: без фильтра воронка выгребает всё, с фильтром — только
     * отфильтрованное. Вставку через этот хендлер шлюз НЕ делает — для вставки идёт
     * {@link #insertToMachine} (чтобы предметы попадали в буфер, а не в слот выхода).
     */
    IItemHandler getExtractHandler();
}
