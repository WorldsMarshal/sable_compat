package com.invfix.cyberware.machines;

import com.invfix.cyberware.machines.crafter.ProgrammableMachineScreen;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/** Клиентская регистрация экранов машин (вызывается только на клиенте). */
public final class MachineClient {
    private MachineClient() {}

    public static void init(IEventBus modEventBus) {
        modEventBus.addListener(MachineClient::onRegisterScreens);
    }

    private static void onRegisterScreens(RegisterMenuScreensEvent event) {
        event.register(MachineRegistry.PROGRAMMABLE_MACHINE_MENU.get(), ProgrammableMachineScreen::new);
    }
}
