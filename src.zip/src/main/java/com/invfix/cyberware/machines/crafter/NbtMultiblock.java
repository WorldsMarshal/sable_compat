package com.invfix.cyberware.machines.crafter;

import com.invfix.cyberware.machines.MachineRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Валидатор обвязки по данным из Create-чертежа ({@link MachineStructures}).
 * Матчинг пробует все 4 поворота вокруг Y — чертёж строится в любом направлении,
 * контроллер ставится на место блока земли из схемы.
 *
 * <p>Шлюзы гибкие: в любой ячейке ОБШИВКИ (dark_metal_plating) — и в ячейках, где в
 * чертеже стоял шлюз, — допускается предметный ({@code machine_item_port}) или
 * жидкостный ({@code machine_fluid_port}) шлюз, в любой комбинации. Требование:
 * суммарно РОВНО {@value #REQUIRED_PORTS} шлюза на структуру. Жидкостный шлюз
 * подключает трубы Create к внутреннему танку машины (3000 mB).
 */
public final class NbtMultiblock {

    public static final int REQUIRED_PORTS = 3;
    private static final String CASING_ID = "dndecor:dark_metal_plating";

    public record Result(boolean formed, @Nullable BlockPos powerPos,
                         List<BlockPos> ports, List<BlockPos> fluidPorts) {
        static final Result INVALID = new Result(false, null, List.of(), List.of());
    }

    private NbtMultiblock() {}

    public static Result validate(Level level, BlockPos controller, String[] palette, int[] cells) {
        Block[] blocks = new Block[palette.length];
        int powerIdx = -1, portIdx = -1, casingIdx = -1;
        for (int i = 0; i < palette.length; i++) {
            ResourceLocation id = ResourceLocation.parse(palette[i]);
            blocks[i] = BuiltInRegistries.BLOCK.get(id);
            if (blocks[i] == Blocks.AIR) return Result.INVALID; // мод-поставщик не загружен
            if (palette[i].equals("sable_compat:power_input")) powerIdx = i;
            if (palette[i].equals("sable_compat:machine_item_port")) portIdx = i;
            if (palette[i].equals(CASING_ID)) casingIdx = i;
        }
        Block itemPort = MachineRegistry.MACHINE_ITEM_PORT.get();
        Block fluidPort = MachineRegistry.MACHINE_FLUID_PORT.get();

        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int rot = 0; rot < 4; rot++) {
            BlockPos powerPos = null;
            List<BlockPos> ports = new ArrayList<>(REQUIRED_PORTS);
            List<BlockPos> fluidPorts = new ArrayList<>(REQUIRED_PORTS);
            boolean ok = true;
            for (int i = 0; i < cells.length; i += 4) {
                int dx = cells[i], dy = cells[i + 1], dz = cells[i + 2], bi = cells[i + 3];
                int rx, rz;
                switch (rot) {
                    case 1 -> { rx = -dz; rz = dx; }
                    case 2 -> { rx = -dx; rz = -dz; }
                    case 3 -> { rx = dz;  rz = -dx; }
                    default -> { rx = dx; rz = dz; }
                }
                p.set(controller.getX() + rx, controller.getY() + dy, controller.getZ() + rz);
                BlockState st = level.getBlockState(p);

                // гибкие ячейки: обшивка и чертёжные шлюзы взаимозаменяемы с любым шлюзом
                if (bi == casingIdx || bi == portIdx) {
                    if (st.is(itemPort)) { ports.add(p.immutable()); continue; }
                    if (st.is(fluidPort)) { fluidPorts.add(p.immutable()); continue; }
                    if (st.is(blocks[casingIdx])) continue;
                    ok = false; break;
                }

                if (!st.is(blocks[bi])) { ok = false; break; }
                if (bi == powerIdx) powerPos = p.immutable();
            }
            if (ok && ports.size() + fluidPorts.size() == REQUIRED_PORTS) {
                return new Result(true, powerPos, ports, fluidPorts);
            }
        }
        return Result.INVALID;
    }
}
