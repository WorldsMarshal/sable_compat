package com.invfix.cyberware.machines;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import com.invfix.cyberware.machines.crafter.ProgrammableMachineBlock;
import com.invfix.cyberware.machines.crafter.HyperbaricFurnaceBlockEntity;
import com.invfix.cyberware.machines.crafter.PrecisionMachineBlockEntity;
import com.invfix.cyberware.machines.crafter.UltraPrecisionMachineBlockEntity;
import com.invfix.cyberware.machines.crafter.ProgrammableMachineMenu;

/**
 * Реестр общей инфраструктуры машин (переиспользуется литографом и станками):
 *  - {@code power_input} — единый Энергоприёмник (FE только от powergrid device_connector);
 *  - {@code machine_item_port} — Create-шлюз предметов (воронки Create → буфер машины);
 *  - {@code precision_machine} — высокоточный станок (программируемый автокрафтер 5×5).
 */
public final class MachineRegistry {

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks("sable_compat");
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("sable_compat");
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, "sable_compat");
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, "sable_compat");

    // --- Блоки ---
    public static final DeferredBlock<PowerInputBlock> POWER_INPUT =
            BLOCKS.registerBlock("power_input", PowerInputBlock::new,
                    BlockBehaviour.Properties.of().mapColor(MapColor.METAL)
                            .strength(4.0F, 8.0F).requiresCorrectToolForDrops().sound(SoundType.NETHERITE_BLOCK));

    public static final DeferredBlock<MachineFluidPortBlock> MACHINE_FLUID_PORT =
            BLOCKS.registerBlock("machine_fluid_port", MachineFluidPortBlock::new,
                    BlockBehaviour.Properties.of().mapColor(MapColor.METAL)
                            .strength(4.0F, 8.0F).requiresCorrectToolForDrops().sound(SoundType.NETHERITE_BLOCK));

    public static final DeferredBlock<MachineItemPortBlock> MACHINE_ITEM_PORT =
            BLOCKS.registerBlock("machine_item_port", MachineItemPortBlock::new,
                    BlockBehaviour.Properties.of().mapColor(MapColor.METAL)
                            .strength(4.0F, 8.0F).requiresCorrectToolForDrops().sound(SoundType.NETHERITE_BLOCK));

    public static final DeferredBlock<ProgrammableMachineBlock> PRECISION_MACHINE =
            BLOCKS.registerBlock("precision_machine",
                    p -> new ProgrammableMachineBlock(p, PrecisionMachineBlockEntity::new),
                    BlockBehaviour.Properties.of().mapColor(MapColor.METAL)
                            .strength(5.0F, 10.0F).requiresCorrectToolForDrops().sound(SoundType.NETHERITE_BLOCK));

    public static final DeferredBlock<ProgrammableMachineBlock> ULTRA_PRECISION_MACHINE =
            BLOCKS.registerBlock("ultra_precision_machine",
                    p -> new ProgrammableMachineBlock(p, UltraPrecisionMachineBlockEntity::new),
                    BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK)
                            .strength(6.0F, 12.0F).requiresCorrectToolForDrops().sound(SoundType.NETHERITE_BLOCK));

    public static final DeferredBlock<ProgrammableMachineBlock> HYPERBARIC_FURNACE =
            BLOCKS.registerBlock("hyperbaric_furnace",
                    p -> new ProgrammableMachineBlock(p, HyperbaricFurnaceBlockEntity::new),
                    BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_RED)
                            .strength(6.0F, 12.0F).requiresCorrectToolForDrops().sound(SoundType.NETHERITE_BLOCK));

    // --- BlockItem'ы ---
    public static final DeferredItem<BlockItem> POWER_INPUT_ITEM =
            ITEMS.registerSimpleBlockItem("power_input", POWER_INPUT);
    public static final DeferredItem<BlockItem> MACHINE_ITEM_PORT_ITEM =
            ITEMS.registerSimpleBlockItem("machine_item_port", MACHINE_ITEM_PORT);
    public static final DeferredItem<BlockItem> MACHINE_FLUID_PORT_ITEM =
            ITEMS.registerSimpleBlockItem("machine_fluid_port", MACHINE_FLUID_PORT);
    public static final DeferredItem<BlockItem> PRECISION_MACHINE_ITEM =
            ITEMS.registerSimpleBlockItem("precision_machine", PRECISION_MACHINE);
    public static final DeferredItem<BlockItem> ULTRA_PRECISION_MACHINE_ITEM =
            ITEMS.registerSimpleBlockItem("ultra_precision_machine", ULTRA_PRECISION_MACHINE);
    public static final DeferredItem<BlockItem> HYPERBARIC_FURNACE_ITEM =
            ITEMS.registerSimpleBlockItem("hyperbaric_furnace", HYPERBARIC_FURNACE);

    // --- BlockEntity ---
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PowerInputBlockEntity>> POWER_INPUT_BE =
            BLOCK_ENTITIES.register("power_input",
                    () -> BlockEntityType.Builder.of(PowerInputBlockEntity::new, POWER_INPUT.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MachineItemPortBlockEntity>> MACHINE_ITEM_PORT_BE =
            BLOCK_ENTITIES.register("machine_item_port",
                    () -> BlockEntityType.Builder.of(MachineItemPortBlockEntity::new, MACHINE_ITEM_PORT.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MachineFluidPortBlockEntity>> MACHINE_FLUID_PORT_BE =
            BLOCK_ENTITIES.register("machine_fluid_port",
                    () -> BlockEntityType.Builder.of(MachineFluidPortBlockEntity::new, MACHINE_FLUID_PORT.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PrecisionMachineBlockEntity>> PRECISION_MACHINE_BE =
            BLOCK_ENTITIES.register("precision_machine",
                    () -> BlockEntityType.Builder.of(PrecisionMachineBlockEntity::new, PRECISION_MACHINE.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<UltraPrecisionMachineBlockEntity>> ULTRA_PRECISION_MACHINE_BE =
            BLOCK_ENTITIES.register("ultra_precision_machine",
                    () -> BlockEntityType.Builder.of(UltraPrecisionMachineBlockEntity::new, ULTRA_PRECISION_MACHINE.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<HyperbaricFurnaceBlockEntity>> HYPERBARIC_FURNACE_BE =
            BLOCK_ENTITIES.register("hyperbaric_furnace",
                    () -> BlockEntityType.Builder.of(HyperbaricFurnaceBlockEntity::new, HYPERBARIC_FURNACE.get()).build(null));

    // --- Menu (общий для всех программируемых станков) ---
    public static final DeferredHolder<MenuType<?>, MenuType<ProgrammableMachineMenu>> PROGRAMMABLE_MACHINE_MENU =
            MENUS.register("programmable_machine",
                    () -> IMenuTypeExtension.create((windowId, inv, buf) -> new ProgrammableMachineMenu(windowId, inv, buf)));

    private MachineRegistry() {}

    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
        MENUS.register(modEventBus);
        modEventBus.addListener(MachineRegistry::onBuildCreativeTabs);
        modEventBus.addListener(MachineRegistry::onRegisterCapabilities);
    }

    private static void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
        PowerInputBlockEntity.registerCapabilities(event);
        MachineItemPortBlockEntity.registerCapabilities(event);
        MachineFluidPortBlockEntity.registerCapabilities(event);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(POWER_INPUT_ITEM);
            event.accept(MACHINE_ITEM_PORT_ITEM);
            event.accept(MACHINE_FLUID_PORT_ITEM);
            event.accept(PRECISION_MACHINE_ITEM);
            event.accept(ULTRA_PRECISION_MACHINE_ITEM);
            event.accept(HYPERBARIC_FURNACE_ITEM);
        }
    }
}
