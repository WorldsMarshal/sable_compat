package com.invfix.cyberware.machines.crafter;

import com.invfix.cyberware.machines.MachineRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Высокоточный станок (E2). Время крафта 800 тиков, буфер 36 (1 инвентарь игрока),
 * потребление 800 FE/тик. Тир 1. Обвязка: короб Д7×Ш5×В5 из dndecor:industrial_plating_block.
 */
public class PrecisionMachineBlockEntity extends ProgrammableMachineBlockEntity {

    public static final int CRAFT_TIME = 800;
    public static final int BUFFER = 36;
    public static final int ENERGY_PER_TICK = 800;
    public static final int TIER = 1;
    public static final int LENGTH = 7;
    private static final ResourceLocation CASING =
            ResourceLocation.fromNamespaceAndPath("dndecor", "industrial_plating_block");

    public PrecisionMachineBlockEntity(BlockPos pos, BlockState state) {
        super(MachineRegistry.PRECISION_MACHINE_BE.get(), pos, state);
    }

    @Override public int craftTime() { return CRAFT_TIME; }
    @Override public int bufferSize() { return BUFFER; }
    @Override public int energyPerTick() { return ENERGY_PER_TICK; }
    @Override public int tierLevel() { return TIER; }
    @Override public int gridWidth() { return 5; }

    @Override
    protected NbtMultiblock.Result validateStructureImpl() {
        var facing = getBlockState().getValue(ProgrammableMachineBlock.FACING);
        MachineMultiblock.Result r = MachineMultiblock.validate(
                getLevel(), getBlockPos(), facing, LENGTH, CASING, getBlockState().getBlock());
        return new NbtMultiblock.Result(r.formed(), r.powerPos(), r.ports(), java.util.List.of());
    }

    /**
     * Звук работы E2 — тяжёлая механообработка: скрежет точила (фреза снимает металл)
     * с рычащим низким питчем + периодический пневматический "чух" поршня.
     */
    @Override
    public void playWorkSound(Level level, BlockPos pos, long gameTime) {
        if (gameTime % 24 == 0) {
            float pitch = 0.55F + level.getRandom().nextFloat() * 0.1F;
            level.playSound(null, pos, SoundEvents.GRINDSTONE_USE, SoundSource.BLOCKS, 0.55F, pitch);
        }
        if (gameTime % 96 == 40) {
            level.playSound(null, pos, SoundEvents.PISTON_EXTEND, SoundSource.BLOCKS, 0.4F, 0.8F);
        }
    }
}
