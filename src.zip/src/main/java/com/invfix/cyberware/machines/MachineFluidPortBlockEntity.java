package com.invfix.cyberware.machines;

import com.invfix.cyberware.machines.crafter.ProgrammableMachineBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import org.jetbrains.annotations.Nullable;

/**
 * Жидкостный шлюз машин ({@code machine_fluid_port}). Ставится в обвязку вместо
 * любого предметного шлюза (валидатор допускает любую комбинацию, суммарно 3).
 * Выставляет {@code IFluidHandler} на всех гранях — к нему подключаются трубы
 * Create; закачка/выкачка идёт напрямую во внутренний танк машины (3000 mB,
 * одна жидкость — {@code FluidTank} по своей природе хранит один тип).
 *
 * Привязку делает контроллер при валидации обвязки ({@link #linkTo}); есть
 * fallback-перепоиск по радиусу на случай перезагрузки чанка до валидации.
 */
public class MachineFluidPortBlockEntity extends BlockEntity {

    private static final int LINK_RADIUS = 3;
    private static final int RESCAN_INTERVAL = 40;

    @Nullable private BlockPos linkPos = null;

    public MachineFluidPortBlockEntity(BlockPos pos, BlockState state) {
        super(MachineRegistry.MACHINE_FLUID_PORT_BE.get(), pos, state);
    }

    /** Явная привязка от контроллера машины (при валидации обвязки). */
    public void linkTo(BlockPos machinePos) {
        if (!java.util.Objects.equals(linkPos, machinePos)) {
            linkPos = machinePos;
            if (level != null) level.invalidateCapabilities(worldPosition);
            setChanged();
        }
    }

    @Nullable
    private IFluidHandler resolveTank() {
        if (level == null) return null;
        if (linkPos != null
                && level.getBlockEntity(linkPos) instanceof ProgrammableMachineBlockEntity m
                && m.getFluidTank() != null) {
            return m.getFluidTank();
        }
        return null;
    }

    private void rescan() {
        if (level == null) return;
        BlockPos prev = linkPos;
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int dx = -LINK_RADIUS; dx <= LINK_RADIUS; dx++)
            for (int dy = -LINK_RADIUS; dy <= LINK_RADIUS; dy++)
                for (int dz = -LINK_RADIUS; dz <= LINK_RADIUS; dz++) {
                    p.set(worldPosition.getX() + dx, worldPosition.getY() + dy, worldPosition.getZ() + dz);
                    if (level.getBlockEntity(p) instanceof ProgrammableMachineBlockEntity m
                            && m.getFluidTank() != null) {
                        double d = p.distSqr(worldPosition);
                        if (d < bestDist) { bestDist = d; best = p.immutable(); }
                    }
                }
        linkPos = best;
        if (!java.util.Objects.equals(prev, linkPos)) level.invalidateCapabilities(worldPosition);
    }

    @Nullable
    public IFluidHandler getAccessHandler() {
        IFluidHandler tank = resolveTank();
        if (tank == null) { rescan(); tank = resolveTank(); }
        return tank;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, MachineFluidPortBlockEntity be) {
        if (level.isClientSide) return;
        if ((level.getGameTime() % RESCAN_INTERVAL) == 0L && be.resolveTank() == null) {
            be.rescan();
        }
    }

    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, MachineRegistry.MACHINE_FLUID_PORT_BE.get(),
                (be, side) -> be.getAccessHandler());
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        if (linkPos != null) { tag.putLong("Link", linkPos.asLong()); tag.putBoolean("HasLink", true); }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        linkPos = tag.getBoolean("HasLink") ? BlockPos.of(tag.getLong("Link")) : null;
    }
}
