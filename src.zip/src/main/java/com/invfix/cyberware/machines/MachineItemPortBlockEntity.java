package com.invfix.cyberware.machines;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.items.IItemHandler;
import org.jetbrains.annotations.Nullable;

/**
 * Create-шлюз машин ({@code machine_item_port}). Отдельный блок, выставляющий
 * {@code IItemHandler} на всех гранях — к нему цепляются воронки/пояса Create
 * ({@code brass_funnel}, {@code andesite_funnel} и т.д.). Работает в ОБЕ стороны:
 *  - вставка → уходит во внутренний инвентарь ближайшей машины (её логика приёма);
 *  - извлечение → берётся из инвентаря машины (буфер + слот результата), как из сундука
 *    (фильтр воронки решает, что тянуть; без фильтра — всё).
 *
 * <p>Машина ищется в кубе радиуса {@link #LINK_RADIUS}; берётся ближайшая, реализующая
 * {@link IMachineItemSink}. Позиция кэшируется; при смене связи capability
 * инвалидируется, чтобы воронка переспросила.
 */
public class MachineItemPortBlockEntity extends BlockEntity {

    private static final int LINK_RADIUS = 3;
    private static final int RESCAN_INTERVAL = 40;

    @Nullable private BlockPos linkPos = null;
    @Nullable private PortAccess access = null;

    public MachineItemPortBlockEntity(BlockPos pos, BlockState state) {
        super(MachineRegistry.MACHINE_ITEM_PORT_BE.get(), pos, state);
    }

    @Nullable
    private IMachineItemSink resolveSink() {
        if (level == null) return null;
        if (linkPos != null) {
            if (level.getBlockEntity(linkPos) instanceof IMachineItemSink sink) return sink;
            linkPos = null;
        }
        return null;
    }

    /** Ищем ближайшую машину; при смене связи инвалидируем capability. */
    private void rescan() {
        if (level == null) return;
        BlockPos prev = linkPos;
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int dx = -LINK_RADIUS; dx <= LINK_RADIUS; dx++)
            for (int dy = -LINK_RADIUS; dy <= LINK_RADIUS; dy++)
                for (int dz = -LINK_RADIUS; dz <= LINK_RADIUS; dz++) {
                    p.set(worldPosition.getX() + dx, worldPosition.getY() + dy, worldPosition.getZ() + dz);
                    if (level.getBlockEntity(p) instanceof IMachineItemSink) {
                        double d = p.distSqr(worldPosition);
                        if (d < bestDist) { bestDist = d; best = p.immutable(); }
                    }
                }
        linkPos = best;
        if (!java.util.Objects.equals(prev, linkPos)) {
            access = null;
            level.invalidateCapabilities(worldPosition);
        }
    }

    /** Явная привязка от контроллера машины (при валидации обвязки). */
    public void linkTo(BlockPos machinePos) {
        if (!java.util.Objects.equals(linkPos, machinePos)) {
            linkPos = machinePos;
            access = null;
            if (level != null) level.invalidateCapabilities(worldPosition);
            setChanged();
        }
    }

    /** Хендлер для воронок: резолвит связь (при необходимости — перепоиск). */
    @Nullable
    public IItemHandler getAccessHandler() {
        IMachineItemSink sink = resolveSink();
        if (sink == null) { rescan(); sink = resolveSink(); }
        if (sink == null) return null;
        if (access == null || access.sink != sink) access = new PortAccess(sink);
        return access;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, MachineItemPortBlockEntity be) {
        if (level.isClientSide) return;
        if ((level.getGameTime() % RESCAN_INTERVAL) == 0L && be.resolveSink() == null) {
            be.rescan();
        }
    }

    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, MachineRegistry.MACHINE_ITEM_PORT_BE.get(),
                (be, side) -> be.getAccessHandler());
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        if (linkPos != null) { tag.putLong("Link", linkPos.asLong()); tag.putBoolean("HasLink", true); }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        linkPos = tag.getBoolean("HasLink") ? BlockPos.of(tag.getLong("Link")) : null;
        access = null;
    }

    /**
     * IItemHandler-обёртка над машиной: вставка идёт через приём машины (в буфер),
     * извлечение и просмотр слотов — из инвентаря машины (буфер + результат).
     */
    static final class PortAccess implements IItemHandler {
        final IMachineItemSink sink;
        final IItemHandler view;

        PortAccess(IMachineItemSink sink) {
            this.sink = sink;
            this.view = sink.getExtractHandler();
        }

        @Override public int getSlots() { return view.getSlots(); }
        @Override public ItemStack getStackInSlot(int slot) { return view.getStackInSlot(slot); }
        @Override public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
            return sink.insertToMachine(stack, simulate);
        }
        @Override public ItemStack extractItem(int slot, int amount, boolean simulate) {
            return view.extractItem(slot, amount, simulate);
        }
        @Override public int getSlotLimit(int slot) { return view.getSlotLimit(slot); }
        @Override public boolean isItemValid(int slot, ItemStack stack) { return true; }
    }
}
