package com.invfix.cyberware;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.fluids.BaseFlowingFluid;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/**
 * Жидкость «незавершённый композит» — промежуточный продукт между композитом
 * Mk1 и Mk2. Получается смешиванием под супернагревом, превращается прессом
 * (compacting) под супернагревом в слитки Mk2.
 *
 * Рендер (текстуры/тон) задаётся во вложенном {@link CompositeFluidType}.
 */
public final class CompositeFluids {

    public static final DeferredRegister<FluidType> FLUID_TYPES =
            DeferredRegister.create(NeoForgeRegistries.Keys.FLUID_TYPES, "sable_compat");
    public static final DeferredRegister<Fluid> FLUIDS =
            DeferredRegister.create(Registries.FLUID, "sable_compat");
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks("sable_compat");
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("sable_compat");

    public static final DeferredHolder<FluidType, FluidType> UNFINISHED_COMPOSITE_TYPE =
            FLUID_TYPES.register("unfinished_composite",
                    () -> new CompositeFluidType(FluidType.Properties.create()
                            .density(3200).viscosity(7000).temperature(1400)
                            .canSwim(false).canDrown(true).canExtinguish(false),
                            0xFF42506E));

    public static final DeferredHolder<Fluid, BaseFlowingFluid.Source> UNFINISHED_COMPOSITE =
            FLUIDS.register("unfinished_composite", () -> new BaseFlowingFluid.Source(makeProps()));
    public static final DeferredHolder<Fluid, BaseFlowingFluid.Flowing> UNFINISHED_COMPOSITE_FLOWING =
            FLUIDS.register("unfinished_composite_flowing", () -> new BaseFlowingFluid.Flowing(makeProps()));

    public static final DeferredBlock<LiquidBlock> UNFINISHED_COMPOSITE_BLOCK =
            BLOCKS.register("unfinished_composite",
                    () -> new LiquidBlock(UNFINISHED_COMPOSITE.get(),
                            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE)
                                    .noCollission().strength(100.0F).noLootTable().liquid().replaceable()));

    public static final DeferredItem<Item> UNFINISHED_COMPOSITE_BUCKET =
            ITEMS.register("unfinished_composite_bucket",
                    () -> new BucketItem(UNFINISHED_COMPOSITE.get(),
                            new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)));

    private static BaseFlowingFluid.Properties makeProps() {
        return new BaseFlowingFluid.Properties(
                UNFINISHED_COMPOSITE_TYPE, UNFINISHED_COMPOSITE, UNFINISHED_COMPOSITE_FLOWING)
                .block(UNFINISHED_COMPOSITE_BLOCK)
                .bucket(UNFINISHED_COMPOSITE_BUCKET);
    }

    private CompositeFluids() {}

    public static void register(IEventBus bus) {
        FLUID_TYPES.register(bus);
        FLUIDS.register(bus);
        BLOCKS.register(bus);
        ITEMS.register(bus);
    }

    /**
     * Свой {@link FluidType} с клиентским рендером через {@code initializeClient}
     * (канонический способ для NeoForge 1.21.1, как в tfmg). Server-safe:
     * {@code initializeClient} и клиентский интерфейс грузятся только на клиенте.
     */
    public static final class CompositeFluidType extends FluidType {
        private static final ResourceLocation STILL = ResourceLocation.withDefaultNamespace("block/water_still");
        private static final ResourceLocation FLOW = ResourceLocation.withDefaultNamespace("block/water_flow");
        private final int tint;

        public CompositeFluidType(Properties properties, int tint) {
            super(properties);
            this.tint = tint;
        }

        @Override
        @SuppressWarnings({"unchecked", "rawtypes"})
        public void initializeClient(java.util.function.Consumer consumer) {
            consumer.accept(new net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions() {
                @Override
                public ResourceLocation getStillTexture() {
                    return STILL;
                }

                @Override
                public ResourceLocation getFlowingTexture() {
                    return FLOW;
                }

                @Override
                public int getTintColor() {
                    return CompositeFluidType.this.tint;
                }
            });
        }
    }
}
