package com.invfix.cyberware;

import com.perigrine3.createcybernetics.api.CyberwareSlot;
import com.perigrine3.createcybernetics.api.ICyberwareItem;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;
import java.util.Set;

/**
 * Наномашины поколений (импланты). Gen1/Gen2 — слот BRAIN, Gen3 — MUSCLE.
 *
 *  - Gen1 (BRAIN, 0 человечности): +9 брони.
 *  - Gen2 (BRAIN, 0 человечности): +17 брони (перки Gen1 включены — слот один,
 *    носится вместо Gen1). Гейт для протезов Mk2 и универсальных имплантов.
 *  - Gen3 (MUSCLE, 1 человечность): перки Gen1/2 (+17 брони), +60 HP, урон
 *    ВЫСТАВЛЯЕТСЯ в 90 (замена, а не прибавка), ×2 скорость, ×3 копание,
 *    нет голода (насыщение поддерживается тиком).
 *
 * Энергии cyberware не требуют. Прирост HP идёт атрибутом MAX_HEALTH — если его
 * заклампят миксины капов (HumanCapsMixin), при сборке Сердца (фаза 10) переведём
 * на переменные Invincible вместе с Unleashed.
 */
public class NanomachinesItem extends Item implements ICyberwareItem {

    private final int generation;
    private final int humanityCost;
    private final CyberwareSlot slot;

    public NanomachinesItem(Properties props, int generation) {
        super(props.stacksTo(1));
        this.generation = generation;
        this.humanityCost = generation >= 3 ? 1 : 0;
        this.slot = generation >= 3 ? CyberwareSlot.MUSCLE : CyberwareSlot.BRAIN;
    }

    public int generation() { return generation; }

    @Override
    public int getHumanityCost() { return humanityCost; }

    @Override
    public Set<CyberwareSlot> getSupportedSlots() { return Set.of(slot); }

    @Override
    public int getEnergyUsedPerTick(LivingEntity entity, ItemStack installedStack, CyberwareSlot slot) {
        return 0;
    }

    @Override
    public boolean requiresEnergyToFunction(LivingEntity entity, ItemStack installedStack, CyberwareSlot slot) {
        return false;
    }

    // Наномашины — аугментация внутри органа, не замена (как Piezoelectric/Sandevistan/
    // SpinalInjector в оригинале — те тоже возвращают false/Set.of()).
    @Override
    public boolean replacesOrgan() { return false; }

    @Override
    public Set<CyberwareSlot> getReplacedOrgans() { return Set.of(); }

    @Override
    public void onInstalled(LivingEntity entity) {
        double armor = generation == 1 ? 9.0D : 17.0D;
        add(entity, Attributes.ARMOR, "nanomachines_armor", armor, AttributeModifier.Operation.ADD_VALUE);
        if (generation >= 3) {
            add(entity, Attributes.MAX_HEALTH, "nanomachines_health", 60.0D, AttributeModifier.Operation.ADD_VALUE);
            add(entity, Attributes.MOVEMENT_SPEED, "nanomachines_speed", 1.0D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
            add(entity, Attributes.BLOCK_BREAK_SPEED, "nanomachines_dig", 2.0D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
            // «урон = 90»: замена итога. База игрока 1.0 → множитель итога ×90 даёт ровно 90
            // при пустой руке; оружие в руке масштабируется тем же порядком силы.
            add(entity, Attributes.ATTACK_DAMAGE, "nanomachines_damage", 89.0D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        }
    }

    @Override
    public void onRemoved(LivingEntity entity) {
        remove(entity, Attributes.ARMOR, "nanomachines_armor");
        remove(entity, Attributes.MAX_HEALTH, "nanomachines_health");
        remove(entity, Attributes.MOVEMENT_SPEED, "nanomachines_speed");
        remove(entity, Attributes.BLOCK_BREAK_SPEED, "nanomachines_dig");
        remove(entity, Attributes.ATTACK_DAMAGE, "nanomachines_damage");
    }

    @Override
    public void onTick(LivingEntity entity) {
        // Gen2: пинг моста — Mk2-протезы и универсалки активны, пока Gen2 в мозге.
        if (generation == 2 && !entity.level().isClientSide) {
            com.invfix.cybercompat.CyberBonusBridge.pingGen2(entity);
        }
        // Gen3: нет голода — держим сытость (каждые 40 тиков, дёшево и надёжно)
        if (generation >= 3 && entity instanceof Player player && !player.level().isClientSide
                && player.level().getGameTime() % 40 == 0) {
            var food = player.getFoodData();
            if (food.getFoodLevel() < 20) food.setFoodLevel(20);
            if (food.getSaturationLevel() < 10.0F) food.setSaturation(10.0F);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.sable_compat.nanomachines_gen" + generation)
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.createcybernetics.humanity", humanityCost)
                .withStyle(ChatFormatting.GOLD));
    }

    private static void add(LivingEntity entity, Holder<Attribute> attribute, String path, double amount,
                            AttributeModifier.Operation op) {
        AttributeInstance inst = entity.getAttribute(attribute);
        if (inst == null) return;
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath("sable_compat", path);
        inst.removeModifier(id);
        inst.addPermanentModifier(new AttributeModifier(id, amount, op));
    }

    private static void remove(LivingEntity entity, Holder<Attribute> attribute, String path) {
        AttributeInstance inst = entity.getAttribute(attribute);
        if (inst != null) inst.removeModifier(ResourceLocation.fromNamespaceAndPath("sable_compat", path));
    }
}
