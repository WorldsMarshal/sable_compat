package com.invfix.cyberware;

import com.perigrine3.createcybernetics.api.CyberwareSlot;
import com.perigrine3.createcybernetics.item.cyberware.leg.CyberlegItem;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;

/**
 * Бионическая нога (Metal Gear) — улучшенный аналог
 * {@code createcybernetics:basecyberware_leftleg/rightleg}.
 *
 * Отличия от базовой кибер-ноги:
 *  - не потребляет энергию и работает вечно;
 *  - эффект втрое выше: база даёт +0.005 скорости и +0.025 прыжка на ногу,
 *    здесь — +0.015 скорости и +0.075 прыжка на ногу (одна нога ×3, две ноги ×3).
 *
 * Использует тот же механизм атрибутов, что и {@link BionicArmItem}.
 */
public class BionicLegItem extends CyberlegItem {

    private final String sideKey;

    public BionicLegItem(Properties props, int humanityCost, CyberwareSlot side) {
        super(props, humanityCost, side);
        this.sideKey = side == CyberwareSlot.LLEG ? "left" : "right";
    }

    @Override
    public int getEnergyUsedPerTick(LivingEntity entity, ItemStack installedStack, CyberwareSlot slot) {
        return 0;
    }

    @Override
    public boolean requiresEnergyToFunction(LivingEntity entity, ItemStack installedStack, CyberwareSlot slot) {
        return false;
    }

    @Override
    public void onInstalled(LivingEntity entity) {
        BionicArmItem.applyModifier(entity, Attributes.MOVEMENT_SPEED, "bionic_leg_speed_" + sideKey, 0.015D);
        BionicArmItem.applyModifier(entity, Attributes.JUMP_STRENGTH, "bionic_leg_jump_" + sideKey, 0.075D);
    }

    @Override
    public void onRemoved(LivingEntity entity) {
        BionicArmItem.removeModifier(entity, Attributes.MOVEMENT_SPEED, "bionic_leg_speed_" + sideKey);
        BionicArmItem.removeModifier(entity, Attributes.JUMP_STRENGTH, "bionic_leg_jump_" + sideKey);
    }
}
