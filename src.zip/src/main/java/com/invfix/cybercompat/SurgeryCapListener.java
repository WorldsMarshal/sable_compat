package com.invfix.cybercompat;

import com.invfix.cyberware.AttributeCaps;
import com.perigrine3.createcybernetics.event.custom.CyberwareSurgeryEvent;
import net.neoforged.bus.api.SubscribeEvent;

/**
 * Пересчёт капов скорости/прыжка после операции (установка/снятие имплантов).
 * Класс ссылается на createcybernetics — регистрируется вручную из InvincibleFix
 * ТОЛЬКО при наличии мода (NeoForge.EVENT_BUS.register), иначе не грузится.
 */
public final class SurgeryCapListener {

    @SubscribeEvent
    public void onSurgery(CyberwareSurgeryEvent event) {
        AttributeCaps.refresh(event.getPlayer());
    }
}
