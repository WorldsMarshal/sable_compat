package com.invfix.cybercompat;

import net.minecraft.world.entity.LivingEntity;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Мост кибер-бонусов к переменным Invincible (аналог VBonusBridge).
 *
 * Сердце наномашин каждый тик «пингует» сюда отметку времени; {@code HumanCapsMixin}
 * спрашивает активность и вместо жёсткого человеческого капа применяет кибер-капы
 * Durability/DTstat. Активность = отметка свежее {@value #TTL} тиков —
 * самовосстанавливается после релога и гаснет сама при снятии импланта, ничего в
 * состоянии Invincible не ломая (паттерн V-бонуса: кап вернёт нули следующим тактом).
 *
 * <p><b>Nanomachines Unleashed</b> — способность, включаемая ИГРОКОМ (клавиша →
 * пакет → {@link #toggleUnleashed}); работает только при активном Сердце.
 *
 * Класс не ссылается на классы cyberware — безопасен для загрузки миксином
 * даже без createcybernetics.
 */
public final class CyberBonusBridge {

    private static final long TTL = 40;

    private static final Map<LivingEntity, Long> HEART = new WeakHashMap<>();
    private static final Map<LivingEntity, Long> GEN2 = new WeakHashMap<>();
    private static final Map<LivingEntity, Boolean> UNLEASHED_TOGGLE = new WeakHashMap<>();

    private CyberBonusBridge() {}

    public static void pingHeart(LivingEntity e) { HEART.put(e, e.level().getGameTime()); }

    public static boolean isHeartActive(LivingEntity e) { return fresh(HEART.get(e), e); }

    /** Наномашины Gen2 пингуют сюда каждый тик; Mk2/универсалки проверяют активность. */
    public static void pingGen2(LivingEntity e) { GEN2.put(e, e.level().getGameTime()); }

    public static boolean isGen2Active(LivingEntity e) { return fresh(GEN2.get(e), e); }

    /** Переключить способность (по клавише игрока). @return новое состояние. */
    public static boolean toggleUnleashed(LivingEntity e) {
        boolean now = !UNLEASHED_TOGGLE.getOrDefault(e, false);
        UNLEASHED_TOGGLE.put(e, now);
        return now;
    }

    /** Unleashed = включено игроком И Сердце активно. */
    public static boolean isUnleashed(LivingEntity e) {
        return UNLEASHED_TOGGLE.getOrDefault(e, false) && isHeartActive(e);
    }

    private static boolean fresh(Long stamp, LivingEntity e) {
        return stamp != null && e.level().getGameTime() - stamp <= TTL;
    }
}
