package com.invfix.cybercompat;

import com.invfix.cyberware.CompositeItems;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.jetbrains.annotations.Nullable;

/**
 * «Синтетический материал → настоящий материал, который он заменяет».
 * Используется {@code IngredientSubstituteMixin}, чтобы синтетические кристалл и
 * незеритовый обломок принимались НАРАВНЕ с оригиналом в ЛЮБОМ рецепте (крафт,
 * ковка, любой процесс, построенный на ванильном {@code Ingredient}) — включая
 * рецепты сторонних модов, до чьих датапаков у нас нет доступа. Патчить каждый
 * такой рецепт руками невозможно (их может быть сколько угодно, в любом моде),
 * поэтому подмена сделана на уровне самого механизма сопоставления предмета —
 * см. миксин.
 *
 * <p>Сравнение с {@code DeferredItem.get()} намеренно НЕ кэшируется в статическом
 * поле при загрузке класса — на момент загрузки миксин-класса реестр предметов
 * может быть ещё не заполнен. Обращение лениво, только при первом реальном вызове
 * {@link #realEquivalent(ItemStack)} (то есть уже во время игры, когда всё точно
 * зарегистрировано).
 *
 * <p>Работает только там, где рецепт проверяет предмет через
 * {@link net.minecraft.world.item.crafting.Ingredient#test(ItemStack)} — это
 * покрывает подавляющее большинство крафтов, включая процессинг многих других
 * модов, поскольку {@code Ingredient} — стандартный ванильный механизм. Что не
 * покрывает: проверки в обход {@code Ingredient} (прямое сравнение
 * {@code stack.is(Items.AMETHYST_SHARD)}, свои кастомные системы ингредиентов) —
 * таких меньшинство, но они в принципе недоступны без ASM-патча конкретного мода.
 */
public final class SubstituteRegistry {

    private SubstituteRegistry() {}

    /**
     * Если {@code stack} — один из наших синтетических материалов, возвращает
     * эквивалентный стек НАСТОЯЩЕГО материала (с тем же count) для повторной
     * проверки ингредиента. Иначе — {@code null}.
     */
    @Nullable
    public static ItemStack realEquivalent(ItemStack stack) {
        if (stack.isEmpty()) return null;
        Item item = stack.getItem();
        if (item == CompositeItems.SYNTHETIC_CRYSTAL.get()) {
            return new ItemStack(Items.AMETHYST_SHARD, stack.getCount());
        }
        if (item == CompositeItems.SYNTHETIC_NETHERITE_SCRAP.get()) {
            return new ItemStack(Items.NETHERITE_SCRAP, stack.getCount());
        }
        return null;
    }
}
