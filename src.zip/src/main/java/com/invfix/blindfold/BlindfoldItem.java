package com.invfix.blindfold;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Equipable;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Повязка на глаза. Носится в слоте шлема (Equipable: ПКМ надевает, в инвентаре кладётся в слот шлема)
 * или в слоте головы Curios (тег curios:head, как очки Create). Пока надета — у носящего чёрный экран
 * (BlindfoldClient), сквозь неё видно только Thermal Sense.
 */
public class BlindfoldItem extends Item implements Equipable {

    public BlindfoldItem(Properties properties) {
        super(properties);
    }

    @Override
    public EquipmentSlot getEquipmentSlot() {
        return EquipmentSlot.HEAD;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return this.swapWithEquipmentSlot(this, level, player, hand);
    }
}
