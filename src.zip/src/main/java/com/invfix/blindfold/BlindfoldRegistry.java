package com.invfix.blindfold;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Регистрация повязки на глаза (вкладка «Инструменты и приспособления»). */
public final class BlindfoldRegistry {

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("sable_compat");

    public static final DeferredItem<BlindfoldItem> BLINDFOLD = ITEMS.register("blindfold",
            () -> new BlindfoldItem(new Item.Properties().stacksTo(1)));

    private BlindfoldRegistry() {}

    public static void register(IEventBus modEventBus) {
        ITEMS.register(modEventBus);
        modEventBus.addListener(BlindfoldRegistry::onBuildCreativeTabs);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(BLINDFOLD);
        }
    }
}
