package com.invfix.blindfold.client;

import com.invfix.blindfold.Blindfold;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Повязка на голове игрока (слот шлема или Curios). Лента вокруг головы чуть шире слоя волос:
 * спереди — лицевая текстура (64×64: лицо головы 8×8 при 8 пикселях на единицу, вырез под нос),
 * с боков и сзади — та же ткань, на затылке узел и два свисающих хвоста.
 * Координаты — в пространстве головы PlayerModel (y вниз, лицо к −z), в пикселях модели.
 */
@OnlyIn(Dist.CLIENT)
public class BlindfoldLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {

    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/blindfold.png");

    /** Полуширина ленты (голова 4, слой волос 4.5). */
    private static final float R = 4.6F;
    private static final float SCALE = R / 4.0F;

    public BlindfoldLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    /** Высота строки лицевой текстуры на голове. */
    private static float row(float r) {
        return -4.0F + (r / 8.0F - 4.0F) * SCALE;
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffers, int light, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (player.isInvisible() || !Blindfold.isWorn(player)) return;
        PlayerModel<AbstractClientPlayer> model = this.getParentModel();
        if (!model.head.visible) return;
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        int overlay = LivingEntityRenderer.getOverlayCoords(player, 0.0F);
        poseStack.pushPose();
        model.head.translateAndRotate(poseStack);
        PoseStack.Pose pose = poseStack.last();

        // лицо: вся лицевая текстура (строки 22..40, столбцы 4..59)
        float fy0 = row(22), fy1 = row(40);
        quad(pose, vc, light, overlay,
                -R, fy0, -R, R, fy0, -R, R, fy1, -R, -R, fy1, -R,
                4 / 64F, 22 / 64F, 59 / 64F, 40 / 64F);
        // бока и затылок: прямая часть ленты (строки 23..33 лица) — полоса ткани 44..54
        float by0 = row(23), by1 = row(33);
        float sv0 = 44 / 64F, sv1 = 54 / 64F;
        quad(pose, vc, light, overlay, R, by0, -R, R, by0, R, R, by1, R, R, by1, -R, 0F, sv0, 1F, sv1);
        quad(pose, vc, light, overlay, -R, by0, R, -R, by0, -R, -R, by1, -R, -R, by1, R, 0F, sv0, 1F, sv1);
        quad(pose, vc, light, overlay, R, by0, R, -R, by0, R, -R, by1, R, R, by1, R, 0F, sv0, 1F, sv1);

        // узел на затылке
        float kv0 = 56 / 64F, kv1 = 64 / 64F;
        box(pose, vc, light, overlay, -0.9F, by0 + 0.15F, R, 0.9F, by1 + 0.05F, R + 0.8F, kv0, kv1);
        // два хвоста: из-под узла вниз и в стороны
        tail(pose, vc, light, overlay, -0.45F, by1, R + 0.5F, -1.35F, by1 + 2.7F, R + 1.25F, kv0, kv1);
        tail(pose, vc, light, overlay, 0.45F, by1, R + 0.5F, 1.25F, by1 + 2.4F, R + 1.15F, kv0, kv1);
        poseStack.popPose();
    }

    /** Свисающий хвост шириной 0.9 от верха (tx, ty, tz) до низа (bx, by, bz). */
    private static void tail(PoseStack.Pose pose, VertexConsumer vc, int light, int overlay,
                             float tx, float ty, float tz, float bx, float by, float bz, float v0, float v1) {
        float hw = 0.45F;
        quad(pose, vc, light, overlay,
                tx - hw, ty, tz, tx + hw, ty, tz, bx + hw, by, bz, bx - hw, by, bz,
                0.1F, v0, 0.45F, v1);
    }

    private static void box(PoseStack.Pose pose, VertexConsumer vc, int light, int overlay,
                            float x0, float y0, float z0, float x1, float y1, float z1, float v0, float v1) {
        quad(pose, vc, light, overlay, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0.5F, v0, 0.62F, v1);
        quad(pose, vc, light, overlay, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, 0.62F, v0, 0.68F, v1);
        quad(pose, vc, light, overlay, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, 0.62F, v0, 0.68F, v1);
        quad(pose, vc, light, overlay, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0.7F, v0, 0.82F, v0 + 0.02F);
        quad(pose, vc, light, overlay, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, 0.7F, v0, 0.82F, v0 + 0.02F);
    }

    /** Четырёхугольник p0..p3 (пиксели модели), uv: p0 (u0, v0), p1 (u1, v0), p2 (u1, v1), p3 (u0, v1). */
    private static void quad(PoseStack.Pose pose, VertexConsumer vc, int light, int overlay,
                             float x0, float y0, float z0, float x1, float y1, float z1,
                             float x2, float y2, float z2, float x3, float y3, float z3,
                             float u0, float v0, float u1, float v1) {
        Vector3f n = new Vector3f(x1 - x0, y1 - y0, z1 - z0).cross(x3 - x0, y3 - y0, z3 - z0);
        if (n.lengthSquared() > 1.0E-12F) n.normalize();
        Vector3f tn = pose.transformNormal(n.x, n.y, n.z, new Vector3f());
        Matrix4f m = pose.pose();
        Vector3f p = new Vector3f();
        float s = 1.0F / 16.0F;
        float[][] pts = {{x0, y0, z0, u0, v0}, {x1, y1, z1, u1, v0}, {x2, y2, z2, u1, v1}, {x3, y3, z3, u0, v1}};
        for (float[] v : pts) {
            m.transformPosition(v[0] * s, v[1] * s, v[2] * s, p);
            vc.addVertex(p.x(), p.y(), p.z(), 0xFFFFFFFF, v[3], v[4], overlay, light, tn.x(), tn.y(), tn.z());
        }
    }
}
