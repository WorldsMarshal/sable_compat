package com.invfix.blindfold.client;

import com.invfix.blindfold.Blindfold;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import org.lwjgl.opengl.GL11;

/**
 * Повязка у своего игрока: экран чёрный — мир, рука, эффекты; от вида (F5) не зависит.
 * Интерфейс (хотбар, чат, экраны) поверх — виден.
 *
 * Сквозь повязку видно только Thermal Sense: пока он виден, кадр мира перед эффектами
 * очищается в чёрное (FxLevelRendererMixin → {@link #clearScene()}), из эффектов рисуется только
 * тепловизор (FxEffect#seenThroughBlindfold) — он строит картинку по глубине кадра и силуэтам тепла.
 * Без него поверх всего мира — чёрная заливка под интерфейсом.
 */
@OnlyIn(Dist.CLIENT)
public final class BlindfoldClient {

    private static boolean blind;

    private BlindfoldClient() {}

    /** Свой игрок в повязке. */
    public static boolean blind() {
        return blind;
    }

    /** Кадр мира — в чёрное (основной буфер, только цвет; глубина остаётся тепловизору). */
    public static void clearScene() {
        float[] previous = new float[4];
        GL11.glGetFloatv(GL11.GL_COLOR_CLEAR_VALUE, previous);
        Minecraft.getInstance().getMainRenderTarget().bindWrite(false);
        RenderSystem.clearColor(0.0F, 0.0F, 0.0F, 1.0F);
        RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT, Minecraft.ON_OSX);
        RenderSystem.clearColor(previous[0], previous[1], previous[2], previous[3]);
    }

    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
    public static final class GameBus {

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            blind = mc.player != null && mc.level != null && Blindfold.isWorn(mc.player);
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            blind = false;
        }

        /** Руки и предмета в руке не видно. */
        @SubscribeEvent(priority = EventPriority.HIGHEST)
        public static void onRenderHand(RenderHandEvent event) {
            if (blind) event.setCanceled(true);
        }
    }

    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
    public static final class ModBus {

        @SubscribeEvent
        public static void onRegisterGuiLayers(RegisterGuiLayersEvent event) {
            event.registerBelowAll(ResourceLocation.fromNamespaceAndPath("sable_compat", "blindfold"), (graphics, delta) -> {
                if (!blind || com.invfix.thermal.client.ThermalClient.viewVisible()) return;
                graphics.fill(0, 0, graphics.guiWidth(), graphics.guiHeight(), 0xFF000000);
            });
        }

        @SubscribeEvent
        public static void onAddLayers(EntityRenderersEvent.AddLayers event) {
            event.getSkins().forEach(skin -> {
                if (event.getSkin(skin) instanceof PlayerRenderer renderer) {
                    renderer.addLayer(new BlindfoldLayer(renderer));
                }
            });
        }
    }
}
