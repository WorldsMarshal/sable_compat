package com.invfix.blindfold;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.capabilities.EntityCapability;

import java.lang.reflect.Method;
import java.util.Map;

/**
 * Надета ли повязка: слот шлема или любой слот Curios (как Create ищет очки — Curios#init:
 * CuriosCapability.INVENTORY → ICuriosItemHandler#getCurios → ICurioStacksHandler#getStacks).
 * Curios — через рефлексию: без него мод не зависит от его классов.
 */
public final class Blindfold {

    private static Boolean curiosLoaded;
    private static EntityCapability<Object, Void> curiosInventory;
    private static Method getCurios, getSlots, getStacks, getStackInSlot;
    private static boolean curiosBroken;

    private Blindfold() {}

    public static boolean isBlindfold(ItemStack stack) {
        return !stack.isEmpty() && stack.is(BlindfoldRegistry.BLINDFOLD.get());
    }

    public static boolean isWorn(LivingEntity entity) {
        if (entity == null) return false;
        if (isBlindfold(entity.getItemBySlot(EquipmentSlot.HEAD))) return true;
        return inCurios(entity);
    }

    /** Метод из публичного интерфейса класса (у реализации класс может быть закрытым). */
    private static Method publicMethod(Class<?> type, String name, Class<?>... params) throws NoSuchMethodException {
        for (Class<?> c = type; c != null; c = c.getSuperclass()) {
            for (Class<?> i : c.getInterfaces()) {
                Method m = interfaceMethod(i, name, params);
                if (m != null) return m;
            }
        }
        return type.getMethod(name, params);
    }

    private static Method interfaceMethod(Class<?> i, String name, Class<?>... params) {
        try {
            if (java.lang.reflect.Modifier.isPublic(i.getModifiers())) return i.getMethod(name, params);
        } catch (NoSuchMethodException ignored) {}
        for (Class<?> parent : i.getInterfaces()) {
            Method m = interfaceMethod(parent, name, params);
            if (m != null) return m;
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private static boolean inCurios(LivingEntity entity) {
        if (curiosLoaded == null) curiosLoaded = ModList.get().isLoaded("curios");
        if (!curiosLoaded || curiosBroken) return false;
        try {
            if (curiosInventory == null) {
                Class<?> cap = Class.forName("top.theillusivec4.curios.api.CuriosCapability");
                curiosInventory = (EntityCapability<Object, Void>) cap.getField("INVENTORY").get(null);
                getCurios = Class.forName("top.theillusivec4.curios.api.type.capability.ICuriosItemHandler")
                        .getMethod("getCurios");
                Class<?> stacksHandler = Class.forName("top.theillusivec4.curios.api.type.inventory.ICurioStacksHandler");
                getSlots = stacksHandler.getMethod("getSlots");
                getStacks = stacksHandler.getMethod("getStacks");
            }
            Object handler = entity.getCapability(curiosInventory);
            if (handler == null) return false;
            Map<?, ?> curios = (Map<?, ?>) getCurios.invoke(handler);
            for (Object stacksHandler : curios.values()) {
                int slots = (Integer) getSlots.invoke(stacksHandler);
                Object stacks = getStacks.invoke(stacksHandler);
                if (getStackInSlot == null) getStackInSlot = publicMethod(stacks.getClass(), "getStackInSlot", int.class);
                for (int slot = 0; slot < slots; slot++) {
                    if (isBlindfold((ItemStack) getStackInSlot.invoke(stacks, slot))) return true;
                }
            }
            return false;
        } catch (Throwable t) {
            curiosBroken = true;
            return false;
        }
    }
}
