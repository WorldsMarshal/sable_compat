package com.invfix.jade;

import com.invfix.shapeshift.MorphInstances;
import net.minecraft.resources.ResourceLocation;
import snownee.jade.api.EntityAccessor;
import snownee.jade.api.IEntityComponentProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.JadeIds;
import snownee.jade.api.config.IPluginConfig;

/**
 * Shapeshifter: у игрока в морфе Jade показывает куклу моба ({@link MorphJade}); броню
 * в тултипе прячем — она бы выдавала игрока. Работает после ванильного провайдера
 * здоровья и брони (у него приоритет -4500).
 */
public enum HideMorphArmorProvider implements IEntityComponentProvider {
    INSTANCE;

    public static final ResourceLocation UID =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "hide_morph_armor");

    @Override
    public void appendTooltip(ITooltip tooltip, EntityAccessor accessor, IPluginConfig config) {
        if (MorphInstances.isMorphInstance(accessor.getEntity())) tooltip.remove(JadeIds.MC_ENTITY_ARMOR);
    }

    @Override
    public ResourceLocation getUid() {
        return UID;
    }

    @Override
    public boolean isRequired() {
        return true;
    }

    @Override
    public int getDefaultPriority() {
        return 5000;
    }
}
