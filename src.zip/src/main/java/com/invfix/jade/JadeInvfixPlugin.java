package com.invfix.jade;

import net.minecraft.world.entity.player.Player;
import snownee.jade.api.IWailaClientRegistration;
import snownee.jade.api.IWailaPlugin;
import snownee.jade.api.WailaPlugin;

/**
 * Совместимость с модом Jade.
 *
 * Jade сам сканирует все моды на наличие классов с аннотацией {@link WailaPlugin}
 * и создаёт их экземпляры ТОЛЬКО если сам Jade загружен
 * ({@code CommonProxy}: перебирает scan-data и инстанцирует плагины). Если Jade
 * отсутствует — этот класс (и {@link HidePlayerHealthProvider}) вообще никогда
 * не грузится в JVM, поэтому ссылки на API Jade ничего не ломают. Это и даёт
 * полностью необязательную (compileOnly) зависимость без падений.
 *
 * Пустое {@code value()} аннотации означает "грузить, когда загружен Jade".
 * Гейтить по нашему modId не нужно: аннотация физически лежит внутри нашего
 * мода, так что она и так присутствует в scan-data только когда мы установлены.
 */
@WailaPlugin
public class JadeInvfixPlugin implements IWailaPlugin {

    @Override
    public void registerClient(IWailaClientRegistration registration) {
        // Провайдер вешаем строго на Player.class — мобов это не касается,
        // у них ХП в тултипе Jade остаётся как было.
        registration.registerEntityComponent(HidePlayerHealthProvider.INSTANCE, Player.class);
    }
}