package com.invfix.jade;

import net.minecraft.resources.ResourceLocation;
import snownee.jade.api.EntityAccessor;
import snownee.jade.api.IEntityComponentProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.JadeIds;
import snownee.jade.api.config.IPluginConfig;

/**
 * Прячет полоску/строку ХП у ИГРОКА в тултипе Jade.
 *
 * Зачем: для баланса не должно быть видно, сколько у игрока хитпоинтов — иначе
 * по числу ХП сразу читается раса. На обычных мобов это не влияет (провайдер
 * зарегистрирован только на {@code Player.class}).
 *
 * Как: ванильный провайдер Jade добавляет элемент здоровья с тегом
 * {@link JadeIds#MC_ENTITY_HEALTH} и приоритетом -4500. Провайдеры сортируются
 * по приоритету ПО ВОЗРАСТАНИЮ, а у нас приоритет по умолчанию 0 (> -4500),
 * значит мы отрабатываем ПОСЛЕ него и просто вырезаем уже добавленную строку
 * через {@link ITooltip#remove(ResourceLocation)} (удаление идёт по тегу).
 *
 * {@code isRequired()} = true — провайдер форсированный, его нельзя выключить в
 * конфиге Jade, чтобы клиент не мог одним тумблером вернуть себе показ ХП.
 * Само скрытие клиентское (Jade рисует тултип на клиенте).
 */
public enum HidePlayerHealthProvider implements IEntityComponentProvider {
    INSTANCE;

    public static final ResourceLocation UID =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "hide_player_health");

    @Override
    public void appendTooltip(ITooltip tooltip, EntityAccessor accessor, IPluginConfig config) {
        // Цель гарантированно игрок (регистрация на Player.class) — просто
        // убираем строку здоровья, добавленную ванильным провайдером.
        tooltip.remove(JadeIds.MC_ENTITY_HEALTH);
    }

    @Override
    public ResourceLocation getUid() {
        return UID;
    }

    @Override
    public boolean isRequired() {
        return true;
    }
}