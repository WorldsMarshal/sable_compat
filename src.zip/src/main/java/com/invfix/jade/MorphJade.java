package com.invfix.jade;

import com.invfix.shapeshift.MorphState;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import snownee.jade.api.Accessor;
import snownee.jade.api.EntityAccessor;
import snownee.jade.api.IWailaClientRegistration;

/**
 * Shapeshifter: игрок в морфе для Jade — это его моб. Навёл на игрока-лису — видишь
 * «Лиса», сердечки лисы и мод Minecraft, как у настоящей лисы. Цель подменяется на
 * куклу морфа ещё на этапе рейкаста (всё остальное Jade берёт уже из неё). Морф игрока —
 * кукла-игрок: ник убитого, ХП скрыто, как у всех игроков (HidePlayerHealthProvider).
 */
final class MorphJade {

    private MorphJade() {}

    static Accessor<?> swap(IWailaClientRegistration registration, Accessor<?> accessor) {
        if (!(accessor instanceof EntityAccessor ea) || !(ea.getEntity() instanceof Player player)) return accessor;
        MorphState st = MorphState.get(player);
        if (st == null || !st.active()) return accessor;
        LivingEntity instance = st.current != null ? st.currentInstance(player)
                : st.prev != null ? st.prevInstance(player) : null;
        if (instance == null) return accessor;
        // serverConnected(false): кукла есть только у клиента. Если у типа моба есть серверные
        // провайдеры Jade (возраст, хозяин и т.п.), Jade ждал бы ответа сервера по этой
        // сущности — а сервер её не знает, ответа нет, и тултип не появлялся бы совсем.
        return registration.entityAccessor().from(ea).entity(instance).serverConnected(false).build();
    }
}
