package com.invfix.rick;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import java.util.function.Supplier;

/**
 * Реестр танков Rick C137. Своего MenuType нет намеренно: панель живёт внутри
 * ванильного InventoryMenu, чтобы не терять книгу рецептов и кнопки других модов.
 */
public final class RickRegistry {

    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS =
            DeferredRegister.create(NeoForgeRegistries.Keys.ATTACHMENT_TYPES, "sable_compat");

    /**
     * Танки переживают смерть — терять 1500 B из-за криперов Рику незачем.
     *
     * Явная лямбда вместо {@code RickTanks::new} тут не косметика: у
     * {@code AttachmentType.builder} перегрузки под Supplier и под
     * Function&lt;IAttachmentHolder, T&gt;, и ссылка на конструктор оставляет
     * компилятору выбор между ними. Лямбда без аргументов подходит только под
     * Supplier, поэтому перегрузка определяется однозначно.
     */
    public static final Supplier<AttachmentType<RickTanks>> TANKS =
            ATTACHMENTS.register("rick_tanks", () -> AttachmentType
                    .<RickTanks>builder(() -> new RickTanks())
                    .serialize(RickTanks.CODEC)
                    .copyOnDeath()
                    .build());

    private RickRegistry() {}

    public static void register(IEventBus modEventBus) {
        ATTACHMENTS.register(modEventBus);
    }
}