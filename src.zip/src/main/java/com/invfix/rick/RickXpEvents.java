package com.invfix.rick;

import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingExperienceDropEvent;
import net.neoforged.neoforge.event.level.BlockDropsEvent;

/**
 * Опыт Rick C137: x20 с добычи ресурсов, x1.5 с убийства мобов.
 *
 * Для блоков берётся именно {@link BlockDropsEvent}, а не BlockEvent.BreakEvent:
 * в NeoForge 1.21 опыт из BreakEvent убрали, он теперь приходит вместе с дропом
 * из Block.dropResources. Ломающий передаётся как Entity, поэтому проверяем тип —
 * блок могло разрушить что угодно, не только игрок.
 *
 * Плавка в печи сюда НЕ входит: там опыт начисляется от рецепта при вынимании
 * результата, игрок событию в этот момент не известен.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class RickXpEvents {

    public static final int MINING_MULTIPLIER = 20;
    public static final float MOB_MULTIPLIER = 1.5F;

    private RickXpEvents() {}

    /** Опыт из руды, спавнера и прочих блоков, что его роняют. */
    @SubscribeEvent
    public static void onBlockDrops(BlockDropsEvent event) {
        if (!(event.getBreaker() instanceof Player player)) return;
        if (!RickBloodline.is(player)) return;

        int xp = event.getDroppedExperience();
        if (xp <= 0) return;
        event.setDroppedExperience(clamp((long) xp * MINING_MULTIPLIER));
    }

    /** Опыт с моба — только если добил именно Рик. */
    @SubscribeEvent
    public static void onMobExperience(LivingExperienceDropEvent event) {
        Player player = event.getAttackingPlayer();
        if (!RickBloodline.is(player)) return;

        int xp = event.getDroppedExperience();
        if (xp <= 0) return;
        event.setDroppedExperience(clamp(Math.round(xp * MOB_MULTIPLIER)));
    }

    /** x20 на жирном блоке может переполнить int — режем по потолку. */
    private static int clamp(long value) {
        return (int) Math.min(value, Integer.MAX_VALUE);
    }
}