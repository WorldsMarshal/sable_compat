package com.invfix.rick.timedevice;

import com.invfix.timestop.TimeStopInstance;
import com.invfix.timestop.TimeStopManager;
import com.invfix.timestop.TimeStopTier;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Пульт остановки времени Rick C137.
 *
 * Уровень {@link TimeStopTier#DEVICE} — нижний. Всё межуровневое поведение
 * задаёт не этот класс, а TimeStopManager: пульт перебивает чужую
 * устройственную зону при активации, с остановкой Metroman не пересекается
 * никак.
 *
 * ПКМ — включить, ПКМ ещё раз — снять. Кулдаун секунда, он только от
 * дребезга. Настоящий ограничитель — энергия: зона бессрочная и держится,
 * пока в пульте есть заряд. 30 млн FE при расходе 100 тыс. в секунду — это
 * ровно пять минут остановленного времени с полного бака.
 */
public class TimeDeviceItem extends Item {

    /** Ёмкость, FE. */
    public static final int CAPACITY = 30_000_000;
    /** Расход за тик активной зоны: 100 000 FE в секунду. */
    public static final int DRAIN_PER_TICK = 5_000;
    /** Кулдаун между нажатиями, тиков. Только от дребезга, не ограничитель. */
    public static final int COOLDOWN_TICKS = 20;
    /** Радиус в чанках, чебышёв. Столько же, сколько у Metroman. */
    public static int chunkRange = 12;

    public TimeDeviceItem(Properties props) {
        super(props);
    }

    public static int energy(ItemStack stack) { return ItemEnergy.get(stack, CAPACITY); }

    /** id зоны, которую держит ЭТОТ стек, либо -1. */
    public static int boundZone(ItemStack stack) {
        Integer id = stack.get(TimeDeviceRegistry.ACTIVE_ZONE.get());
        return id == null ? -1 : id;
    }

    public static void bind(ItemStack stack, int zoneId) {
        if (zoneId < 0) stack.remove(TimeDeviceRegistry.ACTIVE_ZONE.get());
        else stack.set(TimeDeviceRegistry.ACTIVE_ZONE.get(), zoneId);
    }

    /**
     * Найти в инвентаре пульт, привязанный к этой зоне, попутно сняв
     * протухшие привязки с остальных.
     *
     * Протухшие берутся вот откуда: пульт выкинули, зона снялась, а компонент
     * на стеке остался. id зон нумеруются с нуля при каждом запуске сервера,
     * так что в другой сессии такой же id может достаться другой зоне — и
     * тогда платил бы не тот пульт. Раз уж мы всё равно идём по инвентарю,
     * чистим по дороге.
     *
     * @return стек, держащий зону, либо null — тогда держать её больше нечем
     */
    public static @Nullable ItemStack findBound(Player player, int zoneId) {
        var inv = player.getInventory();
        final int size = inv.getContainerSize();
        ItemStack found = null;
        for (int i = 0; i < size; i++) {
            ItemStack s = inv.getItem(i);
            if (!(s.getItem() instanceof TimeDeviceItem)) continue;
            int bound = boundZone(s);
            if (bound < 0) continue;
            if (bound == zoneId && found == null) found = s;
            else bind(s, -1);
        }
        return found;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            // Шифт — мгновенная остановка. Цель берёт клиент из своего прицела
            // и шлёт серверу, как в ROTP; сервер у себя в use() для неё ничего
            // не делает, см. ниже.
            if (player.isShiftKeyDown()) {
                com.invfix.timestop.blink.TimeStopBlinkClientHook.requestDeviceBlink(hand);
            }
            return InteractionResultHolder.success(stack);
        }
        if (!(level instanceof ServerLevel serverLevel)) return InteractionResultHolder.pass(stack);

        // Своя зона висит — снимаем. С шифтом или без: в ROTP шифт с кнопкой
        // при своей остановке — это именно снятие (TimeResume). Кулдаун проверяется ПОСЛЕ этой ветки:
        // выключить пульт можно всегда.
        TimeStopInstance own = TimeStopManager.ownedBy(serverLevel, player.getId());
        if (own != null) {
            TimeStopManager.stopOwnedBy(serverLevel, player.getId());
            bind(stack, -1);
            player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
            sound(serverLevel, player, false);
            player.displayClientMessage(
                    Component.translatable("message.sable_compat.time_device.off")
                            .withStyle(ChatFormatting.GRAY), true);
            return InteractionResultHolder.success(stack);
        }

        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }

        // Шифт без своей зоны — мгновенная остановка, её выполнит пакет от
        // клиента с целью из прицела (blink ниже). Здесь делать нечего.
        if (player.isShiftKeyDown()) {
            return InteractionResultHolder.success(stack);
        }

        if (energy(stack) < DRAIN_PER_TICK) {
            player.displayClientMessage(
                    Component.translatable("message.sable_compat.time_device.no_energy")
                            .withStyle(ChatFormatting.RED), true);
            return InteractionResultHolder.fail(stack);
        }

        // Привязка могла остаться от прошлой зоны — например, пульт выкинули
        // и подобрали обратно. Затираем, чтобы не спутать со свежей.
        bind(stack, -1);

        // Зона бессрочная: её снимают энергия и присутствие пульта в
        // инвентаре, см. TimeDeviceEvents, а не таймер.
        TimeStopInstance inst = TimeStopManager.start(serverLevel, player,
                0, chunkRange, true, TimeStopTier.DEVICE);
        if (inst == null) {
            // Отказ по уровню или по лимиту зон. Кулдаун не жжём.
            player.displayClientMessage(
                    Component.translatable("message.sable_compat.time_device.rejected")
                            .withStyle(ChatFormatting.RED), true);
            return InteractionResultHolder.fail(stack);
        }

        bind(stack, inst.id);
        player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
        sound(serverLevel, player, true);
        return InteractionResultHolder.success(stack);
    }

    // ── пульт как пассивная защита ─────────────────────────────────────────

    /**
     * Суммарный заряд всех пультов в инвентаре.
     *
     * Иммунитет пульт даёт не только из руки: он списан с сериала, где Рик не
     * замер в остановке злого Морти, хотя на свой пульт не жал. Значит,
     * достаточно того, что прибор при тебе и запитан.
     *
     * Обход через Container-интерфейс инвентаря, а не по полям items/offhand:
     * getContainerSize + getItem покрывают и сетку, и броню, и левую руку.
     */
    public static int totalEnergy(Player player) {
        var inv = player.getInventory();
        final int size = inv.getContainerSize();
        long sum = 0;
        for (int i = 0; i < size; i++) {
            ItemStack s = inv.getItem(i);
            if (s.getItem() instanceof TimeDeviceItem) sum += energy(s);
        }
        return (int) Math.min(sum, Integer.MAX_VALUE);
    }

    /** Снять указанное количество с пультов игрока, по очереди. */
    public static int drainFrom(Player player, int amount) {
        var inv = player.getInventory();
        final int size = inv.getContainerSize();
        int left = amount;
        for (int i = 0; i < size && left > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (s.getItem() instanceof TimeDeviceItem) {
                left -= ItemEnergy.drain(s, left, CAPACITY);
            }
        }
        return amount - left;
    }

    // ── мгновенная остановка ───────────────────────────────────────────────

    /**
     * Цена одного подразумеваемого тика мгновенной остановки, FE.
     *
     * В ROTP мгновенная остановка стоит 0.8 от поддержания обычной
     * (TimeStopInstant#getStaminaCostTicking = TimeStop#getStaminaCostTicking
     * · 0.8) за каждый подразумеваемый тик. У пульта поддержание — это
     * DRAIN_PER_TICK, отсюда 5000 · 0.8 = 4000 FE за тик.
     */
    public static final int BLINK_COST_PER_TICK = (int) (DRAIN_PER_TICK * 0.8F);

    /**
     * Мгновенная остановка пультом. Вызывается из пакета клиента.
     *
     * Как в ROTP, заряд не запрещает рывок, а укорачивает его: потолок
     * подразумеваемых тиков — сколько тиков оплачивает заряд
     * (getMaxImpliedTicks ограничен стаминой), дальность — скорость, умноженная
     * на это число, но не больше 192. Списывается ровно за пройденное.
     *
     * Отличие от ROTP одно: там потолок не опускается ниже пяти тиков — стамина
     * может уйти в долг. Заряд в долг не уходит, поэтому здесь нижней планки
     * нет, а без заряда хотя бы на тик рывка не будет.
     */
    public static boolean blink(net.minecraft.server.level.ServerPlayer player, InteractionHand hand,
                                com.invfix.timestop.blink.BlinkTarget target) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(stack.getItem() instanceof TimeDeviceItem self)) return false;
        if (player.getCooldowns().isOnCooldown(self)) return false;
        if (!com.invfix.timestop.blink.TimeStopBlink.allowedAt(player)) return false;

        int maxTicks = energy(stack) / BLINK_COST_PER_TICK;
        if (maxTicks < 1) {
            player.displayClientMessage(
                    Component.translatable("message.sable_compat.time_device.no_energy")
                            .withStyle(ChatFormatting.RED), true);
            return false;
        }

        var plan = com.invfix.timestop.blink.TimeStopBlink.plan(player, target, maxTicks);
        ItemEnergy.drain(stack, plan.impliedTicks() * BLINK_COST_PER_TICK, CAPACITY);
        com.invfix.timestop.blink.TimeStopBlink.perform(player, plan);
        player.getCooldowns().addCooldown(self, COOLDOWN_TICKS);
        return true;
    }

    private static void sound(ServerLevel level, Player player, boolean on) {
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                on ? SoundEvents.BEACON_ACTIVATE : SoundEvents.BEACON_DEACTIVATE,
                SoundSource.PLAYERS, 0.4F, on ? 1.6F : 1.2F);
    }

    // ── полоса заряда на иконке ────────────────────────────────────────────

    @Override public boolean isBarVisible(ItemStack stack) { return energy(stack) < CAPACITY; }

    @Override public int getBarWidth(ItemStack stack) {
        return Math.round(13.0F * energy(stack) / CAPACITY);
    }

    @Override public int getBarColor(ItemStack stack) { return 0x46D95A; }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        lines.add(Component.translatable("tooltip.sable_compat.time_device.energy",
                        ItemEnergy.format(energy(stack)), ItemEnergy.format(CAPACITY))
                .withStyle(ChatFormatting.GREEN));
        lines.add(Component.translatable("tooltip.sable_compat.time_device.drain",
                        ItemEnergy.format(DRAIN_PER_TICK * 20))
                .withStyle(ChatFormatting.GRAY));
        lines.add(Component.translatable("tooltip.sable_compat.time_device.runtime",
                        energy(stack) / (DRAIN_PER_TICK * 20))
                .withStyle(ChatFormatting.GRAY));
        lines.add(Component.translatable("tooltip.sable_compat.time_device.tier")
                .withStyle(ChatFormatting.DARK_AQUA));
        lines.add(Component.translatable("tooltip.sable_compat.time_device.range", chunkRange)
                .withStyle(ChatFormatting.GRAY));
        lines.add(Component.translatable("tooltip.sable_compat.time_device.shield")
                .withStyle(ChatFormatting.DARK_AQUA));
        lines.add(Component.translatable("tooltip.sable_compat.time_device.hint")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
