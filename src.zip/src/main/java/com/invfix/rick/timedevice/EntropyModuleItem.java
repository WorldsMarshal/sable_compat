package com.invfix.rick.timedevice;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * Энтропийный модуль.
 *
 * Активации нет вообще: пока он в инвентаре и в нём есть заряд, носитель не
 * замирает в чужой остановке времени. Расход тот же, что у пульта —
 * 100 000 FE в секунду, но только пока модуль реально работает, то есть пока
 * носитель стоит в чужой остановке.
 *
 * Несколько модулей складываются в общий бак: расход снимается по очереди,
 * поэтому два модуля дают вдвое больше защищённого времени, а не вдвое
 * больший расход. Списанием занимается {@link TimeDeviceEvents} — по игроку
 * целиком, а не по каждому стеку, именно ради этого.
 *
 * Основное применение всё-таки не защита, а крафт: модуль входит в рецепт
 * пульта.
 */
public class EntropyModuleItem extends Item {

    /** Ёмкость, FE. */
    public static final int CAPACITY = 10_000_000;
    /** Расход за тик работы: 100 000 FE в секунду. 100 секунд с полного модуля. */
    public static final int DRAIN_PER_TICK = 5_000;

    public EntropyModuleItem(Properties props) {
        super(props);
    }

    public static int energy(ItemStack stack) { return ItemEnergy.get(stack, CAPACITY); }

    // ── полоса заряда на иконке ────────────────────────────────────────────

    @Override public boolean isBarVisible(ItemStack stack) { return energy(stack) < CAPACITY; }

    @Override public int getBarWidth(ItemStack stack) {
        return Math.round(13.0F * energy(stack) / CAPACITY);
    }

    @Override public int getBarColor(ItemStack stack) { return 0x9A5CE8; }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        lines.add(Component.translatable("tooltip.sable_compat.entropy_module.energy",
                        ItemEnergy.format(energy(stack)), ItemEnergy.format(CAPACITY))
                .withStyle(ChatFormatting.LIGHT_PURPLE));
        lines.add(Component.translatable("tooltip.sable_compat.entropy_module.drain",
                        ItemEnergy.format(DRAIN_PER_TICK * 20))
                .withStyle(ChatFormatting.GRAY));
        lines.add(Component.translatable("tooltip.sable_compat.entropy_module.runtime",
                        energy(stack) / (DRAIN_PER_TICK * 20))
                .withStyle(ChatFormatting.GRAY));
        lines.add(Component.translatable("tooltip.sable_compat.entropy_module.passive")
                .withStyle(ChatFormatting.DARK_PURPLE));
        lines.add(Component.translatable("tooltip.sable_compat.entropy_module.stacking")
                .withStyle(ChatFormatting.DARK_GRAY));
    }

    // ── работа с инвентарём ────────────────────────────────────────────────

    /**
     * Суммарный заряд всех модулей в инвентаре.
     *
     * Обход через Container-интерфейс инвентаря, а не по полям items/offhand:
     * getContainerSize + getItem покрывают и основную сетку, и броню, и левую
     * руку одним циклом, и это методы интерфейса, а не публичные поля ванили.
     */
    public static int totalEnergy(Player player) {
        var inv = player.getInventory();
        final int size = inv.getContainerSize();
        long sum = 0;
        for (int i = 0; i < size; i++) {
            ItemStack s = inv.getItem(i);
            if (s.getItem() instanceof EntropyModuleItem) sum += energy(s);
        }
        return (int) Math.min(sum, Integer.MAX_VALUE);
    }

    /**
     * Снять указанное количество с модулей игрока, по очереди — в этом и
     * состоит «несколько модулей учитываются»: расход общий, а не по модулю.
     * @return сколько реально сняли
     */
    public static int drainFrom(Player player, int amount) {
        var inv = player.getInventory();
        final int size = inv.getContainerSize();
        int left = amount;
        for (int i = 0; i < size && left > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (s.getItem() instanceof EntropyModuleItem) {
                left -= ItemEnergy.drain(s, left, CAPACITY);
            }
        }
        return amount - left;
    }
}
