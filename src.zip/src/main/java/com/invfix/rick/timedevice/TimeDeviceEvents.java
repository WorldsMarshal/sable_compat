package com.invfix.rick.timedevice;

import com.invfix.timestop.TimeStopInstance;
import com.invfix.timestop.TimeStopManager;
import com.invfix.timestop.TimeStopTier;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Обслуживание зоны пульта и плата за пассивную защиту — всё, что нужно
 * делать каждый тик по игроку, а не по предмету.
 *
 * Почему не в {@code Item#inventoryTick}: этот метод перестаёт вызываться в
 * ту же секунду, когда предмет покидает инвентарь. Пульт, выкинутый во время
 * остановки, переставал списывать заряд, а зона оставалась — и снять её было
 * уже нечем. Вдобавок выпавший ItemEntity сам попадал в остановку и замирал,
 * так что «дотикать» он тоже не мог. Отсюда вечная остановка.
 *
 * Теперь инвариант простой и проверяется каждый тик у владельца: зона уровня
 * DEVICE живёт ровно до тех пор, пока в инвентаре владельца лежит привязанный
 * к ней пульт с зарядом. Пропал пульт — зона снимается на следующем тике, то
 * есть мгновенно с точки зрения игрока.
 *
 * Тик владельца идёт всегда: владелец зоны в своей остановке не заморожен.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class TimeDeviceEvents {

    private TimeDeviceEvents() {}

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(player.level() instanceof ServerLevel level)) return;

        // Дешёвая отсечка: в измерении вообще нет зон.
        if (!TimeStopManager.hasAny(level)) return;

        TimeStopInstance own = TimeStopManager.ownedBy(level, player.getId());
        if (own != null) {
            // Своя зона. За защиту владелец не платит — платит сама зона.
            if (own.tierRank == TimeStopTier.DEVICE.rank) {
                upkeep(level, player, own);
            }
            return;
        }

        // Чужая зона накрыла — платим за пассивную защиту, если она есть.
        if (!TimeStopManager.isInside(player)) return;

        int left = EntropyModuleItem.DRAIN_PER_TICK;
        left -= EntropyModuleItem.drainFrom(player, left);
        if (left > 0) TimeDeviceItem.drainFrom(player, left);
    }

    /**
     * Содержание своей устройственной зоны: пульт на месте и заряд есть.
     * Любое «нет» снимает зону здесь же.
     */
    private static void upkeep(ServerLevel level, ServerPlayer player, TimeStopInstance own) {
        ItemStack remote = TimeDeviceItem.findBound(player, own.id);

        if (remote == null) {
            // Выкинули, убрали в сундук, отдали, умерли и вещи выпали,
            // удалили в креативе. Держать зону нечем.
            stop(level, player, "message.sable_compat.time_device.lost");
            return;
        }

        int taken = ItemEnergy.drain(remote, TimeDeviceItem.DRAIN_PER_TICK, TimeDeviceItem.CAPACITY);
        if (taken >= TimeDeviceItem.DRAIN_PER_TICK) {
            // Пульт на месте и заряжен — подтверждаем зону. Молчание дольше
            // upkeepGraceTicks снимет её сторож, даже если мы сюда почему-то
            // перестали попадать.
            TimeStopManager.heartbeat(level, own);
            return;
        }

        TimeDeviceItem.bind(remote, -1);
        stop(level, player, "message.sable_compat.time_device.drained");
    }

    private static void stop(ServerLevel level, ServerPlayer player, String message) {
        TimeStopManager.stopOwnedBy(level, player.getId());
        player.getCooldowns().addCooldown(
                TimeDeviceRegistry.TIME_DEVICE.get(), TimeDeviceItem.COOLDOWN_TICKS);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.4F, 1.2F);
        player.displayClientMessage(
                Component.translatable(message).withStyle(ChatFormatting.RED), true);
    }
}
