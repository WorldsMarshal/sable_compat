package com.invfix.rick.timedevice;

import com.invfix.timestop.TimeStopExemptions;
import com.invfix.timestop.TimeStopTier;
import com.mojang.serialization.Codec;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Реестр пульта остановки времени и энтропийного модуля.
 *
 * Эксклюзивность Рика у пульта берётся не из кода, а из рецепта: он лежит в
 * {@code sable_compat:precision} с {@code tier 137}, станков такого тира в
 * сборке нет (ультрапрецизионный — второй), а карманный резолвер Рика тир не
 * проверяет. Тот же приём, что у энергокуба и портальной пушки.
 *
 * У модуля рецепта два: тир 2, очень тяжёлый — для всех, и тир 3, почти
 * даровой — для Рика. Так же устроена пара aesa_array / rick_aesa_array.
 */
public final class TimeDeviceRegistry {

    private static final String MODID = "sable_compat";

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<DataComponentType<?>> COMPONENTS =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, MODID);

    /**
     * id зоны, которую держит конкретный стек пульта.
     *
     * Нужен, чтобы заряд тратил тот пульт, которым включили, а не любой в
     * инвентаре. Синхронизируется, потому что от него зависит подсказка.
     */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> ACTIVE_ZONE =
            COMPONENTS.register("time_device_zone", () -> DataComponentType.<Integer>builder()
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT)
                    .build());

    public static final DeferredItem<TimeDeviceItem> TIME_DEVICE =
            ITEMS.register("rick_time_device",
                    () -> new TimeDeviceItem(new Item.Properties().stacksTo(1).fireResistant()));

    /**
     * Модуль не стакается: заряд живёт в компоненте стека, а стакать вещи с
     * разным зарядом нельзя — ваниль считала бы их разными предметами и
     * инвентарь забился бы стаками по одному.
     */
    public static final DeferredItem<EntropyModuleItem> ENTROPY_MODULE =
            ITEMS.register("entropy_module",
                    () -> new EntropyModuleItem(new Item.Properties().stacksTo(1).fireResistant()));

    private TimeDeviceRegistry() {}

    public static void register(IEventBus modEventBus) {
        COMPONENTS.register(modEventBus);
        ITEMS.register(modEventBus);
        modEventBus.addListener(TimeDeviceRegistry::onRegisterCapabilities);
        modEventBus.addListener(TimeDeviceRegistry::onBuildCreativeTabs);

        // Носитель пульта не замирает в чужой остановке — где бы пульт ни
        // лежал, лишь бы был заряжен. Так это и в сериале: Рик не замер в
        // остановке злого Морти, хотя на свой пульт не жал. Заряд за это
        // списывается, см. TimeDeviceEvents.
        TimeStopExemptions.register("rick_time_device", TimeStopTier.DEVICE, (player, vars) ->
                TimeDeviceItem.totalEnergy(player) >= TimeDeviceItem.DRAIN_PER_TICK);

        // Энтропийный модуль: активации нет, достаточно лежать в инвентаре с
        // зарядом. Расход снимает TimeDeviceEvents.
        TimeStopExemptions.register("entropy_module", TimeStopTier.DEVICE, (player, vars) ->
                EntropyModuleItem.totalEnergy(player) >= EntropyModuleItem.DRAIN_PER_TICK);
    }

    /**
     * Оба предмета отдают {@code Capabilities.EnergyStorage.ITEM} — именно её
     * ищет любая зарядная станция на FE, поэтому отдельной поддержки под
     * каждый зарядник не нужно.
     */
    private static void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
        event.registerItem(Capabilities.EnergyStorage.ITEM,
                (stack, ctx) -> new ItemEnergy(stack, TimeDeviceItem.CAPACITY),
                TIME_DEVICE.get());
        event.registerItem(Capabilities.EnergyStorage.ITEM,
                (stack, ctx) -> new ItemEnergy(stack, EntropyModuleItem.CAPACITY),
                ENTROPY_MODULE.get());
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(TIME_DEVICE);
        }
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(ENTROPY_MODULE);
        }
    }
}
