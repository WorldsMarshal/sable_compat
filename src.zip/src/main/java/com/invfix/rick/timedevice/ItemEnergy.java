package com.invfix.rick.timedevice;

import com.invfix.rick.cube.RickCubeRegistry;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * Энергохранилище поверх компонента предмета — общая половина пульта и
 * энтропийного модуля.
 *
 * Компонент переиспользуется чужой: {@code sable_compat:stored_energy}, тот же,
 * что у энергокуба. Заводить свой смысла нет — это просто int на стеке, а
 * общий делает предметы взаимозаменяемыми для всего, что читает заряд.
 *
 * Класс реализует {@link IEnergyStorage}, поэтому предметы принимает ЛЮБАЯ
 * зарядная станция на FE: она ищет ровно эту capability на стеке
 * ({@code Capabilities.EnergyStorage.ITEM}), регистрация — в
 * {@link TimeDeviceRegistry}.
 */
public final class ItemEnergy implements IEnergyStorage {

    /**
     * Потолок за одну операцию приёма/выдачи. Ёмкости тут на порядки больше
     * куба (30 млн против 1.6 млн), и лимит куба в 10k за вызов растянул бы
     * зарядку на минуты. Станция всё равно отдаёт столько, сколько может сама.
     */
    public static final int MAX_TRANSFER = 1_000_000;

    private final ItemStack stack;
    private final int capacity;

    public ItemEnergy(ItemStack stack, int capacity) {
        this.stack = stack;
        this.capacity = capacity;
    }

    public static int get(ItemStack stack, int capacity) {
        Integer stored = stack.get(RickCubeRegistry.STORED_ENERGY.get());
        return stored == null ? 0 : Math.max(0, Math.min(stored, capacity));
    }

    public static void set(ItemStack stack, int value, int capacity) {
        stack.set(RickCubeRegistry.STORED_ENERGY.get(), Math.max(0, Math.min(value, capacity)));
    }

    /**
     * Снять со стека сколько получится, но не больше запрошенного.
     * @return сколько реально сняли
     */
    public static int drain(ItemStack stack, int amount, int capacity) {
        int current = get(stack, capacity);
        int taken = Math.min(current, amount);
        if (taken > 0) set(stack, current - taken, capacity);
        return taken;
    }

    @Override public int receiveEnergy(int max, boolean simulate) {
        int current = get(stack, capacity);
        int accepted = Math.min(Math.min(MAX_TRANSFER, max), capacity - current);
        if (!simulate && accepted > 0) set(stack, current + accepted, capacity);
        return accepted;
    }

    @Override public int extractEnergy(int max, boolean simulate) {
        int current = get(stack, capacity);
        int given = Math.min(Math.min(MAX_TRANSFER, max), current);
        if (!simulate && given > 0) set(stack, current - given, capacity);
        return given;
    }

    @Override public int getEnergyStored() { return get(stack, capacity); }
    @Override public int getMaxEnergyStored() { return capacity; }
    @Override public boolean canExtract() { return true; }
    @Override public boolean canReceive() { return true; }

    /** 30 000 000 -> «30.0M». Для подсказок. */
    public static String format(int fe) {
        if (fe >= 1_000_000) return String.format("%.1fM", fe / 1_000_000.0F);
        if (fe >= 1_000) return String.format("%.0fk", fe / 1_000.0F);
        return Integer.toString(fe);
    }
}
