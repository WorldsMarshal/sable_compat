package com.invfix.rick;

import net.minecraft.core.NonNullList;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.inventory.ResultContainer;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidUtil;
import net.neoforged.neoforge.items.wrapper.PlayerMainInvWrapper;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Вся начинка панели Рика: сетка 5x5 со своей выдачей, три слота для вёдер и
 * логика их обработки. Живёт внутри ванильного {@code InventoryMenu} — миксин
 * только создаёт этот объект и просит его добавить слоты.
 *
 * Слоты ДОБАВЛЯЮТСЯ ВСЕМ игрокам, но у не-Рика они неактивны: {@link Slot#isActive()}
 * возвращает false, поэтому экран их не рисует и не даёт по ним кликать, а
 * mayPlace/mayPickup закрывают путь и для подделанного клиента. Так индексы
 * слотов одинаковы на клиенте и сервере при любой родословной, и синхронизация
 * контейнера не разъезжается, когда родословную выдают или сбрасывают на лету.
 *
 * Ванильные индексы 0..45 не сдвигаются — наши идут следом, с 46.
 */
public class RickPocket {

    public static final int GRID = RickCraftingResolver.GRID;
    /** Один предмет в секунду. */
    public static final int DISSOLVE_PERIOD = 20;

    private final AbstractContainerMenu menu;
    private final Player owner;

    private final CraftingContainer grid;
    private final ResultContainer result = new ResultContainer();
    /** Слив: тара -> бак. */
    private final SimpleContainer drainSlots = new SimpleContainer(RickTanks.COUNT);
    /** Налив: бак -> тара. */
    private final SimpleContainer fillSlots = new SimpleContainer(RickTanks.COUNT);
    private final SimpleContainer dissolver = new SimpleContainer(1);

    private RickCraftingResolver.Resolved resolved = RickCraftingResolver.Resolved.EMPTY;
    /** Все варианты, подходящие под текущую сетку. */
    private List<RickCraftingResolver.Resolved> variants = List.of();
    private int variantIndex;
    /** Чтобы выбор не слетал, когда сетка меняется, но вариант остаётся. */
    private ItemStack lastPicked = ItemStack.EMPTY;
    /** Обратный отсчёт до следующего разложения. */
    private int dissolveCooldown;
    private List<FluidStack> lastSentTanks = null;

    public RickPocket(AbstractContainerMenu menu, Player owner) {
        this.menu = menu;
        this.owner = owner;
        this.grid = new TransientCraftingContainer(menu, GRID, GRID);
    }

    public Container grid() { return this.grid; }

    public boolean active() { return RickBloodline.is(owner); }

    // ================= слоты =================

    /** Порядок важен: выдача, затем 25 ячеек, затем 3 ведра. Индексы с 46. */
    public void addSlots(Consumer<Slot> sink) {
        sink.accept(new ResultSlot(RickPanel.RESULT_X, RickPanel.RESULT_Y));

        for (int r = 0; r < GRID; r++)
            for (int c = 0; c < GRID; c++)
                sink.accept(new GatedSlot(grid, r * GRID + c,
                        RickPanel.GRID_X + c * 18, RickPanel.GRID_Y + r * 18));

        for (int i = 0; i < RickTanks.COUNT; i++)
            sink.accept(new FluidSlot(drainSlots, i, true,
                    RickPanel.TANK_X + i * RickPanel.TANK_DX, RickPanel.DRAIN_Y));

        for (int i = 0; i < RickTanks.COUNT; i++)
            sink.accept(new FluidSlot(fillSlots, i, false,
                    RickPanel.TANK_X + i * RickPanel.TANK_DX, RickPanel.FILL_Y));

        sink.accept(new DissolverSlot(RickPanel.DISSOLVER_X, RickPanel.DISSOLVER_Y));
    }

    /** Слот разложения: принимает только то, на что у Alchemistry есть рецепт. */
    private class DissolverSlot extends Slot {
        DissolverSlot(int x, int y) { super(dissolver, 0, x, y); }

        @Override public boolean isActive() { return active(); }
        @Override public boolean mayPickup(Player p) { return active(); }
        @Override public boolean mayPlace(ItemStack stack) {
            if (!active()) return false;
            Level level = owner.level();
            if (level.isClientSide) return true; // клиент рецептов не знает — не мешаем класть
            return RickAlchemistry.findDissolver(level, stack) != null;
        }
    }

    /** Обычная ячейка сетки, выключенная для всех кроме Рика. */
    private class GatedSlot extends Slot {
        GatedSlot(Container c, int idx, int x, int y) { super(c, idx, x, y); }
        @Override public boolean isActive() { return active(); }
        @Override public boolean mayPlace(ItemStack stack) { return active(); }
        @Override public boolean mayPickup(Player p) { return active(); }
    }

    private class ResultSlot extends Slot {
        ResultSlot(int x, int y) { super(result, 0, x, y); }

        @Override public boolean isActive() { return active(); }
        @Override public boolean mayPlace(ItemStack stack) { return false; }
        @Override public boolean mayPickup(Player p) { return active(); }

        @Override public void onTake(Player player, ItemStack taken) {
            taken.onCraftedBy(player.level(), player, taken.getCount());
            var snapshot = resolved;
            NonNullList<ItemStack> rem = RickCraftingResolver.remainders(snapshot);

            // Сколько снимать с какой ячейки, решает сам резолвер: у верстака
            // это по одной штуке, у Combiner'а — по количеству из ингредиента,
            // у Compactor'а — целая пачка с одной ячейки.
            int[] costs = snapshot.costs();
            for (int i = 0; i < GRID * GRID && i < costs.length; i++) {
                if (costs[i] > 0 && !grid.getItem(i).isEmpty()) grid.removeItem(i, costs[i]);
            }
            for (int t = 0; t < rem.size(); t++) {
                ItemStack leftover = rem.get(t);
                if (leftover.isEmpty()) continue;
                int gi = snapshot.gridIndex(t);
                if (gi < 0 || gi >= GRID * GRID) continue;
                ItemStack cur = grid.getItem(gi);
                if (cur.isEmpty()) grid.setItem(gi, leftover);
                else if (ItemStack.isSameItemSameComponents(cur, leftover)) cur.grow(leftover.getCount());
                else if (!player.getInventory().add(leftover)) player.drop(leftover, false);
            }
            onGridChanged();
        }
    }

    /**
     * Слот у бака. Направление задано САМИМ СЛОТОМ, а не содержимым тары:
     * верхний только сливает, нижний только наливает.
     *
     * Раньше слот был один и выбирал направление по содержимому: полное ведро
     * сливалось, а получившееся пустое тут же наполнялось обратно на следующем
     * обновлении контейнера — отсюда и звук при нулевом результате.
     */
    private class FluidSlot extends Slot {
        private final int tankIndex;
        private final boolean drain;

        FluidSlot(Container container, int tankIndex, boolean drain, int x, int y) {
            super(container, tankIndex, x, y);
            this.tankIndex = tankIndex;
            this.drain = drain;
        }

        @Override public boolean isActive() { return active(); }
        @Override public boolean mayPickup(Player p) { return active(); }

        /** Стак целиком: шестнадцать вёдер обрабатываются за одну укладку. */
        @Override public int getMaxStackSize() { return 64; }

        @Override public boolean mayPlace(ItemStack stack) {
            if (!active()) return false;
            var handler = FluidUtil.getFluidHandler(stack);
            if (handler.isEmpty()) return false;

            var content = handler.get().getFluidInTank(0);
            if (drain) {
                // В слив — всё, из чего есть что слить.
                return !content.isEmpty();
            }
            // В налив — всё, что ещё не полное. Проверка по остатку места, а не по
            // «пустая ли тара»: иначе наполовину заряженная портальная пушка не
            // влезала бы в слот и дозаправить её было бы нечем.
            return content.getAmount() < handler.get().getTankCapacity(0);
        }

        @Override public void setChanged() {
            super.setChanged();
            handleFluidSlot(this.container, tankIndex, drain);
        }
    }

    // ================= логика =================

    /** Пересчёт результата сетки. Вызывается из slotsChanged миксина. */
    public void onGridChanged() {
        Level level = owner.level();
        if (level.isClientSide) return;
        // Вторая линия обороны: слоты и так закрыты через mayPlace/mayPickup, но
        // резолвер не должен запускаться для не-Рика ни при каких обстоятельствах.
        if (!active()) {
            this.variants = List.of();
            this.resolved = RickCraftingResolver.Resolved.EMPTY;
            this.result.setItem(0, ItemStack.EMPTY);
            return;
        }

        this.variants = RickCraftingResolver.resolveAll(level, grid);

        // Пытаемся удержать прежний выбор: если тот же предмет всё ещё среди
        // вариантов, остаёмся на нём. Иначе индекс сбрасывается на первый.
        this.variantIndex = 0;
        if (!lastPicked.isEmpty()) {
            for (int i = 0; i < variants.size(); i++) {
                if (ItemStack.isSameItemSameComponents(variants.get(i).result(), lastPicked)) {
                    this.variantIndex = i;
                    break;
                }
            }
        }

        applyVariant();
    }

    /** Переключение стрелками. Индекс клампится по своему списку, не по клиентскому. */
    public void selectVariant(int index) {
        if (owner.level().isClientSide || !active()) return;
        if (variants.isEmpty()) return;
        this.variantIndex = Math.floorMod(index, variants.size());
        this.lastPicked = variants.get(variantIndex).result().copy();
        applyVariant();
    }

    private void applyVariant() {
        this.resolved = variants.isEmpty()
                ? RickCraftingResolver.Resolved.EMPTY
                : variants.get(Math.min(variantIndex, variants.size() - 1));
        this.result.setItem(0, this.resolved.result().copy());

        if (owner instanceof ServerPlayer sp) {
            PacketDistributor.sendToPlayer(sp,
                    new RickVariantPackets.Sync(variants.size(), variantIndex));
        }
        this.menu.broadcastChanges();
    }

    /**
     * Разложение по одному предмету раз в DISSOLVE_PERIOD тиков.
     *
     * Мгновенная переработка целого стака была бы слишком щедрой, а таймер даёт
     * поведение, близкое к настоящему Dissolver'у. Выход валится прямо в
     * инвентарь игрока — отдельные выходные слоты панели не влезли бы, да и
     * таблица вероятностей возвращает переменное число стаков.
     */
    public void tick() {
        if (owner.level().isClientSide || !active()) return;

        ItemStack input = dissolver.getItem(0);
        if (input.isEmpty()) {
            dissolveCooldown = 0;
            return;
        }
        if (++dissolveCooldown < DISSOLVE_PERIOD) return;
        dissolveCooldown = 0;

        Level level = owner.level();
        Object recipe = RickAlchemistry.findDissolver(level, input);
        if (recipe == null) return;

        List<ItemStack> output = RickAlchemistry.rollDissolver(recipe, level.random);
        input.shrink(1);
        if (input.isEmpty()) dissolver.setItem(0, ItemStack.EMPTY);
        dissolver.setChanged();

        for (ItemStack out : output) {
            if (out.isEmpty()) continue;
            if (!owner.getInventory().add(out)) owner.drop(out, false);
        }
        menu.broadcastChanges();
    }

    /**
     * Обработка слота у бака. Направление приходит параметром, поэтому
     * пинг-понга «слил — налил» быть не может по построению.
     *
     * Обрабатывается ВЕСЬ стак, а не одна единица: положил шестнадцать вёдер —
     * наполнилось столько, на сколько хватило жидкости в баке, остальные
     * вернулись как были. Перекладывать по одному не нужно.
     *
     * Готовая тара уходит в инвентарь игрока, а что не влезло — падает под ноги.
     * Слот при этом освобождается полностью, поэтому повторно обработать ту же
     * ёмкость невозможно.
     */
    private void handleFluidSlot(Container container, int tankIndex, boolean drain) {
        Level level = owner.level();
        if (level.isClientSide || !active()) return;

        ItemStack stack = container.getItem(tankIndex);
        if (stack.isEmpty()) return;
        if (FluidUtil.getFluidHandler(stack).isEmpty()) return;

        RickFluidTank tank = RickTanks.of(owner).tank(tankIndex);
        var inv = new PlayerMainInvWrapper(owner.getInventory());

        int processed = 0;
        List<ItemStack> done = new ArrayList<>();

        // Идём по одной единице: FluidUtil работает со стаком как с единичной
        // тарой, а нам нужно знать, на скольких именно жидкость кончилась.
        while (!stack.isEmpty()) {
            ItemStack single = stack.copyWithCount(1);

            var res = drain
                    ? FluidUtil.tryEmptyContainerAndStow(single, tank, inv, Integer.MAX_VALUE, owner, true)
                    : FluidUtil.tryFillContainerAndStow(single, tank, inv, Integer.MAX_VALUE, owner, true);

            if (!res.isSuccess()) break;   // бак пуст или полон — остальное не трогаем

            stack.shrink(1);
            ItemStack result = res.getResult();
            if (!result.isEmpty()) done.add(result);
            processed++;
        }

        if (processed == 0) return;

        // Что осталось необработанным — оставляем в слоте, чтобы было видно,
        // сколько именно не поместилось.
        container.setItem(tankIndex, stack.isEmpty() ? ItemStack.EMPTY : stack);

        for (ItemStack result : done) {
            if (!owner.getInventory().add(result)) owner.drop(result, false);
        }
        syncTanks(true);
    }

    /** Снимок танков клиенту. Attachment сам по себе на клиент не едет. */
    public void syncTanks(boolean force) {
        if (!(owner instanceof ServerPlayer sp)) return;
        List<FluidStack> now = RickTanks.of(owner).snapshot();
        if (!force && lastSentTanks != null && sameTanks(lastSentTanks, now)) return;
        lastSentTanks = now;
        PacketDistributor.sendToPlayer(sp, new RickTanksSyncPacket(now));
    }

    private static boolean sameTanks(List<FluidStack> a, List<FluidStack> b) {
        if (a.size() != b.size()) return false;
        for (int i = 0; i < a.size(); i++) if (!FluidStack.matches(a.get(i), b.get(i))) return false;
        return true;
    }

    /** Содержимое обратно в инвентарь, остаток — под ноги. Для /rick clear. */
    public void returnAll(Player player) {
        this.result.clearContent();
        if (player.level().isClientSide) return;
        for (Container c : new Container[]{grid, drainSlots, fillSlots, dissolver}) {
            for (int i = 0; i < c.getContainerSize(); i++) {
                ItemStack s = c.removeItemNoUpdate(i);
                if (s.isEmpty()) continue;
                if (!player.getInventory().add(s)) player.drop(s, false);
            }
        }
        this.resolved = RickCraftingResolver.Resolved.EMPTY;
    }

    /** Как ванильный InventoryMenu.removed поступает с сеткой 2x2. */
    public void dropAll(Player player) {
        this.result.clearContent();
        if (player.level().isClientSide) return;
        for (int i = 0; i < grid.getContainerSize(); i++) {
            ItemStack s = grid.removeItemNoUpdate(i);
            if (!s.isEmpty()) player.drop(s, false);
        }
        for (Container c : new Container[]{drainSlots, fillSlots}) {
            for (int i = 0; i < c.getContainerSize(); i++) {
                ItemStack s = c.removeItemNoUpdate(i);
                if (!s.isEmpty()) player.drop(s, false);
            }
        }
        for (int i = 0; i < dissolver.getContainerSize(); i++) {
            ItemStack s = dissolver.removeItemNoUpdate(i);
            if (!s.isEmpty()) player.drop(s, false);
        }
    }
}