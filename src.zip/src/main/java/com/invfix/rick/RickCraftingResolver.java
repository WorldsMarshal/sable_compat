package com.invfix.rick;

import net.minecraft.core.NonNullList;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.AbstractCookingRecipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.item.crafting.ShapedRecipe;
import net.minecraft.world.item.crafting.ShapedRecipePattern;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Резолвер карманного крафта Rick C137. Логика снята с
 * {@code ProgrammableMachineBlockEntity.resolveRecipe}, но без тира и без шанса
 * провала: Рику доступны все уровни станков сразу.
 *
 * Порядок: ваниль -> Create mechanical_crafting (нативно, кодом самого Create,
 * поэтому ловятся ВСЕ аддоны без единой строки под каждый) -> sable_compat:precision.
 *
 * Ограничение по геометрии одно: шаблон должен влезть в 5x5. Из 21 рецепта
 * mechanical_crafting в сборке (create, createaddition, CBC, CBC Modern Warfare,
 * TFMG, Create Connected, Propulsion, Crowns) не влезает ровно один — large_engine,
 * он 3 в ширину и 6 в высоту.
 */
public final class RickCraftingResolver {

    public static final int GRID = 5;

    private RickCraftingResolver() {}

    /** Результат резолва: сам предмет, совпавший рецепт и обрезанный вход для остатков. */
    /**
     * @param minX,minY смещение обрезанного окна внутри сетки 5x5 — нужно, чтобы
     *                  разложить остатки рецепта обратно по реальным ячейкам.
     */
    public record Resolved(ItemStack result, @Nullable Recipe<?> recipe, @Nullable CraftingInput input,
                           int[] costs,
                           int minX, int minY, int width, int height) {
        public static final Resolved EMPTY =
                new Resolved(ItemStack.EMPTY, null, null, new int[GRID * GRID], 0, 0, 0, 0);
        public boolean isEmpty() { return result.isEmpty(); }

        /** Индекс ячейки 5x5 по индексу внутри обрезанного окна. */
        public int gridIndex(int trimmedIndex) {
            int r = trimmedIndex / width, c = trimmedIndex % width;
            return (minY + r) * GRID + (minX + c);
        }
    }

    /** Первый вариант — для мест, где выбор не нужен. */
    public static Resolved resolve(Level level, CraftingContainer grid) {
        List<Resolved> all = resolveAll(level, grid);
        return all.isEmpty() ? Resolved.EMPTY : all.get(0);
    }

    /**
     * ВСЕ рецепты, которые подходят под текущую сетку.
     *
     * Источников стало много — ваниль, Create, наши станки, четыре машины
     * Alchemistry, печь и домна — и один набор предметов нередко подходит сразу
     * под несколько. Поэтому резолвер больше не останавливается на первом
     * совпадении, а собирает все, а игрок листает их стрелками у слота выдачи.
     */
    public static List<Resolved> resolveAll(Level level, CraftingContainer grid) {
        List<Resolved> found = new ArrayList<>();
        if (level == null) return found;

        // --- обрезаем пустые края, как это делает верстак ---
        int minX = GRID, minY = GRID, maxX = -1, maxY = -1;
        for (int r = 0; r < GRID; r++) {
            for (int c = 0; c < GRID; c++) {
                if (!grid.getItem(r * GRID + c).isEmpty()) {
                    if (c < minX) minX = c;
                    if (c > maxX) maxX = c;
                    if (r < minY) minY = r;
                    if (r > maxY) maxY = r;
                }
            }
        }
        if (maxX < 0) return found;

        int w = maxX - minX + 1, h = maxY - minY + 1;
        List<ItemStack> trimmed = new ArrayList<>(w * h);
        for (int r = 0; r < h; r++)
            for (int c = 0; c < w; c++)
                trimmed.add(grid.getItem((minY + r) * GRID + (minX + c)).copy());

        CraftingInput ci = CraftingInput.of(w, h, trimmed);

        List<ItemStack> present = new ArrayList<>();
        for (int i = 0; i < GRID * GRID; i++) {
            ItemStack s = grid.getItem(i);
            if (!s.isEmpty()) present.add(s);
        }

        // --- 1. ваниль: берём ВСЕ подходящие, а не первый ---
        for (var holder : level.getRecipeManager().getRecipesFor(RecipeType.CRAFTING, ci, level)) {
            var recipe = holder.value();
            add(found, new Resolved(recipe.assemble(ci, level.registryAccess()), recipe, ci,
                    oneEach(grid), minX, minY, w, h));
        }

        // --- 2. Create mechanical_crafting, нативно ---
        Resolved mech = resolveCreate(level, grid, ci, minX, minY, w, h);
        if (mech != null) add(found, mech);

        // --- 3. наши станочные рецепты, БЕЗ проверки тира и без шанса провала ---
        for (var holder : level.getRecipeManager().getRecipesFor(
                com.invfix.cyberware.machines.SableRecipes.PRECISION_TYPE.get(), ci, level)) {
            var recipe = holder.value();
            add(found, new Resolved(recipe.assemble(ci, level.registryAccess()), recipe, ci,
                    oneEach(grid), minX, minY, w, h));
        }

        // --- 4. Alchemistry ---
        // Combiner сверяет НАБОР стаков без учёта расположения и забирает по
        // количеству из ингредиента, поэтому списание считается отдельно.
        Object combiner = RickAlchemistry.findCombiner(level, present);
        if (combiner != null) {
            ItemStack out = RickAlchemistry.combinerOutput(combiner);
            if (!out.isEmpty()) {
                int[] costs = new int[GRID * GRID];
                for (int i = 0; i < GRID * GRID; i++) {
                    ItemStack in = grid.getItem(i);
                    if (!in.isEmpty()) costs[i] = RickAlchemistry.combinerCostFor(combiner, in);
                }
                add(found, new Resolved(out, null, ci, costs, minX, minY, w, h));
            }
        }

        // Compactor: один предмет, но сразу пачкой — сколько требует рецепт.
        if (present.size() == 1) {
            int slot = firstFilled(grid);
            var compact = RickAlchemistry.findCompactor(level, present.get(0));
            if (compact != null) {
                ItemStack out = RickAlchemistry.compactorOutput(compact);
                int need = RickAlchemistry.compactorCost(compact);
                if (!out.isEmpty() && need > 0 && grid.getItem(slot).getCount() >= need) {
                    int[] costs = new int[GRID * GRID];
                    costs[slot] = need;
                    add(found, new Resolved(out, null, ci, costs, minX, minY, w, h));
                }
            }
        }

        // Fusion: ровно два предмета, по одному с каждой стороны.
        if (present.size() == 2) {
            var fusion = RickAlchemistry.findFusion(level, present.get(0), present.get(1));
            if (fusion != null) {
                ItemStack out = RickAlchemistry.fusionOutput(fusion);
                if (!out.isEmpty()) {
                    // Входы синтеза имеют собственный размер стака, поэтому
                    // списываем по рецепту, а не по одной штуке.
                    int[] costs = new int[GRID * GRID];
                    for (int i = 0; i < GRID * GRID; i++) {
                        ItemStack in = grid.getItem(i);
                        if (!in.isEmpty()) costs[i] = RickAlchemistry.fusionCostFor(fusion, in);
                    }
                    add(found, new Resolved(out, null, ci, costs, minX, minY, w, h));
                }
            }
        }

        // --- 5. Обжиг ---
        // Сначала обычная печь, затем доменная: часть рецептов существует только
        // в доменном варианте, например кремниевая пыль из chemica.
        if (present.size() == 1) {
            SingleRecipeInput input = new SingleRecipeInput(present.get(0));
            for (RecipeType<? extends AbstractCookingRecipe> type
                    : List.of(RecipeType.SMELTING, RecipeType.BLASTING)) {
                var cooked = level.getRecipeManager().getRecipeFor(type, input, level);
                if (cooked.isEmpty()) continue;
                ItemStack out = cooked.get().value().assemble(input, level.registryAccess());
                if (!out.isEmpty()) {
                    add(found, new Resolved(out.copy(), null, ci, oneEach(grid), minX, minY, w, h));
                }
            }
        }

        return found;
    }

    /** Списание по одной штуке с каждой занятой ячейки — обычное поведение верстака. */
    private static int[] oneEach(CraftingContainer grid) {
        int[] costs = new int[GRID * GRID];
        for (int i = 0; i < GRID * GRID; i++) {
            if (!grid.getItem(i).isEmpty()) costs[i] = 1;
        }
        return costs;
    }

    private static int firstFilled(CraftingContainer grid) {
        for (int i = 0; i < GRID * GRID; i++) if (!grid.getItem(i).isEmpty()) return i;
        return 0;
    }

    /**
     * Добавляет вариант, если такого предмета в списке ещё нет.
     *
     * Дубликаты неизбежны: один и тот же слиток выдают и ванильный рецепт, и
     * наш станочный, и печь. Листать три одинаковых результата бессмысленно,
     * поэтому сравниваем по предмету, количеству и компонентам.
     */
    private static void add(List<Resolved> found, Resolved candidate) {
        if (candidate == null || candidate.isEmpty()) return;
        for (Resolved existing : found) {
            if (existing.result().getCount() == candidate.result().getCount()
                    && ItemStack.isSameItemSameComponents(existing.result(), candidate.result())) {
                return;
            }
        }
        found.add(candidate);
    }

    /**
     * Create требует именно MechanicalCraftingInput, обычный CraftingInput их
     * matches() не принимает. Собираем через публичное API Create:
     * GroupedItems.read(nbt) -> calcStats() -> MechanicalCraftingInput.of().
     * Create инвертирует Y, поэтому строка r кладётся как gridY = 4 - r.
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Nullable
    private static Resolved resolveCreate(Level level, CraftingContainer grid, CraftingInput ci,
                                          int minX, int minY, int w, int h) {
        try {
            net.minecraft.nbt.CompoundTag gridTag = new net.minecraft.nbt.CompoundTag();
            net.minecraft.nbt.ListTag gridList = new net.minecraft.nbt.ListTag();
            for (int r = 0; r < GRID; r++) {
                for (int c = 0; c < GRID; c++) {
                    ItemStack s = grid.getItem(r * GRID + c);
                    if (s.isEmpty()) continue;
                    net.minecraft.nbt.CompoundTag e = new net.minecraft.nbt.CompoundTag();
                    e.putInt("x", c);
                    e.putInt("y", (GRID - 1) - r);
                    e.put("item", s.saveOptional(level.registryAccess()));
                    gridList.add(e);
                }
            }
            gridTag.put("Grid", gridList);

            var grouped = com.simibubi.create.content.kinetics.crafter.RecipeGridHandler.GroupedItems
                    .read(gridTag, level.registryAccess());
            grouped.calcStats();
            var mci = com.simibubi.create.content.kinetics.crafter.MechanicalCraftingInput.of(grouped);

            Optional<?> found = com.simibubi.create.AllRecipeTypes.MECHANICAL_CRAFTING.find(mci, level);
            if (found.isPresent()) {
                Object recipe = ((net.minecraft.world.item.crafting.RecipeHolder<?>) found.get()).value();
                ItemStack out = ((Recipe) recipe).assemble(mci, level.registryAccess());
                if (out != null && !out.isEmpty()) {
                    return new Resolved(out, (Recipe<?>) recipe, ci, oneEach(grid), minX, minY, w, h);
                }
            }
            return null;
        } catch (Throwable nativeFail) {
            // Фолбэк на случай смены внутреннего API Create: пересборка в ванильный
            // ShapedRecipe. Матчит обычный CraftingInput, минус — без accept_mirrored.
            try {
                var mechType = com.simibubi.create.AllRecipeTypes.MECHANICAL_CRAFTING.getType();
                for (var holder : level.getRecipeManager().getRecipes()) {
                    if (holder.value().getType() != mechType) continue;
                    if (!(holder.value() instanceof ShapedRecipe shaped)) continue;
                    ShapedRecipe probe = new ShapedRecipe(
                            shaped.getGroup(), shaped.category(),
                            new ShapedRecipePattern(shaped.getWidth(), shaped.getHeight(),
                                    shaped.getIngredients(), Optional.empty()),
                            shaped.getResultItem(level.registryAccess()));
                    if (probe.matches(ci, level)) {
                        return new Resolved(probe.assemble(ci, level.registryAccess()), probe, ci, oneEach(grid), minX, minY, w, h);
                    }
                }
            } catch (Throwable ignored) { /* Create не загружен */ }
            return null;
        }
    }

    /** Остатки (вёдра и т.п.) от совпавшего рецепта — любого типа. */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static NonNullList<ItemStack> remainders(Resolved resolved) {
        if (resolved.recipe() == null || resolved.input() == null) return NonNullList.create();
        try {
            return ((Recipe) resolved.recipe()).getRemainingItems(resolved.input());
        } catch (Throwable t) {
            return NonNullList.create();
        }
    }
}