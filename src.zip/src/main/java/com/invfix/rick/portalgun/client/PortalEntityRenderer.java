package com.invfix.rick.portalgun.client;

import com.invfix.rick.portalgun.PortalEntity;
import com.invfix.rick.portalgun.PortalGunItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;

/**
 * Воронка портала. Порт PortalEntityRenderer из Rick's stuff 0.0.4.3:
 *  - анимированная текстура — вертикальная полоса из 40 кадров 200x200,
 *    кадр выбирается в коде (entity-текстуры не лежат в атласе, .mcmeta не
 *    работает), скорость 0.8 кадра/тик;
 *  - шейдер energy swirl, полная яркость;
 *  - сетка 8x8, чтобы проход мог «продавить» воронку: при проходе — желейная
 *    волна по Catmull-Rom сплайнам оригинала (18 тиков);
 *  - открытие: 14 тиков с перелётом 15%, закрытие: 9 тиков.
 */
@OnlyIn(Dist.CLIENT)
public class PortalEntityRenderer extends EntityRenderer<PortalEntity> {

    private static final ResourceLocation PORTAL_GREEN = ResourceLocation.fromNamespaceAndPath("sable_compat",
            "textures/entity/portal_gun/green_portal_animated_texture.png");
    private static final ResourceLocation PORTAL_YELLOW = ResourceLocation.fromNamespaceAndPath("sable_compat",
            "textures/entity/portal_gun/yellow_portal_animated_texture.png");

    private static final int TOTAL_FRAMES = 40;
    private static final float ANIM_SPEED = 0.8F;
    private static final int FULL_BRIGHT = 0xF000F0;

    private static final float[] PASS_Z_KEYS = {0.0F, -2.0F, 2.0F, -1.0F, 1.0F, -0.5F, 0.5F, 0.0F};
    private static final float[] PASS_LIFT_KEYS = {0.0F, 0.225F, 0.085F, 0.125F, 0.045F, 0.07F, 0.02F, 0.0F};

    public PortalEntityRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public @NotNull ResourceLocation getTextureLocation(PortalEntity entity) {
        return entity.getColor() == PortalGunItem.COLOR_YELLOW ? PORTAL_YELLOW : PORTAL_GREEN;
    }

    @Override
    public void render(PortalEntity entity, float entityYaw, float partialTicks, PoseStack poseStack,
                       @NotNull MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        float baseScale = entity.getScale();
        int orientation = entity.getOrientation();
        int rotation = entity.getRotation();
        float animScale = 1.0F;
        float time = entity.tickCount + partialTicks;

        if (entity.isClosing()) {
            int closingTimer = entity.getClientClosingTimer();
            float elapsed = closingTimer >= 0 ? PortalEntity.CLOSE_DURATION - (closingTimer - partialTicks) : PortalEntity.CLOSE_DURATION;
            float progress = Math.max(0.0F, Math.min(1.0F, elapsed / PortalEntity.CLOSE_DURATION));
            if (progress >= 1.0F) {
                animScale = 0.0F;
            } else if (progress < 0.18F) {
                animScale = 1.0F + progress / 0.18F * 0.15F;
            } else {
                float decay = (progress - 0.18F) / 0.82F;
                animScale = Math.max(0.0F, 1.15F * (1.0F - decay));
            }
        } else if (entity.tickCount < 14) {
            float t = Math.min(1.0F, (entity.tickCount + partialTicks) / 14.0F);
            animScale = (float) Math.sin(t * Math.PI * 0.5);
            if (t < 0.75F) animScale *= 1.0F + 0.15F * (float) Math.sin(t / 0.75F * Math.PI);
        }

        float scale = baseScale * animScale;
        if (scale <= 0.001F) {
            poseStack.popPose();
            return;
        }

        if (orientation == PortalEntity.ORIENTATION_WALL) {
            poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - entity.getYRot()));
        } else if (orientation == PortalEntity.ORIENTATION_CEILING) {
            poseStack.mulPose(Axis.XP.rotationDegrees(90.0F));
            poseStack.mulPose(Axis.ZP.rotationDegrees(rotation * 90.0F));
        } else {
            poseStack.mulPose(Axis.XP.rotationDegrees(-90.0F));
            poseStack.mulPose(Axis.ZP.rotationDegrees(rotation * 90.0F));
        }

        float width = 0.95F * scale;
        float height = (orientation == PortalEntity.ORIENTATION_WALL ? 1.05F : 0.95F) * scale;
        int frame = (int) (time * ANIM_SPEED) % TOTAL_FRAMES;
        float v0 = (float) frame / TOTAL_FRAMES;
        float v1 = (float) (frame + 1) / TOTAL_FRAMES;

        VertexConsumer consumer = buffer.getBuffer(PortalVisualRenderTypes.portal(getTextureLocation(entity)));
        int passTicks = entity.getClientPassTimer();
        float passProgress = 0.0F;
        if (passTicks > 0) {
            passProgress = Math.max(0.0F, Math.min(1.0F,
                    (PortalEntity.PASS_ANIMATION_DURATION - (passTicks - partialTicks)) / PortalEntity.PASS_ANIMATION_DURATION));
        }
        renderVortexMesh(consumer, poseStack.last(), width, height, v0, v1, passProgress, orientation);
        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    private void renderVortexMesh(VertexConsumer consumer, PoseStack.Pose pose, float w, float h, float v0, float v1,
                                  float passProgress, int orientation) {
        float normalSign = orientation == PortalEntity.ORIENTATION_WALL ? -1.0F : 1.0F;
        float zDisplacement = 0.0F;
        float liftOffset = 0.0F;
        boolean passing = passProgress > 0.0F && passProgress <= 1.0F;
        if (passing) {
            float unitScale = 2.0F * w / 54.0F;
            zDisplacement = sampleCatmullRomSpline(PASS_Z_KEYS, passProgress) * unitScale;
            liftOffset = sampleCatmullRomSpline(PASS_LIFT_KEYS, passProgress);
        }
        float totalZOffset = (zDisplacement + liftOffset) * normalSign;
        float lateralDecay = passing ? (float) Math.sin(passProgress * Math.PI * 2.5) * (1.0F - passProgress) : 0.0F;

        final int grid = 8;
        for (int row = 0; row < grid; ++row) {
            for (int col = 0; col < grid; ++col) {
                int[][] quad = {{col, row}, {col + 1, row}, {col + 1, row + 1}, {col, row + 1}};
                for (int[] pt : quad) {
                    float fx = (float) pt[0] / grid;
                    float fy = (float) pt[1] / grid;
                    float gx = fx * 2.0F - 1.0F;
                    float gy = fy * 2.0F - 1.0F;
                    float vx = -w + fx * 2.0F * w;
                    float vy = -h + fy * 2.0F * h;
                    float vz = 0.0F;
                    if (passing) {
                        float falloff = (float) (Math.cos(gx * Math.PI * 0.5) * Math.cos(gy * Math.PI * 0.5));
                        vz = totalZOffset * falloff;
                        vx += (float) Math.sin(gy * Math.PI) * 0.025F * lateralDecay * falloff;
                        vy += (float) Math.sin(gx * Math.PI) * 0.025F * lateralDecay * falloff;
                    }
                    float u = fx;
                    float v = v1 + fy * (v0 - v1);
                    consumer.addVertex(pose, vx, vy, vz).setColor(255, 255, 255, 255).setUv(u, v)
                            .setOverlay(OverlayTexture.NO_OVERLAY).setLight(FULL_BRIGHT)
                            .setNormal(pose, 0.0F, 0.0F, normalSign);
                }
            }
        }
    }

    private static float evalCatmullRom(float p0, float p1, float p2, float p3, float t) {
        return 0.5F * (2.0F * p1 + (-p0 + p2) * t + (2.0F * p0 - 5.0F * p1 + 4.0F * p2 - p3) * t * t
                + (-p0 + 3.0F * p1 - 3.0F * p2 + p3) * t * t * t);
    }

    private static float sampleCatmullRomSpline(float[] keys, float progress) {
        if (progress <= 0.0F) return keys[0];
        if (progress >= 1.0F) return keys[keys.length - 1];
        int n = keys.length - 1;
        float scaled = progress * n;
        int idx = (int) scaled;
        if (idx >= n) return keys[n];
        float t = scaled - idx;
        return evalCatmullRom(keys[Math.max(0, idx - 1)], keys[idx], keys[Math.min(n, idx + 1)],
                keys[Math.min(n, idx + 2)], t);
    }
}
