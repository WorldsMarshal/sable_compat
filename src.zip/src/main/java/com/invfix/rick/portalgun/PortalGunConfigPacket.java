package com.invfix.rick.portalgun;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * C2S: клиент прислал новое состояние пушки из экрана настройки.
 *
 * Сервер не доверяет присланному вслепую: данные прогоняются через sanitized(),
 * подписи режутся по длине, а сам предмет берётся из руки игрока, а не из
 * пакета — подсунуть чужой стак нельзя.
 */
public record PortalGunConfigPacket(boolean mainHand, PortalGunData data) implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<PortalGunConfigPacket> TYPE =
            new CustomPacketPayload.Type<>(
                    ResourceLocation.fromNamespaceAndPath("sable_compat", "portal_gun_config"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PortalGunConfigPacket> STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.BOOL, PortalGunConfigPacket::mainHand,
                    PortalGunData.STREAM_CODEC, PortalGunConfigPacket::data,
                    PortalGunConfigPacket::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(PortalGunConfigPacket packet, IPayloadContext context) {
        context.enqueueWork(() -> {
            Player player = context.player();
            if (player == null) return;

            InteractionHand hand = packet.mainHand() ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
            ItemStack stack = player.getItemInHand(hand);
            if (!(stack.getItem() instanceof PortalGunItem)) return;

            PortalGunData clean = packet.data().sanitized();
            // Подписи режем ещё раз на сервере: клиент мог прислать что угодно.
            java.util.List<PortalPoint> points = new java.util.ArrayList<>(PortalGunData.MAX_POINTS);
            for (PortalPoint p : clean.points()) {
                points.add(new PortalPoint(PortalPoint.sanitize(p.label()), p.pos(), p.dimension()));
            }

            stack.set(PortalGunRegistry.GUN_DATA.get(),
                    new PortalGunData(java.util.List.copyOf(points), clean.selected(), clean.passLimit(), clean.mode(), clean.airDistance()));
        });
    }
}
