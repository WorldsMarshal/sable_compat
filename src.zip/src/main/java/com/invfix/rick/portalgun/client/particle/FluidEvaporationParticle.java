package com.invfix.rick.portalgun.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/** Порт FluidEvaporationParticle из Rick's stuff 0.0.4.3. */
@OnlyIn(Dist.CLIENT)
public class FluidEvaporationParticle extends TextureSheetParticle {
   private final SpriteSet sprites;

   public FluidEvaporationParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
      super(level, x, y, z, vx, vy, vz);
      this.sprites = sprites;
      this.rCol = 0.2F;
      this.gCol = 0.95F;
      this.bCol = 0.15F;
      this.xd = vx * 0.1 + (Math.random() - 0.5) * 0.04;
      this.yd = vy * 0.1 + 0.04 + Math.random() * 0.03;
      this.zd = vz * 0.1 + (Math.random() - 0.5) * 0.04;
      this.lifetime = (int)(12.0 + Math.random() * 8.0);
      this.quadSize = 0.055F + (float)(Math.random() * 0.02500000037252903);
      this.hasPhysics = true;
      this.setSpriteFromAge(sprites);
   }

   @Override
   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @Override
   public int getLightColor(float partialTick) {
      return 15728880;
   }

   @Override
   public void tick() {
      this.xo = this.x;
      this.yo = this.y;
      this.zo = this.z;
      if (this.age++ >= this.lifetime) {
         this.remove();
      } else {
         this.setSpriteFromAge(this.sprites);
         this.move(this.xd, this.yd, this.zd);
         this.xd *= 0.92;
         this.yd *= 0.96;
         this.zd *= 0.92;
         float progress = (float)this.age / (float)this.lifetime;
         this.alpha = 1.0F - progress;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class Provider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public Provider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      @Override
      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new FluidEvaporationParticle(level, x, y, z, vx, vy, vz, this.sprites);
      }
   }
}
