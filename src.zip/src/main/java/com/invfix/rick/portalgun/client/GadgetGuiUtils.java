package com.invfix.rick.portalgun.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Порт GadgetGuiUtils из Rick's stuff 0.0.4.3 — оформление панелей портальной пушки. */
@net.neoforged.api.distmarker.OnlyIn(net.neoforged.api.distmarker.Dist.CLIENT)
public class GadgetGuiUtils {
   public static final int COLOR_CHASSIS_BG = 0xFF24272C;
   public static final int COLOR_CHASSIS_LIGHT = 0xFF454952;
   public static final int COLOR_CHASSIS_DARK = 0xFF121417;
   public static final int COLOR_SHADOW = 0xFF08090A;
   public static final int COLOR_HEADER_BG = 0xFF1A1D22;
   public static final int COLOR_HEADER_BORDER = 0xFF353942;
   public static final int COLOR_CRT_BG = 0xFF061309;
   public static final int COLOR_CRT_BORDER = 0xFF0F2213;
   public static final int COLOR_CRT_SHEEN = 0xFF0B2412;
   public static final int COLOR_TEXT_PHOSPHOR = 0xFF3DE665;
   public static final int COLOR_TEXT_AMBER = 0xFFFFB326;
   public static final int COLOR_TEXT_CYAN = 0xFF36D7E8;
   public static final int COLOR_TEXT_MUTED = 0xFF8A909C;
   public static final int COLOR_FLUID_GREEN_MID = 0xFF2FE65B;
   public static final int COLOR_FLUID_GREEN_TOP = 0xFF85FFA4;
   public static final int COLOR_FLUID_GREEN_BOT = 0xFF199E39;

   public static void renderChassis(GuiGraphics g, int x, int y, int width, int height) {
      g.fill(x - 2, y - 2, x + width + 2, y + height + 2, 0xFF08090A);
      g.fill(x, y, x + width, y + height, 0xFF24272C);
      g.fill(x, y, x + width, y + 2, 0xFF454952);
      g.fill(x, y, x + 2, y + height, 0xFF454952);
      g.fill(x, y + height - 2, x + width, y + height, 0xFF121417);
      g.fill(x + width - 2, y, x + width, y + height, 0xFF121417);
      renderRivet(g, x + 4, y + 4);
      renderRivet(g, x + width - 7, y + 4);
      renderRivet(g, x + 4, y + height - 7);
      renderRivet(g, x + width - 7, y + height - 7);
   }

   public static void renderHeader(GuiGraphics g, int x, int y, int width, int height) {
      g.fill(x - 1, y - 1, x + width + 1, y + height + 1, 0xFF121417);
      g.fill(x, y, x + width, y + height, 0xFF1A1D22);
      g.fill(x, y + height - 1, x + width, y + height, 0xFF353942);
      g.fill(x, y, x + width, y + 1, 0xFF454952);
   }

   public static void renderTerminalScreen(GuiGraphics g, int x, int y, int width, int height) {
      g.fill(x - 1, y - 1, x + width + 1, y + height + 1, 0xFF121417);
      g.fill(x, y, x + width, y + height, 0xFF061309);
      g.renderOutline(x, y, width, height, 0xFF0F2213);
      g.fill(x + 1, y + 1, x + width - 1, y + 2, 0xFF0B2412);
   }

   public static void renderFluidTube(GuiGraphics g, Font font, int x, int y, int width, int height, int charge, boolean showText) {
      g.fill(x - 2, y - 1, x, y + height + 1, 0xFF3F444C);
      g.fill(x + width, y - 1, x + width + 2, y + height + 1, 0xFF3F444C);
      g.fill(x, y, x + width, y + height, 0xFF0D1710);
      g.renderOutline(x, y, width, height, 0xFF1C2C1E);
      int fillW = (int)Math.round((double)(width - 2) * ((double)Math.max(0, Math.min(100, charge)) / 100.0));
      int textX;
      int textColor;
      if (fillW > 0) {
         textX = charge > 25 ? 0xFF199E39 : (charge > 10 ? 0xFFB28800 : 0xFF9E1D19);
         textColor = charge > 25 ? 0xFF2FE65B : (charge > 10 ? 0xFFFFCA18 : 0xFFE62F29);
         int fluidTop = charge > 25 ? 0xFF85FFA4 : (charge > 10 ? -6027 : 0xFFFF8582);
         g.fill(x + 1, y + 1, x + 1 + fillW, y + height - 1, textColor);
         g.fill(x + 1, y + height - 3, x + 1 + fillW, y + height - 1, textX);
         g.fill(x + 1, y + 1, x + 1 + fillW, y + 2, fluidTop);
         if (fillW < width - 2) {
            g.fill(x + fillW, y + 1, x + 1 + fillW, y + height - 1, fluidTop);
         }
      }

      for(textX = 25; textX <= 75; textX += 25) {
         textColor = x + 1 + (int)((double)(width - 2) * ((double)textX / 100.0));
         g.fill(textColor, y + 1, textColor + 1, y + 4, 0x55FFFFFF);
         g.fill(textColor, y + height - 4, textColor + 1, y + height - 1, 0x55000000);
      }

      g.fill(x + 2, y + 1, x + width - 2, y + 2, 0x33FFFFFF);
      if (showText && font != null) {
         textX = x + width + 6;
         textColor = charge > 25 ? 0xFF3DE665 : (charge > 10 ? 0xFFFFB326 : 0xFFFF4444);
         g.drawString(font, "" + charge + "%", textX, y + (height - 8) / 2, textColor, true);
      }

   }

   public static void renderRivet(GuiGraphics g, int rx, int ry) {
      g.fill(rx, ry, rx + 3, ry + 3, 0xFF121417);
      g.fill(rx + 1, ry + 1, rx + 2, ry + 2, 0xFF5C636E);
   }

   public static void renderLed(GuiGraphics g, int x, int y, int color) {
      g.fill(x, y, x + 4, y + 4, 0xFF101214);
      g.fill(x + 1, y + 1, x + 3, y + 3, color);
      g.fill(x + 1, y + 1, x + 2, y + 2, -1);
   }
}
