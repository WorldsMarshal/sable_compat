package com.invfix.rick.portalgun;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidUtil;
import net.neoforged.neoforge.fluids.capability.IFluidHandlerItem;
import org.jetbrains.annotations.Nullable;

/**
 * Заправка «по-оригинальному»: пушка в одной руке, портальная жидкость в другой,
 * правый клик.
 *
 * Почему через событие, а не внутри PortalGunItem.use.
 *
 * Порядок рук в ваниле фиксирован: сначала срабатывает главная рука, потом
 * вторая. Если ведро окажется в главной руке, оно успеет вылить жидкость на
 * землю раньше, чем пушка во второй руке о чём-то узнает. Событие же
 * перехватывает клик до вызова use() у любого предмета, поэтому работает при
 * любом раскладе рук и не даёт ведру пролиться.
 *
 * Ловятся оба варианта клика — по блоку и по воздуху, потому что целиться при
 * заправке игрок может куда угодно.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class PortalGunRefuelHandler {

    private PortalGunRefuelHandler() {}

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        handle(event, event.getEntity());
    }

    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        handle(event, event.getEntity());
    }

    private static void handle(PlayerInteractEvent event, Player player) {
        // Shift + ПКМ у пушки открывает настройку — туда не лезем.
        if (player.isShiftKeyDown()) return;

        ItemStack main = player.getMainHandItem();
        ItemStack off = player.getOffhandItem();

        InteractionHand gunHand;
        InteractionHand fluidHand;

        if (main.getItem() instanceof PortalGunItem && isPortalFluid(off)) {
            gunHand = InteractionHand.MAIN_HAND;
            fluidHand = InteractionHand.OFF_HAND;
        } else if (off.getItem() instanceof PortalGunItem && isPortalFluid(main)) {
            gunHand = InteractionHand.OFF_HAND;
            fluidHand = InteractionHand.MAIN_HAND;
        } else {
            return;
        }

        ItemStack gun = player.getItemInHand(gunHand);
        if (PortalGunItem.fuel(gun) >= PortalGunItem.CAPACITY) return;

        // Гасим клик на обеих сторонах, иначе клиент проиграет выстрел или
        // выливание ведра, которых на сервере не произойдёт.
        if (event instanceof net.neoforged.bus.api.ICancellableEvent cancellable) {
            cancellable.setCanceled(true);
        }

        if (event instanceof PlayerInteractEvent.RightClickBlock blockEvent) {
            blockEvent.setCancellationResult(InteractionResult.SUCCESS);
        } else if (event instanceof PlayerInteractEvent.RightClickItem itemEvent) {
            itemEvent.setCancellationResult(InteractionResult.SUCCESS);
        }

        player.swing(fluidHand, true);

        if (player.level().isClientSide) return;

        ItemStack fluid = player.getItemInHand(fluidHand);
        // За клик расходуется ровно одна единица тары: иначе стопка бутыльков
        // ушла бы в бак целиком и остаток пропал бы.
        ItemStack single = fluid.copyWithCount(1);

        var result = FluidUtil.tryEmptyContainer(single, new PortalFluidHandler(gun),
                PortalGunItem.CAPACITY, player, true);
        if (!result.isSuccess()) return;

        // Звук вставки колбы из Rick's stuff (bulb_insert).
        player.level().playSound(null, player.blockPosition(), PortalGunRegistry.SOUND_REFUEL.get(),
                net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.0F);

        ItemStack emptied = result.getResult();
        if (fluid.getCount() == 1) {
            player.setItemInHand(fluidHand, emptied);
        } else {
            fluid.shrink(1);
            if (!emptied.isEmpty() && !player.getInventory().add(emptied)) {
                player.drop(emptied, false);
            }
        }
    }

    /** Тара, из которой реально можно слить именно портальную жидкость. */
    private static boolean isPortalFluid(@Nullable ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        IFluidHandlerItem handler = stack.getCapability(Capabilities.FluidHandler.ITEM);
        if (handler == null) return false;
        FluidStack content = handler.getFluidInTank(0);
        return !content.isEmpty()
                && content.getFluid() == PortalGunRegistry.PORTAL_FLUID_SOURCE.get();
    }
}
