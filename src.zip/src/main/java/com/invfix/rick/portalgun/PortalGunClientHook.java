package com.invfix.rick.portalgun;

import net.minecraft.world.InteractionHand;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.loading.FMLEnvironment;

/**
 * Тонкая прослойка, чтобы предмет мог попросить открыть экран, не ссылаясь на
 * клиентские классы напрямую. На выделенном сервере метод просто ничего не
 * делает, и RuntimeDistCleaner не спотыкается о загрузку клиентского класса.
 */
public final class PortalGunClientHook {

    private PortalGunClientHook() {}

    public static void openSettings(InteractionHand hand) {
        if (FMLEnvironment.dist != Dist.CLIENT) return;
        com.invfix.rick.portalgun.client.PortalGunScreenOpener.open(hand);
    }

    /** Отдача у самого стрелка — сразу, не дожидаясь сервера. */
    public static void recoil(int entityId, byte hand) {
        if (FMLEnvironment.dist != Dist.CLIENT) return;
        com.invfix.rick.portalgun.client.PortalGunRecoilManager.triggerRecoilByOrdinal(entityId, hand);
    }
}
