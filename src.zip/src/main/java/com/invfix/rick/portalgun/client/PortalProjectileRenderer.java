package com.invfix.rick.portalgun.client;

import com.invfix.rick.portalgun.PortalGunItem;
import com.invfix.rick.portalgun.PortalProjectileEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;

/**
 * Сгусток в полёте. Порт PortalProjectileRenderer из Rick's stuff 0.0.4.3:
 * вращающееся вытянутое плазменное ядро и крест из четырёх плоскостей-ореолов,
 * тот же шейдер, что у воронки.
 */
@OnlyIn(Dist.CLIENT)
public class PortalProjectileRenderer extends EntityRenderer<PortalProjectileEntity> {

    private static final ResourceLocation PROJECTILE_GREEN = ResourceLocation.fromNamespaceAndPath("sable_compat",
            "textures/entity/portal_gun/green_fluid_projectile.png");
    private static final ResourceLocation PROJECTILE_YELLOW = ResourceLocation.fromNamespaceAndPath("sable_compat",
            "textures/entity/portal_gun/yellow_fluid_projectile.png");
    private static final int FULL_BRIGHT = 0xF000F0;

    public PortalProjectileRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public @NotNull ResourceLocation getTextureLocation(PortalProjectileEntity entity) {
        return entity.getColor() == PortalGunItem.COLOR_YELLOW ? PROJECTILE_YELLOW : PROJECTILE_GREEN;
    }

    @Override
    public void render(PortalProjectileEntity entity, float entityYaw, float partialTicks, PoseStack poseStack,
                       @NotNull MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        float time = entity.tickCount + partialTicks;
        VertexConsumer consumer = buffer.getBuffer(PortalVisualRenderTypes.portal(getTextureLocation(entity)));
        poseStack.mulPose(Axis.YP.rotationDegrees(entity.getYRot() - 90.0F));
        poseStack.mulPose(Axis.ZP.rotationDegrees(entity.getXRot()));
        poseStack.mulPose(Axis.XP.rotationDegrees(time * 30.0F));
        float length = 0.55F;
        renderPlasmaCore(poseStack, consumer, length, 0.07F);
        renderEnergyAura(poseStack, consumer, length * 1.2F, 0.18F);
        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    private void renderPlasmaCore(PoseStack poseStack, VertexConsumer c, float length, float r) {
        PoseStack.Pose p = poseStack.last();
        float halfL = length * 0.5F;
        float headX = halfL;
        float tailX = -halfL;
        float midX = halfL * 0.3F;
        float tailR = r * 0.35F;
        quad(c, p, headX, 0, 0, midX, r, r, midX, -r, r, headX, 0, 0, 0.4F, 0.4F, 0.6F, 0.6F);
        quad(c, p, headX, 0, 0, midX, -r, r, midX, -r, -r, headX, 0, 0, 0.4F, 0.4F, 0.6F, 0.6F);
        quad(c, p, headX, 0, 0, midX, -r, -r, midX, r, -r, headX, 0, 0, 0.4F, 0.4F, 0.6F, 0.6F);
        quad(c, p, headX, 0, 0, midX, r, -r, midX, r, r, headX, 0, 0, 0.4F, 0.4F, 0.6F, 0.6F);
        quad(c, p, midX, r, r, tailX, tailR, tailR, tailX, -tailR, tailR, midX, -r, r, 0.2F, 0.2F, 0.8F, 0.8F);
        quad(c, p, midX, -r, r, tailX, -tailR, tailR, tailX, -tailR, -tailR, midX, -r, -r, 0.2F, 0.2F, 0.8F, 0.8F);
        quad(c, p, midX, -r, -r, tailX, -tailR, -tailR, tailX, tailR, -tailR, midX, r, -r, 0.2F, 0.2F, 0.8F, 0.8F);
        quad(c, p, midX, r, -r, tailX, tailR, -tailR, tailX, tailR, tailR, midX, r, r, 0.2F, 0.2F, 0.8F, 0.8F);
    }

    private void renderEnergyAura(PoseStack poseStack, VertexConsumer c, float length, float halo) {
        PoseStack.Pose p = poseStack.last();
        float halfL = length * 0.5F;
        quad(c, p, -halfL, -halo, 0, halfL, -halo, 0, halfL, halo, 0, -halfL, halo, 0, 0, 0, 1, 1);
        quad(c, p, -halfL, 0, -halo, halfL, 0, -halo, halfL, 0, halo, -halfL, 0, halo, 0, 0, 1, 1);
        float d = halo * 0.707F;
        quad(c, p, -halfL, -d, -d, halfL, -d, -d, halfL, d, d, -halfL, d, d, 0, 0, 1, 1);
        quad(c, p, -halfL, -d, d, halfL, -d, d, halfL, d, -d, -halfL, d, -d, 0, 0, 1, 1);
    }

    private static void quad(VertexConsumer c, PoseStack.Pose p,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             float x3, float y3, float z3, float x4, float y4, float z4,
                             float u1, float v1, float u2, float v2) {
        vertex(c, p, x1, y1, z1, u1, v1);
        vertex(c, p, x2, y2, z2, u2, v1);
        vertex(c, p, x3, y3, z3, u2, v2);
        vertex(c, p, x4, y4, z4, u1, v2);
    }

    private static void vertex(VertexConsumer c, PoseStack.Pose p, float x, float y, float z, float u, float v) {
        c.addVertex(p, x, y, z).setColor(255, 255, 255, 255).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(FULL_BRIGHT).setNormal(p, 0.0F, 1.0F, 0.0F);
    }
}
