package com.invfix.rick.portalgun.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/** Точка входа с общей стороны в клиентский экран. */
@OnlyIn(Dist.CLIENT)
public final class PortalGunScreenOpener {

    private PortalGunScreenOpener() {}

    public static void open(InteractionHand hand) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        mc.setScreen(new PortalGunScreen(hand, mc.player.getItemInHand(hand)));
    }
}
