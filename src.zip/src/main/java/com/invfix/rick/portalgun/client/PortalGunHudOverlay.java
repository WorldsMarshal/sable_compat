package com.invfix.rick.portalgun.client;

import com.invfix.rick.portalgun.PortalGunItem;
import com.invfix.rick.portalgun.PortalMode;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.Locale;

/**
 * Панель пушки над хотбаром: режим и трубка заряда. Порт PortalGunHudOverlay
 * из Rick's stuff 0.0.4.3 (положение по умолчанию — левый нижний угол,
 * отступ 0, масштаб 1, как в конфиге оригинала). Заряд — наш бак в процентах.
 */
@OnlyIn(Dist.CLIENT)
public final class PortalGunHudOverlay {

    private PortalGunHudOverlay() {}

    public static final LayeredDraw.Layer HUD_OVERLAY = (guiGraphics, deltaTracker) -> {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.hideGui) return;
        ItemStack stack = heldGun(player);
        if (stack == null) return;
        renderChargeBar(guiGraphics, mc.font, guiGraphics.guiHeight(), stack);
    };

    private static void renderChargeBar(GuiGraphics g, Font font, int height, ItemStack gun) {
        int charge = PortalGunItem.chargePercent(gun);
        PortalMode mode = PortalGunItem.mode(gun);
        boolean evil = gun.getItem() instanceof PortalGunItem item && item.isEvil();

        int boxW = 120;
        int boxH = 34;
        int x = 0;
        int y = height - boxH;

        g.fill(x - 1, y - 1, x + boxW + 1, y + boxH + 1, 0xFF08090A);
        g.fill(x, y, x + boxW, y + boxH, 0xFF2A2D32);
        g.fill(x, y, x + boxW, y + 1, 0xFF4A4E57);
        g.fill(x, y, x + 1, y + boxH, 0xFF4A4E57);
        g.fill(x, y + boxH - 1, x + boxW, y + boxH, 0xFF141618);
        g.fill(x + boxW - 1, y, x + boxW, y + boxH, 0xFF141618);
        rivet(g, x + 2, y + 2);
        rivet(g, x + boxW - 5, y + 2);
        rivet(g, x + 2, y + boxH - 5);
        rivet(g, x + boxW - 5, y + boxH - 5);

        int screenX = x + 8;
        int screenY = y + 4;
        int screenW = boxW - 16;
        int screenH = 11;
        g.fill(screenX - 1, screenY - 1, screenX + screenW + 1, screenY + screenH + 1, 0xFF101214);
        g.fill(screenX, screenY, screenX + screenW, screenY + screenH, 0xFF061309);
        g.fill(screenX, screenY, screenX + screenW, screenY + 1, 0xFF0B2613);
        String modeText = I18n.get("hud.sable_compat.portal_gun.mode",
                I18n.get(mode.translationKey()).toUpperCase(Locale.ROOT));
        g.drawString(font, modeText, screenX + 3, screenY + 2, 0xFF38E55E, false);

        int ledColor = charge > 20 ? 0xFF00FF66 : (charge > 0 ? 0xFFFFBB00 : 0xFFFF2222);
        g.fill(screenX + screenW - 6, screenY + 3, screenX + screenW - 2, screenY + 7, ledColor);
        g.fill(screenX + screenW - 5, screenY + 4, screenX + screenW - 3, screenY + 6, 0xFFFFFFFF);

        int tubeX = x + 8;
        int tubeY = y + 18;
        int tubeW = 74;
        int tubeH = 10;
        g.fill(tubeX - 2, tubeY - 1, tubeX, tubeY + tubeH + 1, 0xFF3F444C);
        g.fill(tubeX + tubeW, tubeY - 1, tubeX + tubeW + 2, tubeY + tubeH + 1, 0xFF3F444C);
        g.fill(tubeX, tubeY, tubeX + tubeW, tubeY + tubeH, 0xFF0D1710);
        g.renderOutline(tubeX, tubeY, tubeW, tubeH, 0xFF1B2A1E);

        int fillW = Math.round((tubeW - 2) * (Math.max(0, Math.min(100, charge)) / 100.0F));
        if (fillW > 0) {
            int base, mid, top;
            if (evil && charge > 25) {
                base = 0xFF997A0F;
                mid = 0xFFFFD219;
                top = 0xFFFFEE88;
            } else {
                base = charge > 25 ? 0xFF199E39 : (charge > 10 ? 0xFFB28800 : 0xFF9E1D19);
                mid = charge > 25 ? 0xFF2FE65B : (charge > 10 ? 0xFFFFCA18 : 0xFFE62F29);
                top = charge > 25 ? 0xFF85FFA4 : (charge > 10 ? 0xFFFFE875 : 0xFFFF8582);
            }
            g.fill(tubeX + 1, tubeY + 1, tubeX + 1 + fillW, tubeY + tubeH - 1, mid);
            g.fill(tubeX + 1, tubeY + tubeH - 3, tubeX + 1 + fillW, tubeY + tubeH - 1, base);
            g.fill(tubeX + 1, tubeY + 1, tubeX + 1 + fillW, tubeY + 2, top);
            if (fillW < tubeW - 2) g.fill(tubeX + fillW, tubeY + 1, tubeX + 1 + fillW, tubeY + tubeH - 1, top);
        }
        for (int mark = 25; mark <= 75; mark += 25) {
            int mx = tubeX + 1 + (int) ((tubeW - 2) * (mark / 100.0));
            g.fill(mx, tubeY + 1, mx + 1, tubeY + 4, 0x55FFFFFF);
            g.fill(mx, tubeY + tubeH - 4, mx + 1, tubeY + tubeH - 1, 0x55000000);
        }
        g.fill(tubeX + 2, tubeY + 1, tubeX + tubeW - 2, tubeY + 2, 0x33FFFFFF);

        int textColor = charge > 25 ? 0xFF38E55E : (charge > 10 ? 0xFFFFCC22 : 0xFFFF4444);
        g.drawString(font, charge + "%", tubeX + tubeW + 5, tubeY + 1, textColor, true);
    }

    private static void rivet(GuiGraphics g, int rx, int ry) {
        g.fill(rx, ry, rx + 3, ry + 3, 0xFF141618);
        g.fill(rx + 1, ry + 1, rx + 2, ry + 2, 0xFF5A606A);
    }

    private static ItemStack heldGun(LocalPlayer player) {
        if (player.getMainHandItem().getItem() instanceof PortalGunItem) return player.getMainHandItem();
        if (player.getOffhandItem().getItem() instanceof PortalGunItem) return player.getOffhandItem();
        return null;
    }
}
