package com.invfix.rick.portalgun.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Отдача портальной пушки. Порт PortalGunRecoilManager из Rick's stuff 0.0.4.3:
 * 340 мс, пик на 65 мс (синусный набор, затем затухание (1-x)^2.2·cos),
 * повторный выстрел во время отдачи наращивает её (до 1.4). Первое лицо —
 * через миксин ItemInHandRenderer, третье — из рендера самой пушки.
 */
@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class PortalGunRecoilManager {

    public static final float TOTAL_DURATION_MS = 340.0F;
    public static final float PEAK_MS = 65.0F;

    private static int clientTickCount = 0;
    private static final Map<Integer, HandRecoilState> RECOIL_MAP = new ConcurrentHashMap<>();
    private static final HandRecoilState LOCAL_PLAYER_FALLBACK = new HandRecoilState();

    private PortalGunRecoilManager() {}

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        if (Minecraft.getInstance().isPaused()) return;
        ++clientTickCount;
        if (clientTickCount % 40 == 0) {
            long now = System.currentTimeMillis();
            RECOIL_MAP.entrySet().removeIf(entry -> {
                HandRecoilState state = entry.getValue();
                boolean mainDone = state.mainHand.startTimeMs <= 0L || now - state.mainHand.startTimeMs > 2340L;
                boolean offDone = state.offHand.startTimeMs <= 0L || now - state.offHand.startTimeMs > 2340L;
                return mainDone && offDone;
            });
        }
    }

    /** Рука числом из пакета: 0 — основная, 1 — вторая. */
    public static void triggerRecoilByOrdinal(int entityId, int handOrdinal) {
        triggerRecoil(entityId, handOrdinal == 1 ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
    }

    public static void triggerRecoil(int entityId, InteractionHand hand) {
        long now = System.currentTimeMillis();
        Minecraft mc = Minecraft.getInstance();
        HandRecoilState entityState = RECOIL_MAP.computeIfAbsent(entityId, k -> new HandRecoilState());
        triggerStateRecoil(entityState.get(hand), now);
        if (mc.player != null && (entityId == mc.player.getId() || entityId == -1)) {
            triggerStateRecoil(LOCAL_PLAYER_FALLBACK.get(hand), now);
        }
    }

    private static void triggerStateRecoil(RecoilState state, long now) {
        float current = calculateCurrentRecoil(state, now);
        state.startAmount = current;
        state.targetAmount = current > 0.05F ? Math.min(1.4F, current + 0.85F) : 1.0F;
        state.startTimeMs = now;
    }

    public static float getRecoilAmount(int entityId, InteractionHand hand) {
        long now = System.currentTimeMillis();
        HandRecoilState entityState = RECOIL_MAP.get(entityId);
        float amount = entityState != null ? calculateCurrentRecoil(entityState.get(hand), now) : 0.0F;
        if (amount <= 1.0E-4F) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && (entityId == mc.player.getId() || entityId == -1)) {
                amount = calculateCurrentRecoil(LOCAL_PLAYER_FALLBACK.get(hand), now);
            }
        }
        return amount;
    }

    public static float calculateCurrentRecoil(RecoilState state, long now) {
        if (state == null || state.startTimeMs <= 0L) return 0.0F;
        float elapsed = (float) (now - state.startTimeMs);
        if (elapsed < 0.0F || elapsed >= TOTAL_DURATION_MS) return 0.0F;
        if (elapsed < PEAK_MS) {
            float x = Mth.sin(elapsed / PEAK_MS * (float) Math.PI * 0.5F);
            return state.startAmount + (state.targetAmount - state.startAmount) * x;
        }
        float x = (elapsed - PEAK_MS) / (TOTAL_DURATION_MS - PEAK_MS);
        float decay = (float) Math.pow(1.0F - x, 2.2) * Mth.cos(x * (float) Math.PI * 0.5F);
        return state.targetAmount * decay;
    }

    public static void applyFirstPersonRecoil(PoseStack poseStack, Player player, InteractionHand hand, float partialTick) {
        if (poseStack == null) return;
        int entityId = player != null ? player.getId() : -1;
        float recoil = getRecoilAmount(entityId, hand);
        if (recoil <= 1.0E-4F) recoil = calculateCurrentRecoil(LOCAL_PLAYER_FALLBACK.get(hand), System.currentTimeMillis());
        if (recoil <= 1.0E-4F) return;

        HumanoidArm arm;
        if (player != null) {
            arm = hand == InteractionHand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        } else {
            arm = hand == InteractionHand.MAIN_HAND ? HumanoidArm.RIGHT : HumanoidArm.LEFT;
        }
        float armSign = arm == HumanoidArm.RIGHT ? 1.0F : -1.0F;
        poseStack.translate(-0.01F * armSign * recoil, 0.03F * recoil, 0.18F * recoil);
        poseStack.translate(0.0F, -0.2F, 0.0F);
        poseStack.mulPose(Axis.XP.rotationDegrees(13.5F * recoil));
        poseStack.mulPose(Axis.ZP.rotationDegrees(-1.8F * armSign * recoil));
        poseStack.translate(0.0F, 0.2F, 0.0F);
    }

    /**
     * Третье лицо. Кто держит пушку, рендер предмета не знает — берём игрока,
     * как делает оригинал в отсутствие явной привязки сущности.
     */
    public static void applyThirdPersonRecoil(PoseStack poseStack, ItemDisplayContext context, float partialTick) {
        if (poseStack == null || context == null) return;
        if (context != ItemDisplayContext.THIRD_PERSON_RIGHT_HAND && context != ItemDisplayContext.THIRD_PERSON_LEFT_HAND) return;
        LivingEntity entity = Minecraft.getInstance().player;
        if (entity == null) return;
        boolean isRightHand = context == ItemDisplayContext.THIRD_PERSON_RIGHT_HAND;
        HumanoidArm mainArm = entity.getMainArm();
        InteractionHand hand = isRightHand == (mainArm == HumanoidArm.RIGHT) ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
        float recoil = getRecoilAmount(entity.getId(), hand);
        if (recoil <= 1.0E-4F) return;
        float kickBack = 0.08F * recoil;
        poseStack.translate(0.0F, 0.02F * recoil, -kickBack);
        poseStack.translate(0.0F, -0.1F, 0.0F);
        poseStack.mulPose(Axis.XP.rotationDegrees(-9.0F * recoil));
        poseStack.translate(0.0F, 0.1F, 0.0F);
    }

    public static final class HandRecoilState {
        public final RecoilState mainHand = new RecoilState();
        public final RecoilState offHand = new RecoilState();

        public RecoilState get(InteractionHand hand) {
            return hand == InteractionHand.MAIN_HAND ? mainHand : offHand;
        }
    }

    public static final class RecoilState {
        public long startTimeMs = -1L;
        public float startAmount = 0.0F;
        public float targetAmount = 1.0F;
    }
}
