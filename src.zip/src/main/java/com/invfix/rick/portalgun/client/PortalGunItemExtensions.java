package com.invfix.rick.portalgun.client;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;

/**
 * Клиентские расширения предметов пушки и колбы — как в PortalGunItem
 * оригинала: отрисовка через PortalGunItemRenderer и поза «держит арбалет».
 */
@OnlyIn(Dist.CLIENT)
public final class PortalGunItemExtensions {

    private PortalGunItemExtensions() {}

    public static final IClientItemExtensions GUN = new IClientItemExtensions() {
        @Override
        public BlockEntityWithoutLevelRenderer getCustomRenderer() {
            return PortalGunItemRenderer.getInstance();
        }

        @Override
        public HumanoidModel.ArmPose getArmPose(LivingEntity entity, InteractionHand hand, ItemStack stack) {
            return !stack.isEmpty() ? HumanoidModel.ArmPose.CROSSBOW_HOLD : HumanoidModel.ArmPose.EMPTY;
        }
    };

    public static final IClientItemExtensions BOTTLE = new IClientItemExtensions() {
        @Override
        public BlockEntityWithoutLevelRenderer getCustomRenderer() {
            return PortalGunItemRenderer.getInstance();
        }
    };
}
