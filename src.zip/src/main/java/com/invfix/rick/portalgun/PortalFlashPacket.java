package com.invfix.rick.portalgun;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** S2C: цветная вспышка экрана у прошедшего через портал (S2CTeleportOverlayPacket оригинала). */
public record PortalFlashPacket(int color) implements CustomPacketPayload {

    public static final Type<PortalFlashPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "portal_flash"));

    public static final StreamCodec<FriendlyByteBuf, PortalFlashPacket> STREAM_CODEC =
            StreamCodec.of((buf, p) -> buf.writeVarInt(p.color()), buf -> new PortalFlashPacket(buf.readVarInt()));

    @Override
    public Type<PortalFlashPacket> type() { return TYPE; }
}
