package com.invfix.rick.portalgun.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/** Порт DimensionalSparkParticle из Rick's stuff 0.0.4.3 (зелёный и жёлтый варианты). */
@OnlyIn(Dist.CLIENT)
public class DimensionalSparkParticle extends TextureSheetParticle {
   private final SpriteSet sprites;
   private final float baseQuadSize;

   public DimensionalSparkParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, float r, float g, float b, SpriteSet sprites) {
      super(level, x, y, z, vx, vy, vz);
      this.sprites = sprites;
      this.rCol = r;
      this.gCol = g;
      this.bCol = b;
      this.xd = vx * 0.2 + (Math.random() - 0.5) * 0.04;
      this.yd = vy * 0.2 + (Math.random() - 0.5) * 0.04;
      this.zd = vz * 0.2 + (Math.random() - 0.5) * 0.04;
      this.lifetime = (int)(12.0 + Math.random() * 12.0);
      this.baseQuadSize = 0.06F + (float)(Math.random() * 0.03999999910593033);
      this.quadSize = this.baseQuadSize;
      this.hasPhysics = false;
      this.setSpriteFromAge(sprites);
   }

   @Override
   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @Override
   public int getLightColor(float partialTick) {
      return 15728880;
   }

   @Override
   public void tick() {
      this.xo = this.x;
      this.yo = this.y;
      this.zo = this.z;
      if (this.age++ >= this.lifetime) {
         this.remove();
      } else {
         this.setSpriteFromAge(this.sprites);
         this.move(this.xd, this.yd, this.zd);
         this.xd *= 0.88;
         this.yd *= 0.88;
         this.zd *= 0.88;
         float progress = (float)this.age / (float)this.lifetime;
         this.quadSize = this.baseQuadSize * (float)Math.sin((double)progress * Math.PI);
         this.alpha = 1.0F - progress * progress;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class YellowProvider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public YellowProvider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      @Override
      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new DimensionalSparkParticle(level, x, y, z, vx, vy, vz, 1.0F, 0.9F, 0.1F, this.sprites);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class GreenProvider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public GreenProvider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      @Override
      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new DimensionalSparkParticle(level, x, y, z, vx, vy, vz, 0.15F, 1.0F, 0.15F, this.sprites);
      }
   }
}
