package com.invfix.rick.portalgun;

import java.util.Locale;

/**
 * Режимы портальной пушки.
 *
 * Четыре парных режима перенесены из Rick's stuff (PortalMode: FIFO / LIFO /
 * MULTI_PAIR / ROOT) вместе с их правилами связывания. Пятый — POINT — наш:
 * выстрел открывает пару «место попадания ↔ сохранённая точка» с лимитом
 * проходов, как раньше работала пушка целиком.
 */
public enum PortalMode {
    /** «Цикл»: пара; третий портал вытесняет самый старый. */
    FIFO("cycle"),
    /** «Замена»: пара; третий портал заменяет второй. */
    LIFO("override"),
    /** «Много пар»: каждый чётный портал связывается с предыдущим. */
    MULTI_PAIR("multi_pair"),
    /** «База»: первый портал — корень, все последующие ведут в него. */
    ROOT("hub"),
    /** «Точка»: пара «попадание ↔ выбранная точка», лимит проходов. */
    POINT("point");

    private final String id;

    PortalMode(String id) { this.id = id; }

    public String id() { return id; }

    public String translationKey() { return "portal_mode.sable_compat." + id; }

    public PortalMode next() {
        PortalMode[] v = values();
        return v[(ordinal() + 1) % v.length];
    }

    public PortalMode previous() {
        PortalMode[] v = values();
        return v[(ordinal() - 1 + v.length) % v.length];
    }

    public static PortalMode byId(String id) {
        if (id != null) {
            String clean = id.trim().toLowerCase(Locale.ROOT);
            for (PortalMode m : values()) {
                if (m.id.equals(clean) || m.name().toLowerCase(Locale.ROOT).equals(clean)) return m;
            }
        }
        return FIFO;
    }
}
