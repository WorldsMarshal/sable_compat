package com.invfix.rick.portalgun;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Игровые события портальной системы (из CommonEvents Rick's stuff):
 *  - ЛКМ пушкой по порталу закрывает его, с Shift — вместе с парой;
 *  - снаряд, попавший в портал, пролетает насквозь; поплавок удочки гаснет;
 *  - кулдауны телепорта тикают раз в серверный тик.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class PortalGunEvents {

    private PortalGunEvents() {}

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        PortalTeleportEngine.tickServer();
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        PortalManager.clear();
    }

    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent event) {
        if (!(event.getTarget() instanceof PortalEntity portal)) return;
        Player player = event.getEntity();
        ItemStack held = player.getMainHandItem();
        if (!(held.getItem() instanceof PortalGunItem)) return;
        event.setCanceled(true);
        if (!player.level().isClientSide) {
            PortalManager.removePortal(portal, player.isShiftKeyDown());
        }
    }

    /** Без урона от падения рядом с открытым порталом (оригинал: onLivingFall). */
    @SubscribeEvent
    public static void onLivingFall(LivingFallEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity == null || !(entity.level() instanceof ServerLevel level)) return;
        AABB area = entity.getBoundingBox().inflate(0.5, 1.5, 0.5);
        for (PortalEntity p : level.getEntitiesOfClass(PortalEntity.class, area)) {
            if (!p.isRemoved() && !p.isClosing()) {
                event.setCanceled(true);
                event.setDistance(0.0F);
                entity.resetFallDistance();
                return;
            }
        }
    }

    /** То же для самого урона от падения (оригинал: onLivingIncomingDamage, ветка FALL). */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onLivingIncomingDamage(LivingIncomingDamageEvent event) {
        if (!event.getSource().is(DamageTypes.FALL) && !event.getSource().is(DamageTypeTags.IS_FALL)) return;
        LivingEntity entity = event.getEntity();
        if (!(entity.level() instanceof ServerLevel level)) return;
        AABB area = entity.getBoundingBox().inflate(0.5, 1.5, 0.5);
        if (!level.getEntitiesOfClass(PortalEntity.class, area).isEmpty()) {
            event.setCanceled(true);
            entity.resetFallDistance();
        }
    }

    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        Projectile projectile = event.getProjectile();
        if (projectile.level().isClientSide) return;
        if (!(event.getRayTraceResult() instanceof EntityHitResult hit)) return;
        if (!(hit.getEntity() instanceof PortalEntity portal)) return;
        if (projectile instanceof PortalProjectileEntity) return;

        event.setCanceled(true);
        if (projectile instanceof FishingHook hook) {
            hook.discard();
            return;
        }
        portal.handleEntityTeleport(projectile);
    }
}
