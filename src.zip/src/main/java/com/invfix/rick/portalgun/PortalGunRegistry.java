package com.invfix.rick.portalgun;

import com.mojang.serialization.Codec;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.fluids.BaseFlowingFluid;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.fluids.capability.wrappers.FluidBucketWrapper;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/**
 * Реестр портальных пушек, портала, снаряда, портальной жидкости, звуков и частиц.
 *
 * Жидкость своя: в Rick's stuff «портальная жидкость» — только предмет-колба,
 * поэтому настоящий Fluid, его блок, ведро и бутылёк заводятся здесь. Текстуры
 * воды переиспользуются, зелёный цвет даёт тинт из клиентского расширения типа
 * жидкости.
 *
 * Пушки, портал, снаряд, звуки и частицы — порт из Rick's stuff 0.0.4.3
 * (ModItems / ModEntities / ModSounds / ModParticles). Пушка Злого Морти —
 * тот же класс, что и пушка Рика, отличается только цветом (как и в оригинале,
 * где EvilMortyPortalGunItem переопределяет лишь цвет).
 */
public final class PortalGunRegistry {

    private static final String MODID = "sable_compat";

    public static final DeferredRegister<FluidType> FLUID_TYPES =
            DeferredRegister.create(NeoForgeRegistries.Keys.FLUID_TYPES, MODID);
    public static final DeferredRegister<Fluid> FLUIDS =
            DeferredRegister.create(Registries.FLUID, MODID);
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<DataComponentType<?>> COMPONENTS =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, MODID);
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, MODID);
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(Registries.PARTICLE_TYPE, MODID);

    // ================= компоненты =================

    /** Топливо пушки в mB. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> FUEL =
            COMPONENTS.register("portal_fuel", () -> DataComponentType.<Integer>builder()
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT)
                    .build());

    /**
     * Номер пушки. Порталы помнят, какой пушкой открыты: по нему работают
     * режимы связывания и закрытие всех порталов пушки. Выдаётся при первом
     * выстреле, случайный ненулевой.
     */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> GUN_ID =
            COMPONENTS.register("portal_gun_id", () -> DataComponentType.<Integer>builder()
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT)
                    .build());

    /** Точки, выбор, лимит проходов и режим. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<PortalGunData>> GUN_DATA =
            COMPONENTS.register("portal_gun_data", () -> DataComponentType.<PortalGunData>builder()
                    .persistent(PortalGunData.CODEC)
                    .networkSynchronized(PortalGunData.STREAM_CODEC)
                    .build());

    // ================= жидкость =================

    /**
     * Тип жидкости вместе с клиентским расширением.
     *
     * В NeoForge 21.1 расширения типа жидкости задаются именно так — через
     * переопределение initializeClient, а не через RegisterClientExtensionsEvent:
     * то событие здесь живёт в другом пакете и обслуживает эффекты, брони и
     * предметы, но не жидкости.
     *
     * Тело метода выполняется только на клиенте, поэтому анонимный класс с
     * клиентскими типами на выделенном сервере не загружается вообще.
     *
     * Своих текстур нет намеренно: берём ванильные текстуры воды и красим
     * тинтом. Так жидкость сразу получает правильную анимацию течения, а задача
     * «просто зелёная непрозрачная вода» решается одним цветом.
     */
    public static final DeferredHolder<FluidType, FluidType> PORTAL_FLUID_TYPE =
            FLUID_TYPES.register("portal_fluid", () -> new FluidType(FluidType.Properties.create()
                    .descriptionId("block.sable_compat.portal_fluid")
                    .density(1200)
                    .viscosity(1400)
                    .canSwim(true)
                    .canDrown(true)
                    .supportsBoating(false)
                    .canConvertToSource(false)) {

                @Override
                public void initializeClient(java.util.function.Consumer<
                        net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions> consumer) {
                    consumer.accept(new net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions() {
                        @Override public ResourceLocation getStillTexture() {
                            return ResourceLocation.withDefaultNamespace("block/water_still");
                        }
                        @Override public ResourceLocation getFlowingTexture() {
                            return ResourceLocation.withDefaultNamespace("block/water_flow");
                        }
                        @Override public ResourceLocation getOverlayTexture() {
                            return ResourceLocation.withDefaultNamespace("block/water_overlay");
                        }
                        /** Альфа полная — жидкость непрозрачная. */
                        @Override public int getTintColor() { return 0xFF2FBF3F; }
                    });
                }
            });

    public static final DeferredHolder<Fluid, BaseFlowingFluid.Source> PORTAL_FLUID_SOURCE =
            FLUIDS.register("portal_fluid", () -> new BaseFlowingFluid.Source(fluidProperties()));

    public static final DeferredHolder<Fluid, BaseFlowingFluid.Flowing> PORTAL_FLUID_FLOWING =
            FLUIDS.register("portal_fluid_flowing", () -> new BaseFlowingFluid.Flowing(fluidProperties()));

    public static final DeferredBlock<LiquidBlock> PORTAL_FLUID_BLOCK =
            BLOCKS.register("portal_fluid", () -> new LiquidBlock(PORTAL_FLUID_SOURCE.get(),
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_GREEN)
                            .replaceable()
                            .noCollission()
                            .strength(100.0F)
                            .pushReaction(PushReaction.DESTROY)
                            .noLootTable()
                            .liquid()
                            .lightLevel(state -> 6)));

    public static final DeferredItem<BucketItem> PORTAL_FLUID_BUCKET =
            ITEMS.register("portal_fluid_bucket", () -> new BucketItem(PORTAL_FLUID_SOURCE.get(),
                    new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)));

    /**
     * Колба портальной жидкости. Рисуется как колба Rick's stuff (portal_fluid):
     * стеклянная модель плюс светящееся тело жидкости из PortalGunItemRenderer.
     */
    public static final DeferredItem<Item> PORTAL_FLUID_BOTTLE =
            ITEMS.register("portal_fluid_bottle", () -> new Item(new Item.Properties().stacksTo(16)) {
                @Override
                public void initializeClient(java.util.function.Consumer<
                        net.neoforged.neoforge.client.extensions.common.IClientItemExtensions> consumer) {
                    consumer.accept(com.invfix.rick.portalgun.client.PortalGunItemExtensions.BOTTLE);
                }
            });

    // ================= материалы (из Rick's stuff, свойства как в оригинале) =================

    public static final DeferredItem<Item> DARK_MATTER_DUST =
            ITEMS.register("dark_matter_dust", () -> new Item(new Item.Properties().stacksTo(64)));
    public static final DeferredItem<Item> QUANTUM_CHIP =
            ITEMS.register("quantum_chip", () -> new Item(new Item.Properties().stacksTo(64)));
    public static final DeferredItem<Item> QUANTUM_ISOTOPE =
            ITEMS.register("quantum_isotope", () -> new Item(new Item.Properties().stacksTo(64)));
    public static final DeferredItem<Item> SUBQUANTUM_RESONATOR =
            ITEMS.register("subquantum_resonator", () -> new Item(new Item.Properties().stacksTo(64).fireResistant()));
    public static final DeferredItem<Item> TACHYON_INHIBITOR_CORE =
            ITEMS.register("tachyon_inhibitor_core", () -> new Item(new Item.Properties().stacksTo(16).fireResistant()));
    public static final DeferredItem<Item> MICROVERSE_BATTERY =
            ITEMS.register("microverse_battery",
                    () -> new MicroverseBatteryItem(new Item.Properties().stacksTo(16).fireResistant()));

    /**
     * Свойства обеих форм жидкости. Отдельным методом, потому что источник и
     * поток обязаны получить ОДИН И ТОТ ЖЕ набор ссылок, иначе они не считают
     * друг друга родственными и вода начинает вести себя как две разные.
     */
    private static BaseFlowingFluid.Properties fluidProperties() {
        return new BaseFlowingFluid.Properties(PORTAL_FLUID_TYPE, PORTAL_FLUID_SOURCE, PORTAL_FLUID_FLOWING)
                .block(PORTAL_FLUID_BLOCK)
                .bucket(PORTAL_FLUID_BUCKET)
                .slopeFindDistance(3)
                .levelDecreasePerBlock(2);
    }

    // ================= пушка и портал =================

    public static final DeferredItem<PortalGunItem> PORTAL_GUN =
            ITEMS.register("rick_portal_gun",
                    () -> new PortalGunItem(new Item.Properties().stacksTo(1).fireResistant(),
                            PortalGunItem.COLOR_GREEN));

    public static final DeferredItem<PortalGunItem> EVIL_PORTAL_GUN =
            ITEMS.register("evil_morty_portal_gun",
                    () -> new PortalGunItem(new Item.Properties().stacksTo(1).fireResistant(),
                            PortalGunItem.COLOR_YELLOW));

    public static final DeferredRegister<net.minecraft.world.entity.EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MODID);

    /**
     * Портал — сущность, а не блок: так он встаёт на стену, пол, потолок и в
     * воздух. Габарит задаёт сам портал (getDimensions по ориентации и
     * масштабу), размер здесь — стартовый, как в Rick's stuff (1.2 x 2.2).
     * Идентификатор прежний, rick_portal: старые порталы из мира загрузятся
     * в новый класс, распознаются как устаревшие и закроются сами.
     */
    public static final DeferredHolder<net.minecraft.world.entity.EntityType<?>,
            net.minecraft.world.entity.EntityType<PortalEntity>> PORTAL_ENTITY =
            ENTITIES.register("rick_portal", () -> net.minecraft.world.entity.EntityType.Builder
                    .<PortalEntity>of(PortalEntity::new, net.minecraft.world.entity.MobCategory.MISC)
                    .sized(1.2F, 2.2F)
                    .fireImmune()
                    .noSummon()
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .build("rick_portal"));

    /** Сгусток портальной жидкости, летящий из пушки. */
    public static final DeferredHolder<net.minecraft.world.entity.EntityType<?>,
            net.minecraft.world.entity.EntityType<PortalProjectileEntity>> PORTAL_PROJECTILE =
            ENTITIES.register("portal_projectile", () -> net.minecraft.world.entity.EntityType.Builder
                    .<PortalProjectileEntity>of(PortalProjectileEntity::new, net.minecraft.world.entity.MobCategory.MISC)
                    .sized(0.25F, 0.25F)
                    .noSummon()
                    .clientTrackingRange(8)
                    .updateInterval(1)
                    .build("portal_projectile"));

    // ================= звуки =================

    public static final DeferredHolder<SoundEvent, SoundEvent> SOUND_GUN_FIRE = sound("portal_gun_fire");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOUND_GUN_EMPTY = sound("portal_gun_empty");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOUND_GUN_MALFUNCTION = sound("portal_gun_malfunction");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOUND_PORTAL_OPEN = sound("portal_open");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOUND_PORTAL_CLOSE = sound("portal_close");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOUND_PORTAL_TELEPORT = sound("portal_teleport");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOUND_PLASMA_SCORCH = sound("portal_plasma_scorch");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOUND_MENU_OPEN = sound("portal_gun_menu_open");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOUND_UI_PRESS = sound("portal_gun_ui_press");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOUND_UI_DIAL = sound("portal_gun_ui_dial");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOUND_REFUEL = sound("portal_gun_refuel");

    private static DeferredHolder<SoundEvent, SoundEvent> sound(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(MODID, name)));
    }

    // ================= частицы =================

    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> GREEN_DIMENSIONAL_SPARK = particle("green_dimensional_spark");
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> YELLOW_DIMENSIONAL_SPARK = particle("yellow_dimensional_spark");
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> GREEN_FLUID_DROPLET = particle("green_fluid_droplet");
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> YELLOW_FLUID_DROPLET = particle("yellow_fluid_droplet");
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> GREEN_PLASMA_SHOCKWAVE = particle("green_plasma_shockwave");
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> YELLOW_PLASMA_SHOCKWAVE = particle("yellow_plasma_shockwave");
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> GREEN_VORTEX_BEAM = particle("green_vortex_beam");
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> YELLOW_VORTEX_BEAM = particle("yellow_vortex_beam");
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> GREEN_FLUID_POISON = particle("green_fluid_poison");
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> YELLOW_FLUID_POISON = particle("yellow_fluid_poison");
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> GREEN_FLUID_GROUND_DROP = particle("green_fluid_ground_drop");
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> YELLOW_FLUID_GROUND_DROP = particle("yellow_fluid_ground_drop");
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> FLUID_EVAPORATION = particle("fluid_evaporation");

    private static DeferredHolder<ParticleType<?>, SimpleParticleType> particle(String name) {
        return PARTICLES.register(name, () -> new SimpleParticleType(false));
    }

    /** Частицы по цвету пушки: 0 — зелёные (Рик), 2 — жёлтые (Злой Морти). */
    public static SimpleParticleType spark(int color) {
        return (color == PortalGunItem.COLOR_YELLOW ? YELLOW_DIMENSIONAL_SPARK : GREEN_DIMENSIONAL_SPARK).get();
    }

    public static SimpleParticleType droplet(int color) {
        return (color == PortalGunItem.COLOR_YELLOW ? YELLOW_FLUID_DROPLET : GREEN_FLUID_DROPLET).get();
    }

    public static SimpleParticleType shockwave(int color) {
        return (color == PortalGunItem.COLOR_YELLOW ? YELLOW_PLASMA_SHOCKWAVE : GREEN_PLASMA_SHOCKWAVE).get();
    }

    public static SimpleParticleType vortexBeam(int color) {
        return (color == PortalGunItem.COLOR_YELLOW ? YELLOW_VORTEX_BEAM : GREEN_VORTEX_BEAM).get();
    }

    public static SimpleParticleType poison(int color) {
        return (color == PortalGunItem.COLOR_YELLOW ? YELLOW_FLUID_POISON : GREEN_FLUID_POISON).get();
    }

    public static SimpleParticleType groundDrop(int color) {
        return (color == PortalGunItem.COLOR_YELLOW ? YELLOW_FLUID_GROUND_DROP : GREEN_FLUID_GROUND_DROP).get();
    }

    private PortalGunRegistry() {}

    public static void register(IEventBus modEventBus) {
        COMPONENTS.register(modEventBus);
        SOUNDS.register(modEventBus);
        PARTICLES.register(modEventBus);
        FLUID_TYPES.register(modEventBus);
        FLUIDS.register(modEventBus);
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        ENTITIES.register(modEventBus);
        modEventBus.addListener(PortalGunRegistry::onRegisterCapabilities);
        modEventBus.addListener(PortalGunRegistry::onBuildCreativeTabs);
    }

    private static void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
        // Бак пушки: её заправляет всё, что умеет лить в предмет, включая нижний
        // слот бака в панели Рика.
        event.registerItem(Capabilities.FluidHandler.ITEM,
                (stack, ctx) -> new PortalFluidHandler(stack), PORTAL_GUN.get(), EVIL_PORTAL_GUN.get());

        event.registerItem(Capabilities.FluidHandler.ITEM,
                (stack, ctx) -> new FluidBucketWrapper(stack), PORTAL_FLUID_BUCKET.get());

        event.registerItem(Capabilities.FluidHandler.ITEM,
                (stack, ctx) -> new PortalBottleHandler(stack, true), PORTAL_FLUID_BOTTLE.get());

        // Пустая стеклянная бутылка умеет принять ровно 250 mB и стать полной.
        event.registerItem(Capabilities.FluidHandler.ITEM,
                (stack, ctx) -> new PortalBottleHandler(stack, false), Items.GLASS_BOTTLE);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(PORTAL_GUN);
            event.accept(EVIL_PORTAL_GUN);
        }
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(PORTAL_FLUID_BUCKET);
            event.accept(PORTAL_FLUID_BOTTLE);
            event.accept(DARK_MATTER_DUST);
            event.accept(QUANTUM_CHIP);
            event.accept(QUANTUM_ISOTOPE);
            event.accept(SUBQUANTUM_RESONATOR);
            event.accept(TACHYON_INHIBITOR_CORE);
            event.accept(MICROVERSE_BATTERY);
        }
    }
}
