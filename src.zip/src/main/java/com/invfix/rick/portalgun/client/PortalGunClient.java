package com.invfix.rick.portalgun.client;

import com.invfix.rick.portalgun.PortalGunActionPacket;
import com.invfix.rick.portalgun.PortalGunItem;
import com.invfix.rick.portalgun.PortalGunRegistry;
import com.invfix.rick.portalgun.PortalMode;
import com.invfix.rick.portalgun.client.particle.DimensionalSparkParticle;
import com.invfix.rick.portalgun.client.particle.FluidDropletParticle;
import com.invfix.rick.portalgun.client.particle.FluidEvaporationParticle;
import com.invfix.rick.portalgun.client.particle.FluidGroundDropParticle;
import com.invfix.rick.portalgun.client.particle.FluidPoisonParticle;
import com.invfix.rick.portalgun.client.particle.PlasmaShockwaveParticle;
import com.invfix.rick.portalgun.client.particle.VortexBeamParticle;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.ModelEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.client.settings.KeyConflictContext;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Клиентская часть портальной пушки. Регистрации — как в ClientSetup
 * Rick's stuff 0.0.4.3: рендереры портала и сгустка, частицы, дополнительные
 * модели пушки и колбы, HUD режима и вспышка при проходе, клавиши
 * «закрыть порталы» (R) и «сменить режим» (B), Shift+колесо — смена режима.
 */
@OnlyIn(Dist.CLIENT)
public final class PortalGunClient {

    private PortalGunClient() {}

    private static final String CATEGORY = "key.categories.sable_compat.portal_gun";

    public static final KeyMapping CLOSE_PORTALS_KEY = new KeyMapping("key.sable_compat.close_portals",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, 82, CATEGORY);
    public static final KeyMapping CYCLE_MODE_KEY = new KeyMapping("key.sable_compat.cycle_portal_mode",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, 66, CATEGORY);

    public static void init(IEventBus modEventBus) {
        modEventBus.addListener(PortalGunClient::onSetup);
        modEventBus.addListener(PortalGunClient::onRegisterRenderers);
        modEventBus.addListener(PortalGunClient::onRegisterAdditionalModels);
        modEventBus.addListener(PortalGunClient::onRegisterGuiLayers);
        modEventBus.addListener(PortalGunClient::onRegisterParticles);
        modEventBus.addListener(PortalGunClient::onRegisterKeys);
        NeoForge.EVENT_BUS.addListener(PortalGunClient::onKeyInput);
        NeoForge.EVENT_BUS.addListener(PortalGunClient::onMouseScroll);
    }

    private static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(PortalGunRegistry.PORTAL_ENTITY.get(), PortalEntityRenderer::new);
        event.registerEntityRenderer(PortalGunRegistry.PORTAL_PROJECTILE.get(), PortalProjectileRenderer::new);
    }

    private static void onRegisterAdditionalModels(ModelEvent.RegisterAdditional event) {
        event.register(PortalGunItemRenderer.GUN_MODEL);
        event.register(PortalGunItemRenderer.FLUID_MODEL);
    }

    private static void onRegisterGuiLayers(RegisterGuiLayersEvent event) {
        event.registerAbove(VanillaGuiLayers.HOTBAR,
                ResourceLocation.fromNamespaceAndPath("sable_compat", "portal_gun_hud"), PortalGunHudOverlay.HUD_OVERLAY);
        event.registerAbove(VanillaGuiLayers.CAMERA_OVERLAYS,
                ResourceLocation.fromNamespaceAndPath("sable_compat", "portal_fade_overlay"), PortalFadeOverlay.OVERLAY);
    }

    private static void onRegisterParticles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(PortalGunRegistry.GREEN_DIMENSIONAL_SPARK.get(), DimensionalSparkParticle.GreenProvider::new);
        event.registerSpriteSet(PortalGunRegistry.YELLOW_DIMENSIONAL_SPARK.get(), DimensionalSparkParticle.YellowProvider::new);
        event.registerSpriteSet(PortalGunRegistry.GREEN_FLUID_DROPLET.get(), FluidDropletParticle.GreenProvider::new);
        event.registerSpriteSet(PortalGunRegistry.YELLOW_FLUID_DROPLET.get(), FluidDropletParticle.YellowProvider::new);
        event.registerSpriteSet(PortalGunRegistry.GREEN_PLASMA_SHOCKWAVE.get(), PlasmaShockwaveParticle.GreenProvider::new);
        event.registerSpriteSet(PortalGunRegistry.YELLOW_PLASMA_SHOCKWAVE.get(), PlasmaShockwaveParticle.YellowProvider::new);
        event.registerSpriteSet(PortalGunRegistry.GREEN_VORTEX_BEAM.get(), VortexBeamParticle.GreenProvider::new);
        event.registerSpriteSet(PortalGunRegistry.YELLOW_VORTEX_BEAM.get(), VortexBeamParticle.YellowProvider::new);
        event.registerSpriteSet(PortalGunRegistry.GREEN_FLUID_POISON.get(), FluidPoisonParticle.GreenProvider::new);
        event.registerSpriteSet(PortalGunRegistry.YELLOW_FLUID_POISON.get(), FluidPoisonParticle.YellowProvider::new);
        event.registerSpriteSet(PortalGunRegistry.GREEN_FLUID_GROUND_DROP.get(), FluidGroundDropParticle.GreenProvider::new);
        event.registerSpriteSet(PortalGunRegistry.YELLOW_FLUID_GROUND_DROP.get(), FluidGroundDropParticle.YellowProvider::new);
        event.registerSpriteSet(PortalGunRegistry.FLUID_EVAPORATION.get(), FluidEvaporationParticle.Provider::new);
    }

    private static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(CLOSE_PORTALS_KEY);
        event.register(CYCLE_MODE_KEY);
    }

    private static void onKeyInput(InputEvent.Key event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        while (CLOSE_PORTALS_KEY.consumeClick()) {
            if (mc.screen == null && hasGunAnywhere(mc.player)) {
                PacketDistributor.sendToServer(PortalGunActionPacket.closeAll());
            }
        }
        while (CYCLE_MODE_KEY.consumeClick()) {
            if (mc.screen == null) cycleHeldGunMode(mc.player, true);
        }
    }

    private static void onMouseScroll(InputEvent.MouseScrollingEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null || !mc.player.isShiftKeyDown()) return;
        if (heldGun(mc.player) == null) return;
        double delta = event.getScrollDeltaY();
        if (Math.abs(delta) > 0.01) {
            event.setCanceled(true);
            cycleHeldGunMode(mc.player, delta > 0.0);
        }
    }

    /** Смена режима сразу в руке (для отзывчивого HUD) и на сервере. */
    private static void cycleHeldGunMode(LocalPlayer player, boolean forward) {
        ItemStack stack = heldGun(player);
        if (stack == null) return;
        PortalMode current = PortalGunItem.mode(stack);
        PortalMode next = forward ? current.next() : current.previous();
        stack.set(PortalGunRegistry.GUN_DATA.get(), PortalGunItem.data(stack).withMode(next));
        PacketDistributor.sendToServer(PortalGunActionPacket.setMode(next));
        player.playSound(PortalGunRegistry.SOUND_UI_DIAL.get(), 1.0F, 1.0F);
    }

    private static ItemStack heldGun(LocalPlayer player) {
        ItemStack main = player.getMainHandItem();
        if (main.getItem() instanceof PortalGunItem) return main;
        ItemStack off = player.getOffhandItem();
        if (off.getItem() instanceof PortalGunItem) return off;
        return null;
    }

    private static boolean hasGunAnywhere(LocalPlayer player) {
        if (heldGun(player) != null) return true;
        for (ItemStack stack : player.getInventory().items) {
            if (stack.getItem() instanceof PortalGunItem) return true;
        }
        return false;
    }

    private static void onSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            ItemBlockRenderTypes.setRenderLayer(PortalGunRegistry.PORTAL_FLUID_SOURCE.get(), RenderType.translucent());
            ItemBlockRenderTypes.setRenderLayer(PortalGunRegistry.PORTAL_FLUID_FLOWING.get(), RenderType.translucent());
            ItemBlockRenderTypes.setRenderLayer(PortalGunRegistry.PORTAL_FLUID_BLOCK.get(), RenderType.translucent());
        });
    }
}
