package com.invfix.rick.portalgun.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.slf4j.Logger;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Модель пушки Злого Морти. Порт EvilMortyGunModel из Rick's stuff 0.0.4.3.
 *
 * Модель лежит двоичным мешем (models/entity/evil_morty_portal_gun.mesh):
 * магия «EMPG»/«EVIL», затем little-endian int версия, число квадов корпуса и
 * квадов светового шара, затем вершины по 8 float (x y z nx ny nz u v).
 * Отличие от оригинала — только путь к ресурсам (наше пространство имён) и
 * try-with-resources вместо декомпилированной лестницы меток.
 */
@OnlyIn(Dist.CLIENT)
public final class EvilMortyGunModel {

    private static final Logger LOGGER = LogUtils.getLogger();

    public static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("sable_compat",
            "textures/entity/evil_morty_portal_gun/evil_morty_portal_gun.png");
    private static final String MESH_PATH = "/assets/sable_compat/models/entity/evil_morty_portal_gun.mesh";

    public static final Vector3f TUBE_SOCKET_CENTER = new Vector3f(-0.03125F, 0.4375F, 0.15F);
    public static final float TUBE_SOCKET_ROT_X = -31.0F;
    public static final Vector3f LIGHT_ORB_CENTER = new Vector3f(0.0F, 0.38125F, 0.39375F);
    public static final float LIGHT_ORB_RADIUS = 0.08125F;

    private static boolean loaded;
    private static boolean failed;
    private static float[] chassisVertices;
    private static float[] lightVertices;
    private static int chassisVertexCount;
    private static int lightVertexCount;

    private EvilMortyGunModel() {}

    public static synchronized void ensureLoaded() {
        if (loaded || failed) return;
        try (InputStream is = EvilMortyGunModel.class.getResourceAsStream(MESH_PATH)) {
            if (is == null) {
                LOGGER.error("Evil Morty portal gun mesh not found: {}", MESH_PATH);
                failed = true;
                return;
            }
            try (DataInputStream dis = new DataInputStream(new BufferedInputStream(is))) {
                byte[] magic = new byte[4];
                dis.readFully(magic);
                boolean validMagic = (magic[0] == 'E' && magic[1] == 'M' && magic[2] == 'P' && magic[3] == 'G')
                        || (magic[0] == 'E' && magic[1] == 'V' && magic[2] == 'I' && magic[3] == 'L');
                if (!validMagic) {
                    LOGGER.error("Invalid magic header in Evil Morty portal gun mesh");
                    failed = true;
                    return;
                }
                byte[] headerBytes = new byte[12];
                dis.readFully(headerBytes);
                ByteBuffer header = ByteBuffer.wrap(headerBytes).order(ByteOrder.LITTLE_ENDIAN);
                int version = header.getInt();
                int chassisQuads = header.getInt();
                int lightQuads = header.getInt();
                chassisVertexCount = chassisQuads * 4;
                lightVertexCount = lightQuads * 4;
                chassisVertices = readFloats(dis, chassisVertexCount * 8);
                lightVertices = readFloats(dis, lightVertexCount * 8);
                loaded = true;
                LOGGER.info("Loaded Evil Morty portal gun mesh: {} chassis quads, {} light quads (version {})",
                        chassisQuads, lightQuads, version);
            }
        } catch (Exception e) {
            failed = true;
            LOGGER.error("Failed to load Evil Morty portal gun mesh", e);
        }
    }

    private static float[] readFloats(DataInputStream dis, int count) throws java.io.IOException {
        if (count <= 0) return new float[0];
        byte[] data = new byte[count * 4];
        dis.readFully(data);
        float[] out = new float[count];
        ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(out);
        return out;
    }

    public static void renderChassis(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                                     float r, float g, float b, float a) {
        ensureLoaded();
        if (!loaded || chassisVertices == null) return;
        Matrix4f pose = poseStack.last().pose();
        Matrix3f normal = poseStack.last().normal();
        for (int i = 0; i < chassisVertexCount; ++i) {
            int o = i * 8;
            float nx = chassisVertices[o + 3];
            float ny = chassisVertices[o + 4];
            float nz = chassisVertices[o + 5];
            float tnx = normal.m00 * nx + normal.m10 * ny + normal.m20 * nz;
            float tny = normal.m01 * nx + normal.m11 * ny + normal.m21 * nz;
            float tnz = normal.m02 * nx + normal.m12 * ny + normal.m22 * nz;
            buffer.addVertex(pose, chassisVertices[o], chassisVertices[o + 1], chassisVertices[o + 2])
                    .setColor(r, g, b, a)
                    .setUv(chassisVertices[o + 6], chassisVertices[o + 7])
                    .setOverlay(packedOverlay)
                    .setLight(packedLight)
                    .setNormal(tnx, tny, tnz);
        }
    }

    /** Световой шар в формате POSITION_COLOR, растянутый от своего центра. */
    public static void renderGlowingSpherePosColor(PoseStack poseStack, VertexConsumer buffer, float scale,
                                                   int r, int g, int b, int a) {
        ensureLoaded();
        if (!loaded || lightVertices == null) return;
        Matrix4f pose = poseStack.last().pose();
        for (int i = 0; i < lightVertexCount; ++i) {
            int o = i * 8;
            float x = (lightVertices[o] - LIGHT_ORB_CENTER.x) * scale + LIGHT_ORB_CENTER.x;
            float y = (lightVertices[o + 1] - LIGHT_ORB_CENTER.y) * scale + LIGHT_ORB_CENTER.y;
            float z = (lightVertices[o + 2] - LIGHT_ORB_CENTER.z) * scale + LIGHT_ORB_CENTER.z;
            buffer.addVertex(pose, x, y, z).setColor(r, g, b, a);
        }
    }
}
