package com.invfix.rick.portalgun.client;

import com.invfix.rick.portalgun.PortalGunItem;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.LayeredDraw;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/**
 * Вспышка экрана при проходе портала. Порт PortalFadeOverlay из Rick's stuff
 * 0.0.4.3: 600 мс, нарастание до 75% к 45% длительности и спад; зелёная для
 * порталов Рика (40,240,70), жёлтая для Злого Морти (255,225,30).
 */
@OnlyIn(Dist.CLIENT)
public final class PortalFadeOverlay {

    private static final long DURATION_MS = 600L;
    private static long startTime = -1L;
    private static int currentColor = PortalGunItem.COLOR_GREEN;

    private PortalFadeOverlay() {}

    public static final LayeredDraw.Layer OVERLAY = (guiGraphics, deltaTracker) -> {
        if (startTime < 0L) return;
        long elapsed = System.currentTimeMillis() - startTime;
        if (elapsed >= DURATION_MS) {
            startTime = -1L;
            return;
        }
        float progress = (float) elapsed / DURATION_MS;
        float alpha = progress < 0.45F
                ? progress / 0.45F * 0.75F
                : (1.0F - (progress - 0.45F) / 0.55F) * 0.75F;
        int alphaInt = (int) (Math.max(0.0F, Math.min(1.0F, alpha)) * 255.0F);
        if (alphaInt <= 0) return;
        int rgb = currentColor == PortalGunItem.COLOR_YELLOW ? (255 << 16 | 225 << 8 | 30) : (40 << 16 | 240 << 8 | 70);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.fill(0, 0, guiGraphics.guiWidth(), guiGraphics.guiHeight(), alphaInt << 24 | rgb);
        RenderSystem.disableBlend();
    };

    public static void trigger(int color) {
        startTime = System.currentTimeMillis();
        currentColor = color;
    }
}
