package com.invfix.rick.portalgun;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

/**
 * Одна сохранённая точка портальной пушки: подпись, координаты и измерение.
 *
 * Измерение хранится как ResourceLocation, а не как ResourceKey, чтобы точка
 * пережила отсутствие измерения — если мод, добавлявший мир, снят, запись
 * останется в списке и её можно будет удалить вручную, а не потерять всю пушку.
 */
public record PortalPoint(String label, BlockPos pos, ResourceLocation dimension) {

    public static final int MAX_LABEL = 24;

    public static final PortalPoint EMPTY =
            new PortalPoint("", BlockPos.ZERO, Level.OVERWORLD.location());

    public static final Codec<PortalPoint> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            Codec.STRING.fieldOf("label").forGetter(PortalPoint::label),
            BlockPos.CODEC.fieldOf("pos").forGetter(PortalPoint::pos),
            ResourceLocation.CODEC.fieldOf("dimension").forGetter(PortalPoint::dimension)
    ).apply(inst, PortalPoint::new));

    public static final StreamCodec<RegistryFriendlyByteBuf, PortalPoint> STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.STRING_UTF8, PortalPoint::label,
                    BlockPos.STREAM_CODEC, PortalPoint::pos,
                    ResourceLocation.STREAM_CODEC, PortalPoint::dimension,
                    PortalPoint::new);

    public boolean isSet() {
        return !(pos.equals(BlockPos.ZERO) && label.isEmpty());
    }

    public ResourceKey<Level> dimensionKey() {
        return ResourceKey.create(net.minecraft.core.registries.Registries.DIMENSION, dimension);
    }

    /** Подпись для показа: если пусто — сами координаты. */
    public String display() {
        if (!label.isBlank()) return label;
        return pos.getX() + " " + pos.getY() + " " + pos.getZ();
    }

    public static String sanitize(String raw) {
        String s = raw == null ? "" : raw.strip();
        return s.length() > MAX_LABEL ? s.substring(0, MAX_LABEL) : s;
    }
}
