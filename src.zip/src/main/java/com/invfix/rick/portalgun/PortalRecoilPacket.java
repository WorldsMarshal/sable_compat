package com.invfix.rick.portalgun;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** S2C: отдача пушки у стрелявшего — другим игрокам рядом (S2CGunRecoilPacket оригинала). */
public record PortalRecoilPacket(int entityId, byte hand) implements CustomPacketPayload {

    public static final Type<PortalRecoilPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "portal_gun_recoil"));

    public static final StreamCodec<FriendlyByteBuf, PortalRecoilPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, p) -> { buf.writeVarInt(p.entityId()); buf.writeByte(p.hand()); },
                    buf -> new PortalRecoilPacket(buf.readVarInt(), buf.readByte()));

    @Override
    public Type<PortalRecoilPacket> type() { return TYPE; }
}
