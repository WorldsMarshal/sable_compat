package com.invfix.rick.portalgun;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.ChatFormatting;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Открытие, связывание и закрытие порталов. Порт PortalManager из Rick's stuff
 * 0.0.4.3 (handlePortalSpawn / handleAirPortalSpawn / applyModeLinking /
 * linkPortals / removePortal / closeOverlappingPortals /
 * removeAllPortalsForGun / playPortalCloseSound с троттлингом).
 *
 * Список порталов пушки хранится здесь, в памяти сервера, как ссылки
 * «измерение + UUID», а не в NBT предмета, как в оригинале: пушка в руке
 * игрока не переписывается на каждый выстрел. После перезапуска сервера список
 * пуст — старые порталы доживают свой срок и закрываются сами, а «закрыть все»
 * дополнительно обходит сущности загруженных миров по номеру пушки.
 *
 * Режим CUSTOM оригинала («GPS») заменён нашим POINT: дальний портал встаёт на
 * сохранённую точку пушки, пара получает лимит проходов.
 */
public final class PortalManager {

    private PortalManager() {}

    /** Больше порталов одной пушки в режимах MULTI_PAIR / ROOT — сброс (оригинал). */
    public static final int MAX_PORTALS_PER_GUN = 10;

    private record PortalRef(ResourceKey<Level> dimension, UUID id) {}

    private static final Map<Integer, List<PortalRef>> GUN_PORTALS = new HashMap<>();
    /** Concurrent, как в оригинале: в одиночной игре к нему может прийти и клиентский поток. */
    private static final Map<UUID, PortalProjectileEntity> ACTIVE_PROJECTILES = new java.util.concurrent.ConcurrentHashMap<>();
    private static final Map<ResourceKey<Level>, List<long[]>> RECENT_CLOSE_SOUNDS = new HashMap<>();

    // ================= снаряды =================

    public static void registerProjectile(Player player, PortalProjectileEntity projectile) {
        if (player != null && projectile != null) ACTIVE_PROJECTILES.put(player.getUUID(), projectile);
    }

    @Nullable
    public static PortalProjectileEntity getActiveProjectile(Player player) {
        if (player == null) return null;
        // Клиент (оригинал делает то же поиском по миру): только поиск, без записи в
        // общий реестр — в одиночной игре он общий с сервером.
        if (player.level().isClientSide) return scanOwnedProjectile(player);

        PortalProjectileEntity proj = ACTIVE_PROJECTILES.get(player.getUUID());
        if (proj != null && !proj.isRemoved() && proj.isAlive()) return proj;
        PortalProjectileEntity found = scanOwnedProjectile(player);
        if (found != null) {
            ACTIVE_PROJECTILES.put(player.getUUID(), found);
            return found;
        }
        ACTIVE_PROJECTILES.remove(player.getUUID());
        return null;
    }

    @Nullable
    private static PortalProjectileEntity scanOwnedProjectile(Player player) {
        List<PortalProjectileEntity> list = player.level().getEntitiesOfClass(PortalProjectileEntity.class,
                player.getBoundingBox().inflate(128.0),
                p -> p.getOwner() == player && !p.isRemoved() && p.isAlive());
        return list.isEmpty() ? null : list.get(0);
    }

    public static void unregisterProjectile(PortalProjectileEntity projectile) {
        if (projectile == null || projectile.level().isClientSide) return;
        ACTIVE_PROJECTILES.values().removeIf(p -> p == projectile);
    }

    // ================= звук закрытия =================

    /** Одновременно закрывающаяся пачка порталов звучит один раз (оригинал: 8 тиков, 20 блоков). */
    public static void playPortalCloseSound(PortalEntity portal) {
        if (portal == null || !(portal.level() instanceof ServerLevel level)) return;
        Vec3 pos = portal.position();
        long now = level.getGameTime();
        List<long[]> entries = RECENT_CLOSE_SOUNDS.computeIfAbsent(level.dimension(), k -> new ArrayList<>());
        entries.removeIf(e -> now - e[3] > 30L || e[3] > now);
        for (long[] e : entries) {
            if (Math.abs(now - e[3]) <= 8L) {
                double dx = pos.x - Double.longBitsToDouble(e[0]);
                double dy = pos.y - Double.longBitsToDouble(e[1]);
                double dz = pos.z - Double.longBitsToDouble(e[2]);
                if (dx * dx + dy * dy + dz * dz <= 400.0) return;
            }
        }
        entries.add(new long[]{Double.doubleToLongBits(pos.x), Double.doubleToLongBits(pos.y),
                Double.doubleToLongBits(pos.z), now});
        level.playSound(null, pos.x, pos.y, pos.z, PortalGunRegistry.SOUND_PORTAL_CLOSE.get(),
                SoundSource.NEUTRAL, 1.0F, 1.0F);
    }

    private static void triggerMalfunction(ServerLevel level, Vec3 pos, @Nullable Player player, @Nullable String messageKey) {
        level.playSound(null, pos.x, pos.y, pos.z, PortalGunRegistry.SOUND_GUN_MALFUNCTION.get(),
                SoundSource.PLAYERS, 1.0F, 1.0F);
        for (int i = 0; i < 16; ++i) {
            level.sendParticles(PortalGunRegistry.FLUID_EVAPORATION.get(),
                    pos.x + (level.random.nextDouble() - 0.5) * 0.8,
                    pos.y + (level.random.nextDouble() - 0.5) * 0.8,
                    pos.z + (level.random.nextDouble() - 0.5) * 0.8, 1,
                    (level.random.nextDouble() - 0.5) * 0.1, level.random.nextDouble() * 0.1,
                    (level.random.nextDouble() - 0.5) * 0.1, 0.05);
        }
        if (player != null && messageKey != null) {
            player.displayClientMessage(Component.translatable(messageKey).withStyle(ChatFormatting.RED), true);
        }
    }

    // ================= открытие =================

    @Nullable
    public static PortalEntity handlePortalSpawn(ServerLevel level, BlockHitResult hit, PortalProjectileEntity projectile) {
        if (level == null || hit == null || projectile == null) return null;
        Player player = projectile.ownerPlayer();
        PortalPlacementHelper.Placement placement = PortalPlacementHelper.calculatePlacement(hit, player, level);
        PortalEntity portal = spawnPortal(level, placement.pos(), placement.orientation(), placement.rotation(),
                placement.yaw(), projectile, player);
        unregisterProjectile(projectile);
        return portal;
    }

    /** Повторное нажатие, пока снаряд в полёте: портал открывается прямо в воздухе. */
    @Nullable
    public static PortalEntity handleAirPortalSpawn(ServerLevel level, Vec3 pos, PortalProjectileEntity projectile) {
        if (level == null || pos == null || projectile == null) return null;
        Player player = projectile.ownerPlayer();
        float pitch = player != null ? player.getXRot() : 0.0F;
        Vec3 vel = projectile.getDeltaMovement();
        double horizontalSpeed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
        float rawYaw = player != null ? player.getYRot() : projectile.getYRot();
        float normalizedYaw = (rawYaw % 360.0F + 360.0F) % 360.0F;
        int cardinalSector = Math.round(normalizedYaw / 90.0F) % 4;
        float yaw = cardinalSector * 90.0F;

        int orientation;
        if (pitch < -45.0F || (vel.y > 0.35 && vel.y > horizontalSpeed * 0.9)) {
            orientation = PortalEntity.ORIENTATION_CEILING;
        } else if (pitch > 45.0F || (vel.y < -0.35 && -vel.y > horizontalSpeed * 0.9)) {
            orientation = PortalEntity.ORIENTATION_FLOOR;
        } else {
            orientation = PortalEntity.ORIENTATION_WALL;
        }

        Vec3 adjusted = PortalPlacementHelper.adjustAirPortalPosition(level, pos, orientation, yaw, PortalGunItem.PORTAL_SCALE);
        PortalEntity portal = spawnPortal(level, adjusted, orientation, cardinalSector, yaw, projectile, player);
        unregisterProjectile(projectile);
        projectile.discard();
        return portal;
    }

    @Nullable
    private static PortalEntity spawnPortal(ServerLevel level, Vec3 pos, int orientation, int rotation, float yaw,
                                            PortalProjectileEntity projectile, @Nullable Player player) {
        PortalMode mode = projectile.getMode();
        int gunId = projectile.getGunId();

        // Режим POINT: цель проверяется ДО открытия, чтобы не мигнуть порталом впустую.
        ServerLevel targetLevel = null;
        Vec3 targetPos = null;
        if (mode == PortalMode.POINT) {
            PortalPoint point = projectile.getTarget();
            if (point == null || !point.isSet()) {
                triggerMalfunction(level, pos, player, "message.sable_compat.portal_gun.no_point");
                return null;
            }
            targetLevel = level.getServer().getLevel(point.dimensionKey());
            if (targetLevel == null) {
                triggerMalfunction(level, pos, player, "message.sable_compat.portal_gun.no_dimension");
                return null;
            }
            BlockPos p = point.pos();
            targetLevel.getChunk(p);
            targetPos = PortalPlacementHelper.findPointPlacement(targetLevel, p);
            if (targetLevel == level && isTooClose(pos, targetPos, p)) {
                triggerMalfunction(level, pos, player, "message.sable_compat.portal_gun.too_close");
                return null;
            }
        }

        closeOverlappingPortals(level, pos, 1.25, null);
        PortalEntity portal = createPortal(level, pos, orientation, rotation, yaw, projectile.getColor(), gunId, mode);
        // Лимит проходов — во всех режимах, у каждого портала свой счётчик.
        portal.setPassesLeft(projectile.getPassLimit());
        applyModeLinking(level, portal, gunId, mode, projectile, targetLevel, targetPos);
        return portal;
    }

    /** Оригинальная проверка «слишком близко» (dist < 3.5 или горизонталь < 3 при разнице высот < 6). */
    private static boolean isTooClose(Vec3 spawnPos, Vec3 safePos, BlockPos raw) {
        double dx = safePos.x - spawnPos.x;
        double dz = safePos.z - spawnPos.z;
        double dy = Math.abs(safePos.y - spawnPos.y);
        double rawDx = raw.getX() + 0.5 - spawnPos.x;
        double rawDz = raw.getZ() + 0.5 - spawnPos.z;
        return safePos.distanceTo(spawnPos) < 3.5
                || (Math.sqrt(dx * dx + dz * dz) < 3.0 && dy < 6.0)
                || (Math.sqrt(rawDx * rawDx + rawDz * rawDz) < 3.0 && Math.abs(raw.getY() - spawnPos.y) < 6.0);
    }

    private static PortalEntity createPortal(ServerLevel level, Vec3 pos, int orientation, int rotation, float yaw,
                                             int color, int gunId, PortalMode mode) {
        PortalEntity portal = new PortalEntity(PortalGunRegistry.PORTAL_ENTITY.get(), level);
        portal.moveTo(pos.x, pos.y, pos.z, yaw, 0.0F);
        portal.setOrientation(orientation);
        portal.setRotation(rotation);
        portal.setColor(color);
        portal.setScale(PortalGunItem.PORTAL_SCALE);
        portal.setOwnerGunId(gunId);
        portal.setGunMode(mode);
        level.addFreshEntity(portal);
        portal.playSound(PortalGunRegistry.SOUND_PORTAL_OPEN.get(), 1.0F, 1.0F);
        PortalPlacementHelper.clearVegetationInPortalArea(level, pos, orientation, yaw, PortalGunItem.PORTAL_SCALE);
        return portal;
    }

    private static void applyModeLinking(ServerLevel level, PortalEntity portal, int gunId, PortalMode mode,
                                         PortalProjectileEntity projectile,
                                         @Nullable ServerLevel targetLevel, @Nullable Vec3 targetPos) {
        if (gunId == 0) return;
        MinecraftServer server = level.getServer();
        List<PortalRef> ids = GUN_PORTALS.computeIfAbsent(gunId, k -> new ArrayList<>());

        List<PortalEntity> active = new ArrayList<>();
        for (PortalRef ref : ids) {
            PortalEntity p = find(server, ref);
            if (p != null && !p.isRemoved() && !p.isClosing()) active.add(p);
        }
        ids.clear();
        for (PortalEntity p : active) ids.add(ref(p));
        ids.add(ref(portal));
        active.add(portal);

        switch (mode) {
            case FIFO -> {
                if (active.size() == 2) {
                    linkPortals(active.get(0), active.get(1));
                } else if (active.size() > 2) {
                    PortalEntity oldest = active.remove(0);
                    removePortal(oldest, false);
                    ids.remove(ref(oldest));
                    linkPortals(active.get(0), active.get(1));
                }
            }
            case LIFO -> {
                if (active.size() == 2) {
                    linkPortals(active.get(0), active.get(1));
                } else if (active.size() > 2) {
                    PortalEntity second = active.remove(1);
                    removePortal(second, false);
                    ids.remove(ref(second));
                    linkPortals(active.get(0), active.get(1));
                }
            }
            case MULTI_PAIR -> {
                if (active.size() > MAX_PORTALS_PER_GUN) {
                    removeAllPortalsForGun(server, gunId, portal);
                    ids.clear();
                    ids.add(ref(portal));
                    // removeAllPortalsForGun выкидывает список из реестра — вернуть, иначе
                    // новый портал «теряется» и следующий выстрел его не видит.
                    GUN_PORTALS.put(gunId, ids);
                } else if (active.size() % 2 == 0) {
                    linkPortals(active.get(active.size() - 2), active.get(active.size() - 1));
                }
            }
            case ROOT -> {
                if (active.size() > MAX_PORTALS_PER_GUN) {
                    removeAllPortalsForGun(server, gunId, portal);
                    ids.clear();
                    ids.add(ref(portal));
                    GUN_PORTALS.put(gunId, ids);
                    portal.setRoot(true);
                } else if (active.size() == 1) {
                    portal.setRoot(true);
                } else {
                    PortalEntity root = active.get(0);
                    root.setRoot(true);
                    portal.setRoot(false);
                    linkPortals(root, portal);
                }
            }
            case POINT -> {
                // Одна пара на пушку: всё прежнее закрывается.
                for (PortalEntity old : active) {
                    if (old != portal) removePortal(old, false);
                }
                ids.clear();
                ids.add(ref(portal));
                if (targetLevel == null || targetPos == null) return;

                closeOverlappingPortals(targetLevel, targetPos, 6.0, portal);
                BlockPos safeBlock = BlockPos.containing(targetPos.x, targetPos.y, targetPos.z);
                boolean hasCeilingSpace = true;
                for (int dy = 1; dy <= 3; ++dy) {
                    BlockState above = targetLevel.getBlockState(safeBlock.above(dy));
                    if (!above.isAir() && above.blocksMotion()) {
                        hasCeilingSpace = false;
                        break;
                    }
                }
                // Как у «GPS» оригинала: с запасом по высоте — иногда над головой, иначе стеной.
                boolean overhead = hasCeilingSpace && ThreadLocalRandom.current().nextBoolean();
                int destOrientation = overhead ? PortalEntity.ORIENTATION_CEILING : PortalEntity.ORIENTATION_WALL;
                double destY = overhead ? targetPos.y + 2.85 : targetPos.y + 1.05;
                float destYaw = portal.getYRot();

                PortalEntity dest = createPortal(targetLevel, new Vec3(targetPos.x, destY, targetPos.z),
                        destOrientation, 0, destYaw, portal.getColor(), gunId, PortalMode.POINT);
                linkPortals(portal, dest);
                portal.setPassesLeft(projectile.getPassLimit());
                dest.setPassesLeft(projectile.getPassLimit());
                ids.add(ref(dest));
            }
        }
    }

    // ================= связи и закрытие =================

    public static void linkPortals(PortalEntity a, PortalEntity b) {
        if (a == null || b == null || a.isRemoved() || b.isRemoved()) return;
        a.setDuality(b.getUUID(), b.level().dimension());
        a.setLinked(true);
        b.setDuality(a.getUUID(), a.level().dimension());
        b.setLinked(true);
    }

    /** Закрыть портал; removeLinked — вместе с напарником. В режиме POINT пара всегда закрывается целиком. */
    public static void removePortal(PortalEntity portal, boolean removeLinked) {
        if (portal == null) return;
        boolean withLinked = removeLinked || portal.getGunMode() == PortalMode.POINT;
        if (withLinked) {
            PortalEntity linked = findPartner(portal);
            if (linked != null && !linked.isRemoved() && !linked.isClosing()) {
                playPortalCloseSound(linked);
                linked.startClosing();
                forget(linked);
            }
        }
        if (!portal.isRemoved() && !portal.isClosing()) {
            playPortalCloseSound(portal);
            portal.startClosing();
        }
        forget(portal);
    }

    private static void forget(PortalEntity portal) {
        List<PortalRef> ids = GUN_PORTALS.get(portal.getOwnerGunId());
        if (ids != null) ids.remove(ref(portal));
    }

    public static void closeOverlappingPortals(ServerLevel level, Vec3 pos, double radius, @Nullable PortalEntity exclude) {
        if (level == null || pos == null) return;
        AABB box = new AABB(pos.x - radius, pos.y - radius, pos.z - radius, pos.x + radius, pos.y + radius, pos.z + radius);
        for (PortalEntity p : level.getEntitiesOfClass(PortalEntity.class, box)) {
            if (p != exclude && !p.isRemoved() && !p.isClosing() && p.position().distanceToSqr(pos) <= radius * radius) {
                removePortal(p, true);
            }
        }
    }

    /** Закрыть все порталы пушки во всех загруженных мирах. */
    public static int removeAllPortalsForGun(MinecraftServer server, int gunId, @Nullable PortalEntity except) {
        if (server == null || gunId == 0) return 0;
        int closed = 0;
        GUN_PORTALS.remove(gunId);
        for (ServerLevel level : server.getAllLevels()) {
            for (Entity entity : level.getAllEntities()) {
                if (entity instanceof PortalEntity p && p != except && p.getOwnerGunId() == gunId
                        && !p.isRemoved() && !p.isClosing()) {
                    playPortalCloseSound(p);
                    p.startClosing();
                    ++closed;
                }
            }
        }
        return closed;
    }

    // ================= поиск =================

    @Nullable
    public static PortalEntity findPartner(PortalEntity portal) {
        if (!(portal.level() instanceof ServerLevel level)) return null;
        UUID id = portal.getDualityPortalId().orElse(null);
        if (id == null) return null;
        ResourceKey<Level> dim = portal.getDualityDimension();
        ServerLevel target = dim != null ? level.getServer().getLevel(dim) : level;
        if (target != null && target.getEntity(id) instanceof PortalEntity p && !p.isRemoved()) return p;
        // Измерение напарника не записано (или он сменил мир) — ищем по всем мирам.
        for (ServerLevel other : level.getServer().getAllLevels()) {
            if (other.getEntity(id) instanceof PortalEntity p && !p.isRemoved()) return p;
        }
        return null;
    }

    @Nullable
    private static PortalEntity find(MinecraftServer server, PortalRef ref) {
        ServerLevel level = server.getLevel(ref.dimension());
        return level != null && level.getEntity(ref.id()) instanceof PortalEntity p ? p : null;
    }

    private static PortalRef ref(PortalEntity p) {
        return new PortalRef(p.level().dimension(), p.getUUID());
    }

    /** Очистка при остановке сервера — статика переживает одиночный мир. */
    public static void clear() {
        GUN_PORTALS.clear();
        ACTIVE_PROJECTILES.clear();
        RECENT_CLOSE_SOUNDS.clear();
    }
}
