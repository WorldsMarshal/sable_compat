package com.invfix.rick.portalgun;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandlerItem;
import org.jetbrains.annotations.NotNull;

/**
 * Бутылёк портальной жидкости: 250 mB, всё или ничего.
 *
 * Работает как ведро, а не как бак: полный бутылёк отдаёт ровно 250 mB и
 * превращается в стеклянную бутылку, пустая стеклянная бутылка принимает ровно
 * 250 mB и становится полной. Частичного налива нет — иначе бутылка с 137 mB
 * выглядела бы как полная и путала бы.
 */
public class PortalBottleHandler implements IFluidHandlerItem {

    public static final int VOLUME = 250;

    private ItemStack stack;
    private final boolean filled;

    public PortalBottleHandler(ItemStack stack, boolean filled) {
        this.stack = stack;
        this.filled = filled;
    }

    @Override public @NotNull ItemStack getContainer() { return this.stack; }

    @Override public int getTanks() { return 1; }

    @Override public @NotNull FluidStack getFluidInTank(int tank) {
        return filled ? new FluidStack(PortalGunRegistry.PORTAL_FLUID_SOURCE.get(), VOLUME)
                : FluidStack.EMPTY;
    }

    @Override public int getTankCapacity(int tank) { return VOLUME; }

    @Override public boolean isFluidValid(int tank, @NotNull FluidStack fluid) {
        return fluid.getFluid() == PortalGunRegistry.PORTAL_FLUID_SOURCE.get();
    }

    @Override
    public int fill(FluidStack resource, FluidAction action) {
        if (filled || stack.getCount() != 1) return 0;
        if (resource.getAmount() < VOLUME || !isFluidValid(0, resource)) return 0;
        if (action.execute()) {
            this.stack = new ItemStack(PortalGunRegistry.PORTAL_FLUID_BOTTLE.get());
        }
        return VOLUME;
    }

    @Override
    public @NotNull FluidStack drain(FluidStack resource, FluidAction action) {
        if (!isFluidValid(0, resource)) return FluidStack.EMPTY;
        return drain(resource.getAmount(), action);
    }

    @Override
    public @NotNull FluidStack drain(int maxDrain, FluidAction action) {
        if (!filled || maxDrain < VOLUME || stack.getCount() != 1) return FluidStack.EMPTY;
        if (action.execute()) {
            this.stack = new ItemStack(Items.GLASS_BOTTLE);
        }
        return new FluidStack(PortalGunRegistry.PORTAL_FLUID_SOURCE.get(), VOLUME);
    }
}
