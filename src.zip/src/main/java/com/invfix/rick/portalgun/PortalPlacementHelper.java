package com.invfix.rick.portalgun;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.GrowingPlantBlock;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Где и как встаёт портал. Порт PortalPlacementHelper из Rick's stuff 0.0.4.3.
 *
 * Отличия от оригинала — только исправления декомпиляции (перепутанные
 * переменные в сэмплинге пола у стенового портала в воздухе и в тройном цикле
 * расчистки травы у стенового портала) и выброс поддержки мода Infinity.
 */
public final class PortalPlacementHelper {

    private PortalPlacementHelper() {}

    public record Placement(Vec3 pos, int orientation, int rotation, float yaw) {}

    /** Портал по попаданию снаряда в блок: стена, пол или потолок. */
    public static Placement calculatePlacement(BlockHitResult hit, Player player, Level level) {
        Direction face = hit.getDirection();
        BlockPos hitPos = hit.getBlockPos();

        // Попали в траву, цветок, снег — опускаемся до настоящей земли под ними.
        BlockState hitState = level.getBlockState(hitPos);
        if (isBreakableFoliage(hitState) || hitState.canBeReplaced()) {
            BlockPos.MutableBlockPos scan = hitPos.mutable();
            int minY = level.getMinBuildHeight();
            while (scan.getY() > minY) {
                scan.move(Direction.DOWN);
                BlockState below = level.getBlockState(scan);
                if (below.isAir()) continue;
                if (below.isSolid() || below.blocksMotion()) {
                    hitPos = scan.immutable();
                    face = Direction.UP;
                    break;
                }
            }
        }

        float playerYaw = player != null ? player.getYRot() : 0.0F;
        float normalizedYaw = (playerYaw % 360.0F + 360.0F) % 360.0F;

        if (face == Direction.UP) {
            int rotation = yawQuadrant(normalizedYaw);
            return new Placement(new Vec3(hitPos.getX() + 0.5, hitPos.getY() + 1.035, hitPos.getZ() + 0.5),
                    PortalEntity.ORIENTATION_FLOOR, rotation, rotation * 90.0F);
        }
        if (face == Direction.DOWN) {
            int rotation = yawQuadrant(normalizedYaw);
            return new Placement(new Vec3(hitPos.getX() + 0.5, hitPos.getY() - 0.035, hitPos.getZ() + 0.5),
                    PortalEntity.ORIENTATION_CEILING, rotation, rotation * 90.0F);
        }

        float yaw = face.toYRot();
        int rotation = switch (face) {
            case SOUTH -> 0;
            case WEST -> 1;
            case NORTH -> 2;
            case EAST -> 3;
            default -> 0;
        };

        double targetCenterY = hitPos.getY() + 0.5;
        double halfH = 1.05;
        BlockPos wallStep = hitPos.relative(face);

        BlockPos blockBelow = BlockPos.containing(wallStep.getX(), targetCenterY - halfH, wallStep.getZ());
        if (level.getBlockState(blockBelow).isSolid()) {
            double floorTop = blockBelow.getY() + 1.0;
            if (targetCenterY - halfH < floorTop) targetCenterY = floorTop + halfH;
        }

        BlockPos blockAbove = BlockPos.containing(wallStep.getX(), targetCenterY + halfH, wallStep.getZ());
        if (level.getBlockState(blockAbove).isSolid()) {
            double ceilBottom = blockAbove.getY();
            if (targetCenterY + halfH > ceilBottom) targetCenterY = ceilBottom - halfH;
        }

        Vec3 pos = new Vec3(hitPos.getX() + 0.5 + face.getStepX() * 0.535, targetCenterY,
                hitPos.getZ() + 0.5 + face.getStepZ() * 0.535);
        return new Placement(pos, PortalEntity.ORIENTATION_WALL, rotation, yaw);
    }

    private static int yawQuadrant(float yaw) {
        float ry = (yaw + 180.0F) % 360.0F;
        if (ry < 45.0F || ry >= 315.0F) return 0;
        if (ry < 135.0F) return 1;
        return ry < 225.0F ? 2 : 3;
    }

    /** Портал, открытый в воздухе: приподнять, чтобы не утонул в земле. */
    public static Vec3 adjustAirPortalPosition(Level level, Vec3 pos, int orientation, float yaw, float scale) {
        if (level == null || pos == null) return pos;

        double effectiveScale = Math.max(0.1, scale);
        double halfH = 1.05 * effectiveScale;
        double halfW = 0.95 * effectiveScale;

        if (orientation == PortalEntity.ORIENTATION_WALL) {
            float rad = (float) Math.toRadians(yaw);
            double sideX = Math.cos(rad);
            double sideZ = Math.sin(rad);
            double[] sampleOffsets = {-0.8, -0.4, 0.0, 0.4, 0.8};

            double highestFloorY = Double.NEGATIVE_INFINITY;
            for (double offsetRatio : sampleOffsets) {
                double sx = pos.x + sideX * offsetRatio * halfW;
                double sz = pos.z + sideZ * offsetRatio * halfW;
                int minBlockY = (int) Math.floor(pos.y - halfH - 0.5);
                int maxBlockY = (int) Math.floor(pos.y + 0.2);
                for (int by = maxBlockY; by >= minBlockY; --by) {
                    BlockPos bPos = BlockPos.containing(sx, by, sz);
                    BlockState state = level.getBlockState(bPos);
                    if (state.isAir() || isBreakableFoliage(state) || !state.blocksMotion()) continue;
                    VoxelShape shape = state.getCollisionShape(level, bPos);
                    double top;
                    if (!shape.isEmpty()) top = bPos.getY() + shape.max(Direction.Axis.Y);
                    else if (state.isSolid()) top = bPos.getY() + 1.0;
                    else continue;
                    if (top > highestFloorY) highestFloorY = top;
                }
            }

            double currentBottomY = pos.y - halfH;
            if (highestFloorY > currentBottomY) {
                double targetCenterY = highestFloorY + halfH + 0.02;
                double lowestCeilY = Double.POSITIVE_INFINITY;
                for (double offsetRatio : sampleOffsets) {
                    double sx = pos.x + sideX * offsetRatio * halfW;
                    double sz = pos.z + sideZ * offsetRatio * halfW;
                    int startY = (int) Math.floor(pos.y + halfH);
                    int endY = (int) Math.ceil(targetCenterY + halfH + 0.5);
                    for (int by = startY; by <= endY; ++by) {
                        BlockPos bPos = BlockPos.containing(sx, by, sz);
                        BlockState state = level.getBlockState(bPos);
                        if (state.isAir() || isBreakableFoliage(state) || !state.blocksMotion()) continue;
                        VoxelShape shape = state.getCollisionShape(level, bPos);
                        double bottom;
                        if (!shape.isEmpty()) bottom = bPos.getY() + shape.min(Direction.Axis.Y);
                        else if (state.isSolid()) bottom = bPos.getY();
                        else continue;
                        if (bottom < lowestCeilY) lowestCeilY = bottom;
                    }
                }
                if (lowestCeilY < Double.POSITIVE_INFINITY) {
                    targetCenterY = Math.min(targetCenterY, lowestCeilY - halfH - 0.02);
                }
                if (targetCenterY > pos.y) return new Vec3(pos.x, targetCenterY, pos.z);
            }
            return pos;
        }

        double radius = 0.8 * halfW;
        double[][] samplePoints = {
                {pos.x, pos.z}, {pos.x + radius, pos.z}, {pos.x - radius, pos.z},
                {pos.x, pos.z + radius}, {pos.x, pos.z - radius}};
        double highestFloorY = Double.NEGATIVE_INFINITY;
        for (double[] pt : samplePoints) {
            int by = (int) Math.floor(pos.y);
            BlockPos bPos = BlockPos.containing(pt[0], by, pt[1]);
            BlockState state = level.getBlockState(bPos);
            if (state.isAir() || isBreakableFoliage(state) || !state.blocksMotion()) continue;
            VoxelShape shape = state.getCollisionShape(level, bPos);
            double top;
            if (!shape.isEmpty()) top = bPos.getY() + shape.max(Direction.Axis.Y);
            else if (state.isSolid()) top = bPos.getY() + 1.0;
            else continue;
            if (top > highestFloorY) highestFloorY = top;
        }
        if (highestFloorY > pos.y - 0.05) {
            double targetY = highestFloorY + 0.05;
            BlockState aboveState = level.getBlockState(BlockPos.containing(pos.x, targetY + 1.0, pos.z));
            if (aboveState.isAir() || isBreakableFoliage(aboveState) || !aboveState.blocksMotion()) {
                return new Vec3(pos.x, targetY, pos.z);
            }
        }
        return pos;
    }

    /** Насколько далеко по вертикали точка режима POINT может сдвинуться, прежде чем сдаться на общий поиск. */
    private static final int POINT_Y_SEARCH = 8;

    /**
     * Точка выхода режима «Координаты». В отличие от «GPS» оригинала (findSafePlacement,
     * который первым делом прыгает на поверхность по карте высот), высота соблюдается:
     *  1) если в самой точке ноги и голова свободны и нет лавы — ровно она, даже в воздухе;
     *  2) иначе ближайшая по высоте безопасная точка (с опорой) в том же столбце, ±8 блоков;
     *  3) иначе ближайшая просто свободная точка в том же столбце, ±8 блоков;
     *  4) иначе — общий поиск findSafePlacement.
     */
    public static Vec3 findPointPlacement(ServerLevel level, BlockPos target) {
        try {
            level.getChunk(target.getX() >> 4, target.getZ() >> 4, ChunkStatus.FULL, true);
        } catch (Exception ignored) {
        }
        if (isPassableLocation(level, target)) return Vec3.atBottomCenterOf(target);
        for (int pass = 0; pass < 2; pass++) {
            for (int delta = 1; delta <= POINT_Y_SEARCH; delta++) {
                for (int sign : new int[]{1, -1}) {
                    BlockPos cand = target.above(delta * sign);
                    boolean ok = pass == 0 ? isSafeLocation(level, cand) : isPassableLocation(level, cand);
                    if (ok) return Vec3.atBottomCenterOf(cand);
                }
            }
        }
        return findSafePlacement(level, Vec3.atBottomCenterOf(target));
    }

    /** Ноги и голова свободны, без огня и лавы, в пределах мира (опора под ногами не нужна). */
    private static boolean isPassableLocation(ServerLevel level, BlockPos pos) {
        if (pos.getY() <= level.getMinBuildHeight() + 1 || pos.getY() >= level.getMaxBuildHeight() - 1) return false;
        BlockState feet = level.getBlockState(pos);
        BlockState head = level.getBlockState(pos.above());
        boolean feetPassable = (feet.isAir() || isBreakableFoliage(feet) || !feet.blocksMotion())
                && !feet.is(Blocks.FIRE) && !feet.is(Blocks.SOUL_FIRE);
        boolean headPassable = (head.isAir() || isBreakableFoliage(head) || !head.blocksMotion())
                && !head.is(Blocks.FIRE) && !head.is(Blocks.SOUL_FIRE);
        boolean notLava = !feet.getFluidState().is(FluidTags.LAVA) && !head.getFluidState().is(FluidTags.LAVA);
        return feetPassable && headPassable && notLava;
    }

    /** Безопасная точка рядом с целью: ноги свободны, голова свободна, под ногами твёрдо, без лавы. */
    public static Vec3 findSafePlacement(ServerLevel level, Vec3 target) {
        if (level == null || target == null) return target;
        BlockPos safe = findSafePlacement(level, BlockPos.containing(target.x, target.y, target.z));
        return safe != null ? new Vec3(safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5) : target;
    }

    public static BlockPos findSafePlacement(ServerLevel level, BlockPos target) {
        if (level == null || target == null) return target;
        try {
            level.getChunk(target.getX() >> 4, target.getZ() >> 4, ChunkStatus.FULL, true);
        } catch (Exception ignored) {
        }

        boolean hasCeiling = level.dimensionType().hasCeiling();
        if (isSafeLocation(level, target)) return target;

        if (!hasCeiling) {
            BlockPos hm = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, target);
            if (hm.getY() > level.getMinBuildHeight() + 2 && isSafeLocation(level, hm)
                    && (target.getY() <= level.getMinBuildHeight() + 10 || target.getY() == 0
                    || Math.abs(target.getY() - hm.getY()) <= 24)) {
                return hm;
            }
        }

        BlockPos vertical = scanVerticalColumn(level, target.getX(), target.getZ(), target.getY(), hasCeiling);
        if (vertical != null) return vertical;

        int maxRadius = 32;
        int step = 2;
        for (int r = 2; r <= maxRadius; r += step) {
            for (int dx = -r; dx <= r; dx += step) {
                for (int dz = -r; dz <= r; dz += step) {
                    if (Math.abs(dx) != r && Math.abs(dz) != r) continue;
                    int cx = target.getX() + dx;
                    int cz = target.getZ() + dz;
                    if (!hasCeiling) {
                        BlockPos hm = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                                new BlockPos(cx, target.getY(), cz));
                        if (hm.getY() > level.getMinBuildHeight() + 2 && isSafeLocation(level, hm)
                                && (target.getY() <= level.getMinBuildHeight() + 10 || target.getY() == 0
                                || Math.abs(target.getY() - hm.getY()) <= 24)) {
                            return hm;
                        }
                    }
                    BlockPos found = scanVerticalColumn(level, cx, cz, target.getY(), hasCeiling);
                    if (found != null) return found;
                }
            }
        }
        return target;
    }

    private static BlockPos scanVerticalColumn(ServerLevel level, int x, int z, int preferredY, boolean hasCeiling) {
        int logicalHeight = level.getLogicalHeight();
        int minBuild = level.getMinBuildHeight();
        int maxBuild = level.getMaxBuildHeight();
        int minY;
        int maxY;
        if (hasCeiling) {
            int roofLimit = logicalHeight - 4;
            if (preferredY >= logicalHeight - 1) {
                minY = logicalHeight;
                maxY = maxBuild - 2;
            } else {
                minY = minBuild + 2;
                maxY = Math.max(minY + 2, roofLimit);
            }
        } else {
            minY = minBuild + 2;
            maxY = maxBuild - 2;
        }

        int clampedY = Math.max(minY, Math.min(maxY, preferredY));
        int maxDelta = Math.max(clampedY - minY, maxY - clampedY);
        for (int delta = 0; delta <= maxDelta; ++delta) {
            if (delta == 0) {
                BlockPos cand = new BlockPos(x, clampedY, z);
                if (isSafeLocation(level, cand)) return cand;
                continue;
            }
            int yUp = clampedY + delta;
            if (yUp <= maxY) {
                BlockPos cand = new BlockPos(x, yUp, z);
                if (isSafeLocation(level, cand)) return cand;
            }
            int yDown = clampedY - delta;
            if (yDown >= minY) {
                BlockPos cand = new BlockPos(x, yDown, z);
                if (isSafeLocation(level, cand)) return cand;
            }
        }
        return null;
    }

    private static boolean isSafeLocation(ServerLevel level, BlockPos pos) {
        if (pos.getY() <= level.getMinBuildHeight() + 1 || pos.getY() >= level.getMaxBuildHeight() - 1) return false;
        if (level.dimensionType().hasCeiling()
                && pos.getY() >= level.getLogicalHeight() - 4 && pos.getY() < level.getLogicalHeight()) {
            return false;
        }
        BlockState feet = level.getBlockState(pos);
        BlockState head = level.getBlockState(pos.above());
        BlockState ground = level.getBlockState(pos.below());
        boolean feetPassable = (feet.isAir() || isBreakableFoliage(feet) || !feet.blocksMotion())
                && !feet.is(Blocks.FIRE) && !feet.is(Blocks.SOUL_FIRE);
        boolean headPassable = (head.isAir() || isBreakableFoliage(head) || !head.blocksMotion())
                && !head.is(Blocks.FIRE) && !head.is(Blocks.SOUL_FIRE);
        boolean groundSolid = !ground.isAir() && ground.blocksMotion() && !isBreakableFoliage(ground)
                && !ground.is(Blocks.MAGMA_BLOCK) && !ground.is(Blocks.CAMPFIRE) && !ground.is(Blocks.SOUL_CAMPFIRE);
        boolean notLava = !feet.getFluidState().is(FluidTags.LAVA) && !ground.getFluidState().is(FluidTags.LAVA)
                && !head.getFluidState().is(FluidTags.LAVA);
        return feetPassable && headPassable && groundSolid && notLava;
    }

    public static boolean isBreakableFoliage(BlockState state) {
        if (state == null || state.isAir()) return false;
        if (state.is(BlockTags.FLOWERS) || state.is(BlockTags.CROPS) || state.is(BlockTags.SAPLINGS)
                || state.is(BlockTags.REPLACEABLE_BY_TREES) || state.is(BlockTags.REPLACEABLE)) {
            return true;
        }
        Block block = state.getBlock();
        if (block instanceof BushBlock || block instanceof DoublePlantBlock || block instanceof GrowingPlantBlock
                || block instanceof VineBlock || block instanceof SnowLayerBlock) {
            return true;
        }
        return !state.isSolid() && state.canBeReplaced();
    }

    /** Трава и цветы в плоскости портала срезаются, иначе они торчат сквозь воронку. */
    public static void clearVegetationInPortalArea(ServerLevel level, Vec3 centerPos, int orientation, float yaw, float scale) {
        if (level == null || centerPos == null) return;
        double effectiveScale = Math.max(0.5, Math.min(3.0, scale));
        BlockPos center = BlockPos.containing(centerPos.x, centerPos.y, centerPos.z);

        if (orientation == PortalEntity.ORIENTATION_WALL) {
            int radius = Math.max(1, (int) Math.ceil(1.0 * effectiveScale));
            int radiusV = Math.max(1, (int) Math.ceil(1.4 * effectiveScale));
            for (int dx = -radius; dx <= radius; ++dx) {
                for (int dz = -radius; dz <= radius; ++dz) {
                    for (int dy = -radiusV; dy <= radiusV; ++dy) {
                        clearIfFoliage(level, center.offset(dx, dy, dz));
                    }
                }
            }
            return;
        }

        int radius = Math.max(1, (int) Math.ceil(1.3 * effectiveScale));
        double maxDistSq = 1.35 * effectiveScale * 1.35 * effectiveScale;
        int dyMin = orientation == PortalEntity.ORIENTATION_FLOOR ? -1 : -2;
        int dyMax = orientation == PortalEntity.ORIENTATION_FLOOR ? 2 : 1;
        for (int dx = -radius; dx <= radius; ++dx) {
            for (int dz = -radius; dz <= radius; ++dz) {
                if (dx * dx + dz * dz > maxDistSq) continue;
                for (int dy = dyMin; dy <= dyMax; ++dy) {
                    clearIfFoliage(level, center.offset(dx, dy, dz));
                }
            }
        }
    }

    private static void clearIfFoliage(ServerLevel level, BlockPos pos) {
        if (isBreakableFoliage(level.getBlockState(pos))) {
            level.destroyBlock(pos, true);
            level.sendParticles(PortalGunRegistry.FLUID_EVAPORATION.get(),
                    pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 4, 0.2, 0.2, 0.2, 0.02);
        }
    }
}
