package com.invfix.rick.portalgun;

import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.portal.DimensionTransition;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Перенос сущности из портала в портал. Порт PortalTeleportEngine из Rick's
 * stuff 0.0.4.3: точка выхода перед плоскостью (стена) / над полом / под
 * потолком, поворот взгляда стена→стена, пересчёт скорости в базис выходного
 * портала (скорость сохраняется, прыжок в портал на полу выбрасывает из
 * портала на стене), перенос между мирами через DimensionTransition.
 *
 * Не перенесено: антипортальное поле, «хазард-щит», история телепортов и
 * перетекание жидкостей через портал. Добавлено: списание проходов у пары
 * режима POINT.
 */
public final class PortalTeleportEngine {

    private PortalTeleportEngine() {}

    public static final int DEFAULT_COOLDOWN_TICKS = 30;

    private static final Map<UUID, Integer> GLOBAL_COOLDOWNS = new HashMap<>();

    /** Раз в серверный тик (PortalGunEvents). */
    public static void tickServer() {
        if (GLOBAL_COOLDOWNS.isEmpty()) return;
        Iterator<Map.Entry<UUID, Integer>> it = GLOBAL_COOLDOWNS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> e = it.next();
            int left = e.getValue() - 1;
            if (left <= 0) it.remove(); else e.setValue(left);
        }
    }

    public static void setCooldown(UUID entity, int ticks) {
        if (entity == null) return;
        GLOBAL_COOLDOWNS.merge(entity, ticks, Math::max);
    }

    public static boolean hasCooldown(UUID entity) {
        Integer ticks = entity == null ? null : GLOBAL_COOLDOWNS.get(entity);
        return ticks != null && ticks > 0;
    }

    public static boolean teleportEntity(PortalEntity entrance, PortalEntity exit, Entity entity) {
        if (entrance == null || exit == null || entity == null || entity.isRemoved()) return false;
        if (!(entrance.level() instanceof ServerLevel)) return false;
        if (!(exit.level() instanceof ServerLevel exitLevel)) return false;
        if (entrance.isClosing() || exit.isClosing()) return false;

        UUID uuid = entity.getUUID();
        if (hasCooldown(uuid) || entrance.hasTeleportCooldown(uuid) || exit.hasTeleportCooldown(uuid)) return false;
        if (entity.isPassenger() || entity.isVehicle()) return false;

        Vec3 exitForward = getPortalNormal(exit.getOrientation(), exit.getYRot());
        double halfEntityDepth = Math.max(0.08, entity.getBbWidth() * 0.5);
        double offsetDist = Math.max(0.75, halfEntityDepth + 0.35);
        double exitX = exit.getX();
        double exitY = exit.getY();
        double exitZ = exit.getZ();
        if (exit.getOrientation() == PortalEntity.ORIENTATION_WALL) {
            exitX += exitForward.x * offsetDist;
            exitZ += exitForward.z * offsetDist;
        } else if (exit.getOrientation() == PortalEntity.ORIENTATION_FLOOR) {
            exitY += 0.05;
        } else {
            exitY -= entity.getBbHeight() + 0.05;
        }

        float exitPitch = entity.getXRot();
        float exitYaw;
        if (entrance.getOrientation() == PortalEntity.ORIENTATION_WALL && exit.getOrientation() == PortalEntity.ORIENTATION_WALL) {
            float rotDiff = exit.getYRot() - entrance.getYRot() + 180.0F;
            exitYaw = (entity.getYRot() + rotDiff) % 360.0F;
        } else if (exit.getOrientation() == PortalEntity.ORIENTATION_WALL) {
            exitYaw = exit.getYRot();
        } else {
            exitYaw = entity.getYRot();
        }

        Vec3 outVel = transformVelocity(entrance, exit, entity.getDeltaMovement());

        exitLevel.getChunk(BlockPos.containing(exitX, exitY, exitZ));
        performTeleport(entity, exitLevel, exitX, exitY, exitZ, exitYaw, exitPitch, outVel);
        entity.resetFallDistance();

        setCooldown(uuid, DEFAULT_COOLDOWN_TICKS);
        entrance.setTeleportCooldown(uuid, DEFAULT_COOLDOWN_TICKS);
        exit.setTeleportCooldown(uuid, DEFAULT_COOLDOWN_TICKS);

        entrance.playSound(PortalGunRegistry.SOUND_PORTAL_TELEPORT.get(), 0.4F, 1.0F);
        exit.playSound(PortalGunRegistry.SOUND_PORTAL_TELEPORT.get(), 0.4F, 1.0F);
        entrance.triggerPassAnimation();
        exit.triggerPassAnimation();

        if (entity instanceof ServerPlayer player) {
            PacketDistributor.sendToPlayer(player, new PortalFlashPacket(entrance.getColor()));
        }

        spendPass(entrance, exit);
        return true;
    }

    /**
     * Лимит проходов, во всех режимах: проход списывается и со входа, и с выхода,
     * у каждого портала свой счётчик. Портал на нуле закрывается (в режиме POINT —
     * вместе с парой, это делает removePortal). У пары, открытой вместе, счётчики
     * равны, поэтому она и закрывается вместе.
     */
    private static void spendPass(PortalEntity entrance, PortalEntity exit) {
        spendOne(entrance);
        spendOne(exit);
    }

    private static void spendOne(PortalEntity portal) {
        int left = portal.getPassesLeft();
        if (left == PortalEntity.UNLIMITED_PASSES) return;
        left = Math.max(0, left - 1);
        portal.setPassesLeft(left);
        if (left <= 0) PortalManager.removePortal(portal, false);
    }

    private static void performTeleport(Entity entity, ServerLevel targetLevel, double x, double y, double z,
                                        float yaw, float pitch, Vec3 velocity) {
        if (entity.level() == targetLevel) {
            if (entity instanceof ServerPlayer player) {
                player.connection.teleport(x, y, z, yaw, pitch);
                player.setDeltaMovement(velocity);
                player.connection.send(new ClientboundSetEntityMotionPacket(player.getId(), velocity));
                player.hurtMarked = true;
                player.hasImpulse = true;
            } else {
                entity.teleportTo(x, y, z);
                entity.setYRot(yaw);
                entity.setXRot(pitch);
                entity.setYHeadRot(yaw);
                entity.setDeltaMovement(velocity);
                if (entity instanceof Projectile projectile) alignProjectile(projectile, velocity);
                entity.hurtMarked = true;
                entity.hasImpulse = true;
            }
            return;
        }

        DimensionTransition transition = new DimensionTransition(targetLevel, new Vec3(x, y, z), velocity,
                yaw, pitch, DimensionTransition.DO_NOTHING);
        if (entity instanceof ServerPlayer player) {
            player.changeDimension(transition);
            player.setDeltaMovement(velocity);
            player.connection.send(new ClientboundSetEntityMotionPacket(player.getId(), velocity));
            player.hurtMarked = true;
            player.hasImpulse = true;
        } else {
            Entity transferred = entity.changeDimension(transition);
            if (transferred != null) {
                transferred.setDeltaMovement(velocity);
                transferred.resetFallDistance();
                if (transferred instanceof Projectile projectile) alignProjectile(projectile, velocity);
            }
        }
    }

    /** Снаряд после портала смотрит туда, куда летит, иначе стрела летит боком. */
    private static void alignProjectile(Projectile projectile, Vec3 velocity) {
        if (velocity.length() <= 0.001) return;
        double hSpeed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
        float newYaw = (float) (Math.atan2(velocity.x, velocity.z) * (180.0 / Math.PI));
        float newPitch = (float) (Math.atan2(velocity.y, hSpeed) * (180.0 / Math.PI));
        projectile.setYRot(newYaw);
        projectile.setXRot(newPitch);
        projectile.yRotO = newYaw;
        projectile.xRotO = newPitch;
    }

    public static Vec3 getPortalNormal(int orientation, float yaw) {
        if (orientation == PortalEntity.ORIENTATION_WALL) {
            float rad = (float) Math.toRadians(yaw);
            return new Vec3(-Math.sin(rad), 0.0, Math.cos(rad));
        }
        return orientation == PortalEntity.ORIENTATION_FLOOR ? new Vec3(0.0, 1.0, 0.0) : new Vec3(0.0, -1.0, 0.0);
    }

    public static Vec3 getPortalTangentX(float yaw) {
        float rad = (float) Math.toRadians(yaw);
        return new Vec3(Math.cos(rad), 0.0, Math.sin(rad));
    }

    public static Vec3 getPortalTangentY(int orientation, float yaw) {
        if (orientation == PortalEntity.ORIENTATION_WALL) return new Vec3(0.0, 1.0, 0.0);
        float rad = (float) Math.toRadians(yaw);
        return new Vec3(-Math.sin(rad), 0.0, Math.cos(rad));
    }

    public static Vec3 transformVelocity(PortalEntity entrance, PortalEntity exit, Vec3 inVel) {
        Vec3 nIn = getPortalNormal(entrance.getOrientation(), entrance.getYRot());
        Vec3 txIn = getPortalTangentX(entrance.getYRot());
        Vec3 tyIn = getPortalTangentY(entrance.getOrientation(), entrance.getYRot());
        Vec3 nOut = getPortalNormal(exit.getOrientation(), exit.getYRot());
        Vec3 txOut = getPortalTangentX(exit.getYRot());
        Vec3 tyOut = getPortalTangentY(exit.getOrientation(), exit.getYRot());

        double vN = inVel.dot(nIn);
        double vTx = inVel.dot(txIn);
        double vTy = inVel.dot(tyIn);
        double totalSpeed = inVel.length();
        double forwardSpeed = Math.max(Math.abs(vN), Math.max(0.45, totalSpeed * 0.95));
        double outTx = vTx * 0.75;
        double outTy = vTy * 0.75;

        double vx = nOut.x * forwardSpeed + txOut.x * outTx + tyOut.x * outTy;
        double vy = nOut.y * forwardSpeed + txOut.y * outTx + tyOut.y * outTy;
        double vz = nOut.z * forwardSpeed + txOut.z * outTx + tyOut.z * outTy;
        if (exit.getOrientation() == PortalEntity.ORIENTATION_WALL && vy < 0.05) {
            vy = 0.05;
        } else if (exit.getOrientation() == PortalEntity.ORIENTATION_CEILING && vy > -0.2) {
            vy = -0.35;
        }
        return new Vec3(vx, vy, vz);
    }
}
