package com.invfix.rick.portalgun;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

import java.util.ArrayList;
import java.util.List;

/**
 * Состояние портальной пушки, лежащее в компоненте предмета.
 *
 * Топливо здесь не хранится: его держит отдельный компонент, потому что бак
 * пушки — это полноценный IFluidHandler, и его правят из слотов панели Рика и
 * из любого мода, умеющего заливать жидкость в предмет.
 *
 * Поле mode добавлено с переносом механик Rick's stuff. В кодеке оно
 * необязательное: у пушек, созданных до переноса, его нет, и они просто
 * получают режим по умолчанию. Так же необязательно air_distance (0 — подрыв
 * в воздухе выключен).
 */
public record PortalGunData(List<PortalPoint> points, int selected, int passLimit, String mode, int airDistance) {

    public static final int MAX_POINTS = 5;
    public static final int MIN_PASSES = 1;
    public static final int MAX_PASSES = 16;
    /** Подрыв в воздухе: 0 — выключен, иначе через столько блоков полёта без попадания. */
    public static final int MIN_AIR_DISTANCE = 0;
    public static final int MAX_AIR_DISTANCE = (int) PortalProjectileEntity.MAX_DISTANCE;

    public static final PortalGunData DEFAULT =
            new PortalGunData(List.of(), 0, 2, PortalMode.FIFO.id(), 0);

    public static final Codec<PortalGunData> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            PortalPoint.CODEC.listOf().fieldOf("points").forGetter(PortalGunData::points),
            Codec.INT.fieldOf("selected").forGetter(PortalGunData::selected),
            Codec.INT.fieldOf("pass_limit").forGetter(PortalGunData::passLimit),
            Codec.STRING.optionalFieldOf("mode", PortalMode.FIFO.id()).forGetter(PortalGunData::mode),
            Codec.INT.optionalFieldOf("air_distance", 0).forGetter(PortalGunData::airDistance)
    ).apply(inst, PortalGunData::new));

    public static final StreamCodec<RegistryFriendlyByteBuf, PortalGunData> STREAM_CODEC =
            StreamCodec.composite(
                    PortalPoint.STREAM_CODEC.apply(ByteBufCodecs.list(MAX_POINTS)), PortalGunData::points,
                    ByteBufCodecs.VAR_INT, PortalGunData::selected,
                    ByteBufCodecs.VAR_INT, PortalGunData::passLimit,
                    ByteBufCodecs.STRING_UTF8, PortalGunData::mode,
                    ByteBufCodecs.VAR_INT, PortalGunData::airDistance,
                    PortalGunData::new);

    /** Нормализованная копия: список ровно MAX_POINTS, индексы, лимит и режим в границах. */
    public PortalGunData sanitized() {
        List<PortalPoint> list = new ArrayList<>(MAX_POINTS);
        for (int i = 0; i < MAX_POINTS; i++) {
            list.add(i < points.size() ? points.get(i) : PortalPoint.EMPTY);
        }
        int sel = Math.max(0, Math.min(selected, MAX_POINTS - 1));
        int passes = Math.max(MIN_PASSES, Math.min(passLimit, MAX_PASSES));
        int air = Math.max(MIN_AIR_DISTANCE, Math.min(airDistance, MAX_AIR_DISTANCE));
        return new PortalGunData(List.copyOf(list), sel, passes, PortalMode.byId(mode).id(), air);
    }

    public PortalMode portalMode() {
        return PortalMode.byId(mode);
    }

    public PortalPoint point(int index) {
        return index >= 0 && index < points.size() ? points.get(index) : PortalPoint.EMPTY;
    }

    public PortalPoint active() {
        return point(selected);
    }

    public PortalGunData withPoint(int index, PortalPoint point) {
        List<PortalPoint> list = new ArrayList<>(sanitized().points());
        if (index >= 0 && index < MAX_POINTS) list.set(index, point);
        return new PortalGunData(List.copyOf(list), selected, passLimit, mode, airDistance);
    }

    public PortalGunData withSelected(int index) {
        return new PortalGunData(points, index, passLimit, mode, airDistance).sanitized();
    }

    public PortalGunData withPassLimit(int limit) {
        return new PortalGunData(points, selected, limit, mode, airDistance).sanitized();
    }

    public PortalGunData withMode(PortalMode newMode) {
        return new PortalGunData(points, selected, passLimit, newMode.id(), airDistance).sanitized();
    }
}
