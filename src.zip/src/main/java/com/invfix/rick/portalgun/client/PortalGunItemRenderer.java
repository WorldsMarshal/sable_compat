package com.invfix.rick.portalgun.client;

import com.invfix.rick.portalgun.PortalGunItem;
import com.invfix.rick.portalgun.PortalGunRegistry;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Отрисовка портальных пушек и колбы портальной жидкости. Порт
 * PortalGunItemRenderer из Rick's stuff 0.0.4.3.
 *
 * Пушка Рика — запечённая Blockbench-модель rick_portal_gun_base (текстура
 * 512x512) плюс процедурная колба: жидкость с уровнем по заряду, вихри,
 * пузыри, мениск, сияние, капли на стекле; сверху — светящийся экран
 * координат (красный; оранжевый ≤ 20%; мигает при нуле).
 *
 * Пушка Злого Морти — двоичный меш с текстурой 512x512, жёлтый плазменный шар
 * и наклонённая колба с той же жидкостью.
 *
 * Бутылка портальной жидкости рисуется как колба оригинала (portal_fluid_base
 * + процедурная жидкость, всегда полная).
 *
 * Все методы отрисовки ниже renderByItem перенесены без изменений. Переписан
 * только вход: вместо NBT оригинала заряд берётся из нашего бака в mB
 * (переводится в проценты), «бесконечной колбы» и «разряженной» пушки у нас нет.
 */
@OnlyIn(Dist.CLIENT)
public class PortalGunItemRenderer extends BlockEntityWithoutLevelRenderer {

    private static PortalGunItemRenderer instance;

    public static final ModelResourceLocation GUN_MODEL = ModelResourceLocation.standalone(
            ResourceLocation.fromNamespaceAndPath("sable_compat", "item/rick_portal_gun_base"));
    public static final ModelResourceLocation FLUID_MODEL = ModelResourceLocation.standalone(
            ResourceLocation.fromNamespaceAndPath("sable_compat", "item/portal_fluid_base"));

    public static final ResourceLocation VORTEX_TEXTURE = ResourceLocation.fromNamespaceAndPath("sable_compat",
            "textures/entity/portal_gun/orb_swirl_ring.png");

    /** Цвет жидкости пушки Рика и Злого Морти (FluidColor по умолчанию в оригинале). */
    public static final int FLUID_GREEN = 2356545;
    public static final int FLUID_YELLOW = 16765465;

    private static final int FULL_LIGHT = 15728880;


   private static int fastHash(int x) {
      x = (x >>> 16 ^ x) * 73244475;
      x = (x >>> 16 ^ x) * 73244475;
      x ^= x >>> 16;
      return x;
   }

   private static float hashFloat(int seed, int idx) {
      int h = fastHash(seed ^ idx * -1640531527);
      return (float)(h & 16777215) / 1.6777216E7F;
   }

   private static float hashSignedFloat(int seed, int idx) {
      return hashFloat(seed, idx) * 2.0F - 1.0F;
   }

    public PortalGunItemRenderer(BlockEntityRenderDispatcher dispatcher, EntityModelSet modelSet) {
        super(dispatcher, modelSet);
    }

    public static PortalGunItemRenderer getInstance() {
        if (instance == null) {
            Minecraft mc = Minecraft.getInstance();
            instance = new PortalGunItemRenderer(mc.getBlockEntityRenderDispatcher(), mc.getEntityModels());
        }
        return instance;
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext displayContext, PoseStack poseStack,
                             MultiBufferSource buffer, int packedLight, int packedOverlay) {
        Minecraft mc = Minecraft.getInstance();
        ItemRenderer itemRenderer = mc.getItemRenderer();
        float frameTime = mc.getTimer().getGameTimeDeltaPartialTick(false);

        boolean isFluidItem = stack.is(PortalGunRegistry.PORTAL_FLUID_BOTTLE.get());
        boolean isGun = stack.getItem() instanceof PortalGunItem;
        boolean isEvilGun = isGun && ((PortalGunItem) stack.getItem()).isEvil();
        // Разряженной пушки, пустой колбы и бесконечной колбы у нас нет.
        boolean isUnplugged = false;
        boolean isEmptyBulb = false;
        boolean isInfinityBulb = false;
        boolean isCreative = false;
        int charge = isGun ? PortalGunItem.chargePercent(stack) : 100;

        float time;
        if (mc.level != null && displayContext != ItemDisplayContext.GUI) {
            time = ((float) mc.level.getGameTime() + frameTime) * 0.05F;
        } else {
            time = (float) (System.currentTimeMillis() % 3600000L) * 0.003F;
        }

        int fluidColor = isEvilGun ? FLUID_YELLOW : FLUID_GREEN;
        int coreColor = -1;

        float minY;
        float maxY;
        float minZ;
        float maxZ;
        float maxX;
        if (isEvilGun) {
         poseStack.pushPose();
         float s;
         switch (displayContext) {
            case GUI:
               poseStack.translate(0.5, 0.5, 0.5);
               poseStack.mulPose(Axis.XP.rotationDegrees(43.5F));
               poseStack.mulPose(Axis.YP.rotationDegrees(132.75F));
               s = 0.82F;
               poseStack.scale(s, s, s);
               poseStack.translate(0.0, -0.35, -0.09);
               break;
            case FIRST_PERSON_RIGHT_HAND:
               poseStack.translate(0.56, 0.42, 0.15);
               poseStack.mulPose(Axis.YP.rotationDegrees(169.75F));
               poseStack.mulPose(Axis.XP.rotationDegrees(2.0F));
               poseStack.mulPose(Axis.ZP.rotationDegrees(-2.0F));
               s = 0.82F;
               poseStack.scale(s, s, s);
               poseStack.translate(0.0, -0.25, -0.36);
               break;
            case FIRST_PERSON_LEFT_HAND:
               poseStack.translate(0.44, 0.42, 0.15);
               poseStack.mulPose(Axis.YP.rotationDegrees(-169.75F));
               poseStack.mulPose(Axis.XP.rotationDegrees(2.0F));
               poseStack.mulPose(Axis.ZP.rotationDegrees(2.0F));
               s = 0.82F;
               poseStack.scale(s, s, s);
               poseStack.translate(0.0, -0.25, -0.36);
               break;
            case THIRD_PERSON_RIGHT_HAND:
               poseStack.translate(0.5, 0.48, 0.6);
               poseStack.mulPose(Axis.XP.rotationDegrees(2.13F));
               poseStack.mulPose(Axis.YP.rotationDegrees(177.38F));
               poseStack.mulPose(Axis.ZP.rotationDegrees(8.0F));
               s = 0.55F;
               poseStack.scale(s, s, s);
               poseStack.translate(0.0, -0.1, 0.12);
               isGun = stack.getItem() instanceof PortalGunItem;
               if (isGun) {
                  PortalGunRecoilManager.applyThirdPersonRecoil(poseStack, displayContext, frameTime);
               }
               break;
            case THIRD_PERSON_LEFT_HAND:
               poseStack.translate(0.5, 0.48, 0.6);
               poseStack.mulPose(Axis.XP.rotationDegrees(2.13F));
               poseStack.mulPose(Axis.YP.rotationDegrees(-177.38F));
               poseStack.mulPose(Axis.ZP.rotationDegrees(-8.0F));
               s = 0.55F;
               poseStack.scale(s, s, s);
               poseStack.translate(0.0, -0.1, 0.12);
               isGun = stack.getItem() instanceof PortalGunItem;
               if (isGun) {
                  PortalGunRecoilManager.applyThirdPersonRecoil(poseStack, displayContext, frameTime);
               }
               break;
            case GROUND:
               poseStack.translate(0.5, 0.25, 0.5);
               poseStack.mulPose(Axis.YP.rotationDegrees(135.0F));
               s = 0.5F;
               poseStack.scale(s, s, s);
               poseStack.translate(0.0, -0.35, -0.09);
               break;
            case FIXED:
               poseStack.translate(0.5, 0.5, 0.5);
               poseStack.mulPose(Axis.YP.rotationDegrees(-90.0F));
               s = 0.65F;
               poseStack.scale(s, s, s);
               poseStack.translate(0.0, -0.35, -0.09);
               break;
            default:
               poseStack.translate(0.5, 0.5, 0.5);
               poseStack.mulPose(Axis.YP.rotationDegrees(180.0F));
               s = 0.5F;
               poseStack.scale(s, s, s);
               poseStack.translate(0.0, -0.35, -0.09);
         }

         VertexConsumer chassisConsumer = buffer.getBuffer(RenderType.entityCutoutNoCull(EvilMortyGunModel.TEXTURE));
         EvilMortyGunModel.renderChassis(poseStack, chassisConsumer, 15728880, packedOverlay, 1.0F, 1.0F, 1.0F, 1.0F);
         VertexConsumer coreConsumer = buffer.getBuffer(PortalVisualRenderTypes.PLASMA_SOLID_BODY);
         EvilMortyGunModel.renderGlowingSpherePosColor(poseStack, coreConsumer, 0.95F, 255, 235, 70, 255);
         VertexConsumer coronaConsumer = buffer.getBuffer(PortalVisualRenderTypes.PLASMA_ADDITIVE_GLOW);
         EvilMortyGunModel.renderGlowingSpherePosColor(poseStack, coronaConsumer, 1.25F, 255, 195, 25, 210);
         if (buffer instanceof MultiBufferSource.BufferSource) {
            MultiBufferSource.BufferSource bs = (MultiBufferSource.BufferSource)buffer;
            bs.endBatch();
         }

         poseStack.pushPose();
         poseStack.translate(EvilMortyGunModel.TUBE_SOCKET_CENTER.x, EvilMortyGunModel.TUBE_SOCKET_CENTER.y, EvilMortyGunModel.TUBE_SOCKET_CENTER.z);
         poseStack.mulPose(Axis.XP.rotationDegrees(-31.0F));
         maxX = -0.0625F;
         minY = 0.0625F;
         maxY = -0.025F;
         minZ = 0.240625F;
         maxZ = -0.0625F;
         float tubeMaxZ = 0.0625F;
         this.renderGlassTubeVial(poseStack, buffer, maxX, minY, maxY, minZ, maxZ, tubeMaxZ);
         if (isUnplugged) {
            this.renderStaticEmptyBulbInterior(poseStack, buffer, maxX, minY, maxY, minZ, maxZ, tubeMaxZ);
         } else {
            float fluidMinX = maxX + 8.0E-4F;
            float fluidMaxX = minY - 8.0E-4F;
            float fluidMinY = maxY + 8.0E-4F;
            float fluidMaxY = minZ - 8.0E-4F;
            float fluidMinZ = maxZ + 8.0E-4F;
            float fluidMaxZ = tubeMaxZ - 8.0E-4F;
            if (charge <= 0 && !isCreative && !isInfinityBulb) {
               this.renderDischargedResidue(poseStack, buffer, fluidMinX, fluidMaxX, fluidMinY, fluidMinZ, fluidMaxZ, fluidColor);
            } else {
               this.renderDynamicPortalLiquid(poseStack, buffer, charge, isCreative, fluidColor, coreColor, time, fluidMinX, fluidMaxX, fluidMinY, fluidMaxY, fluidMinZ, fluidMaxZ);
            }
         }

         poseStack.popPose();
         if (buffer instanceof MultiBufferSource.BufferSource) {
            MultiBufferSource.BufferSource bs = (MultiBufferSource.BufferSource)buffer;
            bs.endBatch();
         }

         poseStack.popPose();
        } else {
            if (displayContext == ItemDisplayContext.THIRD_PERSON_RIGHT_HAND
                    || displayContext == ItemDisplayContext.THIRD_PERSON_LEFT_HAND) {
                if (isGun) PortalGunRecoilManager.applyThirdPersonRecoil(poseStack, displayContext, frameTime);
            }

            BakedModel baseModel = mc.getModelManager().getModel(isFluidItem ? FLUID_MODEL : GUN_MODEL);
            if (baseModel != null && baseModel != mc.getModelManager().getMissingModel()) {
                VertexConsumer solidConsumer = buffer.getBuffer(ItemBlockRenderTypes.getRenderType(stack, true));
                itemRenderer.renderModelLists(baseModel, stack, 15728880, packedOverlay, poseStack, solidConsumer);
            }

            if (buffer instanceof MultiBufferSource.BufferSource bs) bs.endBatch();

            float minX;
            if (isFluidItem) {
                minX = 0.251875F;
                maxX = 0.304375F;
            } else {
                minX = 0.464375F;
                maxX = 0.516875F;
            }
            minY = 0.189375F;
            maxY = 0.273125F;
            minZ = 0.476875F;
            maxZ = 0.523125F;

            if (charge <= 0) {
                this.renderDischargedResidue(poseStack, buffer, minX, maxX, minY, minZ, maxZ, fluidColor);
                this.renderStylizedGlassCapsule(poseStack, buffer, minX, maxX, minY, maxY, minZ, maxZ);
            } else {
                this.renderDynamicPortalLiquid(poseStack, buffer, charge, isCreative, fluidColor, coreColor, time,
                        minX, maxX, minY, maxY, minZ, maxZ);
                this.renderStylizedGlassCapsule(poseStack, buffer, minX, maxX, minY, maxY, minZ, maxZ);
            }

            if (!isFluidItem) {
                this.renderDigitalCoordinateScreen(poseStack, buffer, stack, charge, isCreative, isInfinityBulb, false, time);
            }

            if (buffer instanceof MultiBufferSource.BufferSource bs) bs.endBatch();
        }
    }

   private void renderGlassTubeVial(PoseStack poseStack, MultiBufferSource buffer, float minX, float maxX, float minY, float maxY, float minZ, float maxZ) {
      VertexConsumer glassConsumer = buffer.getBuffer(PortalFluidRenderTypes.FLUID_TRANSLUCENT_BODY);
      Matrix4f mat = poseStack.last().pose();
      int rGlass = 230;
      int gGlass = 240;
      int bGlass = 250;
      int aGlass = 35;
      int rRim = 255;
      int gRim = 245;
      int bRim = 200;
      int aRim = 75;
      putVertex(glassConsumer, mat, minX, minY, minZ, rGlass, gGlass, bGlass, aGlass);
      putVertex(glassConsumer, mat, maxX, minY, minZ, rGlass, gGlass, bGlass, aGlass);
      putVertex(glassConsumer, mat, maxX, maxY, minZ, rRim, gRim, bRim, aRim);
      putVertex(glassConsumer, mat, minX, maxY, minZ, rRim, gRim, bRim, aRim);
      putVertex(glassConsumer, mat, maxX, minY, maxZ, rGlass, gGlass, bGlass, aGlass);
      putVertex(glassConsumer, mat, minX, minY, maxZ, rGlass, gGlass, bGlass, aGlass);
      putVertex(glassConsumer, mat, minX, maxY, maxZ, rRim, gRim, bRim, aRim);
      putVertex(glassConsumer, mat, maxX, maxY, maxZ, rRim, gRim, bRim, aRim);
      putVertex(glassConsumer, mat, minX, minY, maxZ, rGlass, gGlass, bGlass, aGlass);
      putVertex(glassConsumer, mat, minX, minY, minZ, rGlass, gGlass, bGlass, aGlass);
      putVertex(glassConsumer, mat, minX, maxY, minZ, rRim, gRim, bRim, aRim);
      putVertex(glassConsumer, mat, minX, maxY, maxZ, rRim, gRim, bRim, aRim);
      putVertex(glassConsumer, mat, maxX, minY, minZ, rGlass, gGlass, bGlass, aGlass);
      putVertex(glassConsumer, mat, maxX, minY, maxZ, rGlass, gGlass, bGlass, aGlass);
      putVertex(glassConsumer, mat, maxX, maxY, maxZ, rRim, gRim, bRim, aRim);
      putVertex(glassConsumer, mat, maxX, maxY, minZ, rRim, gRim, bRim, aRim);
      putVertex(glassConsumer, mat, minX, minY, minZ, rGlass, gGlass, bGlass, 55);
      putVertex(glassConsumer, mat, minX, minY, maxZ, rGlass, gGlass, bGlass, 55);
      putVertex(glassConsumer, mat, maxX, minY, maxZ, rGlass, gGlass, bGlass, 55);
      putVertex(glassConsumer, mat, maxX, minY, minZ, rGlass, gGlass, bGlass, 55);
      putVertex(glassConsumer, mat, minX, maxY, minZ, rRim, gRim, bRim, aRim);
      putVertex(glassConsumer, mat, minX, maxY, maxZ, rRim, gRim, bRim, aRim);
      putVertex(glassConsumer, mat, maxX, maxY, maxZ, rRim, gRim, bRim, aRim);
      putVertex(glassConsumer, mat, maxX, maxY, minZ, rRim, gRim, bRim, aRim);
   }

   private void renderStylizedGlassCapsule(PoseStack poseStack, MultiBufferSource buffer, float minX, float maxX, float minY, float maxY, float minZ, float maxZ) {
      Matrix4f mat = poseStack.last().pose();
      VertexConsumer glassConsumer = buffer.getBuffer(PortalFluidRenderTypes.FLUID_TRANSLUCENT_BODY);
      float gasketHeight = 0.0015F;
      float gasketMaxY = minY + gasketHeight;
      int rGasket = 55;
      int gGasket = 65;
      int bGasket = 75;
      int aGasket = 120;
      addQuad(glassConsumer, mat, minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ, minX, minY, maxZ, rGasket, gGasket, bGasket, aGasket);
      addQuad(glassConsumer, mat, minX, minY, minZ, maxX, minY, minZ, maxX, gasketMaxY, minZ, minX, gasketMaxY, minZ, rGasket, gGasket, bGasket, aGasket);
      addQuad(glassConsumer, mat, maxX, minY, maxZ, minX, minY, maxZ, minX, gasketMaxY, maxZ, maxX, gasketMaxY, maxZ, rGasket, gGasket, bGasket, aGasket);
      addQuad(glassConsumer, mat, minX, minY, maxZ, minX, minY, minZ, minX, gasketMaxY, minZ, minX, gasketMaxY, maxZ, rGasket, gGasket, bGasket, aGasket);
      addQuad(glassConsumer, mat, maxX, minY, minZ, maxX, minY, maxZ, maxX, gasketMaxY, maxZ, maxX, gasketMaxY, minZ, rGasket, gGasket, bGasket, aGasket);
      int rGlass = 220;
      int gGlass = 245;
      int bGlass = 255;
      int aBase = 28;
      int aRim = 40;
      putVertex(glassConsumer, mat, minX, minY, minZ, rGlass, gGlass, bGlass, aBase);
      putVertex(glassConsumer, mat, maxX, minY, minZ, rGlass, gGlass, bGlass, aBase);
      putVertex(glassConsumer, mat, maxX, maxY, minZ, rGlass, gGlass, bGlass, aRim);
      putVertex(glassConsumer, mat, minX, maxY, minZ, rGlass, gGlass, bGlass, aRim);
      putVertex(glassConsumer, mat, maxX, minY, maxZ, rGlass, gGlass, bGlass, aBase);
      putVertex(glassConsumer, mat, minX, minY, maxZ, rGlass, gGlass, bGlass, aBase);
      putVertex(glassConsumer, mat, minX, maxY, maxZ, rGlass, gGlass, bGlass, aRim);
      putVertex(glassConsumer, mat, maxX, maxY, maxZ, rGlass, gGlass, bGlass, aRim);
      putVertex(glassConsumer, mat, minX, minY, maxZ, rGlass, gGlass, bGlass, aBase);
      putVertex(glassConsumer, mat, minX, minY, minZ, rGlass, gGlass, bGlass, aBase);
      putVertex(glassConsumer, mat, minX, maxY, minZ, rGlass, gGlass, bGlass, aRim);
      putVertex(glassConsumer, mat, minX, maxY, maxZ, rGlass, gGlass, bGlass, aRim);
      putVertex(glassConsumer, mat, maxX, minY, minZ, rGlass, gGlass, bGlass, aBase);
      putVertex(glassConsumer, mat, maxX, minY, maxZ, rGlass, gGlass, bGlass, aBase);
      putVertex(glassConsumer, mat, maxX, maxY, maxZ, rGlass, gGlass, bGlass, aRim);
      putVertex(glassConsumer, mat, maxX, maxY, minZ, rGlass, gGlass, bGlass, aRim);
      int rTop = 225;
      int gTop = 248;
      int bTop = 255;
      int aTop = 36;
      addQuad(glassConsumer, mat, minX, maxY, minZ, minX, maxY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ, rTop, gTop, bTop, aTop);
   }

   private void renderStaticEmptyBulbInterior(PoseStack poseStack, MultiBufferSource buffer, float minX, float maxX, float minY, float maxY, float minZ, float maxZ) {
      VertexConsumer consumer = buffer.getBuffer(PortalFluidRenderTypes.FLUID_TRANSLUCENT_BODY);
      Matrix4f mat = poseStack.last().pose();
      int r = 230;
      int g = 240;
      int b = 255;
      int a = 10;
      float iMinX = minX + 8.0E-4F;
      float iMaxX = maxX - 8.0E-4F;
      float iMinY = minY + 8.0E-4F;
      float iMaxY = maxY - 8.0E-4F;
      float iMinZ = minZ + 8.0E-4F;
      float iMaxZ = maxZ - 8.0E-4F;
      putVertex(consumer, mat, iMinX, iMinY, iMinZ, r, g, b, a);
      putVertex(consumer, mat, iMaxX, iMinY, iMinZ, r, g, b, a);
      putVertex(consumer, mat, iMaxX, iMaxY, iMinZ, r, g, b, a);
      putVertex(consumer, mat, iMinX, iMaxY, iMinZ, r, g, b, a);
      putVertex(consumer, mat, iMaxX, iMinY, iMaxZ, r, g, b, a);
      putVertex(consumer, mat, iMinX, iMinY, iMaxZ, r, g, b, a);
      putVertex(consumer, mat, iMinX, iMaxY, iMaxZ, r, g, b, a);
      putVertex(consumer, mat, iMaxX, iMaxY, iMaxZ, r, g, b, a);
      putVertex(consumer, mat, iMinX, iMinY, iMaxZ, r, g, b, a);
      putVertex(consumer, mat, iMinX, iMinY, iMinZ, r, g, b, a);
      putVertex(consumer, mat, iMinX, iMaxY, iMinZ, r, g, b, a);
      putVertex(consumer, mat, iMinX, iMaxY, iMaxZ, r, g, b, a);
      putVertex(consumer, mat, iMaxX, iMinY, iMinZ, r, g, b, a);
      putVertex(consumer, mat, iMaxX, iMinY, iMaxZ, r, g, b, a);
      putVertex(consumer, mat, iMaxX, iMaxY, iMaxZ, r, g, b, a);
      putVertex(consumer, mat, iMaxX, iMaxY, iMinZ, r, g, b, a);
      putVertex(consumer, mat, iMinX, iMinY, iMinZ, r, g, b, a);
      putVertex(consumer, mat, iMinX, iMinY, iMaxZ, r, g, b, a);
      putVertex(consumer, mat, iMaxX, iMinY, iMaxZ, r, g, b, a);
      putVertex(consumer, mat, iMaxX, iMinY, iMinZ, r, g, b, a);
      putVertex(consumer, mat, iMinX, iMaxY, iMinZ, r, g, b, a);
      putVertex(consumer, mat, iMinX, iMaxY, iMaxZ, r, g, b, a);
      putVertex(consumer, mat, iMaxX, iMaxY, iMaxZ, r, g, b, a);
      putVertex(consumer, mat, iMaxX, iMaxY, iMinZ, r, g, b, a);
   }

   private void renderDynamicPortalLiquid(PoseStack poseStack, MultiBufferSource buffer, int charge, boolean isCreative, boolean isEvilGun, float time, float minX, float maxX, float minY, float maxY, float minZ, float maxZ) {
      this.renderDynamicPortalLiquid(poseStack, buffer, charge, isCreative, isEvilGun ? 16765465 : 2356545, time, minX, maxX, minY, maxY, minZ, maxZ);
   }

   private void renderDynamicPortalLiquid(PoseStack poseStack, MultiBufferSource buffer, int charge, boolean isCreative, int fluidRgb, float time, float minX, float maxX, float minY, float maxY, float minZ, float maxZ) {
      this.renderDynamicPortalLiquid(poseStack, buffer, charge, isCreative, fluidRgb, -1, time, minX, maxX, minY, maxY, minZ, maxZ);
   }

   private void renderDynamicPortalLiquid(PoseStack poseStack, MultiBufferSource buffer, int charge, boolean isCreative, int fluidRgb, int coreRgb, float time, float minX, float maxX, float minY, float maxY, float minZ, float maxZ) {
      poseStack.pushPose();
      if (charge <= 0) {
         this.renderDischargedResidue(poseStack, buffer, minX, maxX, minY, minZ, maxZ, fluidRgb);
      } else {
         float fillRatio = Mth.clamp((float)charge / 100.0F, 0.0F, 1.0F);
         float curMaxY = minY + (maxY - minY) * (0.02F + 0.95F * fillRatio);
         float ctrX = (minX + maxX) * 0.5F;
         float ctrZ = (minZ + maxZ) * 0.5F;
         float radX = (maxX - minX) * 0.5F;
         float radZ = (maxZ - minZ) * 0.5F;
         float breath = 0.88F + 0.12F * Mth.sin(time * 3.5F);
         int rPri;
         int gPri;
         int bPri;
         int rCore;
         int gCore;
         int bCore;
         int baseG;
         int baseB;
         int baseR;
         if (isCreative) {
            float shift = 0.5F + 0.5F * Mth.sin(time * 2.0F);
            rPri = (int)((20.0F * (1.0F - shift) + 0.0F * shift) * breath);
            gPri = (int)(255.0F * breath);
            bPri = (int)((70.0F * (1.0F - shift) + 245.0F * shift) * breath);
            rCore = (int)(170.0F + 85.0F * (1.0F - shift));
            gCore = 255;
            bCore = (int)(205.0F + 50.0F * shift);
         } else if (fluidRgb == 2356545) {
            rPri = (int)(35.0F * breath);
            gPri = (int)(245.0F * breath);
            bPri = (int)(65.0F * breath);
            rCore = 195;
            gCore = 255;
            bCore = 225;
         } else if (fluidRgb == 16765465) {
            rPri = (int)(255.0F * breath);
            gPri = (int)(210.0F * breath);
            bPri = (int)(25.0F * breath);
            rCore = 255;
            gCore = 245;
            bCore = 160;
         } else {
            baseR = fluidRgb >> 16 & 255;
            baseG = fluidRgb >> 8 & 255;
            baseB = fluidRgb & 255;
            rPri = (int)((float)baseR * breath);
            gPri = (int)((float)baseG * breath);
            bPri = (int)((float)baseB * breath);
            rCore = Math.min(255, (int)((float)baseR * 0.7F + 76.5F));
            gCore = Math.min(255, (int)((float)baseG * 0.7F + 76.5F));
            bCore = Math.min(255, (int)((float)baseB * 0.7F + 76.5F));
         }

         if (coreRgb != -1) {
            baseR = coreRgb >> 16 & 255;
            baseG = coreRgb >> 8 & 255;
            baseB = coreRgb & 255;
            rCore = Math.min(255, (int)((float)baseR * 0.75F + 63.75F));
            gCore = Math.min(255, (int)((float)baseG * 0.75F + 63.75F));
            bCore = Math.min(255, (int)((float)baseB * 0.75F + 63.75F));
         }

         this.renderFullRectangularBody(poseStack, buffer, minX, maxX, minY, curMaxY, minZ, maxZ, rPri, gPri, bPri);
         this.renderRectangularVortexRibbon(poseStack, buffer, minY, curMaxY, ctrX, ctrZ, radX, radZ, 0.86F, -time * 4.5F, -time * 0.15F, rPri, gPri, bPri, 165);
         this.renderRectangularVortexRibbon(poseStack, buffer, minY, curMaxY, ctrX, ctrZ, radX, radZ, 0.52F, time * 6.8F, time * 0.28F, rCore, gCore, bCore, 205);
         this.renderCoreFilament(poseStack, buffer, minY, curMaxY, ctrX, ctrZ, rCore, gCore, bCore, time, coreRgb);
         this.renderRectangularBubbles(poseStack, buffer, minX, maxX, minY, curMaxY, minZ, maxZ, ctrX, ctrZ, radX, radZ, rCore, gCore, bCore, time, fillRatio);
         this.renderSmoothRectangularMeniscus(poseStack, buffer, minX, maxX, curMaxY, minZ, maxZ, rPri, gPri, bPri, rCore, gCore, bCore, time);
         this.renderRadioactiveAura(poseStack, buffer, minX, maxX, minY, curMaxY, minZ, maxZ, rPri, gPri, bPri, time);
         if (fillRatio < 0.95F) {
            this.renderUpperGlassDroplets(poseStack, buffer, minX, maxX, curMaxY, maxY, minZ, maxZ, rPri, gPri, bPri, time);
         }
      }

      poseStack.popPose();
   }

   private void renderDischargedResidue(PoseStack poseStack, MultiBufferSource buffer, float minX, float maxX, float minY, float minZ, float maxZ) {
      this.renderDischargedResidue(poseStack, buffer, minX, maxX, minY, minZ, maxZ, 2356545);
   }

   private void renderDischargedResidue(PoseStack poseStack, MultiBufferSource buffer, float minX, float maxX, float minY, float minZ, float maxZ, boolean isEvilGun) {
      this.renderDischargedResidue(poseStack, buffer, minX, maxX, minY, minZ, maxZ, isEvilGun ? 16765465 : 2356545);
   }

   private void renderDischargedResidue(PoseStack poseStack, MultiBufferSource buffer, float minX, float maxX, float minY, float minZ, float maxZ, int fluidRgb) {
      VertexConsumer consumer = buffer.getBuffer(PortalFluidRenderTypes.FLUID_TRANSLUCENT_BODY);
      Matrix4f mat = poseStack.last().pose();
      float topY = minY + 0.003F;
      int r;
      int g;
      int b;
      byte a;
      if (fluidRgb == 16765465) {
         r = 50;
         g = 40;
         b = 10;
         a = 55;
      } else if (fluidRgb == 2356545) {
         r = 15;
         g = 30;
         b = 20;
         a = 45;
      } else {
         int baseR = fluidRgb >> 16 & 255;
         int baseG = fluidRgb >> 8 & 255;
         int baseB = fluidRgb & 255;
         r = (int)((float)baseR * 0.18F);
         g = (int)((float)baseG * 0.18F);
         b = (int)((float)baseB * 0.18F);
         a = 50;
      }

      addQuad(consumer, mat, minX, minY, minZ, maxX, minY, minZ, maxX, topY, maxZ, minX, topY, maxZ, r, g, b, a);
   }

   private void renderFullRectangularBody(PoseStack poseStack, MultiBufferSource buffer, float minX, float maxX, float minY, float maxY, float minZ, float maxZ, int r, int g, int b) {
      VertexConsumer consumer = buffer.getBuffer(PortalFluidRenderTypes.FLUID_TRANSLUCENT_BODY);
      Matrix4f mat = poseStack.last().pose();
      int botR = (int)((float)r * 0.75F);
      int botG = (int)((float)g * 0.75F);
      int botB = (int)((float)b * 0.75F);
      int alphaBot = 170;
      int alphaTop = 200;
      putVertex(consumer, mat, minX, minY, minZ, botR, botG, botB, alphaBot);
      putVertex(consumer, mat, maxX, minY, minZ, botR, botG, botB, alphaBot);
      putVertex(consumer, mat, maxX, maxY, minZ, r, g, b, alphaTop);
      putVertex(consumer, mat, minX, maxY, minZ, r, g, b, alphaTop);
      putVertex(consumer, mat, maxX, minY, maxZ, botR, botG, botB, alphaBot);
      putVertex(consumer, mat, minX, minY, maxZ, botR, botG, botB, alphaBot);
      putVertex(consumer, mat, minX, maxY, maxZ, r, g, b, alphaTop);
      putVertex(consumer, mat, maxX, maxY, maxZ, r, g, b, alphaTop);
      putVertex(consumer, mat, minX, minY, maxZ, botR, botG, botB, alphaBot);
      putVertex(consumer, mat, minX, minY, minZ, botR, botG, botB, alphaBot);
      putVertex(consumer, mat, minX, maxY, minZ, r, g, b, alphaTop);
      putVertex(consumer, mat, minX, maxY, maxZ, r, g, b, alphaTop);
      putVertex(consumer, mat, maxX, minY, minZ, botR, botG, botB, alphaBot);
      putVertex(consumer, mat, maxX, minY, maxZ, botR, botG, botB, alphaBot);
      putVertex(consumer, mat, maxX, maxY, maxZ, r, g, b, alphaTop);
      putVertex(consumer, mat, maxX, maxY, minZ, r, g, b, alphaTop);
      putVertex(consumer, mat, minX, minY, minZ, botR, botG, botB, 215);
      putVertex(consumer, mat, minX, minY, maxZ, botR, botG, botB, 215);
      putVertex(consumer, mat, maxX, minY, maxZ, botR, botG, botB, 215);
      putVertex(consumer, mat, maxX, minY, minZ, botR, botG, botB, 215);
      putVertex(consumer, mat, minX, maxY, minZ, r, g, b, alphaTop);
      putVertex(consumer, mat, minX, maxY, maxZ, r, g, b, alphaTop);
      putVertex(consumer, mat, maxX, maxY, maxZ, r, g, b, alphaTop);
      putVertex(consumer, mat, maxX, maxY, minZ, r, g, b, alphaTop);
   }

   private void renderRectangularVortexRibbon(PoseStack poseStack, MultiBufferSource buffer, float minY, float maxY, float ctrX, float ctrZ, float radX, float radZ, float scale, float angleDeg, float vScroll, int r, int g, int b, int alpha) {
      poseStack.pushPose();
      poseStack.translate(ctrX, (minY + maxY) * 0.5F, ctrZ);
      poseStack.mulPose(Axis.YP.rotationDegrees(angleDeg));
      VertexConsumer consumer = buffer.getBuffer(PortalFluidRenderTypes.fluidAdditiveSwirl(VORTEX_TEXTURE));
      Matrix4f mat = poseStack.last().pose();
      Matrix3f norm = poseStack.last().normal();
      float rx = radX * scale;
      float rz = radZ * scale;
      float halfH = (maxY - minY) * 0.5F;
      int sides = 8;

      for(int i = 0; i < sides; ++i) {
         float a1 = (float)((double)i * 2.0 * Math.PI / (double)sides);
         float a2 = (float)((double)(i + 1) * 2.0 * Math.PI / (double)sides);
         float x1 = Mth.cos(a1) * rx;
         float z1 = Mth.sin(a1) * rz;
         float x2 = Mth.cos(a2) * rx;
         float z2 = Mth.sin(a2) * rz;
         float u1 = (float)i / (float)sides;
         float u2 = (float)(i + 1) / (float)sides;
         consumer.addVertex(mat, x1, -halfH, z1).setColor(r, g, b, alpha).setUv(u1, vScroll).setOverlay(OverlayTexture.NO_OVERLAY).setLight(15728880).setNormal(0.0F, 0.0F, 1.0F);
         consumer.addVertex(mat, x2, -halfH, z2).setColor(r, g, b, alpha).setUv(u2, vScroll).setOverlay(OverlayTexture.NO_OVERLAY).setLight(15728880).setNormal(0.0F, 0.0F, 1.0F);
         consumer.addVertex(mat, x2, halfH, z2).setColor(r, g, b, alpha).setUv(u2, vScroll + 1.2F).setOverlay(OverlayTexture.NO_OVERLAY).setLight(15728880).setNormal(0.0F, 0.0F, 1.0F);
         consumer.addVertex(mat, x1, halfH, z1).setColor(r, g, b, alpha).setUv(u1, vScroll + 1.2F).setOverlay(OverlayTexture.NO_OVERLAY).setLight(15728880).setNormal(0.0F, 0.0F, 1.0F);
      }

      poseStack.popPose();
   }

   private void renderCoreFilament(PoseStack poseStack, MultiBufferSource buffer, float minY, float maxY, float ctrX, float ctrZ, int rCore, int gCore, int bCore, float time, int coreRgb) {
      VertexConsumer consumer = buffer.getBuffer(PortalFluidRenderTypes.FLUID_ADDITIVE_GLOW);
      Matrix4f mat = poseStack.last().pose();
      float swayX = 6.0E-4F * Mth.sin(time * 3.0F);
      float swayZ = 6.0E-4F * Mth.cos(time * 2.5F);
      float cx = ctrX + swayX;
      float cz = ctrZ + swayZ;
      float w1 = 0.0014F + 4.0E-4F * Mth.sin(time * 6.0F);
      int a1 = 180;
      renderFilamentCross(consumer, mat, cx, cz, minY, maxY, w1, rCore, gCore, bCore, a1);
      float w2 = 0.0036F + 7.0E-4F * Mth.sin(time * 4.5F + 1.0F);
      int a2 = 115;
      int rMid;
      int gMid;
      int bMid;
      int rOut;
      int gOut;
      int bOut;
      if (coreRgb != -1) {
         int cR = coreRgb >> 16 & 255;
         int cG = coreRgb >> 8 & 255;
         int cB = coreRgb & 255;
         rMid = Math.min(255, (int)((float)cR * 0.9F));
         gMid = Math.min(255, (int)((float)cG * 0.9F));
         bMid = Math.min(255, (int)((float)cB * 0.9F));
         rOut = Math.min(255, (int)((float)cR * 0.55F));
         gOut = Math.min(255, (int)((float)cG * 0.55F));
         bOut = Math.min(255, (int)((float)cB * 0.55F));
      } else {
         rMid = 65;
         gMid = 255;
         bMid = 115;
         rOut = 20;
         gOut = 240;
         bOut = 65;
      }

      renderFilamentCross(consumer, mat, cx, cz, minY, maxY, w2, rMid, gMid, bMid, a2);
      float w3 = 0.0068F + 0.001F * Mth.sin(time * 3.0F + 2.0F);
      int a3 = 45;
      renderFilamentCross(consumer, mat, cx, cz, minY, maxY, w3, rOut, gOut, bOut, a3);
   }

   private static void renderFilamentCross(VertexConsumer consumer, Matrix4f mat, float cx, float cz, float minY, float maxY, float width, int r, int g, int b, int alpha) {
      addQuad(consumer, mat, cx - width, minY, cz, cx + width, minY, cz, cx + width, maxY, cz, cx - width, maxY, cz, r, g, b, alpha);
      addQuad(consumer, mat, cx, minY, cz - width, cx, minY, cz + width, cx, maxY, cz + width, cx, maxY, cz - width, r, g, b, alpha);
      float d = width * 0.7071F;
      addQuad(consumer, mat, cx - d, minY, cz - d, cx + d, minY, cz + d, cx + d, maxY, cz + d, cx - d, maxY, cz - d, r, g, b, alpha);
   }

   private void renderRectangularBubbles(PoseStack poseStack, MultiBufferSource buffer, float minX, float maxX, float minY, float maxY, float minZ, float maxZ, float ctrX, float ctrZ, float radX, float radZ, int r, int g, int b, float time, float fillRatio) {
      VertexConsumer consumer = buffer.getBuffer(PortalFluidRenderTypes.FLUID_ADDITIVE_GLOW);
      Matrix4f mat = poseStack.last().pose();
      float totalH = maxY - minY;
      if (!(totalH <= 0.005F)) {
         int bubbleCount = (int)(8.0F + 8.0F * fillRatio);

         for(int i = 0; i < bubbleCount; ++i) {
            float speed = 0.25F + (float)(i % 5) * 0.07F;
            float phase = (float)((double)i * 0.381966);
            float progress = (time * speed + phase) % 1.0F;
            float bY = minY + 0.001F + progress * (totalH - 0.002F);
            float u = (float)((double)i * 0.6180339887 % 1.0);
            float v = (float)((double)i * 0.7548776662 % 1.0);
            float bX = ctrX + (2.0F * u - 1.0F) * radX * 0.82F + 0.0018F * Mth.sin(time * 3.2F + (float)i * 1.7F);
            float bZ = ctrZ + (2.0F * v - 1.0F) * radZ * 0.82F + 0.0018F * Mth.cos(time * 2.6F + (float)i * 2.3F);
            bX = Mth.clamp(bX, minX + 0.0015F, maxX - 0.0015F);
            bZ = Mth.clamp(bZ, minZ + 0.0015F, maxZ - 0.0015F);
            float bubbleScale = (0.0012F + 6.0E-4F * (float)Math.sin((double)((float)i * 3.1F))) * Mth.sin(progress * 3.1415927F);
            int bAlpha = (int)(240.0F * Mth.sin(progress * 3.1415927F));
            if (bubbleScale > 2.0E-4F && bAlpha > 5) {
               addQuad(consumer, mat, bX - bubbleScale, bY - bubbleScale, bZ, bX + bubbleScale, bY - bubbleScale, bZ, bX + bubbleScale, bY + bubbleScale, bZ, bX - bubbleScale, bY + bubbleScale, bZ, r, g, b, bAlpha);
               addQuad(consumer, mat, bX, bY - bubbleScale, bZ - bubbleScale, bX, bY - bubbleScale, bZ + bubbleScale, bX, bY + bubbleScale, bZ + bubbleScale, bX, bY + bubbleScale, bZ - bubbleScale, r, g, b, bAlpha);
            }
         }

      }
   }

   private void renderSmoothRectangularMeniscus(PoseStack poseStack, MultiBufferSource buffer, float minX, float maxX, float maxY, float minZ, float maxZ, int rPri, int gPri, int bPri, int rCore, int gCore, int bCore, float time) {
      VertexConsumer consumer = buffer.getBuffer(PortalFluidRenderTypes.FLUID_ADDITIVE_GLOW);
      Matrix4f mat = poseStack.last().pose();
      int gridX = 6;
      int gridZ = 6;
      float stepX = (maxX - minX) / (float)gridX;
      float stepZ = (maxZ - minZ) / (float)gridZ;

      for(int ix = 0; ix < gridX; ++ix) {
         for(int iz = 0; iz < gridZ; ++iz) {
            float u0 = (float)ix / (float)gridX;
            float u1 = (float)(ix + 1) / (float)gridX;
            float v0 = (float)iz / (float)gridZ;
            float v1 = (float)(iz + 1) / (float)gridZ;
            float x0 = minX + (float)ix * stepX;
            float x1 = minX + (float)(ix + 1) * stepX;
            float z0 = minZ + (float)iz * stepZ;
            float z1 = minZ + (float)(iz + 1) * stepZ;
            float y00 = maxY + evaluateRectangularMeniscusWave(u0, v0, time);
            float y10 = maxY + evaluateRectangularMeniscusWave(u1, v0, time);
            float y11 = maxY + evaluateRectangularMeniscusWave(u1, v1, time);
            float y01 = maxY + evaluateMeniscusWave(u0, v1, time);
            float borderFactor = Math.max(Math.abs(2.0F * (u0 + u1) * 0.5F - 1.0F), Math.abs(2.0F * (v0 + v1) * 0.5F - 1.0F));
            int r = (int)((float)rCore * (1.0F - borderFactor) + (float)rPri * borderFactor);
            int g = (int)((float)gCore * (1.0F - borderFactor) + (float)gPri * borderFactor);
            int b = (int)((float)bCore * (1.0F - borderFactor) + (float)bPri * borderFactor);
            int alpha = (int)(200.0F + 45.0F * borderFactor);
            putVertex(consumer, mat, x0, y00, z0, r, g, b, alpha);
            putVertex(consumer, mat, x1, y10, z0, r, g, b, alpha);
            putVertex(consumer, mat, x1, y11, z1, r, g, b, alpha);
            putVertex(consumer, mat, x0, y01, z1, r, g, b, alpha);
         }
      }

   }

   private static float evaluateRectangularMeniscusWave(float u, float v, float time) {
      float edgeDist = Math.max(Math.abs(2.0F * u - 1.0F), Math.abs(2.0F * v - 1.0F));
      float capillary = 3.5E-4F * edgeDist * edgeDist;
      float wave1 = 2.0E-4F * Mth.sin(6.28F * (1.2F * u + 0.8F * v) - 3.2F * time);
      float wave2 = 1.5E-4F * Mth.cos(6.28F * (0.9F * u - 1.4F * v) + 2.6F * time);
      return capillary + wave1 + wave2;
   }

   private static float evaluateMeniscusWave(float u, float v, float time) {
      return evaluateRectangularMeniscusWave(u, v, time);
   }

   private void renderRadioactiveAura(PoseStack poseStack, MultiBufferSource buffer, float minX, float maxX, float minY, float maxY, float minZ, float maxZ, int r, int g, int b, float time) {
      VertexConsumer consumer = buffer.getBuffer(PortalFluidRenderTypes.FLUID_ADDITIVE_GLOW);
      Matrix4f mat = poseStack.last().pose();
      float auraPulse = 6.0E-4F * Mth.sin(time * 3.0F);
      float ax0 = minX - 6.0E-4F - auraPulse;
      float ax1 = maxX + 6.0E-4F + auraPulse;
      float az0 = minZ - 6.0E-4F - auraPulse;
      float az1 = maxZ + 6.0E-4F + auraPulse;
      float ay0 = minY - 4.0E-4F;
      float ay1 = maxY + 8.0E-4F + auraPulse;
      int auraAlpha = (int)(35.0F + 15.0F * Mth.sin(time * 2.8F));
      addQuad(consumer, mat, ax0, ay0, az1, ax1, ay0, az1, ax1, ay1, az1, ax0, ay1, az1, r, g, b, auraAlpha);
      addQuad(consumer, mat, ax1, ay0, az0, ax0, ay0, az0, ax0, ay1, az0, ax1, ay1, az0, r, g, b, auraAlpha);
      addQuad(consumer, mat, ax0, ay0, az0, ax0, ay0, az1, ax0, ay1, az1, ax0, ay1, az0, r, g, b, auraAlpha);
      addQuad(consumer, mat, ax1, ay0, az1, ax1, ay0, az0, ax1, ay1, az0, ax1, ay1, az1, r, g, b, auraAlpha);
   }

   private void renderUpperGlassDroplets(PoseStack poseStack, MultiBufferSource buffer, float minX, float maxX, float curMaxY, float maxY, float minZ, float maxZ, int r, int g, int b, float time) {
      if (!(maxY - curMaxY < 0.004F)) {
         VertexConsumer consumer = buffer.getBuffer(PortalFluidRenderTypes.FLUID_ADDITIVE_GLOW);
         Matrix4f mat = poseStack.last().pose();
         float emptyH = maxY - curMaxY;
         float[][] dropletLocs = new float[][]{{0.25F, 0.3F, 0.0F}, {0.75F, 0.65F, 1.0F}, {0.0F, 0.45F, 0.35F}, {1.0F, 0.8F, 0.7F}};

         for(int i = 0; i < dropletLocs.length; ++i) {
            float[] d = dropletLocs[i];
            float yRel = d[1];
            float dropY = curMaxY + emptyH * yRel;
            if (!(dropY >= maxY - 0.001F) && !(dropY <= curMaxY + 0.001F)) {
               float dropX = minX + (maxX - minX) * d[0];
               float dropZ = minZ + (maxZ - minZ) * d[2];
               float sz = 7.0E-4F + 2.0E-4F * (float)Math.sin((double)(time * 2.0F + (float)i));
               int a = (int)(120.0 + 30.0 * Math.sin((double)(time * 3.0F + (float)i * 2.0F)));
               if (d[0] != 0.0F && d[0] != 1.0F) {
                  addQuad(consumer, mat, dropX - sz, dropY - sz, dropZ, dropX + sz, dropY - sz, dropZ, dropX + sz, dropY + sz, dropZ, dropX - sz, dropY + sz, dropZ, r, g, b, a);
               } else {
                  addQuad(consumer, mat, dropX, dropY - sz, dropZ - sz, dropX, dropY - sz, dropZ + sz, dropX, dropY + sz, dropZ + sz, dropX, dropY + sz, dropZ - sz, r, g, b, a);
               }
            }
         }

      }
   }

   public static void putVertex(VertexConsumer consumer, Matrix4f mat, float x, float y, float z, int r, int g, int b, int a) {
      consumer.addVertex(mat, x, y, z).setColor(r, g, b, a).setUv(0.5F, 0.5F).setOverlay(OverlayTexture.NO_OVERLAY).setLight(15728880).setNormal(0.0F, 0.0F, 1.0F);
   }

   private static void addQuad(VertexConsumer consumer, Matrix4f mat, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float x4, float y4, float z4, int r, int g, int b, int a) {
      putVertex(consumer, mat, x1, y1, z1, r, g, b, a);
      putVertex(consumer, mat, x2, y2, z2, r, g, b, a);
      putVertex(consumer, mat, x3, y3, z3, r, g, b, a);
      putVertex(consumer, mat, x4, y4, z4, r, g, b, a);
   }

   private void renderDigitalCoordinateScreen(PoseStack poseStack, MultiBufferSource buffer, ItemStack stack, int charge, boolean isCreative, boolean isInfinityBulb, boolean isEvilGun, float time) {
      float scrMinX = 0.3753125F;
      float scrMaxX = 0.3996875F;
      float scrMinZ = 0.4565625F;
      float scrMaxZ = 0.5434375F;
      float scrY0 = 0.181375F;
      float glowHeight = 0.01625F;
      float scrY1 = scrY0 + glowHeight;
      Matrix4f mat = poseStack.last().pose();
      boolean isQuantum = isInfinityBulb || isCreative;
      float breath = 0.88F + 0.12F * Mth.sin(time * 4.5F);
      float flicker = 0.96F + 0.04F * Mth.sin(time * 32.0F);
      float intensity = breath * flicker;
      int r;
      int g;
      int b;
      short aBed;
      short aGlowBot;
      if (charge <= 0 && !isQuantum) {
         boolean blink = (int)(time * 3.0F) % 2 == 0;
         if (!blink) {
            return;
         }

         r = 255;
         g = 15;
         b = 20;
         aBed = 90;
         aGlowBot = 60;
      } else if (charge <= 20 && !isQuantum) {
         r = (int)(255.0F * intensity);
         g = (int)(140.0F * intensity);
         b = (int)(20.0F * intensity);
         aBed = 145;
         aGlowBot = 125;
      } else if (isQuantum) {
         r = (int)(35.0F * intensity);
         g = (int)(255.0F * intensity);
         b = (int)(110.0F * intensity);
         aBed = 150;
         aGlowBot = 135;
      } else if (isEvilGun) {
         r = (int)(255.0F * intensity);
         g = (int)(200.0F * intensity);
         b = (int)(30.0F * intensity);
         aBed = 155;
         aGlowBot = 143;
      } else {
         r = (int)(255.0F * intensity);
         g = (int)(30.0F * intensity);
         b = (int)(40.0F * intensity);
         aBed = 155;
         aGlowBot = 143;
      }

      VertexConsumer bodyConsumer = buffer.getBuffer(PortalFluidRenderTypes.FLUID_TRANSLUCENT_BODY);
      addQuad(bodyConsumer, mat, scrMinX, scrY0, scrMinZ, scrMinX, scrY0, scrMaxZ, scrMaxX, scrY0, scrMaxZ, scrMaxX, scrY0, scrMinZ, r / 2, g / 2, b / 2, aBed);
      VertexConsumer glowConsumer = buffer.getBuffer(PortalFluidRenderTypes.FLUID_ADDITIVE_GLOW);
      addQuad(glowConsumer, mat, scrMinX, scrY0, scrMinZ, scrMinX, scrY0, scrMaxZ, scrMaxX, scrY0, scrMaxZ, scrMaxX, scrY0, scrMinZ, r, g, b, (int)((float)aGlowBot * 0.75F));
      putVertex(glowConsumer, mat, scrMinX, scrY0, scrMinZ, r, g, b, aGlowBot);
      putVertex(glowConsumer, mat, scrMinX, scrY0, scrMaxZ, r, g, b, aGlowBot);
      putVertex(glowConsumer, mat, scrMinX, scrY1, scrMaxZ, r, g, b, 0);
      putVertex(glowConsumer, mat, scrMinX, scrY1, scrMinZ, r, g, b, 0);
      putVertex(glowConsumer, mat, scrMaxX, scrY0, scrMaxZ, r, g, b, aGlowBot);
      putVertex(glowConsumer, mat, scrMaxX, scrY0, scrMinZ, r, g, b, aGlowBot);
      putVertex(glowConsumer, mat, scrMaxX, scrY1, scrMinZ, r, g, b, 0);
      putVertex(glowConsumer, mat, scrMaxX, scrY1, scrMaxZ, r, g, b, 0);
      putVertex(glowConsumer, mat, scrMaxX, scrY0, scrMinZ, r, g, b, aGlowBot);
      putVertex(glowConsumer, mat, scrMinX, scrY0, scrMinZ, r, g, b, aGlowBot);
      putVertex(glowConsumer, mat, scrMinX, scrY1, scrMinZ, r, g, b, 0);
      putVertex(glowConsumer, mat, scrMaxX, scrY1, scrMinZ, r, g, b, 0);
      putVertex(glowConsumer, mat, scrMinX, scrY0, scrMaxZ, r, g, b, aGlowBot);
      putVertex(glowConsumer, mat, scrMaxX, scrY0, scrMaxZ, r, g, b, aGlowBot);
      putVertex(glowConsumer, mat, scrMaxX, scrY1, scrMaxZ, r, g, b, 0);
      putVertex(glowConsumer, mat, scrMinX, scrY1, scrMaxZ, r, g, b, 0);
      float scrMidX = (scrMinX + scrMaxX) * 0.5F;
      int aMid = (int)((float)aGlowBot * 0.85F);
      putVertex(glowConsumer, mat, scrMidX, scrY0, scrMinZ, r, g, b, aMid);
      putVertex(glowConsumer, mat, scrMidX, scrY0, scrMaxZ, r, g, b, aMid);
      putVertex(glowConsumer, mat, scrMidX, scrY1, scrMaxZ, r, g, b, 0);
      putVertex(glowConsumer, mat, scrMidX, scrY1, scrMinZ, r, g, b, 0);
      putVertex(glowConsumer, mat, scrMinX, scrY0, scrMinZ, r, g, b, aMid / 2);
      putVertex(glowConsumer, mat, scrMaxX, scrY0, scrMaxZ, r, g, b, aMid / 2);
      putVertex(glowConsumer, mat, scrMaxX, scrY1, scrMaxZ, r, g, b, 0);
      putVertex(glowConsumer, mat, scrMinX, scrY1, scrMinZ, r, g, b, 0);
      putVertex(glowConsumer, mat, scrMaxX, scrY0, scrMinZ, r, g, b, aMid / 2);
      putVertex(glowConsumer, mat, scrMinX, scrY0, scrMaxZ, r, g, b, aMid / 2);
      putVertex(glowConsumer, mat, scrMinX, scrY1, scrMaxZ, r, g, b, 0);
      putVertex(glowConsumer, mat, scrMaxX, scrY1, scrMinZ, r, g, b, 0);
   }
}

