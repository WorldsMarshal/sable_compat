package com.invfix.rick.portalgun.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/** Порт FluidPoisonParticle из Rick's stuff 0.0.4.3 (зелёный и жёлтый варианты). */
@OnlyIn(Dist.CLIENT)
public class FluidPoisonParticle extends TextureSheetParticle {
   private final SpriteSet sprites;
   private final float baseSize;

   public FluidPoisonParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
      super(level, x, y, z, vx, vy, vz);
      this.sprites = sprites;
      this.rCol = 1.0F;
      this.gCol = 1.0F;
      this.bCol = 1.0F;
      this.xd = vx * 0.35;
      this.yd = vy * 0.35;
      this.zd = vz * 0.35;
      this.lifetime = (int)(20.0 + Math.random() * 10.0);
      this.baseSize = 0.48F + (float)(Math.random() * 0.1599999964237213);
      this.quadSize = this.baseSize;
      this.hasPhysics = false;
      this.setSpriteFromAge(sprites);
   }

   @Override
   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @Override
   public int getLightColor(float partialTick) {
      return 15728880;
   }

   @Override
   public void tick() {
      this.xo = this.x;
      this.yo = this.y;
      this.zo = this.z;
      if (this.age++ >= this.lifetime) {
         this.remove();
      } else {
         this.setSpriteFromAge(this.sprites);
         this.move(this.xd, this.yd, this.zd);
         this.xd *= 0.82;
         this.yd = this.yd * 0.82 + 0.008;
         this.zd *= 0.82;
         float progress = (float)this.age / (float)this.lifetime;
         this.quadSize = this.baseSize * (1.0F + progress * 0.25F);
         this.alpha = (float)Math.sin((double)(1.0F - progress) * Math.PI * 0.5);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class YellowProvider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public YellowProvider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      @Override
      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         FluidPoisonParticle p = new FluidPoisonParticle(level, x, y, z, vx, vy, vz, this.sprites);
         p.setColor(1.0F, 1.0F, 1.0F);
         return p;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class GreenProvider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public GreenProvider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      @Override
      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         FluidPoisonParticle p = new FluidPoisonParticle(level, x, y, z, vx, vy, vz, this.sprites);
         p.setColor(1.0F, 1.0F, 1.0F);
         return p;
      }
   }
}
