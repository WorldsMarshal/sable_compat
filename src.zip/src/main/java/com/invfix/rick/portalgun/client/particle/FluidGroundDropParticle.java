package com.invfix.rick.portalgun.client.particle;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/** Порт FluidGroundDropParticle из Rick's stuff 0.0.4.3 — лужица, лежащая на земле. */
@OnlyIn(Dist.CLIENT)
public class FluidGroundDropParticle extends TextureSheetParticle {
   private final SpriteSet sprites;
   private final float baseSize;

   public FluidGroundDropParticle(ClientLevel level, double x, double y, double z, SpriteSet sprites) {
      super(level, x, y, z, 0.0, 0.0, 0.0);
      this.sprites = sprites;
      this.rCol = 1.0F;
      this.gCol = 1.0F;
      this.bCol = 1.0F;
      this.xd = 0.0;
      this.yd = 0.0;
      this.zd = 0.0;
      this.lifetime = (int)(35.0 + Math.random() * 25.0);
      this.baseSize = 0.45F + (float)(Math.random() * 0.25);
      this.quadSize = this.baseSize;
      this.roll = (float)(Math.random() * Math.PI * 2.0);
      this.hasPhysics = false;
      this.setSpriteFromAge(sprites);
   }

   @Override
   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @Override
   public int getLightColor(float partialTick) {
      return 15728880;
   }

   @Override
   public void tick() {
      this.xo = this.x;
      this.yo = this.y;
      this.zo = this.z;
      if (this.age++ >= this.lifetime) {
         this.remove();
      } else {
         this.setSpriteFromAge(this.sprites);
         float progress = (float)this.age / (float)this.lifetime;
         if (progress > 0.65F) {
            this.alpha = 1.0F - (progress - 0.65F) / 0.35F;
         } else {
            this.alpha = 1.0F;
         }
      }
   }

   @Override
   public void render(VertexConsumer consumer, Camera camera, float partialTicks) {
      Vec3 camPos = camera.getPosition();
      float px = (float)(Mth.lerp((double)partialTicks, this.xo, this.x) - camPos.x());
      float py = (float)(Mth.lerp((double)partialTicks, this.yo, this.y) - camPos.y()) + 0.015F;
      float pz = (float)(Mth.lerp((double)partialTicks, this.zo, this.z) - camPos.z());
      float size = this.quadSize;
      float u0 = this.getU0();
      float u1 = this.getU1();
      float v0 = this.getV0();
      float v1 = this.getV1();
      int light = this.getLightColor(partialTicks);
      float sin = Mth.sin(this.roll);
      float cos = Mth.cos(this.roll);
      float x0 = (-cos - sin) * size;
      float z0 = (-sin + cos) * size;
      float x1 = (cos - sin) * size;
      float z1 = (sin + cos) * size;
      float x2 = (cos + sin) * size;
      float z2 = (sin - cos) * size;
      float x3 = (-cos + sin) * size;
      float z3 = (-sin - cos) * size;
      consumer.addVertex(px + x0, py, pz + z0).setUv(u0, v1).setColor(this.rCol, this.gCol, this.bCol, this.alpha).setLight(light);
      consumer.addVertex(px + x1, py, pz + z1).setUv(u1, v1).setColor(this.rCol, this.gCol, this.bCol, this.alpha).setLight(light);
      consumer.addVertex(px + x2, py, pz + z2).setUv(u1, v0).setColor(this.rCol, this.gCol, this.bCol, this.alpha).setLight(light);
      consumer.addVertex(px + x3, py, pz + z3).setUv(u0, v0).setColor(this.rCol, this.gCol, this.bCol, this.alpha).setLight(light);
   }

   @OnlyIn(Dist.CLIENT)
   public static class YellowProvider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public YellowProvider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      @Override
      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new FluidGroundDropParticle(level, x, y, z, this.sprites);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class GreenProvider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public GreenProvider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      @Override
      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new FluidGroundDropParticle(level, x, y, z, this.sprites);
      }
   }
}
