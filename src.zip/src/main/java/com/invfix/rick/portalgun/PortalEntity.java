package com.invfix.rick.portalgun;

import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.animal.WaterAnimal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Портал. Порт PortalEntity из Rick's stuff 0.0.4.3: ориентация (стена / пол /
 * потолок), масштаб, связь с парой по UUID, анимации открытия, прохода и
 * закрытия, проверка пересечения плоскости с учётом прошлой позиции (быстрые
 * сущности не проскакивают сквозь портал), проход для ЛЮБЫХ сущностей.
 *
 * Что убрано из оригинала: блендер-измерение, «хазард-щит», произвольная
 * «GPS»-цель без второго портала — у нас точка всегда получает свой портал.
 *
 * Что добавлено:
 *  - лимит проходов для режима POINT (как было у нашей пушки);
 *  - измерение напарника: пара может жить в разных мирах, а искать напарника
 *    перебором всех миров незачем;
 *  - чанк портала держится региональным тикетом, пока портал жив. Иначе
 *    дальняя половина пары выгружается, и телепорт в неё тихо не срабатывает.
 *    Тикет временный (TicketType.PORTAL, 300 тиков) и продлевается портал
 *    сам — после удаления портала чанк отпускается без явной отписки.
 */
public class PortalEntity extends Entity {

    public static final int ORIENTATION_WALL = 0;
    public static final int ORIENTATION_CEILING = 1;
    public static final int ORIENTATION_FLOOR = 2;

    /** Продолжительность анимации прохода, тиков (оригинал). */
    public static final int PASS_ANIMATION_DURATION = 18;
    /** Продолжительность схлопывания, тиков (оригинал). */
    public static final int CLOSE_DURATION = 9;
    /** Срок жизни парных порталов: 60 сек (portalMaxLifetimeTicks оригинала). */
    public static final int PAIR_LIFETIME = 1200;
    /** Срок жизни пары режима POINT — прежняя страховка нашей пушки, 15 мин. */
    public static final int POINT_LIFETIME = 20 * 60 * 15;
    /** Без лимита проходов. */
    public static final int UNLIMITED_PASSES = -1;

    private static final int TICKET_REFRESH = 100;

    private static final EntityDataAccessor<Integer> DATA_ORIENTATION =
            SynchedEntityData.defineId(PortalEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ROTATION =
            SynchedEntityData.defineId(PortalEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DATA_SCALE =
            SynchedEntityData.defineId(PortalEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> DATA_COLOR =
            SynchedEntityData.defineId(PortalEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_IS_LINKED =
            SynchedEntityData.defineId(PortalEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Optional<UUID>> DATA_DUALITY_UUID =
            SynchedEntityData.defineId(PortalEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Boolean> DATA_IS_ROOT =
            SynchedEntityData.defineId(PortalEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_OWNER_GUN_ID =
            SynchedEntityData.defineId(PortalEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<String> DATA_GUN_MODE =
            SynchedEntityData.defineId(PortalEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> DATA_CLOSING =
            SynchedEntityData.defineId(PortalEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_PASS_TICKS =
            SynchedEntityData.defineId(PortalEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_PASSES_LEFT =
            SynchedEntityData.defineId(PortalEntity.class, EntityDataSerializers.INT);

    private final Map<UUID, Integer> teleportCooldowns = new HashMap<>();
    @Nullable private ResourceKey<Level> dualityDimension;
    private int closingTimer = -1;
    private int clientClosingTimer = -1;
    private int clientPassTimer = 0;
    private int lifetime = PAIR_LIFETIME;
    /** Портал старой пушки (до переноса): закрыть и отпустить его форс-чанк. */
    private boolean legacy;

    public PortalEntity(EntityType<? extends PortalEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    // ================= синхронизируемые поля =================

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_ORIENTATION, ORIENTATION_WALL);
        builder.define(DATA_ROTATION, 0);
        builder.define(DATA_SCALE, PortalGunItem.PORTAL_SCALE);
        builder.define(DATA_COLOR, PortalGunItem.COLOR_GREEN);
        builder.define(DATA_IS_LINKED, false);
        builder.define(DATA_DUALITY_UUID, Optional.empty());
        builder.define(DATA_IS_ROOT, false);
        builder.define(DATA_OWNER_GUN_ID, 0);
        builder.define(DATA_GUN_MODE, PortalMode.FIFO.id());
        builder.define(DATA_CLOSING, false);
        builder.define(DATA_PASS_TICKS, 0);
        builder.define(DATA_PASSES_LEFT, UNLIMITED_PASSES);
    }

    public int getOrientation() { return this.entityData.get(DATA_ORIENTATION); }

    public void setOrientation(int orientation) {
        this.entityData.set(DATA_ORIENTATION, orientation);
        this.refreshDimensions();
    }

    public int getRotation() { return this.entityData.get(DATA_ROTATION); }
    public void setRotation(int rotation) { this.entityData.set(DATA_ROTATION, rotation); }

    public float getScale() { return this.entityData.get(DATA_SCALE); }

    public void setScale(float scale) {
        this.entityData.set(DATA_SCALE, Math.max(0.1F, scale));
        this.refreshDimensions();
    }

    public int getColor() { return this.entityData.get(DATA_COLOR); }
    public void setColor(int color) { this.entityData.set(DATA_COLOR, color); }

    public boolean isLinked() { return this.entityData.get(DATA_IS_LINKED); }
    public void setLinked(boolean linked) { this.entityData.set(DATA_IS_LINKED, linked); }

    public Optional<UUID> getDualityPortalId() { return this.entityData.get(DATA_DUALITY_UUID); }

    public void setDuality(@Nullable UUID uuid, @Nullable ResourceKey<Level> dimension) {
        this.entityData.set(DATA_DUALITY_UUID, Optional.ofNullable(uuid));
        this.dualityDimension = dimension;
    }

    @Nullable public ResourceKey<Level> getDualityDimension() { return this.dualityDimension; }

    public boolean isRoot() { return this.entityData.get(DATA_IS_ROOT); }
    public void setRoot(boolean root) { this.entityData.set(DATA_IS_ROOT, root); }

    public int getOwnerGunId() { return this.entityData.get(DATA_OWNER_GUN_ID); }
    public void setOwnerGunId(int id) { this.entityData.set(DATA_OWNER_GUN_ID, id); }

    public PortalMode getGunMode() { return PortalMode.byId(this.entityData.get(DATA_GUN_MODE)); }

    public void setGunMode(PortalMode mode) {
        this.entityData.set(DATA_GUN_MODE, mode.id());
        this.lifetime = mode == PortalMode.POINT ? POINT_LIFETIME : PAIR_LIFETIME;
    }

    public int getPassesLeft() { return this.entityData.get(DATA_PASSES_LEFT); }
    public void setPassesLeft(int passes) { this.entityData.set(DATA_PASSES_LEFT, passes); }

    public boolean isClosing() { return this.entityData.get(DATA_CLOSING); }

    public int getClientPassTimer() { return clientPassTimer; }
    public int getClientClosingTimer() { return clientClosingTimer; }

    public void triggerPassAnimation() {
        this.entityData.set(DATA_PASS_TICKS, PASS_ANIMATION_DURATION);
        this.clientPassTimer = PASS_ANIMATION_DURATION;
    }

    public void setTeleportCooldown(UUID entity, int ticks) { this.teleportCooldowns.put(entity, ticks); }

    public boolean hasTeleportCooldown(UUID entity) {
        Integer cd = this.teleportCooldowns.get(entity);
        return cd != null && cd > 0;
    }

    public Vec3 getNormalVector() {
        return PortalTeleportEngine.getPortalNormal(getOrientation(), getYRot());
    }

    @Override
    public void onSyncedDataUpdated(@NotNull EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (DATA_SCALE.equals(key) || DATA_ORIENTATION.equals(key)) this.refreshDimensions();
        if (DATA_PASS_TICKS.equals(key)) {
            int val = this.entityData.get(DATA_PASS_TICKS);
            if (val > 0) this.clientPassTimer = val;
        }
        if (DATA_CLOSING.equals(key) && this.entityData.get(DATA_CLOSING) && this.clientClosingTimer < 0) {
            this.clientClosingTimer = CLOSE_DURATION;
        }
    }

    // ================= геометрия =================

    @Override
    protected @NotNull AABB makeBoundingBox() {
        float scale = getScale();
        int orientation = getOrientation();
        double x = getX(), y = getY(), z = getZ();
        if (orientation == ORIENTATION_WALL) {
            float rad = (float) Math.toRadians(getYRot());
            double nx = Math.abs(-Math.sin(rad));
            double nz = Math.abs(Math.cos(rad));
            double tx = Math.abs(Math.cos(rad));
            double tz = Math.abs(Math.sin(rad));
            double hw = 0.7 * scale;
            double hh = 1.05 * scale;
            double ht = 0.35 * scale;
            double hx = tx * hw + nx * ht;
            double hz = tz * hw + nz * ht;
            return new AABB(x - hx, y - hh, z - hz, x + hx, y + hh, z + hz);
        }
        double r = 0.65 * scale;
        double ht = 0.3 * scale;
        return orientation == ORIENTATION_FLOOR
                ? new AABB(x - r, y - 0.1, z - r, x + r, y + ht, z + r)
                : new AABB(x - r, y - ht, z - r, x + r, y + 0.1, z + r);
    }

    @Override
    public @NotNull EntityDimensions getDimensions(@NotNull Pose pose) {
        float scale = getScale();
        return getOrientation() == ORIENTATION_WALL
                ? EntityDimensions.scalable(1.9F * scale, 2.1F * scale)
                : EntityDimensions.scalable(1.9F * scale, 0.2F * scale);
    }

    /** ЛКМ пушкой по порталу закрывает его — поэтому портал «выделяемый». */
    @Override public boolean isPickable() { return !this.isRemoved(); }
    @Override public boolean isPushable() { return false; }
    @Override public boolean canBeCollidedWith() { return false; }
    @Override public boolean hurt(@NotNull DamageSource source, float amount) { return false; }
    @Override public boolean fireImmune() { return true; }

    // ================= тик =================

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            if (this.clientPassTimer > 0) --this.clientPassTimer;
            if (this.clientClosingTimer > 0) {
                --this.clientClosingTimer;
                if (this.clientClosingTimer == 1) spawnCollapseParticles();
            }
            spawnClientParticles();
            return;
        }

        int pass = this.entityData.get(DATA_PASS_TICKS);
        if (pass > 0) this.entityData.set(DATA_PASS_TICKS, pass - 1);
        serverTick((ServerLevel) this.level());
    }

    private void serverTick(ServerLevel level) {
        if (legacy) {
            // Портал старой пушки держал чанк через setChunkForced — отпускаем.
            ChunkPos pos = new ChunkPos(this.blockPosition());
            level.setChunkForced(pos.x, pos.z, false);
            this.discard();
            return;
        }

        if (this.tickCount == 1 || this.tickCount % TICKET_REFRESH == 0) {
            ChunkPos chunk = new ChunkPos(this.blockPosition());
            level.getChunkSource().addRegionTicket(TicketType.PORTAL, chunk, 3, chunk.getWorldPosition());
        }

        if (!this.teleportCooldowns.isEmpty()) {
            Iterator<Map.Entry<UUID, Integer>> it = this.teleportCooldowns.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Integer> e = it.next();
                int left = e.getValue() - 1;
                if (left <= 0) it.remove(); else e.setValue(left);
            }
        }

        if (isClosing()) {
            if (--this.closingTimer <= 0) this.discard();
            return;
        }

        if (--this.lifetime <= 0) {
            PortalManager.removePortal(this, getGunMode() == PortalMode.POINT);
            return;
        }

        double rxz = Math.max(3.5, 2.5 * getScale());
        double ry = Math.max(3.5, 2.5 * getScale());
        AABB box = new AABB(getX() - rxz, getY() - ry, getZ() - rxz, getX() + rxz, getY() + ry, getZ() + rxz);
        List<Entity> colliding = level.getEntities(this, box, this::isEntityIntersectingPortal);
        if (getScale() <= 0.5F) colliding = filterSmallEntities(colliding);

        for (Entity entity : colliding) {
            if (isClosing()) break;
            entity.resetFallDistance();
            handleEntityTeleport(entity);
        }
    }

    public void handleEntityTeleport(Entity entity) {
        if (entity.isPassenger() || entity.isVehicle()) return;
        if (!(this.level() instanceof ServerLevel)) return;
        PortalEntity exit = PortalManager.findPartner(this);
        if (exit != null && !exit.isRemoved()) {
            PortalTeleportEngine.teleportEntity(this, exit, entity);
        }
    }

    /** Пересекает ли сущность плоскость портала (в т.ч. «перелёт» между тиками). */
    private boolean isEntityIntersectingPortal(Entity entity) {
        // Сгусток пушки тоже проходит сквозь портал (как в оригинале) и открывает портал уже по ту сторону.
        if (entity == null || entity.isRemoved() || entity instanceof PortalEntity
                || hasTeleportCooldown(entity.getUUID())) {
            return false;
        }
        AABB eBox = entity.getBoundingBox();
        float scale = getScale();
        int orientation = getOrientation();

        if (orientation == ORIENTATION_WALL) {
            float rad = (float) Math.toRadians(getYRot());
            double nx = -Math.sin(rad);
            double nz = Math.cos(rad);
            double tx = Math.cos(rad);
            double tz = Math.sin(rad);
            double cx = (eBox.minX + eBox.maxX) * 0.5 - getX();
            double cz = (eBox.minZ + eBox.maxZ) * 0.5 - getZ();
            double normalDist = Math.abs(cx * nx + cz * nz);
            double tangentDist = Math.abs(cx * tx + cz * tz);
            double halfWidth = 0.65 * scale;
            double halfHeight = 1.05 * scale;
            double entityRadius = Math.max(eBox.getXsize(), eBox.getZsize()) * 0.5;
            double triggerThickness = entityRadius + 0.12 * scale;
            boolean inY = eBox.minY <= getY() + halfHeight && eBox.maxY >= getY() - halfHeight;
            if (inY && normalDist <= triggerThickness && tangentDist <= halfWidth && eBox.intersects(getBoundingBox())) {
                return true;
            }
            double prevNormDist = (entity.xo - getX()) * nx + (entity.zo - getZ()) * nz;
            double currNormDist = cx * nx + cz * nz;
            if (prevNormDist * currNormDist <= 0.0 || Math.abs(currNormDist) <= 0.35 * scale) {
                double denom = prevNormDist - currNormDist;
                double t = Math.abs(denom) > 1.0E-4 ? Math.max(0.0, Math.min(1.0, prevNormDist / denom)) : 0.5;
                double crossX = entity.xo + (entity.getX() - entity.xo) * t - getX();
                double crossY = entity.yo + (entity.getY() - entity.yo) * t + entity.getBbHeight() * 0.5 - getY();
                double crossZ = entity.zo + (entity.getZ() - entity.zo) * t - getZ();
                double crossTangent = Math.abs(crossX * tx + crossZ * tz);
                return crossTangent <= halfWidth + entityRadius
                        && Math.abs(crossY) <= halfHeight + entity.getBbHeight() * 0.5;
            }
            return false;
        }

        double cx = (eBox.minX + eBox.maxX) * 0.5 - getX();
        double cz = (eBox.minZ + eBox.maxZ) * 0.5 - getZ();
        double radiusSq = cx * cx + cz * cz;
        double maxRadius = 0.55 * scale;
        boolean inRadius = radiusSq <= maxRadius * maxRadius;
        if (orientation == ORIENTATION_FLOOR) {
            boolean inY = eBox.minY <= getY() + 0.35 * scale && eBox.maxY >= getY() - 0.35 * scale;
            if (inY && inRadius && eBox.intersects(getBoundingBox())) return true;
            double prev = entity.yo - getY();
            double curr = entity.getY() - getY();
            return (prev * curr <= 0.0 || Math.abs(curr) <= 0.4 * scale) && inRadius;
        }
        boolean inY = eBox.maxY >= getY() - 0.35 * scale && eBox.minY <= getY() + 0.35 * scale;
        if (inY && inRadius && eBox.intersects(getBoundingBox())) return true;
        double prev = entity.yo + entity.getBbHeight() - getY();
        double curr = entity.getY() + entity.getBbHeight() - getY();
        return (prev * curr <= 0.0 || Math.abs(curr) <= 0.4 * scale) && inRadius;
    }

    /** Маленький портал пропускает только мелочь (оригинал: масштаб ≤ 0.5). */
    private static List<Entity> filterSmallEntities(List<Entity> entities) {
        List<Entity> filtered = new ArrayList<>();
        for (Entity e : entities) {
            if (e instanceof ItemEntity || e instanceof Projectile || e instanceof Player
                    || e instanceof AbstractMinecart || e instanceof Boat || e instanceof PrimedTnt
                    || e instanceof WaterAnimal || (e instanceof LivingEntity living && living.isBaby())) {
                filtered.add(e);
            }
        }
        return filtered;
    }

    public void startClosing() {
        if (isClosing()) return;
        this.entityData.set(DATA_CLOSING, true);
        this.closingTimer = CLOSE_DURATION;
        this.clientClosingTimer = CLOSE_DURATION;
    }

    // ================= частицы (клиент) =================

    private void spawnClientParticles() {
        int color = getColor();
        float scale = getScale();
        int orientation = getOrientation();
        if (this.tickCount == 1) {
            this.level().addParticle(PortalGunRegistry.vortexBeam(color), getX(), getY(), getZ(), 0.0, 0.0, 0.0);
        }
        var spark = PortalGunRegistry.spark(color);
        for (int i = 0; i < 2; ++i) {
            double angle = this.random.nextDouble() * Math.PI * 2.0;
            double rx = Math.cos(angle) * 0.85 * scale;
            double ry = Math.sin(angle) * (orientation == ORIENTATION_WALL ? 0.95 * scale : 0.85 * scale);
            double px = getX(), py = getY(), pz = getZ();
            if (orientation == ORIENTATION_WALL) {
                float rad = (float) Math.toRadians(getYRot());
                px += rx * Math.cos(rad);
                pz += rx * Math.sin(rad);
                py += ry;
            } else {
                px += rx;
                pz += ry;
            }
            this.level().addParticle(spark, px, py, pz,
                    (this.random.nextDouble() - 0.5) * 0.02,
                    (this.random.nextDouble() - 0.5) * 0.02,
                    (this.random.nextDouble() - 0.5) * 0.02);
        }
    }

    private void spawnCollapseParticles() {
        int color = getColor();
        int orientation = getOrientation();
        Vec3 normal = PortalTeleportEngine.getPortalNormal(orientation, getYRot());
        double cx = getX(), cy = getY(), cz = getZ();
        int dropletCount = 6 + this.random.nextInt(5);
        var droplet = PortalGunRegistry.droplet(color);
        for (int i = 0; i < dropletCount; ++i) {
            double speed = 0.14 + this.random.nextDouble() * 0.18;
            double vx = normal.x * speed + (this.random.nextDouble() - 0.5) * 0.08;
            double vy = normal.y * speed + (this.random.nextDouble() - 0.5) * 0.08 + (orientation == ORIENTATION_WALL ? 0.04 : 0.0);
            double vz = normal.z * speed + (this.random.nextDouble() - 0.5) * 0.08;
            this.level().addParticle(droplet, cx + normal.x * 0.05, cy + normal.y * 0.05, cz + normal.z * 0.05, vx, vy, vz);
        }
        for (int i = 0; i < 3; ++i) {
            this.level().addParticle(PortalGunRegistry.FLUID_EVAPORATION.get(),
                    cx + (this.random.nextDouble() - 0.5) * 0.1,
                    cy + (this.random.nextDouble() - 0.5) * 0.1,
                    cz + (this.random.nextDouble() - 0.5) * 0.1,
                    normal.x * 0.05 + (this.random.nextDouble() - 0.5) * 0.03,
                    normal.y * 0.05 + 0.03,
                    normal.z * 0.05 + (this.random.nextDouble() - 0.5) * 0.03);
        }
        var spark = PortalGunRegistry.spark(color);
        for (int i = 0; i < 2; ++i) {
            this.level().addParticle(spark, cx, cy, cz,
                    normal.x * 0.1 + (this.random.nextDouble() - 0.5) * 0.05,
                    normal.y * 0.1 + (this.random.nextDouble() - 0.5) * 0.05,
                    normal.z * 0.1 + (this.random.nextDouble() - 0.5) * 0.05);
        }
    }

    // ================= сохранение =================

    @Override
    protected void addAdditionalSaveData(@NotNull CompoundTag tag) {
        tag.putInt("Orientation", getOrientation());
        tag.putInt("PortalRotation", getRotation());
        tag.putFloat("PortalYaw", getYRot());
        tag.putFloat("Scale", getScale());
        tag.putInt("Color", getColor());
        tag.putBoolean("IsLinked", isLinked());
        getDualityPortalId().ifPresent(id -> tag.putUUID("DualityUUID", id));
        if (dualityDimension != null) tag.putString("DualityDim", dualityDimension.location().toString());
        tag.putBoolean("IsRoot", isRoot());
        tag.putInt("OwnerGunId", getOwnerGunId());
        tag.putString("GunMode", getGunMode().id());
        tag.putBoolean("Closing", isClosing());
        tag.putInt("PassesLeft", getPassesLeft());
        tag.putInt("Lifetime", lifetime);
    }

    @Override
    protected void readAdditionalSaveData(@NotNull CompoundTag tag) {
        if (!tag.contains("Orientation")) {
            // Сохранение портала старой пушки (TargetDim / Partner / Passes).
            this.legacy = tag.contains("TargetDim");
            return;
        }
        setOrientation(tag.getInt("Orientation"));
        setRotation(tag.getInt("PortalRotation"));
        float yaw = tag.getFloat("PortalYaw");
        setYRot(yaw);
        this.yRotO = yaw;
        setScale(tag.getFloat("Scale"));
        setColor(tag.getInt("Color"));
        setLinked(tag.getBoolean("IsLinked"));
        ResourceKey<Level> dim = null;
        if (tag.contains("DualityDim")) {
            ResourceLocation loc = ResourceLocation.tryParse(tag.getString("DualityDim"));
            if (loc != null) dim = ResourceKey.create(Registries.DIMENSION, loc);
        }
        setDuality(tag.hasUUID("DualityUUID") ? tag.getUUID("DualityUUID") : null, dim);
        setRoot(tag.getBoolean("IsRoot"));
        setOwnerGunId(tag.getInt("OwnerGunId"));
        setGunMode(PortalMode.byId(tag.getString("GunMode")));
        setPassesLeft(tag.contains("PassesLeft") ? tag.getInt("PassesLeft") : UNLIMITED_PASSES);
        if (tag.contains("Lifetime")) this.lifetime = tag.getInt("Lifetime");
        if (tag.getBoolean("Closing")) {
            this.entityData.set(DATA_CLOSING, true);
            this.closingTimer = 1;
        }
    }
}
