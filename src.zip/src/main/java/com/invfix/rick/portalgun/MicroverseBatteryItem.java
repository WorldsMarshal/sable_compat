package com.invfix.rick.portalgun;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/** Микровселенский аккумулятор — порт MicroverseBatteryItem из Rick's stuff 0.0.4.3 (материал с подсказкой). */
public class MicroverseBatteryItem extends Item {

    public MicroverseBatteryItem(Properties properties) {
        super(properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.sable_compat.microverse_battery.desc").withStyle(ChatFormatting.GRAY));
    }
}
