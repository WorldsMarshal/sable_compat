package com.invfix.rick.portalgun.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/** Порт PlasmaShockwaveParticle из Rick's stuff 0.0.4.3 (зелёный и жёлтый варианты). */
@OnlyIn(Dist.CLIENT)
public class PlasmaShockwaveParticle extends TextureSheetParticle {
   private final SpriteSet sprites;
   private final float baseSize;

   public PlasmaShockwaveParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, float r, float g, float b, SpriteSet sprites) {
      this(level, x, y, z, vx, vy, vz, r, g, b, 0.35F, 8, sprites);
   }

   public PlasmaShockwaveParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, float r, float g, float b, float customBaseSize, int customLifetime, SpriteSet sprites) {
      super(level, x, y, z, vx, vy, vz);
      this.sprites = sprites;
      this.rCol = r;
      this.gCol = g;
      this.bCol = b;
      this.xd = vx * 0.1;
      this.yd = vy * 0.1;
      this.zd = vz * 0.1;
      this.lifetime = customLifetime;
      this.baseSize = customBaseSize;
      this.quadSize = this.baseSize;
      this.hasPhysics = false;
      this.setSpriteFromAge(sprites);
   }

   @Override
   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @Override
   public int getLightColor(float partialTick) {
      return 15728880;
   }

   @Override
   public void tick() {
      this.xo = this.x;
      this.yo = this.y;
      this.zo = this.z;
      if (this.age++ >= this.lifetime) {
         this.remove();
      } else {
         this.setSpriteFromAge(this.sprites);
         float progress = (float)this.age / (float)this.lifetime;
         this.quadSize = this.baseSize * (1.0F + progress * 4.0F);
         this.alpha = (float)Math.sin((double)(1.0F - progress) * Math.PI * 0.5);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class YellowProvider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public YellowProvider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      @Override
      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new PlasmaShockwaveParticle(level, x, y, z, vx, vy, vz, 1.0F, 0.9F, 0.1F, this.sprites);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class GreenProvider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public GreenProvider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      @Override
      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new PlasmaShockwaveParticle(level, x, y, z, vx, vy, vz, 0.15F, 1.0F, 0.15F, this.sprites);
      }
   }
}
