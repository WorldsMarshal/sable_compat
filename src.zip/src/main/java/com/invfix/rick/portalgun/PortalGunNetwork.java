package com.invfix.rick.portalgun;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Пакеты портальных пушек. Клиентские приёмники — через ClientPacketHandlers и
 * только на клиенте (схема HeatVisionRegistration): на выделенном сервере
 * клиентские классы не трогаются.
 */
@EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD)
public final class PortalGunNetwork {

    private static final boolean CLIENT = FMLEnvironment.dist == Dist.CLIENT;

    private PortalGunNetwork() {}

    @SubscribeEvent
    public static void onRegisterPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("sable_compat");

        registrar.playToServer(PortalGunConfigPacket.TYPE, PortalGunConfigPacket.STREAM_CODEC,
                PortalGunConfigPacket::handle);
        registrar.playToServer(PortalGunActionPacket.TYPE, PortalGunActionPacket.STREAM_CODEC,
                PortalGunActionPacket::handle);

        registrar.playToClient(PortalRecoilPacket.TYPE, PortalRecoilPacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) com.invfix.network.ClientPacketHandlers.portalRecoil(pkt, ctx); });
        registrar.playToClient(PortalFlashPacket.TYPE, PortalFlashPacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) com.invfix.network.ClientPacketHandlers.portalFlash(pkt, ctx); });
    }
}
