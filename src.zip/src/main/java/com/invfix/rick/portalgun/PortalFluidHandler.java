package com.invfix.rick.portalgun;

import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandlerItem;
import org.jetbrains.annotations.NotNull;

/**
 * Бак портальной пушки поверх компонента предмета.
 *
 * Реализован как IFluidHandlerItem, поэтому пушка заправляется чем угодно, что
 * умеет лить жидкость в предмет — в том числе нижним слотом бака в панели Рика.
 * Принимает ТОЛЬКО портальную жидкость: залить туда воду и получить бесплатные
 * порталы не выйдет.
 */
public class PortalFluidHandler implements IFluidHandlerItem {

    private final ItemStack stack;

    public PortalFluidHandler(ItemStack stack) {
        this.stack = stack;
    }

    private int stored() {
        Integer value = stack.get(PortalGunRegistry.FUEL.get());
        if (value == null) return 0;
        return Math.max(0, Math.min(value, PortalGunItem.CAPACITY));
    }

    private void store(int amount) {
        stack.set(PortalGunRegistry.FUEL.get(),
                Math.max(0, Math.min(amount, PortalGunItem.CAPACITY)));
    }

    @Override public @NotNull ItemStack getContainer() { return this.stack; }

    @Override public int getTanks() { return 1; }

    @Override public @NotNull FluidStack getFluidInTank(int tank) {
        int amount = stored();
        return amount <= 0 ? FluidStack.EMPTY
                : new FluidStack(PortalGunRegistry.PORTAL_FLUID_SOURCE.get(), amount);
    }

    @Override public int getTankCapacity(int tank) { return PortalGunItem.CAPACITY; }

    @Override public boolean isFluidValid(int tank, @NotNull FluidStack fluid) {
        return fluid.getFluid() == PortalGunRegistry.PORTAL_FLUID_SOURCE.get();
    }

    @Override
    public int fill(FluidStack resource, FluidAction action) {
        if (resource.isEmpty() || !isFluidValid(0, resource)) return 0;
        int room = PortalGunItem.CAPACITY - stored();
        int accepted = Math.min(room, resource.getAmount());
        if (accepted > 0 && action.execute()) store(stored() + accepted);
        return accepted;
    }

    @Override
    public @NotNull FluidStack drain(FluidStack resource, FluidAction action) {
        if (resource.isEmpty() || !isFluidValid(0, resource)) return FluidStack.EMPTY;
        return drain(resource.getAmount(), action);
    }

    @Override
    public @NotNull FluidStack drain(int maxDrain, FluidAction action) {
        int taken = Math.min(maxDrain, stored());
        if (taken <= 0) return FluidStack.EMPTY;
        if (action.execute()) store(stored() - taken);
        return new FluidStack(PortalGunRegistry.PORTAL_FLUID_SOURCE.get(), taken);
    }
}
