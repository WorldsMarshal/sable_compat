package com.invfix.rick.portalgun.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/** Порт FluidDropletParticle из Rick's stuff 0.0.4.3 (зелёный и жёлтый варианты). */
@OnlyIn(Dist.CLIENT)
public class FluidDropletParticle extends TextureSheetParticle {
   protected final SpriteSet sprites;
   protected final float baseSize;

   public FluidDropletParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, float r, float g, float b, SpriteSet sprites) {
      super(level, x, y, z, vx, vy, vz);
      this.sprites = sprites;
      this.rCol = r;
      this.gCol = g;
      this.bCol = b;
      this.xd = vx + (Math.random() - 0.5) * 0.08;
      this.yd = vy + Math.random() * 0.05;
      this.zd = vz + (Math.random() - 0.5) * 0.08;
      this.gravity = 0.45F;
      this.lifetime = (int)(14.0 + Math.random() * 8.0);
      this.baseSize = 0.095F + (float)(Math.random() * 0.02500000037252903);
      this.quadSize = this.baseSize;
      this.setSpriteFromAge(sprites);
   }

   @Override
   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @Override
   public int getLightColor(float partialTick) {
      return 15728880;
   }

   @Override
   public void tick() {
      this.xo = this.x;
      this.yo = this.y;
      this.zo = this.z;
      if (this.age++ >= this.lifetime) {
         this.remove();
      } else {
         this.setSpriteFromAge(this.sprites);
         this.yd -= 0.04 * (double)this.gravity;
         this.move(this.xd, this.yd, this.zd);
         this.xd *= 0.96;
         this.yd *= 0.96;
         this.zd *= 0.96;
         if (this.onGround) {
            this.xd *= 0.7;
            this.zd *= 0.7;
         }

         float progress = (float)this.age / (float)this.lifetime;
         this.quadSize = this.baseSize * Math.max(0.0F, 1.0F - progress);
         this.alpha = Math.max(0.0F, 1.0F - progress * progress);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class YellowProvider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public YellowProvider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      @Override
      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new FluidDropletParticle(level, x, y, z, vx, vy, vz, 1.0F, 0.85F, 0.0F, this.sprites);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class GreenProvider implements ParticleProvider<SimpleParticleType> {
      private final SpriteSet sprites;

      public GreenProvider(SpriteSet sprites) {
         this.sprites = sprites;
      }

      @Override
      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
         return new FluidDropletParticle(level, x, y, z, vx, vy, vz, 0.5F, 1.0F, 0.05F, this.sprites);
      }
   }
}
