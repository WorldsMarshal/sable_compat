package com.invfix.rick.portalgun;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.List;
import java.util.function.Consumer;

/**
 * Портальная пушка — Рика и Злого Морти (один класс, разный цвет).
 *
 * Механика выстрела — порт PortalGunItem из Rick's stuff 0.0.4.3:
 *  - ПКМ — выстрел сгустком жидкости (3.2 блока/тик + скорость стрелка, без
 *    гравитации); попадание в блок открывает портал на стене, полу или потолке;
 *  - ПКМ ещё раз, пока сгусток летит, — портал открывается прямо в воздухе;
 *  - отдача в руке и у других игроков, звук выстрела, «пусто» без заряда;
 *  - Shift+ПКМ — панель управления; Shift+колесо или клавиша — режим;
 *    клавиша R — закрыть все порталы пушки; ЛКМ пушкой по порталу закрывает
 *    его (с Shift — вместе с парой).
 *
 * Заряд — наша портальная жидкость в mB, как и была: бак 1000 mB, 10 mB за
 * выстрел (у оригинала 2% колбы за выстрел). Режим POINT открывает пару
 * «попадание ↔ точка» одним выстрелом, остальные режимы — по порталу на выстрел.
 *
 * Модель и отрисовка — порт PortalGunItemRenderer (см. клиентскую часть).
 */
public class PortalGunItem extends Item {

    public static final int COLOR_GREEN = 0;
    public static final int COLOR_YELLOW = 2;

    /** Масштаб портала по умолчанию в оригинале (Scale = 2.0). */
    public static final float PORTAL_SCALE = 2.0F;

    /** Бак пушки. */
    public static final int CAPACITY = 1000;
    /** Расход за выстрел. */
    public static final int COST_PER_SHOT = 10;
    /** Скорость сгустка (velocity 3.2F оригинала). */
    public static final float PROJECTILE_SPEED = 3.2F;

    private final int color;

    public PortalGunItem(Properties props, int color) {
        super(props);
        this.color = color;
    }

    public int portalColor() { return color; }

    public boolean isEvil() { return color == COLOR_YELLOW; }

    public static int fuel(ItemStack stack) {
        Integer value = stack.get(PortalGunRegistry.FUEL.get());
        return value == null ? 0 : Math.max(0, Math.min(value, CAPACITY));
    }

    /** Заряд в процентах — для колбы в модели и шкалы в интерфейсе. */
    public static int chargePercent(ItemStack stack) {
        return Math.round(100.0F * fuel(stack) / CAPACITY);
    }

    public static PortalGunData data(ItemStack stack) {
        PortalGunData d = stack.get(PortalGunRegistry.GUN_DATA.get());
        return (d == null ? PortalGunData.DEFAULT : d).sanitized();
    }

    public static PortalMode mode(ItemStack stack) {
        return data(stack).portalMode();
    }

    public static int gunId(ItemStack stack) {
        Integer id = stack.get(PortalGunRegistry.GUN_ID.get());
        return id == null ? 0 : id;
    }

    /** Номер пушки; выдаётся при первом выстреле. */
    private static int ensureGunId(ItemStack stack, Level level) {
        int id = gunId(stack);
        if (id != 0) return id;
        id = 1 + level.random.nextInt(999_999);
        stack.set(PortalGunRegistry.GUN_ID.get(), id);
        return id;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (player.isShiftKeyDown()) {
            if (level.isClientSide) PortalGunClientHook.openSettings(hand);
            player.playSound(PortalGunRegistry.SOUND_MENU_OPEN.get(), 1.0F, 1.0F);
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }

        // Повторное нажатие, пока сгусток в полёте, — портал в воздухе. Сгусток ищется
        // на обеих сторонах (как в оригинале), чтобы клиент не проигрывал выстрел.
        PortalProjectileEntity active = PortalManager.getActiveProjectile(player);
        if (active != null) {
            if (level instanceof ServerLevel serverLevel) {
                PortalManager.handleAirPortalSpawn(serverLevel, active.position(), active);
            }
            player.getCooldowns().addCooldown(this, 6);
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }

        if (player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.pass(stack);

        boolean creative = player.getAbilities().instabuild;
        if (!creative && fuel(stack) < COST_PER_SHOT) {
            player.playSound(PortalGunRegistry.SOUND_GUN_EMPTY.get(), 1.0F, 1.0F);
            if (!level.isClientSide) {
                player.displayClientMessage(Component.translatable("message.sable_compat.portal_gun.no_fuel")
                        .withStyle(ChatFormatting.RED), true);
            }
            return InteractionResultHolder.fail(stack);
        }

        PortalGunData data = data(stack);
        PortalMode mode = data.portalMode();
        if (mode == PortalMode.POINT && !data.active().isSet()) {
            if (!level.isClientSide) {
                player.displayClientMessage(Component.translatable("message.sable_compat.portal_gun.no_point")
                        .withStyle(ChatFormatting.RED), true);
            }
            player.playSound(PortalGunRegistry.SOUND_GUN_EMPTY.get(), 1.0F, 1.0F);
            return InteractionResultHolder.fail(stack);
        }

        player.playSound(PortalGunRegistry.SOUND_GUN_FIRE.get(), 1.0F, 1.0F);
        byte handByte = (byte) (hand == InteractionHand.MAIN_HAND ? 0 : 1);

        if (level.isClientSide) {
            PortalGunClientHook.recoil(player.getId(), handByte);
        } else if (level instanceof ServerLevel serverLevel) {
            if (!creative) stack.set(PortalGunRegistry.FUEL.get(), fuel(stack) - COST_PER_SHOT);

            PacketDistributor.sendToPlayersNear(serverLevel, player instanceof ServerPlayer sp ? sp : null,
                    player.getX(), player.getY(), player.getZ(), 64.0,
                    new PortalRecoilPacket(player.getId(), handByte));

            Vec3 look = player.getLookAngle();
            PortalProjectileEntity projectile = new PortalProjectileEntity(serverLevel, player);
            projectile.setPos(player.getX() + look.x * 0.75,
                    player.getEyeY() - 0.15 + look.y * 0.75,
                    player.getZ() + look.z * 0.75);
            projectile.setColor(color);
            projectile.configure(ensureGunId(stack, level), mode, data.passLimit(),
                    mode == PortalMode.POINT ? data.active() : null, data.airDistance());
            projectile.setDeltaMovement(look.scale(PROJECTILE_SPEED).add(player.getDeltaMovement()));
            serverLevel.addFreshEntity(projectile);
            PortalManager.registerProjectile(player, projectile);
        }

        player.getCooldowns().addCooldown(this, 3);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /** Смена заряда и данных не должна дёргать пушку в руке (оригинал). */
    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    @Override
    public boolean isBarVisible(ItemStack stack) { return fuel(stack) < CAPACITY; }

    @Override
    public int getBarWidth(ItemStack stack) {
        return Math.round(13.0F * fuel(stack) / CAPACITY);
    }

    /** Цвет шкалы — как у оригинала: зелёный, оранжевый ниже 25%, красный ниже 10%. */
    @Override
    public int getBarColor(ItemStack stack) {
        int pct = chargePercent(stack);
        if (pct > 25) return isEvil() ? 0xFFD219 : 0x00FF66;
        return pct > 10 ? 0xFFA500 : 0xFF2222;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> lines, TooltipFlag flag) {
        PortalGunData data = data(stack);
        lines.add(Component.translatable("tooltip.sable_compat.portal_gun.fuel",
                fuel(stack), CAPACITY).withStyle(isEvil() ? ChatFormatting.YELLOW : ChatFormatting.GREEN));
        lines.add(Component.translatable("tooltip.sable_compat.portal_gun.mode",
                Component.translatable(data.portalMode().translationKey())).withStyle(ChatFormatting.AQUA));

        if (data.portalMode() == PortalMode.POINT) {
            PortalPoint point = data.active();
            if (point.isSet()) {
                lines.add(Component.translatable("tooltip.sable_compat.portal_gun.target",
                        point.display(), point.dimension().getPath()).withStyle(ChatFormatting.AQUA));
            } else {
                lines.add(Component.translatable("tooltip.sable_compat.portal_gun.target_none")
                        .withStyle(ChatFormatting.GRAY));
            }
        }
        lines.add(Component.translatable("tooltip.sable_compat.portal_gun.passes",
                data.passLimit()).withStyle(ChatFormatting.DARK_AQUA));
        lines.add(data.airDistance() > 0
                ? Component.translatable("tooltip.sable_compat.portal_gun.air_distance", data.airDistance())
                        .withStyle(ChatFormatting.DARK_AQUA)
                : Component.translatable("tooltip.sable_compat.portal_gun.air_distance_off")
                        .withStyle(ChatFormatting.DARK_GRAY));
        lines.add(Component.translatable("tooltip.sable_compat.portal_gun.hint")
                .withStyle(ChatFormatting.DARK_GRAY));
        lines.add(Component.translatable("tooltip.sable_compat.portal_gun.hint_keys")
                .withStyle(ChatFormatting.DARK_GRAY));
    }

    /**
     * Отрисовка через BEWLR и поза «держит арбалет» (оригинал). Метод зовётся
     * только на клиенте, клиентские классы внутри него на сервере не грузятся.
     */
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(com.invfix.rick.portalgun.client.PortalGunItemExtensions.GUN);
    }
}
