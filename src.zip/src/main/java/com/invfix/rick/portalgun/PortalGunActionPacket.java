package com.invfix.rick.portalgun;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * C2S: действия с клавиш и из панели — закрыть все порталы пушки и сменить
 * режим (C2SCloseAllPortalsPacket / C2SSelectModePacket оригинала).
 *
 * Сервер берёт пушку из руки игрока, а не из пакета; для «закрыть все» —
 * первую пушку в инвентаре, как в оригинале (клавиша R работает, даже если
 * пушка не в руке).
 */
public record PortalGunActionPacket(int action, String mode) implements CustomPacketPayload {

    public static final int CLOSE_ALL = 0;
    public static final int SET_MODE = 1;

    public static final Type<PortalGunActionPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "portal_gun_action"));

    public static final StreamCodec<FriendlyByteBuf, PortalGunActionPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, p) -> { buf.writeVarInt(p.action()); buf.writeUtf(p.mode(), 32); },
                    buf -> new PortalGunActionPacket(buf.readVarInt(), buf.readUtf(32)));

    public static PortalGunActionPacket closeAll() { return new PortalGunActionPacket(CLOSE_ALL, ""); }

    public static PortalGunActionPacket setMode(PortalMode mode) { return new PortalGunActionPacket(SET_MODE, mode.id()); }

    @Override
    public Type<PortalGunActionPacket> type() { return TYPE; }

    public static void handle(PortalGunActionPacket packet, IPayloadContext context) {
        context.enqueueWork(() -> {
            Player player = context.player();
            if (player == null || !(player.level() instanceof ServerLevel level)) return;

            if (packet.action() == CLOSE_ALL) {
                ItemStack gun = findGun(player);
                int id = gun.isEmpty() ? 0 : PortalGunItem.gunId(gun);
                if (id != 0) PortalManager.removeAllPortalsForGun(level.getServer(), id, null);
                return;
            }
            if (packet.action() == SET_MODE) {
                for (InteractionHand hand : InteractionHand.values()) {
                    ItemStack stack = player.getItemInHand(hand);
                    if (stack.getItem() instanceof PortalGunItem) {
                        stack.set(PortalGunRegistry.GUN_DATA.get(),
                                PortalGunItem.data(stack).withMode(PortalMode.byId(packet.mode())));
                        return;
                    }
                }
            }
        });
    }

    private static ItemStack findGun(Player player) {
        for (InteractionHand hand : InteractionHand.values()) {
            ItemStack s = player.getItemInHand(hand);
            if (s.getItem() instanceof PortalGunItem) return s;
        }
        for (ItemStack s : player.getInventory().items) {
            if (s.getItem() instanceof PortalGunItem) return s;
        }
        return ItemStack.EMPTY;
    }
}
