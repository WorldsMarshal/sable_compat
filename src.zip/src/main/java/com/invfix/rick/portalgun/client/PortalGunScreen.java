package com.invfix.rick.portalgun.client;

import com.invfix.rick.portalgun.PortalGunActionPacket;
import com.invfix.rick.portalgun.PortalGunConfigPacket;
import com.invfix.rick.portalgun.PortalGunData;
import com.invfix.rick.portalgun.PortalGunItem;
import com.invfix.rick.portalgun.PortalGunRegistry;
import com.invfix.rick.portalgun.PortalMode;
import com.invfix.rick.portalgun.PortalPoint;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

/**
 * Панель управления портальной пушкой.
 *
 * Оформление — как у панелей Rick's stuff 0.0.4.3 (PortalGunScreen /
 * SetCoordinatesScreen): металлический корпус с заклёпками, шапка с иконкой,
 * «терминал» со шкалой жидкости, режимом, номером устройства и целью,
 * кнопки GadgetButton со светодиодом. Содержимое — наше: пять сохраняемых
 * точек, редактор выбранной (подпись, координаты, измерение), лимит проходов,
 * режим, «закрыть все порталы».
 *
 * Координаты и измерение вводятся вручную — смысл пушки в том, чтобы попасть
 * туда, где ты не был. Измерение — строкой вида minecraft:the_nether; кнопка ↻
 * листает измерения, известные подключению.
 */
@OnlyIn(Dist.CLIENT)
public class PortalGunScreen extends Screen {

    private static final int PANEL_W = 340;
    private static final int PANEL_H = 236;
    private static final int PAD = 12;
    private static final int ROW_H = 20;
    private static final int LIST_W = 130;

    private static final int TEXT_MUTED = 0xFF8A909C;
    private static final int TEXT_PHOSPHOR = 0xFF3DE665;
    private static final int TEXT_CYAN = 0xFF36D7E8;
    private static final int TEXT_AMBER = 0xFFFFB326;

    private final InteractionHand hand;
    private final ItemStack gunStack;
    private final List<PortalPoint> points = new ArrayList<>();

    private EditBox labelBox, xBox, yBox, zBox, dimBox, airBox;
    private GadgetButton passesButton;
    private int airRowY, airLabelX;

    private int selected;
    private int passLimit;
    private int airDistance;
    private PortalMode mode;
    private int left, top;

    public PortalGunScreen(InteractionHand hand, ItemStack stack) {
        super(Component.translatable("screen.sable_compat.portal_gun"));
        this.hand = hand;
        this.gunStack = stack;
        PortalGunData data = PortalGunItem.data(stack);
        this.points.addAll(data.points());
        this.selected = data.selected();
        this.passLimit = data.passLimit();
        this.airDistance = data.airDistance();
        this.mode = data.portalMode();
    }

    @Override
    protected void init() {
        this.left = (this.width - PANEL_W) / 2;
        this.top = (this.height - PANEL_H) / 2;

        int listX = left + PAD;
        int listTop = top + 84;
        for (int i = 0; i < PortalGunData.MAX_POINTS; i++) {
            final int index = i;
            PortalPoint p = points.get(i);
            String name = p.isSet() ? p.display() : I18n.get("screen.sable_compat.portal_gun.empty");
            addRenderableWidget(GadgetButton.gadget(Component.literal(trim((i + 1) + ". " + name, LIST_W - 20)),
                            b -> { click(); commit(); selected = index; rebuild(); })
                    .bounds(listX, listTop + i * ROW_H, LIST_W, 18)
                    .style(index == selected ? GadgetButton.Style.PRIMARY : GadgetButton.Style.NORMAL)
                    .build());
        }

        int editX = listX + LIST_W + 10;
        int editW = left + PANEL_W - PAD - editX;
        int y = listTop;
        labelBox = box(editX, y, editW, points.get(selected).label(), "screen.sable_compat.portal_gun.label");
        y += ROW_H;

        int third = (editW - 8) / 3;
        BlockPos pos = points.get(selected).pos();
        xBox = box(editX, y, third, Integer.toString(pos.getX()), "screen.sable_compat.portal_gun.x");
        yBox = box(editX + third + 4, y, third, Integer.toString(pos.getY()), "screen.sable_compat.portal_gun.y");
        zBox = box(editX + (third + 4) * 2, y, third, Integer.toString(pos.getZ()), "screen.sable_compat.portal_gun.z");
        y += ROW_H;

        dimBox = box(editX, y, editW - 24, points.get(selected).dimension().toString(),
                "screen.sable_compat.portal_gun.dimension");
        addRenderableWidget(GadgetButton.gadget(Component.literal("↻"), b -> { click(); cycleDimension(); })
                .bounds(editX + editW - 20, y, 20, 18).build());
        y += ROW_H + 2;

        int halfW = (editW - 4) / 2;
        addRenderableWidget(GadgetButton.gadget(Component.translatable("screen.sable_compat.portal_gun.here"),
                        b -> { click(); fillFromPlayer(); })
                .bounds(editX, y, halfW, 18).build());
        addRenderableWidget(GadgetButton.gadget(Component.translatable("screen.sable_compat.portal_gun.clear"),
                        b -> { click(); points.set(selected, PortalPoint.EMPTY); rebuild(); })
                .bounds(editX + halfW + 4, y, halfW, 18).style(GadgetButton.Style.DANGER).build());
        y += ROW_H + 2;

        // Подрыв в воздухе: через сколько блоков без попадания открыть портал (0 — выкл.).
        int airW = 44;
        airRowY = y;
        airLabelX = editX;
        airBox = new EditBox(this.font, editX + editW - airW, y, airW, 18,
                Component.translatable("screen.sable_compat.portal_gun.air_distance"));
        airBox.setMaxLength(3);
        airBox.setFilter(s -> s.isEmpty() || s.chars().allMatch(Character::isDigit));
        airBox.setValue(Integer.toString(airDistance));
        airBox.setResponder(s -> airDistance = clampAir(parse(s, 0)));
        addRenderableWidget(airBox);

        int bottom = top + PANEL_H - PAD - 18;
        int quarter = (PANEL_W - PAD * 2 - 12) / 4;
        int bx = left + PAD;
        addRenderableWidget(GadgetButton.gadget(
                        Component.translatable("screen.sable_compat.portal_gun.mode",
                                Component.translatable(mode.translationKey())),
                        b -> { click(); commit(); mode = mode.next(); rebuild(); })
                .bounds(bx, bottom, quarter, 18).build());
        bx += quarter + 4;
        // ЛКМ — больше, ПКМ — меньше (по кругу в обе стороны).
        passesButton = addRenderableWidget(GadgetButton.gadget(
                        Component.translatable("screen.sable_compat.portal_gun.passes", passLimit),
                        b -> { click(); commit(); stepPasses(1); rebuild(); })
                .bounds(bx, bottom, quarter, 18).build());
        bx += quarter + 4;
        addRenderableWidget(GadgetButton.gadget(Component.translatable("screen.sable_compat.portal_gun.close_all"),
                        b -> { click(); PacketDistributor.sendToServer(PortalGunActionPacket.closeAll()); })
                .bounds(bx, bottom, quarter, 18).style(GadgetButton.Style.DANGER).build());
        bx += quarter + 4;
        addRenderableWidget(GadgetButton.gadget(Component.translatable("screen.sable_compat.portal_gun.apply"),
                        b -> { click(); commit(); apply(); onClose(); })
                .bounds(bx, bottom, quarter, 18).style(GadgetButton.Style.PRIMARY).build());
    }

    private void stepPasses(int delta) {
        int span = PortalGunData.MAX_PASSES - PortalGunData.MIN_PASSES + 1;
        passLimit = PortalGunData.MIN_PASSES
                + Math.floorMod(passLimit - PortalGunData.MIN_PASSES + delta, span);
    }

    private static int clampAir(int value) {
        return Math.max(PortalGunData.MIN_AIR_DISTANCE, Math.min(value, PortalGunData.MAX_AIR_DISTANCE));
    }

    /** ПКМ по кнопке проходов уменьшает их; остальное — как обычно. */
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 1 && passesButton != null && passesButton.isMouseOver(mouseX, mouseY)) {
            click();
            commit();
            stepPasses(-1);
            rebuild();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    /** При смене размера окна введённое не теряется. */
    @Override
    public void resize(Minecraft minecraft, int width, int height) {
        commit();
        super.resize(minecraft, width, height);
    }

    private EditBox box(int x, int y, int w, String value, String hintKey) {
        EditBox b = new EditBox(this.font, x, y, w, 18, Component.translatable(hintKey));
        b.setMaxLength(64);
        b.setValue(value);
        b.setHint(Component.translatable(hintKey).withStyle(ChatFormatting.DARK_GRAY));
        addRenderableWidget(b);
        return b;
    }

    private void click() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.playSound(PortalGunRegistry.SOUND_UI_PRESS.get(), 1.0F, 1.0F);
    }

    /** Переносит введённое в модель. Зовётся перед любой сменой состояния. */
    private void commit() {
        if (labelBox == null) return;
        PortalPoint old = points.get(selected);
        int x = parse(xBox.getValue(), old.pos().getX());
        int y = parse(yBox.getValue(), old.pos().getY());
        int z = parse(zBox.getValue(), old.pos().getZ());
        ResourceLocation dim = ResourceLocation.tryParse(dimBox.getValue().trim());
        if (dim == null) dim = old.dimension();
        points.set(selected, new PortalPoint(labelBox.getValue(), new BlockPos(x, y, z), dim));
    }

    private static int parse(String raw, int fallback) {
        try {
            return Integer.parseInt(raw.trim());
        } catch (NumberFormatException bad) {
            return fallback;
        }
    }

    private void fillFromPlayer() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        BlockPos pos = mc.player.blockPosition();
        xBox.setValue(Integer.toString(pos.getX()));
        yBox.setValue(Integer.toString(pos.getY()));
        zBox.setValue(Integer.toString(pos.getZ()));
        dimBox.setValue(mc.player.level().dimension().location().toString());
    }

    /** Листает измерения, известные текущему подключению. */
    private void cycleDimension() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.connection == null) return;
        List<ResourceLocation> known = new ArrayList<>();
        for (ResourceKey<Level> key : mc.player.connection.levels()) known.add(key.location());
        if (known.isEmpty()) return;
        known.sort(ResourceLocation::compareTo);
        ResourceLocation current = ResourceLocation.tryParse(dimBox.getValue().trim());
        int index = current == null ? -1 : known.indexOf(current);
        dimBox.setValue(known.get((index + 1) % known.size()).toString());
    }

    private void rebuild() {
        this.clearWidgets();
        this.init();
    }

    private void apply() {
        List<PortalPoint> clean = new ArrayList<>(PortalGunData.MAX_POINTS);
        for (PortalPoint p : points) {
            clean.add(new PortalPoint(PortalPoint.sanitize(p.label()), p.pos(), p.dimension()));
        }
        PacketDistributor.sendToServer(new PortalGunConfigPacket(
                hand == InteractionHand.MAIN_HAND,
                new PortalGunData(List.copyOf(clean), selected, passLimit, mode.id(), clampAir(airDistance))));
    }

    private String trim(String text, int width) {
        return this.font.width(text) <= width ? text : this.font.plainSubstrByWidth(text, width - 6) + "…";
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g, mouseX, mouseY, partialTick);

        GadgetGuiUtils.renderChassis(g, left, top, PANEL_W, PANEL_H);
        GadgetGuiUtils.renderHeader(g, left + 4, top + 4, PANEL_W - 8, 30);
        g.fill(left + 8, top + 6, left + 34, top + 32, 0xFF121417);
        g.renderOutline(left + 8, top + 6, 26, 26, 0xFF353942);
        g.renderItem(gunStack, left + 13, top + 11);
        g.drawString(this.font, gunStack.getHoverName().getString(), left + 40, top + 9, TEXT_PHOSPHOR, false);
        g.drawString(this.font, I18n.get("screen.sable_compat.portal_gun.subtitle"), left + 40, top + 21, TEXT_MUTED, false);

        int screenX = left + PAD;
        int screenY = top + 38;
        int screenW = PANEL_W - PAD * 2;
        int screenH = 40;
        GadgetGuiUtils.renderTerminalScreen(g, screenX, screenY, screenW, screenH);

        int charge = PortalGunItem.chargePercent(gunStack);
        g.drawString(this.font, I18n.get("screen.sable_compat.portal_gun.fluid"), screenX + 6, screenY + 5, TEXT_MUTED, false);
        GadgetGuiUtils.renderFluidTube(g, this.font, screenX + 52, screenY + 4, 140, 9, charge, true);

        g.drawString(this.font, I18n.get("screen.sable_compat.portal_gun.mode_label"), screenX + 6, screenY + 17, TEXT_MUTED, false);
        g.drawString(this.font, I18n.get(mode.translationKey()), screenX + 52, screenY + 17, TEXT_CYAN, false);
        int gunId = PortalGunItem.gunId(gunStack);
        String device = I18n.get("screen.sable_compat.portal_gun.device", gunId == 0 ? "---" : Integer.toString(gunId));
        g.drawString(this.font, device, screenX + screenW - this.font.width(device) - 8, screenY + 17, TEXT_MUTED, false);

        g.drawString(this.font, I18n.get("screen.sable_compat.portal_gun.target_label"), screenX + 6, screenY + 29, TEXT_MUTED, false);
        String target;
        int targetColor;
        if (mode == PortalMode.POINT) {
            PortalPoint p = points.get(selected);
            target = p.isSet() ? p.display() + " (" + p.dimension().getPath() + ")"
                    : I18n.get("screen.sable_compat.portal_gun.no_target");
            targetColor = p.isSet() ? TEXT_AMBER : TEXT_MUTED;
        } else {
            target = I18n.get("screen.sable_compat.portal_gun.ready");
            targetColor = TEXT_PHOSPHOR;
        }
        g.drawString(this.font, trim(target, screenW - 60), screenX + 52, screenY + 29, targetColor, false);

        int led = charge > 25 ? 0xFF00FF66 : (charge > 0 ? 0xFFFFCC00 : 0xFFFF2222);
        GadgetGuiUtils.renderLed(g, screenX + screenW - 12, screenY + 6, led);

        g.drawString(this.font, I18n.get("screen.sable_compat.portal_gun.points"), left + PAD, top + 84 - 11, TEXT_MUTED, false);
        String airLabel = I18n.get(airDistance > 0 ? "screen.sable_compat.portal_gun.air_distance"
                : "screen.sable_compat.portal_gun.air_distance_off");
        g.drawString(this.font, airLabel, airLabelX, airRowY + 5, airDistance > 0 ? TEXT_CYAN : TEXT_MUTED, false);

        // Не super.render: он повторно рисует фон поверх корпуса. Как в оригинале —
        // только виджеты.
        for (net.minecraft.client.gui.components.Renderable renderable : this.renderables) {
            renderable.render(g, mouseX, mouseY, partialTick);
        }
    }

    /** Размытый фон ванили не нужен — у панели свой корпус (оригинал тоже его отключает). */
    @Override
    protected void renderBlurredBackground(float partialTick) {
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
