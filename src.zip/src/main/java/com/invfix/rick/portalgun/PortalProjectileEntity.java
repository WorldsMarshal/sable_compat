package com.invfix.rick.portalgun;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Сгусток портальной жидкости. Порт PortalProjectileEntity из Rick's stuff
 * 0.0.4.3: летит без гравитации, попадание в блок открывает портал, попадание
 * в живое существо обдаёт его жидкостью (иссушение и замедление V на 15 сек,
 * брызги, лужицы на земле), сам стрелок снарядом не задевается. Дальность
 * 128 блоков, живёт не дольше 240 тиков.
 *
 * Вместо «GPS-метки» оригинала снаряд несёт цель режима POINT: измерение,
 * координаты и лимит проходов.
 */
public class PortalProjectileEntity extends ThrowableProjectile {

    /** portalGunMaxDistance оригинала. */
    public static final double MAX_DISTANCE = 128.0;
    public static final int MAX_AGE = 240;

    private static final EntityDataAccessor<Integer> DATA_COLOR =
            SynchedEntityData.defineId(PortalProjectileEntity.class, EntityDataSerializers.INT);

    private int gunId;
    private PortalMode mode = PortalMode.FIFO;
    private int passLimit = PortalEntity.UNLIMITED_PASSES;
    /** Через сколько блоков полёта без попадания открыть портал в воздухе; 0 — не открывать. */
    private int airDistance;
    /** Пройденный путь (сумма шагов — корректен и после прохода через портал). */
    private double pathLength;
    @Nullable private PortalPoint target;
    @Nullable private Vec3 spawnOrigin;

    public PortalProjectileEntity(EntityType<? extends PortalProjectileEntity> type, Level level) {
        super(type, level);
    }

    public PortalProjectileEntity(Level level, LivingEntity shooter) {
        super(PortalGunRegistry.PORTAL_PROJECTILE.get(), shooter, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_COLOR, PortalGunItem.COLOR_GREEN);
    }

    public int getColor() { return this.entityData.get(DATA_COLOR); }
    public void setColor(int color) { this.entityData.set(DATA_COLOR, color); }

    public int getGunId() { return gunId; }
    public PortalMode getMode() { return mode; }
    public int getPassLimit() { return passLimit; }
    @Nullable public PortalPoint getTarget() { return target; }

    public void configure(int gunId, PortalMode mode, int passLimit, @Nullable PortalPoint target, int airDistance) {
        this.gunId = gunId;
        this.mode = mode;
        this.passLimit = passLimit;
        this.target = target;
        this.airDistance = airDistance;
    }

    @Override
    protected double getDefaultGravity() { return 0.0; }

    @Override
    public void tick() {
        Vec3 before = this.position();
        super.tick();
        if (this.isRemoved()) return;

        if (!this.level().isClientSide) {
            if (this.spawnOrigin == null) this.spawnOrigin = this.position();
            double travelled = this.position().distanceTo(this.spawnOrigin);
            if (travelled >= MAX_DISTANCE || this.tickCount > MAX_AGE) {
                this.discard();
                return;
            }
            // Подрыв в воздухе на заданной дистанции (AutoAirDetonate / AirDistance оригинала).
            // Точка берётся ровно на заданной длине пути, а не там, где снаряд оказался
            // к концу тика (за тик он пролетает больше трёх блоков).
            Vec3 after = this.position();
            double step = before.distanceTo(after);
            if (step > 32.0) step = 0.0; // скачок позиции (перенос), а не полёт
            double prev = this.pathLength;
            this.pathLength += step;
            if (this.airDistance > 0 && this.pathLength >= this.airDistance
                    && this.level() instanceof ServerLevel serverLevel) {
                Vec3 at = after;
                if (step > 0.0 && prev < this.airDistance) {
                    at = before.add(after.subtract(before).scale((this.airDistance - prev) / step));
                }
                PortalManager.handleAirPortalSpawn(serverLevel, at, this);
            }
            return;
        }

        Vec3 movement = this.getDeltaMovement();
        int color = getColor();
        var drop = PortalGunRegistry.droplet(color);
        for (int i = 0; i < 2; ++i) {
            this.level().addParticle(drop,
                    getX() + (this.random.nextDouble() - 0.5) * 0.06,
                    getY() + (this.random.nextDouble() - 0.5) * 0.06,
                    getZ() + (this.random.nextDouble() - 0.5) * 0.06,
                    -movement.x * 0.08, -movement.y * 0.08, -movement.z * 0.08);
        }
        if (this.tickCount % 2 == 0) {
            this.level().addParticle(PortalGunRegistry.shockwave(color), getX(), getY(), getZ(), 0.0, 0.0, 0.0);
        }
    }

    @Override
    protected void onHitEntity(@NotNull EntityHitResult result) {
        Entity target = result.getEntity();
        Entity owner = this.getOwner();
        if (target instanceof PortalEntity) return;
        if (owner != null && (target == owner || target.getUUID().equals(owner.getUUID()))) return;

        super.onHitEntity(result);
        if (this.isRemoved()) return;

        if (this.level() instanceof ServerLevel level) {
            if (target instanceof LivingEntity living) {
                living.addEffect(new MobEffectInstance(MobEffects.WITHER, 300, 5));
                living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 300, 5));
            }
            int color = getColor();
            double tx = target.getX();
            double ty = target.getY() + target.getBbHeight() * 0.5;
            double tz = target.getZ();
            var poison = PortalGunRegistry.poison(color);
            for (int i = 0; i < 100; ++i) {
                double theta = this.random.nextDouble() * Math.PI * 2.0;
                double phi = Math.acos(this.random.nextDouble() * 2.0 - 1.0);
                double speed = 0.02 + this.random.nextDouble() * 0.055;
                double vx = Math.sin(phi) * Math.cos(theta) * speed;
                double vy = Math.sin(phi) * Math.sin(theta) * speed + 0.012;
                double vz = Math.cos(phi) * speed;
                level.sendParticles(poison, tx, ty, tz, 1, vx, vy, vz, 1.0);
            }

            BlockPos targetPos = target.blockPosition();
            BlockPos.MutableBlockPos scan = targetPos.mutable();
            double groundY = 0.0;
            boolean foundGround = false;
            for (int i = 0; i <= 4; ++i) {
                scan.set(targetPos.getX(), targetPos.getY() - i, targetPos.getZ());
                BlockState state = level.getBlockState(scan);
                if (!state.isAir() && (state.isSolid() || state.blocksMotion())) {
                    foundGround = true;
                    groundY = scan.getY() + 1.0;
                    break;
                }
            }
            if (foundGround && Math.abs(target.getY() - groundY) < 2.5) {
                var ground = PortalGunRegistry.groundDrop(color);
                for (int i = 0; i < 8; ++i) {
                    double gx = target.getX() + (this.random.nextDouble() - 0.5) * 1.8;
                    double gz = target.getZ() + (this.random.nextDouble() - 0.5) * 1.8;
                    level.sendParticles(ground, gx, groundY, gz, 1, 0.0, 0.0, 0.0, 0.0);
                }
            }
            level.playSound(null, this.blockPosition(), PortalGunRegistry.SOUND_PLASMA_SCORCH.get(),
                    SoundSource.NEUTRAL, 1.0F, 1.0F);
        }
        this.discard();
    }

    @Override
    protected void onHitBlock(@NotNull BlockHitResult result) {
        super.onHitBlock(result);
        if (this.level() instanceof ServerLevel level) {
            PortalManager.handlePortalSpawn(level, result, this);
            this.discard();
        }
    }

    @Override
    protected boolean canHitEntity(@NotNull Entity entity) {
        if (entity instanceof PortalEntity) return false;
        Entity owner = this.getOwner();
        if (owner != null && (entity == owner || entity.getUUID().equals(owner.getUUID()))) return false;
        return super.canHitEntity(entity);
    }

    @Override
    public void remove(@NotNull RemovalReason reason) {
        PortalManager.unregisterProjectile(this);
        super.remove(reason);
    }

    @Nullable
    public Player ownerPlayer() {
        return this.getOwner() instanceof Player p ? p : null;
    }

    @Override
    protected void addAdditionalSaveData(@NotNull CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Color", getColor());
        tag.putInt("GunId", gunId);
        tag.putString("GunMode", mode.id());
        tag.putInt("PassLimit", passLimit);
        tag.putInt("AirDistance", airDistance);
        tag.putDouble("PathLength", pathLength);
        if (spawnOrigin != null) {
            tag.putDouble("SpawnOriginX", spawnOrigin.x);
            tag.putDouble("SpawnOriginY", spawnOrigin.y);
            tag.putDouble("SpawnOriginZ", spawnOrigin.z);
        }
        if (target != null) {
            PortalPoint.CODEC.encodeStart(net.minecraft.nbt.NbtOps.INSTANCE, target)
                    .result().ifPresent(t -> tag.put("Target", t));
        }
    }

    @Override
    protected void readAdditionalSaveData(@NotNull CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setColor(tag.getInt("Color"));
        this.gunId = tag.getInt("GunId");
        this.mode = PortalMode.byId(tag.getString("GunMode"));
        this.passLimit = tag.contains("PassLimit") ? tag.getInt("PassLimit") : PortalEntity.UNLIMITED_PASSES;
        this.airDistance = tag.getInt("AirDistance");
        this.pathLength = tag.getDouble("PathLength");
        if (tag.contains("SpawnOriginX")) {
            this.spawnOrigin = new Vec3(tag.getDouble("SpawnOriginX"), tag.getDouble("SpawnOriginY"), tag.getDouble("SpawnOriginZ"));
        }
        if (tag.contains("Target")) {
            this.target = PortalPoint.CODEC.parse(net.minecraft.nbt.NbtOps.INSTANCE, tag.get("Target"))
                    .result().orElse(null);
        }
    }
}
