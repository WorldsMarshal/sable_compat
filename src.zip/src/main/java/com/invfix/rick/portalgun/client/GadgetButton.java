package com.invfix.rick.portalgun.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** Порт GadgetButton из Rick's stuff 0.0.4.3 — оформление панелей портальной пушки. */
@net.neoforged.api.distmarker.OnlyIn(net.neoforged.api.distmarker.Dist.CLIENT)
public class GadgetButton extends Button {
   private Style style;

   public GadgetButton(int x, int y, int width, int height, Component message, Button.OnPress onPress, Style style) {
      super(x, y, width, height, message, onPress, DEFAULT_NARRATION);
      this.style = GadgetButton.Style.NORMAL;
      this.style = style != null ? style : GadgetButton.Style.NORMAL;
   }

   public GadgetButton(int x, int y, int width, int height, Component message, Button.OnPress onPress) {
      this(x, y, width, height, message, onPress, GadgetButton.Style.NORMAL);
   }

   public void setStyle(Style style) {
      this.style = style;
   }

   public Style getStyle() {
      return this.style;
   }

   public static Builder gadget(Component message, Button.OnPress onPress) {
      return new Builder(message, onPress);
   }

   public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      Minecraft mc = Minecraft.getInstance();
      Font font = mc.font;
      boolean hovered = this.isHoveredOrFocused();
      int x = this.getX();
      int y = this.getY();
      int w = this.getWidth();
      int h = this.getHeight();
      int bg;
      int bevelLight;
      int bevelDark;
      int border;
      int ledColor;
      int textColor;
      if (!this.active) {
         bg = 0xFF181A1D;
         bevelLight = 0xFF24272C;
         bevelDark = 0xFF0F1113;
         border = 0xFF0A0B0D;
         ledColor = 0xFF282B30;
         textColor = 0xFF555B66;
      } else if (hovered) {
         switch (this.style.ordinal()) {
            case 1:
               bg = 0xFF223828;
               bevelLight = 0xFF35613F;
               bevelDark = 0xFF142419;
               border = 0xFF3DE665;
               ledColor = 0xFF45FF70;
               textColor = 0xFF85FFA4;
               break;
            case 2:
               bg = 0xFF382022;
               bevelLight = 0xFF613034;
               bevelDark = 0xFF241315;
               border = 0xFFFF4444;
               ledColor = 0xFFFF4545;
               textColor = 0xFFFF9E9E;
               break;
            default:
               bg = 0xFF2F333C;
               bevelLight = 0xFF545C6C;
               bevelDark = 0xFF181B20;
               border = 0xFF36D7E8;
               ledColor = 0xFF36D7E8;
               textColor = -1;
         }
      } else {
         switch (this.style.ordinal()) {
            case 1:
               bg = 0xFF1D2C22;
               bevelLight = 0xFF2E4D38;
               bevelDark = 0xFF111C15;
               border = 0xFF18241C;
               ledColor = 0xFF2BB54D;
               textColor = 0xFF4AE673;
               break;
            case 2:
               bg = 0xFF2C1C1E;
               bevelLight = 0xFF4D2C30;
               bevelDark = 0xFF1C1113;
               border = 0xFF241618;
               ledColor = 0xFFB52B2B;
               textColor = 0xFFE65555;
               break;
            default:
               bg = 0xFF22252B;
               bevelLight = 0xFF444955;
               bevelDark = 0xFF131518;
               border = 0xFF0D0E10;
               ledColor = 0xFF484E5A;
               textColor = 0xFFD2D6DF;
         }
      }

      guiGraphics.fill(x, y, x + w, y + h, border);
      guiGraphics.fill(x + 1, y + 1, x + w - 1, y + h - 1, bg);
      guiGraphics.fill(x + 1, y + 1, x + w - 1, y + 2, bevelLight);
      guiGraphics.fill(x + 1, y + 1, x + 2, y + h - 1, bevelLight);
      guiGraphics.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, bevelDark);
      guiGraphics.fill(x + w - 2, y + 1, x + w - 1, y + h - 1, bevelDark);
      int ledX;
      int ledY;
      if (h >= 14 && w >= 30) {
         ledX = x + 4;
         ledY = y + (h - 4) / 2;
         guiGraphics.fill(ledX - 1, ledY - 1, ledX + 4, ledY + 4, 0xFF0D0E10);
         guiGraphics.fill(ledX, ledY, ledX + 3, ledY + 3, ledColor);
         if (hovered && this.active) {
            guiGraphics.fill(ledX + 1, ledY + 1, ledX + 2, ledY + 2, -1);
         }
      }

      ledX = h >= 14 && w >= 45 ? 4 : 0;
      ledY = x + (w + ledX) / 2;
      int textY = y + (h - 8) / 2;
      guiGraphics.drawCenteredString(font, this.getMessage(), ledY, textY, textColor);
   }

   public static enum Style {
      NORMAL,
      PRIMARY,
      DANGER;
   }

   public static class Builder {
      private final Component message;
      private final Button.OnPress onPress;
      private int x;
      private int y;
      private int width = 120;
      private int height = 20;
      private Style style;

      public Builder(Component message, Button.OnPress onPress) {
         this.style = GadgetButton.Style.NORMAL;
         this.message = message;
         this.onPress = onPress;
      }

      public Builder bounds(int x, int y, int width, int height) {
         this.x = x;
         this.y = y;
         this.width = width;
         this.height = height;
         return this;
      }

      public Builder style(Style style) {
         this.style = style;
         return this;
      }

      public GadgetButton build() {
         return new GadgetButton(this.x, this.y, this.width, this.height, this.message, this.onPress, this.style);
      }
   }
}
