package com.invfix.rick;

/**
 * Геометрия панели Рика. Все координаты — ОТНОСИТЕЛЬНО левого верхнего угла
 * ванильного инвентаря (leftPos, topPos), поэтому Y отрицательный: панель висит
 * НАД ванильным окном, а не заменяет его.
 *
 * Ванильный экран при этом остаётся ванильным целиком — книга рецептов, кнопки
 * Curios и всё, что другие моды навешивают на InventoryScreen, на месте.
 */
public final class RickPanel {

    public static final int PANEL_W = 236;
    public static final int PANEL_H = 120;

    /** Панель шире инвентаря (236 против 176) и центрируется по нему. */
    public static final int OX = (176 - PANEL_W) / 2;   // -30
    public static final int OY = -PANEL_H;              // -120

    // сетка 5x5
    public static final int GRID_X = OX + 8;            // -22
    public static final int GRID_Y = OY + 18;           // -102

    // слот выдачи сетки
    public static final int RESULT_X = OX + 132;        // 102
    public static final int RESULT_Y = OY + 56;         // -64

    // ── танки ──────────────────────────────────────────────────────────────
    // Над каждым столбиком слот СЛИВА (жидкость из тары уходит в бак), под
    // столбиком — слот НАЛИВА (бак заправляет тару). Два раздельных слота
    // вместо одного универсального: с одним слотом ведро сливалось и тут же
    // наполнялось обратно, потому что направление выбиралось по содержимому
    // тары и переключалось на каждое обновление контейнера.
    public static final int TANK_X = OX + 165;          // 135
    public static final int TANK_Y = OY + 23;           // -97
    public static final int TANK_W = 16;
    public static final int TANK_H = 60;
    public static final int TANK_DX = 24;

    public static final int DRAIN_Y = OY + 4;           // -116, над столбиком
    public static final int FILL_Y  = OY + 87;          // -33,  под столбиком

    // ── выбор варианта крафта ──────────────────────────────────────────────
    // Полоска под слотом выдачи: стрелка влево, счётчик, стрелка вправо.
    // Появляется только когда из текущей сетки выходит больше одного предмета.
    public static final int VARIANT_Y = OY + 79;        // -41
    public static final int VARIANT_W = 8;
    public static final int VARIANT_H = 10;
    public static final int VARIANT_PREV_X = OX + 127;  // 97
    public static final int VARIANT_NEXT_X = OX + 145;  // 115
    public static final int VARIANT_LABEL_X = OX + 140; // 110, центр счётчика

    // слот разложения Alchemistry — под стрелкой, левее танков
    public static final int DISSOLVER_X = OX + 104;     // 74
    public static final int DISSOLVER_Y = OY + 92;      // -28

    private RickPanel() {}
}