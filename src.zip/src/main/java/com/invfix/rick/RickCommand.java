package com.invfix.rick;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.context.CommandContext;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import java.util.Collection;
import java.util.List;

/**
 * Выдача и снятие родословной Rick C137. Только OP (permission 2).
 *
 *   /rick                 — выдать себе
 *   /rick <игроки>        — выдать указанным
 *   /rick clear           — снять с себя (вернуть безродного)
 *   /rick clear <игроки>  — снять с указанных
 *
 * Родословная — единственное, что меняется: раса, силы и статы не трогаются,
 * потому что Rick расо-независим и сам по себе статов не даёт. Поле Bloodline
 * пишется напрямую, без вызова BloodlineRandomizerProcedure, чтобы команда не
 * зависела от бросков костей.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class RickCommand {

    private RickCommand() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("rick")
                        .requires(s -> s.hasPermission(2)) // только OP
                        .executes(ctx -> applySelf(ctx, true))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> applyTargets(ctx, true)))
                        .then(Commands.literal("clear")
                                .executes(ctx -> applySelf(ctx, false))
                                .then(Commands.argument("targets", EntityArgument.players())
                                        .executes(ctx -> applyTargets(ctx, false))))
        );
    }

    private static int applySelf(CommandContext<CommandSourceStack> ctx, boolean give) {
        if (!(ctx.getSource().getEntity() instanceof ServerPlayer player)) {
            ctx.getSource().sendFailure(
                    Component.literal("\u00a7cБез аргумента команда доступна только игроку."));
            return 0;
        }
        return run(ctx.getSource(), List.of(player), give);
    }

    private static int applyTargets(CommandContext<CommandSourceStack> ctx, boolean give)
            throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        return run(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"), give);
    }

    private static int run(CommandSourceStack source, Collection<ServerPlayer> targets, boolean give) {
        int count = 0;
        for (ServerPlayer player : targets) {
            if (give) set(player, RickBloodline.RICK);
            else set(player, "\u00a7f\u00a7l" + nameOf(player));
            count++;
        }

        final int n = count;
        if (n == 1) {
            ServerPlayer only = targets.iterator().next();
            source.sendSuccess(() -> Component.literal(give
                    ? "\u00a7aRick C137 выдан: " + only.getGameProfile().getName()
                    : "\u00a7eРодословная снята: " + only.getGameProfile().getName()), true);
        } else {
            source.sendSuccess(() -> Component.literal(give
                    ? "\u00a7aRick C137 выдан игрокам: " + n
                    : "\u00a7eРодословная снята у игроков: " + n), true);
        }
        return n > 0 ? Command.SINGLE_SUCCESS : 0;
    }

    private static void set(ServerPlayer player, String bloodline) {
        InvincibleIncModVariables.PlayerVariables vars =
                player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        vars.Bloodline = bloodline;
        vars.markSyncDirty();

        // Слоты панели есть у всех и всегда — они лишь оживают или гаснут по
        // isActive(). Переоткрывать инвентарь не нужно.
        RickPocket pocket = RickMenuAccess.of(player);
        if (pocket == null) return;

        if (RickBloodline.RICK.equals(bloodline)) {
            pocket.syncTanks(true);
        } else {
            // При снятии возвращаем содержимое, чтобы ничего не залипло в
            // недоступных ячейках.
            pocket.returnAll(player);
        }
        player.inventoryMenu.sendAllDataToRemote();
    }

    /** Безродный в этом моде — это собственный ник в поле Bloodline. */
    private static String nameOf(ServerPlayer player) {
        InvincibleIncModVariables.PlayerVariables vars =
                player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        String ign = vars.IGN;
        return (ign == null || ign.isEmpty()) ? player.getGameProfile().getName() : ign;
    }
}