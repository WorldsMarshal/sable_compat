package com.invfix.rick;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.fluids.FluidStack;

import java.util.List;

/**
 * Три карманных танка, привязанных к игроку через AttachmentType. Живут в
 * сохранении игрока, а не в мире, поэтому переносятся между измерениями и
 * переживают смерть (attachment копируется, см. {@code copyOnDeath} в реестре).
 *
 * ВАЖНО: конструктор здесь ровно ОДИН, без аргументов. Второй конструктор,
 * принимающий список, делал {@code RickTanks::new} «неточной» ссылкой на метод,
 * а у {@code AttachmentType.builder} две перегрузки — Supplier и
 * Function&lt;IAttachmentHolder, T&gt;. Компилятор не мог выбрать между ними и
 * ругался «Cannot resolve constructor». Восстановление из списка вынесено в
 * статическую фабрику {@link #fromList}.
 */
public class RickTanks {

    public static final int COUNT = 3;

    private final RickFluidTank[] tanks = new RickFluidTank[COUNT];

    public RickTanks() {
        for (int i = 0; i < COUNT; i++) tanks[i] = new RickFluidTank();
    }

    /** Фабрика для кодека — вместо второго конструктора. */
    public static RickTanks fromList(List<FluidStack> initial) {
        RickTanks t = new RickTanks();
        t.apply(initial);
        return t;
    }

    public RickFluidTank tank(int i) { return tanks[i]; }

    public List<FluidStack> snapshot() {
        return List.of(tanks[0].stack().copy(), tanks[1].stack().copy(), tanks[2].stack().copy());
    }

    public void apply(List<FluidStack> list) {
        for (int i = 0; i < COUNT && i < list.size(); i++) tanks[i].set(list.get(i));
    }

    /** Танки текущего игрока; на клиенте панель читает кэш, см. RickTanksClient. */
    public static RickTanks of(Player player) {
        return player.getData(RickRegistry.TANKS.get());
    }

    public static final Codec<RickTanks> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            FluidStack.OPTIONAL_CODEC.listOf().fieldOf("tanks").forGetter(RickTanks::snapshot)
    ).apply(inst, RickTanks::fromList));

    public static final StreamCodec<RegistryFriendlyByteBuf, List<FluidStack>> LIST_STREAM_CODEC =
            FluidStack.OPTIONAL_STREAM_CODEC.apply(ByteBufCodecs.list(COUNT));
}