package com.invfix.rick;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Особенность родословной Rick C137: всё в его инвентаре, что умеет хранить
 * FE, заряжается на {@link #FE_PER_TICK} FE в тик — каждый предмет отдельно.
 *
 * Работает через ту же capability, что и зарядные станции
 * ({@code Capabilities.EnergyStorage.ITEM}), поэтому годится для любого
 * мода, а не только для наших предметов. Сколько предмет примет за один
 * вызов, решает он сам: энергокуб, например, берёт не больше 10 000 за
 * операцию — у него так устроен бак.
 *
 * Инвентарь целиком: сетка, броня, левая рука (Container-интерфейс).
 *
 * Весь инвентарь (41 ячейка, поиск capability в каждом предмете) перебирается раз в {@link #SCAN_INTERVAL}
 * тиков; между переборами каждый тик заряжаются запомненные ячейки с хранилищами — с той же скоростью, что и
 * раньше, — если в ячейке всё тот же предмет (переложенный или новый подхватит следующий перебор).
 */
@EventBusSubscriber(modid = "sable_compat")
public final class RickInventoryCharger {

    private RickInventoryCharger() {}

    public static final int FE_PER_TICK = 45_000;
    public static final int SCAN_INTERVAL = 20;

    /** Ячейка с хранилищем FE и предмет, что в ней был при переборе. */
    private record Slot(int index, ItemStack stack) {}

    private static final Map<UUID, List<Slot>> SLOTS = new HashMap<>();

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!RickBloodline.is(player)) {
            if (!SLOTS.isEmpty()) SLOTS.remove(player.getUUID());
            return;
        }

        Inventory inv = player.getInventory();
        List<Slot> slots = SLOTS.get(player.getUUID());
        // переборы разных игроков — в разные тики
        if (slots == null || (player.tickCount + player.getId()) % SCAN_INTERVAL == 0) {
            slots = scan(inv);
            SLOTS.put(player.getUUID(), slots);
        }
        for (Slot s : slots) {
            ItemStack stack = s.stack();
            if (inv.getItem(s.index()) != stack || stack.isEmpty()) continue;
            IEnergyStorage storage = stack.getCapability(Capabilities.EnergyStorage.ITEM);
            if (storage == null || !storage.canReceive()) continue;
            if (storage.getEnergyStored() >= storage.getMaxEnergyStored()) continue;
            storage.receiveEnergy(FE_PER_TICK, false);
        }
    }

    /** Ячейки, где лежит что-то, что принимает FE (полное тоже — его могут разрядить до следующего перебора). */
    private static List<Slot> scan(Inventory inv) {
        List<Slot> out = new ArrayList<>(4);
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty()) continue;
            IEnergyStorage storage = stack.getCapability(Capabilities.EnergyStorage.ITEM);
            if (storage == null || !storage.canReceive()) continue;
            out.add(new Slot(i, stack));
        }
        return out;
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        SLOTS.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        SLOTS.clear();
    }
}
