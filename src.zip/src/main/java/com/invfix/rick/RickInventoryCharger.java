package com.invfix.rick;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Особенность родословной Rick C137: всё в его инвентаре, что умеет хранить
 * FE, заряжается на {@link #FE_PER_TICK} FE в тик — каждый предмет отдельно.
 *
 * Работает через ту же capability, что и зарядные станции
 * ({@code Capabilities.EnergyStorage.ITEM}), поэтому годится для любого
 * мода, а не только для наших предметов. Сколько предмет примет за один
 * вызов, решает он сам: энергокуб, например, берёт не больше 10 000 за
 * операцию — у него так устроен бак.
 *
 * Инвентарь целиком: сетка, броня, левая рука (Container-интерфейс).
 */
@EventBusSubscriber(modid = "sable_compat")
public final class RickInventoryCharger {

    private RickInventoryCharger() {}

    public static final int FE_PER_TICK = 45_000;

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!RickBloodline.is(player)) return;

        var inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty()) continue;
            IEnergyStorage storage = stack.getCapability(Capabilities.EnergyStorage.ITEM);
            if (storage == null || !storage.canReceive()) continue;
            if (storage.getEnergyStored() >= storage.getMaxEnergyStored()) continue;
            storage.receiveEnergy(FE_PER_TICK, false);
        }
    }
}
