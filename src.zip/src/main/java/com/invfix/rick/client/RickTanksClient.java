package com.invfix.rick.client;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.fluids.FluidStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Клиентский кэш содержимого танков — заполняется RickTanksSyncPacket. */
@OnlyIn(Dist.CLIENT)
public final class RickTanksClient {

    private static final List<FluidStack> TANKS =
            new ArrayList<>(Collections.nCopies(3, FluidStack.EMPTY));

    private RickTanksClient() {}

    public static void accept(List<FluidStack> incoming) {
        for (int i = 0; i < TANKS.size(); i++) {
            TANKS.set(i, i < incoming.size() ? incoming.get(i) : FluidStack.EMPTY);
        }
    }

    public static FluidStack get(int index) {
        return index >= 0 && index < TANKS.size() ? TANKS.get(index) : FluidStack.EMPTY;
    }
}