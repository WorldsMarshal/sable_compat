package com.invfix.rick.client;

import com.invfix.rick.RickFluidTank;
import com.invfix.rick.RickPanel;
import com.invfix.rick.RickTanks;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.material.Fluid;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.neoforge.fluids.FluidStack;

import java.util.ArrayList;
import java.util.List;

/** Отрисовка панели Рика поверх ванильного экрана инвентаря. */
@OnlyIn(Dist.CLIENT)
public final class RickPanelRenderer {

    private static final ResourceLocation PANEL =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/gui/rick_panel.png");

    private RickPanelRenderer() {}

    /** Фон панели. Вызывается из renderBg, координаты — угол ванильного окна. */
    public static void renderBackground(GuiGraphics g, int leftPos, int topPos) {
        g.blit(PANEL, leftPos + RickPanel.OX, topPos + RickPanel.OY,
                0, 0, RickPanel.PANEL_W, RickPanel.PANEL_H, 256, 256);

        for (int i = 0; i < RickTanks.COUNT; i++) renderTank(g, leftPos, topPos, i);
    }

    /**
     * Стрелки выбора варианта под слотом выдачи.
     *
     * Рисуются поверх содержимого, а не в фоне, и только когда вариантов больше
     * одного — иначе полоска мозолила бы глаза на каждом обычном крафте.
     * Рисуем вручную, без виджетов: набор вариантов меняется на каждое движение
     * предмета в сетке, а виджеты создаются один раз в init.
     */
    public static void renderVariantControls(GuiGraphics g, Font font, int leftPos, int topPos, int mouseX, int mouseY) {
        if (!RickVariantsClient.hasChoice()) return;

        drawArrow(g, leftPos + RickPanel.VARIANT_PREV_X, topPos + RickPanel.VARIANT_Y, true, mouseX, mouseY);
        drawArrow(g, leftPos + RickPanel.VARIANT_NEXT_X, topPos + RickPanel.VARIANT_Y, false, mouseX, mouseY);

        String label = (RickVariantsClient.index() + 1) + "/" + RickVariantsClient.count();
        int x = leftPos + RickPanel.VARIANT_LABEL_X - font.width(label) / 2;
        g.drawString(font, label, x, topPos + RickPanel.VARIANT_Y + 1, 0xE8F0E8, true);
    }

    private static void drawArrow(GuiGraphics g, int x, int y, boolean left, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX < x + RickPanel.VARIANT_W
                && mouseY >= y && mouseY < y + RickPanel.VARIANT_H;
        int color = hovered ? 0xFF9BF0A8 : 0xFF6E7A82;

        // Треугольник строками: чем ближе к острию, тем короче строка. На восьми
        // пикселях это чище, чем заводить отдельную текстуру.
        for (int row = 0; row < 5; row++) {
            int len = 1 + Math.min(row, 4 - row) * 2;
            int cy = y + 2 + row;
            if (left) {
                g.fill(x + 2, cy, x + 2 + len, cy + 1, color);
            } else {
                g.fill(x + 6 - len, cy, x + 6, cy + 1, color);
            }
        }
    }

    /** Попадание по стрелке: -1 назад, +1 вперёд, 0 мимо. */
    public static int arrowAt(int leftPos, int topPos, double mouseX, double mouseY) {
        if (!RickVariantsClient.hasChoice()) return 0;
        if (mouseY < topPos + RickPanel.VARIANT_Y || mouseY >= topPos + RickPanel.VARIANT_Y + RickPanel.VARIANT_H) {
            return 0;
        }
        int prev = leftPos + RickPanel.VARIANT_PREV_X;
        int next = leftPos + RickPanel.VARIANT_NEXT_X;
        if (mouseX >= prev && mouseX < prev + RickPanel.VARIANT_W) return -1;
        if (mouseX >= next && mouseX < next + RickPanel.VARIANT_W) return 1;
        return 0;
    }

    /**
     * Заливка столбика цветом жидкости — тот же приём, что уже работает в экране
     * программируемой машины: тинт из IClientFluidTypeExtensions, без возни с атласом.
     */
    private static void renderTank(GuiGraphics g, int leftPos, int topPos, int index) {
        FluidStack stack = RickTanksClient.get(index);
        if (stack.isEmpty()) return;

        Fluid fluid = stack.getFluid();
        int tint = IClientFluidTypeExtensions.of(fluid).getTintColor(stack);
        int a = (tint >>> 24) & 0xFF;
        if (a == 0) a = 0xFF; // многие жидкости не пишут альфу в тинт
        int argb = (a << 24) | (tint & 0xFFFFFF);

        int filled = (int) (RickPanel.TANK_H * (stack.getAmount() / (float) RickFluidTank.CAPACITY));
        if (filled <= 0) filled = 1;                        // капля тоже видна
        if (filled > RickPanel.TANK_H) filled = RickPanel.TANK_H;

        int bx = leftPos + RickPanel.TANK_X + index * RickPanel.TANK_DX;
        int by = topPos + RickPanel.TANK_Y;
        g.fill(bx, by + (RickPanel.TANK_H - filled), bx + RickPanel.TANK_W, by + RickPanel.TANK_H, argb);
    }

    /** Подсказка по танку под курсором. Вызывается в самом конце render. */
    public static void renderTankTooltip(GuiGraphics g, Font font, int leftPos, int topPos,
                                         int mouseX, int mouseY) {
        for (int i = 0; i < RickTanks.COUNT; i++) {
            int bx = leftPos + RickPanel.TANK_X + i * RickPanel.TANK_DX;
            int by = topPos + RickPanel.TANK_Y;
            if (mouseX < bx || mouseX >= bx + RickPanel.TANK_W
                    || mouseY < by || mouseY >= by + RickPanel.TANK_H) continue;

            FluidStack stack = RickTanksClient.get(i);
            List<Component> lines = new ArrayList<>(2);
            if (stack.isEmpty()) {
                lines.add(Component.translatable("gui.sable_compat.tank.empty").withStyle(ChatFormatting.GRAY));
            } else {
                lines.add(stack.getHoverName());
                lines.add(Component.literal(format(stack.getAmount()) + " / "
                        + format(RickFluidTank.CAPACITY)).withStyle(ChatFormatting.GRAY));
            }
            g.renderComponentTooltip(font, lines, mouseX, mouseY);
            return;
        }
    }

    /** 500000 -> «500 B», 1500 -> «1,5 B», 250 -> «250 mB». */
    private static String format(int mb) {
        if (mb < 1000) return mb + " mB";
        if (mb % 1000 == 0) return (mb / 1000) + " B";
        return String.format("%.1f B", mb / 1000.0F);
    }
}