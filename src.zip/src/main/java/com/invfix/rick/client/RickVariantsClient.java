package com.invfix.rick.client;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/** Клиентский кэш числа вариантов крафта и текущего выбора. */
@OnlyIn(Dist.CLIENT)
public final class RickVariantsClient {

    private static int count;
    private static int index;

    private RickVariantsClient() {}

    public static void accept(int newCount, int newIndex) {
        count = Math.max(0, newCount);
        index = Math.max(0, newIndex);
    }

    public static int count() { return count; }

    public static int index() { return index; }

    /** Стрелки показываем только когда есть между чем выбирать. */
    public static boolean hasChoice() { return count > 1; }
}
