package com.invfix.rick;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Пакеты выбора варианта крафта.
 *
 * Состояние живёт на сервере: клиент лишь показывает стрелки и просит сменить
 * номер. Так подделанный клиент не может выбрать вариант, которого в списке нет
 * — сервер всё равно клампит индекс по своему списку.
 */
public final class RickVariantPackets {

    private RickVariantPackets() {}

    /** S2C: сколько вариантов и какой сейчас выбран. */
    public record Sync(int count, int index) implements CustomPacketPayload {

        public static final CustomPacketPayload.Type<Sync> TYPE =
                new CustomPacketPayload.Type<>(
                        ResourceLocation.fromNamespaceAndPath("sable_compat", "rick_variants_sync"));

        public static final StreamCodec<RegistryFriendlyByteBuf, Sync> STREAM_CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.VAR_INT, Sync::count,
                        ByteBufCodecs.VAR_INT, Sync::index,
                        Sync::new);

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() { return TYPE; }

        public static void handle(Sync packet, IPayloadContext context) {
            if (FMLEnvironment.dist != Dist.CLIENT) return;
            context.enqueueWork(() ->
                    com.invfix.rick.client.RickVariantsClient.accept(packet.count(), packet.index()));
        }
    }

    /** C2S: «переключи на этот номер». */
    public record Select(int index) implements CustomPacketPayload {

        public static final CustomPacketPayload.Type<Select> TYPE =
                new CustomPacketPayload.Type<>(
                        ResourceLocation.fromNamespaceAndPath("sable_compat", "rick_variant_select"));

        public static final StreamCodec<RegistryFriendlyByteBuf, Select> STREAM_CODEC =
                StreamCodec.composite(ByteBufCodecs.VAR_INT, Select::index, Select::new);

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() { return TYPE; }

        public static void handle(Select packet, IPayloadContext context) {
            context.enqueueWork(() -> {
                var player = context.player();
                if (player == null) return;
                RickPocket pocket = RickMenuAccess.of(player);
                if (pocket != null) pocket.selectVariant(packet.index());
            });
        }
    }
}
