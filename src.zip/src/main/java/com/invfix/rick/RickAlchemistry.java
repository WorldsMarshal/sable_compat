package com.invfix.rick;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Мост к Alchemistry для карманной панели Рика: Dissolver и Combiner.
 *
 * Fusion и Fission сюда сознательно не заведены — расщепление и синтез изотопов
 * в кармане ломали бы всю прогрессию мода. Рику достаются только разложение и
 * сборка.
 *
 * Всё сделано на рефлексии, и это осознанно: Alchemistry не заявлен зависимостью
 * сборочного скрипта, а прямые ссылки на его классы потребовали бы правки
 * build.gradle и жёсткой привязки к версии. Здесь же отсутствие мода означает
 * просто «нет рецептов» — ни ошибок компиляции, ни падений в рантайме.
 *
 * Имена методов взяты из Alchemistry 2.4.5: DissolverRecipe#matches(ItemStack),
 * DissolverRecipe#getOutput() -> ProbabilitySet#calculateOutput(RandomSource),
 * CombinerRecipe#matchInputs(List), #getOutput(), #getInput() -> IngredientStack
 * с #matches(ItemStack) и #getCount().
 */
public final class RickAlchemistry {

    private static final ResourceLocation DISSOLVER_ID =
            ResourceLocation.fromNamespaceAndPath("alchemistry", "dissolver");
    private static final ResourceLocation COMBINER_ID =
            ResourceLocation.fromNamespaceAndPath("alchemistry", "combiner");

    private static boolean probed;
    private static boolean available;

    private static Method mDissolverMatches;
    private static Method mDissolverOutput;
    private static Method mProbabilityCalculate;
    private static Method mCombinerMatch;
    private static Method mCombinerOutput;
    private static Method mCombinerInput;
    private static Method mIngredientMatches;
    private static Method mIngredientCount;

    private static Method mCompactorMatches;
    private static Method mCompactorOutput;
    private static Method mCompactorInput;
    private static Method mFusionInput1;
    private static Method mFusionInput2;
    private static Method mFusionOutput;

    private RickAlchemistry() {}

    // ================= доступность =================

    public static boolean available() {
        probe();
        return available;
    }

    private static synchronized void probe() {
        if (probed) return;
        probed = true;
        try {
            Class<?> dissolver = Class.forName("com.smashingmods.alchemistry.common.recipe.dissolver.DissolverRecipe");
            Class<?> probability = Class.forName("com.smashingmods.alchemistry.common.recipe.dissolver.ProbabilitySet");
            Class<?> combiner = Class.forName("com.smashingmods.alchemistry.common.recipe.combiner.CombinerRecipe");
            Class<?> ingredient = Class.forName("com.smashingmods.alchemylib.api.item.IngredientStack");

            mDissolverMatches = dissolver.getMethod("matches", ItemStack.class);
            mDissolverOutput = dissolver.getMethod("getOutput");
            mProbabilityCalculate = probability.getMethod("calculateOutput", RandomSource.class);
            mCombinerMatch = combiner.getMethod("matchInputs", List.class);
            mCombinerOutput = combiner.getMethod("getOutput");
            mCombinerInput = combiner.getMethod("getInput");
            mIngredientMatches = ingredient.getMethod("matches", ItemStack.class);
            mIngredientCount = ingredient.getMethod("getCount");

            // Compactor и Fusion подключаются отдельно и мягко: если у этих
            // классов окажутся другие имена методов, Dissolver с Combiner всё
            // равно продолжат работать.
            probeCompactor();
            probeFusion();

            available = true;
        } catch (Throwable missing) {
            available = false;
        }
    }

    private static void probeCompactor() {
        try {
            Class<?> c = Class.forName("com.smashingmods.alchemistry.common.recipe.compactor.CompactorRecipe");
            // Сверено по Alchemistry 2.4.5: matches(ItemStack), getInput() ->
            // IngredientStack, getOutput() -> ItemStack.
            mCompactorMatches = c.getMethod("matches", ItemStack.class);
            mCompactorOutput = c.getMethod("getOutput");
            mCompactorInput = c.getMethod("getInput");
        } catch (Throwable missing) {
            mCompactorMatches = null;
        }
    }

    private static void probeFusion() {
        try {
            Class<?> c = Class.forName("com.smashingmods.alchemistry.common.recipe.fusion.FusionRecipe");
            // У FusionRecipe метода сравнения НЕТ вообще — только два входа и
            // выход. Сверку делаем сами, как это делает сам мод в своём
            // JEI-обработчике: isSameItemSameComponents по каждому входу.
            mFusionInput1 = c.getMethod("getInput1");
            mFusionInput2 = c.getMethod("getInput2");
            mFusionOutput = c.getMethod("getOutput");
        } catch (Throwable missing) {
            mFusionInput1 = null;
        }
    }

    @Nullable
    private static RecipeType<?> type(ResourceLocation id) {
        return BuiltInRegistries.RECIPE_TYPE.get(id);
    }

    @SuppressWarnings("unchecked")
    private static List<? extends RecipeHolder<?>> recipes(Level level, ResourceLocation id) {
        RecipeType<?> type = type(id);
        if (type == null) return List.of();
        return new ArrayList<>(level.getRecipeManager()
                .getAllRecipesFor((RecipeType<Recipe<net.minecraft.world.item.crafting.RecipeInput>>) type));
    }

    // ================= Dissolver =================

    /** Рецепт разложения для предмета или {@code null}. */
    @Nullable
    public static Object findDissolver(Level level, ItemStack input) {
        if (input.isEmpty() || !available()) return null;
        for (RecipeHolder<?> holder : recipes(level, DISSOLVER_ID)) {
            Object recipe = holder.value();
            try {
                if (Boolean.TRUE.equals(mDissolverMatches.invoke(recipe, input))) return recipe;
            } catch (Throwable ignored) { /* не наш тип рецепта */ }
        }
        return null;
    }

    /** Один прокат таблицы вероятностей. Может вернуть пустой список — это норма. */
    public static List<ItemStack> rollDissolver(Object recipe, RandomSource random) {
        try {
            Object set = mDissolverOutput.invoke(recipe);
            Object out = mProbabilityCalculate.invoke(set, random);
            List<ItemStack> result = new ArrayList<>();
            if (out instanceof List<?> list) {
                for (Object o : list) {
                    if (o instanceof ItemStack stack && !stack.isEmpty()) result.add(stack.copy());
                }
            }
            return result;
        } catch (Throwable t) {
            return List.of();
        }
    }

    // ================= Compactor =================

    private static final ResourceLocation COMPACTOR_ID =
            ResourceLocation.fromNamespaceAndPath("alchemistry", "compactor");
    private static final ResourceLocation FUSION_ID =
            ResourceLocation.fromNamespaceAndPath("alchemistry", "fusion");

    /** Рецепт сжатия для предмета или {@code null}. */
    @Nullable
    public static Object findCompactor(Level level, ItemStack input) {
        if (input.isEmpty() || !available() || mCompactorMatches == null) return null;
        for (RecipeHolder<?> holder : recipes(level, COMPACTOR_ID)) {
            Object recipe = holder.value();
            try {
                if (Boolean.TRUE.equals(mCompactorMatches.invoke(recipe, input))) return recipe;
            } catch (Throwable ignored) { }
        }
        return null;
    }

    public static ItemStack compactorOutput(Object recipe) {
        return stackOf(mCompactorOutput, recipe);
    }

    /** Сколько предметов съедает сжатие. По умолчанию один. */
    public static int compactorCost(Object recipe) {
        if (mCompactorInput == null) return 1;
        try {
            Object ingredient = mCompactorInput.invoke(recipe);
            if (ingredient == null || mIngredientCount == null) return 1;
            Object count = mIngredientCount.invoke(ingredient);
            return count instanceof Integer i && i > 0 ? i : 1;
        } catch (Throwable t) {
            return 1;
        }
    }

    // ================= Fusion =================

    /**
     * Рецепт синтеза для пары предметов.
     *
     * Сравниваем вручную: у FusionRecipe нет метода сопоставления, есть только
     * два входных стака. Порядок проверяем в обе стороны, потому что в сетке
     * игрок кладёт предметы как придётся, а количество учитываем — у входов
     * рецепта свой размер стака.
     */
    @Nullable
    public static Object findFusion(Level level, ItemStack a, ItemStack b) {
        if (a.isEmpty() || b.isEmpty() || !available() || mFusionInput1 == null) return null;
        for (RecipeHolder<?> holder : recipes(level, FUSION_ID)) {
            Object recipe = holder.value();
            try {
                Object first = mFusionInput1.invoke(recipe);
                Object second = mFusionInput2.invoke(recipe);
                if (!(first instanceof ItemStack in1) || !(second instanceof ItemStack in2)) continue;
                if (fits(in1, a) && fits(in2, b)) return recipe;
                if (fits(in1, b) && fits(in2, a)) return recipe;
            } catch (Throwable ignored) { }
        }
        return null;
    }

    /** Тот же предмет и его хватает по количеству. */
    private static boolean fits(ItemStack required, ItemStack present) {
        return ItemStack.isSameItemSameComponents(required, present)
                && present.getCount() >= required.getCount();
    }

    /** Сколько штук съедает синтез из конкретного стака. */
    public static int fusionCostFor(Object recipe, ItemStack stack) {
        if (mFusionInput1 == null) return 1;
        try {
            for (Method getter : new Method[]{mFusionInput1, mFusionInput2}) {
                Object in = getter.invoke(recipe);
                if (in instanceof ItemStack required
                        && ItemStack.isSameItemSameComponents(required, stack)) {
                    return Math.max(1, required.getCount());
                }
            }
        } catch (Throwable ignored) { }
        return 1;
    }

    public static ItemStack fusionOutput(Object recipe) {
        return stackOf(mFusionOutput, recipe);
    }

    private static ItemStack stackOf(@Nullable Method getter, Object recipe) {
        if (getter == null) return ItemStack.EMPTY;
        try {
            Object out = getter.invoke(recipe);
            return out instanceof ItemStack stack ? stack.copy() : ItemStack.EMPTY;
        } catch (Throwable t) {
            return ItemStack.EMPTY;
        }
    }

    // ================= Combiner =================

    /**
     * Рецепт сборки по содержимому сетки. Combiner в Alchemistry сравнивает
     * НАБОР стаков без учёта расположения, поэтому сетка 5x5 подходит как есть —
     * важно лишь, что непустых стаков ровно столько же, сколько ингредиентов.
     */
    @Nullable
    public static Object findCombiner(Level level, List<ItemStack> inputs) {
        if (inputs.isEmpty() || !available()) return null;
        for (RecipeHolder<?> holder : recipes(level, COMBINER_ID)) {
            Object recipe = holder.value();
            try {
                if (Boolean.TRUE.equals(mCombinerMatch.invoke(recipe, inputs))) return recipe;
            } catch (Throwable ignored) { /* не наш тип рецепта */ }
        }
        return null;
    }

    public static ItemStack combinerOutput(Object recipe) {
        try {
            Object out = mCombinerOutput.invoke(recipe);
            return out instanceof ItemStack stack ? stack.copy() : ItemStack.EMPTY;
        } catch (Throwable t) {
            return ItemStack.EMPTY;
        }
    }

    /**
     * Сколько штук съедает рецепт из конкретного стака.
     *
     * Combiner, в отличие от верстака, забирает не по одной единице, а столько,
     * сколько указано в ингредиенте — поэтому списание считается отдельно, а не
     * стандартным «shrink(1) по каждой занятой ячейке».
     */
    public static int combinerCostFor(Object recipe, ItemStack stack) {
        if (stack.isEmpty()) return 0;
        try {
            Object inputs = mCombinerInput.invoke(recipe);
            if (!(inputs instanceof List<?> list)) return 0;
            for (Object ingredient : list) {
                if (Boolean.TRUE.equals(mIngredientMatches.invoke(ingredient, stack))) {
                    Object count = mIngredientCount.invoke(ingredient);
                    return count instanceof Integer i ? i : 0;
                }
            }
        } catch (Throwable ignored) { }
        return 0;
    }
}
