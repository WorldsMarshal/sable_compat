package com.invfix.rick;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.InventoryMenu;
import org.jetbrains.annotations.Nullable;

/**
 * Доступ к {@link RickPocket} внутри ванильного InventoryMenu. Интерфейс
 * реализует InventoryMenuRickMixin.
 *
 * Карман существует у КАЖДОГО игрока — слоты добавляются в конструкторе меню
 * безусловно, иначе клиент и сервер разъезжаются по числу слотов. Активность
 * определяется родословной, а не наличием кармана.
 */
public final class RickMenuAccess {

    public interface PocketHolder {
        @Nullable RickPocket invfix$pocket();
    }

    private RickMenuAccess() {}

    @Nullable
    public static RickPocket of(Player player) {
        InventoryMenu menu = player.inventoryMenu;
        return menu instanceof PocketHolder holder ? holder.invfix$pocket() : null;
    }
}
