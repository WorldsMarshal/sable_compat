package com.invfix.rick;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/**
 * S2C: снимок трёх танков. Attachment на игроке сам по себе на клиент не едет,
 * а DataSlot в меню передаёт short — 500 000 mB туда не влезет. Поэтому свой пакет,
 * шлётся при открытии меню и при каждом изменении объёма.
 */
public record RickTanksSyncPacket(List<FluidStack> tanks) implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<RickTanksSyncPacket> TYPE =
            new CustomPacketPayload.Type<>(
                    ResourceLocation.fromNamespaceAndPath("sable_compat", "rick_tanks_sync"));

    public static final StreamCodec<RegistryFriendlyByteBuf, RickTanksSyncPacket> STREAM_CODEC =
            StreamCodec.composite(RickTanks.LIST_STREAM_CODEC, RickTanksSyncPacket::tanks, RickTanksSyncPacket::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(RickTanksSyncPacket packet, IPayloadContext context) {
        if (FMLEnvironment.dist != Dist.CLIENT) return;
        context.enqueueWork(() -> com.invfix.rick.client.RickTanksClient.accept(packet.tanks()));
    }
}