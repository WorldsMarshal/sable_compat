package com.invfix.rick.shield.client;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
/**
 * Купола и искры попаданий. Перенесено из ricks_stuff
 * (EvilMortyShieldClientManager) без изменений логики: каждое попадание —
 * купол на 25 тиков и 25–35 искр (50–70 при пробое), искры с гравитацией,
 * трением и отскоком от блоков.
 */
public class ShieldClientManager {
   private static final List<ShieldInstance> ACTIVE_SHIELDS = new CopyOnWriteArrayList();
   private static final List<SparkInstance> ACTIVE_SPARKS = new CopyOnWriteArrayList();

   public static void addShieldEffect(int entityId, Vec3 impactPos) {
      addShieldEffect(entityId, impactPos, (Vec3)null, false);
   }

   public static void addShieldEffect(int entityId, Vec3 impactPos, Vec3 impactDir) {
      addShieldEffect(entityId, impactPos, impactDir, false);
   }

   public static void addShieldEffect(int entityId, Vec3 impactPos, Vec3 impactDir, boolean isBreak) {
      Minecraft mc = Minecraft.getInstance();
      Vec3 finalDir = impactDir;
      Vec3 center;
      Vec3 t1;
      if (finalDir != null && !(finalDir.lengthSqr() < 1.0E-4)) {
         finalDir = finalDir.normalize();
      } else {
         finalDir = new Vec3(0.0, 0.0, 1.0);
         if (mc.level != null) {
            Entity entity = mc.level.getEntity(entityId);
            if (entity != null) {
               center = entity.position().add(0.0, (double)entity.getBbHeight() * 0.5, 0.0);
               t1 = impactPos.subtract(center);
               if (t1.lengthSqr() > 1.0E-4) {
                  finalDir = t1.normalize();
               }
            }
         }
      }

      ACTIVE_SHIELDS.add(new ShieldInstance(entityId, impactPos, finalDir, isBreak));
      Vec3 normal;
      if (finalDir.lengthSqr() < 1.0E-4) {
         normal = new Vec3(0.0, 1.0, 0.0);
      } else {
         normal = finalDir.normalize();
      }

      center = Math.abs(normal.y) < 0.95 ? new Vec3(0.0, 1.0, 0.0) : new Vec3(1.0, 0.0, 0.0);
      t1 = normal.cross(center).normalize();
      Vec3 t2 = normal.cross(t1).normalize();
      RandomSource random = mc.level != null ? mc.level.getRandom() : RandomSource.create();
      int sparkCount = isBreak ? 50 + random.nextInt(21) : 25 + random.nextInt(11);

      for(int i = 0; i < sparkCount; ++i) {
         double theta = random.nextDouble() * 6.283185307179586;
         double cos = Math.cos(theta);
         double sin = Math.sin(theta);
         double forwardSpeed = isBreak ? 0.4 + random.nextDouble() * 0.5 : 0.25 + random.nextDouble() * 0.35;
         double radialSpeed = isBreak ? 0.25 + random.nextDouble() * 0.45 : 0.15 + random.nextDouble() * 0.3;
         double lift = isBreak ? 0.1 + random.nextDouble() * 0.25 : 0.05 + random.nextDouble() * 0.15;
         Vec3 velocity = normal.scale(forwardSpeed).add(t1.scale(cos).add(t2.scale(sin)).scale(radialSpeed)).add(0.0, lift, 0.0);
         int maxAge = (isBreak ? 20 : 16) + random.nextInt(isBreak ? 11 : 9);
         ACTIVE_SPARKS.add(new SparkInstance(impactPos.x, impactPos.y, impactPos.z, velocity.x, velocity.y, velocity.z, maxAge, isBreak));
      }

   }

   public static List<SparkInstance> getActiveSparks() {
      return ACTIVE_SPARKS;
   }

   public static List<ShieldInstance> getActiveShields() {
      return ACTIVE_SHIELDS;
   }

   @SubscribeEvent
   public static void onClientTick(ClientTickEvent.Post event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level == null) {
         ACTIVE_SHIELDS.clear();
         ACTIVE_SPARKS.clear();
      } else if (!mc.isPaused()) {
         ACTIVE_SHIELDS.removeIf(ShieldInstance::tickAndCheckExpired);
         ACTIVE_SPARKS.removeIf((spark) -> {
            return spark.tick(mc.level);
         });
      }
   }

   public static class ShieldInstance {
      private final int entityId;
      private final Vec3 impactPos;
      private final Vec3 impactDir;
      private final boolean isBreak;
      private int age;
      public static final int MAX_AGE = 25;

      public ShieldInstance(int entityId, Vec3 impactPos, Vec3 impactDir, boolean isBreak) {
         this.entityId = entityId;
         this.impactPos = impactPos;
         this.impactDir = impactDir;
         this.isBreak = isBreak;
         this.age = 0;
      }

      public ShieldInstance(int entityId, Vec3 impactPos, Vec3 impactDir) {
         this(entityId, impactPos, impactDir, false);
      }

      public boolean tickAndCheckExpired() {
         ++this.age;
         return this.age >= 25;
      }

      public int getEntityId() {
         return this.entityId;
      }

      public Vec3 getImpactPos() {
         return this.impactPos;
      }

      public Vec3 getImpactDir() {
         return this.impactDir;
      }

      public boolean isBreak() {
         return this.isBreak;
      }

      public int getAge() {
         return this.age;
      }

      public int getMaxAge() {
         return 25;
      }
   }

   public static class SparkInstance {
      private double x;
      private double y;
      private double z;
      private double xo;
      private double yo;
      private double zo;
      private double vx;
      private double vy;
      private double vz;
      private int age;
      private final int maxAge;
      private final List<Vec3> trailHistory;
      private final boolean isBreak;

      public SparkInstance(double x, double y, double z, double vx, double vy, double vz, int maxAge, boolean isBreak) {
         this.trailHistory = new CopyOnWriteArrayList();
         this.x = x;
         this.y = y;
         this.z = z;
         this.xo = x;
         this.yo = y;
         this.zo = z;
         this.vx = vx;
         this.vy = vy;
         this.vz = vz;
         this.age = 0;
         this.maxAge = maxAge;
         this.isBreak = isBreak;
      }

      public SparkInstance(double x, double y, double z, double vx, double vy, double vz, int maxAge) {
         this(x, y, z, vx, vy, vz, maxAge, false);
      }

      public boolean tick(Level level) {
         this.xo = this.x;
         this.yo = this.y;
         this.zo = this.z;
         this.trailHistory.add(0, new Vec3(this.x, this.y, this.z));

         while(this.trailHistory.size() > 6) {
            this.trailHistory.remove(this.trailHistory.size() - 1);
         }

         this.vy -= 0.042;
         this.vx *= 0.96;
         this.vy *= 0.96;
         this.vz *= 0.96;
         double nx = this.x + this.vx;
         double ny = this.y + this.vy;
         double nz = this.z + this.vz;
         if (level != null) {
            BlockPos posY = BlockPos.containing(this.x, ny, this.z);
            if (level.hasChunkAt(posY)) {
               BlockState stateY = level.getBlockState(posY);
               if (!stateY.isAir() && !stateY.getCollisionShape(level, posY).isEmpty()) {
                  this.vy = -this.vy * 0.4;
                  this.vx *= 0.65;
                  this.vz *= 0.65;
                  ny = this.y;
               }
            }

            BlockPos posX = BlockPos.containing(nx, ny, this.z);
            if (level.hasChunkAt(posX)) {
               BlockState stateX = level.getBlockState(posX);
               if (!stateX.isAir() && !stateX.getCollisionShape(level, posX).isEmpty()) {
                  this.vx = -this.vx * 0.4;
                  this.vy *= 0.65;
                  this.vz *= 0.65;
                  nx = this.x;
               }
            }

            BlockPos posZ = BlockPos.containing(nx, ny, nz);
            if (level.hasChunkAt(posZ)) {
               BlockState stateZ = level.getBlockState(posZ);
               if (!stateZ.isAir() && !stateZ.getCollisionShape(level, posZ).isEmpty()) {
                  this.vz = -this.vz * 0.4;
                  this.vx *= 0.65;
                  this.vz *= 0.65;
                  nz = this.z;
               }
            }

            BlockPos posCorner = BlockPos.containing(nx, ny, nz);
            if (level.hasChunkAt(posCorner)) {
               BlockState stateCorner = level.getBlockState(posCorner);
               if (!stateCorner.isAir() && !stateCorner.getCollisionShape(level, posCorner).isEmpty()) {
                  this.vx = -this.vx * 0.4;
                  this.vy = -this.vy * 0.4;
                  this.vz = -this.vz * 0.4;
                  nx = this.x;
                  ny = this.y;
                  nz = this.z;
               }
            }
         }

         this.x = nx;
         this.y = ny;
         this.z = nz;
         ++this.age;
         return this.age >= this.maxAge;
      }

      public double getX(float pt) {
         return Mth.lerp((double)pt, this.xo, this.x);
      }

      public double getY(float pt) {
         return Mth.lerp((double)pt, this.yo, this.y);
      }

      public double getZ(float pt) {
         return Mth.lerp((double)pt, this.zo, this.z);
      }

      public List<Vec3> getTrailHistory() {
         return this.trailHistory;
      }

      public int getAge() {
         return this.age;
      }

      public int getMaxAge() {
         return this.maxAge;
      }

      public double getX() {
         return this.x;
      }

      public double getY() {
         return this.y;
      }

      public double getZ() {
         return this.z;
      }

      public double getVx() {
         return this.vx;
      }

      public double getVy() {
         return this.vy;
      }

      public double getVz() {
         return this.vz;
      }

      public boolean isBreak() {
         return this.isBreak;
      }
   }
}
