package com.invfix.rick.shield;

import com.invfix.rick.timedevice.ItemEnergy;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Модули щита. Две версии одного предмета, отличаются ёмкостью, ценой урона и
 * рецептом (см. {@link ShieldRegistry}):
 *  - модуль управления щитом (Рик): 10 000 000 FE, урон × 3 FE;
 *  - модуль щита (обычный): 5 000 000 FE, урон × 200 FE.
 *
 * Модуль управления щитом — энергетический щит злого Морти из ricks_stuff
 * (EvilMortyEnergyShieldItem), переведённый с «десяти сердец и кулдауна» на FE.
 *
 * Отличия от оригинала, заданные для сборки:
 *  - закрывает ЛЮБОЙ урон, кроме падения в пустоту (в оригинале — снаряды,
 *    а с опцией protectAllDamage ещё взрывы и атаки мобов/игроков);
 *  - платит энергией: урон × {@link #fePerDamage()} FE за удар;
 *  - работает из любого слота инвентаря, пока включён (ПКМ);
 *  - заряжается любой FE-станцией и, у Рика, прямо в инвентаре.
 *
 * Визуал, звук и отражение снарядов перенесены из оригинала без изменений,
 * см. {@link ShieldEvents} и пакет client.
 */
public class ShieldModuleItem extends Item {

    /** Модуль управления щитом (Рик). Ёмкость в задании не была указана — как у энтропийного модуля. */
    public static final int CONTROL_CAPACITY = 10_000_000;
    public static final int CONTROL_FE_PER_DAMAGE = 3;

    /** Модуль щита (обычный): ёмкость и цена — по заданию. */
    public static final int BASIC_CAPACITY = 5_000_000;
    public static final int BASIC_FE_PER_DAMAGE = 200;

    private final int capacity;
    private final int fePerDamage;
    /** Ключ строки описания в подсказке. */
    private final String descKey;

    public ShieldModuleItem(Properties props, int capacity, int fePerDamage, String descKey) {
        super(props);
        this.capacity = capacity;
        this.fePerDamage = fePerDamage;
        this.descKey = descKey;
    }

    public int capacity() { return capacity; }

    public int fePerDamage() { return fePerDamage; }

    /** Сколько урона выдержит полный модуль. */
    public int maxAbsorbableDamage() { return capacity / fePerDamage; }

    public static int energy(ItemStack stack) {
        return stack.getItem() instanceof ShieldModuleItem m ? ItemEnergy.get(stack, m.capacity) : 0;
    }

    public static int capacity(ItemStack stack) {
        return stack.getItem() instanceof ShieldModuleItem m ? m.capacity : 0;
    }

    /** По умолчанию включён: свежесобранный щит без заряда всё равно ничего не держит. */
    public static boolean enabled(ItemStack stack) {
        Boolean b = stack.get(ShieldRegistry.ENABLED.get());
        return b == null || b;
    }

    public static void setEnabled(ItemStack stack, boolean value) {
        stack.set(ShieldRegistry.ENABLED.get(), value);
    }

    /** Включён и держит хотя бы единицу урона. */
    public static boolean usable(ItemStack stack) {
        return stack.getItem() instanceof ShieldModuleItem m && enabled(stack) && energy(stack) >= m.fePerDamage;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            boolean now = !enabled(stack);
            setEnabled(stack, now);
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    now ? SoundEvents.BEACON_ACTIVATE : SoundEvents.BEACON_DEACTIVATE,
                    SoundSource.PLAYERS, 0.5F, now ? 1.8F : 1.4F);
            player.displayClientMessage(Component.translatable(now
                            ? "message.sable_compat.shield_module.on"
                            : "message.sable_compat.shield_module.off")
                    .withStyle(now ? ChatFormatting.AQUA : ChatFormatting.GRAY), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    // ── инвентарь: включённые модули ──────────────────────────────────────

    /**
     * Включённые модули инвентаря, дешёвые за единицу урона — первыми (при равной
     * цене — по порядку слотов). Обход через Container-интерфейс инвентаря:
     * сетка, броня и левая рука одним циклом.
     */
    private static List<ItemStack> enabledModules(Player player) {
        var inv = player.getInventory();
        List<ItemStack> list = new ArrayList<>();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.getItem() instanceof ShieldModuleItem && enabled(s)) list.add(s);
        }
        list.sort(Comparator.comparingInt(s -> ((ShieldModuleItem) s.getItem()).fePerDamage));  // сортировка устойчивая
        return list;
    }

    /** Хоть один включённый модуль держит хотя бы единицу урона. */
    public static boolean anyUsable(Player player) {
        var inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (usable(inv.getItem(i))) return true;
        }
        return false;
    }

    /**
     * Погасить урон включёнными модулями, списав FE. Модули идут по очереди,
     * дешёвые первыми; каждый платит урон × свою цену. Если модулю не хватает на
     * остаток удара, он гасит столько целых единиц, сколько оплачено, и удар идёт
     * к следующему. Модуль, у которого меньше цены одной единицы, пропускается.
     *
     * @return результат: списано ли хоть что-то и непогашенный остаток урона
     *         (0 — погашен целиком). Признак списания отдельный: при огромном уроне
     *         (/kill — Float.MAX_VALUE) вычитание единиц не меняет число.
     */
    public static Absorbed absorb(Player player, float amount) {
        float remaining = amount;
        boolean paid = false;
        for (ItemStack s : enabledModules(player)) {
            if (!(remaining > 0)) break;
            ShieldModuleItem m = (ShieldModuleItem) s.getItem();
            int cost = m.fePerDamage;
            int stored = energy(s);
            if (stored < cost) continue;
            double need = Math.ceil((double) remaining * cost);
            if (need <= stored) {
                ItemEnergy.drain(s, (int) need, m.capacity);
                remaining = 0;
                paid = true;
            } else {
                int units = stored / cost;
                ItemEnergy.drain(s, units * cost, m.capacity);
                remaining -= units;
                paid = true;
            }
        }
        return new Absorbed(paid, Math.max(0, remaining));
    }

    public record Absorbed(boolean paid, float remaining) {}

    // ── полоса и подсказка ─────────────────────────────────────────────────

    @Override public boolean isBarVisible(ItemStack stack) { return energy(stack) < capacity; }

    @Override public int getBarWidth(ItemStack stack) {
        return Math.round(13.0F * energy(stack) / capacity);
    }

    @Override public int getBarColor(ItemStack stack) { return 0x44D8FF; }

    @Override
    public boolean isFoil(ItemStack stack) {
        return enabled(stack) && energy(stack) >= fePerDamage;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        lines.add(Component.translatable(enabled(stack)
                        ? "tooltip.sable_compat.shield_module.state_on"
                        : "tooltip.sable_compat.shield_module.state_off")
                .withStyle(enabled(stack) ? ChatFormatting.AQUA : ChatFormatting.DARK_GRAY));
        lines.add(Component.translatable("tooltip.sable_compat.shield_module.energy",
                        ItemEnergy.format(energy(stack)), ItemEnergy.format(capacity))
                .withStyle(ChatFormatting.AQUA));
        lines.add(Component.translatable("tooltip.sable_compat.shield_module.cost", fePerDamage)
                .withStyle(ChatFormatting.GRAY));
        lines.add(Component.translatable("tooltip.sable_compat.shield_module.holds",
                        String.format("%,d", energy(stack) / fePerDamage).replace(',', ' '),
                        String.format("%,d", maxAbsorbableDamage()).replace(',', ' '))
                .withStyle(ChatFormatting.GRAY));
        lines.add(Component.translatable(descKey).withStyle(ChatFormatting.DARK_AQUA));
        lines.add(Component.translatable("tooltip.sable_compat.shield_module.hint")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
