package com.invfix.rick.shield.client;

import com.invfix.rick.shield.ShieldEffectPacket;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Клиентская половина ShieldEffectPacket — как ClientHandler в оригинале. */
public final class ShieldClientPackets {

    private ShieldClientPackets() {}

    public static void handle(ShieldEffectPacket p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ShieldClientManager.addShieldEffect(p.entityId(),
                new Vec3(p.impactX(), p.impactY(), p.impactZ()),
                new Vec3(p.dirX(), p.dirY(), p.dirZ()), p.isBreak()));
    }
}
