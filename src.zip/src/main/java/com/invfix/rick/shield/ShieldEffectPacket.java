package com.invfix.rick.shield;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Сервер → клиент: попадание в щит. Порт S2CEvilMortyShieldEffectPacket из
 * ricks_stuff: сущность, точка удара на эллипсоиде, направление удара и
 * признак пробоя (красный купол вместо голубого).
 */
public record ShieldEffectPacket(int entityId, double impactX, double impactY, double impactZ,
                                 double dirX, double dirY, double dirZ, boolean isBreak)
        implements CustomPacketPayload {

    public static final Type<ShieldEffectPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "shield_effect"));

    public static final StreamCodec<FriendlyByteBuf, ShieldEffectPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, p) -> {
                        buf.writeInt(p.entityId());
                        buf.writeDouble(p.impactX()); buf.writeDouble(p.impactY()); buf.writeDouble(p.impactZ());
                        buf.writeDouble(p.dirX()); buf.writeDouble(p.dirY()); buf.writeDouble(p.dirZ());
                        buf.writeBoolean(p.isBreak());
                    },
                    buf -> new ShieldEffectPacket(buf.readInt(),
                            buf.readDouble(), buf.readDouble(), buf.readDouble(),
                            buf.readDouble(), buf.readDouble(), buf.readDouble(),
                            buf.readBoolean()));

    @Override
    public Type<ShieldEffectPacket> type() { return TYPE; }
}
