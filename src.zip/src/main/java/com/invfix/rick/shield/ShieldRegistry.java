package com.invfix.rick.shield;

import com.invfix.rick.timedevice.ItemEnergy;
import com.mojang.serialization.Codec;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Реестр модулей щита.
 *
 * Модуль управления щитом — эксклюзив Рика: рецепт tier 137, как у пульта и
 * энергокуба. Обычный модуль щита — tier 5 (и облегчённый tier 137).
 */
public final class ShieldRegistry {

    private static final String MODID = "sable_compat";

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<DataComponentType<?>> COMPONENTS =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, MODID);
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, MODID);

    /** Вкл/выкл. Синхронизируется: от него зависят подсказка и блеск. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Boolean>> ENABLED =
            COMPONENTS.register("shield_enabled", () -> DataComponentType.<Boolean>builder()
                    .persistent(Codec.BOOL)
                    .networkSynchronized(ByteBufCodecs.BOOL)
                    .build());

    /** Стек не собирается: заряд живёт в компоненте, как у пульта и модуля энтропии. */
    public static final DeferredItem<ShieldModuleItem> SHIELD_MODULE =
            ITEMS.register("shield_control_module",
                    () -> new ShieldModuleItem(new Item.Properties().stacksTo(1).fireResistant(),
                            ShieldModuleItem.CONTROL_CAPACITY, ShieldModuleItem.CONTROL_FE_PER_DAMAGE,
                            "tooltip.sable_compat.shield_module.desc"));

    /**
     * Модуль щита — обычная версия: тот же щит, 5 000 000 FE, урон × 200 FE.
     * Рецепт tier 5 (очень дорогой) и облегчённый tier 137.
     */
    public static final DeferredItem<ShieldModuleItem> BASIC_SHIELD_MODULE =
            ITEMS.register("shield_module",
                    () -> new ShieldModuleItem(new Item.Properties().stacksTo(1).fireResistant(),
                            ShieldModuleItem.BASIC_CAPACITY, ShieldModuleItem.BASIC_FE_PER_DAMAGE,
                            "tooltip.sable_compat.shield_module.desc_basic"));

    /** anti_portal_deflect.ogg из ricks_stuff — звук, который играет оригинальный щит. */
    public static final DeferredHolder<SoundEvent, SoundEvent> DEFLECT =
            SOUNDS.register("shield_deflect", () -> SoundEvent.createVariableRangeEvent(
                    ResourceLocation.fromNamespaceAndPath(MODID, "shield_deflect")));

    private ShieldRegistry() {}

    public static void register(IEventBus modEventBus) {
        COMPONENTS.register(modEventBus);
        ITEMS.register(modEventBus);
        SOUNDS.register(modEventBus);
        modEventBus.addListener(ShieldRegistry::onRegisterCapabilities);
        modEventBus.addListener(ShieldRegistry::onBuildCreativeTabs);
    }

    /** Та же capability, что ищет любая FE-станция. */
    private static void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
        event.registerItem(Capabilities.EnergyStorage.ITEM,
                (stack, ctx) -> new ItemEnergy(stack, ShieldModuleItem.capacity(stack)),
                SHIELD_MODULE.get(), BASIC_SHIELD_MODULE.get());
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(SHIELD_MODULE);
            event.accept(BASIC_SHIELD_MODULE);
        }
    }
}
