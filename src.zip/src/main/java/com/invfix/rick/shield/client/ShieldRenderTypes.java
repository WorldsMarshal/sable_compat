package com.invfix.rick.shield.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.RenderType;

/**
 * Два типа рендера купола — ровно FORCEFIELD_DOME и FORCEFIELD_ADDITIVE из
 * PortalRenderTypes ricks_stuff: шейдер молнии, без отсечения граней,
 * запись только цвета. Первый — обычная прозрачность (тело купола), второй —
 * аддитивная (свечение, искры).
 *
 * Наследование от RenderType — тот же приём, что в оригинале: без него
 * защищённые состояния RenderStateShard недоступны.
 */
public final class ShieldRenderTypes extends RenderType {

    private ShieldRenderTypes(String name, VertexFormat format, VertexFormat.Mode mode, int bufferSize,
                              boolean affectsCrumbling, boolean sortOnUpload,
                              Runnable setupState, Runnable clearState) {
        super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setupState, clearState);
    }

    public static final RenderType FORCEFIELD_DOME = create("sable_compat_shield_dome",
            DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS, 256, false, true,
            CompositeState.builder()
                    .setShaderState(RENDERTYPE_LIGHTNING_SHADER)
                    .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
                    .setCullState(NO_CULL)
                    .setDepthTestState(LEQUAL_DEPTH_TEST)
                    .setWriteMaskState(COLOR_WRITE)
                    .createCompositeState(false));

    public static final RenderType FORCEFIELD_ADDITIVE = create("sable_compat_shield_additive",
            DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS, 256, false, true,
            CompositeState.builder()
                    .setShaderState(RENDERTYPE_LIGHTNING_SHADER)
                    .setTransparencyState(LIGHTNING_TRANSPARENCY)
                    .setCullState(NO_CULL)
                    .setDepthTestState(LEQUAL_DEPTH_TEST)
                    .setWriteMaskState(COLOR_WRITE)
                    .createCompositeState(false));
}
