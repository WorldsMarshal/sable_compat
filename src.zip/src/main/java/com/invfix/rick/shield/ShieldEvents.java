package com.invfix.rick.shield;

import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.network.protocol.game.ClientboundTeleportEntityPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Работа щита. Геометрия, отражение снарядов, звуки и пакет эффекта — из
 * CommonEvents ricks_stuff (deflectProjectileWithShield, triggerShieldDeflect).
 * Что изменено — только правило «что закрывается и чем платится».
 */
@EventBusSubscriber(modid = "sable_compat")
public final class ShieldEvents {

    private ShieldEvents() {}

    /** Полуоси эллипсоида щита, как в оригинале (RADIUS_X/Y/Z рендера). */
    private static final double RX = 1.35, RY = 1.45, RZ = 1.35;

    /** Радиус рассылки эффекта, как в оригинале. */
    private static final double EFFECT_RANGE = 64.0;

    /**
     * Приоритет LOW — на ступень выше LOWEST, и это не произвол.
     *
     * На LOWEST у нас уже стоит единая точка смягчения урона
     * (ViltrumiteImmunityHandler#onIncomingDamage): процентные срезы и пул
     * DamageTolerance, который тратится. Два обработчика на одном
     * приоритете идут в неопределённом порядке, и если бы смягчение
     * сработало первым, оно списало бы пул, а щит потом всё равно отменил бы
     * удар — защита тратилась бы дважды. На LOW щит гарантированно первый:
     * он внешний слой, до тела удар доходит только если щит его не закрыл.
     *
     * Урон здесь — входящий урон атаки: после модов на HIGHEST..NORMAL, до
     * брони и до смягчения. За него и платится урон × цена модуля (3 FE у модуля
     * управления, 200 FE у обычного; дешёвые модули тратятся первыми).
     *
     * Закрывается всё, кроме падения в пустоту. Заряда не хватает на весь
     * удар — щит гасит, сколько оплачено, остальное проходит дальше, в
     * смягчение. Так /kill по-прежнему убивает: его урон — Float.MAX_VALUE.
     */
    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide()) return;
        DamageSource source = event.getSource();
        if (source.is(DamageTypes.FELL_OUT_OF_WORLD)) return;

        float amount = event.getAmount();
        if (!(amount > 0)) return;

        ShieldModuleItem.Absorbed result = ShieldModuleItem.absorb(player, amount);
        if (!result.paid()) return;               // ни один модуль ничего не погасил
        boolean full = result.remaining() <= 0;
        if (full) event.setCanceled(true);
        else event.setAmount(result.remaining());

        // Пробой — щит больше не держит ни единицы урона. Купол красный.
        boolean isBreak = !ShieldModuleItem.anyUsable(player);

        Entity direct = source.getDirectEntity();
        if (full && direct instanceof Projectile projectile) {
            deflectProjectile(player, projectile, isBreak);
        } else {
            Vec3 srcPos = source.getSourcePosition() != null ? source.getSourcePosition()
                    : (source.getEntity() != null ? source.getEntity().position() : null);
            triggerDeflect(player, srcPos, isBreak);
        }
    }

    /** deflectProjectileWithShield: отражение снаряда от эллипсоида щита. */
    private static void deflectProjectile(Player player, Projectile projectile, boolean isBreak) {
        Vec3 center = player.position().add(0.0, player.getEyeHeight() * 0.5, 0.0);
        Vec3 projPos = projectile.position();
        Vec3 projVel = projectile.getDeltaMovement();
        Vec3 toProj = projPos.subtract(center);
        Vec3 dir;
        if (toProj.lengthSqr() > 1.0E-4) dir = toProj.normalize();
        else if (projVel.lengthSqr() > 1.0E-4) dir = projVel.reverse().normalize();
        else dir = player.getLookAngle();

        Vec3 impact = new Vec3(center.x + dir.x * RX, center.y + dir.y * RY, center.z + dir.z * RZ);
        Vec3 normal = dir;
        double speed = Math.max(1.4, projVel.length() * 1.25);
        Vec3 vNew = projVel.subtract(normal.scale(2.0 * projVel.dot(normal)));
        vNew = vNew.dot(normal) < 0.25 ? normal.scale(speed) : vNew.normalize().scale(speed);

        double push = 0.35;
        projectile.setPos(impact.x + normal.x * push, impact.y + normal.y * push, impact.z + normal.z * push);
        projectile.setDeltaMovement(vNew);
        projectile.hasImpulse = true;
        projectile.hurtMarked = true;
        double horiz = Math.sqrt(vNew.x * vNew.x + vNew.z * vNew.z);
        float yRot = (float) (Mth.atan2(vNew.x, vNew.z) * 57.29577951308232);
        float xRot = (float) (Mth.atan2(vNew.y, horiz) * 57.29577951308232);
        projectile.setYRot(yRot);
        projectile.setXRot(xRot);
        projectile.yRotO = yRot;
        projectile.xRotO = xRot;
        if (projectile instanceof AbstractArrow arrow) {
            arrow.setCritArrow(false);
            arrow.setOwner(player);
            arrow.tickCount = 0;
        }
        if (projectile.level() instanceof ServerLevel sl) {
            sl.getChunkSource().broadcast(projectile, new ClientboundSetEntityMotionPacket(projectile));
            sl.getChunkSource().broadcast(projectile, new ClientboundTeleportEntityPacket(projectile));
        }
        effects(player, impact, dir, isBreak);
    }

    /** triggerShieldDeflect: удар не снарядом — только вспышка в сторону источника. */
    private static void triggerDeflect(Player player, Vec3 sourcePos, boolean isBreak) {
        Vec3 center = player.position().add(0.0, player.getEyeHeight() * 0.5, 0.0);
        Vec3 dir;
        if (sourcePos != null) {
            Vec3 diff = sourcePos.subtract(center);
            dir = diff.lengthSqr() > 1.0E-4 ? diff.normalize() : player.getLookAngle();
        } else {
            dir = player.getLookAngle();
        }
        Vec3 impact = new Vec3(center.x + dir.x * RX, center.y + dir.y * RY, center.z + dir.z * RZ);
        effects(player, impact, dir, isBreak);
    }

    /**
     * Звук и пакет — как в оригинале. Одно исправление: там пакет уходил всем
     * в радиусе И отдельно самому игроку, и у него купол и искры рисовались
     * дважды. Здесь игрок уже входит в рассылку по радиусу.
     */
    private static void effects(Player player, Vec3 impact, Vec3 dir, boolean isBreak) {
        if (isBreak) {
            player.level().playSound(null, impact.x, impact.y, impact.z, SoundEvents.ITEM_BREAK,
                    SoundSource.PLAYERS, 1.5F, 0.8F + player.getRandom().nextFloat() * 0.2F);
            player.level().playSound(null, impact.x, impact.y, impact.z, SoundEvents.ANVIL_LAND,
                    SoundSource.PLAYERS, 0.8F, 1.6F);
        } else {
            player.level().playSound(null, impact.x, impact.y, impact.z, ShieldRegistry.DEFLECT.get(),
                    SoundSource.PLAYERS, 1.2F, 1.1F + player.getRandom().nextFloat() * 0.2F);
        }
        if (player.level() instanceof ServerLevel sl) {
            PacketDistributor.sendToPlayersNear(sl, (ServerPlayer) null,
                    player.getX(), player.getY(), player.getZ(), EFFECT_RANGE,
                    new ShieldEffectPacket(player.getId(), impact.x, impact.y, impact.z,
                            dir.x, dir.y, dir.z, isBreak),
                    new CustomPacketPayload[0]);
        }
    }
}
