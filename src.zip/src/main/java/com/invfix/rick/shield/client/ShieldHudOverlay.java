package com.invfix.rick.shield.client;

import com.invfix.rick.shield.ShieldModuleItem;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffects;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;

/**
 * Полупрозрачные пульсирующие сердца щита поверх полоски здоровья.
 * Перенесено из ricks_stuff (EvilMortyShieldHudOverlay) вместе с текстурой
 * shield_hearts.png: те же координаты, пульс и подпрыгивание при регенерации.
 *
 * Изменено одно: в оригинале сердца — это десять зарядов щита. У нас заряд
 * в FE, поэтому число сердец — доля заряда включённых модулей от их общей
 * ёмкости, с округлением вверх: пока щит держит хоть что-то, видно хотя бы
 * одно сердце.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class ShieldHudOverlay {

    private ShieldHudOverlay() {}

    public static final ResourceLocation SHIELD_HEARTS_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/gui/shield_hearts.png");
    private static final int MAX_HEARTS = 10;

    private static int savedLeft;
    private static int savedTop;
    private static boolean hasCoords;

    @SubscribeEvent
    public static void onRenderGuiOverlayPre(RenderGuiLayerEvent.Pre event) {
        if (!event.getName().equals(VanillaGuiLayers.PLAYER_HEALTH)) return;
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null || player.isCreative() || player.isSpectator()) return;
        if (hearts(player) <= 0) return;
        savedLeft = event.getGuiGraphics().guiWidth() / 2 - 91;
        savedTop = event.getGuiGraphics().guiHeight() - Minecraft.getInstance().gui.leftHeight;
        hasCoords = true;
    }

    @SubscribeEvent
    public static void onRenderGuiOverlayPost(RenderGuiLayerEvent.Post event) {
        if (!event.getName().equals(VanillaGuiLayers.PLAYER_HEALTH)) return;
        if (!hasCoords) return;
        hasCoords = false;
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null || player.isCreative() || player.isSpectator()) return;
        int hearts = hearts(player);
        if (hearts <= 0) return;

        int regen = -1;
        if (player.hasEffect(MobEffects.REGENERATION)) {
            regen = Minecraft.getInstance().gui.getGuiTicks() % Mth.ceil(player.getMaxHealth() + 5.0F);
        }
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        float time = ((float) Minecraft.getInstance().gui.getGuiTicks() + partialTick) * 0.12F;
        float pulse = Mth.sin(time) * 0.5F + 0.5F;
        float alpha = 0.3F + 0.3F * pulse;
        GuiGraphics g = event.getGuiGraphics();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        g.setColor(1.0F, 1.0F, 1.0F, alpha);
        for (int i = 0; i < hearts; i++) {
            int x = savedLeft + i * 8;
            int y = savedTop + (i == regen ? -2 : 0);
            g.blit(SHIELD_HEARTS_TEXTURE, x, y, 9.0F, 0.0F, 9, 9, 64, 32);
        }
        g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }

    /** Сердец по доле заряда включённых модулей; 0 — щит ничего не держит. */
    private static int hearts(LocalPlayer player) {
        long energy = 0, capacity = 0;
        var inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            var s = inv.getItem(i);
            if (s.getItem() instanceof ShieldModuleItem && ShieldModuleItem.enabled(s)) {
                energy += ShieldModuleItem.energy(s);
                capacity += ShieldModuleItem.capacity(s);
            }
        }
        if (capacity == 0 || !ShieldModuleItem.anyUsable(player)) return 0;
        return (int) Math.max(1, Math.min(MAX_HEARTS, Math.ceil(MAX_HEARTS * (double) energy / capacity)));
    }
}
