package com.invfix.rick.shield.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(
   modid = "sable_compat",
   value = {Dist.CLIENT}
)
/**
 * Рендер купола щита. Перенесено из ricks_stuff (EvilMortyShieldRenderer)
 * без изменений: эллипсоид 1.35×1.45×1.35, 24×36 полос, волна от точки
 * удара, френель, плазменный шум, звезда удара и искры со шлейфом. Голубой
 * при обычном попадании, красный при пробое.
 */
public class ShieldRenderer {
   private static final float RADIUS_X = 1.35F;
   private static final float RADIUS_Y = 1.45F;
   private static final float RADIUS_Z = 1.35F;
   private static final int LAT_BANDS = 24;
   private static final int LON_BANDS = 36;

   @SubscribeEvent
   public static void onRenderLevelStage(RenderLevelStageEvent event) {
      if (event.getStage() == Stage.AFTER_TRANSLUCENT_BLOCKS) {
         List<ShieldClientManager.ShieldInstance> shields = ShieldClientManager.getActiveShields();
         List<ShieldClientManager.SparkInstance> sparks = ShieldClientManager.getActiveSparks();
         if (!shields.isEmpty() || !sparks.isEmpty()) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level != null && mc.player != null) {
               PoseStack poseStack = event.getPoseStack();
               if (poseStack != null) {
                  Camera camera = event.getCamera();
                  Vec3 camPos = camera.getPosition();
                  float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
                  float gameTime = (float)mc.level.getGameTime() + partialTick;
                  MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();
                  boolean renderedShields = false;
                  boolean renderedSparks = false;
                  VertexConsumer domeConsumer;
                  if (!shields.isEmpty()) {
                     domeConsumer = bufferSource.getBuffer(ShieldRenderTypes.FORCEFIELD_DOME);
                     Iterator var13 = shields.iterator();

                     float currentAge;
                     while(var13.hasNext()) {
                        ShieldClientManager.ShieldInstance shield = (ShieldClientManager.ShieldInstance)var13.next();
                        Entity entity = mc.level.getEntity(shield.getEntityId());
                        if (entity != null && entity.isAlive()) {
                           double px = Mth.lerp((double)partialTick, entity.xOld, entity.getX());
                           double py = Mth.lerp((double)partialTick, entity.yOld, entity.getY());
                           double pz = Mth.lerp((double)partialTick, entity.zOld, entity.getZ());
                           Vec3 center = new Vec3(px, py + (double)entity.getBbHeight() * 0.5, pz);
                           currentAge = (float)shield.getAge() + partialTick;
                           currentAge = Mth.clamp(currentAge / (float)shield.getMaxAge(), 0.0F, 1.0F);
                           poseStack.pushPose();
                           poseStack.translate(center.x - camPos.x, center.y - camPos.y, center.z - camPos.z);
                           Matrix4f matrix = poseStack.last().pose();
                           renderShieldDomeBase(matrix, domeConsumer, center, camPos, shield.getImpactDir(), currentAge, gameTime, shield.isBreak());
                           poseStack.popPose();
                           renderedShields = true;
                        }
                     }

                     if (renderedShields) {
                        bufferSource.endBatch(ShieldRenderTypes.FORCEFIELD_DOME);
                     }

                     VertexConsumer additiveConsumer = bufferSource.getBuffer(ShieldRenderTypes.FORCEFIELD_ADDITIVE);
                     Iterator var29 = shields.iterator();

                     while(var29.hasNext()) {
                        ShieldClientManager.ShieldInstance shield = (ShieldClientManager.ShieldInstance)var29.next();
                        Entity entity = mc.level.getEntity(shield.getEntityId());
                        if (entity != null && entity.isAlive()) {
                           double px = Mth.lerp((double)partialTick, entity.xOld, entity.getX());
                           double py = Mth.lerp((double)partialTick, entity.yOld, entity.getY());
                           double pz = Mth.lerp((double)partialTick, entity.zOld, entity.getZ());
                           Vec3 center = new Vec3(px, py + (double)entity.getBbHeight() * 0.5, pz);
                           currentAge = (float)shield.getAge() + partialTick;
                           float t = Mth.clamp(currentAge / (float)shield.getMaxAge(), 0.0F, 1.0F);
                           poseStack.pushPose();
                           poseStack.translate(center.x - camPos.x, center.y - camPos.y, center.z - camPos.z);
                           Matrix4f matrix = poseStack.last().pose();
                           renderShieldDomeAdditive(matrix, additiveConsumer, center, camPos, shield.getImpactDir(), t, gameTime, shield.isBreak());
                           poseStack.popPose();
                        }
                     }

                     renderedSparks = true;
                  }

                  if (!sparks.isEmpty()) {
                     domeConsumer = bufferSource.getBuffer(ShieldRenderTypes.FORCEFIELD_ADDITIVE);
                     poseStack.pushPose();
                     Matrix4f sparkPose = poseStack.last().pose();
                     renderSparks(sparkPose, domeConsumer, sparks, camPos, camera, partialTick);
                     poseStack.popPose();
                     renderedSparks = true;
                  }

                  if (renderedShields || renderedSparks) {
                     bufferSource.endBatch(ShieldRenderTypes.FORCEFIELD_ADDITIVE);
                  }

               }
            }
         }
      }
   }

   private static void renderShieldDomeBase(Matrix4f pose, VertexConsumer domeConsumer, Vec3 worldCenter, Vec3 camPos, Vec3 impactDir, float t, float gameTime, boolean isBreak) {
      float uFront = t <= 0.35F ? t / 0.35F : 1.0F;
      float fade = 1.0F;
      if (t > 0.65F) {
         fade = Math.max(0.0F, 1.0F - (t - 0.65F) / 0.35F);
      }

      Vec3 toCam = camPos.subtract(worldCenter);
      double camDist = toCam.length();
      Vec3 camViewDir = camDist > 1.0E-4 ? toCam.scale(1.0 / camDist) : new Vec3(0.0, 1.0, 0.0);
      Vec3 normImpactDir = impactDir != null && !(impactDir.lengthSqr() < 1.0E-4) ? impactDir.normalize() : new Vec3(0.0, 0.0, 1.0);
      float dx = (float)normImpactDir.x;
      float dy = (float)normImpactDir.y;
      float dz = (float)normImpactDir.z;

      for(int lat = 0; lat < 24; ++lat) {
         float theta0 = (float)((double)lat * Math.PI / 24.0);
         float theta1 = (float)((double)(lat + 1) * Math.PI / 24.0);
         float sinTheta0 = Mth.sin(theta0);
         float cosTheta0 = Mth.cos(theta0);
         float sinTheta1 = Mth.sin(theta1);
         float cosTheta1 = Mth.cos(theta1);

         for(int lon = 0; lon < 36; ++lon) {
            float phi0 = (float)((double)(lon * 2) * Math.PI / 36.0);
            float phi1 = (float)((double)((lon + 1) * 2) * Math.PI / 36.0);
            float sinPhi0 = Mth.sin(phi0);
            float cosPhi0 = Mth.cos(phi0);
            float sinPhi1 = Mth.sin(phi1);
            float cosPhi1 = Mth.cos(phi1);
            float n00x = sinTheta0 * cosPhi0;
            float n00y = cosTheta0;
            float n00z = sinTheta0 * sinPhi0;
            float n01x = sinTheta0 * cosPhi1;
            float n01y = cosTheta0;
            float n01z = sinTheta0 * sinPhi1;
            float n11x = sinTheta1 * cosPhi1;
            float n11y = cosTheta1;
            float n11z = sinTheta1 * sinPhi1;
            float n10x = sinTheta1 * cosPhi0;
            float n10y = cosTheta1;
            float n10z = sinTheta1 * sinPhi0;
            float x00 = n00x * 1.35F;
            float y00 = n00y * 1.45F;
            float z00 = n00z * 1.35F;
            float x01 = n01x * 1.35F;
            float y01 = n01y * 1.45F;
            float z01 = n01z * 1.35F;
            float x11 = n11x * 1.35F;
            float y11 = n11y * 1.45F;
            float z11 = n11z * 1.35F;
            float x10 = n10x * 1.35F;
            float y10 = n10y * 1.45F;
            float z10 = n10z * 1.35F;
            float avgNx = 0.25F * (n00x + n01x + n11x + n10x);
            float avgNy = 0.25F * (n00y + n01y + n11y + n10y);
            float avgNz = 0.25F * (n00z + n01z + n11z + n10z);
            float nLen = Mth.sqrt(avgNx * avgNx + avgNy * avgNy + avgNz * avgNz);
            if (nLen > 1.0E-4F) {
               avgNx /= nLen;
               avgNy /= nLen;
               avgNz /= nLen;
            }

            float dotImpact = avgNx * dx + avgNy * dy + avgNz * dz;
            dotImpact = Mth.clamp(dotImpact, -1.0F, 1.0F);
            float angle = (float)Math.acos((double)dotImpact);
            float u = angle / 3.1415927F;
            float noise = (float)Math.sin((double)(avgNx * 12.0F + avgNy * 14.0F + gameTime * 0.2F)) * 0.025F;
            float uEffective = u + noise;
            if (!(uEffective > uFront + 0.05F)) {
               float distToFront = Math.abs(uEffective - uFront);
               float edgeFlash = 0.0F;
               if (t <= 0.4F && distToFront < 0.1F) {
                  edgeFlash = 1.0F - distToFront / 0.1F;
                  if (t > 0.35F) {
                     edgeFlash *= 1.0F - (t - 0.35F) / 0.05F;
                  }
               }

               float impactFlash = 0.0F;
               if (t <= 0.3F && u < 0.35F) {
                  impactFlash = (1.0F - t / 0.3F) * (1.0F - u / 0.35F);
               }

               float originGlow = 0.0F;
               float dotCam;
               float fresnel;
               if (t <= 0.35F && u < 0.32F) {
                  dotCam = 1.0F - u / 0.32F;
                  fresnel = 1.0F - t / 0.35F;
                  originGlow = dotCam * dotCam * fresnel;
               }

               dotCam = (float)Math.abs((double)avgNx * camViewDir.x + (double)avgNy * camViewDir.y + (double)avgNz * camViewDir.z);
               dotCam = Math.min(1.0F, dotCam);
               fresnel = (float)Math.pow((double)(1.0F - dotCam), 2.2);
               float p1 = Mth.sin(avgNx * 4.2F + avgNy * 5.0F + gameTime * 0.18F);
               float p2 = Mth.cos(avgNz * 4.5F - avgNy * 3.8F + gameTime * 0.15F);
               float p3 = Mth.sin((avgNx + avgNz) * 5.5F + gameTime * 0.22F);
               float plasmaVal = (p1 * p2 + p3) * 0.5F + 0.5F;
               float r;
               float g;
               float b;
               if (isBreak) {
                  r = 1.0F;
                  g = 0.12F + 0.25F * (edgeFlash + impactFlash);
                  b = 0.12F;
               } else {
                  r = 0.08F + 0.35F * (edgeFlash + impactFlash) + 0.55F * originGlow;
                  g = 0.82F + 0.18F * (edgeFlash + impactFlash) + 0.18F * originGlow;
                  b = 1.0F;
               }

               float alpha = (0.1F + 0.42F * fresnel + 0.12F * plasmaVal + 0.55F * edgeFlash + 0.4F * impactFlash + 0.55F * originGlow) * fade;
               alpha = Mth.clamp(alpha, 0.0F, 0.95F);
               domeConsumer.addVertex(pose, x00, y00, z00).setColor(r, g, b, alpha);
               domeConsumer.addVertex(pose, x01, y01, z01).setColor(r, g, b, alpha);
               domeConsumer.addVertex(pose, x11, y11, z11).setColor(r, g, b, alpha);
               domeConsumer.addVertex(pose, x10, y10, z10).setColor(r, g, b, alpha);
            }
         }
      }

   }

   private static void renderShieldDomeAdditive(Matrix4f pose, VertexConsumer additiveConsumer, Vec3 worldCenter, Vec3 camPos, Vec3 impactDir, float t, float gameTime, boolean isBreak) {
      float uFront = t <= 0.35F ? t / 0.35F : 1.0F;
      float fade = 1.0F;
      if (t > 0.65F) {
         fade = Math.max(0.0F, 1.0F - (t - 0.65F) / 0.35F);
      }

      Vec3 toCam = camPos.subtract(worldCenter);
      double camDist = toCam.length();
      Vec3 camViewDir = camDist > 1.0E-4 ? toCam.scale(1.0 / camDist) : new Vec3(0.0, 1.0, 0.0);
      Vec3 normImpactDir = impactDir != null && !(impactDir.lengthSqr() < 1.0E-4) ? impactDir.normalize() : new Vec3(0.0, 0.0, 1.0);
      float dx = (float)normImpactDir.x;
      float dy = (float)normImpactDir.y;
      float dz = (float)normImpactDir.z;

      for(int lat = 0; lat < 24; ++lat) {
         float theta0 = (float)((double)lat * Math.PI / 24.0);
         float theta1 = (float)((double)(lat + 1) * Math.PI / 24.0);
         float sinTheta0 = Mth.sin(theta0);
         float cosTheta0 = Mth.cos(theta0);
         float sinTheta1 = Mth.sin(theta1);
         float cosTheta1 = Mth.cos(theta1);

         for(int lon = 0; lon < 36; ++lon) {
            float phi0 = (float)((double)(lon * 2) * Math.PI / 36.0);
            float phi1 = (float)((double)((lon + 1) * 2) * Math.PI / 36.0);
            float sinPhi0 = Mth.sin(phi0);
            float cosPhi0 = Mth.cos(phi0);
            float sinPhi1 = Mth.sin(phi1);
            float cosPhi1 = Mth.cos(phi1);
            float n00x = sinTheta0 * cosPhi0;
            float n00y = cosTheta0;
            float n00z = sinTheta0 * sinPhi0;
            float n01x = sinTheta0 * cosPhi1;
            float n01y = cosTheta0;
            float n01z = sinTheta0 * sinPhi1;
            float n11x = sinTheta1 * cosPhi1;
            float n11y = cosTheta1;
            float n11z = sinTheta1 * sinPhi1;
            float n10x = sinTheta1 * cosPhi0;
            float n10y = cosTheta1;
            float n10z = sinTheta1 * sinPhi0;
            float x00 = n00x * 1.35F;
            float y00 = n00y * 1.45F;
            float z00 = n00z * 1.35F;
            float x01 = n01x * 1.35F;
            float y01 = n01y * 1.45F;
            float z01 = n01z * 1.35F;
            float x11 = n11x * 1.35F;
            float y11 = n11y * 1.45F;
            float z11 = n11z * 1.35F;
            float x10 = n10x * 1.35F;
            float y10 = n10y * 1.45F;
            float z10 = n10z * 1.35F;
            float avgNx = 0.25F * (n00x + n01x + n11x + n10x);
            float avgNy = 0.25F * (n00y + n01y + n11y + n10y);
            float avgNz = 0.25F * (n00z + n01z + n11z + n10z);
            float nLen = Mth.sqrt(avgNx * avgNx + avgNy * avgNy + avgNz * avgNz);
            if (nLen > 1.0E-4F) {
               avgNx /= nLen;
               avgNy /= nLen;
               avgNz /= nLen;
            }

            float dotImpact = avgNx * dx + avgNy * dy + avgNz * dz;
            dotImpact = Mth.clamp(dotImpact, -1.0F, 1.0F);
            float angle = (float)Math.acos((double)dotImpact);
            float u = angle / 3.1415927F;
            float noise = (float)Math.sin((double)(avgNx * 12.0F + avgNy * 14.0F + gameTime * 0.2F)) * 0.025F;
            float uEffective = u + noise;
            if (!(uEffective > uFront + 0.05F)) {
               float distToFront = Math.abs(uEffective - uFront);
               float edgeFlash = 0.0F;
               if (t <= 0.4F && distToFront < 0.1F) {
                  edgeFlash = 1.0F - distToFront / 0.1F;
                  if (t > 0.35F) {
                     edgeFlash *= 1.0F - (t - 0.35F) / 0.05F;
                  }
               }

               float impactFlash = 0.0F;
               if (t <= 0.3F && u < 0.35F) {
                  impactFlash = (1.0F - t / 0.3F) * (1.0F - u / 0.35F);
               }

               float originGlow = 0.0F;
               float dotCam;
               float fresnel;
               if (t <= 0.35F && u < 0.32F) {
                  dotCam = 1.0F - u / 0.32F;
                  fresnel = 1.0F - t / 0.35F;
                  originGlow = dotCam * dotCam * fresnel;
               }

               dotCam = (float)Math.abs((double)avgNx * camViewDir.x + (double)avgNy * camViewDir.y + (double)avgNz * camViewDir.z);
               dotCam = Math.min(1.0F, dotCam);
               fresnel = (float)Math.pow((double)(1.0F - dotCam), 2.2);
               float p1 = Mth.sin(avgNx * 4.2F + avgNy * 5.0F + gameTime * 0.18F);
               float p2 = Mth.cos(avgNz * 4.5F - avgNy * 3.8F + gameTime * 0.15F);
               float p3 = Mth.sin((avgNx + avgNz) * 5.5F + gameTime * 0.22F);
               float plasmaVal = (p1 * p2 + p3) * 0.5F + 0.5F;
               if (plasmaVal > 0.58F || edgeFlash > 0.12F || impactFlash > 0.1F || originGlow > 0.05F || fresnel > 0.72F) {
                  float addR;
                  float addG;
                  float addB;
                  if (isBreak) {
                     addR = 1.0F;
                     addG = 0.2F + 0.3F * edgeFlash;
                     addB = 0.1F;
                  } else {
                     addR = 0.2F + 0.8F * (edgeFlash + impactFlash) + 0.8F * originGlow;
                     addG = 0.88F + 0.12F * (edgeFlash + impactFlash) + 0.12F * originGlow;
                     addB = 1.0F;
                  }

                  float addAlpha = ((plasmaVal - 0.58F) * 1.6F + edgeFlash * 1.2F + impactFlash * 1.5F + originGlow * 1.8F + (fresnel - 0.72F) * 0.9F) * fade;
                  addAlpha = Mth.clamp(addAlpha, 0.0F, 1.0F);
                  additiveConsumer.addVertex(pose, x00, y00, z00).setColor(addR, addG, addB, addAlpha);
                  additiveConsumer.addVertex(pose, x01, y01, z01).setColor(addR, addG, addB, addAlpha);
                  additiveConsumer.addVertex(pose, x11, y11, z11).setColor(addR, addG, addB, addAlpha);
                  additiveConsumer.addVertex(pose, x10, y10, z10).setColor(addR, addG, addB, addAlpha);
               }
            }
         }
      }

      if (t <= 0.35F) {
         renderImpactStarburst(pose, additiveConsumer, normImpactDir, t, gameTime, fade, isBreak);
      }

   }

   private static void renderImpactStarburst(Matrix4f pose, VertexConsumer consumer, Vec3 dir, float t, float gameTime, float fade, boolean isBreak) {
      Vec3 d = dir != null && !(dir.lengthSqr() < 1.0E-4) ? dir.normalize() : new Vec3(0.0, 0.0, 1.0);
      Vec3 up = Math.abs(d.y) < 0.9 ? new Vec3(0.0, 1.0, 0.0) : new Vec3(1.0, 0.0, 0.0);
      Vec3 t1 = up.cross(d).normalize();
      Vec3 t2 = d.cross(t1).normalize();
      float cx = (float)d.x * 1.35F;
      float cy = (float)d.y * 1.45F;
      float cz = (float)d.z * 1.35F;
      float burstFade = (1.0F - t / 0.35F) * fade;
      int rayCount = 8;

      for(int i = 0; i < rayCount; ++i) {
         float baseAngle = (float)((double)(i * 2) * Math.PI / (double)rayCount) + gameTime * 0.15F;
         float rayLen = (0.28F + 0.22F * Mth.sin((float)i * 3.5F + gameTime * 0.4F)) * burstFade;
         float halfWidth = 0.035F * burstFade;
         float cosA = Mth.cos(baseAngle);
         float sinA = Mth.sin(baseAngle);
         float rx = (float)(t1.x * (double)cosA + t2.x * (double)sinA);
         float ry = (float)(t1.y * (double)cosA + t2.y * (double)sinA);
         float rz = (float)(t1.z * (double)cosA + t2.z * (double)sinA);
         float perpX = (float)(-t1.x * (double)sinA + t2.x * (double)cosA) * halfWidth;
         float perpY = (float)(-t1.y * (double)sinA + t2.y * (double)cosA) * halfWidth;
         float perpZ = (float)(-t1.z * (double)sinA + t2.z * (double)cosA) * halfWidth;
         float lift = 0.03F;
         float bx = cx + (float)d.x * lift;
         float by = cy + (float)d.y * lift;
         float bz = cz + (float)d.z * lift;
         float tipX = bx + rx * rayLen;
         float tipY = by + ry * rayLen;
         float tipZ = bz + rz * rayLen;
         float r = isBreak ? 1.0F : 0.7F;
         float g = isBreak ? 0.25F : 0.96F;
         float bVal = isBreak ? 0.1F : 1.0F;
         float a = 0.85F * burstFade;
         float tipR = 1.0F;
         float tipG = isBreak ? 0.6F : 1.0F;
         float tipB = isBreak ? 0.2F : 1.0F;
         consumer.addVertex(pose, bx - perpX, by - perpY, bz - perpZ).setColor(r, g, bVal, a);
         consumer.addVertex(pose, bx + perpX, by + perpY, bz + perpZ).setColor(r, g, bVal, a);
         consumer.addVertex(pose, tipX + perpX * 0.2F, tipY + perpY * 0.2F, tipZ + perpZ * 0.2F).setColor(tipR, tipG, tipB, a * 0.4F);
         consumer.addVertex(pose, tipX - perpX * 0.2F, tipY - perpY * 0.2F, tipZ - perpZ * 0.2F).setColor(tipR, tipG, tipB, a * 0.4F);
      }

   }

   private static void renderSparks(Matrix4f pose, VertexConsumer consumer, List<ShieldClientManager.SparkInstance> sparks, Vec3 camPos, Camera camera, float partialTick) {
      Quaternionf camRot = camera.rotation();
      Vector3f camRight = (new Vector3f(1.0F, 0.0F, 0.0F)).rotate(camRot);
      Vector3f camUp = (new Vector3f(0.0F, 1.0F, 0.0F)).rotate(camRot);
      Iterator var9 = sparks.iterator();

      while(true) {
         while(true) {
            ShieldClientManager.SparkInstance spark;
            Vec3 head;
            ArrayList<Vec3> points;
            int n;
            float fSpark;
            do {
               if (!var9.hasNext()) {
                  return;
               }

               spark = (ShieldClientManager.SparkInstance)var9.next();
               double hx = spark.getX(partialTick);
               double hy = spark.getY(partialTick);
               double hz = spark.getZ(partialTick);
               head = new Vec3(hx, hy, hz);
               List<Vec3> history = spark.getTrailHistory();
               points = new ArrayList<>(history.size() + 1);
               points.add(head);
               points.addAll(history);
               int numPoints = points.size();
               n = numPoints - 1;
               fSpark = (float)Math.max(0.0, 1.0 - ((double)spark.getAge() + (double)partialTick) / (double)spark.getMaxAge());
            } while(fSpark <= 0.0F);

            boolean isBreakSpark = spark.isBreak();
            float headR = isBreakSpark ? 1.0F : 0.85F;
            float headG = isBreakSpark ? 0.3F : 0.98F;
            float headB = isBreakSpark ? 0.1F : 1.0F;
            Vec3 headRel;
            if (n < 1) {
               headRel = head.subtract(camPos);
               renderSparkPoint(pose, consumer, headRel, camRight, camUp, 0.04F, headR, headG, headB, fSpark);
            } else {
               for(int i = 0; i < n; ++i) {
                  Vec3 p0 = (Vec3)points.get(i);
                  Vec3 p1 = (Vec3)points.get(i + 1);
                  Vec3 s = p0.subtract(p1);
                  double sLenSqr = s.lengthSqr();
                  if (!(sLenSqr < 1.0E-8)) {
                     Vec3 mid = p0.add(p1).scale(0.5);
                     Vec3 c = mid.subtract(camPos);
                     Vec3 w = s.cross(c);
                     double wLen = w.length();
                     if (wLen < 1.0E-6) {
                        Vec3 ref = Math.abs(s.y) < 0.95 ? new Vec3(0.0, 1.0, 0.0) : new Vec3(1.0, 0.0, 0.0);
                        w = s.cross(ref);
                        wLen = w.length();
                        if (wLen < 1.0E-6) {
                           w = new Vec3(0.0, 1.0, 0.0);
                           wLen = 1.0;
                        }
                     }

                     w = w.scale(1.0 / wLen);
                     double wi = Math.max(0.005, 0.04 * (1.0 - (double)i / (double)n));
                     double wNext = Math.max(0.002, 0.04 * (1.0 - (double)(i + 1) / (double)n));
                     float ai = (float)((1.0 - (double)i / (double)n) * (double)fSpark);
                     float aNext = (float)((1.0 - (double)(i + 1) / (double)n) * (double)fSpark);
                     float[] colI = getTrailColor((double)i / (double)n, isBreakSpark);
                     float[] colNext = getTrailColor((double)(i + 1) / (double)n, isBreakSpark);
                     double offXi = w.x * wi;
                     double offYi = w.y * wi;
                     double offZi = w.z * wi;
                     double offXnext = w.x * wNext;
                     double offYnext = w.y * wNext;
                     double offZnext = w.z * wNext;
                     float x0 = (float)(p0.x - camPos.x + offXi);
                     float y0 = (float)(p0.y - camPos.y + offYi);
                     float z0 = (float)(p0.z - camPos.z + offZi);
                     float x1 = (float)(p0.x - camPos.x - offXi);
                     float y1 = (float)(p0.y - camPos.y - offYi);
                     float z1 = (float)(p0.z - camPos.z - offZi);
                     float x2 = (float)(p1.x - camPos.x - offXnext);
                     float y2 = (float)(p1.y - camPos.y - offYnext);
                     float z2 = (float)(p1.z - camPos.z - offZnext);
                     float x3 = (float)(p1.x - camPos.x + offXnext);
                     float y3 = (float)(p1.y - camPos.y + offYnext);
                     float z3 = (float)(p1.z - camPos.z + offZnext);
                     consumer.addVertex(pose, x0, y0, z0).setColor(colI[0], colI[1], colI[2], ai);
                     consumer.addVertex(pose, x1, y1, z1).setColor(colI[0], colI[1], colI[2], ai);
                     consumer.addVertex(pose, x2, y2, z2).setColor(colNext[0], colNext[1], colNext[2], aNext);
                     consumer.addVertex(pose, x3, y3, z3).setColor(colNext[0], colNext[1], colNext[2], aNext);
                  }
               }

               headRel = head.subtract(camPos);
               renderSparkPoint(pose, consumer, headRel, camRight, camUp, 0.04F, headR, headG, headB, fSpark);
            }
         }
      }
   }

   private static void renderSparkPoint(Matrix4f pose, VertexConsumer consumer, Vec3 posRel, Vector3f camRight, Vector3f camUp, float radius, float r, float g, float b, float a) {
      if (!(a <= 0.001F)) {
         float rx = camRight.x() * radius;
         float ry = camRight.y() * radius;
         float rz = camRight.z() * radius;
         float ux = camUp.x() * radius;
         float uy = camUp.y() * radius;
         float uz = camUp.z() * radius;
         float px = (float)posRel.x;
         float py = (float)posRel.y;
         float pz = (float)posRel.z;
         consumer.addVertex(pose, px - rx - ux, py - ry - uy, pz - rz - uz).setColor(r, g, b, a);
         consumer.addVertex(pose, px + rx - ux, py + ry - uy, pz + rz - uz).setColor(r, g, b, a);
         consumer.addVertex(pose, px + rx + ux, py + ry + uy, pz + rz + uz).setColor(r, g, b, a);
         consumer.addVertex(pose, px - rx + ux, py - ry + uy, pz - rz + uz).setColor(r, g, b, a);
      }
   }

   private static float[] getTrailColor(double t) {
      return getTrailColor(t, false);
   }

   private static float[] getTrailColor(double t, boolean isBreak) {
      float r;
      float g;
      float b;
      float f;
      if (isBreak) {
         if (t <= 0.5) {
            f = (float)(t / 0.5);
            r = 1.0F;
            g = Mth.lerp(f, 0.45F, 0.25F);
            b = Mth.lerp(f, 0.15F, 0.05F);
         } else {
            f = (float)((t - 0.5) / 0.5);
            r = Mth.lerp(f, 1.0F, 0.8F);
            g = Mth.lerp(f, 0.25F, 0.08F);
            b = Mth.lerp(f, 0.05F, 0.01F);
         }

         return new float[]{r, g, b};
      } else {
         if (t <= 0.5) {
            f = (float)(t / 0.5);
            r = Mth.lerp(f, 0.85F, 0.05F);
            g = Mth.lerp(f, 0.98F, 0.85F);
            b = 1.0F;
         } else {
            f = (float)((t - 0.5) / 0.5);
            r = Mth.lerp(f, 0.05F, 0.0F);
            g = Mth.lerp(f, 0.85F, 0.6F);
            b = 1.0F;
         }

         return new float[]{r, g, b};
      }
   }
}
