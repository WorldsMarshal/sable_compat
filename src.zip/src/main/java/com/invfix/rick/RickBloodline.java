package com.invfix.rick;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;

/**
 * Родословная Rick C137 — расо-независимая, статов не даёт вообще.
 *
 * Ноль статов получается сам собой: {@code BloodlineMultiplierProcedure} при каждом
 * вызове сначала обнуляет bloodlineMultiplier / bloodlineStrengthMultipler /
 * speedMultiplier / ArgallAgeBuff / atomic_recon_chance и ставит Curse = None, и
 * только потом сравнивает строку. Наша строка ему неизвестна — всё остаётся в нулях.
 * Поэтому в ту процедуру лезть НЕ нужно.
 *
 * Вместо статов Rick получает две вещи: панель 5x5 с танками прямо над ванильным
 * инвентарём (см. {@link RickPocket}) и тройной потолок зачарований (см. {@link RickEnchant}).
 */
public final class RickBloodline {

    /** Значение поля Bloodline. Цвет §3 (тёмно-бирюзовый) — портальная зелень. */
    public static final String RICK = "\u00a73\u00a7lRick C137";

    private RickBloodline() {}

    /** Работает и на сервере, и на клиенте: PlayerVariables синкаются через markSyncDirty. */
    public static boolean is(Entity entity) {
        if (entity == null) return false;
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            return vars != null && RICK.equals(vars.Bloodline);
        } catch (Throwable t) {
            return false; // Invincible Inc не загружен
        }
    }
}