package com.invfix.rick.cube.client;

import com.invfix.rick.cube.RickEnergyCubeMenu;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

import java.util.List;

/** Экран куба: два слота и вертикальная полоса заряда. */
public class RickEnergyCubeScreen extends AbstractContainerScreen<RickEnergyCubeMenu> {

    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/gui/rick_energy_cube.png");

    private static final int BAR_X = 116, BAR_Y = 17, BAR_W = 16, BAR_H = 54;

    public RickEnergyCubeScreen(RickEnergyCubeMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = 166;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        g.blit(TEXTURE, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, 256, 256);

        int energy = this.menu.energy();
        int capacity = this.menu.capacity();
        if (energy <= 0 || capacity <= 0) return;

        int filled = (int) (BAR_H * (energy / (float) capacity));
        if (filled <= 0) filled = 1;
        if (filled > BAR_H) filled = BAR_H;

        int x = this.leftPos + BAR_X;
        int y = this.topPos + BAR_Y;
        g.fill(x, y + (BAR_H - filled), x + BAR_W, y + BAR_H, 0xFF2FE2C8);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g, mouseX, mouseY, partialTick);
        super.render(g, mouseX, mouseY, partialTick);
        renderBarTooltip(g, mouseX, mouseY);
        this.renderTooltip(g, mouseX, mouseY);
    }

    private void renderBarTooltip(GuiGraphics g, int mouseX, int mouseY) {
        int x = this.leftPos + BAR_X;
        int y = this.topPos + BAR_Y;
        if (mouseX < x || mouseX >= x + BAR_W || mouseY < y || mouseY >= y + BAR_H) return;

        g.renderComponentTooltip(this.font, List.of(
                Component.translatable("tooltip.sable_compat.rick_energy_cube.stored",
                        format(this.menu.energy()), format(this.menu.capacity())),
                Component.translatable("tooltip.sable_compat.rick_energy_cube.generation",
                        com.invfix.rick.cube.RickEnergyCubeBlockEntity.GENERATION)
                        .withStyle(ChatFormatting.DARK_AQUA)
        ), mouseX, mouseY);
    }

    private static String format(int fe) {
        if (fe >= 1_000_000) return String.format("%.2fM", fe / 1_000_000.0F);
        if (fe >= 1_000) return String.format("%.1fk", fe / 1_000.0F);
        return Integer.toString(fe);
    }
}
