package com.invfix.rick.cube;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;

/**
 * Блок самозарядного энергетического куба.
 *
 * Повёрнутая грань отдаёт энергию, поэтому направление важно и ставится по
 * взгляду игрока, включая вертикаль — как у куба Mekanism.
 *
 * Заряд переживает разрушение: {@link #getDrops} собирает предмет вручную и
 * кладёт остаток энергии в компонент, поэтому таблица лута этому блоку не нужна.
 */
public class RickEnergyCubeBlock extends Block implements EntityBlock {

    public static final DirectionProperty FACING = BlockStateProperties.FACING;

    public RickEnergyCubeBlock(Properties props) {
        super(props);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        // Лицевая грань смотрит НА игрока: так удобнее ставить куб «выдачей» в машину.
        return this.defaultBlockState().setValue(FACING, ctx.getNearestLookingDirection().getOpposite());
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new RickEnergyCubeBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) return null;
        return type == RickCubeRegistry.ENERGY_CUBE_BE.get()
                ? (lvl, pos, st, be) -> RickEnergyCubeBlockEntity.tick(lvl, pos, st, (RickEnergyCubeBlockEntity) be)
                : null;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                               Player player, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (level.getBlockEntity(pos) instanceof RickEnergyCubeBlockEntity be) {
            player.openMenu(be, pos);
        }
        return InteractionResult.CONSUME;
    }

    /** Ставим куб уже заряженным, если предмет нёс заряд. */
    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level.isClientSide) return;
        Integer stored = stack.get(RickCubeRegistry.STORED_ENERGY.get());
        if (stored != null && level.getBlockEntity(pos) instanceof RickEnergyCubeBlockEntity be) {
            be.setEnergy(stored);
            be.setChanged();
        }
    }

    /** Дроп собираем сами — иначе заряд потеряется, а таблицу лута пришлось бы плодить. */
    @Override
    public List<ItemStack> getDrops(BlockState state, LootParams.Builder params) {
        ItemStack stack = new ItemStack(RickCubeRegistry.ENERGY_CUBE_ITEM.get());
        BlockEntity be = params.getOptionalParameter(net.minecraft.world.level.storage.loot.parameters.LootContextParams.BLOCK_ENTITY);
        if (be instanceof RickEnergyCubeBlockEntity cube && cube.getEnergy() > 0) {
            stack.set(RickCubeRegistry.STORED_ENERGY.get(), cube.getEnergy());
        }
        return Collections.singletonList(stack);
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock())) {
            if (level.getBlockEntity(pos) instanceof RickEnergyCubeBlockEntity be) {
                be.dropContents(level, pos);
            }
        }
        super.onRemove(state, level, pos, newState, moved);
    }

    @Override
    protected boolean hasAnalogOutputSignal(BlockState state) { return true; }

    @Override
    protected int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
        if (level.getBlockEntity(pos) instanceof RickEnergyCubeBlockEntity be) {
            if (be.getEnergy() <= 0) return 0;
            return 1 + (int) (be.getEnergy() * 14L / be.getCapacity());
        }
        return 0;
    }
}
