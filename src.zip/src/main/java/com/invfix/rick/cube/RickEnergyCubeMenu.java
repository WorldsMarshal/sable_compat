package com.invfix.rick.cube;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.items.SlotItemHandler;
import org.jetbrains.annotations.Nullable;

/**
 * Меню куба: два слота под предметы и синхронизация заряда.
 *
 * ContainerData передаёт short, поэтому 1 600 000 FE не влезает в один слот —
 * заряд разбит на старшие и младшие 16 бит.
 */
public class RickEnergyCubeMenu extends AbstractContainerMenu {

    public static final int SLOT_DISCHARGE = 0;
    public static final int SLOT_CHARGE = 1;
    private static final int INV_START = 2;
    private static final int INV_END = INV_START + 36;

    @Nullable private final RickEnergyCubeBlockEntity be;
    private final ContainerData data;

    /** Клиентский конструктор. */
    public RickEnergyCubeMenu(int id, Inventory inv, RegistryFriendlyByteBuf buf) {
        this(id, inv, resolve(inv, buf));
    }

    public RickEnergyCubeMenu(int id, Inventory inv, @Nullable RickEnergyCubeBlockEntity be) {
        super(RickCubeRegistry.ENERGY_CUBE_MENU.get(), id);
        this.be = be;
        this.data = new SimpleContainerData(2);

        if (be != null) {
            addSlot(new SlotItemHandler(be.items(), RickEnergyCubeBlockEntity.SLOT_DISCHARGE, 56, 17));
            addSlot(new SlotItemHandler(be.items(), RickEnergyCubeBlockEntity.SLOT_CHARGE, 56, 53));
        } else {
            // Клиент до прихода данных: пустышки, чтобы совпало число слотов.
            addSlot(new Slot(new net.minecraft.world.SimpleContainer(2), 0, 56, 17));
            addSlot(new Slot(new net.minecraft.world.SimpleContainer(2), 1, 56, 53));
        }

        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 9; c++)
                addSlot(new Slot(inv, 9 + r * 9 + c, 8 + c * 18, 84 + r * 18));
        for (int c = 0; c < 9; c++)
            addSlot(new Slot(inv, c, 8 + c * 18, 142));

        addDataSlots(this.data);
    }

    @Nullable
    private static RickEnergyCubeBlockEntity resolve(Inventory inv, RegistryFriendlyByteBuf buf) {
        if (buf == null) return null;
        var pos = buf.readBlockPos();
        return inv.player.level().getBlockEntity(pos) instanceof RickEnergyCubeBlockEntity cube ? cube : null;
    }

    @Override
    public void broadcastChanges() {
        if (be != null) {
            int energy = be.getEnergy();
            this.data.set(0, energy & 0xFFFF);
            this.data.set(1, (energy >>> 16) & 0xFFFF);
        }
        super.broadcastChanges();
    }

    /** Заряд для отрисовки — собирается обратно из двух половин. */
    public int energy() {
        return (this.data.get(0) & 0xFFFF) | ((this.data.get(1) & 0xFFFF) << 16);
    }

    public int capacity() { return RickEnergyCubeBlockEntity.CAPACITY; }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;

        ItemStack stack = slot.getItem();
        ItemStack copy = stack.copy();

        if (index < INV_START) {
            if (!moveItemStackTo(stack, INV_START, INV_END, true)) return ItemStack.EMPTY;
        } else {
            // Внутрь пускаем только то, что вообще умеет хранить энергию.
            boolean energyItem = stack.getCapability(Capabilities.EnergyStorage.ITEM) != null;
            if (!energyItem || !moveItemStackTo(stack, 0, INV_START, false)) return ItemStack.EMPTY;
        }

        if (stack.isEmpty()) slot.set(ItemStack.EMPTY); else slot.setChanged();
        if (stack.getCount() == copy.getCount()) return ItemStack.EMPTY;
        slot.onTake(player, stack);
        return copy;
    }

    @Override
    public boolean stillValid(Player player) {
        if (be == null) return true;
        return player.distanceToSqr(be.getBlockPos().getX() + 0.5,
                be.getBlockPos().getY() + 0.5, be.getBlockPos().getZ() + 0.5) <= 64.0;
    }
}
