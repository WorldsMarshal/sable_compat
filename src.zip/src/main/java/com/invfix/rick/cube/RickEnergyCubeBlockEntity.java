package com.invfix.rick.cube;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.items.ItemStackHandler;
import org.jetbrains.annotations.Nullable;

/**
 * Самозарядный энергетический куб.
 *
 * Ёмкость 1 600 000 FE — как у базового куба Mekanism (4 000 000 J при курсе
 * 2.5 J за FE). Отличие в том, что этот сам вырабатывает 1000 FE/т, пока не
 * заполнен, поэтому внешний источник ему не нужен вообще.
 *
 * Поведение сторон повторяет меканизмовское по умолчанию: грань, в которую куб
 * повёрнут, работает на выдачу, все остальные — на приём. Соседям энергия
 * толкается сама, каждый тик.
 *
 * Два слота как в оригинале: верхний разряжает предмет в куб, нижний заряжает
 * предмет из куба.
 */
public class RickEnergyCubeBlockEntity extends BlockEntity implements MenuProvider {

    public static final int CAPACITY = 1_600_000;
    /** Собственная генерация, пока бак не полон. */
    public static final int GENERATION = 1_000;
    /** Пропускная способность на приём и на выдачу. */
    public static final int TRANSFER = 10_000;

    public static final int SLOT_DISCHARGE = 0; // предмет -> куб
    public static final int SLOT_CHARGE = 1;    // куб -> предмет

    private int energy;
    /** Счётчик, чтобы не помечать чанк грязным на каждом тике. */
    private int saveTimer;

    private final ItemStackHandler items = new ItemStackHandler(2) {
        @Override protected void onContentsChanged(int slot) {
            setChanged();
        }
        @Override public boolean isItemValid(int slot, ItemStack stack) {
            return stack.getCapability(Capabilities.EnergyStorage.ITEM) != null;
        }
    };

    /** Обёртка стороны: одна грань только отдаёт, остальные только принимают. */
    private final IEnergyStorage inputFace = new Face(false, true);
    private final IEnergyStorage outputFace = new Face(true, false);
    private final IEnergyStorage anyFace = new Face(true, true);

    public RickEnergyCubeBlockEntity(BlockPos pos, BlockState state) {
        super(RickCubeRegistry.ENERGY_CUBE_BE.get(), pos, state);
    }

    // ================= энергия =================

    public int getEnergy() { return this.energy; }
    public int getCapacity() { return CAPACITY; }

    public void setEnergy(int value) {
        this.energy = Math.max(0, Math.min(value, CAPACITY));
    }

    /** Что отдаём наружу по конкретной стороне. null-сторона — полный доступ. */
    @Nullable
    public IEnergyStorage sided(@Nullable Direction side) {
        if (side == null) return anyFace;
        Direction facing = getBlockState().getValue(RickEnergyCubeBlock.FACING);
        return side == facing ? outputFace : inputFace;
    }

    public ItemStackHandler items() { return this.items; }

    // ================= тик =================

    public static void tick(Level level, BlockPos pos, BlockState state, RickEnergyCubeBlockEntity be) {
        if (level.isClientSide) return;

        int before = be.energy;

        // 1. Самозарядка
        if (be.energy < CAPACITY) {
            be.energy = Math.min(CAPACITY, be.energy + GENERATION);
        }

        // 2. Слоты: разряд предмета в куб, заряд предмета из куба
        be.serviceDischargeSlot();
        be.serviceChargeSlot();

        // 3. Выдача соседу с лицевой стороны
        be.pushToNeighbour(level, pos, state);

        // ВАЖНО: никакого sendBlockUpdated каждый тик.
        //
        // Куб заряжает себя постоянно, поэтому энергия меняется буквально каждый
        // тик. Ранее это дёргало sendBlockUpdated с флагом 3 двадцать раз в
        // секунду — то есть уведомление соседей и перерасчёт компараторов на
        // каждый тик у каждого куба, плюс пометка чанка грязным без остановки.
        // Клиенту постоянный синк не нужен: гуй читает заряд через ContainerData
        // меню. Достаточно раз в секунду пометить блок-энтити изменённым.
        if (be.energy != before && ++be.saveTimer >= 20) {
            be.saveTimer = 0;
            be.setChanged();
        }
    }

    /** Верхний слот: тянем энергию ИЗ предмета в куб. */
    private void serviceDischargeSlot() {
        if (energy >= CAPACITY) return;
        ItemStack stack = items.getStackInSlot(SLOT_DISCHARGE);
        if (stack.isEmpty()) return;

        IEnergyStorage storage = stack.getCapability(Capabilities.EnergyStorage.ITEM);
        if (storage == null || !storage.canExtract()) return;

        int room = Math.min(TRANSFER, CAPACITY - energy);
        int drained = storage.extractEnergy(room, false);
        energy += drained;
    }

    /** Нижний слот: отдаём энергию В предмет. */
    private void serviceChargeSlot() {
        if (energy <= 0) return;
        ItemStack stack = items.getStackInSlot(SLOT_CHARGE);
        if (stack.isEmpty()) return;

        IEnergyStorage storage = stack.getCapability(Capabilities.EnergyStorage.ITEM);
        if (storage == null || !storage.canReceive()) return;

        int offer = Math.min(TRANSFER, energy);
        int accepted = storage.receiveEnergy(offer, false);
        energy -= accepted;
    }

    private void pushToNeighbour(Level level, BlockPos pos, BlockState state) {
        if (energy <= 0) return;

        Direction facing = state.getValue(RickEnergyCubeBlock.FACING);
        IEnergyStorage target = level.getCapability(
                Capabilities.EnergyStorage.BLOCK, pos.relative(facing), facing.getOpposite());
        if (target == null || !target.canReceive()) return;

        int offer = Math.min(TRANSFER, energy);
        int accepted = target.receiveEnergy(offer, false);
        energy -= accepted;
    }

    // ================= сохранение и синк =================

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy);
        tag.put("Items", this.items.serializeNBT(registries));
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy = tag.getInt("Energy");
        if (tag.contains("Items")) this.items.deserializeNBT(registries, tag.getCompound("Items"));
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        CompoundTag tag = super.getUpdateTag(registries);
        tag.putInt("Energy", this.energy);
        return tag;
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    /** Содержимое слотов при разрушении — на землю. Заряд уезжает в предмет. */
    public void dropContents(Level level, BlockPos pos) {
        for (int i = 0; i < items.getSlots(); i++) {
            ItemStack stack = items.getStackInSlot(i);
            if (!stack.isEmpty()) Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), stack);
        }
    }

    // ================= меню =================

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.sable_compat.rick_energy_cube");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new RickEnergyCubeMenu(id, inv, this);
    }

    /** Одна грань куба с точки зрения соседа. */
    private class Face implements IEnergyStorage {
        private final boolean extract;
        private final boolean receive;

        Face(boolean extract, boolean receive) {
            this.extract = extract;
            this.receive = receive;
        }

        @Override public int receiveEnergy(int max, boolean simulate) {
            if (!receive) return 0;
            int accepted = Math.min(Math.min(TRANSFER, max), CAPACITY - energy);
            if (!simulate && accepted > 0) {
                energy += accepted;
                setChanged();
            }
            return accepted;
        }

        @Override public int extractEnergy(int max, boolean simulate) {
            if (!extract) return 0;
            int given = Math.min(Math.min(TRANSFER, max), energy);
            if (!simulate && given > 0) {
                energy -= given;
                setChanged();
            }
            return given;
        }

        @Override public int getEnergyStored() { return energy; }
        @Override public int getMaxEnergyStored() { return CAPACITY; }
        @Override public boolean canExtract() { return extract; }
        @Override public boolean canReceive() { return receive; }
    }
}
