package com.invfix.rick.cube;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.energy.IEnergyStorage;

import java.util.List;

/**
 * Предмет-куб. Носит заряд в компоненте {@code sable_compat:stored_energy},
 * показывает его в подсказке и полосе прочности, и умеет заряжаться прямо в
 * инвентаре — как куб Mekanism.
 */
public class RickEnergyCubeItem extends BlockItem {

    public RickEnergyCubeItem(Block block, Properties props) {
        super(block, props);
    }

    public static int energyOf(ItemStack stack) {
        Integer stored = stack.get(RickCubeRegistry.STORED_ENERGY.get());
        return stored == null ? 0 : Math.max(0, Math.min(stored, RickEnergyCubeBlockEntity.CAPACITY));
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return energyOf(stack) > 0;
    }

    @Override
    public int getBarWidth(ItemStack stack) {
        return Math.round(13.0F * energyOf(stack) / RickEnergyCubeBlockEntity.CAPACITY);
    }

    @Override
    public int getBarColor(ItemStack stack) {
        return 0x2FE2C8; // бирюза под палитру куба
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext ctx, List<Component> lines, TooltipFlag flag) {
        super.appendHoverText(stack, ctx, lines, flag);
        lines.add(Component.translatable("tooltip.sable_compat.rick_energy_cube.stored",
                        format(energyOf(stack)), format(RickEnergyCubeBlockEntity.CAPACITY))
                .withStyle(ChatFormatting.AQUA));
        lines.add(Component.translatable("tooltip.sable_compat.rick_energy_cube.generation",
                        RickEnergyCubeBlockEntity.GENERATION)
                .withStyle(ChatFormatting.DARK_AQUA));
    }

    private static String format(int fe) {
        if (fe >= 1_000_000) return String.format("%.2fM", fe / 1_000_000.0F);
        if (fe >= 1_000) return String.format("%.1fk", fe / 1_000.0F);
        return Integer.toString(fe);
    }

    /** Энергохранилище поверх компонента предмета. */
    public static class StackEnergy implements IEnergyStorage {

        private final ItemStack stack;

        public StackEnergy(ItemStack stack) { this.stack = stack; }

        private void set(int value) {
            stack.set(RickCubeRegistry.STORED_ENERGY.get(),
                    Math.max(0, Math.min(value, RickEnergyCubeBlockEntity.CAPACITY)));
        }

        @Override public int receiveEnergy(int max, boolean simulate) {
            int current = energyOf(stack);
            int accepted = Math.min(Math.min(RickEnergyCubeBlockEntity.TRANSFER, max),
                    RickEnergyCubeBlockEntity.CAPACITY - current);
            if (!simulate && accepted > 0) set(current + accepted);
            return accepted;
        }

        @Override public int extractEnergy(int max, boolean simulate) {
            int current = energyOf(stack);
            int given = Math.min(Math.min(RickEnergyCubeBlockEntity.TRANSFER, max), current);
            if (!simulate && given > 0) set(current - given);
            return given;
        }

        @Override public int getEnergyStored() { return energyOf(stack); }
        @Override public int getMaxEnergyStored() { return RickEnergyCubeBlockEntity.CAPACITY; }
        @Override public boolean canExtract() { return true; }
        @Override public boolean canReceive() { return true; }
    }
}
