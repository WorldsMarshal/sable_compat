package com.invfix.rick.cube;

import com.mojang.serialization.Codec;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

/**
 * Реестр самозарядного энергетического куба — первого эксклюзивного крафта Рика.
 *
 * Рецепт лежит в {@code sable_compat:precision} с {@code "tier": 137}. Станков
 * третьего тира в сборке нет (высокоточный — 1, сверхвысокоточный — 2), а
 * карманный резолвер Рика тир не проверяет вообще. Так что собрать куб может
 * только он, и никакой отдельной проверки родословной в блоке не нужно.
 */
public final class RickCubeRegistry {

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks("sable_compat");
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("sable_compat");
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, "sable_compat");
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, "sable_compat");
    public static final DeferredRegister<DataComponentType<?>> COMPONENTS =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, "sable_compat");

    /** Заряд, который предмет несёт в себе между установкой и разрушением. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> STORED_ENERGY =
            COMPONENTS.register("stored_energy", () -> DataComponentType.<Integer>builder()
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT)
                    .build());

    public static final DeferredBlock<RickEnergyCubeBlock> ENERGY_CUBE =
            BLOCKS.registerBlock("rick_energy_cube", RickEnergyCubeBlock::new,
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_CYAN)
                            .strength(5.0F, 12.0F)
                            .requiresCorrectToolForDrops()
                            .sound(SoundType.NETHERITE_BLOCK)
                            .lightLevel(state -> 7));

    public static final DeferredItem<RickEnergyCubeItem> ENERGY_CUBE_ITEM =
            ITEMS.register("rick_energy_cube",
                    () -> new RickEnergyCubeItem(ENERGY_CUBE.get(), new Item.Properties().stacksTo(1)));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RickEnergyCubeBlockEntity>> ENERGY_CUBE_BE =
            BLOCK_ENTITIES.register("rick_energy_cube",
                    () -> BlockEntityType.Builder.of(RickEnergyCubeBlockEntity::new, ENERGY_CUBE.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<RickEnergyCubeMenu>> ENERGY_CUBE_MENU =
            MENUS.register("rick_energy_cube",
                    () -> IMenuTypeExtension.create((id, inv, buf) -> new RickEnergyCubeMenu(id, inv, buf)));

    private RickCubeRegistry() {}

    public static void register(IEventBus modEventBus) {
        COMPONENTS.register(modEventBus);
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
        MENUS.register(modEventBus);
        modEventBus.addListener(RickCubeRegistry::onRegisterCapabilities);
        modEventBus.addListener(RickCubeRegistry::onBuildCreativeTabs);
    }

    private static void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
        // Блок: сторона, в которую он повёрнут, отдаёт энергию; остальные принимают.
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ENERGY_CUBE_BE.get(),
                (be, side) -> be.sided(side));

        // Предмет: куб можно заряжать и разряжать прямо в инвентаре, как в Mekanism.
        event.registerItem(Capabilities.EnergyStorage.ITEM,
                (stack, ctx) -> new RickEnergyCubeItem.StackEnergy(stack),
                ENERGY_CUBE_ITEM.get());
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(ENERGY_CUBE_ITEM);
        }
    }

    /** Удобный доступ к типу компонента без каста. */
    public static Supplier<DataComponentType<Integer>> storedEnergy() {
        return () -> STORED_ENERGY.get();
    }
}
