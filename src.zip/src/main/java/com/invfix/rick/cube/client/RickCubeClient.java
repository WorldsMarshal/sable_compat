package com.invfix.rick.cube.client;

import com.invfix.rick.cube.RickCubeRegistry;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/** Клиентская регистрация экрана куба. */
public final class RickCubeClient {

    private RickCubeClient() {}

    public static void init(IEventBus modEventBus) {
        modEventBus.addListener(RickCubeClient::onRegisterScreens);
    }

    private static void onRegisterScreens(RegisterMenuScreensEvent event) {
        event.register(RickCubeRegistry.ENERGY_CUBE_MENU.get(), RickEnergyCubeScreen::new);
    }
}
