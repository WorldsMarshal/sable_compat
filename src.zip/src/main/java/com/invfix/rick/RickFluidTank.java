package com.invfix.rick;

import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import org.jetbrains.annotations.NotNull;

/**
 * Один карманный танк Рика: 500 B (500 000 mB), ровно один тип жидкости за раз.
 *
 * Пока танк пуст — принимает что угодно и запоминает тип. Пока не пуст —
 * принимает только совпадающую жидкость. Тип сбрасывается сам, когда объём
 * доходит до нуля.
 */
public class RickFluidTank implements IFluidHandler {

    /** 500 B. */
    public static final int CAPACITY = 500_000;

    private FluidStack stack = FluidStack.EMPTY;

    public RickFluidTank() {}

    public RickFluidTank(FluidStack initial) { this.stack = initial.copy(); }

    public FluidStack stack() { return this.stack; }

    public void set(FluidStack s) {
        this.stack = s.isEmpty() ? FluidStack.EMPTY : s.copyWithAmount(Math.min(s.getAmount(), CAPACITY));
    }

    public int amount() { return this.stack.isEmpty() ? 0 : this.stack.getAmount(); }

    public boolean isEmpty() { return this.stack.isEmpty(); }

    // --- IFluidHandler ---

    @Override public int getTanks() { return 1; }

    @Override public @NotNull FluidStack getFluidInTank(int tank) { return this.stack; }

    @Override public int getTankCapacity(int tank) { return CAPACITY; }

    @Override public boolean isFluidValid(int tank, @NotNull FluidStack fluid) {
        return this.stack.isEmpty() || FluidStack.isSameFluidSameComponents(this.stack, fluid);
    }

    @Override
    public int fill(FluidStack resource, FluidAction action) {
        if (resource.isEmpty()) return 0;
        if (!this.stack.isEmpty() && !FluidStack.isSameFluidSameComponents(this.stack, resource)) return 0;

        int room = CAPACITY - amount();
        if (room <= 0) return 0;
        int accepted = Math.min(room, resource.getAmount());
        if (action.execute()) {
            if (this.stack.isEmpty()) this.stack = resource.copyWithAmount(accepted);
            else this.stack.grow(accepted);
        }
        return accepted;
    }

    @Override
    public @NotNull FluidStack drain(FluidStack resource, FluidAction action) {
        if (resource.isEmpty() || this.stack.isEmpty()) return FluidStack.EMPTY;
        if (!FluidStack.isSameFluidSameComponents(this.stack, resource)) return FluidStack.EMPTY;
        return drain(resource.getAmount(), action);
    }

    @Override
    public @NotNull FluidStack drain(int maxDrain, FluidAction action) {
        if (this.stack.isEmpty() || maxDrain <= 0) return FluidStack.EMPTY;
        int taken = Math.min(maxDrain, amount());
        FluidStack out = this.stack.copyWithAmount(taken);
        if (action.execute()) {
            this.stack.shrink(taken);
            if (this.stack.getAmount() <= 0) this.stack = FluidStack.EMPTY;
        }
        return out;
    }
}