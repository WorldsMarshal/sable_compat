package com.invfix.rick;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Обслуживание кармана Рика на сервере.
 *
 * Слоты пристраиваются в конструкторе InventoryMenu и в пакете-включателе не
 * нуждаются — отсюда уходит только снимок танков, потому что attachment на
 * игроке сам по себе на клиент не едет, а панель рисуется постоянно.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class RickServerEvents {

    private RickServerEvents() {}

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) { push(event.getEntity()); }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) { push(event.getEntity()); }

    @SubscribeEvent
    public static void onChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) { push(event.getEntity()); }

    /**
     * Тик кармана — нужен слоту разложения Alchemistry, который перерабатывает по
     * предмету в секунду. Собственного тика у InventoryMenu нет, а slotsChanged
     * срабатывает только на изменения, поэтому таймер живёт здесь.
     */
    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer sp)) return;
        RickPocket pocket = RickMenuAccess.of(sp);
        if (pocket != null) pocket.tick();
    }

    private static void push(net.minecraft.world.entity.player.Player player) {
        if (!(player instanceof ServerPlayer)) return;
        RickPocket pocket = RickMenuAccess.of(player);
        if (pocket != null) pocket.syncTanks(true);
    }
}
