package com.invfix.rick;

import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/**
 * Потолок зачарований Rick C137 — десятикратный от ванильного.
 *
 * В 1.21.1 максимальный уровень живёт в дата-дривен определении зачарования
 * ({@code Enchantment.definition().maxLevel()}) и он ГЛОБАЛЬНЫЙ — про игрока
 * ничего не знает. Поэтому правим не определение, а две точки применения, где
 * игрок доступен: стол зачарований и наковальню.
 *
 * Работаем ПОСТ-ФАКТУМ, по готовому предмету: читаем компонент зачарований и
 * переписываем уровни. Так мы не зависим от того, какими именно вызовами ваниль
 * пишет зачарования внутри своих методов — а она это меняет от версии к версии.
 *
 * Разброс есть только на СТОЛЕ. Наковальня считается детерминированно, и это
 * принципиально: {@code createResult} пересчитывается на каждое изменение
 * слотов, и случайность там заставляла бы результат прыгать на глазах у игрока
 * несколько раз в секунду.
 *
 * Уровни выше ванильного максимума хранятся штатно, ItemEnchantments допускает
 * 0..255. Эффекты в 1.21.1 дата-дривен и считаются от уровня, так что
 * Sharpness XXXVII реально бьёт. Римские цифры выше X ванильный локализатор не
 * знает и покажет арабские — так и оставлено, специально.
 */
public final class RickEnchant {

    public static final int MULTIPLIER = 10;
    /** Нижняя граница разброса — доля от потолка. 4 означает «не ниже четверти». */
    private static final int SPREAD_FLOOR_DIVISOR = 4;
    private static final int HARD_CAP = 255; // предел ItemEnchantments

    private RickEnchant() {}

    public static boolean applies(Player player) {
        return player != null && RickBloodline.is(player);
    }

    /** Потолок для наковальни. */
    public static int cap(Player player, int vanillaMax) {
        if (!applies(player)) return vanillaMax;
        return Math.min(vanillaMax * MULTIPLIER, HARD_CAP);
    }

    /**
     * Переписывает уровни всех зачарований предмета со случайным разбросом.
     *
     * Потолок для каждого зачарования — десятикратный ванильный максимум, но
     * выпадает не он один: уровень катается в диапазоне от четверти потолка до
     * самого потолка, со смещением к верхней части. Поэтому один и тот же
     * бросок стола даёт разные результаты, а максимум остаётся редким.
     *
     * Книги обрабатываются правильно: у зачарованной книги уровни лежат в
     * STORED_ENCHANTMENTS, а не в ENCHANTMENTS, поэтому компонент выбирается по
     * факту наличия.
     */
    public static void boostAll(ItemStack stack, RandomSource random) {
        if (stack.isEmpty()) return;

        DataComponentType<ItemEnchantments> type =
                stack.has(DataComponents.STORED_ENCHANTMENTS)
                        ? DataComponents.STORED_ENCHANTMENTS
                        : DataComponents.ENCHANTMENTS;

        ItemEnchantments current = stack.getOrDefault(type, ItemEnchantments.EMPTY);
        if (current.isEmpty()) return;

        ItemEnchantments.Mutable mutable = new ItemEnchantments.Mutable(current);
        boolean changed = false;

        for (Holder<Enchantment> holder : current.keySet()) {
            int level = current.getLevel(holder);
            if (level <= 0) continue;

            int ceiling = Math.min(level * MULTIPLIER,
                    Math.min(holder.value().getMaxLevel() * MULTIPLIER, HARD_CAP));
            int floor = Math.max(level, ceiling / SPREAD_FLOOR_DIVISOR);

            int rolled = rollBiasedHigh(random, floor, ceiling);
            if (rolled != level) {
                mutable.set(holder, rolled);
                changed = true;
            }
        }

        if (changed) stack.set(type, mutable.toImmutable());
    }

    /**
     * Случайное значение в [min, max] со смещением к верхней границе.
     *
     * Берём больший из двух равномерных бросков: среднее уезжает на две трети
     * диапазона, низ становится редким, а точный максимум перестаёт быть
     * гарантией. Ровно тот разброс, который нужен.
     */
    private static int rollBiasedHigh(RandomSource random, int min, int max) {
        if (max <= min) return min;
        float bias = Math.max(random.nextFloat(), random.nextFloat());
        return min + Math.round((max - min) * bias);
    }

    /**
     * Каким уровень ДОЛЖЕН был получиться при объединении на наковальне, если бы
     * потолок был десятикратным. Повторяет ванильное правило: равные уровни дают
     * +1, разные — больший из двух. Без случайности, см. комментарий к классу.
     */
    public static int mergedLevel(int left, int right, int vanillaMax) {
        int merged = (left == right) ? right + 1 : Math.max(left, right);
        return Math.min(merged, Math.min(vanillaMax * MULTIPLIER, HARD_CAP));
    }
}
