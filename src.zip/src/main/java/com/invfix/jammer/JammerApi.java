package com.invfix.jammer;

import com.simibubi.create.Create;
import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.LinkBehaviour;
import com.simibubi.create.content.redstone.link.RedstoneLinkBlock;
import com.simibubi.create.content.redstone.link.RedstoneLinkBlockEntity;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler;
import com.simibubi.create.infrastructure.config.AllConfigs;
import dan200.computercraft.api.lua.IComputerSystem;
import dan200.computercraft.api.lua.ILuaAPI;
import dan200.computercraft.api.lua.LuaException;
import dan200.computercraft.api.lua.LuaFunction;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.createmod.catnip.data.Couple;
import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.sublevel.SubLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Глобальная таблица {@code link} — компьютер как частотный передатчик Create.
 *
 * Это не периферия и не блок: API вешается на сам компьютер, поэтому доступно и
 * продвинутому компьютеру, и нашему саблевел-компьютеру, и компьютеру внутри
 * ракеты, без единого дополнительного предмета. Сигнал живёт ровно столько,
 * сколько живёт компьютер: {@code shutdown} у API зовётся при выключении,
 * поломке блока и выгрузке, и все узлы снимаются с сети немедленно.
 *
 * Идея простая. Create держит сеть редстоун-линков как множество участников с
 * частотной парой и позицией; блок-передатчик — просто участник, который что-то
 * вещает. Компьютер здесь регистрирует таких участников сам, сколько угодно и на
 * каких угодно частотах, стоя при этом в одной точке. Для приёмника разницы нет:
 * он видит частоту, видит силу, срабатывает.
 *
 * Практически это дистанционное управление всем, что висит на линках, без стойки
 * с передатчиками рядом с компьютером и без проводов до неё. Каналов можно
 * держать открытыми сколько угодно, и что с этим делать - дело программы: в сети
 * Create участник, вещающий убедительно, ничем не отличается от блока.
 *
 * Про саблевелы здесь сознательно не делается ничего. Sable сам редиректит
 * {@code withinRange} внутри {@code updateNetworkOf} и проецирует обе точки
 * наружу через позу их плота перед тем, как мерить расстояние, — поэтому линки
 * между двумя кораблями и между кораблём и миром работают из коробки. Узел
 * поэтому стоит на честной позиции компьютера, не спроецированной: если
 * компьютер на корабле, это локальные координаты плота, и патч Sable сам
 * разберётся, куда они попадают в мире. Спроецировать их заранее было бы прямой
 * ошибкой — узел остался бы висеть в неподвижной точке мира, пока корабль летит
 * дальше.
 */
public class JammerApi implements ILuaAPI {

    /** Как часто толкать сеть, в тиках. */
    /**
     * Как часто подтверждается помеха, в тиках.
     *
     * Раз в тик, а не раз в пять: сеть Create живёт своей жизнью, и любое чужое
     * обновление, посчитавшее мощность без нас, сбрасывает приёмники в ноль.
     * Чем реже подтверждение, тем длиннее окно, в которое чужой сигнал проходит.
     * Стоит это обхода нескольких десятков участников - на фоне серверного тика
     * незаметно.
     */
    static final int REFRESH_INTERVAL = 1;

    private final IComputerSystem system;

    /** Активные каналы: частотная пара -> её узел. */
    private final Map<Couple<RedstoneLinkNetworkHandler.Frequency>, JammerNode> channels =
            new LinkedHashMap<>();

    private int refreshCountdown = 0;

    public JammerApi(IComputerSystem system) {
        this.system = system;
    }

    @Override
    public String[] getNames() {
        return new String[]{"link"};
    }

    @Override
    public void startup() {
        JammerRegistrar.track(this);
    }

    @Override
    public void shutdown() {
        JammerRegistrar.untrack(this);
        removeAll();
    }

    // ---- Lua ----

    /**
     * Начать вещать на частоте.
     *
     * Частоты задаются идентификаторами предметов, как в самом Create, где пара
     * предметов в слотах передатчика и есть частота. Пустая строка — пустой слот.
     */
    @LuaFunction(mainThread = true)
    public final void transmit(String first, String second, int strength) throws LuaException {
        if (strength < 0 || strength > 15) throw new LuaException("strength must be 0..15");
        ServerLevel level = level();
        if (level == null) throw new LuaException("no world");

        Couple<RedstoneLinkNetworkHandler.Frequency> key = frequency(first, second);
        JammerNode node = channels.get(key);
        if (node == null) {
            node = new JammerNode(key, system.getPosition(), strength);
            channels.put(key, node);
            JammerNode added = node;
            onServer(level, () -> Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(level, added));
        } else {
            node.setTransmittedStrength(strength);
        }
        push(level, node);
    }

    /** Замолчать на одной частоте. */
    @LuaFunction(mainThread = true)
    public final boolean stop(String first, String second) throws LuaException {
        JammerNode node = channels.remove(frequency(first, second));
        if (node == null) return false;
        detach(level(), node);
        return true;
    }

    /** Замолчать везде. */
    @LuaFunction(mainThread = true)
    public final void stopAll() {
        removeAll();
    }

    /** Что этот компьютер сейчас вещает и что слышит в ответ. */
    @LuaFunction
    public final List<Map<String, Object>> listTransmitting() {
        List<Map<String, Object>> out = new ArrayList<>();
        ServerLevel level = level();

        for (Map.Entry<Couple<RedstoneLinkNetworkHandler.Frequency>, JammerNode> e : channels.entrySet()) {
            JammerNode node = e.getValue();
            Map<String, Object> m = new HashMap<>();
            m.put("first", itemId(e.getKey().getFirst()));
            m.put("second", itemId(e.getKey().getSecond()));
            m.put("strength", node.getTransmittedStrength());
            m.put("received", node.getReceivedStrength());

            // Лежим ли мы в сети Create и кого там видим.
            //
            // Без этого "глушение не действует" не отличить от трёх разных
            // причин: узел не попал в сеть, попал в свою собственную, или
            // попал в общую, но никого не достаёт. Числа отвечают сразу.
            if (level != null) {
                try {
                    Object net = Create.REDSTONE_LINK_NETWORK_HANDLER
                            .networksIn(level).get(e.getKey());
                    int total = 0, others = 0;
                    boolean present = false;
                    for (Object member : membersOf(net)) {
                        total++;
                        if (member == node) present = true;
                        else if (member instanceof IRedstoneLinkable) others++;
                    }
                    m.put("inNetwork", present);
                    m.put("networkSize", total);
                    m.put("others", others);
                } catch (Throwable t) {
                    m.put("inNetwork", "error: " + t);
                }
            }
            out.add(m);
        }
        return out;
    }

    /**
     * Поимённый разбор одной частотной сети.
     *
     * {@code listTransmitting} отвечает «сколько», а этого мало: наш узел может
     * лежать в правильной сети рядом с правильным приёмником и всё равно его не
     * питать. Здесь по каждому участнику видно, почему он получает или не
     * получает наш сигнал, ровно теми же вопросами, какие задаёт
     * {@code updateNetworkOf} у Create:
     *
     *   alive      — {@code isAlive}. Ответивший «нет» вычёркивается из сети
     *                навсегда, поэтому вызов сделан в серверном потоке.
     *   listening  — {@code isListening}. У Create это режим приёма; передатчик
     *                отвечает «нет» и наш сигнал не получит никогда.
     *   transmit   — {@code getTransmittedStrength}, вклад участника в мощность.
     *   dist       — расстояние по правилу мискина Sable: обе точки выводятся
     *                наружу через позу своего саблевела, потом меряется.
     *   inRange    — проходит ли это расстояние ограничение {@code linkRange}.
     *   rawDist    — то же без проекции, сырыми координатами плота. Осмысленное
     *                число здесь при бессмысленном dist (или наоборот) сразу
     *                показывает, чья геометрия врёт.
     *
     * Причина, по которой это понадобилось: глушение не действует, пока рядом
     * не поставить настоящий передатчик той же частоты, даже обесточенный.
     */
    @LuaFunction(mainThread = true)
    public final List<Map<String, Object>> members(String first, String second) throws LuaException {
        List<Map<String, Object>> out = new ArrayList<>();
        ServerLevel level = level();
        if (level == null) return out;
        Couple<RedstoneLinkNetworkHandler.Frequency> key = frequency(first, second);
        Object net = Create.REDSTONE_LINK_NETWORK_HANDLER.networksIn(level).get(key);
        JammerNode ours = channels.get(key);
        BlockPos here = ours != null ? ours.getLocation() : system.getPosition();
        Vec3 hereWorld = toWorld(level, here);
        double range = getRange();

        for (Object member : membersOf(net)) {
            if (!(member instanceof IRedstoneLinkable link)) continue;
            Map<String, Object> m = new HashMap<>();
            m.put("ours", member == ours);
            m.put("type", member.getClass().getSimpleName());
            BlockPos at = link.getLocation();
            m.put("x", at.getX());
            m.put("y", at.getY());
            m.put("z", at.getZ());
            try {
                m.put("alive", link.isAlive());
            } catch (Throwable t) {
                m.put("alive", "error: " + t);
            }
            m.put("listening", link.isListening());
            m.put("transmit", link.getTransmittedStrength());
            // Мировые координаты узла, а не координаты плота.
            //
            // Нужны для прицельного глушения: радар отдаёт габариты корабля в
            // мире, а сырой x у линка на плоту - двадцать миллионов. Сравнивать
            // одно с другим нельзя, а приведённые точки - можно, и тогда
            // «этот линк принадлежит той цели» перестаёт быть догадкой по
            // дальности и становится проверкой на попадание в коробку.
            Vec3 atWorld = toWorld(level, at);
            m.put("wx", atWorld.x);
            m.put("wy", atWorld.y);
            m.put("wz", atWorld.z);

            double dist = hereWorld.distanceTo(atWorld);
            m.put("dist", dist);
            m.put("inRange", dist < range);
            m.put("rawDist", Math.sqrt(here.distSqr(at)));

            // Что у приёмника внутри, а не что должно быть по нашим расчётам.
            //
            // Всё остальное в этом отчёте говорит, что сигнал обязан дойти:
            // сеть общая, узел в ней, расстояние в пределах радиуса. Значит
            // спрашивать надо не нас, а сам блок. signal - сила, которую Create
            // в него записал, powered - зажёгся ли блок. Пятнадцать в signal при
            // погашенном блоке и ноль в signal - это две совершенно разные
            // поломки, и дальше искать надо в разных местах.
            if (level.isLoaded(at) && level.getBlockEntity(at)
                    instanceof RedstoneLinkBlockEntity rl) {
                m.put("signal", rl.getReceivedSignal());
                BlockState state = level.getBlockState(at);
                if (state.hasProperty(RedstoneLinkBlock.POWERED)) {
                    m.put("powered", state.getValue(RedstoneLinkBlock.POWERED));
                }
            }
            out.add(m);
        }
        return out;
    }

    /**
     * Прослушать частоту.
     *
     * Возвращает силу, которую видит наш узел на этой паре, то есть что вещают
     * чужие передатчики в радиусе. Если канал ещё не открыт, он открывается с
     * нулевой силой — слушать можно только оттуда, где стоит узел, а нулевой
     * передатчик никому не мешает.
     */
    @LuaFunction(mainThread = true)
    public final int receive(String first, String second) throws LuaException {
        ServerLevel level = level();
        if (level == null) throw new LuaException("no world");

        Couple<RedstoneLinkNetworkHandler.Frequency> key = frequency(first, second);
        JammerNode node = channels.get(key);
        if (node == null) {
            node = new JammerNode(key, system.getPosition(), 0);
            channels.put(key, node);
            JammerNode added = node;
            onServer(level, () -> Create.REDSTONE_LINK_NETWORK_HANDLER.addToNetwork(level, added));
        }
        push(level, node);
        return node.getReceivedStrength();
    }

    /**
     * Перечислить частоты, на которых кто-то вещает поблизости.
     *
     * Без этого подавление было бы игрой в угадайку: чтобы перебить чужой
     * передатчик, надо сперва знать его частотную пару, а пара - это два
     * произвольных предмета из всей игры. Здесь берётся карта сетей уровня и
     * отбираются те, у которых хотя бы один участник попал в радиус линка.
     *
     * Расстояние меряется в мировых координатах, с явным переводом обеих точек
     * через {@code toWorld}. Прямая разность сырых позиций на саблевеле даёт
     * миллионы блоков, и в радиус не попадает никто.
     *
     * Возвращается расстояние до ближайшего участника и его сила: по ним
     * программа решает, что глушить, а что оставить. Свои узлы в выдачу не
     * попадают - иначе список бы засорялся тем, что мы сами и вещаем.
     */
    /**
     * Точка в мировых координатах, чем бы она ни была на самом деле.
     *
     * Блок на саблевеле живёт в координатах плота - восьмизначных, за двадцать
     * миллионов, - а блок на земле в обычных. Вычитать их друг из друга
     * бессмысленно: расстояние выходит в миллионы, и в радиус линка не попадает
     * никто.
     *
     * Спросить дальность у самого Create тоже не вышло: его {@code withinRange}
     * Sable подменяет и проецирует точки, но, судя по всему, опирается на
     * настоящий блок, а наш пробный узел таковым не является - проверку не
     * прошёл ни один из сорока двух живых соседей. Поэтому проекция делается
     * здесь и явно.
     */
    private static Vec3 toWorld(ServerLevel level, BlockPos pos) {
        Vec3 centre = Vec3.atCenterOf(pos);
        try {
            SubLevel sub = Sable.HELPER.getContaining(level, pos);
            if (sub != null) return sub.logicalPose().transformPosition(centre);
        } catch (Throwable ignored) {
            // Sable отсутствует или перестраивается: точка и так мировая
        }
        return centre;
    }

    /**
     * Участники одной частотной сети.
     *
     * У Create сеть - это {@code LinkedHashSet}, а не карта. Проверка на карту
     * молча отбрасывала всё: одиннадцать сетей находилось, участников ноль, и
     * снаружи это выглядело как «вокруг никого». Здесь принимается и то, и
     * другое, чтобы правка пережила смену типа на их стороне.
     */
    private static Iterable<?> membersOf(Object value) {
        if (value instanceof Map<?, ?> map) return map.values();
        if (value instanceof Iterable<?> iterable) return iterable;
        return List.of();
    }

    /**
     * Почему перебор ничего не нашёл.
     *
     * Пустая выдача {@code scan} имеет пять разных причин, и снаружи они
     * выглядят одинаково. Здесь счётчик на каждом отсеве: сколько сетей вообще
     * зарегистрировано в этом мире, сколько в них участников, сколько из них
     * живых, сколько чужих и сколько прошло проверку дальности. Первый же ноль
     * в цепочке и есть ответ.
     */
    @LuaFunction
    @SuppressWarnings("unchecked")
    public final Map<String, Object> scanStats() {
        Map<String, Object> stats = new HashMap<>();
        int networks = 0, members = 0, alive = 0, foreign = 0, inRange = 0;

        ServerLevel level = level();
        stats.put("level", level == null ? "null" : level.dimension().location().toString());
        if (level == null) {
            stats.put("networks", 0);
            return stats;
        }

        BlockPos here = system.getPosition();
        Vec3 origin = toWorld(level, here);
        stats.put("worldX", origin.x);
        stats.put("worldZ", origin.z);
        stats.put("x", here.getX());
        stats.put("y", here.getY());
        stats.put("z", here.getZ());

        Map<?, ?> nets;
        try {
            nets = Create.REDSTONE_LINK_NETWORK_HANDLER.networksIn(level);
        } catch (Throwable t) {
            stats.put("error", String.valueOf(t));
            return stats;
        }
        if (nets != null) {
            for (Map.Entry<?, ?> entry : nets.entrySet()) {
                networks++;
                for (Object member : membersOf(entry.getValue())) {
                    members++;
                    if (!(member instanceof IRedstoneLinkable node)) continue;
                    if (node instanceof JammerNode) continue;
                    foreign++;
                    // Считается для отчёта, но ничего не отсеивает: из потока
                    // компьютера этот вызов всегда лжёт.
                    if (node.isAlive()) alive++;
                    try {
                        double d = toWorld(level, node.getLocation()).distanceTo(origin);
                        // Ближайший сосед в выдаче всегда, даже если он вне
                        // радиуса: по нему видно, осмысленно ли вообще
                        // считается расстояние.
                        Object prev = stats.get("nearest");
                        if (!(prev instanceof Double p) || d < p) stats.put("nearest", d);
                        if (d <= getRange()) inRange++;
                    } catch (Throwable ignored) {
                    }
                }
            }
        }

        stats.put("networks", networks);
        stats.put("members", members);
        stats.put("foreign", foreign);
        stats.put("alive", alive);
        stats.put("inRange", inRange);
        stats.put("range", getRange());
        return stats;
    }

    // Без mainThread. Обращений к миру внутри больше нет, а на саблевеле
    // задачи главного потока в этой сборке не доносят результат: методы с
    // такой пометкой возвращают пустоту, и мы это уже проходили с шиной.
    @LuaFunction
    @SuppressWarnings("unchecked")
    public final List<Map<String, Object>> scan() {
        List<Map<String, Object>> out = new ArrayList<>();
        ServerLevel level = level();
        if (level == null) return out;

        BlockPos here = system.getPosition();
        Vec3 origin = toWorld(level, here);
        double range = getRange();

        Map<?, ?> networks;
        try {
            networks = Create.REDSTONE_LINK_NETWORK_HANDLER.networksIn(level);
        } catch (Throwable t) {
            return out;
        }
        if (networks == null) return out;

        for (Map.Entry<?, ?> entry : networks.entrySet()) {
            if (!(entry.getKey() instanceof Couple<?> key)) continue;

            double best = Double.MAX_VALUE;
            Vec3 nearest = null;
            int strength = 0;
            int count = 0;
            for (Object member : membersOf(entry.getValue())) {
                if (!(member instanceof IRedstoneLinkable node)) continue;
                if (node instanceof JammerNode) continue;   // это мы сами

                // Проверки isAlive здесь нет намеренно. У Create она делает
                // level.isLoaded и level.getBlockEntity, то есть лезет в мир, а
                // периферия и глобальные таблицы работают в потоке компьютера:
                // оттуда обращение к уровню возвращает не ошибку, а ложь, и
                // живые узлы поголовно считались мёртвыми.
                //
                // Обходиться без неё безопасно. Create сам вычищает мёртвые
                // узлы из сети, а если один и задержится, худшее последствие -
                // лишняя частота в списке глушения. Это дешевле, чем не видеть
                // эфир вообще.

                Vec3 at = toWorld(level, node.getLocation());
                double d = at.distanceTo(origin);
                if (d > range) continue;

                count++;
                if (d < best) { best = d; nearest = at; }
                strength = Math.max(strength, node.getTransmittedStrength());
            }
            if (count == 0) continue;

            Map<String, Object> m = new HashMap<>();
            m.put("first", itemId((RedstoneLinkNetworkHandler.Frequency) key.getFirst()));
            m.put("second", itemId((RedstoneLinkNetworkHandler.Frequency) key.getSecond()));
            m.put("strength", strength);
            m.put("nodes", count);
            m.put("distance", best);
            // Ближайший узел частоты в мировых координатах. По нему видно, какому
            // корпусу принадлежит частота, без отдельного вызова на каждую.
            if (nearest != null) {
                m.put("wx", nearest.x);
                m.put("wy", nearest.y);
                m.put("wz", nearest.z);
            }
            out.add(m);
        }
        return out;
    }

    /** Радиус линков Create, в блоках. За его пределами вещать бессмысленно. */
    @LuaFunction
    public final int getRange() {
        return AllConfigs.server().logistics.linkRange.get();
    }

    /** Сколько частот открыто прямо сейчас. */
    @LuaFunction
    public final int getChannelCount() {
        return channels.size();
    }

    // ---- обслуживание ----

    /** Зовётся из серверного тика, не из потока компьютера. */
    void serverTick() {
        if (channels.isEmpty()) return;
        if (--refreshCountdown > 0) return;
        refreshCountdown = REFRESH_INTERVAL;

        ServerLevel level = level();
        if (level == null) return;
        for (JammerNode node : channels.values()) {
            node.setLocation(system.getPosition());
            push(level, node);
        }
    }

    /**
     * Толкнуть сеть.
     *
     * Делать это приходится самим и регулярно. Create пересчитывает силу у
     * приёмника только когда кто-то из участников об этом попросит, а взаимное
     * расстояние здесь меняется молча: летит либо корабль с приёмником, либо тот,
     * на котором стоит компьютер. Без периодического толчка дальний борт узнал бы
     * о смене сигнала только когда на нём кто-нибудь дёрнет рычаг.
     */
    /**
     * Выполнить в серверном потоке, чего бы это ни стоило.
     *
     * Не удобство, а обязательное условие. {@code updateNetworkOf} у Create
     * проходит по сети и вычёркивает из неё всех, кто ответил, что не жив:
     *
     *     if (!other.isAlive()) iterator.remove();
     *
     * А {@code isAlive} у настоящего линка спрашивает мир - {@code isLoaded} и
     * {@code getBlockEntity}, - и из потока компьютера отвечает ложью на всё.
     * Один вызов оттуда вычёркивает из сетей все чужие линки навсегда: не
     * глушит, а уничтожает, и новый линк той же частоты уже ничего не получает,
     * потому что самой сети больше нет.
     *
     * Так и произошло при выключении компьютера: CC зовёт shutdown в своём
     * потоке, а мы оттуда трогали сеть.
     */
    private static void onServer(ServerLevel level, Runnable job) {
        if (level == null) return;
        MinecraftServer server = level.getServer();
        if (server == null) return;
        if (server.isSameThread()) {
            job.run();
        } else {
            server.execute(job);
        }
    }

    /**
     * Разослать свою силу приёмникам самостоятельно, не через updateNetworkOf.
     *
     * Просить об этом Create оказалось бесполезно. Отчёт показывал одно и то же:
     * сеть общая, узел в ней, расстояние в пределах радиуса, передаём
     * пятнадцать - а у приёмников ноль. Ни обновление от своего имени, ни
     * обновление от имени каждого приёмника до них не доходило. При этом
     * настоящий блок-передатчик, поставленный рядом, ту же частоту оживлял, и
     * наш узел при нём начинал слышать свои же пятнадцать. То есть в сети мы
     * лежим правильно, а рассылка у Create по дороге теряется - и где именно,
     * снаружи не видно.
     *
     * Поэтому рассылка делается здесь. Это ровно то, что делает
     * {@code updateNetworkOf}, разобранное на части:
     *
     *   мощность    - максимум переданного среди участников в радиусе;
     *   доставка    - {@code setReceivedStrength} каждому слушающему в радиусе.
     *
     * Отличие одно, и оно намеренное: радиус считается нашей проекцией, той же,
     * что в {@code members}, а не проверкой Create. Наша проекция проверена
     * числами - сорок блоков между плотами вместо двух тысяч сырых, - а
     * проверка Create подменяется мискином Sable, и что она отвечает изнутри
     * чужого метода, узнать нельзя.
     *
     * {@code newPosition} поднимается перед доставкой. Это поле у Create
     * публичное и служит ровно затвором: при снятом флаге приёмник молча
     * игнорирует любую переданную ему силу, а снимается флаг при чтении из NBT
     * у линка, стоящего на прежнем месте.
     *
     * Набор участников копируется перед обходом: доставка может привести к
     * изменению сети на стороне Create.
     */
    private static void push(ServerLevel level, JammerNode node) {
        onServer(level, () -> {
            RedstoneLinkNetworkHandler handler = Create.REDSTONE_LINK_NETWORK_HANDLER;
            List<IRedstoneLinkable> members = new ArrayList<>();
            for (Object member : membersOf(handler.networksIn(level).get(node.getNetworkKey()))) {
                if (member instanceof IRedstoneLinkable link) members.add(link);
            }

            Vec3 here = toWorld(level, node.getLocation());
            double rangeSqr = AllConfigs.server().logistics.linkRange.get()
                    * (double) AllConfigs.server().logistics.linkRange.get();
            int power = 0;

            // Один проход на отбор, второй только на доставку. Дорогое здесь -
            // isAlive, который лезет в мир за блок-сущностью, и проекция
            // координат; и то и другое делается по разу на участника, а не по
            // два, как выходило бы при двух полных проходах.
            List<IRedstoneLinkable> reachable = new ArrayList<>();
            for (IRedstoneLinkable link : members) {
                try {
                    if (!link.isAlive()) continue;
                    if (here.distanceToSqr(toWorld(level, link.getLocation())) >= rangeSqr) continue;
                    reachable.add(link);
                    power = Math.max(power, link.getTransmittedStrength());
                } catch (Throwable ignored) {
                    // чужой линк не должен ронять весь проход
                }
            }

            for (IRedstoneLinkable link : reachable) {
                try {
                    if (link == node || !link.isListening()) continue;
                    if (link instanceof LinkBehaviour behaviour) behaviour.newPosition = true;
                    link.setReceivedStrength(power);
                } catch (Throwable ignored) {
                    // и здесь тоже
                }
            }
        });
    }

    private void removeAll() {
        ServerLevel level = level();
        for (JammerNode node : channels.values()) detach(level, node);
        channels.clear();
    }

    /**
     * Снять узел с сети.
     *
     * Сначала гасим передачу и только потом убираем: {@code updateNetworkOf}
     * прогоняет по сети уже нулевое значение, и приёмники отпускает в тот же тик.
     * Просто удалить узел мало — оставшиеся участники о его исчезновении узнают
     * лишь на своём следующем обновлении, и сигнал висел бы после смерти
     * компьютера.
     */
    private static void detach(ServerLevel level, JammerNode node) {
        node.kill();
        if (level == null) return;
        push(level, node);
        onServer(level, () -> Create.REDSTONE_LINK_NETWORK_HANDLER.removeFromNetwork(level, node));
    }

    private ServerLevel level() {
        try {
            return system.getLevel();
        } catch (Throwable t) {
            return null;
        }
    }

    // ---- частоты ----

    private static Couple<RedstoneLinkNetworkHandler.Frequency> frequency(String first, String second)
            throws LuaException {
        return Couple.create(parse(first), parse(second));
    }

    private static RedstoneLinkNetworkHandler.Frequency parse(String id) throws LuaException {
        if (id == null || id.isEmpty()) return RedstoneLinkNetworkHandler.Frequency.EMPTY;
        ResourceLocation key = ResourceLocation.tryParse(id.toLowerCase(Locale.ROOT));
        if (key == null) throw new LuaException("bad item id: " + id);
        Item item = BuiltInRegistries.ITEM.get(key);
        if (item == Items.AIR) throw new LuaException("no such item: " + id);
        return RedstoneLinkNetworkHandler.Frequency.of(new ItemStack(item));
    }

    private static String itemId(RedstoneLinkNetworkHandler.Frequency frequency) {
        ItemStack stack = frequency.getStack();
        if (stack.isEmpty()) return "";
        return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
    }
}