package com.invfix.jammer;

import dan200.computercraft.api.ComputerCraftAPI;
import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Вешает таблицу {@code link} на все компьютеры и обновляет их узлы.
 *
 * Обновление вынесено в серверный тик намеренно. У {@code ILuaAPI} есть свой
 * {@code update}, но он вызывается из потока компьютера, а сеть редстоун-линков
 * Create к этому не готова — трогать её оттуда значит рано или поздно поймать
 * гонку на карте участников. Здесь же всё происходит в главном потоке, ровно
 * там, где Create сам с ней работает.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class JammerRegistrar {

    private JammerRegistrar() {}

    /**
     * Живые API.
     *
     * Слабые ссылки: если компьютер исчез, не позвав {@code shutdown} — например
     * мир выгрузился целиком, — набор не должен держать его вечно. Узлы в таком
     * случае уйдут вместе с сетью уровня.
     */
    private static final Set<JammerApi> ACTIVE =
            Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap<>()));

    static void track(JammerApi api) {
        ACTIVE.add(api);
    }

    static void untrack(JammerApi api) {
        ACTIVE.remove(api);
    }

    @EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD)
    public static final class Setup {

        private Setup() {}

        @SubscribeEvent
        public static void onCommonSetup(FMLCommonSetupEvent event) {
            ModList mods = ModList.get();
            if (mods == null || !mods.isLoaded("computercraft") || !mods.isLoaded("create")) return;
            event.enqueueWork(() -> ComputerCraftAPI.registerAPIFactory(JammerApi::new));
        }
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        if (ACTIVE.isEmpty()) return;
        synchronized (ACTIVE) {
            for (JammerApi api : ACTIVE) {
                try {
                    api.serverTick();
                } catch (Throwable ignored) {
                    // один сломавшийся глушитель не должен ронять серверный тик
                }
            }
        }
    }
}
