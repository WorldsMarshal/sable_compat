package com.invfix.jammer;

import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;

/**
 * Один поддельный передатчик редстоун-линка.
 *
 * Для Create это обычный участник сети: у него есть частотная пара, позиция и
 * сила сигнала, и он ничем не отличается от настоящего блока-передатчика. Разница
 * только в том, что стоит он не там, где блок, а там, куда его поставил
 * компьютер — и таких узлов на одну частоту может быть несколько, по одному на
 * каждое координатное пространство, до которого нужно дотянуться.
 *
 * Узел слушает и передаёт одновременно: передача - это то, ради чего он заведён,
 * а приём достаётся почти бесплатно и позволяет программе прочитать, что на этой
 * частоте вещает кто-то ещё.
 */
public class JammerNode implements IRedstoneLinkable {

    private final Couple<RedstoneLinkNetworkHandler.Frequency> key;
    private BlockPos location;
    private int transmitted;
    private int received;
    private boolean alive = true;

    public JammerNode(Couple<RedstoneLinkNetworkHandler.Frequency> key, BlockPos location, int strength) {
        this.key = key;
        this.location = location.immutable();
        this.transmitted = strength;
    }

    @Override
    public int getTransmittedStrength() {
        return alive ? transmitted : 0;
    }

    public void setTransmittedStrength(int strength) {
        this.transmitted = strength;
    }

    @Override
    public void setReceivedStrength(int strength) {
        this.received = strength;
    }

    public int getReceivedStrength() {
        return received;
    }

    /**
     * Всегда true.
     *
     * Слушающий узел стоит Create одного присваивания на обновление сети, зато
     * даёт программе читать частоту без второго набора узлов.
     */
    @Override
    public boolean isListening() {
        return true;
    }

    @Override
    public boolean isAlive() {
        return alive;
    }

    /**
     * Убить узел.
     *
     * Create вычищает мёртвых из сети сам на ближайшем обновлении, поэтому
     * достаточно снять флаг — но мы всё равно снимаем узел явно, чтобы сигнал
     * пропадал в тот же тик, когда компьютер выключили или сломали, а не когда
     * кто-то по соседству дёрнет свой рычаг.
     */
    public void kill() {
        alive = false;
        transmitted = 0;
    }

    @Override
    public Couple<RedstoneLinkNetworkHandler.Frequency> getNetworkKey() {
        return key;
    }

    @Override
    public BlockPos getLocation() {
        return location;
    }

    /** Корабли двигаются, поэтому позиция узла пересчитывается на каждом обновлении. */
    public void setLocation(BlockPos location) {
        this.location = location.immutable();
    }
}
