package com.invfix.xcoin;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * X Coin на сервере. Нажатие (клиент шлёт Use): монеты в главной руке нет — фокус «появление», есть — «исчезание»;
 * всем рядом — Trick (анимация руки, искра, блёстки), через {@link XCoin#REVEAL} тиков — сам фокус и звон:
 *  - появление: прочие монеты X из инвентаря убираются, предмет из главной руки — в свободный слот, в руку —
 *    монета (свободного слота нет — монета в инвентарь, нет и там — к ногам);
 *  - исчезание: монета из главной руки пропадает.
 * Пока фокус идёт — новое нажатие не принимается.
 *
 * Возврат монеты после Aim flight ({@link #returnCoin}): тот же фокус «появление» с той же монетой (режим
 * сохраняется), если главная рука пуста; иначе — молча в инвентарь (нет места — к ногам). Монета у игрока
 * одна: если он уже достал другую, вернувшаяся просто исчезает.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class XCoinHandler {

    /** coin — монета, которая появится (null — новая). */
    private record Pending(int kind, long reveal, long end, boolean revealed, @Nullable ItemStack coin) {}

    private static final Map<UUID, Pending> PENDING = new HashMap<>();

    private XCoinHandler() {}

    static void use(ServerPlayer player) {
        if (!XCoin.eligible(player) || player.isSpectator() || player.isSleeping()) return;
        if (PENDING.containsKey(player.getUUID()) || com.invfix.flat.Flat.flat(player)
                || com.invfix.compat.LovsDowned.downed(player)) return;
        int kind = XCoin.isCoin(player.getMainHandItem()) ? XCoin.KIND_VANISH : XCoin.KIND_CONJURE;
        if (kind == XCoin.KIND_CONJURE && !player.getMainHandItem().isEmpty() && player.getInventory().getFreeSlot() < 0
                && !hasCoin(player.getInventory())) {
            player.displayClientMessage(Component.literal("§7Рука занята, а в инвентаре нет места"), true);
            return;
        }
        start(player, kind, null);
    }

    private static void start(ServerPlayer player, int kind, @Nullable ItemStack coin) {
        long now = player.getServer().getTickCount();
        PENDING.put(player.getUUID(), new Pending(kind, now + XCoin.REVEAL, now + XCoin.duration(kind), false, coin));
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player,
                new XCoinPackets.Trick(player.getId(), kind, player.getMainArm() == HumanoidArm.RIGHT));
    }

    /** Монета вернулась после Aim flight. */
    static void returnCoin(ServerPlayer player, ItemStack coin) {
        Inventory inv = player.getInventory();
        if (hasCoin(inv)) return;
        Pending p = PENDING.get(player.getUUID());
        if (p != null && p.kind() == XCoin.KIND_CONJURE) return;
        if (p == null && player.isAlive() && !player.isSpectator() && inv.getItem(inv.selected).isEmpty()) {
            start(player, XCoin.KIND_CONJURE, coin.copy());
            return;
        }
        if (!inv.add(coin.copy())) player.drop(coin.copy(), false);
        inv.setChanged();
    }

    /** Идёт фокус (монета появляется или исчезает). */
    static boolean busy(ServerPlayer player) {
        return PENDING.containsKey(player.getUUID());
    }

    private static boolean hasCoin(Inventory inv) {
        for (int i = 0; i < inv.getContainerSize(); i++) if (XCoin.isCoin(inv.getItem(i))) return true;
        return false;
    }

    private static void reveal(ServerPlayer player, int kind, @Nullable ItemStack stored) {
        if (!player.isAlive()) return;
        Inventory inv = player.getInventory();
        if (kind == XCoin.KIND_VANISH) {
            if (!XCoin.isCoin(player.getMainHandItem())) return;
            inv.setItem(inv.selected, ItemStack.EMPTY);
        } else {
            for (int i = 0; i < inv.getContainerSize(); i++) if (XCoin.isCoin(inv.getItem(i))) inv.setItem(i, ItemStack.EMPTY);
            ItemStack coin = stored != null ? stored.copy() : new ItemStack(XCoinRegistry.COIN.get());
            ItemStack held = inv.getItem(inv.selected);
            if (held.isEmpty()) {
                inv.setItem(inv.selected, coin);
            } else {
                int free = inv.getFreeSlot();
                if (free >= 0) {
                    inv.setItem(free, held);
                    inv.setItem(inv.selected, coin);
                } else if (!inv.add(coin)) {
                    player.drop(coin, false);
                }
            }
        }
        inv.setChanged();
        player.level().playSound(null, player.getX(), player.getEyeY() - 0.3, player.getZ(),
                XCoinRegistry.CONJURE.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || PENDING.isEmpty() || player.getServer() == null) return;
        Pending p = PENDING.get(player.getUUID());
        if (p == null) return;
        long now = player.getServer().getTickCount();
        if (!p.revealed() && now >= p.reveal()) {
            PENDING.put(player.getUUID(), p = new Pending(p.kind(), p.reveal(), p.end(), true, p.coin()));
            try {
                reveal(player, p.kind(), p.coin());
            } catch (Exception ignored) {}
        }
        if (now >= p.end()) PENDING.remove(player.getUUID());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        PENDING.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        PENDING.remove(event.getOriginal().getUUID());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        PENDING.clear();
    }
}
