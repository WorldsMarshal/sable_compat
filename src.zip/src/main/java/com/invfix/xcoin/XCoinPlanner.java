package com.invfix.xcoin;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * Путь монеты Aim flight: в воздухе она не поворачивает — только прямые и отскоки от поверхностей блоков.
 * Отскок разрешён, если угол в точке отскока (между обратным входящим и исходящим направлением) в пределах
 * {@link #MIN_ANGLE}…{@link #MAX_ANGLE} — ни очень острый (почти назад), ни очень тупой (почти насквозь), — и
 * исходящее направление уходит от поверхности.
 *
 * Поиск — встречный: из цели — {@link #SIDE_RAYS} лучей до стен (точки, откуда цель видна: последний отскок),
 * от старта — лучевой по слоям отскоков: из старта {@link #START_RAYS} направлений, из точек отскока —
 * {@link #UNIFORM} по сфере (Фибоначчи) и {@link #BIASED} в конусе к цели, луч до стены на {@link #CAST}
 * блоков; слой — лучшие {@link #BEAM} точки (ближе к цели). На каждом слое — сначала прямая видимость цели,
 * потом связка «точка слоя → точка у цели» (углы в обеих точках, затем прямая видимость; самые короткие
 * первыми, не больше {@link #LOS_CAP} проверок на слой). До maxBounces отскоков. Путь — точки (старт,
 * отскоки, цель) и нормали поверхностей в них.
 *
 * Путь не выходит из шара (center, radius) — области полёта монеты: точки отскока и цель — внутри (отрезки
 * между точками внутри выпуклого шара — тоже внутри).
 *
 * Лучи не грузят чанки: незагруженный блок — конец луча (для {@link #clear} — преграда, для {@link #cast} —
 * стены нет).
 */
public final class XCoinPlanner {

    public static final double MIN_ANGLE = Math.toRadians(30.0);
    public static final double MAX_ANGLE = Math.toRadians(150.0);
    public static final int MAX_BOUNCES = 3;
    private static final int START_RAYS = 160;
    private static final int SIDE_RAYS = 160;
    private static final int UNIFORM = 64;
    private static final int BIASED = 24;
    private static final int BEAM = 12;
    private static final int LOS_CAP = 300;
    private static final double CAST = 32.0;
    private static final double MIN_HOP = 1.2;
    private static final double LEAVE = 0.12;
    /** Удар в стену не по касательной: -cos угла к нормали не меньше. */
    private static final double GRAZE = 0.15;
    private static final Vec3[] SPHERE = sphere(UNIFORM);
    private static final Vec3[] SPHERE_DENSE = sphere(START_RAYS);
    private static final Vec3[] SPHERE_SIDE = sphere(SIDE_RAYS);
    /** Луч упёрся в незагруженный чанк. */
    private static final BlockHitResult STOP = BlockHitResult.miss(Vec3.ZERO, Direction.UP, BlockPos.ZERO);

    public record Path(List<Vec3> points, List<Vec3> normals) {
        public double length() {
            double l = 0.0;
            for (int i = 1; i < points.size(); i++) l += points.get(i).distanceTo(points.get(i - 1));
            return l;
        }
    }

    private record State(Vec3 p, @Nullable Vec3 in, @Nullable Vec3 normal, @Nullable State parent, double length) {}

    /** Точка отскока у цели: out — направление от неё к цели, len — до цели. */
    private record Side(Vec3 p, Vec3 n, Vec3 out, double len) {}

    private record Link(double len, State s, Side t) {}

    private XCoinPlanner() {}

    private static Vec3[] sphere(int n) {
        Vec3[] out = new Vec3[n];
        double golden = Math.PI * (3.0 - Math.sqrt(5.0));
        for (int i = 0; i < n; i++) {
            double y = 1.0 - 2.0 * (i + 0.5) / n, r = Math.sqrt(1.0 - y * y), a = golden * i;
            out[i] = new Vec3(Math.cos(a) * r, y, Math.sin(a) * r);
        }
        return out;
    }

    /** Угол в точке отскока допустим (in — куда летела, out — куда полетит; null — без ограничения). */
    public static boolean angleOk(@Nullable Vec3 in, Vec3 out) {
        if (in == null) return true;
        double c = -in.dot(out);
        return c <= Math.cos(MIN_ANGLE) && c >= Math.cos(MAX_ANGLE);
    }

    public static boolean leaves(@Nullable Vec3 normal, Vec3 out) {
        return normal == null || out.dot(normal) > LEAVE;
    }

    /** Level#clip (блоки по коллизии, без жидкостей), но без загрузки чанков. */
    private static BlockHitResult trace(Level level, Vec3 a, Vec3 b) {
        ClipContext ctx = new ClipContext(a, b, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, CollisionContext.empty());
        return BlockGetter.traverseBlocks(a, b, ctx, (c, pos) -> {
            if (!level.isLoaded(pos)) return STOP;
            BlockState state = level.getBlockState(pos);
            return level.clipWithInteractionOverride(c.getFrom(), c.getTo(), pos, c.getBlockShape(state, level, pos), state);
        }, c -> {
            Vec3 d = c.getFrom().subtract(c.getTo());
            return BlockHitResult.miss(c.getTo(), Direction.getNearest(d.x, d.y, d.z), BlockPos.containing(c.getTo()));
        });
    }

    /** Прямая видимость a→b (только блоки). */
    public static boolean clear(Level level, Vec3 a, Vec3 b) {
        BlockHitResult hit = trace(level, a, b);
        return hit != STOP && hit.getType() == HitResult.Type.MISS;
    }

    /** Луч из a по dir до стены (или null — пусто на всей длине). */
    @Nullable
    public static BlockHitResult cast(Level level, Vec3 a, Vec3 dir, double len) {
        BlockHitResult hit = trace(level, a, a.add(dir.scale(len)));
        return hit != STOP && hit.getType() == HitResult.Type.BLOCK ? hit : null;
    }

    /**
     * Отскок без цели: зеркальное отражение, а если угол в точке отскока вне MIN_ANGLE…MAX_ANGLE — ближайшее
     * к нему допустимое направление (в плоскости обратного входящего и зеркального). null — уйти от
     * поверхности нельзя.
     */
    @Nullable
    public static Vec3 freeBounce(Vec3 in, Vec3 normal) {
        Vec3 r = in.subtract(normal.scale(2.0 * in.dot(normal)));
        Vec3 a = in.scale(-1.0);
        double phi = Math.acos(Math.max(-1.0, Math.min(1.0, a.dot(r))));
        double target = Math.max(MIN_ANGLE, Math.min(MAX_ANGLE, phi));
        Vec3 out = r;
        if (Math.abs(target - phi) > 1.0E-6) {
            Vec3 w = r.subtract(a.scale(a.dot(r)));
            if (w.lengthSqr() < 1.0E-8) {
                // ровно навстречу — уводим вдоль поверхности (любое касательное направление)
                w = a.cross(Math.abs(a.y) < 0.9 ? new Vec3(0.0, 1.0, 0.0) : new Vec3(1.0, 0.0, 0.0));
            }
            w = w.normalize();
            out = a.scale(Math.cos(target)).add(w.scale(Math.sin(target))).normalize();
        }
        return leaves(normal, out) ? out : null;
    }

    public static Vec3 normal(Direction d) {
        return new Vec3(d.getStepX(), d.getStepY(), d.getStepZ());
    }

    /** Точка чуть над поверхностью — лучи из неё не цепляют стену, от которой отскочили. */
    public static Vec3 lift(Vec3 p, @Nullable Vec3 normal) {
        return normal != null ? p.add(normal.scale(0.02)) : p;
    }

    /**
     * Путь из start к aim; in/normal — как монета пришла в start (null — бросок из руки); cone — для первого
     * отрезка: направление броска не дальше 90° от него (null — без ограничения); center/radius — шар полёта.
     */
    @Nullable
    public static Path plan(Level level, Vec3 start, @Nullable Vec3 in, @Nullable Vec3 normal, @Nullable Vec3 cone,
                            Vec3 aim, int maxBounces, Vec3 center, double radius) {
        double r2 = radius * radius;
        if (aim.distanceToSqr(center) > r2) return null;
        List<State> layer = new ArrayList<>();
        layer.add(new State(start, in, normal, null, 0.0));
        List<Side> side = null;
        Random rnd = new Random(Double.doubleToLongBits(start.x * 31 + start.y * 17 + start.z + aim.x * 7 + aim.z));
        int los = 0;
        for (int depth = 0; depth <= maxBounces; depth++) {
            State best = null;
            double bestLen = Double.MAX_VALUE;
            for (State s : layer) {
                if (reaches(level, s, cone, aim)) {
                    double len = s.length() + s.p().distanceTo(aim);
                    if (len < bestLen) { best = s; bestLen = len; }
                }
            }
            if (best != null) return build(best, null, aim);
            if (depth + 1 > maxBounces) break;
            if (side == null) side = side(level, aim, center, r2);
            List<Link> links = new ArrayList<>();
            for (State s : layer) {
                for (Side t : side) {
                    Vec3 v = t.p().subtract(s.p());
                    double l = v.length();
                    if (l < MIN_HOP) continue;
                    Vec3 d = v.scale(1.0 / l);
                    if (!allowed(s, cone, d) || -d.dot(t.n()) < GRAZE || !angleOk(d, t.out())) continue;
                    links.add(new Link(s.length() + l + t.len(), s, t));
                }
            }
            links.sort(Comparator.comparingDouble(Link::len));
            for (Link k : links) {
                if (los >= LOS_CAP * (depth + 1)) break;
                los++;
                if (clear(level, lift(k.s().p(), k.s().normal()), lift(k.t().p(), k.t().n()))) return build(k.s(), k.t(), aim);
            }
            if (depth + 2 > maxBounces) break;
            List<State> next = new ArrayList<>();
            for (State s : layer) expand(level, s, cone, aim, rnd, next, center, r2);
            if (next.isEmpty()) break;
            next.sort(Comparator.comparingDouble(s -> s.p().distanceTo(aim) + 0.15 * s.length()));
            List<State> kept = new ArrayList<>();
            for (State s : next) {
                boolean near = false;
                for (State k : kept) if (k.p().distanceToSqr(s.p()) < 1.0) { near = true; break; }
                if (!near) kept.add(s);
                if (kept.size() >= BEAM) break;
            }
            layer = kept;
        }
        return null;
    }

    /** Точки на стенах, из которых цель видна и в которые можно прийти не по касательной. */
    private static List<Side> side(Level level, Vec3 aim, Vec3 center, double r2) {
        List<Side> out = new ArrayList<>();
        for (Vec3 d : SPHERE_SIDE) {
            BlockHitResult hit = cast(level, aim, d, CAST);
            if (hit == null) continue;
            Vec3 n = normal(hit.getDirection());
            double l = hit.getLocation().distanceTo(aim);
            if (l < 0.6 || d.dot(n) > -GRAZE || hit.getLocation().distanceToSqr(center) > r2) continue;
            out.add(new Side(hit.getLocation(), n, d.scale(-1.0), l));
        }
        return out;
    }

    private static boolean allowed(State s, @Nullable Vec3 cone, Vec3 d) {
        if (s.parent() == null && cone != null && d.dot(cone) < 0.0) return false;
        return angleOk(s.in(), d) && leaves(s.normal(), d);
    }

    private static boolean reaches(Level level, State s, @Nullable Vec3 cone, Vec3 aim) {
        Vec3 d = aim.subtract(s.p());
        double len = d.length();
        if (len < 1e-4) return true;
        Vec3 dir = d.scale(1.0 / len);
        if (!allowed(s, cone, dir)) return false;
        return clear(level, lift(s.p(), s.normal()), aim);
    }

    private static void expand(Level level, State s, @Nullable Vec3 cone, Vec3 aim, Random rnd, List<State> out,
                               Vec3 center, double r2) {
        Vec3 from = lift(s.p(), s.normal());
        Vec3 toAim = aim.subtract(s.p()).normalize();
        List<Vec3> dirs = new ArrayList<>(START_RAYS + BIASED);
        Collections.addAll(dirs, s.parent() == null ? SPHERE_DENSE : SPHERE);
        for (int i = 0; i < BIASED; i++) {
            Vec3 r = SPHERE[rnd.nextInt(UNIFORM)];
            dirs.add(toAim.add(r.scale(0.9 * rnd.nextDouble())).normalize());
        }
        for (Vec3 d : dirs) {
            if (!allowed(s, cone, d)) continue;
            BlockHitResult hit = cast(level, from, d, CAST);
            if (hit == null) continue;
            double hop = hit.getLocation().distanceTo(from);
            if (hop < MIN_HOP || hit.getLocation().distanceToSqr(center) > r2) continue;
            Vec3 n = normal(hit.getDirection());
            // в стену — не по касательной (иначе отскок неотличим от скольжения)
            if (-d.dot(n) < GRAZE) continue;
            out.add(new State(hit.getLocation(), d, n, s, s.length() + hop));
        }
    }

    /** Цепочка состояний до end, затем точка у цели (если есть) и цель. */
    private static Path build(State end, @Nullable Side last, Vec3 aim) {
        List<Vec3> pts = new ArrayList<>(), ns = new ArrayList<>();
        pts.add(aim);
        ns.add(null);
        if (last != null) {
            pts.add(last.p());
            ns.add(last.n());
        }
        for (State s = end; s != null; s = s.parent()) {
            pts.add(s.p());
            ns.add(s.normal());
        }
        Collections.reverse(pts);
        Collections.reverse(ns);
        return new Path(pts, ns);
    }
}
