package com.invfix.xcoin;

import com.invfix.kitsune.KitsuneRace;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import javax.annotation.Nullable;

/**
 * X Coin (Kitsune, LVL {@link #LVL_REQUIRED}) — монета X (To Be Hero X), как фокус: рука поднимается, щелчок
 * кистью — и монета уже между пальцами, со звоном (x_coin/conjure), искрой-«кира», лучами и блёстками.
 * Монета уже в руке — тот же фокус наоборот: исчезает. Монета у игрока одна: при появлении все прочие
 * монеты X из инвентаря «переходят» в руку (убираются). Монета — предмет части будущих способностей.
 *
 * Тайминг (тики от нажатия): рука поднимается к {@link #RAISE}, рывок кистью, на {@link #REVEAL} — монета
 * появляется (или исчезает) и звон; фокус длится {@link #CONJURE_TICKS} / {@link #VANISH_TICKS}.
 */
public final class XCoin {

    public static final String ABILITY = "§6§lX Coin";
    public static final int LVL_REQUIRED = 10;

    public static final int KIND_CONJURE = 0;
    public static final int KIND_VANISH = 1;

    public static final int RAISE = 5;
    public static final int REVEAL = 6;
    public static final int CONJURE_TICKS = 20;
    public static final int VANISH_TICKS = 16;

    private XCoin() {}

    public static int duration(int kind) {
        return kind == KIND_VANISH ? VANISH_TICKS : CONJURE_TICKS;
    }

    public static boolean isCoin(@Nullable ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.is(XCoinRegistry.COIN.get());
    }

    public static boolean eligible(@Nullable Entity entity) {
        if (!(entity instanceof Player player)) return false;
        try {
            InvincibleIncModVariables.PlayerVariables v = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            return KitsuneRace.isKitsune(v.Race) && v.Lvl >= LVL_REQUIRED;
        } catch (Exception e) {
            return false;
        }
    }
}
