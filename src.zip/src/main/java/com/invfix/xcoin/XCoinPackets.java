package com.invfix.xcoin;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Пакеты X Coin. */
public final class XCoinPackets {

    private XCoinPackets() {}

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath("sable_compat", path);
    }

    /** Клиент → сервер: фокус (достать монету / убрать её из руки). */
    public record Use() implements CustomPacketPayload {
        public static final Type<Use> TYPE = new Type<>(id("x_coin_use"));
        public static final StreamCodec<FriendlyByteBuf, Use> STREAM_CODEC = StreamCodec.of((buf, m) -> {}, buf -> new Use());

        @Override public Type<Use> type() { return TYPE; }

        public static void handleServer(Use pkt, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (ctx.player() instanceof ServerPlayer player) XCoinHandler.use(player);
            });
        }
    }

    /** Сервер → игроки рядом и сам игрок: фокус начался (kind — XCoin#KIND_*, mainRight — главная рука правая). */
    public record Trick(int entityId, int kind, boolean mainRight) implements CustomPacketPayload {
        public static final Type<Trick> TYPE = new Type<>(id("x_coin_trick"));
        public static final StreamCodec<FriendlyByteBuf, Trick> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> {
                    buf.writeVarInt(m.entityId());
                    buf.writeVarInt(m.kind());
                    buf.writeBoolean(m.mainRight());
                },
                buf -> new Trick(buf.readVarInt(), buf.readVarInt(), buf.readBoolean()));

        @Override public Type<Trick> type() { return TYPE; }
    }

    /** Клиент → сервер: назначить способность в слот. */
    public record Assign() implements CustomPacketPayload {
        public static final Type<Assign> TYPE = new Type<>(id("x_coin_assign"));
        public static final StreamCodec<FriendlyByteBuf, Assign> STREAM_CODEC = StreamCodec.of((buf, m) -> {}, buf -> new Assign());

        @Override public Type<Assign> type() { return TYPE; }

        public static void handleServer(Assign pkt, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (!(ctx.player() instanceof ServerPlayer player) || !XCoin.eligible(player)) return;
                try {
                    InvincibleIncModVariables.PlayerVariables vars =
                            player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                    vars.AbilitySet = XCoin.ABILITY;
                    vars.abilityDescription = XCoin.ABILITY + " | LVL:" + XCoin.LVL_REQUIRED
                            + " | Фокус: монета появляется в руке (в руке — исчезает)";
                    vars.markSyncDirty();
                } catch (Exception ignored) {}
            });
        }
    }
}
