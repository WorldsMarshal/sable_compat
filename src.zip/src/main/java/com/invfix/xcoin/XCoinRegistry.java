package com.invfix.xcoin;

import com.mojang.serialization.Codec;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Монета X (sable_compat:x_coin) и её звук: x_coin_conjure — звон монеты (0,67 с, моно, звон в самом начале —
 * на {@link XCoin#REVEAL}). Монета — во вкладке «Инструменты и приспособления». Компонент x_coin_mode —
 * выбранная способность монеты (XCoin#MODES).
 */
public final class XCoinRegistry {

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("sable_compat");
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, "sable_compat");
    public static final DeferredRegister<DataComponentType<?>> COMPONENTS =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, "sable_compat");

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> MODE =
            COMPONENTS.register("x_coin_mode", () -> DataComponentType.<Integer>builder()
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT)
                    .build());

    public static final DeferredItem<XCoinItem> COIN = ITEMS.register("x_coin",
            () -> new XCoinItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));

    public static final ResourceLocation CONJURE_ID = ResourceLocation.fromNamespaceAndPath("sable_compat", "x_coin_conjure");
    public static final DeferredHolder<SoundEvent, SoundEvent> CONJURE = SOUNDS.register("x_coin_conjure",
            () -> SoundEvent.createVariableRangeEvent(CONJURE_ID));

    private XCoinRegistry() {}

    public static void register(IEventBus modEventBus) {
        COMPONENTS.register(modEventBus);
        ITEMS.register(modEventBus);
        SOUNDS.register(modEventBus);
        modEventBus.addListener(XCoinRegistry::onBuildCreativeTabs);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) event.accept(COIN);
    }
}
