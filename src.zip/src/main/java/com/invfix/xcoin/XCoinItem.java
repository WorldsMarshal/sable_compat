package com.invfix.xcoin;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;

import java.util.List;
import java.util.function.Consumer;

/**
 * Монета X: настоящая 3D-модель (диск с гуртом, client.XCoinRenderer), аверс — треугольник с эмблемой,
 * реверс — «0». Сама по себе ничего не делает — предмет для способностей X.
 */
public class XCoinItem extends Item {

    public XCoinItem(Properties properties) {
        super(properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        lines.add(Component.translatable("tooltip.sable_compat.x_coin").withStyle(ChatFormatting.GRAY));
    }

    /** Отрисовка через BEWLR. Зовётся только на клиенте — клиентские классы на сервере не грузятся. */
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(com.invfix.xcoin.client.XCoinItemExtensions.INSTANCE);
    }
}
