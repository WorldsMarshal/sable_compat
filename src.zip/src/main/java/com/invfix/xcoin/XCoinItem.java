package com.invfix.xcoin;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;

import java.util.List;
import java.util.function.Consumer;

/**
 * Монета X: настоящая 3D-модель (диск с гуртом, client.XCoinRenderer), аверс — треугольник с эмблемой,
 * реверс — «0». Способности встроены в монету и доступны только расе Kitsune: ПКМ — использовать выбранную
 * (XCoin#MODES; Aim flight — XCoinFlight), Shift+ПКМ — переключить на следующую.
 */
public class XCoinItem extends Item {

    public XCoinItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!XCoin.kitsune(player)) return InteractionResultHolder.pass(stack);
        if (player.isSecondaryUseActive()) {
            if (!level.isClientSide) {
                int mode = (XCoin.mode(stack) + 1) % XCoin.MODES.length;
                stack.set(XCoinRegistry.MODE.get(), mode);
                player.displayClientMessage(Component.literal("§6X Coin §7— §e" + XCoin.MODES[mode]), true);
                level.playSound(null, player.getX(), player.getEyeY(), player.getZ(), XCoinRegistry.CONJURE.get(),
                        SoundSource.PLAYERS, 0.35F, 2.0F);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        if (!level.isClientSide && player instanceof ServerPlayer sp && XCoin.mode(stack) == XCoin.MODE_AIM_FLIGHT
                && !XCoinFlight.launch(sp, hand)) {
            return InteractionResultHolder.fail(stack);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        lines.add(Component.translatable("tooltip.sable_compat.x_coin").withStyle(ChatFormatting.GRAY));
        lines.add(Component.translatable("tooltip.sable_compat.x_coin.mode",
                Component.literal(XCoin.MODES[XCoin.mode(stack)]).withStyle(ChatFormatting.YELLOW)).withStyle(ChatFormatting.GOLD));
        lines.add(Component.translatable("tooltip.sable_compat.x_coin.controls").withStyle(ChatFormatting.DARK_GRAY));
    }

    /** Отрисовка через BEWLR. Зовётся только на клиенте — клиентские классы на сервере не грузятся. */
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(com.invfix.xcoin.client.XCoinItemExtensions.INSTANCE);
    }
}
