package com.invfix.xcoin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/**
 * Монета X — настоящий диск: аверс (+Z) и реверс (−Z) кольцами по {@link #RINGS}×{@link #SEGMENTS}, гурт
 * {@link #SEGMENTS} гранями. Текстура — атлас 512×512 (textures/entity/x_coin.png): аверс (0,0)-(256,256),
 * реверс (256,0)-(512,256), гурт (0,256)-(512,288). Рельеф запечён в текстуру, свет мира — по нормалям.
 *
 * Поверх — блик: та же текстура аддитивно (RenderType#eyes), яркость вершин — полоса, что раз в
 * {@link #GLINT_PERIOD} тиков пробегает по монете наискосок за {@link #GLINT_SWEEP} тиков.
 *
 * Модель в своих единицах: центр в нуле, радиус {@link #R}, толщина 2·{@link #HALF}. Как предмет — в кубе
 * 0…1 (builtin/entity), сдвиг на центр делает {@link #renderByItem}.
 */
@OnlyIn(Dist.CLIENT)
public final class XCoinRenderer extends BlockEntityWithoutLevelRenderer {

    public static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/x_coin.png");

    public static final float R = 0.5F;
    public static final float HALF = 0.0375F;
    private static final int RINGS = 6;
    private static final int SEGMENTS = 48;
    private static final float GLINT_PERIOD = 80.0F;
    private static final float GLINT_SWEEP = 22.0F;
    private static final int FULL_BRIGHT = 15728880;

    private static XCoinRenderer instance;

    private XCoinRenderer() {
        super(Minecraft.getInstance().getBlockEntityRenderDispatcher(), Minecraft.getInstance().getEntityModels());
    }

    public static XCoinRenderer instance() {
        if (instance == null) instance = new XCoinRenderer();
        return instance;
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext ctx, PoseStack pose, MultiBufferSource buffers,
                             int light, int overlay) {
        pose.pushPose();
        pose.translate(0.5F, 0.5F, 0.5F);
        render(pose, buffers, light, overlay, glintPhase(0.0F));
        pose.popPose();
    }

    /** Положение полосы блика (−1,6…1,6), или NaN — блика сейчас нет. Сдвиг — чтобы монеты не блестели разом. */
    public static float glintPhase(float shift) {
        Minecraft mc = Minecraft.getInstance();
        float t = (mc.level != null ? mc.level.getGameTime() : System.currentTimeMillis() / 50L)
                + mc.getTimer().getGameTimeDeltaPartialTick(false) + shift;
        float c = t % GLINT_PERIOD;
        if (c > GLINT_SWEEP) return Float.NaN;
        return -1.6F + 3.2F * c / GLINT_SWEEP;
    }

    /** Монета в нуле позы. glint — {@link #glintPhase} (NaN — без блика). */
    public static void render(PoseStack pose, MultiBufferSource buffers, int light, int overlay, float glint) {
        PoseStack.Pose p = pose.last();
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutout(TEXTURE));
        faces(p, vc, light, overlay, Float.NaN);
        edge(p, vc, light, overlay);
        if (!Float.isNaN(glint)) faces(p, buffers.getBuffer(RenderType.eyes(TEXTURE)), FULL_BRIGHT, OverlayTexture.NO_OVERLAY, glint);
    }

    private static float bright(float glint, float x, float y) {
        if (Float.isNaN(glint)) return 1.0F;
        float d = (x * 0.8F + y * 0.6F) / R - glint;
        return 0.65F * (float) Math.exp(-d * d * 7.0F);
    }

    private static void faces(PoseStack.Pose p, VertexConsumer vc, int light, int overlay, float glint) {
        for (int side = 0; side < 2; side++) {
            boolean front = side == 0;
            float z = front ? HALF : -HALF, nz = front ? 1.0F : -1.0F;
            for (int k = 0; k < RINGS; k++) {
                float r0 = R * k / RINGS, r1 = R * (k + 1) / RINGS;
                for (int i = 0; i < SEGMENTS; i++) {
                    float a0 = Mth.TWO_PI * i / SEGMENTS, a1 = Mth.TWO_PI * (i + 1) / SEGMENTS;
                    float[][] q = {{r0, a0}, {r1, a0}, {r1, a1}, {r0, a1}};
                    for (int j = 0; j < 4; j++) {
                        float[] v = q[front ? j : 3 - j];
                        float x = v[0] * Mth.cos(v[1]), y = v[0] * Mth.sin(v[1]);
                        float u = front ? (0.5F + x / (2 * R)) * 0.5F : 0.5F + (0.5F - x / (2 * R)) * 0.5F;
                        float w = (0.5F - y / (2 * R)) * 0.5F;
                        float b = bright(glint, front ? x : -x, y);
                        vc.addVertex(p, x, y, z).setColor(b, b, b, 1.0F).setUv(u, w).setOverlay(overlay).setLight(light)
                                .setNormal(p, 0.0F, 0.0F, nz);
                    }
                }
            }
        }
    }

    private static void edge(PoseStack.Pose p, VertexConsumer vc, int light, int overlay) {
        float v0 = 256.0F / 512.0F, v1 = 288.0F / 512.0F;
        for (int i = 0; i < SEGMENTS; i++) {
            float a0 = Mth.TWO_PI * i / SEGMENTS, a1 = Mth.TWO_PI * (i + 1) / SEGMENTS;
            float c0 = Mth.cos(a0), s0 = Mth.sin(a0), c1 = Mth.cos(a1), s1 = Mth.sin(a1);
            float u0 = (float) i / SEGMENTS, u1 = (float) (i + 1) / SEGMENTS;
            vc.addVertex(p, R * c0, R * s0, HALF).setColor(1.0F, 1.0F, 1.0F, 1.0F).setUv(u0, v0).setOverlay(overlay).setLight(light).setNormal(p, c0, s0, 0.0F);
            vc.addVertex(p, R * c0, R * s0, -HALF).setColor(1.0F, 1.0F, 1.0F, 1.0F).setUv(u0, v1).setOverlay(overlay).setLight(light).setNormal(p, c0, s0, 0.0F);
            vc.addVertex(p, R * c1, R * s1, -HALF).setColor(1.0F, 1.0F, 1.0F, 1.0F).setUv(u1, v1).setOverlay(overlay).setLight(light).setNormal(p, c1, s1, 0.0F);
            vc.addVertex(p, R * c1, R * s1, HALF).setColor(1.0F, 1.0F, 1.0F, 1.0F).setUv(u1, v0).setOverlay(overlay).setLight(light).setNormal(p, c1, s1, 0.0F);
        }
    }
}
