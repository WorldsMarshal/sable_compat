package com.invfix.xcoin.client;

import com.invfix.xcoin.XCoinFlight;
import com.invfix.xcoin.XCoinPackets;
import com.invfix.xcoin.XCoinRegistry;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Aim flight на клиенте: монета идёт по пути сервера (XCoinPackets.FlightPath) со скоростью XCoinFlight#SPEED,
 * отставая на {@link #DELAY} тик — правка пути приходит раньше, чем монета доходит до точки отскока. События
 * (FlightEvent) срабатывают, когда монета доходит до их отметки пути.
 *
 * Отрисовка (после частиц): 3D-монета кувыркается через ребро (поперёк полёта, {@link #FLIP}°/тик) с бегущим
 * бликом; за ней — золотой след {@link #TRAIL} блоков (мягкая лента к камере, сужается к хвосту, плюс яркая
 * сердцевина) — на изломах след ломается вместе с путём; хвост дотягивается до конца после исчезновения монеты.
 * Вспышки (XCoinFx#draw, аддитивно): отскок — малая, попадание — большая, сбитый снаряд — белая вспышка,
 * 14 длинных лучей-осколков и большая искра, конец полёта — блёстки исчезновения. Вместе со вспышкой —
 * звук и частицы события ({@link #fire}): отскок — звон монеты выше тоном и искры; попадание — критический
 * удар и звон трезубца; снаряд — бьющееся стекло, аметист, звон и искры с «концом стержня»; конец — тихий звон.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class XCoinFlightClient {

    private static final float COIN_RADIUS = 0.13F;
    private static final double TRAIL = 5.0;
    private static final float DELAY = 1.0F;
    private static final float FLIP = 48.0F;
    private static final float BURST_END = 14.0F;
    private static final float TIMEOUT = 400.0F;
    private static final int FULL_BRIGHT = 15728880;

    private static final class Flight {
        final List<Vec3> pts = new ArrayList<>();
        final List<Double> cum = new ArrayList<>();
        final List<XCoinPackets.FlightEvent> events = new ArrayList<>();
        final float t0;
        final long seed;
        double end = Double.MAX_VALUE;

        Flight(float t0, long seed) {
            this.t0 = t0;
            this.seed = seed;
        }
    }

    private record Burst(int kind, Vec3 pos, float t0, long seed) {}

    private static final Map<Integer, Flight> FLIGHTS = new HashMap<>();
    private static final List<Burst> BURSTS = new ArrayList<>();
    private static ClientLevel lastLevel;

    private XCoinFlightClient() {}

    // ── пакеты ───────────────────────────────────────────────────────────────

    public static void onPath(XCoinPackets.FlightPath pkt) {
        List<Vec3> pts = pkt.points();
        if (pts.isEmpty()) return;
        Flight f = FLIGHTS.get(pkt.flightId());
        if (f == null) {
            float now = XCoinClient.now(0.0F);
            f = new Flight(now - (float) (pkt.startDist() / XCoinFlight.SPEED), pkt.flightId() * 977L + (long) now);
            FLIGHTS.put(pkt.flightId(), f);
            f.pts.add(pts.get(0));
            f.cum.add(pkt.startDist());
        } else {
            cut(f, pkt.startDist(), pts.get(0));
        }
        for (int i = 1; i < pts.size(); i++) {
            f.cum.add(f.cum.get(f.cum.size() - 1) + pts.get(i).distanceTo(f.pts.get(f.pts.size() - 1)));
            f.pts.add(pts.get(i));
        }
    }

    public static void onEvent(XCoinPackets.FlightEvent pkt) {
        Flight f = FLIGHTS.get(pkt.flightId());
        if (f == null) {
            BURSTS.add(new Burst(pkt.kind(), pkt.pos(), XCoinClient.now(0.0F), pkt.flightId() * 31L + pkt.kind()));
            Minecraft mc = Minecraft.getInstance();
            if (mc.level != null) fire(mc.level, pkt.kind(), pkt.pos());
            return;
        }
        f.events.add(pkt);
        if (pkt.kind() == XCoinFlight.EV_END) f.end = Math.min(f.end, pkt.dist());
    }

    /** Оставить путь до отметки d; точка на ней — p. */
    private static void cut(Flight f, double d, Vec3 p) {
        int k = f.cum.size() - 1;
        while (k > 0 && f.cum.get(k) > d) k--;
        while (f.pts.size() > k + 1) {
            f.pts.remove(f.pts.size() - 1);
            f.cum.remove(f.cum.size() - 1);
        }
        if (d - f.cum.get(k) > 1.0E-4) {
            f.pts.add(p);
            f.cum.add(d);
        } else {
            f.pts.set(k, p);
        }
    }

    // ── путь ─────────────────────────────────────────────────────────────────

    private static int segment(Flight f, double d) {
        int k = 0;
        while (k < f.cum.size() - 2 && f.cum.get(k + 1) < d) k++;
        return k;
    }

    private static Vec3 at(Flight f, double d) {
        if (f.pts.size() == 1) return f.pts.get(0);
        int k = segment(f, d);
        double a = f.cum.get(k), b = f.cum.get(k + 1);
        double u = b - a > 1.0E-6 ? Mth.clamp((d - a) / (b - a), 0.0, 1.0) : 1.0;
        return f.pts.get(k).lerp(f.pts.get(k + 1), u);
    }

    private static Vec3 dirAt(Flight f, double d) {
        for (int k = Math.min(segment(f, d), f.pts.size() - 2); k >= 0; k--) {
            Vec3 v = f.pts.get(k + 1).subtract(f.pts.get(k));
            if (v.lengthSqr() > 1.0E-8) return v.normalize();
        }
        return new Vec3(0.0, 0.0, 1.0);
    }

    // ── отрисовка ────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != lastLevel) {
            lastLevel = mc.level;
            FLIGHTS.clear();
            BURSTS.clear();
        }
        if (mc.level == null || (FLIGHTS.isEmpty() && BURSTS.isEmpty())) return;
        if (com.invfix.portal.client.PortalPassCompat.inPortalPass()) return;
        float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        float now = XCoinClient.now(partial);
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        Vector3f right = new Vector3f(1.0F, 0.0F, 0.0F).rotate(camera.rotation());
        Vector3f up = new Vector3f(0.0F, 1.0F, 0.0F).rotate(camera.rotation());
        Vector3f down = new Vector3f(0.0F, -1.0F, 0.0F);
        PoseStack pose = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        Matrix4f m = pose.last().pose();
        boolean coins = false;
        List<Flight> trails = new ArrayList<>();
        List<double[]> spans = new ArrayList<>();

        // события по отметкам, монеты (свой буфер — ленты и вспышки потом, одним проходом)
        for (Iterator<Map.Entry<Integer, Flight>> it = FLIGHTS.entrySet().iterator(); it.hasNext(); ) {
            Flight f = it.next().getValue();
            double d = Math.max(0.0, (now - f.t0 - DELAY) * XCoinFlight.SPEED);
            for (Iterator<XCoinPackets.FlightEvent> ei = f.events.iterator(); ei.hasNext(); ) {
                XCoinPackets.FlightEvent ev = ei.next();
                if (ev.dist() > d) continue;
                BURSTS.add(new Burst(ev.kind(), ev.pos(), now - (float) ((d - ev.dist()) / XCoinFlight.SPEED),
                        f.seed + ev.kind() * 131L + (long) (ev.dist() * 7.0)));
                fire(mc.level, ev.kind(), ev.pos());
                ei.remove();
            }
            if (d > f.end + TRAIL || now - f.t0 > TIMEOUT) {
                it.remove();
                continue;
            }
            double head = Math.min(d, f.end);
            trails.add(f);
            spans.add(new double[]{Math.max(f.cum.get(0), head - TRAIL), head});
            if (d >= f.end) continue;
            Vec3 p = at(f, head);
            if (p.distanceToSqr(cam) > 160.0 * 160.0) continue;
            coin(pose, buffers, mc.level, f, p, dirAt(f, head), cam, now);
            coins = true;
        }

        if (coins) {
            buffers.endBatch(RenderType.entityCutout(XCoinRenderer.TEXTURE));
            buffers.endBatch(RenderType.eyes(XCoinRenderer.TEXTURE));
        }

        VertexConsumer fx = buffers.getBuffer(RenderType.eyes(XCoinFx.TEXTURE));
        for (int i = 0; i < trails.size(); i++) trail(fx, m, trails.get(i), cam, spans.get(i)[0], spans.get(i)[1]);
        for (Iterator<Burst> it = BURSTS.iterator(); it.hasNext(); ) {
            Burst b = it.next();
            float s = now - b.t0();
            if (s > BURST_END) {
                it.remove();
                continue;
            }
            if (s < 0.0F || b.pos().distanceToSqr(cam) > 160.0 * 160.0) continue;
            Vector3f c = new Vector3f((float) (b.pos().x - cam.x), (float) (b.pos().y - cam.y), (float) (b.pos().z - cam.z));
            switch (b.kind()) {
                case XCoinFlight.EV_BOUNCE -> XCoinFx.draw(fx, m, c, right, up, down, 0.5F, s, b.seed());
                case XCoinFlight.EV_HIT -> XCoinFx.draw(fx, m, c, right, up, down, 0.95F, s, b.seed());
                case XCoinFlight.EV_SHATTER -> {
                    shatter(fx, m, c, right, up, s, b.seed());
                    XCoinFx.draw(fx, m, c, right, up, down, 1.2F, s, b.seed());
                }
                default -> XCoinFx.draw(fx, m, c, right, up, down, 0.3F, s, b.seed());
            }
        }

        buffers.endBatch(RenderType.eyes(XCoinFx.TEXTURE));
    }

    /** Звук и частицы события полёта. */
    private static void fire(ClientLevel level, int kind, Vec3 p) {
        RandomSource r = level.random;
        switch (kind) {
            case XCoinFlight.EV_BOUNCE -> {
                sound(level, p, XCoinRegistry.CONJURE.get(), 0.75F, 1.7F + r.nextFloat() * 0.25F);
                particles(level, ParticleTypes.CRIT, p, 6, 0.25);
            }
            case XCoinFlight.EV_HIT -> {
                sound(level, p, SoundEvents.PLAYER_ATTACK_CRIT, 1.0F, 1.2F);
                sound(level, p, SoundEvents.TRIDENT_HIT, 0.8F, 1.6F);
                particles(level, ParticleTypes.CRIT, p, 14, 0.45);
            }
            case XCoinFlight.EV_SHATTER -> {
                sound(level, p, SoundEvents.GLASS_BREAK, 1.0F, 1.5F);
                sound(level, p, SoundEvents.AMETHYST_CLUSTER_BREAK, 1.0F, 1.2F);
                sound(level, p, XCoinRegistry.CONJURE.get(), 0.9F, 2.0F);
                particles(level, ParticleTypes.CRIT, p, 18, 0.5);
                particles(level, ParticleTypes.END_ROD, p, 5, 0.12);
            }
            default -> sound(level, p, XCoinRegistry.CONJURE.get(), 0.45F, 1.25F);
        }
    }

    private static void sound(ClientLevel level, Vec3 p, SoundEvent sound, float volume, float pitch) {
        level.playLocalSound(p.x, p.y, p.z, sound, SoundSource.PLAYERS, volume, pitch, false);
    }

    /** Как ServerLevel#sendParticles: разброс 0,05, скорости — нормальные с масштабом speed. */
    private static void particles(ClientLevel level, ParticleOptions type, Vec3 p, int count, double speed) {
        RandomSource r = level.random;
        for (int i = 0; i < count; i++) {
            level.addParticle(type, p.x + r.nextGaussian() * 0.05, p.y + r.nextGaussian() * 0.05, p.z + r.nextGaussian() * 0.05,
                    r.nextGaussian() * speed, r.nextGaussian() * speed, r.nextGaussian() * speed);
        }
    }

    /** Монета в p, летит по dir: кувыркается вокруг оси поперёк полёта. */
    private static void coin(PoseStack pose, MultiBufferSource buffers, ClientLevel level, Flight f, Vec3 p, Vec3 dir,
                             Vec3 cam, float now) {
        Vector3f fw = new Vector3f((float) dir.x, (float) dir.y, (float) dir.z);
        Vector3f side = new Vector3f(fw).cross(0.0F, 1.0F, 0.0F);
        if (side.lengthSquared() < 1.0E-4F) side.set(1.0F, 0.0F, 0.0F);
        side.normalize();
        Vector3f up2 = new Vector3f(side).cross(fw).normalize();
        float th = (now * FLIP + (f.seed & 255L)) * Mth.DEG_TO_RAD;
        Vector3f y = new Vector3f(up2).mul(Mth.cos(th)).add(new Vector3f(fw).mul(Mth.sin(th)));
        Vector3f z = new Vector3f(side).cross(y);
        Quaternionf q = new Quaternionf().setFromNormalized(new Matrix3f(side.x, side.y, side.z, y.x, y.y, y.z, z.x, z.y, z.z));
        pose.pushPose();
        pose.translate(p.x - cam.x, p.y - cam.y, p.z - cam.z);
        pose.mulPose(q);
        float sc = COIN_RADIUS / XCoinRenderer.R;
        pose.scale(sc, sc, sc);
        float glint = (now * 0.35F + (f.seed & 15L)) % 3.2F - 1.6F;
        XCoinRenderer.render(pose, buffers, LevelRenderer.getLightColor(level, BlockPos.containing(p)),
                OverlayTexture.NO_OVERLAY, glint);
        pose.popPose();
    }

    /** След от отметки tail до head: лента к камере (мягкие края — срез точки текстуры) и сердцевина. */
    private static void trail(VertexConsumer vc, Matrix4f m, Flight f, Vec3 cam, double tail, double head) {
        if (head - tail < 0.05) return;
        List<Vector3f> ps = new ArrayList<>();
        List<Float> us = new ArrayList<>();
        double step = 0.4;
        double x = tail;
        int k = segment(f, tail);
        while (true) {
            Vec3 p = at(f, x);
            ps.add(new Vector3f((float) (p.x - cam.x), (float) (p.y - cam.y), (float) (p.z - cam.z)));
            us.add((float) ((x - tail) / TRAIL));
            if (x >= head) break;
            double nx = Math.min(head, x + step);
            // изломы пути — точно в вершинах
            while (k + 1 < f.cum.size() && f.cum.get(k + 1) <= x + 1.0E-6) k++;
            if (k + 1 < f.cum.size() && f.cum.get(k + 1) < nx) nx = f.cum.get(k + 1);
            x = nx;
        }
        if (ps.size() < 2) return;
        double total = (head - tail) / TRAIL;
        band(vc, m, ps, us, total, 0.085F, 1.0F, 0.72F, 0.28F);
        band(vc, m, ps, us, total, 0.03F, 1.0F, 0.95F, 0.78F);
    }

    private static void band(VertexConsumer vc, Matrix4f m, List<Vector3f> ps, List<Float> us, double total,
                             float width, float r, float g, float b) {
        Vector3f[] sides = new Vector3f[ps.size()];
        for (int i = 0; i < ps.size(); i++) {
            Vector3f t = i + 1 < ps.size() ? new Vector3f(ps.get(i + 1)).sub(ps.get(i)) : new Vector3f(ps.get(i)).sub(ps.get(i - 1));
            Vector3f toCam = new Vector3f(ps.get(i)).negate();
            Vector3f s = toCam.cross(t);
            sides[i] = s.lengthSquared() > 1.0E-10F ? s.normalize() : (i > 0 ? sides[i - 1] : new Vector3f(0.0F, 1.0F, 0.0F));
        }
        for (int i = 0; i + 1 < ps.size(); i++) {
            float ua = us.get(i) / (float) Math.max(total, 1.0E-3), ub = us.get(i + 1) / (float) Math.max(total, 1.0E-3);
            float wa = width * (0.15F + 0.85F * ua), wb = width * (0.15F + 0.85F * ub);
            float ka = ua * ua, kb = ub * ub;
            Vector3f a = ps.get(i), c = ps.get(i + 1);
            vertex(vc, m, new Vector3f(sides[i]).mul(-wa).add(a), 0.5F, r * ka, g * ka, b * ka);
            vertex(vc, m, new Vector3f(sides[i + 1]).mul(-wb).add(c), 0.5F, r * kb, g * kb, b * kb);
            vertex(vc, m, new Vector3f(sides[i + 1]).mul(wb).add(c), 1.0F, r * kb, g * kb, b * kb);
            vertex(vc, m, new Vector3f(sides[i]).mul(wa).add(a), 1.0F, r * ka, g * ka, b * ka);
        }
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, Vector3f p, float u, float r, float g, float b) {
        vc.addVertex(m, p.x, p.y, p.z).setColor(r, g, b, 1.0F).setUv(u, 0.5F).setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(FULL_BRIGHT).setNormal(0.0F, 1.0F, 0.0F);
    }

    /** Сбитый снаряд: белая вспышка и лучи-осколки наружу (в плоскости экрана). */
    private static void shatter(VertexConsumer vc, Matrix4f m, Vector3f c, Vector3f right, Vector3f up, float s, long seed) {
        if (s < 2.5F) {
            float k = 1.0F - s / 2.5F;
            XCoinFx.sprite(vc, m, c, right, up, 0.5F + 0.6F * s, 0.0F, true, k, k * 0.97F, k * 0.9F);
        }
        if (s >= 7.0F) return;
        float k = 1.0F - XCoinClient.smooth(s / 7.0F);
        java.util.Random r = new java.util.Random(seed * 17L + 11L);
        for (int i = 0; i < 14; i++) {
            float a = Mth.TWO_PI * (i + r.nextFloat() * 0.7F) / 14.0F;
            Vector3f dir = new Vector3f(right).mul(Mth.cos(a)).add(new Vector3f(up).mul(Mth.sin(a)));
            Vector3f side = new Vector3f(up).mul(Mth.cos(a)).sub(new Vector3f(right).mul(Mth.sin(a)));
            float speed = 0.22F + 0.18F * r.nextFloat();
            float len = (0.35F + 0.5F * r.nextFloat()) * k;
            float r0 = 0.15F + speed * s;
            XCoinFx.streak(vc, m, new Vector3f(c).add(new Vector3f(dir).mul(r0 + len * 0.5F)), dir, side, len, 0.028F,
                    k, 0.93F * k, 0.8F * k);
        }
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        FLIGHTS.clear();
        BURSTS.clear();
    }
}
