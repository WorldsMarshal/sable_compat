package com.invfix.xcoin.client;

import com.invfix.xcoin.XCoin;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * Аниме-вспышка фокуса X Coin в момент появления (исчезания) монеты, от XCoin#REVEAL (s — тики от него):
 *  - большая четырёхлучевая искра-«кира» (0…6, вспыхивает за тик, гаснет, поворачиваясь) и вторая, поменьше,
 *    наискосок вверх-вправо, на 1,5 тика позже;
 *  - мягкая вспышка (0…3);
 *  - лучи-разлёт: 10 тонких штрихов от монеты наружу (0…4);
 *  - блёстки: 16 точек разлетаются вверх-в стороны, падают и мерцают (0…14).
 * Всё — аддитивно (RenderType#eyes), тёплое золото. В мире — у кончиков пальцев главной руки (у себя от
 * первого лица — в руке, XCoinHand), в плоскости экрана.
 *
 * Здесь же от третьего лица — сама монета на время фокуса (слой предмета её не рисует, XCoinHeldItemMixin):
 * у кончиков пальцев, лицом к смотрящему, с прыжком и вращением XCoinClient#coinScale / #coinSpin.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class XCoinFx {

    public static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/x_coin_fx.png");
    private static final int FULL_BRIGHT = 15728880;
    private static final float END = 14.0F;
    /**
     * Радиус монеты в руке от третьего лица, блоков — с ванильный золотой самородок (6 px спрайта × 0,55
     * thirdperson_righthand item/generated = 3,3 px модели; модель игрока × 0,9375).
     */
    private static final float COIN_RADIUS = 1.65F * 0.9375F / 16.0F;
    /** Размер вспышки фокуса от третьего лица. */
    private static final float FX_SIZE = 0.42F;

    private record Active(int entityId, long seed) {}

    private static final List<Active> ACTIVE = new ArrayList<>();

    private XCoinFx() {}

    static void start(Entity e, int kind) {
        ACTIVE.removeIf(a -> a.entityId() == e.getId());
        ACTIVE.add(new Active(e.getId(), (long) e.getId() * 31L + (long) XCoinClient.now(0.0F)));
    }

    static long seed(int entityId) {
        for (Active a : ACTIVE) if (a.entityId() == entityId) return a.seed();
        return entityId;
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || ACTIVE.isEmpty()) return;
        if (com.invfix.portal.client.PortalPassCompat.inPortalPass()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            ACTIVE.clear();
            return;
        }
        float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        Vector3f right = new Vector3f(1.0F, 0.0F, 0.0F).rotate(camera.rotation());
        Vector3f up = new Vector3f(0.0F, 1.0F, 0.0F).rotate(camera.rotation());
        PoseStack pose = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        boolean drew = false, coins = false;
        for (int i = ACTIVE.size() - 1; i >= 0; i--) {
            Active a = ACTIVE.get(i);
            XCoinClient.Trick t = XCoinClient.trick(a.entityId());
            Entity e = mc.level.getEntity(a.entityId());
            float age = XCoinClient.age(a.entityId(), partial);
            float s = age - XCoin.REVEAL;
            if (t == null || !(e instanceof Player p) || age < 0.0F || s > END) {
                if (t == null || age < 0.0F || s > END) ACTIVE.remove(i);
                continue;
            }
            // у себя от первого лица — рисует XCoinHand
            if (p == mc.player && mc.options.getCameraType().isFirstPerson()) continue;
            Vec3 at = XCoinClient.fingertips(p, partial, t.mainRight(), XCoinClient.flick(age)).add(0.0, 0.04, 0.0);
            if (at.distanceToSqr(cam) > 96.0 * 96.0) continue;
            Vector3f rel = new Vector3f((float) (at.x - cam.x), (float) (at.y - cam.y), (float) (at.z - cam.z));
            boolean coin = t.kind() == XCoin.KIND_CONJURE ? age >= XCoin.REVEAL : age < XCoin.REVEAL;
            float scale = XCoinClient.coinScale(t.kind(), age);
            if (coin && scale > 0.001F) {
                pose.pushPose();
                pose.translate(rel.x, rel.y, rel.z);
                pose.mulPose(camera.rotation());
                pose.mulPose(com.mojang.math.Axis.YP.rotationDegrees(XCoinClient.coinSpin(t.kind(), age)));
                float sc = COIN_RADIUS / XCoinRenderer.R * scale;
                pose.scale(sc, sc, sc);
                XCoinRenderer.render(pose, buffers, net.minecraft.client.renderer.LevelRenderer.getLightColor(mc.level,
                        net.minecraft.core.BlockPos.containing(at)), OverlayTexture.NO_OVERLAY, XCoinRenderer.glintPhase(5.0F));
                pose.popPose();
                coins = true;
            }
            if (s < 0.0F) continue;
            pose.pushPose();
            Matrix4f m = pose.last().pose();
            draw(buffers.getBuffer(RenderType.eyes(TEXTURE)), m, rel, right, up,
                    new Vector3f(0.0F, -1.0F, 0.0F), FX_SIZE, s, a.seed());
            pose.popPose();
            drew = true;
        }
        if (coins) {
            buffers.endBatch(RenderType.entityCutout(XCoinRenderer.TEXTURE));
            buffers.endBatch(RenderType.eyes(XCoinRenderer.TEXTURE));
        }
        if (drew) buffers.endBatch(RenderType.eyes(TEXTURE));
    }

    // ── рисование (общее с XCoinHand) ────────────────────────────────────────

    /**
     * Вспышка в точке c (в пространстве матрицы m): right/up — плоскость экрана, down — «вниз» для падения
     * блёсток, size — масштаб (≈ блоки), s — тики от появления монеты.
     */
    static void draw(VertexConsumer vc, Matrix4f m, Vector3f c, Vector3f right, Vector3f up, Vector3f down,
                     float size, float s, long seed) {
        // вспышка
        if (s < 3.0F) {
            float k = 1.0F - s / 3.0F;
            sprite(vc, m, c, right, up, size * (0.55F + 0.35F * s), 0.0F, true, 0.55F * k, 0.48F * k, 0.32F * k);
        }
        // большая искра
        if (s < 6.0F) {
            float k = s < 1.0F ? s : 1.0F - XCoinClient.smooth((s - 1.0F) / 5.0F);
            sprite(vc, m, c, right, up, size * 0.75F * k, Mth.DEG_TO_RAD * (12.0F + s * 9.0F), false, k, 0.86F * k, 0.55F * k);
        }
        // вторая искра наискосок
        float s2 = s - 1.5F;
        if (s2 >= 0.0F && s2 < 5.0F) {
            float k = s2 < 1.0F ? s2 : 1.0F - XCoinClient.smooth((s2 - 1.0F) / 4.0F);
            Vector3f c2 = new Vector3f(c).add(new Vector3f(right).mul(size * 0.3F)).add(new Vector3f(up).mul(size * 0.26F));
            sprite(vc, m, c2, right, up, size * 0.34F * k, Mth.DEG_TO_RAD * (45.0F - s2 * 12.0F), false, k, 0.9F * k, 0.65F * k);
        }
        // лучи-разлёт
        if (s < 4.0F) {
            float k = 1.0F - s / 4.0F;
            java.util.Random r = new java.util.Random(seed * 7L + 3L);
            for (int i = 0; i < 10; i++) {
                float a = Mth.TWO_PI * (i + r.nextFloat() * 0.6F) / 10.0F;
                Vector3f dir = new Vector3f(right).mul(Mth.cos(a)).add(new Vector3f(up).mul(Mth.sin(a)));
                Vector3f side = new Vector3f(up).mul(Mth.cos(a)).sub(new Vector3f(right).mul(Mth.sin(a)));
                float r0 = size * (0.16F + 0.32F * s / 4.0F + 0.06F * r.nextFloat());
                float len = size * (0.22F + 0.18F * r.nextFloat()) * k;
                streak(vc, m, new Vector3f(c).add(new Vector3f(dir).mul(r0 + len * 0.5F)), dir, side, len, size * 0.022F,
                        k, 0.9F * k, 0.62F * k);
            }
        }
        // блёстки
        java.util.Random r = new java.util.Random(seed * 13L + 5L);
        for (int i = 0; i < 16; i++) {
            float a = Mth.TWO_PI * r.nextFloat();
            float speed = size * (0.045F + 0.05F * r.nextFloat());
            float life = 9.0F + 5.0F * r.nextFloat();
            float tw = r.nextFloat() * Mth.TWO_PI;
            if (s > life) continue;
            float vx = Mth.cos(a) * speed, vy = Mth.sin(a) * speed * 0.8F + speed * 0.7F;
            float fall = size * 0.0035F * s * s;
            Vector3f q = new Vector3f(c).add(new Vector3f(right).mul(vx * s)).add(new Vector3f(up).mul(vy * s))
                    .add(new Vector3f(down).mul(fall));
            float k = (1.0F - s / life) * (0.55F + 0.45F * Mth.sin(s * 2.1F + tw));
            sprite(vc, m, q, right, up, size * (0.05F + 0.03F * Mth.sin(tw)), 0.0F, true, k, 0.85F * k, 0.5F * k);
        }
    }

    /** Квадратный спрайт: dot — мягкая точка, иначе искра; поворот rot в плоскости экрана. */
    static void sprite(VertexConsumer vc, Matrix4f m, Vector3f c, Vector3f right, Vector3f up, float half,
                               float rot, boolean dot, float r, float g, float b) {
        if (half <= 0.0005F || r <= 0.002F) return;
        float cs = Mth.cos(rot), sn = Mth.sin(rot);
        Vector3f ax = new Vector3f(right).mul(cs).add(new Vector3f(up).mul(sn)).mul(half);
        Vector3f ay = new Vector3f(up).mul(cs).sub(new Vector3f(right).mul(sn)).mul(half);
        float u0 = dot ? 0.5F : 0.0F, u1 = dot ? 1.0F : 0.5F;
        quad(vc, m, c, ax, ay, u0, u1, r, g, b);
    }

    /** Штрих вдоль dir (side — перпендикуляр в плоскости экрана) длиной len, полутолщиной w (растянутая точка). */
    static void streak(VertexConsumer vc, Matrix4f m, Vector3f c, Vector3f dir, Vector3f side, float len, float w,
                               float r, float g, float b) {
        if (len <= 0.0005F) return;
        Vector3f ax = new Vector3f(dir).mul(len * 0.5F);
        Vector3f ay = new Vector3f(side).mul(w);
        quad(vc, m, c, ax, ay, 0.5F, 1.0F, r, g, b);
    }

    static void quad(VertexConsumer vc, Matrix4f m, Vector3f c, Vector3f ax, Vector3f ay, float u0, float u1,
                             float r, float g, float b) {
        float[][] k = {{-1, -1, u0, 1}, {1, -1, u1, 1}, {1, 1, u1, 0}, {-1, 1, u0, 0}};
        for (float[] v : k) {
            vc.addVertex(m, c.x + ax.x * v[0] + ay.x * v[1], c.y + ax.y * v[0] + ay.y * v[1], c.z + ax.z * v[0] + ay.z * v[1])
                    .setColor(r, g, b, 1.0F).setUv(v[2], v[3]).setOverlay(OverlayTexture.NO_OVERLAY).setLight(FULL_BRIGHT)
                    .setNormal(0.0F, 1.0F, 0.0F);
        }
    }
}
