package com.invfix.xcoin.client;

import com.invfix.xcoin.XCoin;
import com.invfix.xcoin.XCoinPackets;
import com.invfix.xcoin.XCoinTargets;
import com.mojang.blaze3d.platform.Window;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;

/**
 * Подсветка цели Aim flight: пока Kitsune держит монету с выбранной Aim flight (в главной руке, иначе — в
 * левой), цель, в которую монета полетит первой (XCoinTargets#primary: в области прицела, иначе первая по
 * приоритету), слабо светится контуром — ванильное свечение (видно и сквозь блоки), тусклое золото с медленной
 * пульсацией ({@link #color}; XCoinGlowMixin, XCoinTeamColorMixin). Цель шлётся серверу при смене
 * (XCoinPackets.Aim) — бросок полетит именно в подсвеченную.
 *
 * Область прицела — крестик (15×15 пикселей интерфейса) × {@link #AIM_SCALE}, в угол — по высоте окна,
 * масштабу интерфейса и полю зрения из настроек.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class XCoinAimClient {

    private static final double AIM_SCALE = 1.6;

    /** Читается и из потока EntityCulling (Minecraft#shouldEntityAppearGlowing). */
    private static volatile Entity target;
    private static int sentId = -1;

    private XCoinAimClient() {}

    public static boolean highlighted(@Nullable Entity e) {
        Entity t = target;
        return t != null && t == e;
    }

    /** Цвет контура: тусклое золото, яркость 0,4…0,7 с периодом ~2,4 с. */
    public static int color() {
        float k = 0.55F + 0.15F * Mth.sin((float) (Util.getMillis() % 1000000L) / 1000.0F * 2.6F);
        int r = (int) (255.0F * k), g = (int) (196.0F * k), b = (int) (92.0F * k);
        return r << 16 | g << 8 | b;
    }

    private static boolean holdingAim(LocalPlayer p) {
        ItemStack main = p.getMainHandItem();
        if (XCoin.isCoin(main)) return XCoin.mode(main) == XCoin.MODE_AIM_FLIGHT;
        ItemStack off = p.getOffhandItem();
        return XCoin.isCoin(off) && XCoin.mode(off) == XCoin.MODE_AIM_FLIGHT;
    }

    private static double aimAngle(Minecraft mc) {
        Window w = mc.getWindow();
        double half = 7.5 * AIM_SCALE * w.getGuiScale();
        double fov = Math.toRadians(mc.options.fov().get());
        return Math.atan(half / Math.max(1.0, w.getHeight() / 2.0) * Math.tan(fov / 2.0));
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        Entity t = null;
        try {
            if (p != null && mc.level != null && !p.isSpectator() && holdingAim(p) && XCoin.kitsune(p)) {
                t = XCoinTargets.primary(mc.level, p, p.getEyePosition(), p.getLookAngle(), aimAngle(mc));
            }
        } catch (Throwable ignored) {
            t = null;
        }
        target = t;
        int id = t != null ? t.getId() : -1;
        if (id != sentId && mc.getConnection() != null) {
            PacketDistributor.sendToServer(new XCoinPackets.Aim(id));
            sentId = id;
        }
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        target = null;
        sentId = -1;
    }
}
