package com.invfix.xcoin.client;

import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;

/** Монета X рисуется XCoinRenderer (3D-диск). */
@OnlyIn(Dist.CLIENT)
public final class XCoinItemExtensions {

    private XCoinItemExtensions() {}

    public static final IClientItemExtensions INSTANCE = new IClientItemExtensions() {
        @Override
        public BlockEntityWithoutLevelRenderer getCustomRenderer() {
            return XCoinRenderer.instance();
        }
    };
}
