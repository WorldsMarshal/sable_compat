package com.invfix.xcoin.client;

import com.invfix.xcoin.XCoin;
import com.invfix.xcoin.XCoinPackets;
import net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;

/**
 * X Coin на клиенте: фронт нажатия клавиши, в слоте которой способность — серверу Use; фокусы игроков (Trick) —
 * время начала по часам клиента и кривые анимации (рука, рывок кистью, появление и вращение монеты, искра).
 *
 * Кривые (age — тики от начала фокуса):
 *  - {@link #raise}: рука поднимается к XCoin#RAISE (ease-out), держится, опускается за 6 тиков в конце;
 *  - {@link #flick}: рывок кистью 5…7,5 (полусинус);
 *  - {@link #coinScale}: появление — с REVEAL выпрыгивает с перелётом (1,25 → 1); исчезание — сжимается к REVEAL;
 *  - {@link #coinSpin}: монета прокручивается вокруг вертикали (появление — 720° с затуханием).
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class XCoinClient {

    public record Trick(int kind, boolean mainRight, float start) {}

    private static final Map<Integer, Trick> TRICKS = new HashMap<>();
    private static final boolean[] WAS_DOWN = new boolean[5];
    private static long ticks;

    private XCoinClient() {}

    public static void onTrick(XCoinPackets.Trick pkt) {
        TRICKS.put(pkt.entityId(), new Trick(pkt.kind(), pkt.mainRight(), ticks));
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) {
            Entity e = mc.level.getEntity(pkt.entityId());
            if (e != null) XCoinFx.start(e, pkt.kind());
        }
    }

    /** Часы клиента (тики + доля). */
    public static float now(float partial) {
        return ticks + partial;
    }

    @Nullable
    public static Trick trick(int entityId) {
        return TRICKS.get(entityId);
    }

    /** Возраст фокуса сущности в тиках, или -1, если фокуса нет. */
    public static float age(int entityId, float partial) {
        Trick t = TRICKS.get(entityId);
        if (t == null) return -1.0F;
        float a = now(partial) - t.start();
        return a <= XCoin.duration(t.kind()) ? a : -1.0F;
    }

    // ── кривые ───────────────────────────────────────────────────────────────

    static float smooth(float u) {
        u = Mth.clamp(u, 0.0F, 1.0F);
        return u * u * (3.0F - 2.0F * u);
    }

    public static float raise(int kind, float age) {
        if (age < 0.0F) return 0.0F;
        float end = XCoin.duration(kind);
        if (age < XCoin.RAISE) {
            float u = age / XCoin.RAISE;
            return 1.0F - (1.0F - u) * (1.0F - u) * (1.0F - u);
        }
        return 1.0F - smooth((age - (end - 6.0F)) / 6.0F);
    }

    public static float flick(float age) {
        if (age < XCoin.RAISE || age > XCoin.RAISE + 2.5F) return 0.0F;
        return Mth.sin((age - XCoin.RAISE) / 2.5F * Mth.PI);
    }

    public static float coinScale(int kind, float age) {
        if (kind == XCoin.KIND_VANISH) {
            if (age < XCoin.REVEAL - 1.5F) return 1.0F;
            return Mth.clamp((XCoin.REVEAL - age) / 1.5F, 0.0F, 1.0F);
        }
        if (age < XCoin.REVEAL) return 0.0F;
        float u = Mth.clamp((age - XCoin.REVEAL) / 2.5F, 0.0F, 1.0F);
        // ease-out-back: перелёт до ~1,25 и обратно к 1
        float c1 = 2.6F, c3 = c1 + 1.0F;
        return 1.0F + c3 * (float) Math.pow(u - 1.0F, 3) + c1 * (float) Math.pow(u - 1.0F, 2);
    }

    public static float coinSpin(int kind, float age) {
        if (kind == XCoin.KIND_VANISH) {
            float u = Mth.clamp((age - (XCoin.REVEAL - 2.0F)) / 2.0F, 0.0F, 1.0F);
            return 540.0F * u * u;
        }
        float u = Mth.clamp((age - XCoin.REVEAL) / 6.0F, 0.0F, 1.0F);
        return 720.0F * (1.0F - (1.0F - u) * (1.0F - u) * (1.0F - u));
    }

    // ── поза руки от третьего лица (XCoinPoseMixin) и точка кончиков пальцев в мире ──

    /** Целевая поза поднятой руки: xRot, yRot, zRot (для правой; левая — зеркально). */
    public static float[] armPose(float flick) {
        return new float[]{-1.95F, -0.45F, 0.15F - 0.5F * flick};
    }

    /**
     * Кончики пальцев главной руки игрока в мире при позе {@link #armPose} (модель игрока: тело повёрнуто на
     * yBodyRot, масштаб 0,9375, плечо в точке (∓5, 2, 0) px, рука вниз на 10,5 px).
     */
    public static Vec3 fingertips(Player p, float partial, boolean right, float flick) {
        float[] a = armPose(flick);
        float s = right ? 1.0F : -1.0F;
        float xr = a[0], yr = a[1] * s, zr = a[2] * s;
        // кончик в системе руки, повёрнут ZYX (ModelPart#translateAndRotate)
        double tx = -1.0 * s, ty = 10.5, tz = -0.5;
        double cx = Math.cos(xr), sx = Math.sin(xr), cy = Math.cos(yr), sy = Math.sin(yr), cz = Math.cos(zr), sz = Math.sin(zr);
        double y1 = ty * cx - tz * sx, z1 = ty * sx + tz * cx, x1 = tx;              // Rx
        double x2 = x1 * cy + z1 * sy, z2 = -x1 * sy + z1 * cy, y2 = y1;             // Ry
        double x3 = x2 * cz - y2 * sz, y3 = x2 * sz + y2 * cz, z3 = z2;              // Rz
        double mx = -5.0 * s + x3, my = 2.0 + y3, mz = z3;
        double sc = 0.9375;
        double qx = -(mx / 16.0) * sc, qy = -(my / 16.0 - 1.501) * sc, qz = (mz / 16.0) * sc;
        float body = Mth.rotLerp(partial, p.yBodyRotO, p.yBodyRot);
        double th = Math.toRadians(180.0F - body), c = Math.cos(th), sn = Math.sin(th);
        double wx = qx * c + qz * sn, wz = -qx * sn + qz * c;
        Vec3 pos = p.getPosition(partial);
        return new Vec3(pos.x + wx, pos.y + qy, pos.z + wz);
    }

    // ── клавиша ──────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        ticks++;
        TRICKS.values().removeIf(t -> ticks - t.start() > XCoin.duration(t.kind()) + 2);
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        KeyMapping[] keys = {
                InvincibleIncModKeyMappings.ABILITY_1, InvincibleIncModKeyMappings.ABILITY_2,
                InvincibleIncModKeyMappings.ABILITY_3, InvincibleIncModKeyMappings.ABILITY_4,
                InvincibleIncModKeyMappings.ABILITY_5};
        boolean[] down = new boolean[5];
        for (int i = 0; i < 5; i++) down[i] = keys[i] != null && keys[i].isDown();
        try {
            if (player == null || mc.screen != null || !XCoin.eligible(player)) return;
            InvincibleIncModVariables.PlayerVariables v = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            boolean row1 = v.AbilityRow == 1.0;
            String[] slots = row1
                    ? new String[]{v.AbilitySlot1, v.AbilitySlot2, v.AbilitySlot3, v.AbilitySlot4, v.AbilitySlot5}
                    : new String[]{v.AbilitySlot1_row2, v.AbilitySlot2_row2, v.AbilitySlot3_row2,
                                   v.AbilitySlot4_row2, v.AbilitySlot5_row2};
            for (int i = 0; i < 5; i++) {
                if (!down[i] || WAS_DOWN[i] || !XCoin.ABILITY.equals(slots[i])) continue;
                PacketDistributor.sendToServer(new XCoinPackets.Use());
                break;
            }
        } catch (Throwable ignored) {
        } finally {
            System.arraycopy(down, 0, WAS_DOWN, 0, 5);
        }
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        TRICKS.clear();
    }
}
