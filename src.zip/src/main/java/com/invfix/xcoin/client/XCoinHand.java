package com.invfix.xcoin.client;

import com.invfix.xcoin.XCoin;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Монета X от первого лица: главная рука рисуется сама (как пустая рука ванили, ItemInHandRenderer#renderPlayerArm),
 * монета — между пальцами, торчит из кулака и смотрит в камеру (поворот подобран по ванильной позе руки:
 * направление на камеру в системе руки — Y −136,2°, X 38,4°).
 *
 * Фокус (XCoinClient): рука поворачивается вокруг точки ниже экрана ({@link #PIVOT}) — к центру и вверх, к
 * XCoin#RAISE; рывок кистью; на REVEAL монета выпрыгивает с перелётом и прокручивается (исчезание — сжимается),
 * искра, лучи и блёстки (XCoinFx) — у монеты, в плоскости экрана. Во время фокуса прочий предмет в главной
 * руке не рисуется: его «прячут» вместе с началом фокуса.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class XCoinHand {

    /** Точка поворота руки при фокусе — ниже и правее экрана (для правой руки). */
    private static final float[] PIVOT = {0.55F, -1.25F, -0.85F};
    /**
     * Радиус монеты в руке, блоков — с ванильный золотой самородок от первого лица (6 px спрайта × 0,68
     * firstperson_righthand item/generated: ширина 0,255 блока).
     */
    private static final float COIN_RADIUS = 2.0F / 16.0F;
    /** Размер вспышки фокуса у монеты (XCoinFx#draw). */
    private static final float FX_SIZE = 0.37F;

    /** Идёт отрисовка руки от первого лица — поза фокуса от третьего лица (XCoinPoseMixin) не нужна. */
    public static boolean firstPersonArm;

    private XCoinHand() {}

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onRenderHand(RenderHandEvent event) {
        if (event.getHand() != InteractionHand.MAIN_HAND) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || player.isScoping()) return;
        float partial = event.getPartialTick();
        XCoinClient.Trick trick = XCoinClient.trick(player.getId());
        float age = XCoinClient.age(player.getId(), partial);
        boolean tricking = trick != null && age >= 0.0F;
        boolean holding = XCoin.isCoin(event.getItemStack());
        if (!tricking && !holding) return;
        event.setCanceled(true);

        boolean right = player.getMainArm() == HumanoidArm.RIGHT;
        float f = right ? 1.0F : -1.0F;
        int kind = tricking ? trick.kind() : XCoin.KIND_CONJURE;
        float w = tricking ? XCoinClient.raise(kind, age) : 0.0F;
        float flick = tricking ? XCoinClient.flick(age) : 0.0F;
        float equip = tricking ? 0.0F : event.getEquipProgress();
        float swing = event.getSwingProgress();
        boolean coinVisible = tricking ? (kind == XCoin.KIND_CONJURE ? age >= XCoin.REVEAL : age < XCoin.REVEAL) : true;

        PoseStack ps = event.getPoseStack();
        MultiBufferSource buffers = event.getMultiBufferSource();
        int light = event.getPackedLight();
        ps.pushPose();
        // фокус: поворот вокруг точки ниже экрана, подъём
        if (w > 0.0F || flick > 0.0F) {
            ps.translate(f * PIVOT[0], PIVOT[1], PIVOT[2]);
            ps.mulPose(Axis.ZP.rotationDegrees(f * (24.0F * w - 9.0F * flick)));
            ps.mulPose(Axis.XP.rotationDegrees(-8.0F * w));
            ps.translate(-f * PIVOT[0], -PIVOT[1] + 0.3F * w, -PIVOT[2]);
        }
        armTransform(ps, equip, swing, f);
        PlayerRenderer renderer = (PlayerRenderer) mc.getEntityRenderDispatcher().<AbstractClientPlayer>getRenderer(player);
        if (!player.isInvisible() && !com.invfix.shapeshift.client.ShapeshiftClient.hideOwnArms()) {
            firstPersonArm = true;
            try {
                if (right) renderer.renderRightHand(ps, buffers, light, player);
                else renderer.renderLeftHand(ps, buffers, light, player);
            } finally {
                firstPersonArm = false;
            }
        }
        // монета у кончиков пальцев (в системе руки модели, как её рисует renderHand)
        PlayerModel<AbstractClientPlayer> model = renderer.getModel();
        ModelPart arm = right ? model.rightArm : model.leftArm;
        ps.pushPose();
        arm.translateAndRotate(ps);
        ps.translate(-f / 16.0F, 10.3F / 16.0F, -0.3F / 16.0F);
        ps.mulPose(Axis.YP.rotationDegrees(f * -136.2F));
        ps.mulPose(Axis.XP.rotationDegrees(38.4F));
        ps.translate(0.0F, COIN_RADIUS * 1.15F, 0.6F / 16.0F);
        Vector3f center = ps.last().pose().transformPosition(new Vector3f());
        if (coinVisible) {
            float scale = tricking ? XCoinClient.coinScale(kind, age) : 1.0F;
            float spin = tricking ? XCoinClient.coinSpin(kind, age) : 0.0F;
            if (scale > 0.001F) {
                ps.pushPose();
                ps.mulPose(Axis.YP.rotationDegrees(spin));
                float sc = COIN_RADIUS / XCoinRenderer.R * scale;
                ps.scale(sc, sc, sc);
                XCoinRenderer.render(ps, buffers, light, OverlayTexture.NO_OVERLAY, XCoinRenderer.glintPhase(17.0F));
                ps.popPose();
            }
        }
        ps.popPose();
        ps.popPose();
        // искра, лучи, блёстки — в пространстве камеры у монеты
        if (tricking) {
            float s = age - XCoin.REVEAL;
            if (s >= 0.0F && s <= 14.0F) {
                XCoinFx.draw(buffers.getBuffer(RenderType.eyes(XCoinFx.TEXTURE)), new Matrix4f(), center,
                        new Vector3f(1.0F, 0.0F, 0.0F), new Vector3f(0.0F, 1.0F, 0.0F), new Vector3f(0.0F, -1.0F, 0.0F),
                        FX_SIZE, s, XCoinFx.seed(player.getId()));
            }
        }
    }

    /** ItemInHandRenderer#renderPlayerArm без отрисовки (те же числа). */
    private static void armTransform(PoseStack ps, float equip, float swing, float f) {
        float f1 = Mth.sqrt(swing);
        float f2 = -0.3F * Mth.sin(f1 * Mth.PI);
        float f3 = 0.4F * Mth.sin(f1 * Mth.TWO_PI);
        float f4 = -0.4F * Mth.sin(swing * Mth.PI);
        ps.translate(f * (f2 + 0.64000005F), f3 + -0.6F + equip * -0.6F, f4 + -0.71999997F);
        ps.mulPose(Axis.YP.rotationDegrees(f * 45.0F));
        float f5 = Mth.sin(swing * swing * Mth.PI);
        float f6 = Mth.sin(f1 * Mth.PI);
        ps.mulPose(Axis.YP.rotationDegrees(f * f6 * 70.0F));
        ps.mulPose(Axis.ZP.rotationDegrees(f * f5 * -20.0F));
        ps.translate(f * -1.0F, 3.6F, 3.5F);
        ps.mulPose(Axis.ZP.rotationDegrees(f * 120.0F));
        ps.mulPose(Axis.XP.rotationDegrees(200.0F));
        ps.mulPose(Axis.YP.rotationDegrees(f * -135.0F));
        ps.translate(f * 5.6F, 0.0F, 0.0F);
    }
}
