package com.invfix.xcoin;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Aim flight — первая способность монеты X (ПКМ монетой, Kitsune). Монета уходит из руки и летит со скоростью
 * {@link #SPEED} блоков за тик; в воздухе не поворачивает — только отскакивает от поверхностей блоков под
 * допустимым углом (XCoinPlanner: не очень острым и не очень тупым).
 *
 * Бросок — всегда по взгляду: в точку, куда смотрит прицел (луч из глаз до блока, не дальше
 * XCoinTargets#RANGE). Наведение — только с отскока: в каждой точке отскока ищется путь к цели (с упреждением
 * по её движению) — и монета уходит по нему; пути нет — отскок без цели (зеркальный, угол подправлен в
 * допустимый), а на следующей стене — снова поиск. Промах — дальше по прямой до стены.
 *
 * Цели — из поля зрения в момент броска (XCoinTargets): сначала сущность в области прицела (её сообщает
 * клиент — та же, что подсвечена, XCoinPackets.Aim; клиент не сообщил — своя проверка с
 * XCoinTargets#AIM_FALLBACK), затем по приоритету: снаряды, враждебные, игроки, нейтральные, мирные. На отскоке
 * цель — первая из очереди, до которой есть путь (не больше {@link #PLANS_BOUNCE} поисков). Цель на прямой —
 * монета попадает и без отскока. Снаряд монета разбивает и летит дальше по прямой — до стены, от неё — к
 * следующей цели очереди. Живую цель бьёт на {@link #DAMAGE} единиц ровно (sable_compat:x_coin: мимо брони,
 * эффектов и щита), и полёт кончается.
 *
 * Полёт кончается и на {@link #MAX_WALLS}+1-й стене (отскоков — {@link #MAX_WALLS}), и на выходе из шара
 * XCoinTargets#RANGE блоков вокруг точки выпуска (весь путь строится внутри него).
 *
 * Конец полёта — монета исчезает и возвращается к хозяину (XCoinHandler#returnCoin); хозяина нет в игре или
 * он мёртв — монета падает предметом в точке конца. В творческом монета не тратится и не возвращается.
 *
 * Клиентам рядом: путь (XCoinPackets.FlightPath) при броске и при каждом изменении, события (FlightEvent) —
 * отскок, попадание, сбитый снаряд, конец — по отметке пути: вспышки, звуки и частицы событий — на клиенте,
 * когда до отметки доходит его монета (XCoinFlightClient).
 */
@EventBusSubscriber(modid = "sable_compat")
public final class XCoinFlight {

    public static final double SPEED = 2.5;
    public static final float DAMAGE = 100.0F;
    public static final ResourceKey<DamageType> DAMAGE_TYPE = ResourceKey.create(Registries.DAMAGE_TYPE,
            ResourceLocation.fromNamespaceAndPath("sable_compat", "x_coin"));

    public static final int EV_BOUNCE = 0;
    public static final int EV_HIT = 1;
    public static final int EV_SHATTER = 2;
    public static final int EV_END = 3;

    public static final int MAX_WALLS = 8;
    private static final int MAX_TICKS = 400;
    private static final int PLANS_BOUNCE = 4;
    private static final double SEND_RANGE = 160.0;
    private static final int COOLDOWN = 10;

    /** Вершины пути: старт, отскок от стены, точка в воздухе (сбитый снаряд), точка цели, конец. */
    private static final int V_START = 0, V_WALL = 1, V_AIR = 2, V_AIM = 3, V_END = 4;

    private static final class Flight {
        final int id;
        final ServerLevel level;
        final UUID owner;
        final ServerPlayer ownerRef;
        @Nullable final ItemStack coin;
        final List<Entity> queue;
        final Vec3 origin;
        final List<Vec3> pts = new ArrayList<>();
        final List<Vec3> normals = new ArrayList<>();
        final List<Integer> kinds = new ArrayList<>();
        final List<Double> cum = new ArrayList<>();
        @Nullable Entity target;
        Vec3 dir;
        int next = 1;
        double dist;
        int ticks, walls;
        boolean done;

        Flight(int id, ServerPlayer owner, @Nullable ItemStack coin, List<Entity> queue, Vec3 origin, Vec3 dir) {
            this.id = id;
            this.level = owner.serverLevel();
            this.owner = owner.getUUID();
            this.ownerRef = owner;
            this.coin = coin;
            this.queue = queue;
            this.origin = origin;
            this.dir = dir;
        }
    }

    private record Plan(Entity target, XCoinPlanner.Path path) {}

    private static final List<Flight> FLIGHTS = new ArrayList<>();
    /** Цель в области прицела, которую видит (и подсвечивает) клиент: id сущности. */
    private static final Map<UUID, Integer> AIM = new HashMap<>();
    private static int nextId = 1;

    private XCoinFlight() {}

    /** Клиент сообщил цель в области прицела (-1 — нет). */
    static void setAim(ServerPlayer player, int entityId) {
        if (entityId < 0) AIM.remove(player.getUUID());
        else AIM.put(player.getUUID(), entityId);
    }

    // ── бросок ───────────────────────────────────────────────────────────────

    /** ПКМ монетой (сервер). false — бросить нельзя. */
    static boolean launch(ServerPlayer player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!XCoin.isCoin(stack) || !XCoin.kitsune(player) || player.isSpectator() || player.isSleeping()) return false;
        if (XCoinHandler.busy(player) || com.invfix.flat.Flat.flat(player) || com.invfix.compat.LovsDowned.downed(player)) {
            return false;
        }
        ServerLevel level = player.serverLevel();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 right = new Vec3(-look.z, 0.0, look.x);
        if (right.lengthSqr() < 1.0E-4) {
            double yaw = Math.toRadians(player.getYRot());
            right = new Vec3(-Math.cos(yaw), 0.0, -Math.sin(yaw));
        }
        right = right.normalize();
        boolean rightHand = (hand == InteractionHand.MAIN_HAND) == (player.getMainArm() == HumanoidArm.RIGHT);
        Vec3 start = eye.add(look.scale(0.45)).add(right.scale(rightHand ? 0.28 : -0.28)).add(0.0, -0.25, 0.0);
        if (!XCoinPlanner.clear(level, eye, start)) start = eye;
        // по взгляду: в точку прицела (блок под прицелом или конец дальности)
        BlockHitResult sight = XCoinPlanner.cast(level, eye, look, XCoinTargets.RANGE);
        Vec3 point = sight != null ? sight.getLocation() : eye.add(look.scale(XCoinTargets.RANGE));
        Vec3 dir = point.subtract(start);
        dir = dir.lengthSqr() > 1.0E-4 ? dir.normalize() : look;

        ItemStack coin = player.hasInfiniteMaterials() ? null : stack.copyWithCount(1);
        stack.consume(1, player);
        player.getCooldowns().addCooldown(XCoinRegistry.COIN.get(), COOLDOWN);

        Flight f = new Flight(nextId++, player, coin, queue(player, eye, look), start, dir);
        f.target = f.queue.isEmpty() ? null : f.queue.get(0);
        append(f, start, null, V_START);
        level.playSound(null, start.x, start.y, start.z, XCoinRegistry.CONJURE.get(), SoundSource.PLAYERS, 0.9F, 1.35F);
        straight(f, 0, dir);
        FLIGHTS.add(f);
        return true;
    }

    /** Очередь целей: в области прицела — первой, дальше по приоритету. */
    private static List<Entity> queue(ServerPlayer player, Vec3 eye, Vec3 look) {
        List<Entity> q = XCoinTargets.candidates(player.serverLevel(), player, eye, look);
        Entity aimed = null;
        Integer id = AIM.get(player.getUUID());
        if (id != null) {
            Entity e = player.serverLevel().getEntity(id);
            if (e != null && q.contains(e)) aimed = e;
        }
        if (aimed == null) aimed = XCoinTargets.crosshair(q, eye, look, XCoinTargets.AIM_FALLBACK);
        if (aimed != null) {
            q.remove(aimed);
            q.add(0, aimed);
        }
        return q;
    }

    private static boolean valid(Flight f, Entity e) {
        if (e.isRemoved() || !e.isAlive() || e.level() != f.level) return false;
        if (e instanceof Projectile) return e.getDeltaMovement().lengthSqr() > 0.01;
        return e instanceof LivingEntity le && !le.isDeadOrDying()
                && !(e instanceof Player p && (p.isCreative() || p.isSpectator()));
    }

    // ── выбор цели и пути ────────────────────────────────────────────────────

    @Nullable
    private static Plan choose(Flight f, Vec3 from, Vec3 in, Vec3 normal) {
        f.queue.removeIf(e -> !valid(f, e));
        int plans = 0;
        for (Entity e : f.queue) {
            if (plans++ >= PLANS_BOUNCE) break;
            XCoinPlanner.Path p = planTo(f, from, in, normal, e);
            if (p != null) return new Plan(e, p);
        }
        return null;
    }

    /** Путь к цели с упреждением: время — по длине пути без упреждения. */
    @Nullable
    private static XCoinPlanner.Path planTo(Flight f, Vec3 from, Vec3 in, Vec3 normal, Entity e) {
        XCoinPlanner.Path p = XCoinPlanner.plan(f.level, from, in, normal, null, aimPoint(e, 0.0),
                XCoinPlanner.MAX_BOUNCES, f.origin, XCoinTargets.RANGE);
        if (p == null || velocity(e).lengthSqr() < 1.0E-4) return p;
        double t = Math.min(p.length() / SPEED, 20.0);
        XCoinPlanner.Path q = XCoinPlanner.plan(f.level, from, in, normal, null, aimPoint(e, t),
                XCoinPlanner.MAX_BOUNCES, f.origin, XCoinTargets.RANGE);
        return q != null ? q : p;
    }

    private static Vec3 velocity(Entity e) {
        if (e instanceof Projectile) return e.getDeltaMovement();
        Vec3 v = new Vec3(e.getX() - e.xo, e.getY() - e.yo, e.getZ() - e.zo);
        return e.onGround() ? new Vec3(v.x, 0.0, v.z) : v;
    }

    private static Vec3 aimPoint(Entity e, double t) {
        Vec3 c = e.getBoundingBox().getCenter().add(velocity(e).scale(t));
        return e instanceof Projectile ? c.add(0.0, -0.5 * e.getGravity() * t * t, 0.0) : c;
    }

    // ── путь ─────────────────────────────────────────────────────────────────

    private static void append(Flight f, Vec3 p, @Nullable Vec3 normal, int kind) {
        double d = f.pts.isEmpty() ? 0.0 : f.cum.get(f.cum.size() - 1) + p.distanceTo(f.pts.get(f.pts.size() - 1));
        f.pts.add(p);
        f.normals.add(normal);
        f.kinds.add(kind);
        f.cum.add(d);
    }

    private static void truncate(Flight f, int keep) {
        while (f.pts.size() > keep + 1) {
            int last = f.pts.size() - 1;
            f.pts.remove(last);
            f.normals.remove(last);
            f.kinds.remove(last);
            f.cum.remove(last);
        }
    }

    /** Путь плана — после вершины i (она и есть начало плана). */
    private static void splice(Flight f, int i, Plan plan) {
        truncate(f, i);
        List<Vec3> pts = plan.path().points(), ns = plan.path().normals();
        for (int k = 1; k < pts.size(); k++) append(f, pts.get(k), ns.get(k), k == pts.size() - 1 ? V_AIM : V_WALL);
        f.target = plan.target();
        f.next = i + 1;
        sendPath(f, i);
    }

    /** Сколько можно пролететь из p по dir, не выходя из шара полёта (0 — уже на границе или снаружи). */
    private static double inside(Flight f, Vec3 p, Vec3 dir) {
        Vec3 rel = p.subtract(f.origin);
        double b = dir.dot(rel), c = rel.lengthSqr() - XCoinTargets.RANGE * XCoinTargets.RANGE;
        double disc = b * b - c;
        if (c >= 0.0 || disc <= 0.0) return 0.0;
        return -b + Math.sqrt(disc);
    }

    /** Прямо из вершины i по dir: до стены (отскок) или до границы шара полёта (конец). */
    private static void straight(Flight f, int i, Vec3 dir) {
        truncate(f, i);
        Vec3 from = f.pts.get(i);
        double len = inside(f, from, dir);
        if (len < 1.0E-3) {
            end(f, from);
            return;
        }
        BlockHitResult hit = XCoinPlanner.cast(f.level, XCoinPlanner.lift(from, f.normals.get(i)), dir, len);
        if (hit != null && hit.getLocation().distanceToSqr(from) > 1.0E-4) {
            append(f, hit.getLocation(), XCoinPlanner.normal(hit.getDirection()), V_WALL);
        } else if (hit != null) {
            end(f, from);
            return;
        } else {
            append(f, from.add(dir.scale(len)), null, V_END);
        }
        f.next = i + 1;
        sendPath(f, i);
    }

    private static Vec3 position(Flight f) {
        int i = Math.min(f.next, f.pts.size() - 1);
        Vec3 a = f.pts.get(Math.max(i - 1, 0));
        return a.add(f.dir.scale(f.dist - f.cum.get(Math.max(i - 1, 0))));
    }

    // ── тик ──────────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        if (FLIGHTS.isEmpty()) return;
        for (Flight f : new ArrayList<>(FLIGHTS)) {
            try {
                tick(f);
            } catch (Exception e) {
                Vec3 at;
                try {
                    at = position(f);
                } catch (Exception ex) {
                    at = f.origin;
                }
                try {
                    end(f, at);
                } catch (Exception ex) {
                    f.done = true;
                }
            }
        }
        FLIGHTS.removeIf(f -> f.done);
    }

    private static void tick(Flight f) {
        f.ticks++;
        double left = SPEED;
        for (int guard = 0; left > 1.0E-6 && !f.done && guard < 24; guard++) {
            if (f.next >= f.pts.size()) {
                end(f, f.pts.get(f.pts.size() - 1));
                break;
            }
            Vec3 a = f.pts.get(f.next - 1), b = f.pts.get(f.next);
            double segStart = f.cum.get(f.next - 1), segEnd = f.cum.get(f.next);
            if (segEnd - segStart > 1.0E-6) f.dir = b.subtract(a).scale(1.0 / (segEnd - segStart));
            double step = Math.max(0.0, Math.min(left, segEnd - f.dist));
            Vec3 p0 = a.add(f.dir.scale(f.dist - segStart)), p1 = p0.add(f.dir.scale(step));
            if (f.target != null && valid(f, f.target)) {
                double t = sweep(f.target, p0, p1);
                if (t >= 0.0) {
                    f.dist += step * t;
                    left -= step * t;
                    hit(f, p0.add(f.dir.scale(step * t)));
                    continue;
                }
            }
            f.dist += step;
            left -= step;
            if (f.dist >= segEnd - 1.0E-6) {
                f.dist = segEnd;
                int i = f.next++;
                arrive(f, i);
            }
        }
        if (!f.done && (f.ticks >= MAX_TICKS
                || position(f).distanceToSqr(f.origin) > (XCoinTargets.RANGE + 0.5) * (XCoinTargets.RANGE + 0.5))) {
            end(f, position(f));
        }
    }

    /** Доля отрезка p0→p1, на которой монета задевает цель, или -1. Снаряд — с учётом его движения за тик. */
    private static double sweep(Entity e, Vec3 p0, Vec3 p1) {
        AABB box;
        Vec3 r0, r1;
        if (e instanceof Projectile) {
            Vec3 pos = e.position(), v = e.getDeltaMovement();
            box = e.getBoundingBox().inflate(0.6).move(pos.scale(-1.0));
            r0 = p0.subtract(pos.subtract(v));
            r1 = p1.subtract(pos);
        } else {
            box = e.getBoundingBox().inflate(0.3);
            r0 = p0;
            r1 = p1;
        }
        if (box.contains(r0)) return 0.0;
        double len = r0.distanceTo(r1);
        if (len < 1.0E-6) return -1.0;
        Optional<Vec3> h = box.clip(r0, r1);
        return h.map(v -> r0.distanceTo(v) / len).orElse(-1.0);
    }

    private static void arrive(Flight f, int i) {
        switch (f.kinds.get(i)) {
            case V_END -> end(f, f.pts.get(i));
            case V_AIM -> straight(f, i, f.dir);
            case V_WALL -> bounce(f, i);
            default -> {
                if (f.next >= f.pts.size()) end(f, f.pts.get(i));
            }
        }
    }

    private static void bounce(Flight f, int i) {
        Vec3 p = f.pts.get(i), n = f.normals.get(i), in = f.dir;
        if (++f.walls > MAX_WALLS) {
            end(f, p);
            return;
        }
        event(f, EV_BOUNCE, p);
        Plan plan = choose(f, p, in, n);
        if (plan != null) {
            splice(f, i, plan);
            return;
        }
        // пути к цели нет — отскок без цели, на следующей стене снова поиск
        Vec3 out = XCoinPlanner.freeBounce(in, n);
        if (out != null) straight(f, i, out);
        else end(f, p);
    }

    private static void hit(Flight f, Vec3 p) {
        Entity e = f.target;
        if (e == null) return;
        if (e instanceof Projectile) {
            event(f, EV_SHATTER, p);
            e.discard();
            f.queue.remove(e);
            // в воздухе не поворачивает: дальше по прямой до стены, следующая цель — первая в очереди (если она
            // на этой прямой — попадёт, иначе путь к ней ищется от стены)
            truncate(f, f.next - 1);
            append(f, p, null, V_AIR);
            int j = f.pts.size() - 1;
            f.dist = f.cum.get(j);
            f.queue.removeIf(q -> !valid(f, q));
            f.target = f.queue.isEmpty() ? null : f.queue.get(0);
            straight(f, j, f.dir);
            return;
        }
        if (e instanceof LivingEntity le) {
            DamageSource src = new DamageSource(f.level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                    .getHolderOrThrow(DAMAGE_TYPE), null, f.ownerRef, p.subtract(f.dir));
            le.invulnerableTime = 0;
            le.hurt(src, DAMAGE);
        }
        event(f, EV_HIT, p);
        end(f, p);
    }

    private static void end(Flight f, Vec3 p) {
        if (f.done) return;
        f.done = true;
        event(f, EV_END, p);
        if (f.coin == null) return;
        ServerPlayer owner = f.level.getServer().getPlayerList().getPlayer(f.owner);
        if (owner != null && owner.isAlive()) {
            XCoinHandler.returnCoin(owner, f.coin);
        } else {
            ItemEntity item = new ItemEntity(f.level, p.x, p.y, p.z, f.coin.copy());
            item.setDefaultPickUpDelay();
            f.level.addFreshEntity(item);
        }
    }

    // ── клиентам ─────────────────────────────────────────────────────────────

    private static void sendPath(Flight f, int from) {
        List<Vec3> pts = new ArrayList<>(f.pts.subList(from, f.pts.size()));
        PacketDistributor.sendToPlayersNear(f.level, null, f.origin.x, f.origin.y, f.origin.z, SEND_RANGE,
                new XCoinPackets.FlightPath(f.id, f.cum.get(from), pts));
    }

    private static void event(Flight f, int kind, Vec3 p) {
        PacketDistributor.sendToPlayersNear(f.level, null, f.origin.x, f.origin.y, f.origin.z, SEND_RANGE,
                new XCoinPackets.FlightEvent(f.id, kind, f.dist, p));
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        AIM.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        FLIGHTS.clear();
        AIM.clear();
    }
}
