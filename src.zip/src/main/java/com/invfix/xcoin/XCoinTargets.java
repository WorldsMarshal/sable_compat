package com.invfix.xcoin;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Цели Aim flight — общее для сервера (XCoinFlight) и подсветки на клиенте (client.XCoinAimClient).
 *
 * Кандидаты — в поле зрения бросающего: центр сущности не дальше {@link #RANGE} блоков от глаз и не дальше 90°
 * от взгляда (180° обзора), сквозь блоки. Приоритет (меньше — раньше), внутри — ближние раньше:
 *  0 — снаряды (чужие, в полёте); 1 — враждебные мобы (Enemy); 2 — игроки (не в творческом и не наблюдатели);
 *  3 — нейтральные мобы (NeutralMob); 4 — мирные мобы (прочие Mob). Свои прирученные и свой транспорт — не цели.
 *
 * Область прицела: сущность, которую луч взгляда задевает с запасом угла aim (рамка сущности раздута на
 * расстояние × tg aim), — ближняя из таких — цель вне очереди приоритетов.
 */
public final class XCoinTargets {

    public static final double RANGE = 60.0;
    /** Область прицела на сервере, если клиент не сообщил свою цель. */
    public static final double AIM_FALLBACK = Math.toRadians(2.5);

    private XCoinTargets() {}

    /** Приоритет цели, -1 — не цель. */
    public static int category(Player owner, Entity e) {
        if (!e.isAlive() || e == owner || e.isSpectator()) return -1;
        if (e instanceof Projectile pr) {
            return pr.getOwner() != owner && pr.getDeltaMovement().lengthSqr() > 0.01 ? 0 : -1;
        }
        if (!(e instanceof LivingEntity le) || le.isDeadOrDying()) return -1;
        if (e == owner.getVehicle() || e.getVehicle() == owner) return -1;
        if (e instanceof OwnableEntity own && owner.getUUID().equals(own.getOwnerUUID())) return -1;
        if (e instanceof Enemy) return 1;
        if (e instanceof Player p) return p.isCreative() || p.isSpectator() ? -1 : 2;
        if (e instanceof NeutralMob) return 3;
        if (e instanceof Mob) return 4;
        return -1;
    }

    public static boolean inView(Vec3 eye, Vec3 look, Entity e) {
        Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
        return to.lengthSqr() <= RANGE * RANGE && to.dot(look) >= 0.0;
    }

    /** Кандидаты по приоритету и расстоянию. */
    public static List<Entity> candidates(Level level, Player owner, Vec3 eye, Vec3 look) {
        List<Entity> out = level.getEntities(owner, owner.getBoundingBox().inflate(RANGE),
                e -> category(owner, e) >= 0 && inView(eye, look, e));
        out.sort(Comparator.<Entity>comparingInt(e -> category(owner, e))
                .thenComparingDouble(e -> e.getBoundingBox().getCenter().distanceToSqr(eye)));
        return out;
    }

    /** Сущность в области прицела (ближняя по лучу), или null. */
    @Nullable
    public static Entity crosshair(List<Entity> candidates, Vec3 eye, Vec3 look, double aim) {
        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        double tan = Math.tan(aim);
        Vec3 end = eye.add(look.scale(RANGE + 8.0));
        for (Entity e : candidates) {
            double along = e.getBoundingBox().getCenter().subtract(eye).dot(look);
            if (along <= 0.0) continue;
            AABB box = e.getBoundingBox().inflate(along * tan);
            double d;
            if (box.contains(eye)) {
                d = 0.0;
            } else {
                Optional<Vec3> hit = box.clip(eye, end);
                if (hit.isEmpty()) continue;
                d = hit.get().distanceToSqr(eye);
            }
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    /** Цель, в которую монета полетит первой: в области прицела, иначе первая по приоритету. */
    @Nullable
    public static Entity primary(Level level, Player owner, Vec3 eye, Vec3 look, double aim) {
        List<Entity> cands = candidates(level, owner, eye, look);
        if (cands.isEmpty()) return null;
        Entity e = crosshair(cands, eye, look, aim);
        return e != null ? e : cands.get(0);
    }
}
