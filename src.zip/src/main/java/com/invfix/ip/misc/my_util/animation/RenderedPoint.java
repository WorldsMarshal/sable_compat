package com.invfix.ip.misc.my_util.animation;

import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import com.invfix.ip.misc.my_util.WithDim;

public record RenderedPoint(@Nullable WithDim<Vec3> pos, double scale) {
    public static final RenderedPoint EMPTY = new RenderedPoint(null, 0);
}
