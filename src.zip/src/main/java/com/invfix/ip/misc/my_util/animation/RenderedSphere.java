package com.invfix.ip.misc.my_util.animation;

import org.jetbrains.annotations.Nullable;
import com.invfix.ip.misc.my_util.DQuaternion;
import com.invfix.ip.misc.my_util.Sphere;
import com.invfix.ip.misc.my_util.WithDim;

public record RenderedSphere(
    @Nullable WithDim<Sphere> sphere,
    DQuaternion orientation,
    double scale
) {
    public static final RenderedSphere NONE = new RenderedSphere(
        null, DQuaternion.identity, 0
    );
}
