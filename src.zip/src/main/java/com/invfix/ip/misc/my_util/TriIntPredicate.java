package com.invfix.ip.misc.my_util;

public interface TriIntPredicate {
    boolean test(int x, int y, int z);
}
