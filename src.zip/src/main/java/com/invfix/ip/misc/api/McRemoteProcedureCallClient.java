package com.invfix.ip.misc.api;

import net.minecraft.client.Minecraft;

import static com.invfix.ip.misc.api.McRemoteProcedureCall.createPacketToSendToServer;

public class McRemoteProcedureCallClient {
    public static void tellServerToInvoke(
            String methodPath, Object... arguments
    ) {
        var packet = createPacketToSendToServer(methodPath, arguments);
        Minecraft.getInstance().getConnection().send(packet);
    }
}
