package com.invfix.ip.misc.my_util;

public record Vec2d(double x, double y) {
}
