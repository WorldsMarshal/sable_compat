package com.invfix.ip.misc;

import net.minecraft.server.MinecraftServer;
import com.invfix.ip.misc.my_util.MyTaskList;

import java.lang.ref.WeakReference;

public class MiscGlobals {
    public static WeakReference<MinecraftServer> refMinecraftServer =
        new WeakReference<>(null);
    
    public static final MyTaskList serverTaskList = new MyTaskList();
    
}
