package com.invfix.ip.misc.my_util.animation;

import org.jetbrains.annotations.Nullable;
import com.invfix.ip.misc.my_util.Plane;
import com.invfix.ip.misc.my_util.WithDim;

public record RenderedPlane(
    @Nullable WithDim<Plane> plane,
    double scale
) {
    public static final RenderedPlane NONE = new RenderedPlane(null, 0);
}
