package com.invfix.ip.misc.ducks;

import net.minecraft.world.level.storage.LevelStorageSource;

public interface IEMinecraftServer_Misc {
    
    LevelStorageSource.LevelStorageAccess ip_getStorageSource();
}
