package com.invfix.ip.misc;

import com.invfix.ip.neomisc.networking.Payloads;
import net.neoforged.bus.api.IEventBus;
import com.invfix.ip.misc.dimension.DimensionIntId;

import static com.invfix.ip.misc.MiscUtilModEntry.MOD_ID;

// sable_compat: запускается из com.invfix.InvincibleFix, без @Mod.
public class MiscUtilModEntry {
    public static final String MOD_ID = "q_misc_util";

    public MiscUtilModEntry(IEventBus eventBus) {
        onInitialize();
        eventBus.addListener(Payloads::register);
    }

    public void onInitialize() {
        DimensionIntId.init();
    }
}
