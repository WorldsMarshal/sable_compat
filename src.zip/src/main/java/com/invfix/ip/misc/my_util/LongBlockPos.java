package com.invfix.ip.misc.my_util;

public record LongBlockPos(long x, long y, long z) {
}
