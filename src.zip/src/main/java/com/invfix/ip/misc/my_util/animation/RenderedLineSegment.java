package com.invfix.ip.misc.my_util.animation;

import org.jetbrains.annotations.Nullable;
import com.invfix.ip.misc.my_util.LineSegment;
import com.invfix.ip.misc.my_util.WithDim;

public record RenderedLineSegment(@Nullable WithDim<LineSegment> lineSegment, double scale) {
    public static final RenderedLineSegment EMPTY = new RenderedLineSegment(null, 0);
}
