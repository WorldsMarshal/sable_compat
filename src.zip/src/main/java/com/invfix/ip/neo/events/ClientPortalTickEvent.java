package com.invfix.ip.neo.events;

import com.invfix.ip.core.portal.Portal;

public class ClientPortalTickEvent extends PortalEvent {

    public ClientPortalTickEvent(Portal portal) {
        super(portal);
    }
}
