package com.invfix.ip.neo.events;

import com.invfix.ip.core.portal.Portal;

public class ServerPortalTickEvent extends PortalEvent {
    public ServerPortalTickEvent(Portal portal) {
        super(portal);
    }
}
