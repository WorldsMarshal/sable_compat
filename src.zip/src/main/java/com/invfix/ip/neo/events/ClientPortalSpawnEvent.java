package com.invfix.ip.neo.events;

import com.invfix.ip.core.portal.Portal;

public class ClientPortalSpawnEvent extends PortalEvent {

    public ClientPortalSpawnEvent(Portal portal) {
        super(portal);
    }
}
