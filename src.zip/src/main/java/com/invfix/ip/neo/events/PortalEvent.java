package com.invfix.ip.neo.events;

import net.neoforged.bus.api.Event;
import com.invfix.ip.core.portal.Portal;

public abstract class PortalEvent extends Event {
    public final Portal portal;

    protected PortalEvent(Portal portal) {
        this.portal = portal;
    }
}
