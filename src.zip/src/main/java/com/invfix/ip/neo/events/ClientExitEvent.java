package com.invfix.ip.neo.events;

import net.neoforged.bus.api.Event;

/**
 * Fired when client exits world. Does not fire when doing conventional dimension travel.
 */
public class ClientExitEvent extends Event {
}
