package com.invfix.ip.neo.events;

import net.minecraft.nbt.CompoundTag;
import com.invfix.ip.core.portal.Portal;

public class ReadPortalDataEvent extends PortalEvent{
    public final CompoundTag tag;

    public ReadPortalDataEvent(Portal portal, CompoundTag tag) {
        super(portal);
        this.tag = tag;
    }
}
