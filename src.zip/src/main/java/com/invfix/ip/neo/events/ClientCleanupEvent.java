package com.invfix.ip.neo.events;

import net.neoforged.bus.api.Event;

/**
 * Fired when client exits world or doing conventional dimension travel (with loading screen).
 */
public class ClientCleanupEvent extends Event {
}
