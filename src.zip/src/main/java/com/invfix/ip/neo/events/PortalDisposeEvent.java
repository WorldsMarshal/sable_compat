package com.invfix.ip.neo.events;

import com.invfix.ip.core.portal.Portal;

public class PortalDisposeEvent extends PortalEvent {

    public PortalDisposeEvent(Portal portal) {
        super(portal);
    }
}
