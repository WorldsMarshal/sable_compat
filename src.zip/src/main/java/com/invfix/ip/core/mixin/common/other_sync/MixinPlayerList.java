package com.invfix.ip.core.mixin.common.other_sync;

import com.invfix.ip.core.IPGlobal;
import net.minecraft.core.BlockPos;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.players.PlayerList;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.invfix.ip.core.chunk_loading.ImmPtlChunkTracking;
import com.invfix.ip.core.network.PacketRedirection;
import com.invfix.ip.core.portal.global_portals.GlobalPortalStorage;
import com.invfix.ip.core.teleportation.ServerTeleportationManager;
import com.invfix.ip.misc.Helper;

import java.util.List;
import java.util.Set;

@Mixin(value = PlayerList.class, priority = 800)
public class MixinPlayerList {
    @Shadow
    @Final
    private List<ServerPlayer> players;
    
    @Shadow
    @Final
    private MinecraftServer server;
    
    @Inject(method = "Lnet/minecraft/server/players/PlayerList;sendLevelInfo(Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/server/level/ServerLevel;)V", at = @At("RETURN"))
    private void onSendWorldInfo(ServerPlayer player, ServerLevel world, CallbackInfo ci) {
        if (!ServerTeleportationManager.of(player.server).isFiringMyChangeDimensionEvent) {
            GlobalPortalStorage.onPlayerLoggedIn(player);
        }
    }
    
    @Inject(method = "placeNewPlayer", at = @At("TAIL"))
    private void onOnPlayerConnect(
        Connection connection, ServerPlayer player,
        CommonListenerCookie commonListenerCookie, CallbackInfo ci
    ) {
        if (IPGlobal.multiWorld) ImmPtlChunkTracking.immediatelyUpdateForPlayer(player);
        
        // debug
        Helper.LOGGER.info("Player login {} {}", player.level().getGameTime(), player);
    }
    
    //with redirection
    @SuppressWarnings({"unchecked", "rawtypes"})
    @Inject(
        method = "Lnet/minecraft/server/players/PlayerList;broadcastAll(Lnet/minecraft/network/protocol/Packet;Lnet/minecraft/resources/ResourceKey;)V",
        at = @At("HEAD"),
        cancellable = true
    )
    public void sendToDimension(Packet<?> packet, ResourceKey<Level> dimension, CallbackInfo ci) {
        if (!IPGlobal.multiWorld) return;
        for (ServerPlayer player : players) {
            if (player.level().dimension() == dimension) {
                PacketRedirection.sendRedirectedMessage(
                    player,
                    dimension,
                    (Packet<ClientGamePacketListener>) packet
                );
            }
        }
        
        ci.cancel();
    }
    
    /**
     * correct the player reference, so that in
     * {@link com.invfix.ip.core.mixin.common.position_sync.MixinServerGamePacketListenerImpl#teleport(double, double, double, float, float, Set)}
     * the player's dimension will be correct
     */
    @Redirect(
        method = "respawn",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;restoreFrom(Lnet/minecraft/server/level/ServerPlayer;Z)V"
        )
    )
    private void onRestoreFrom(ServerPlayer newPlayer, ServerPlayer that, boolean keepEverything) {
        newPlayer.restoreFrom(that, keepEverything);
        
        newPlayer.connection.player = newPlayer;
    }
    
    /**
     * sable_compat: у IP здесь был @Overwrite (звуки сквозь порталы), но Sable тоже
     * перезаписывает broadcast (расстояние с учётом кораблей) — сработала бы только
     * одна перезапись. Теперь тело остаётся за Sable/ванилью, а в конце пакет
     * досылается тем, кто слышит точку только через портал: игрокам из записей
     * наблюдения IP, которых обычная рассылка не покрыла (другое измерение или дальше
     * distance напрямую).
     */
    @Inject(method = "broadcast", at = @At("TAIL"))
    private void ip_onBroadcast(
        @Nullable Player excludingPlayer,
        double x, double y, double z, double distance,
        ResourceKey<Level> dimension, Packet<?> packet, CallbackInfo ci
    ) {
        if (!IPGlobal.multiWorld) return; // записи наблюдения IP не ведутся — звуки сквозь портал позже, через com.invfix.portal.far
        ChunkPos chunkPos = new ChunkPos(BlockPos.containing(new Vec3(x, y, z)));
        
        var recs =
            ImmPtlChunkTracking.getWatchRecordForChunk(dimension, chunkPos.x, chunkPos.z);
        
        if (recs == null) {
            return;
        }
        
        for (ImmPtlChunkTracking.PlayerWatchRecord rec : recs.values()) {
            if (rec.isLoadedToPlayer && rec.player != excludingPlayer) {
                boolean reachedDirectly = rec.player.level().dimension() == dimension
                    && rec.player.distanceToSqr(x, y, z) < distance * distance;
                if (reachedDirectly) {
                    continue;
                }
                if (ImmPtlChunkTracking.isPlayerWatchingChunkWithinRadius(
                    rec.player, dimension, chunkPos.x, chunkPos.z, (int) distance + 16
                )) {
                    rec.player.connection.send(
                        PacketRedirection.createRedirectedMessage(
                            rec.player.getServer(),
                            dimension, (Packet<ClientGamePacketListener>) packet
                        )
                    );
                }
            }
        }
    }
}
