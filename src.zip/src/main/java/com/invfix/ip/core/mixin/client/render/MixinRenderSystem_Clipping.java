package com.invfix.ip.core.mixin.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.renderer.ShaderInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.invfix.ip.core.IPGlobal;
import com.invfix.ip.core.compat.iris_compatibility.IrisInterface;
import com.invfix.ip.core.render.CrossPortalEntityRenderer;
import com.invfix.ip.core.render.FrontClipping;
import com.invfix.ip.core.render.context_management.RenderStates;

import java.util.function.Supplier;

@Mixin(value = RenderSystem.class, remap = false)
public class MixinRenderSystem_Clipping {
    @Inject(
        method = "Lcom/mojang/blaze3d/systems/RenderSystem;setShader(Ljava/util/function/Supplier;)V",
        at = @At("RETURN")
    )
    private static void onSetShader(Supplier<ShaderInstance> supplier, CallbackInfo ci) {
        if (IPGlobal.enableClippingMechanism) {
            if (!IrisInterface.invoker.isIrisPresent()) {
                if (CrossPortalEntityRenderer.isRenderingEntityNormally ||
                    CrossPortalEntityRenderer.isRenderingEntityProjection
                ) {
                    FrontClipping.updateClippingEquationUniformForCurrentShader(true);
                }
                else if (RenderStates.isRenderingPortalWeather) {
                    FrontClipping.updateClippingEquationUniformForCurrentShader(false);
                }
                else {
                    FrontClipping.unsetClippingUniform();
                }
            }
            else {
                FrontClipping.unsetClippingUniform();
            }
        }
        
    }
}
