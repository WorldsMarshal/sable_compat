package com.invfix.ip.core.mixin.common;

import net.minecraft.server.level.DistanceManager;
import net.minecraft.server.level.ServerChunkCache;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import com.invfix.ip.core.ducks.IEServerChunkCache;

@Mixin(ServerChunkCache.class)
public abstract class MixinServerChunkCache implements IEServerChunkCache {
    @Shadow
    @Final
    private DistanceManager distanceManager;
    
    @Override
    public DistanceManager ip_getDistanceManager() {
        return distanceManager;
    }
}
