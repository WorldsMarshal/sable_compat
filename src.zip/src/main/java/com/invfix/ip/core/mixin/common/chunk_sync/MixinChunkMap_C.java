package com.invfix.ip.core.mixin.common.chunk_sync;

import net.minecraft.server.level.*;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.invfix.ip.core.chunk_loading.ImmPtlChunkTracking;
import com.invfix.ip.core.chunk_loading.PlayerChunkLoading;
import com.invfix.ip.core.ducks.IEChunkMap;

import java.util.List;

@Mixin(value = ChunkMap.class, priority = 1100)
public abstract class MixinChunkMap_C implements IEChunkMap {
    
    @Shadow
    @Final
    private ServerLevel level;
    
    @Shadow
    protected abstract ChunkHolder getVisibleChunkIfPresent(long long_1);
    
    @Shadow
    @Final
    private ThreadedLevelLightEngine lightEngine;
    
    @Shadow
    abstract int getPlayerViewDistance(ServerPlayer serverPlayer);
    
    @Override
    public int ip_getPlayerViewDistance(ServerPlayer player) {
        return getPlayerViewDistance(player);
    }
    
    @Override
    public ServerLevel ip_getWorld() {
        return level;
    }
    
    @Override
    public ThreadedLevelLightEngine ip_getLightingProvider() {
        return lightEngine;
    }
    
    @Override
    public ChunkHolder ip_getChunkHolder(long chunkPosLong) {
        return getVisibleChunkIfPresent(chunkPosLong);
    }
    
    /**
     * packets will be sent on {@link PlayerChunkLoading}
     */
    @Inject(
        method = "applyChunkTrackingView",
        at = @At("HEAD"),
        cancellable = true
    )
    private void onUpdateChunkTracking(
        ServerPlayer serverPlayer, ChunkTrackingView chunkTrackingView, CallbackInfo ci
    ) {
        ci.cancel();
    }
    
    // sable_compat: у IP оба метода ниже были @Overwrite. Другие моды ставят в них
    // INVOKE-инжекторы (CBC Modern Warfare — getPlayers), а Mixin запрещает их в метод,
    // перезаписанный другим миксином — мир не загружался. Теперь отмена в HEAD: тело
    // остаётся, чужие инжекторы применяются, результат прежний.
    
    @Inject(method = "onChunkReadyToSend", at = @At("HEAD"), cancellable = true)
    private void ip_onChunkReadyToSend(LevelChunk chunk, CallbackInfo ci) {
        ImmPtlChunkTracking.onChunkProvidedDeferred(chunk);
        ci.cancel();
    }

    /**
     * otherwise, an empty list will always be returned here (Nick1st).
     * Чанки участков кораблей Sable не трогаются — их игроков отдаёт Sable
     * (его HEAD-инжектор), независимо от порядка инжекторов.
     */
    @Inject(method = "getPlayers", at = @At("HEAD"), cancellable = true)
    private void ip_onGetPlayers(ChunkPos pos, boolean boundaryOnly, CallbackInfoReturnable<List<ServerPlayer>> cir) {
        if (com.invfix.portal.compat.PortalSableCompat.isPlotChunk(level, pos)) {
            return;
        }
        cir.setReturnValue(ImmPtlChunkTracking.getPlayersViewingChunk(level.dimension(), pos.x, pos.z, boundaryOnly));
    }
}
