package com.invfix.ip.core.mixin.common.chunk_sync;

import com.invfix.ip.core.IPGlobal;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.PlayerChunkSender;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.invfix.ip.core.chunk_loading.ImmPtlChunkTracking;

/**
 * Disable the functionality of this class.
 * Because its implementation is based on single-dimension loaded and near-loading-only assumption.
 */
@SuppressWarnings({"JavadocReference", "UnstableApiUsage"})
@Mixin(value = PlayerChunkSender.class)
public class MixinPlayerChunkSender {
    @Shadow @Final private static Logger LOGGER;
    
    // sable_compat: @Overwrite у IP заменены на отмену в HEAD — чтобы чужие INVOKE-инжекторы
    // в этих методах применялись (Mixin запрещает их в перезаписанный метод). Поведение то же.
    @Inject(method = "markChunkPendingToSend", at = @At("HEAD"), cancellable = true)
    private void ip_onMarkChunkPendingToSend(LevelChunk levelChunk, CallbackInfo ci) {
        if (!IPGlobal.multiWorld) return;
        ci.cancel();
    }
    
    @Inject(method = "dropChunk", at = @At("HEAD"), cancellable = true)
    private void ip_onDropChunk(ServerPlayer serverPlayer, ChunkPos chunkPos, CallbackInfo ci) {
        if (!IPGlobal.multiWorld) return;
        ci.cancel();
    }
    
    /**
     * Fabric API mixins this method
     * {@link net.fabricmc.fabric.mixin.attachment.ChunkDataSenderMixin}
     */
    @Inject(
        method = "sendNextChunks",
        at = @At("HEAD"),
        cancellable = true
    )
    public void sendNextChunks(ServerPlayer serverPlayer, CallbackInfo ci) {
        if (!IPGlobal.multiWorld) return;
        ImmPtlChunkTracking.getPlayerInfo(serverPlayer).doChunkSending(serverPlayer);
        ci.cancel();
    }
    
    @Inject(method = "onChunkBatchReceivedByClient", at = @At("HEAD"), cancellable = true)
    private void ip_onChunkBatchReceivedByClient(float f, CallbackInfo ci) {
        if (!IPGlobal.multiWorld) return;
        ci.cancel();
    }
    
    // У IP здесь писалась ошибка со стеком: метод не должен вызываться (отправкой чанков
    // управляет IP). Ответ прежний — false.
    @Inject(method = "isPending", at = @At("HEAD"), cancellable = true)
    private void ip_onIsPending(long l, CallbackInfoReturnable<Boolean> cir) {
        if (!IPGlobal.multiWorld) return;
        cir.setReturnValue(false);
    }
}
