package com.invfix.ip.core.mixin.common.entity_sync;

import net.minecraft.world.level.entity.PersistentEntitySectionManager;
import org.spongepowered.asm.mixin.Mixin;
import com.invfix.ip.core.ducks.IEServerEntityManager;

@Mixin(PersistentEntitySectionManager.class)
public class MixinPersistentEntitySectionManager implements IEServerEntityManager {
}
