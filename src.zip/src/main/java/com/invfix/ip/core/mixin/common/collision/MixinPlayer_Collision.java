package com.invfix.ip.core.mixin.common.collision;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import com.invfix.ip.core.ducks.IEEntity;

/**
 * sable_compat: у IP был @Overwrite canPlayerFitWithinBlocksAndEntitiesWhen, но Sable
 * оборачивает вызов Level#noCollision внутри него (@WrapOperation, @At INVOKE), а Mixin
 * не даёт ставить INVOKE-инжекторы в метод, перезаписанный другим миксином того же
 * приоритета — игра не запускалась. Теперь тот же расчёт IP — обёрткой этого вызова:
 * коробка ужимается до активной части по эту сторону портала (null — места хватает).
 * Обёртки MixinExtras складываются, обёртка Sable остаётся.
 */
@Mixin(Player.class)
public abstract class MixinPlayer_Collision {
    @WrapOperation(
        method = "canPlayerFitWithinBlocksAndEntitiesWhen",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/Level;noCollision(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;)Z"
        )
    )
    private boolean ip_wrapNoCollision(Level level, Entity entity, AABB box, Operation<Boolean> original) {
        // ванильная коробка уже ужата на 1.0E-7 — как у IP: активная часть считается
        // от полной коробки и ужимается после
        AABB activeCollisionBox = ((IEEntity) this).ip_getActiveCollisionBox(box.inflate(1.0E-7));
        if (activeCollisionBox == null) {
            return true;
        }
        return original.call(level, entity, activeCollisionBox.deflate(1.0E-7));
    }
}
