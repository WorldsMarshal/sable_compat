package com.invfix.sizediff;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Пакеты Size Difference. */
public final class SizePackets {

    private SizePackets() {}

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath("sable_compat", path);
    }

    /** Сервер → клиенты: размер игрока (entityId). */
    public record State(int entityId, CompoundTag state) implements CustomPacketPayload {
        public static final Type<State> TYPE = new Type<>(id("size_state"));
        public static final StreamCodec<FriendlyByteBuf, State> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> { buf.writeVarInt(m.entityId()); buf.writeNbt(m.state()); },
                buf -> {
                    int idv = buf.readVarInt();
                    CompoundTag tag = buf.readNbt();
                    return new State(idv, tag != null ? tag : new CompoundTag());
                });

        @Override public Type<State> type() { return TYPE; }
    }

    /** Клиент → сервер: размер из меню. */
    public record SetTarget(float size) implements CustomPacketPayload {
        public static final Type<SetTarget> TYPE = new Type<>(id("size_set"));
        public static final StreamCodec<FriendlyByteBuf, SetTarget> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> buf.writeFloat(m.size()),
                buf -> new SetTarget(buf.readFloat()));

        @Override public Type<SetTarget> type() { return TYPE; }

        public static void handleServer(SetTarget pkt, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (ctx.player() instanceof ServerPlayer player) SizeHandler.setTarget(player, pkt.size());
            });
        }
    }

    /** Клиент → сервер: назначить способность в слот. */
    public record Assign() implements CustomPacketPayload {
        public static final Type<Assign> TYPE = new Type<>(id("size_assign"));
        public static final StreamCodec<FriendlyByteBuf, Assign> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> {}, buf -> new Assign());

        @Override public Type<Assign> type() { return TYPE; }

        public static void handleServer(Assign pkt, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (!(ctx.player() instanceof ServerPlayer player) || !SizeHandler.eligible(player)) return;
                try {
                    InvincibleIncModVariables.PlayerVariables vars =
                            player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                    vars.AbilitySet = SizeHandler.ABILITY;
                    vars.abilityDescription = SizeHandler.ABILITY + " | LVL:" + SizeHandler.LVL_REQUIRED
                            + " | Размер (Shift — точная настройка)";
                    vars.markSyncDirty();
                } catch (Exception ignored) {}
            });
        }
    }
}
