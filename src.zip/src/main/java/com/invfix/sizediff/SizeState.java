package com.invfix.sizediff;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

import javax.annotation.Nullable;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

/**
 * Размер игрока (Size Difference) — одно число, общее для сервера и всех клиентов, что его
 * видят (сервер шлёт {@link SizePackets.State}). Меняется плавно: за {@link #DURATION}
 * тиков от {@link #from} к {@link #to}, как в Pehkui (там тоже 20 тиков).
 *
 * Работает через LivingEntity#getScale (ScaleLivingEntityMixin): на него уже опираются
 * хитбокс и высота глаз, модель, тень, камера от третьего лица и посадка пассажиров —
 * поэтому размер может выходить за ванильные 1/16…16: {@link #MIN}…{@link #MAX}.
 *
 * {@link #target} и {@link #active} — выбор игрока (меню и клавиша); их знает и его клиент.
 */
public final class SizeState {

    public static final float MIN = 0.02F;
    public static final float MAX = 25.0F;
    public static final int DURATION = 20;

    private static final Map<UUID, SizeState> SERVER = new ConcurrentHashMap<>();
    private static final Map<UUID, SizeState> CLIENT = new ConcurrentHashMap<>();

    /** Доля кадра на клиенте (для плавной отрисовки между тиками) — ставит клиент. */
    @Nullable
    public static volatile Supplier<Float> partial;

    public float from = 1.0F;
    public float to = 1.0F;
    public int ticks = DURATION;
    public float target = 1.0F;
    public boolean active;

    public static Map<UUID, SizeState> map(boolean client) {
        return client ? CLIENT : SERVER;
    }

    @Nullable
    public static SizeState get(Player player) {
        return map(player.level().isClientSide()).get(player.getUUID());
    }

    public static SizeState getOrCreate(Player player) {
        return map(player.level().isClientSide()).computeIfAbsent(player.getUUID(), k -> new SizeState());
    }

    public static float clamp(float v) {
        if (Float.isNaN(v)) return 1.0F;
        return Mth.clamp(v, MIN, MAX);
    }

    public boolean transitioning() {
        return ticks < DURATION;
    }

    /** Размер на тике (хитбокс, атрибуты). */
    public float scale() {
        return at(ticks);
    }

    /** Размер на кадре (отрисовка). */
    public float renderScale(float pt) {
        if (!transitioning()) return to;
        return at(ticks + pt);
    }

    private float at(float t) {
        if (t >= DURATION) return to;
        float p = Mth.clamp(t / DURATION, 0.0F, 1.0F);
        float k = (float) (Math.sin(Math.toRadians(-90.0 + 180.0 * p)) / 2.0 + 0.5);
        // в логарифме: рост ×25 и сжатие ÷25 идут одинаково плавно
        double lf = Math.log(from), lt = Math.log(to);
        return (float) Math.exp(lf + (lt - lf) * k);
    }

    /** Начать переход к новому размеру с текущего. */
    public void goTo(float size) {
        size = clamp(size);
        if (Math.abs(size - to) < 1.0E-4F) return;
        from = scale();
        to = size;
        ticks = 0;
    }

    /** true — размер ещё меняется (хитбокс пересчитать). */
    public boolean tick() {
        if (!transitioning()) return false;
        ticks++;
        return true;
    }

    public CompoundTag write() {
        CompoundTag tag = new CompoundTag();
        tag.putFloat("from", from);
        tag.putFloat("to", to);
        tag.putInt("ticks", ticks);
        tag.putFloat("target", target);
        tag.putBoolean("active", active);
        return tag;
    }

    public void read(CompoundTag tag) {
        from = clamp(tag.getFloat("from"));
        to = clamp(tag.getFloat("to"));
        ticks = Mth.clamp(tag.getInt("ticks"), 0, DURATION);
        target = clamp(tag.getFloat("target"));
        active = tag.getBoolean("active");
    }
}
