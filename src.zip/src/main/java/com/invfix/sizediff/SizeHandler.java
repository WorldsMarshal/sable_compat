package com.invfix.sizediff;

import com.invfix.kitsune.KitsuneRace;
import com.invfix.shapeshift.MorphState;
import com.invfix.threatmode.ThreatModeState;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.core.Holder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingKnockBackEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Size Difference — способность Kitsune, LVL {@link #LVL_REQUIRED}. Механика размеров —
 * по мотивам Pehkui, по-своему и только для игрока:
 *
 *  - клавиша способности — стать выбранного размера или вернуться к обычному;
 *    Shift + клавиша — меню точной настройки (на клиенте);
 *  - размер {@link SizeState#MIN}…{@link SizeState#MAX}, меняется плавно за 1 секунду;
 *  - вместе с размером (как BASE в Pehkui) меняются хитбокс, глаза, модель, камера,
 *    скорость ходьбы, шаг, прыжок (высота ∝ размеру), падение (безопасная высота ∝ размеру,
 *    урон от падения ∝ 1/размер), дальность по сущностям и по блокам ∝ размеру;
 *  - сила и отдача — только в Alt-режиме и только больше обычного размера: урон рукой
 *    обычного игрока × размер, отдача от твоих ударов × размер, твоя отдача ÷ размер.
 *    Меньше обычного — сила как у обычного игрока;
 *  - в морфе Size не действует: морф — обычного размера своего моба; после демофра
 *    размер возвращается;
 *  - смерть возвращает к обычному размеру (выбранный размер в меню сохраняется).
 */
@EventBusSubscriber(modid = "sable_compat")
public final class SizeHandler {

    public static final String ABILITY = "§a§lSize Difference";
    public static final int LVL_REQUIRED = 30;

    private static final String DATA = "invfix_size";

    private static final ResourceLocation ENTITY_REACH = id("size_entity_reach");
    private static final ResourceLocation BLOCK_REACH = id("size_block_reach");
    private static final ResourceLocation SPEED = id("size_speed");
    private static final ResourceLocation STEP = id("size_step");
    private static final ResourceLocation JUMP = id("size_jump");
    private static final ResourceLocation SAFE_FALL = id("size_safe_fall");
    private static final ResourceLocation FALL_DAMAGE = id("size_fall_damage");

    private static final Map<UUID, Boolean> KEY_DOWN = new ConcurrentHashMap<>();
    private static final Map<UUID, Float> APPLIED = new ConcurrentHashMap<>();

    private SizeHandler() {}

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath("sable_compat", path);
    }

    public static boolean eligible(Player player) {
        try {
            InvincibleIncModVariables.PlayerVariables v = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            return KitsuneRace.isKitsune(v.Race) && v.Lvl >= LVL_REQUIRED;
        } catch (Exception e) {
            return false;
        }
    }

    /** Текущий размер игрока (1 — обычный). */
    public static float scaleOf(LivingEntity entity) {
        if (!(entity instanceof Player player)) return 1.0F;
        SizeState st = SizeState.get(player);
        return st == null ? 1.0F : st.scale();
    }

    // ── сохранение ───────────────────────────────────────────────────────────

    private static CompoundTag data(Player player) {
        CompoundTag root = player.getPersistentData();
        if (!root.contains(DATA, Tag.TAG_COMPOUND)) root.put(DATA, new CompoundTag());
        return root.getCompound(DATA);
    }

    private static void save(Player player, SizeState st) {
        CompoundTag d = data(player);
        d.putFloat("target", st.target);
        d.putBoolean("active", st.active);
    }

    // ── клавиша и меню ───────────────────────────────────────────────────────

    /** Клавиша (AbilityCallProcedureMixin, каждый тик): по фронту нажатия. Shift — меню на клиенте. */
    public static void handleKeyState(ServerPlayer player, boolean pressed) {
        boolean was = Boolean.TRUE.equals(KEY_DOWN.put(player.getUUID(), pressed));
        if (!pressed || was || player.isShiftKeyDown() || !eligible(player)) return;
        SizeState st = SizeState.getOrCreate(player);
        st.active = !st.active;
        save(player, st);
        update(player, st, true);
    }

    /** Меню: выбрать размер. Если размер включён — сразу плавно к нему. */
    public static void setTarget(ServerPlayer player, float size) {
        if (!eligible(player)) return;
        SizeState st = SizeState.getOrCreate(player);
        st.target = SizeState.clamp(size);
        save(player, st);
        update(player, st, true);
    }

    /** Нужный сейчас размер: включён и не в морфе — выбранный, иначе обычный. */
    private static float desired(Player player, SizeState st) {
        if (!st.active || !eligible(player)) return 1.0F;
        MorphState ms = MorphState.get(player);
        if (ms != null && ms.active()) return 1.0F;
        return st.target;
    }

    /** Довести состояние до нужного размера; force — разослать даже без перехода. */
    private static void update(ServerPlayer player, SizeState st, boolean force) {
        float want = desired(player, st);
        boolean started = Math.abs(want - st.to) > 1.0E-4F;
        if (started) st.goTo(want);
        if (started || force) {
            broadcast(player, st);
            player.refreshDimensions();
        }
    }

    private static void broadcast(ServerPlayer player, SizeState st) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new SizePackets.State(player.getId(), st.write()));
    }

    // ── атрибуты ─────────────────────────────────────────────────────────────

    private static void applyAttributes(ServerPlayer player, float s) {
        Float last = APPLIED.get(player.getUUID());
        if (last != null && Math.abs(last - s) < 1.0E-5F) return;
        APPLIED.put(player.getUUID(), s);
        double k = s - 1.0;
        modifier(player, Attributes.ENTITY_INTERACTION_RANGE, ENTITY_REACH, k);
        modifier(player, Attributes.BLOCK_INTERACTION_RANGE, BLOCK_REACH, k);
        modifier(player, Attributes.MOVEMENT_SPEED, SPEED, k);
        modifier(player, Attributes.STEP_HEIGHT, STEP, k);
        modifier(player, Attributes.JUMP_STRENGTH, JUMP, Math.sqrt(s) - 1.0);   // высота прыжка ∝ размеру
        modifier(player, Attributes.SAFE_FALL_DISTANCE, SAFE_FALL, k);
        modifier(player, Attributes.FALL_DAMAGE_MULTIPLIER, FALL_DAMAGE, 1.0 / s - 1.0);
    }

    private static void modifier(Player player, Holder<Attribute> attr, ResourceLocation id, double value) {
        AttributeInstance inst = player.getAttribute(attr);
        if (inst == null) return;
        inst.removeModifier(id);
        if (Math.abs(value) > 1.0E-6) {
            inst.addTransientModifier(new AttributeModifier(id, value, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
    }

    // ── сила и отдача (Alt) ──────────────────────────────────────────────────

    /** Множитель силы удара рукой: только в Alt-режиме и только больше обычного размера. */
    public static float altStrengthFactor(net.minecraft.world.entity.Entity attacker) {
        if (!(attacker instanceof ServerPlayer player) || !ThreatModeState.isHeld(player)) return 1.0F;
        return Math.max(1.0F, scaleOf(player));
    }

    @SubscribeEvent
    public static void onKnockBack(LivingKnockBackEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide()) return;
        float strength = event.getStrength();
        // большой (Alt) отбрасывает сильнее
        if (victim.getLastHurtByMob() instanceof ServerPlayer attacker && attacker != victim
                && attacker.getLastHurtMob() == victim) {
            strength *= altStrengthFactor(attacker);
        }
        // большого (Alt) отбрасывает слабее
        if (victim instanceof ServerPlayer self) {
            float f = altStrengthFactor(self);
            if (f > 1.0F) strength /= f;
        }
        event.setStrength(strength);
    }

    // ── события ──────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        SizeState st = SizeState.get(player);
        if (st == null) return;
        if (st.active && !eligible(player)) {
            st.active = false;
            save(player, st);
        }
        update(player, st, false);
        if (st.tick()) player.refreshDimensions();
        applyAttributes(player, st.scale());
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        SizeState.map(false).remove(player.getUUID());
        APPLIED.remove(player.getUUID());
        CompoundTag d = data(player);
        SizeState st = SizeState.getOrCreate(player);
        st.target = d.contains("target") ? SizeState.clamp(d.getFloat("target")) : 1.0F;
        st.active = d.getBoolean("active") && eligible(player);
        float want = desired(player, st);
        st.from = st.to = want;
        st.ticks = SizeState.DURATION;
        player.refreshDimensions();
        broadcast(player, st);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        SizeState st = SizeState.get(player);
        if (st == null) return;
        st.active = false;
        st.from = st.to = 1.0F;
        st.ticks = SizeState.DURATION;
        save(player, st);
        broadcast(player, st);
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        CompoundTag old = event.getOriginal().getPersistentData();
        if (!old.contains(DATA, Tag.TAG_COMPOUND)) return;
        CompoundTag copy = old.getCompound(DATA).copy();
        if (event.isWasDeath()) copy.putBoolean("active", false);
        event.getEntity().getPersistentData().put(DATA, copy);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        APPLIED.remove(player.getUUID());
        SizeState st = SizeState.get(player);
        if (st != null) {
            player.refreshDimensions();
            broadcast(player, st);
        }
    }

    @SubscribeEvent
    public static void onChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        APPLIED.remove(player.getUUID());
        SizeState st = SizeState.get(player);
        if (st != null) broadcast(player, st);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID();
        SizeState.map(false).remove(id);
        KEY_DOWN.remove(id);
        APPLIED.remove(id);
    }

    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (!(event.getTarget() instanceof ServerPlayer target) || !(event.getEntity() instanceof ServerPlayer watcher)) return;
        SizeState st = SizeState.get(target);
        if (st == null) return;
        PacketDistributor.sendToPlayer(watcher, new SizePackets.State(target.getId(), st.write()));
    }
}
