package com.invfix.sizediff.client;

import com.invfix.sizediff.SizePackets;
import com.invfix.sizediff.SizeState;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Locale;

/**
 * Меню Size Difference (Shift + клавиша): точная настройка размера. Ползунок —
 * в логарифме (1 посередине, слева до 0.02, справа до 25), поле для точного числа,
 * быстрые кнопки. «Применить» запоминает размер; если размер включён — переход к нему
 * сразу. Включается и выключается сам размер клавишей способности.
 */
@OnlyIn(Dist.CLIENT)
public final class SizeScreen extends Screen {

    private static final float[] PRESETS = {0.02F, 0.1F, 0.25F, 0.5F, 1.0F, 2.0F, 4.0F, 10.0F, 25.0F};
    private static final double LOG_MIN = Math.log(SizeState.MIN);
    private static final double LOG_MAX = Math.log(SizeState.MAX);

    private float value;
    private Slider slider;
    private EditBox field;
    private boolean syncing;
    private int left, top, panelW = 260, panelH = 150;

    public SizeScreen() {
        super(Component.literal("Size Difference"));
        value = SizeClient.myTarget();
    }

    private static double toSlider(float v) {
        return (Math.log(SizeState.clamp(v)) - LOG_MIN) / (LOG_MAX - LOG_MIN);
    }

    private static float fromSlider(double t) {
        return SizeState.clamp((float) Math.exp(LOG_MIN + (LOG_MAX - LOG_MIN) * Mth.clamp(t, 0.0, 1.0)));
    }

    static String fmt(float v) {
        if (v < 0.1F) return String.format(Locale.ROOT, "%.3f", v);
        if (v < 10.0F) return String.format(Locale.ROOT, "%.2f", v);
        return String.format(Locale.ROOT, "%.1f", v);
    }

    @Override
    protected void init() {
        left = (width - panelW) / 2;
        top = (height - panelH) / 2;
        slider = new Slider(left + 10, top + 28, panelW - 20, 20);
        addRenderableWidget(slider);
        field = new EditBox(font, left + 10, top + 56, 80, 18, Component.literal("Размер"));
        field.setValue(fmt(value));
        field.setResponder(s -> {
            if (syncing) return;
            try {
                float v = Float.parseFloat(s.trim().replace(',', '.'));
                if (v > 0) {
                    value = SizeState.clamp(v);
                    syncing = true;
                    slider.setFromValue(value);
                    syncing = false;
                }
            } catch (NumberFormatException ignored) {}
        });
        addRenderableWidget(field);
        int bw = (panelW - 20 - 4 * (PRESETS.length - 1)) / PRESETS.length;
        for (int i = 0; i < PRESETS.length; i++) {
            float p = PRESETS[i];
            String label = p < 1.0F ? (p == 0.5F ? "½" : fmt(p).replaceAll("0+$", "")) : "×" + (int) p;
            addRenderableWidget(Button.builder(Component.literal(label), b -> setValue(p))
                    .bounds(left + 10 + i * (bw + 4), top + 82, bw, 18).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Применить"), b -> {
            PacketDistributor.sendToServer(new SizePackets.SetTarget(value), new CustomPacketPayload[0]);
            onClose();
        }).bounds(left + 10, top + panelH - 28, (panelW - 30) / 2, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Отмена"), b -> onClose())
                .bounds(left + 20 + (panelW - 30) / 2, top + panelH - 28, (panelW - 30) / 2, 20).build());
    }

    private void setValue(float v) {
        value = SizeState.clamp(v);
        syncing = true;
        slider.setFromValue(value);
        field.setValue(fmt(value));
        syncing = false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderTransparentBackground(g);
        g.fill(left, top, left + panelW, top + panelH, 0xE0101418);
        g.renderOutline(left, top, panelW, panelH, 0xFF4CC870);
        g.drawString(font, "§a§lSize Difference", left + 10, top + 9, 0xFFFFFF, false);
        String state = SizeClient.myActive() ? "§aвключён" : "§7выключен";
        g.drawString(font, state, left + panelW - 10 - font.width(state), top + 9, 0xFFFFFF, false);
        g.drawString(font, "§7обычный рост: 1.80 → §f" + fmt(1.8F * value) + " §7блока", left + 98, top + 61, 0xFFFFFF, false);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private final class Slider extends AbstractSliderButton {
        Slider(int x, int y, int w, int h) {
            super(x, y, w, h, Component.empty(), toSlider(SizeScreen.this.value));
            updateMessage();
        }

        void setFromValue(float v) {
            this.value = toSlider(v);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Component.literal("Размер: ×" + fmt(fromSlider(this.value))));
        }

        @Override
        protected void applyValue() {
            if (syncing) return;
            SizeScreen.this.value = fromSlider(this.value);
            syncing = true;
            field.setValue(fmt(SizeScreen.this.value));
            syncing = false;
        }
    }
}
