package com.invfix.sizediff.client;

import com.invfix.sizediff.SizeHandler;
import com.invfix.sizediff.SizeState;
import com.mojang.blaze3d.platform.InputConstants;
import net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/** Клиент Size Difference: размеры игроков (с сервера), их плавный ход, меню по Shift + клавиша. */
@OnlyIn(Dist.CLIENT)
public final class SizeClient {

    private static final Map<Integer, CompoundTag> PENDING = new HashMap<>();
    private static boolean wasDown;

    private SizeClient() {}

    public static void onState(int entityId, CompoundTag tag) {
        ClientLevel level = Minecraft.getInstance().level;
        Entity e = level != null ? level.getEntity(entityId) : null;
        if (!(e instanceof Player player)) {
            PENDING.put(entityId, tag);
            return;
        }
        apply(player, tag);
    }

    private static void apply(Player player, CompoundTag tag) {
        SizeState.getOrCreate(player).read(tag);
        player.refreshDimensions();
    }

    /** Свой выбранный размер (для меню). */
    public static float myTarget() {
        Player p = Minecraft.getInstance().player;
        SizeState st = p != null ? SizeState.get(p) : null;
        return st != null ? st.target : 1.0F;
    }

    public static boolean myActive() {
        Player p = Minecraft.getInstance().player;
        SizeState st = p != null ? SizeState.get(p) : null;
        return st != null && st.active;
    }

    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {
            SizeState.partial = () -> Minecraft.getInstance().getTimer().getGameTimeDeltaPartialTick(true);
        }
    }

    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
    public static final class GameBus {

        @SubscribeEvent
        public static void onJoin(EntityJoinLevelEvent event) {
            if (!event.getLevel().isClientSide() || !(event.getEntity() instanceof Player player)) return;
            CompoundTag tag = PENDING.remove(player.getId());
            if (tag != null) apply(player, tag);
        }

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null || mc.player == null) {
                wasDown = false;
                return;
            }
            if (!mc.isPaused()) {
                for (Player player : mc.level.players()) {
                    SizeState st = SizeState.get(player);
                    if (st != null && st.tick()) player.refreshDimensions();
                }
            }
            boolean down = mc.screen == null && slotKeyDown(mc);
            if (down && !wasDown && rawDown(mc, mc.options.keyShift) && SizeHandler.eligible(mc.player)) {
                mc.setScreen(new SizeScreen());
            }
            wasDown = down;
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            SizeState.map(true).clear();
            PENDING.clear();
            wasDown = false;
        }
    }

    private static boolean slotKeyDown(Minecraft mc) {
        try {
            InvincibleIncModVariables.PlayerVariables v = mc.player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            boolean row1 = v.AbilityRow == 1.0;
            String[] slots = {
                    row1 ? v.AbilitySlot1 : v.AbilitySlot1_row2,
                    row1 ? v.AbilitySlot2 : v.AbilitySlot2_row2,
                    row1 ? v.AbilitySlot3 : v.AbilitySlot3_row2,
                    row1 ? v.AbilitySlot4 : v.AbilitySlot4_row2,
                    row1 ? v.AbilitySlot5 : v.AbilitySlot5_row2};
            KeyMapping[] keys = {
                    InvincibleIncModKeyMappings.ABILITY_1, InvincibleIncModKeyMappings.ABILITY_2,
                    InvincibleIncModKeyMappings.ABILITY_3, InvincibleIncModKeyMappings.ABILITY_4,
                    InvincibleIncModKeyMappings.ABILITY_5};
            for (int i = 0; i < 5; i++) {
                if (SizeHandler.ABILITY.equals(slots[i]) && rawDown(mc, keys[i])) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private static boolean rawDown(Minecraft mc, KeyMapping km) {
        if (km == null) return false;
        InputConstants.Key key = km.getKey();
        if (key == null || key.getValue() == InputConstants.UNKNOWN.getValue()) return false;
        long window = mc.getWindow().getWindow();
        return switch (key.getType()) {
            case KEYSYM -> InputConstants.isKeyDown(window, key.getValue());
            case MOUSE -> GLFW.glfwGetMouseButton(window, key.getValue()) == GLFW.GLFW_PRESS;
            default -> km.isDown();
        };
    }
}
