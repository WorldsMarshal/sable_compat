package com.invfix.devperks.client;

import com.invfix.devperks.DevPerks;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;
import org.joml.Matrix4f;

/**
 * Лисьи уши на модели LovsPlayer. В анимациях, касаниях и сценах Lovs отменяет ванильную
 * отрисовку игрока (AvatarRenderer#render на RenderPlayerEvent.Pre) и рисует свою модель
 * (AvatarRig) — слои ванильного рендерера, а с ними FoxEarsLayer, не вызываются. Пока Lovs
 * рисует игрока, событие запоминается (LovsAvatarRendererMixin); сразу после его модели
 * (LovsAvatarRigMixin, AvatarRig#renderToBuffer) уши рисуются в пространстве её головы —
 * AvatarRig#headMatrix, та же цепочка костей, по которой Lovs ставит глаза. Голова Lovs того же
 * размера, что ванильная (8×8×8, шарнир у шеи), так что меш ушей садится так же.
 * От первого лица своя голова Lovs скрыта — уши тоже.
 */
@OnlyIn(Dist.CLIENT)
public final class LovsRigEars {

    private static RenderPlayerEvent.Pre current;

    private LovsRigEars() {}

    public static void begin(RenderPlayerEvent.Pre event) {
        current = event;
    }

    public static void end() {
        current = null;
    }

    /** После модели Lovs: стек — тот, в котором она нарисована (мир → модель). */
    public static void render(PoseStack stack, Matrix4f headMatrix) {
        RenderPlayerEvent.Pre event = current;
        if (event == null || headMatrix == null) return;
        Player player = event.getEntity();
        if (player.isInvisible() || !DevPerks.isDeveloper(player)) return;
        Minecraft mc = Minecraft.getInstance();
        if (player == mc.player && mc.options.getCameraType().isFirstPerson()) return;
        stack.pushPose();
        stack.mulPose(headMatrix);
        FoxEarsLayer.renderEars(stack.last(), event.getMultiBufferSource(), event.getPackedLight(),
                LivingEntityRenderer.getOverlayCoords(player, 0.0F));
        stack.popPose();
    }
}
