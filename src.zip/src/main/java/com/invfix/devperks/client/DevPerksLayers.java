package com.invfix.devperks.client;

import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/** Слои приколов разработчика на рендерерах игрока (обе модели — default/slim). */
@EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class DevPerksLayers {

    private DevPerksLayers() {}

    @SubscribeEvent
    public static void onAddLayers(EntityRenderersEvent.AddLayers event) {
        event.getSkins().forEach(skin -> {
            if (event.getSkin(skin) instanceof PlayerRenderer renderer) {
                renderer.addLayer(new FoxEarsLayer(renderer));
            }
        });
    }
}
