package com.invfix.devperks.client;

import com.invfix.devperks.DevPerks;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Лисьи уши на ванильном скине — только у разработчика ({@link DevPerks#isDeveloper}).
 * Крепятся к голове модели (наклоны, присед — вместе с ней), рисуются как обычная часть модели:
 * свет, красная вспышка урона; невидимость прячет.
 */
@OnlyIn(Dist.CLIENT)
public class FoxEarsLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {

    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/dev/fox_ears.png");

    public FoxEarsLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffers, int packedLight,
                       AbstractClientPlayer player, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (player.isInvisible() || !DevPerks.isDeveloper(player)) return;
        PlayerModel<AbstractClientPlayer> model = this.getParentModel();
        if (!model.head.visible) return;

        VertexConsumer buffer = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        int overlay = LivingEntityRenderer.getOverlayCoords(player, 0.0F);

        poseStack.pushPose();
        model.head.translateAndRotate(poseStack);
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        Vector3f p = new Vector3f();
        Vector3f n = new Vector3f();
        float[] q = FoxEarsMesh.QUADS;
        for (int i = 0; i < q.length; i += FoxEarsMesh.STRIDE) {
            pose.transformNormal(q[i + 12], q[i + 13], q[i + 14], n);
            float u = q[i + 15];
            for (int v = 0; v < 4; v++) {
                int k = i + v * 3;
                matrix.transformPosition(q[k], q[k + 1], q[k + 2], p);
                buffer.addVertex(p.x(), p.y(), p.z(), 0xFFFFFFFF, u, 0.5F, overlay, packedLight, n.x(), n.y(), n.z());
            }
        }
        poseStack.popPose();
    }
}
