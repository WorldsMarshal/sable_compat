package com.invfix.devperks;

import com.mojang.authlib.GameProfile;
import net.minecraft.world.entity.player.Player;

import java.util.Set;

/**
 * Приколы для разработчика сборки. Кто разработчик — по нику аккаунта.
 *
 * LovsPlayer (aot_player_interactions, необязательный): свой пресет груди — глубина (единственный
 * «размер» пресета в моде: BreastData#size → depthScale → zScale) ×{@link #LOVS_BREAST_DEPTH}
 * от пресета мода. Только отрисовка, на каждом клиенте; данные мода и пресет не меняются.
 * Мода нет — миксин не ставится (DevPerksMixinPlugin), ничего не происходит.
 *
 * Лисьи уши на ванильном скине (client/FoxEarsLayer) — слой модели игрока, виден всем клиентам с модом.
 */
public final class DevPerks {

    /** Ники разработчиков. */
    public static final Set<String> DEVELOPERS = Set.of("HoustonWTF");

    /** Во сколько раз больше пресета LovsPlayer. */
    public static final float LOVS_BREAST_DEPTH = 1.5F;

    private DevPerks() {}

    public static boolean isDeveloper(Player player) {
        if (player == null) return false;
        GameProfile profile = player.getGameProfile();
        if (profile == null || profile.getName() == null) return false;
        for (String name : DEVELOPERS) {
            if (name.equalsIgnoreCase(profile.getName())) return true;
        }
        return false;
    }
}
