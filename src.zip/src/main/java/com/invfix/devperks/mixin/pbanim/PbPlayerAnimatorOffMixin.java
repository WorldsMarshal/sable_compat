package com.invfix.devperks.mixin.pbanim;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Point Blank и Player Animator (его приносит в сборку LovsPlayer — jar-in-jar
 * player-animation-lib-forge 2.0.4). Увидев мод playeranimator, Point Blank включает
 * PlayerAnimatorCompatImpl: проигрывает на модели игрока свои анимации от третьего лица
 * (перезарядка, ходьба, прицеливание) вместо обычной позы рук, и перезарядка ломается.
 *
 * Здесь совместимость выключена — Point Blank ведёт себя так же, как без Player Animator
 * (PlayerAnimatorCompat без реализации): isEnabled() = false (обычная поза BOW_AND_ARROW
 * у игрока с оружием, ClientEventHandler#onRenderLivingEvent), анимации не регистрируются
 * и не проигрываются. Сам Player Animator и LovsPlayer работают как работали.
 */
@Mixin(targets = "com.vicmatskiv.pointblank.compat.playeranimator.PlayerAnimatorCompatImpl", remap = false)
public abstract class PbPlayerAnimatorOffMixin {

    @Inject(method = "isEnabled()Z", at = @At("HEAD"), cancellable = true, remap = false)
    private void invfix$disabled(CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(false);
    }

    @Inject(method = "registerAnimationTypes()V", at = @At("HEAD"), cancellable = true, remap = false)
    private void invfix$noLayers(CallbackInfo ci) {
        ci.cancel();
    }

    @Inject(method = "handlePlayerThirdPersonMovement(Lnet/minecraft/world/entity/player/Player;F)V",
            at = @At("HEAD"), cancellable = true, remap = false)
    private void invfix$noMovement(CallbackInfo ci) {
        ci.cancel();
    }

    @Inject(method = "playAnimation(Lnet/minecraft/world/entity/player/Player;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V",
            at = @At("HEAD"), cancellable = true, remap = false)
    private void invfix$noPlay(CallbackInfo ci) {
        ci.cancel();
    }

    @Inject(method = "aux(Lnet/minecraft/world/entity/player/Player;)V", at = @At("HEAD"), cancellable = true, remap = false)
    private void invfix$noAux(CallbackInfo ci) {
        ci.cancel();
    }
}
