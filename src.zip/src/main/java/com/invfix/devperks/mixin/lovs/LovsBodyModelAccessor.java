package com.invfix.devperks.mixin.lovs;

import net.minecraft.client.model.geom.ModelPart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Части груди модели LovsPlayer (SharedBodyModel#rightBreast / leftBreast). Класс — по имени: мод необязательный. */
@Mixin(targets = "pro.webhm.playerinteractions.client.SharedBodyModel", remap = false)
public interface LovsBodyModelAccessor {

    @Accessor("rightBreast")
    ModelPart invfix$rightBreast();

    @Accessor("leftBreast")
    ModelPart invfix$leftBreast();
}
