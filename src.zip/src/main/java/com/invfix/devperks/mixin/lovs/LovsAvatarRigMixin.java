package com.invfix.devperks.mixin.lovs;

import com.invfix.devperks.DevPerks;
import com.invfix.devperks.client.LovsRigEars;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;

/**
 * Пресет разработчика в LovsPlayer. Модель игрока мод собирает в AvatarRig#prepare(игрок, …) →
 * configure → breasts(BreastData, …): там глубина груди = zScale = BreastData#depthScale() / 4
 * (размер пресета; ширина привязана к торсу, высота — 1). Для разработчика после breasts глубина
 * умножается на DevPerks#LOVS_BREAST_DEPTH. breasts пересчитывает её каждый кадр — множитель не
 * накапливается. Классы мода — по именам: без него миксин не ставится (DevPerksMixinPlugin).
 */
@Mixin(targets = "pro.webhm.playerinteractions.client.AvatarRig", remap = false)
public abstract class LovsAvatarRigMixin {

    @Shadow(remap = false)
    public abstract Matrix4f headMatrix();

    /** После модели игрока — лисьи уши на её голове (LovsRigEars; вне отрисовки игрока Lovs — ничего). */
    @Inject(method = "renderToBuffer", at = @At("RETURN"))
    private void invfix$rigEars(PoseStack stack, VertexConsumer out, int light, int overlay, int color,
                                CallbackInfo ci) {
        LovsRigEars.render(stack, this.headMatrix());
    }

    /** Модель сейчас собирается для разработчика (между началом и концом prepare). */
    @Unique private boolean invfix$developer;

    @Inject(method = "prepare", at = @At("HEAD"))
    private void invfix$prepareStart(AbstractClientPlayer player, Map<?, ?> pose, float partial, boolean scene,
                                     CallbackInfo ci) {
        invfix$developer = DevPerks.isDeveloper(player);
    }

    @Inject(method = "prepare", at = @At("RETURN"))
    private void invfix$prepareEnd(AbstractClientPlayer player, Map<?, ?> pose, float partial, boolean scene,
                                   CallbackInfo ci) {
        invfix$developer = false;
    }

    @Inject(method = "breasts", at = @At("TAIL"))
    private void invfix$developerPreset(CallbackInfo ci) {
        if (!invfix$developer) return;
        LovsBodyModelAccessor parts = (LovsBodyModelAccessor) (Object) this;
        ModelPart right = parts.invfix$rightBreast();
        ModelPart left = parts.invfix$leftBreast();
        if (right != null) right.zScale *= DevPerks.LOVS_BREAST_DEPTH;
        if (left != null) left.zScale *= DevPerks.LOVS_BREAST_DEPTH;
    }
}
