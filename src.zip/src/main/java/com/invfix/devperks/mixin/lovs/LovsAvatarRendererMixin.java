package com.invfix.devperks.mixin.lovs;

import com.invfix.devperks.client.LovsRigEars;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * LovsPlayer AvatarRenderer#render(RenderPlayerEvent.Pre): пока Lovs рисует игрока своей моделью,
 * событие (игрок, буферы, свет) доступно LovsRigEars. Класс — по имени: мод необязательный.
 */
@Mixin(targets = "pro.webhm.playerinteractions.client.AvatarRenderer", remap = false)
public abstract class LovsAvatarRendererMixin {

    @Inject(method = "render(Lnet/neoforged/neoforge/client/event/RenderPlayerEvent$Pre;)Z", at = @At("HEAD"))
    private static void invfix$rigEarsBegin(RenderPlayerEvent.Pre event, CallbackInfoReturnable<Boolean> cir) {
        LovsRigEars.begin(event);
    }

    @Inject(method = "render(Lnet/neoforged/neoforge/client/event/RenderPlayerEvent$Pre;)Z", at = @At("RETURN"))
    private static void invfix$rigEarsEnd(RenderPlayerEvent.Pre event, CallbackInfoReturnable<Boolean> cir) {
        LovsRigEars.end();
    }
}
