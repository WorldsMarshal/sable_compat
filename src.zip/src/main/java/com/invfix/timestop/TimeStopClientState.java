package com.invfix.timestop;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.CalculatePlayerTurnEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Клиентское зеркало зон остановки. Пишется только из
 * {@link TimeStopSyncPacket#handleClient}, читается с рендер-потока.
 *
 * Класс не помечен @OnlyIn: на него ссылается TimeStopManager (общий код), а
 * вся клиентская механика лежит во вложенном ClientEvents, который снят с
 * сервера аннотацией EventBusSubscriber(value = Dist.CLIENT).
 */
public final class TimeStopClientState {

    private TimeStopClientState() {}

    private static volatile List<TimeStopSyncPacket.Entry> entries = List.of();
    /** id тех, кого сервер освободил от заморозки (см. TimeStopExemptions). */
    private static volatile int[] exempt = new int[0];
    /** Ранг иммунитета для каждого id из exempt, той же длины и в том же порядке. */
    private static volatile int[] exemptTiers = new int[0];

    /** Локальный игрок внутри зоны. Обновляется раз в тик, читается рендером. */
    public static boolean localInsideTimeStop = false;
    /** Локальный игрок заморожен (внутри зоны и не владелец). */
    public static boolean localFrozen = false;
    /** partialTick, зафиксированный на момент входа в остановку — для замороженных сущностей. */
    public static float frozenPartialTick = 1.0f;
    /** Может ли локальный игрок действовать внутри зоны (владелец или исключение). */
    public static boolean localCanAct = false;

    static void accept(List<TimeStopSyncPacket.Entry> incoming, int[] incomingExempt,
                       int[] incomingExemptTiers) {
        entries = new ArrayList<>(incoming);
        int[] ids = incomingExempt == null ? new int[0] : incomingExempt;
        int[] ranks = incomingExemptTiers == null ? new int[0] : incomingExemptTiers;
        // Рассинхрон длин означал бы битый пакет; тогда безопаснее считать, что
        // исключений нет, чем читать чужой ранг по индексу.
        if (ids.length != ranks.length) { ids = new int[0]; ranks = new int[0]; }
        exempt = ids;
        exemptTiers = ranks;
        if (incoming.isEmpty()) {
            localInsideTimeStop = false;
            localFrozen = false;
            localCanAct = false;
        }
    }

    /** Владеет ли сущность одной из зон (по клиентскому зеркалу). */
    public static boolean ownsZone(int entityId) {
        List<TimeStopSyncPacket.Entry> snapshot = entries;
        for (int i = 0; i < snapshot.size(); i++) {
            if (snapshot.get(i).ownerEntityId() == entityId) return true;
        }
        return false;
    }

    public static boolean hasAny() {
        return !entries.isEmpty();
    }

    /** Пересекает ли мировой габарит какую-либо зону (клиентское зеркало). */
    public static boolean intersectsWorldBox(double minX, double minZ, double maxX, double maxZ) {
        List<TimeStopSyncPacket.Entry> snapshot = entries;
        if (snapshot.isEmpty()) return false;
        int minCX = net.minecraft.util.Mth.floor(minX) >> 4;
        int maxCX = net.minecraft.util.Mth.floor(maxX) >> 4;
        int minCZ = net.minecraft.util.Mth.floor(minZ) >> 4;
        int maxCZ = net.minecraft.util.Mth.floor(maxZ) >> 4;
        for (int i = 0; i < snapshot.size(); i++) {
            TimeStopSyncPacket.Entry e = snapshot.get(i);
            int range = e.chunkRange();
            if (range <= 0) return true;
            int nearX = Math.max(minCX, Math.min(e.chunkX(), maxCX));
            int nearZ = Math.max(minCZ, Math.min(e.chunkZ(), maxCZ));
            if (Math.abs(e.chunkX() - nearX) < range && Math.abs(e.chunkZ() - nearZ) < range) {
                return true;
            }
        }
        return false;
    }

    public static boolean isInsideChunk(int chunkX, int chunkZ) {
        List<TimeStopSyncPacket.Entry> snapshot = entries;
        for (int i = 0; i < snapshot.size(); i++) {
            TimeStopSyncPacket.Entry e = snapshot.get(i);
            int range = e.chunkRange();
            if (range <= 0) return true;
            if (Math.abs(e.chunkX() - chunkX) < range && Math.abs(e.chunkZ() - chunkZ) < range) {
                return true;
            }
        }
        return false;
    }

    public static boolean isInside(BlockPos pos) {
        List<TimeStopSyncPacket.Entry> snapshot = entries;
        for (int i = 0; i < snapshot.size(); i++) {
            TimeStopSyncPacket.Entry e = snapshot.get(i);
            if (inRange(e, pos)) return true;
        }
        return false;
    }

    /**
     * Клиентское зеркало серверного решения о заморозке — логика та же, что в
     * TimeStopManager#frozenIn. Ранг зоны здесь не смотрится: иммунные равны
     * между собой независимо от уровня накрывшей их остановки.
     */
    public static boolean isFrozenAt(int entityId, BlockPos pos) {
        List<TimeStopSyncPacket.Entry> snapshot = entries;
        final int size = snapshot.size();
        if (size == 0) return false;

        final int cx = pos.getX() >> 4;
        final int cz = pos.getZ() >> 4;
        boolean inside = false;
        for (int i = 0; i < size; i++) {
            TimeStopSyncPacket.Entry e = snapshot.get(i);
            if (e.ownerEntityId() == entityId) return false;
            if (!inside && inRange(e, cx, cz)) inside = true;
        }
        if (!inside) return false;

        final int[] ids = exempt;
        for (int i = 0; i < ids.length; i++) {
            if (ids[i] == entityId) return false;
        }
        return true;
    }

    /** Может ли сущность действовать: отрицание {@link #isFrozenAt}. */
    public static boolean canAct(int entityId, BlockPos pos) {
        return !isFrozenAt(entityId, pos);
    }

    private static boolean inRange(TimeStopSyncPacket.Entry e, BlockPos pos) {
        return inRange(e, pos.getX() >> 4, pos.getZ() >> 4);
    }

    private static boolean inRange(TimeStopSyncPacket.Entry e, int chunkX, int chunkZ) {
        int range = e.chunkRange();
        if (range <= 0) return true;
        return Math.abs(e.chunkX() - chunkX) < range && Math.abs(e.chunkZ() - chunkZ) < range;
    }

    /** Заморожена ли сущность с точки зрения клиента (используется рендером). */
    public static boolean isFrozen(Entity entity) {
        if (entity == null || entries.isEmpty()) return false;
        if (entity.isSpectator()) return false;
        return isFrozenAt(entity.getId(), entity.blockPosition());
    }

    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
    public static final class ClientEvents {

        private ClientEvents() {}

        @SubscribeEvent(priority = EventPriority.HIGHEST)
        public static void onClientTick(ClientTickEvent.Pre event) {
            Minecraft mc = Minecraft.getInstance();
            Entity camera = mc.cameraEntity != null ? mc.cameraEntity : mc.player;
            if (camera == null || entries.isEmpty()) {
                localInsideTimeStop = false;
                localFrozen = false;
                localCanAct = false;
                com.invfix.timestop.client.TimeStopShaderState.update(false);
                onFrozenChanged(mc, false);
                return;
            }
            boolean wasInside = localInsideTimeStop;
            localInsideTimeStop = isInside(camera.blockPosition());
            localCanAct = camera.isSpectator()
                    || !isFrozenAt(camera.getId(), camera.blockPosition());
            localFrozen = localInsideTimeStop && !localCanAct;
            onFrozenChanged(mc, localFrozen);
            if (localInsideTimeStop && !wasInside) {
                frozenPartialTick = 1.0f;
            }
            // Фильтр — всем, кто внутри зоны, и действующим, и пойманным.
            // В ROTP он только для действующих, но пойманный игрок тогда видит
            // ровно картину зависшей игры и не понимает, что произошло.
            com.invfix.timestop.client.TimeStopShaderState.update(localInsideTimeStop
                    && (localCanAct || TimeStopConfig.indicateToFrozenPlayers));
        }

        /**
         * Был ли этот клиент заморожен на прошлом тике. Отдельно от
         * localFrozen: тот сбрасывает ещё и обработчик пакета синхронизации,
         * и переход «был заморожен → уже нет» мог бы пройти мимо.
         */
        private static boolean frozenLastTick = false;

        /**
         * Разморозка без проезда.
         *
         * Пока клиент был заморожен, сущности у него не тикали, а позиции от
         * сервера копились целью интерполяции (ваниль ставит её на три
         * шага). После снятия клиент доигрывал бы её — иммунный, ходивший в
         * остановке, проезжал бы от точки заморозки до своего места. Но
         * замороженный не мог за ним проследить: для него тот просто
         * оказывается в другом месте в то же мгновение. Ровно так же, как при
         * мгновенной остановке, поэтому и средство то же самое — порт
         * LivingUtilCap#tickNoLerp из ROTP: оставшуюся интерполяцию сжать до
         * одного шага. Здесь это делается разом для всех, до тика сущностей.
         *
         * Отступление от ROTP: там при снятии обычной остановки интерполяцию
         * не трогают, и проезд виден.
         */
        private static void onFrozenChanged(Minecraft mc, boolean frozenNow) {
            boolean was = frozenLastTick;
            frozenLastTick = frozenNow;
            if (!was || frozenNow || mc.level == null) return;
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e instanceof net.minecraft.world.entity.LivingEntity living) {
                    var acc = (com.invfix.mixin.timestop.TsLivingEntityLerpAccessor) living;
                    if (acc.invfix$getLerpSteps() > 1) acc.invfix$setLerpSteps(1);
                }
            }
        }

        /** Замороженный игрок не может бить/ставить/ломать. */
        @SubscribeEvent(priority = EventPriority.HIGHEST)
        public static void onInteractionKey(InputEvent.InteractionKeyMappingTriggered event) {
            if (localFrozen) {
                event.setCanceled(true);
                event.setSwingHand(false);
            }
        }

        /** Замороженный игрок не может вертеть головой. */
        @SubscribeEvent(priority = EventPriority.HIGHEST)
        public static void onTurn(CalculatePlayerTurnEvent event) {
            if (localFrozen) {
                // b = (0.6*a + 0.2)^3 * 8; при a = -1/3 множитель обнуляется
                event.setMouseSensitivity(-1.0f / 3.0f);
            }
        }
    }
}
