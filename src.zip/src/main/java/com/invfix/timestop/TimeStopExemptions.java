package com.invfix.timestop;

import com.invfix.altrumite.AltrumiteRace;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Реестр правил «этот игрок не морозится внутри чужой остановки времени».
 *
 * Правило даёт не просто иммунитет, а иммунитет ДО определённого уровня
 * ({@link TimeStopTier}). Носитель устройства свободно ходит в чужой
 * устройственной остановке, но замирает в остановке Metroman; сам Metroman не
 * замечает ни того, ни другого. Сравнение идёт по рангу: правило перекрывает
 * зону, если его ранг не ниже ранга зоны.
 *
 * Зачем реестр, а не набор if'ов: источников тайм-стопа будет много —
 * разновидности Metroman, пульт Рика, камень времени. Каждый регистрирует своё
 * правило и ничего не знает про остальные.
 *
 * Про производительность. Правила НЕ вычисляются на горячем пути. Сервер раз в
 * {@link TimeStopConfig#exemptRefreshIntervalTicks} тиков прогоняет их по
 * игрокам измерения (их единицы), складывает id и выданный ранг в два
 * параллельных массива и синхронизирует клиентам. В проверке заморозки
 * остаётся линейный проход по int[] длиной обычно ноль или один.
 */
public final class TimeStopExemptions {

    private TimeStopExemptions() {}

    /**
     * Правило исключения. Вызывается редко, поэтому внутри можно позволить
     * себе чтение переменных игрока и сравнение строк.
     */
    @FunctionalInterface
    public interface Rule {
        /** true — игрок продолжает действовать внутри остановки своего уровня и ниже. */
        boolean exempt(ServerPlayer player, InvincibleIncModVariables.PlayerVariables vars);
    }

    private record NamedRule(String name, int tierRank, Rule rule) {}

    private static final List<NamedRule> RULES = new CopyOnWriteArrayList<>();

    /**
     * Регистрирует правило.
     *
     * @param tier уровень, до которого правило даёт иммунитет включительно
     */
    public static void register(String name, TimeStopTier tier, Rule rule) {
        if (name == null || tier == null || rule == null) return;
        RULES.add(new NamedRule(name, tier.rank, rule));
    }

    /**
     * Наибольший ранг, до которого игрок освобождён от заморозки.
     * {@link Integer#MIN_VALUE} — не освобождён ничем.
     */
    public static int grantedTierRank(ServerPlayer player) {
        InvincibleIncModVariables.PlayerVariables vars = variables(player);
        if (vars == null) return Integer.MIN_VALUE;
        int best = Integer.MIN_VALUE;
        for (NamedRule named : RULES) {
            if (named.tierRank() <= best) continue;
            try {
                if (named.rule().exempt(player, vars)) best = named.tierRank();
            } catch (Throwable ignored) {}
        }
        return best;
    }

    /** Имя сильнейшего сработавшего правила, либо null. Для /timestop debug. */
    public static String matchedRule(ServerPlayer player) {
        InvincibleIncModVariables.PlayerVariables vars = variables(player);
        if (vars == null) return null;
        String bestName = null;
        int best = Integer.MIN_VALUE;
        for (NamedRule named : RULES) {
            if (named.tierRank() <= best) continue;
            try {
                if (named.rule().exempt(player, vars)) {
                    best = named.tierRank();
                    bestName = named.name();
                }
            } catch (Throwable ignored) {}
        }
        return bestName;
    }

    private static InvincibleIncModVariables.PlayerVariables variables(ServerPlayer player) {
        try {
            return player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Лежит ли способность в одном из десяти слотов обоих рядов. */
    public static boolean hasAbilityInSlots(InvincibleIncModVariables.PlayerVariables vars, String ability) {
        return ability.equals(vars.AbilitySlot1) || ability.equals(vars.AbilitySlot2)
                || ability.equals(vars.AbilitySlot3) || ability.equals(vars.AbilitySlot4)
                || ability.equals(vars.AbilitySlot5)
                || ability.equals(vars.AbilitySlot1_row2) || ability.equals(vars.AbilitySlot2_row2)
                || ability.equals(vars.AbilitySlot3_row2) || ability.equals(vars.AbilitySlot4_row2)
                || ability.equals(vars.AbilitySlot5_row2);
    }

    static {
        // Metroman: раса подходит, уровень набран, способность разложена по
        // слотам. Уровень ABSOLUTE — значит не замечает ни чужого Metroman,
        // ни любых устройств.
        register("metroman_time_stop", TimeStopTier.ABSOLUTE, (player, vars) ->
                AltrumiteRace.isAltrumite(vars.Race)
                        && vars.Lvl >= TimeStopHandler.lvlRequired
                        && hasAbilityInSlots(vars, TimeStopHandler.ABILITY));
    }
}
