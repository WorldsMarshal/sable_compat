package com.invfix.timestop;

import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ChunkPos;

/**
 * Одна активная зона остановки времени. Живёт на сервере в {@link TimeStopLevelState}
 * и зеркалится на клиент через {@link TimeStopSyncPacket}.
 *
 * Геометрия зоны — чебышёвское расстояние в чанках от центрального чанка,
 * как в ROTP 1.21.1 (TimeStopInstance#isInRange). Зона не ограничена по Y.
 */
public final class TimeStopInstance {

    public final int id;
    /** Центр зоны в координатах чанка. */
    public final int chunkX;
    public final int chunkZ;
    public final int chunkRange;
    /** Entity#getId() владельца, или -1. Владелец не морозится. */
    public final int ownerEntityId;
    /** Для конечной зоны — длительность в тиках. Для бесконечной не используется. */
    public final int duration;
    /** Бесконечная зона: снимается только владельцем, смертью, выходом или командой. */
    public final boolean endless;

    /**
     * Ранг уровня остановки ({@link TimeStopTier#rank}). Хранится числом, а не
     * enum'ом: так между уровнями можно вставить новый, не ломая ни сеть, ни
     * сравнение — оно везде идёт по рангу.
     */
    public final int tierRank;

    /** Только на сервере: сколько тиков осталось. На клиенте — снимок на момент синка. */
    public int ticksLeft;

    /**
     * Наш собственный счётчик тиков уровня на момент старта (только сервер).
     * Сторож конечной зоны считает возраст по нему, а не по ticksLeft: если наш
     * обработчик тика почему-то не позвали, счётчик застынет, а сторож — нет.
     *
     * Раньше здесь лежало level.getGameTime(), и это было ошибкой: мы сами
     * морозили суточный цикл отменой ServerLevel#tickTime, а та же функция
     * двигает и gameTime, так что сторож всегда видел возраст 0.
     */
    public long startedTick;

    /**
     * Зона требует «подтверждения жизни» каждый тик от того, кто её держит.
     *
     * Ставится для бессрочных зон устройств. Пульт подтверждает её из
     * PlayerTickEvent владельца, пока лежит у него в инвентаре и имеет заряд.
     * Если подтверждений нет дольше {@link TimeStopConfig#upkeepGraceTicks} —
     * зону снимает сторож в TimeStopManager.
     *
     * Без этого мир один раз уже завис навсегда: пульт выкинули во время
     * остановки, списывать заряд стало не с чего, а снять зону — нечем.
     */
    public boolean requiresUpkeep;

    /** Тик уровня, когда зону подтвердили в последний раз. */
    public long lastUpkeepTick;

    public TimeStopInstance(int id, int chunkX, int chunkZ, int chunkRange,
                            int ownerEntityId, int duration, int ticksLeft, boolean endless,
                            int tierRank) {
        this.endless = endless;
        this.tierRank = tierRank;
        this.id = id;
        this.chunkX = chunkX;
        this.chunkZ = chunkZ;
        this.chunkRange = chunkRange;
        this.ownerEntityId = ownerEntityId;
        this.duration = duration;
        this.ticksLeft = ticksLeft;
    }

    public boolean isInRange(int otherChunkX, int otherChunkZ) {
        return chunkRange <= 0
                || (Math.abs(chunkX - otherChunkX) < chunkRange
                 && Math.abs(chunkZ - otherChunkZ) < chunkRange);
    }

    public boolean isInRange(ChunkPos pos) {
        return isInRange(pos.x, pos.z);
    }

    public boolean isInRangeChunkPacked(long packedChunkPos) {
        return isInRange(new ChunkPos(packedChunkPos));
    }

    public boolean isInRange(BlockPos pos) {
        return isInRange(SectionPos.blockToSectionCoord(pos.getX()),
                         SectionPos.blockToSectionCoord(pos.getZ()));
    }

    /** Для мировых координат с плавающей точкой (судна Sable, вагоны Create). */
    public boolean isInRangeWorld(double worldX, double worldZ) {
        return isInRange(SectionPos.blockToSectionCoord(Mth.floor(worldX)),
                         SectionPos.blockToSectionCoord(Mth.floor(worldZ)));
    }

    /** Пересекается ли зона с мировым AABB (габарит судна). */
    public boolean intersects(double minX, double minZ, double maxX, double maxZ) {
        if (chunkRange <= 0) return true;
        int minCX = SectionPos.blockToSectionCoord(Mth.floor(minX));
        int maxCX = SectionPos.blockToSectionCoord(Mth.floor(maxX));
        int minCZ = SectionPos.blockToSectionCoord(Mth.floor(minZ));
        int maxCZ = SectionPos.blockToSectionCoord(Mth.floor(maxZ));
        // ближайшая к центру зоны точка габарита
        int nearX = Math.max(minCX, Math.min(chunkX, maxCX));
        int nearZ = Math.max(minCZ, Math.min(chunkZ, maxCZ));
        return isInRange(nearX, nearZ);
    }

    public ChunkPos center() {
        return new ChunkPos(chunkX, chunkZ);
    }
}
