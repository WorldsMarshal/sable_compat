package com.invfix.timestop.client;

import com.invfix.timestop.TimeStopConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.resources.ResourceLocation;

/**
 * Потускнение кадра на время остановки: пост-чейн
 * assets/sable_compat/shaders/post/time_stop.json поверх собственной
 * программы time_stop_fade (насыщенность 0.65, яркость 0.8). Не серая пелена
 * поверх картинки — выцветают сами цвета.
 *
 * Своя программа, а не ванильный color_convolve, ровно по той же схеме, что
 * у ROTP 1.21.1 (jojo_ripples:color_convolve, vertex "sobel"): так набор
 * униформ известен точно и не зависит от того, что из них объявлено в ванили.
 *
 * Загружается штатным API GameRenderer, а не миксином, поэтому промах по имени
 * метода был бы ошибкой компиляции, а не крашем при запуске. Образец
 * использования взят у PointBlank из этой же сборки
 * (PostPassEffectController), он собран под ровно эту версию.
 *
 * Гасим эффект только если он наш — проверка по префиксу имени, как у них же:
 * иначе можно снести чужой пост-эффект, например рябь от выстрела PointBlank.
 */
public final class TimeStopShaderState {

    private TimeStopShaderState() {}

    private static final ResourceLocation SHADER =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "shaders/post/time_stop.json");
    private static final String OWN_PREFIX = "sable_compat:";

    private static boolean applied = false;
    private static boolean loggedOutcome = false;
    private static boolean loggedReloadLoop = false;

    /**
     * Как часто перепроверять, что наш пост-чейн ещё висит, в клиентских тиках.
     *
     * Проверка не бесплатная не сама по себе, а последствиями: если она решит,
     * что чейна нет, будет loadEffect — то есть пересборка и перелинковка
     * GLSL-программы и перевыделение таргетов. В прошлой версии это выходило
     * КАЖДЫЙ тик, 20 полных пересборок в секунду на рендер-потоке (видно по
     * логу: ровно 20 предупреждений EffectInstance в секунду всё время
     * остановки). Раз в секунду — потолок в двадцать раз ниже, а на глаз
     * разницы нет: чейн либо висит, либо его отобрали насовсем.
     */
    private static final int VERIFY_INTERVAL_TICKS = 20;

    private static int sinceVerify = 0;
    private static int reloadsInARow = 0;

    private static final org.slf4j.Logger LOGGER =
            org.slf4j.LoggerFactory.getLogger("invfix/timestop");

    /**
     * Поднялся ли наш пост-чейн на самом деле. Если нет, экран красит запасная
     * заливка из TimeStopScreenTint.
     */
    public static boolean isActive() {
        if (!TimeStopConfig.useTimeStopShader || !applied) return false;
        try {
            return isOursActive(Minecraft.getInstance());
        } catch (Throwable t) {
            return false;
        }
    }

    /** Зовётся каждый клиентский тик из TimeStopClientState. */
    public static void update(boolean insideTimeStop) {
        if (!TimeStopConfig.useTimeStopShader) {
            if (applied) clear();
            return;
        }
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null || mc.player == null) {
                // Выход в меню или смена мира с висящим фильтром — снимаем.
                if (applied) clear();
                return;
            }
            if (!insideTimeStop) {
                if (applied) clear();
                return;
            }

            if (applied) {
                // Уже поставили. Перепроверяем не каждый тик, см.
                // VERIFY_INTERVAL_TICKS.
                if (++sinceVerify < VERIFY_INTERVAL_TICKS) return;
                sinceVerify = 0;
                if (isOursActive(mc)) {
                    reloadsInARow = 0;
                    return;
                }
                // Чейн кто-то снял. Ставим заново, но если это повторяется —
                // говорим об этом один раз и с именем того, что висит сейчас:
                // без этой строки причину не отличить от «мы сами сбрасываем».
                if (++reloadsInARow >= 3 && !loggedReloadLoop) {
                    loggedReloadLoop = true;
                    PostChain other = mc.gameRenderer.currentEffect();
                    LOGGER.warn("[timestop] наш пост-чейн снимают со стороны, ставим заново каждую секунду; сейчас активен: {}",
                            other == null ? "ничего" : other.getName());
                }
            } else {
                sinceVerify = 0;
            }

            mc.gameRenderer.loadEffect(SHADER);
            applied = true;

            // loadEffect глотает ошибку разбора внутрь лога ванили, а
            // шейдерпак может и вовсе отобрать пост-обработку. Поэтому один
            // раз сообщаем, чем всё кончилось: без этой строки «фильтр не
            // появился» не отличить от «фильтр не загрузился».
            if (!loggedOutcome) {
                loggedOutcome = true;
                PostChain chain = mc.gameRenderer.currentEffect();
                if (chain == null) {
                    LOGGER.warn("[timestop] пост-чейн {} не поднялся — включается запасная заливка экрана", SHADER);
                } else {
                    LOGGER.info("[timestop] пост-чейн активен: {}", chain.getName());
                }
            }
        } catch (Throwable ignored) {
            applied = false;
        }
    }

    private static boolean isOursActive(Minecraft mc) {
        PostChain current = mc.gameRenderer.currentEffect();
        return current != null && current.getName() != null && current.getName().startsWith(OWN_PREFIX);
    }

    /** Снимает фильтр, если сейчас висит именно наш. */
    public static void clear() {
        applied = false;
        sinceVerify = 0;
        reloadsInARow = 0;
        try {
            Minecraft mc = Minecraft.getInstance();
            if (isOursActive(mc)) {
                mc.gameRenderer.shutdownEffect();
            }
        } catch (Throwable ignored) {}
    }
}
