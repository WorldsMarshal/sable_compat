package com.invfix.timestop.client;

import com.invfix.timestop.TimeStopClientState;
import com.invfix.timestop.TimeStopConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderGuiEvent;

/**
 * Запасное затемнение — на случай, если пост-чейн не применился.
 *
 * Рамки и надписей здесь нет: индикация должна быть интуитивной, а не
 * читаемой. Основной способ — потускнение через {@link TimeStopShaderState};
 * этот класс рисует плоскую заливку только тогда, когда пост-чейн не поднялся
 * (например, его перехватил шейдерпак Iris). Заливкой обесцветить нельзя,
 * поэтому здесь слабое нейтральное затемнение, а не серая пелена.
 *
 * Рисуется на RenderGuiEvent.Pre, то есть под ванильным интерфейсом:
 * затемняется мир, а хотбар и сердца остаются читаемыми.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class TimeStopScreenTint {

    private TimeStopScreenTint() {}

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Pre event) {
        if (!TimeStopConfig.useTintFallback) return;
        if (!TimeStopClientState.localInsideTimeStop) return;
        if (!TimeStopClientState.localCanAct && !TimeStopConfig.indicateToFrozenPlayers) return;
        // Пост-чейн справился сам — поверх него ничего не надо.
        if (TimeStopShaderState.isActive()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        GuiGraphics graphics = event.getGuiGraphics();
        graphics.fill(0, 0, graphics.guiWidth(), graphics.guiHeight(), TimeStopConfig.tintColor);
    }
}
