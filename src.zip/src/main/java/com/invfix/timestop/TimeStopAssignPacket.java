package com.invfix.timestop;

import com.invfix.altrumite.AltrumiteRace;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Клиент → сервер: положить «Остановку времени» в AbilitySet.
 * Тот же протокол, что у HeatVisionAssignPacket/KineticStrikeAssignPacket.
 */
public record TimeStopAssignPacket(int x, int y, int z) implements CustomPacketPayload {

    public static final Type<TimeStopAssignPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "timestop_assign"));

    public static final StreamCodec<FriendlyByteBuf, TimeStopAssignPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, msg) -> { buf.writeInt(msg.x()); buf.writeInt(msg.y()); buf.writeInt(msg.z()); },
                    buf -> new TimeStopAssignPacket(buf.readInt(), buf.readInt(), buf.readInt()));

    @Override
    public Type<TimeStopAssignPacket> type() { return TYPE; }

    public static void handleServer(TimeStopAssignPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer player)) return;
            try {
                InvincibleIncModVariables.PlayerVariables vars =
                        player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                if (!AltrumiteRace.isAltrumite(vars.Race)) return;
                if (vars.Lvl < TimeStopHandler.lvlRequired) return;

                vars.AbilitySet = TimeStopHandler.ABILITY;
                vars.abilityDescription = TimeStopHandler.ABILITY
                        + " | LVL:" + TimeStopHandler.lvlRequired + " | ";
                vars.markSyncDirty();
            } catch (Exception ignored) {}
        });
    }
}
