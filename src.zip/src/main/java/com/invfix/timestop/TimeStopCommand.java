package com.invfix.timestop;

import com.invfix.timestop.compat.SableTimeStop;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import java.util.List;

/**
 * Отладка и аварийное управление:
 *
 *  /timestop            — бесконечная зона от своего имени, минуя расу и уровень;
 *  /timestop [секунды]  — конечная зона;
 *  /timestop resume     — снять свою зону;
 *  /timestop status     — сколько зон и замороженных судов, взведён ли рубильник;
 *  /timestop debug      — по каждой сущности вокруг: заморожена ли и почему нет;
 *  /timestop clear      — снять всё во всех измерениях, отпустить констрейнты
 *                         судов и вернуть механику в строй после рубильника.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class TimeStopCommand {

    private TimeStopCommand() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("timestop")
                        .requires(src -> src.hasPermission(2))
                        .executes(ctx -> start(ctx.getSource().getEntity(), 0, true,
                                TimeStopTier.ABSOLUTE, ctx))
                        .then(Commands.literal("clear")
                                .executes(ctx -> {
                                    TimeStopManager.emergencyClearAll(ctx.getSource().getServer());
                                    TimeStopManager.reenable();
                                    ctx.getSource().sendSuccess(() -> Component.literal(
                                            "§bВсё снято, констрейнты судов отпущены, рубильник взведён обратно"), true);
                                    return Command.SINGLE_SUCCESS;
                                }))
                        .then(Commands.literal("status")
                                .executes(ctx -> {
                                    if (!(ctx.getSource().getLevel() instanceof ServerLevel level)) return 0;
                                    int zones = TimeStopManager.instances(level).size();
                                    int ships = SableTimeStop.frozenShipCount(level);
                                    boolean off = TimeStopManager.isDisabled();
                                    ctx.getSource().sendSuccess(() -> Component.literal(
                                            "§bзон: " + zones + ", замороженных судов: " + ships
                                                    + (off ? ", §cмеханика отключена рубильником" : "")), false);
                                    return Command.SINGLE_SUCCESS;
                                }))
                        .then(Commands.literal("debug").executes(TimeStopCommand::debug))
                        .then(Commands.literal("resume")
                                .executes(ctx -> {
                                    if (!(ctx.getSource().getEntity() instanceof ServerPlayer player)) return 0;
                                    boolean stopped = TimeStopHandler.resume(player);
                                    ctx.getSource().sendSuccess(() -> Component.literal(
                                            stopped ? "§bВремя возобновлено" : "§7Активной зоны нет"), false);
                                    return Command.SINGLE_SUCCESS;
                                }))
                        // Нижний уровень — для проверки приоритетов без пульта Рика.
                        .then(Commands.literal("device")
                                .executes(ctx -> start(ctx.getSource().getEntity(), 0, true,
                                        TimeStopTier.DEVICE, ctx))
                                .then(Commands.argument("seconds", IntegerArgumentType.integer(1, 600))
                                        .executes(ctx -> start(ctx.getSource().getEntity(),
                                                IntegerArgumentType.getInteger(ctx, "seconds") * 20,
                                                false, TimeStopTier.DEVICE, ctx))))
                        .then(Commands.argument("seconds", IntegerArgumentType.integer(1, 600))
                                .executes(ctx -> start(ctx.getSource().getEntity(),
                                        IntegerArgumentType.getInteger(ctx, "seconds") * 20, false,
                                        TimeStopTier.ABSOLUTE, ctx)))
        );
    }

    private static int start(Entity entity, int ticks, boolean endless, TimeStopTier tier,
                             CommandContext<CommandSourceStack> ctx) {
        if (!(entity instanceof ServerPlayer player)) return 0;
        if (!(player.level() instanceof ServerLevel level)) return 0;

        boolean ownsAlready = TimeStopManager.ownedBy(level, player.getId()) != null;
        TimeStopInstance inst = TimeStopManager.start(level, player, ticks,
                TimeStopConfig.chunkRange, endless, tier);
        if (inst == null) {
            ctx.getSource().sendSuccess(() -> Component.literal(ownsAlready
                    ? "§7Зона уже активна — /timestop resume, чтобы снять"
                    : "§7Отклонено: точка уже накрыта остановкой уровня "
                            + tier.name().toLowerCase(java.util.Locale.ROOT)), false);
            return 0;
        }
        final String how = endless ? "бессрочно" : (ticks / 20) + " с";
        ctx.getSource().sendSuccess(() -> Component.literal(
                "§bВремя остановлено " + how + ", радиус " + TimeStopConfig.chunkRange
                        + " чанков, уровень " + tier.name().toLowerCase(java.util.Locale.ROOT)), false);
        return Command.SINGLE_SUCCESS;
    }

    /**
     * Построчный разбор по сущностям в радиусе 24 блоков: считает ли механика
     * каждую замороженной, а если нет — по какой причине. Нужна, когда «существа
     * не стопорятся, а замедляются»: сразу видно, зона это не накрыла, сущность
     * исключена как действующая, или тик отменяется, а двигает её кто-то другой.
     */
    private static int debug(CommandContext<CommandSourceStack> ctx) {
        if (!(ctx.getSource().getEntity() instanceof ServerPlayer player)) return 0;
        if (!(player.level() instanceof ServerLevel level)) return 0;

        List<TimeStopInstance> zones = TimeStopManager.instances(level);
        ctx.getSource().sendSuccess(() -> Component.literal(
                "§b— зон в измерении: " + zones.size()
                        + ", рубильник: " + (TimeStopManager.isDisabled() ? "§cвыключено" : "§aв строю")), false);
        for (TimeStopInstance z : zones) {
            ctx.getSource().sendSuccess(() -> Component.literal(
                    "§7  зона " + z.id + " центр " + z.chunkX + "/" + z.chunkZ
                            + " радиус " + z.chunkRange
                            + (z.endless ? " бессрочная" : " осталось " + z.ticksLeft)
                            + " уровень " + TimeStopTier.byRank(z.tierRank).name()
                                    .toLowerCase(java.util.Locale.ROOT) + "(" + z.tierRank + ")"
                            + " владелец eid " + z.ownerEntityId), false);
        }

        AABB box = player.getBoundingBox().inflate(24.0);
        List<Entity> around = level.getEntities(player, box);
        int shown = 0;
        for (Entity e : around) {
            if (shown++ >= 12) break;
            boolean inside = TimeStopApi.isInsideTimeStop(e);
            boolean canAct = TimeStopApi.canActInStoppedTime(e);
            boolean frozen = TimeStopApi.isFrozen(e);
            String why;
            if (frozen) {
                why = "§aзаморожена";
            } else if (!inside) {
                why = "§cвне зоны";
            } else if (canAct) {
                String rule = e instanceof ServerPlayer sp ? TimeStopExemptions.matchedRule(sp) : null;
                if (rule != null) {
                    int rank = TimeStopExemptions.grantedTierRank((ServerPlayer) e);
                    why = "§eисключена правилом " + rule + " (уровень " + rank + ")";
                }
                else if (e instanceof net.minecraft.world.entity.monster.EnderMan) why = "§eэндермен (ходит, но не телепортируется)";
                else why = "§eисключена (владелец/креатив/спектатор/в воздухе без mayfly)";
            } else {
                why = "§cвнутри зоны, но не заморожена";
            }
            final String line = "§7  " + e.getType().toShortString() + " eid " + e.getId()
                    + " tick " + e.tickCount + " — " + why;
            ctx.getSource().sendSuccess(() -> Component.literal(line), false);
        }
        final int total = around.size();
        ctx.getSource().sendSuccess(() -> Component.literal(
                "§7  всего сущностей в 24 блоках: " + total
                        + ", замороженных судов: " + SableTimeStop.frozenShipCount(level)), false);
        return Command.SINGLE_SUCCESS;
    }
}
