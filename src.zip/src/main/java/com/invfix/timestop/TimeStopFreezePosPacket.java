package com.invfix.timestop;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Сервер → клиент: сущность только что замерзла, поставь её ровно сюда и
 * обнули интерполяцию.
 *
 * Зачем. Клиент рисует сущность между её прошлой позицией (xo/yo/zo) и текущей
 * (x/y/z). Когда сущность замерзает на ходу, прошлая позиция остаётся позади
 * текущей, и та продолжает «доезжать» до неё на рендере — моб не встаёт колом,
 * а плавно дотягивает шаг. На бегущей толпе это читается как замедление, а не
 * остановка. Поэтому вместе с заморозкой клиенту сообщается позиция, и он
 * приравнивает xo/yo/zo к ней.
 *
 * Механика взята из ROTP 1.21.1: TimeStopEffect#setTimeStopState шлёт
 * EntityDirectPosNoLerpPacket ровно по этой причине («should prevent the old
 * position desync if the entity was moving at high speed»). В первой версии
 * этой ветки я её не перенёс — это и был пропуск.
 */
public record TimeStopFreezePosPacket(int entityId, double x, double y, double z)
        implements CustomPacketPayload {

    public static final Type<TimeStopFreezePosPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "timestop_freeze_pos"));

    public static final StreamCodec<FriendlyByteBuf, TimeStopFreezePosPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, msg) -> {
                        buf.writeVarInt(msg.entityId());
                        buf.writeDouble(msg.x());
                        buf.writeDouble(msg.y());
                        buf.writeDouble(msg.z());
                    },
                    buf -> new TimeStopFreezePosPacket(
                            buf.readVarInt(), buf.readDouble(), buf.readDouble(), buf.readDouble()));

    @Override
    public Type<TimeStopFreezePosPacket> type() { return TYPE; }
}
