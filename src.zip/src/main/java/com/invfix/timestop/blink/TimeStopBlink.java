package com.invfix.timestop.blink;

import com.invfix.timestop.TimeStopExemptions;
import com.invfix.timestop.TimeStopManager;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;

/**
 * Мгновенная остановка времени — порт TimeStopInstant из ROTP 1.16.5.
 *
 * По лору это не телепорт: владелец останавливает время, проходит до точки и
 * отпускает его, а окружающие видят только результат. Поэтому зоны здесь нет
 * вовсе — ни заморозки, ни шейдера, ни затрат на работу всего мира. Считается
 * только, СКОЛЬКО тиков такой остановки подразумевается: расстояние, делённое
 * на скорость ходьбы. От этого числа зависит цена у пульта.
 *
 * Всё, что ниже, повторяет оригинал по шагам, с названиями методов ROTP в
 * комментариях. Отступления от него — только там, где в нашей сборке нет
 * соответствующей сущности (стенда, стамины, тренировки), и каждое помечено.
 */
public final class TimeStopBlink {

    private TimeStopBlink() {}

    /** getMaxDistance: потолок дистанции, блоков. */
    public static final double MAX_DISTANCE = 192.0;

    /** getDistancePerTick: множитель к атрибуту скорости. */
    public static final double DISTANCE_PER_TICK_FACTOR = 2.1585;

    /** TrNoMotionLerpPacket(entityId, 3): на сколько тиков у зрителей гасится интерполяция. */
    public static final int NO_LERP_TICKS = 3;

    /**
     * Вариант The World: к цели-сущности встаём за спину, а не перед ней.
     * В ROTP это флаг teleportBehindEntity, у The World он true, у Star
     * Platinum false. Ветка false тоже перенесена — на случай, если
     * понадобится.
     */
    public static final boolean TELEPORT_BEHIND_ENTITY = true;

    /** Радиус, в котором мобы теряют пользователя из виду (inflate(8)). */
    private static final double MOB_FORGET_RADIUS = 8.0;

    /** Результат расчёта: куда, к кому лицом, сколько тиков это «стоило». */
    public record Plan(Vec3 pos, @Nullable Entity faceTarget, double distance, int impliedTicks) {}

    /**
     * checkSpecificConditions: внутри остановленного времени мгновенная
     * остановка запрещена. У владельца своей зоны это означает, что шифт с
     * кнопкой — снятие, а не рывок; решает это вызывающий код, как в ROTP
     * решает TimeResume#getVisibleAction.
     */
    public static boolean allowedAt(ServerPlayer user) {
        return !TimeStopManager.isStoppedAt(user.level(), user.blockPosition());
    }

    /** getDistancePerTick. */
    public static double distancePerTick(LivingEntity entity) {
        return entity.getAttributeValue(Attributes.MOVEMENT_SPEED) * DISTANCE_PER_TICK_FACTOR;
    }

    /** getMaxDistance. */
    public static double maxDistance(double speed, int maxTicks) {
        return Math.min(speed * maxTicks, MAX_DISTANCE);
    }

    /**
     * Сначала то, что perform делает до телепортации: цель, точка,
     * подразумеваемые тики. Отдельным шагом, чтобы пульт успел проверить
     * заряд до того, как что-либо произошло.
     *
     * @param maxTicks getMaxImpliedTicks — у Metroman бесконечность, у пульта
     *                 столько, на сколько хватает заряда
     */
    public static Plan plan(ServerPlayer user, BlinkTarget clientTarget, int maxTicks) {
        double speed = distancePerTick(user);
        double distance = maxDistance(speed, maxTicks);

        BlinkTarget target = sanitize(user, clientTarget);
        Vec3 blinkPos = null;
        Entity targetEntity = null;

        // calcBlinkPos, ветка EMPTY: прицел клиента ничего не задел — ведём луч
        // сами, на полную дистанцию.
        HitResult ray = null;
        if (target.type() == BlinkTarget.Type.EMPTY) {
            ray = rayTrace(user, distance);
            if (ray.getType() == HitResult.Type.MISS) {
                blinkPos = ray.getLocation();
            }
            target = BlinkTarget.fromHitResult(ray);
        }

        switch (target.type()) {
            case ENTITY -> {
                targetEntity = ray instanceof EntityHitResult ehr ? ehr.getEntity()
                        : target.resolveEntity(user.level());
                if (targetEntity == null) {
                    // Цель исчезла между кадром клиента и тиком сервера.
                    return plan(user, BlinkTarget.EMPTY, maxTicks);
                }
                blinkPos = entityTargetTeleportPos(user, targetEntity);
            }
            case BLOCK -> {
                BlockPos targeted = target.blockPos();
                blinkPos = Vec3.atBottomCenterOf(user.level().isEmptyBlock(targeted.above())
                        ? targeted.above() : targeted.relative(target.face()));
            }
            default -> {
                Vec3 pos = blinkPos;
                BlockPos blockPos = BlockPos.containing(pos);
                // В 1.16.5 низ мира — 0, здесь — getMinBuildHeight: иначе в
                // пещере ниже нуля точка падала бы на высоту игрока.
                int minY = user.level().getMinBuildHeight();
                while (user.level().isEmptyBlock(blockPos.below()) && blockPos.getY() > minY) {
                    blockPos = blockPos.below();
                }
                blinkPos = new Vec3(pos.x, blockPos.getY() > minY ? blockPos.getY() : user.position().y, pos.z);
            }
        }

        double actualDistance = user.position().subtract(blinkPos).length();
        int implied = (int) Math.max(0, Math.min((long) Math.ceil(actualDistance / speed), maxTicks));
        return new Plan(blinkPos, targetEntity, actualDistance, implied);
    }

    /**
     * perform — всё, что видят окружающие. Порядок тот же, что у ROTP: звук
     * со старого места, поворот к цели, мобы теряют из виду, пропуск тиков,
     * телепортация.
     */
    public static void perform(ServerPlayer user, Plan plan) {
        ServerLevel level = user.serverLevel();
        Vec3 blinkPos = plan.pos();

        playSound(level, user);

        float yRot = user.getYRot();
        if (plan.faceTarget() != null) {
            Vec3 toTarget = plan.faceTarget().position().subtract(blinkPos);
            // MathUtil.yRotDegFromVec: -atan2(x, z) в градусах.
            yRot = (float) Math.toDegrees(-Math.atan2(toTarget.x, toTarget.z));
            user.setYRot(yRot);
            user.yRotO = yRot;
        }

        List<Mob> mobs = level.getEntitiesOfClass(Mob.class,
                user.getBoundingBox().inflate(MOB_FORGET_RADIUS),
                mob -> mob.getTarget() == user
                        && mob.getLookAngle().dot(mob.getEyePosition(1).subtract(blinkPos)) >= 0);
        for (Mob mob : mobs) loseTarget(mob, user);

        skipTicks(user, plan.impliedTicks());

        user.teleportTo(level, blinkPos.x, blinkPos.y, blinkPos.z, yRot, user.getXRot());
    }

    // ── вспомогательное, всё из ROTP ────────────────────────────────────────

    /**
     * Цель от клиента проверяется на правдоподобие: блок или сущность должны
     * быть в пределах ванильной дальности, с запасом. ROTP этого не делает —
     * там клиенту верят. Здесь поведение честного клиента то же самое, а
     * подделанная цель в километре просто превращается в EMPTY и считается
     * лучом сервера.
     */
    private static BlinkTarget sanitize(ServerPlayer user, BlinkTarget t) {
        Vec3 eye = user.getEyePosition(1.0F);
        double slack = 3.0;
        switch (t.type()) {
            case ENTITY -> {
                Entity e = t.resolveEntity(user.level());
                double r = user.getAttributeValue(Attributes.ENTITY_INTERACTION_RANGE) + slack;
                if (e == null || e == user || !e.isAlive()
                        || e.getBoundingBox().distanceToSqr(eye) > r * r) {
                    return BlinkTarget.EMPTY;
                }
            }
            case BLOCK -> {
                double r = user.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE) + slack;
                if (Vec3.atCenterOf(t.blockPos()).distanceToSqr(eye) > r * r) {
                    return BlinkTarget.EMPTY;
                }
            }
            default -> {}
        }
        return t;
    }

    /**
     * getEntityTargetTeleportPos. В варианте The World — за спину, на
     * расстоянии суммы ширин: берётся поворот ТЕЛА цели (yRot), не головы.
     * В варианте Star Platinum — перед целью по линии взгляда, а если цель
     * уже ближе этой суммы, на месте.
     *
     * Проверки на стены нет — её нет и в ROTP: встать за спину можно и
     * внутрь блока.
     */
    private static Vec3 entityTargetTeleportPos(Entity user, Entity target) {
        double distance = target.getBbWidth() + user.getBbWidth();
        if (TELEPORT_BEHIND_ENTITY) {
            return target.position().subtract(
                    Vec3.directionFromRotation(0, target.getYRot()).scale(distance));
        }
        return user.distanceToSqr(target) > distance * distance
                ? target.position().subtract(user.getLookAngle().scale(distance))
                : user.position();
    }

    /**
     * JojoModUtil#rayTrace → rayTraceMultipleEntities, фильтр
     * {@code entity instanceof LivingEntity}.
     *
     * Особенность оригинала сохранена сознательно: сущности проверяются
     * ПЕРВЫМИ и без оглядки на блоки. Если на линии взгляда в пределах
     * дистанции есть живая сущность, луч вернёт её, даже если между вами
     * стена. Блоки считаются, только когда сущностей на луче нет. Именно
     * поэтому в ROTP можно «сквозь стену» встать за спину тому, кто за ней.
     */
    private static HitResult rayTrace(Entity user, double distance) {
        Level level = user.level();
        Vec3 start = user.getEyePosition(1.0F);
        Vec3 rtVec = user.getViewVector(1.0F).normalize().scale(distance);
        Vec3 end = start.add(rtVec);
        AABB area = user.getBoundingBox().expandTowards(rtVec).inflate(1.0);
        double minDistanceSqr = distance * distance;

        EntityHitResult best = null;
        double bestDistanceSqr = Double.MAX_VALUE;
        for (Entity candidate : level.getEntities(user, area,
                e -> !e.isSpectator() && e.isPickable() && e instanceof LivingEntity)) {
            AABB box = candidate.getBoundingBox().inflate(candidate.getPickRadius());
            Optional<Vec3> clip = box.clip(start, end);
            double d;
            Vec3 at;
            if (box.contains(start)) {
                d = 0.0;
                at = clip.orElse(start);
            } else if (clip.isPresent()) {
                at = clip.get();
                d = start.distanceToSqr(at);
                if (!(d < minDistanceSqr || minDistanceSqr == 0.0)) continue;
                if (candidate.getRootVehicle() == user.getRootVehicle() && !candidate.canRiderInteract()) {
                    if (minDistanceSqr != 0.0) continue;
                    d = 0.0;
                }
            } else {
                continue;
            }
            if (d < bestDistanceSqr) {
                bestDistanceSqr = d;
                best = new EntityHitResult(candidate, at);
            }
        }
        if (best != null) return best;
        return level.clip(new ClipContext(start, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, user));
    }

    /**
     * MCUtil#loseTarget: сбросить цель и остановить работающие цели выбора
     * цели — иначе на следующем же тике NearestAttackableTargetGoal нашёл бы
     * пользователя снова.
     */
    private static void loseTarget(Mob mob, LivingEntity target) {
        if (mob.getTarget() != target) return;
        mob.setTarget(null);
        for (WrappedGoal goal : mob.targetSelector.getAvailableGoals()) {
            if (goal.isRunning()) goal.stop();
        }
    }

    /**
     * skipTicks: пользователь «прожил» подразумеваемые тики — tickCount
     * сдвигается, а всем, кто на него смотрит, уходит пакет, гасящий
     * интерполяцию на три тика. Без него зрители видели бы, как он
     * проскальзывает до точки, вместо мгновенного появления.
     */
    private static void skipTicks(ServerPlayer user, int ticks) {
        try {
            PacketDistributor.sendToPlayersTrackingEntity(user,
                    new TimeStopNoLerpPacket(user.getId(), NO_LERP_TICKS),
                    new CustomPacketPayload[0]);
        } catch (Throwable ignored) {}
        user.tickCount += ticks;
    }

    /**
     * playSound: громкость 5, категория AMBIENT, слышно на 16·5 = 80 блоков —
     * и только тем, кто «видит» в остановленном времени
     * (TimeStopHandler::canPlayerSeeInStoppedTime). Остальные ничего не
     * слышат: для них время никто не останавливал.
     *
     * Сам пользователь тоже слышит: в ROTP звук ему играет клиентская половина
     * perform, у нас её нет, поэтому пакет идёт и ему.
     */
    private static void playSound(ServerLevel level, ServerPlayer user) {
        final float volume = 5.0F;
        final double range = 16.0 * volume;
        double x = user.getX(), y = user.getY(), z = user.getZ();
        long seed = level.getRandom().nextLong();
        for (ServerPlayer p : level.players()) {
            if (p.distanceToSqr(x, y, z) > range * range) continue;
            if (p != user && !canSeeInStoppedTime(p)) continue;
            p.connection.send(new ClientboundSoundPacket(TimeStopBlinkSounds.BLINK,
                    SoundSource.AMBIENT, x, y, z, volume, 1.0F, seed));
        }
    }

    /**
     * canPlayerSeeInStoppedTime для нашей сборки: креатив/наблюдатель или
     * любое правило иммунитета (Metroman, пульт, модуль). Пункт ROTP «хост
     * одиночной игры видит всегда» не перенесён — у нас хост в остановке
     * замирает, как все, и видеть без этого было бы непоследовательно.
     */
    public static boolean canSeeInStoppedTime(ServerPlayer p) {
        if (p.isCreative() || p.isSpectator()) return true;
        return TimeStopExemptions.grantedTierRank(p) != Integer.MIN_VALUE;
    }
}
