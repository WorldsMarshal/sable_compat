package com.invfix.timestop.blink;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Звук мгновенной остановки. Файл — the_world_time_stop_blink.ogg из ROTP
 * 1.16.5 (ModSounds.THE_WORLD_TIME_STOP_BLINK), без изменений: вариант
 * The World, потому что и сама телепортация перенесена в варианте The World
 * (за спину цели).
 */
public final class TimeStopBlinkSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, "sable_compat");

    public static final DeferredHolder<SoundEvent, SoundEvent> BLINK =
            SOUNDS.register("time_stop_blink", () -> SoundEvent.createVariableRangeEvent(
                    ResourceLocation.fromNamespaceAndPath("sable_compat", "time_stop_blink")));

    private TimeStopBlinkSounds() {}
}
