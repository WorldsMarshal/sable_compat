package com.invfix.timestop.blink;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import org.jetbrains.annotations.Nullable;

/**
 * Порт ActionTarget из ROTP 1.16.5 — ровно та часть, что нужна
 * мгновенной остановке: пусто / блок с гранью / сущность.
 *
 * Как и в ROTP, цель выбирает КЛИЕНТ по своему прицелу (mc.hitResult, то есть
 * ванильная дальность взаимодействия), а сервер получает её в пакете. Если
 * прицел ничего не задел, приходит EMPTY, и тогда сервер сам ведёт луч на
 * полную дистанцию — ветка EMPTY в TimeStopInstant#calcBlinkPos.
 */
public record BlinkTarget(Type type, @Nullable BlockPos blockPos, @Nullable Direction face, int entityId) {

    public enum Type { EMPTY, BLOCK, ENTITY }

    public static final BlinkTarget EMPTY = new BlinkTarget(Type.EMPTY, null, null, -1);

    public static BlinkTarget block(BlockPos pos, Direction face) {
        return new BlinkTarget(Type.BLOCK, pos, face, -1);
    }

    public static BlinkTarget entity(Entity e) {
        return e == null ? EMPTY : new BlinkTarget(Type.ENTITY, null, null, e.getId());
    }

    /** ActionTarget#fromRayTraceResult. */
    public static BlinkTarget fromHitResult(@Nullable HitResult result) {
        if (result == null) return EMPTY;
        return switch (result.getType()) {
            case BLOCK -> {
                BlockHitResult b = (BlockHitResult) result;
                yield block(b.getBlockPos(), b.getDirection());
            }
            case ENTITY -> entity(((EntityHitResult) result).getEntity());
            default -> EMPTY;
        };
    }

    public @Nullable Entity resolveEntity(Level level) {
        return type == Type.ENTITY ? level.getEntity(entityId) : null;
    }

    public void write(FriendlyByteBuf buf) {
        buf.writeEnum(type);
        switch (type) {
            case ENTITY -> buf.writeVarInt(entityId);
            case BLOCK -> { buf.writeBlockPos(blockPos); buf.writeEnum(face); }
            default -> {}
        }
    }

    public static BlinkTarget read(FriendlyByteBuf buf) {
        Type type = buf.readEnum(Type.class);
        return switch (type) {
            case ENTITY -> new BlinkTarget(Type.ENTITY, null, null, buf.readVarInt());
            case BLOCK -> {
                BlockPos pos = buf.readBlockPos();
                yield new BlinkTarget(Type.BLOCK, pos, buf.readEnum(Direction.class), -1);
            }
            default -> EMPTY;
        };
    }
}
