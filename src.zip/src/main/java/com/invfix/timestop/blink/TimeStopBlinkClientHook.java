package com.invfix.timestop.blink;

import net.minecraft.world.InteractionHand;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.loading.FMLEnvironment;

/**
 * Прослойка для общего кода (предмет пульта), чтобы попросить клиента
 * отправить мгновенную остановку, не ссылаясь на клиентские классы напрямую.
 * Тот же приём, что у PortalGunClientHook.
 */
public final class TimeStopBlinkClientHook {

    private TimeStopBlinkClientHook() {}

    public static void requestDeviceBlink(InteractionHand hand) {
        if (FMLEnvironment.dist != Dist.CLIENT) return;
        com.invfix.timestop.blink.client.TimeStopBlinkClient.sendBlink(
                TimeStopBlinkPacket.Source.DEVICE, hand);
    }

    public static void requestStoneBlink(InteractionHand hand) {
        if (FMLEnvironment.dist != Dist.CLIENT) return;
        com.invfix.timestop.blink.client.TimeStopBlinkClient.sendBlink(
                TimeStopBlinkPacket.Source.STONE, hand);
    }
}
