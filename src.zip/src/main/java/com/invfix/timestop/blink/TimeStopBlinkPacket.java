package com.invfix.timestop.blink;

import com.invfix.rick.timedevice.TimeDeviceItem;
import com.invfix.timestop.TimeStopHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Клиент → сервер: «шифт + мгновенная остановка», с целью из прицела.
 *
 * Так же, как в ROTP: цель выбирает клиент (ClickActionKeyPacket несёт
 * ActionTarget), выполняет сервер. Источник — способность Metroman или пульт
 * в указанной руке; сервер сам проверяет, что игрок имеет право на то и на
 * другое, клиенту здесь не верят ни в чём, кроме цели.
 */
public record TimeStopBlinkPacket(Source source, InteractionHand hand, BlinkTarget target)
        implements CustomPacketPayload {

    /** Новые источники — только в конец: в пакете пишется порядковый номер. */
    public enum Source { ABILITY, DEVICE, STONE }

    public static final Type<TimeStopBlinkPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "timestop_blink"));

    public static final StreamCodec<FriendlyByteBuf, TimeStopBlinkPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, msg) -> {
                        buf.writeEnum(msg.source());
                        buf.writeEnum(msg.hand());
                        msg.target().write(buf);
                    },
                    buf -> new TimeStopBlinkPacket(buf.readEnum(Source.class),
                            buf.readEnum(InteractionHand.class), BlinkTarget.read(buf)));

    @Override
    public Type<TimeStopBlinkPacket> type() { return TYPE; }

    public static void handleServer(TimeStopBlinkPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer player)) return;
            try {
                switch (pkt.source()) {
                    case ABILITY -> TimeStopHandler.blink(player, pkt.target());
                    case DEVICE -> TimeDeviceItem.blink(player, pkt.hand(), pkt.target());
                    case STONE -> com.invfix.infinity.TimeStoneItem.blink(player, pkt.hand(), pkt.target());
                }
            } catch (Throwable ignored) {}
        });
    }
}
