package com.invfix.timestop.blink;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Сервер → клиент: на столько-то тиков не интерполировать движение сущности.
 * Порт TrNoMotionLerpPacket из ROTP 1.16.5; клиентская половина — в
 * {@link com.invfix.timestop.blink.client.TimeStopBlinkClient}.
 */
public record TimeStopNoLerpPacket(int entityId, int ticks) implements CustomPacketPayload {

    public static final Type<TimeStopNoLerpPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "timestop_no_lerp"));

    public static final StreamCodec<FriendlyByteBuf, TimeStopNoLerpPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, msg) -> { buf.writeVarInt(msg.entityId()); buf.writeVarInt(msg.ticks()); },
                    buf -> new TimeStopNoLerpPacket(buf.readVarInt(), buf.readVarInt()));

    @Override
    public Type<TimeStopNoLerpPacket> type() { return TYPE; }
}
