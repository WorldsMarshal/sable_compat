package com.invfix.timestop.blink.client;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.mixin.timestop.TsLivingEntityLerpAccessor;
import com.invfix.rick.timedevice.EntropyModuleItem;
import com.invfix.rick.timedevice.TimeDeviceItem;
import com.invfix.timestop.TimeStopClientState;
import com.invfix.timestop.TimeStopExemptions;
import com.invfix.timestop.TimeStopHandler;
import com.invfix.timestop.blink.BlinkTarget;
import com.invfix.timestop.blink.TimeStopBlinkPacket;
import com.invfix.timestop.blink.TimeStopNoLerpPacket;
import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Клиентская половина мгновенной остановки.
 *
 * Три задачи, все из ROTP:
 *  1. поймать «шифт + кнопка способности» и отправить серверу цель из
 *     прицела — ClickActionKeyPacket с ActionTarget;
 *  2. отправить то же из пульта (его use() зовёт сюда через хук);
 *  3. погасить интерполяцию у того, кто мгновенно переместился, чтобы он
 *     появился в точке, а не проехал до неё — TrNoMotionLerpPacket и
 *     LivingUtilCap#tickNoLerp.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class TimeStopBlinkClient {

    private TimeStopBlinkClient() {}

    /** Состояние клавиш способностей на прошлом тике — для фронта нажатия. */
    private static final boolean[] WAS_DOWN = new boolean[5];

    /** entityId -> сколько тиков ещё гасить интерполяцию. */
    private static final Int2IntOpenHashMap NO_LERP = new Int2IntOpenHashMap();

    // ── отправка ─────────────────────────────────────────────────────────────

    /**
     * Цель — ровно то, что сейчас под прицелом (mc.hitResult), как в ROTP:
     * без призванного стенда там берётся ванильный hitResult. Ничего под
     * прицелом в пределах ванильной дальности — уходит EMPTY, и сервер ведёт
     * луч на полную дистанцию сам.
     */
    public static void sendBlink(TimeStopBlinkPacket.Source source, InteractionHand hand) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null) return;
        // Своя зона стоит — шифт означает снятие, его сделает сервер сам.
        // Без этой проверки рывок мог бы проскочить в тот же тик, если пакет
        // снятия обгонит пакет рывка.
        if (TimeStopClientState.ownsZone(player.getId())) return;
        BlinkTarget target = BlinkTarget.fromHitResult(mc.hitResult);
        PacketDistributor.sendToServer(new TimeStopBlinkPacket(source, hand, target),
                new CustomPacketPayload[0]);
    }

    /**
     * Фронт нажатия кнопки, в слоте которой лежит остановка времени, при
     * зажатом шифте. Слот и ряд читаются так же, как на сервере
     * (AbilityCallProcedureMixin#pressedAbility). Клавиши invincible_inc
     * опрашиваются через isDown, а не consumeClick: чужие клики не съедаем.
     */
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        KeyMapping[] keys = {
                InvincibleIncModKeyMappings.ABILITY_1, InvincibleIncModKeyMappings.ABILITY_2,
                InvincibleIncModKeyMappings.ABILITY_3, InvincibleIncModKeyMappings.ABILITY_4,
                InvincibleIncModKeyMappings.ABILITY_5 };
        boolean[] down = new boolean[5];
        for (int i = 0; i < 5; i++) down[i] = keys[i].isDown();

        try {
            if (player == null || mc.screen != null || !player.isShiftKeyDown()) return;
            InvincibleIncModVariables.PlayerVariables v =
                    player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (!AltrumiteRace.isAltrumite(v.Race) || v.Lvl < TimeStopHandler.lvlRequired) return;

            boolean row1 = v.AbilityRow == 1.0;
            String[] slots = row1
                    ? new String[]{ v.AbilitySlot1, v.AbilitySlot2, v.AbilitySlot3, v.AbilitySlot4, v.AbilitySlot5 }
                    : new String[]{ v.AbilitySlot1_row2, v.AbilitySlot2_row2, v.AbilitySlot3_row2,
                                    v.AbilitySlot4_row2, v.AbilitySlot5_row2 };
            for (int i = 0; i < 5; i++) {
                if (down[i] && !WAS_DOWN[i] && TimeStopHandler.ABILITY.equals(slots[i])) {
                    sendBlink(TimeStopBlinkPacket.Source.ABILITY, InteractionHand.MAIN_HAND);
                    break;
                }
            }
        } catch (Throwable ignored) {
        } finally {
            System.arraycopy(down, 0, WAS_DOWN, 0, 5);
        }
    }

    // ── интерполяция ────────────────────────────────────────────────────────

    /**
     * TrNoMotionLerpPacket.Handler#handle: применяется только если этот
     * клиент НЕ видит в остановленном времени. Тот, кто видит, и должен
     * видеть, как пользователь идёт до точки.
     */
    public static void handleNoLerp(TimeStopNoLerpPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            LocalPlayer player = Minecraft.getInstance().player;
            if (player == null || canSeeInStoppedTime(player)) return;
            NO_LERP.put(pkt.entityId(), pkt.ticks());
        });
    }

    /**
     * LivingUtilCap#tickNoLerp: пока тики не кончились и интерполяции
     * осталось больше одного шага — сжать её до одного. До aiStep, иначе шаг
     * уже будет сделан по старому числу.
     */
    @SubscribeEvent
    public static void onEntityTickPre(EntityTickEvent.Pre event) {
        if (NO_LERP.isEmpty()) return;
        if (!(event.getEntity() instanceof LivingEntity living) || !living.level().isClientSide()) return;
        int id = living.getId();
        int left = NO_LERP.get(id);
        if (left <= 0) return;
        TsLivingEntityLerpAccessor acc = (TsLivingEntityLerpAccessor) living;
        if (acc.invfix$getLerpSteps() > 1) {
            acc.invfix$setLerpSteps(1);
            if (--left <= 0) NO_LERP.remove(id);
            else NO_LERP.put(id, left);
        }
    }

    /**
     * Клиентское зеркало TimeStopBlink#canSeeInStoppedTime: креатив,
     * наблюдатель или любое правило иммунитета. Всё нужное клиенту видно:
     * переменные игрока синхронизируются, инвентарь свой.
     */
    private static boolean canSeeInStoppedTime(Player player) {
        if (player.isCreative() || player.isSpectator()) return true;
        try {
            InvincibleIncModVariables.PlayerVariables v =
                    player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (AltrumiteRace.isAltrumite(v.Race) && v.Lvl >= TimeStopHandler.lvlRequired
                    && TimeStopExemptions.hasAbilityInSlots(v, TimeStopHandler.ABILITY)) {
                return true;
            }
        } catch (Throwable ignored) {}
        // Те же правила, что на сервере: суммарный заряд по инвентарю.
        return TimeDeviceItem.totalEnergy(player) >= TimeDeviceItem.DRAIN_PER_TICK
                || EntropyModuleItem.totalEnergy(player) >= EntropyModuleItem.DRAIN_PER_TICK
                || com.invfix.infinity.TimeStoneItem.totalCharge(player) >= 1;
    }
}
