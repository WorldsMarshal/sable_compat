package com.invfix.timestop;

import com.invfix.timestop.compat.SableTimeStop;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Единственная точка входа для миксинов и чужого кода. Держит две вещи,
 * которые нельзя путать:
 *
 *  - «мировая» проверка (сущности, вагоны, произвольные точки) — берёт
 *    координату как есть;
 *  - «чанковая» проверка (тики блоков, блок-сущности, компьютеры) — сначала
 *    спрашивает Sable, не принадлежит ли чанк делянке саблевела, и если да,
 *    судит по мировому положению судна, а не по координатам делянки.
 */
public final class TimeStopApi {

    private TimeStopApi() {}

    /**
     * Все методы этого класса зовутся из миксинов в ванильный и чужой код:
     * тики блоков, тик компьютера, тик поезда. Исключение оттуда — краш чужого
     * мода по нашей вине, причём на горячем пути, то есть каждый тик. Поэтому
     * единственная точка входа не бросает наружу ничего: при сбое пишем в лог
     * (один раз) и отвечаем «не остановлено», то есть мир просто продолжает
     * идти. Ронять сервер из-за тайм-стопа нельзя.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger("invfix/timestop");
    private static boolean loggedFailure = false;

    private static boolean fail(Throwable t) {
        if (!loggedFailure) {
            loggedFailure = true;
            LOGGER.error("[timestop] сбой в запросе состояния — считаем время идущим", t);
        }
        return false;
    }

    /** Есть ли в измерении хоть одна активная зона. Самая дешёвая проверка. */
    public static boolean hasAnyTimeStop(Level level) {
        try {
            if (level == null) return false;
            if (level.isClientSide()) return TimeStopClientState.hasAny();
            return TimeStopManager.hasAny(level);
        } catch (Throwable t) { return fail(t); }
    }

    /** Мировая точка внутри зоны. */
    public static boolean isTimeStoppedAt(Level level, BlockPos worldPos) {
        try {
            if (level == null || worldPos == null) return false;
            if (level.isClientSide()) return TimeStopClientState.isInside(worldPos);
            return TimeStopManager.isStoppedAt(level, worldPos);
        } catch (Throwable t) { return fail(t); }
    }

    /** Мировая точка внутри зоны (координаты с плавающей точкой). */
    public static boolean isTimeStoppedAt(Level level, double x, double z) {
        try {
            if (level == null) return false;
            if (!hasAnyTimeStop(level)) return false;
            return isTimeStoppedAt(level, BlockPos.containing(x, 0.0, z));
        } catch (Throwable t) { return fail(t); }
    }

    /**
     * Пересекает ли мировой габарит какую-либо зону. Нужна для объектов, у
     * которых «положение» — это коробка, а не точка: судов Sable в первую
     * очередь, чтобы стометровый дирижабль замирал целиком, а не по центру.
     */
    public static boolean isWorldBoxStopped(Level level, double minX, double minZ,
                                            double maxX, double maxZ) {
        try {
            if (level == null) return false;
            if (level.isClientSide()) {
                return TimeStopClientState.intersectsWorldBox(minX, minZ, maxX, maxZ);
            }
            return TimeStopManager.isWorldBoxStopped(level, minX, minZ, maxX, maxZ);
        } catch (Throwable t) { return fail(t); }
    }

    /**
     * Чанк внутри зоны, с поправкой на делянки Sable.
     * @param packedChunkPos значение ChunkPos#toLong
     */
    public static boolean isTimeStoppedAtChunk(Level level, long packedChunkPos) {
        try {
            if (level == null) return false;
            if (!hasAnyTimeStop(level)) return false;

            Boolean plotVerdict = SableTimeStop.isPlotChunkStopped(level, packedChunkPos);
            if (plotVerdict != null) return plotVerdict;

            if (level.isClientSide()) {
                ChunkPos chunk = new ChunkPos(packedChunkPos);
                return TimeStopClientState.isInsideChunk(chunk.x, chunk.z);
            }
            return TimeStopManager.isStoppedAtChunk(level, packedChunkPos);
        } catch (Throwable t) { return fail(t); }
    }

    /**
     * Позиция блок-сущности/компьютера внутри зоны, с поправкой на делянки.
     * Отличается от {@link #isTimeStoppedAt} тем, что для блоков на судне
     * переводит координаты делянки в мировые.
     */
    public static boolean isTimeStoppedAtBlock(Level level, BlockPos pos) {
        try {
            if (level == null || pos == null) return false;
            if (!hasAnyTimeStop(level)) return false;
            return isTimeStoppedAtChunk(level, new ChunkPos(pos).toLong());
        } catch (Throwable t) { return fail(t); }
    }

    // ── Сущности ───────────────────────────────────────────────────────────────

    /** Сущность внутри зоны (не важно, заморожена ли). */
    public static boolean isInsideTimeStop(Entity entity) {
        try { return TimeStopManager.isInside(entity); }
        catch (Throwable t) { return fail(t); }
    }

    /** Сущность заморожена: внутри зоны и не имеет права действовать. */
    public static boolean isFrozen(Entity entity) {
        try { return TimeStopManager.isFrozen(entity); }
        catch (Throwable t) { return fail(t); }
    }

    /** Сущность может действовать в остановленном времени (владелец, креатив, спектатор). */
    public static boolean canActInStoppedTime(Entity entity) {
        try { return TimeStopManager.canAct(entity); }
        catch (Throwable t) { return !fail(t); }
    }
}
