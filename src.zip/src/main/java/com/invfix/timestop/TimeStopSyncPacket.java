package com.invfix.timestop;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Сервер → клиент: полный список активных зон измерения.
 *
 * Помимо самих зон несёт id тех, кого правила освободили от заморозки
 * ({@link TimeStopExemptions}) — клиенту это нужно, чтобы не рисовать таких
 * игроков замороженными.
 *
 * Шлётся при изменении набора зон или набора исключений и при входе, респавне и смене измерения,
 * не каждый тик: клиенту нужно знать «где стоит время», а не сколько тиков
 * осталось. Обратный отсчёт клиенту не нужен — конец остановки приходит
 * отдельным пакетом с пустым списком.
 */
public record TimeStopSyncPacket(List<Entry> entries, int[] exempt,
                                 int[] exemptTiers) implements CustomPacketPayload {

    public record Entry(int id, int chunkX, int chunkZ, int chunkRange, int ownerEntityId,
                        int tierRank) {}

    public static final Type<TimeStopSyncPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "timestop_sync"));

    public static final StreamCodec<FriendlyByteBuf, TimeStopSyncPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, msg) -> {
                        buf.writeVarInt(msg.entries().size());
                        for (Entry e : msg.entries()) {
                            buf.writeVarInt(e.id());
                            buf.writeVarInt(e.chunkX());
                            buf.writeVarInt(e.chunkZ());
                            buf.writeVarInt(e.chunkRange());
                            buf.writeVarInt(e.ownerEntityId());
                            buf.writeVarInt(e.tierRank());
                        }
                        buf.writeVarInt(msg.exempt().length);
                        for (int id : msg.exempt()) buf.writeVarInt(id);
                        for (int rank : msg.exemptTiers()) buf.writeVarInt(rank);
                    },
                    buf -> {
                        int count = buf.readVarInt();
                        List<Entry> list = new ArrayList<>(count);
                        for (int i = 0; i < count; i++) {
                            list.add(new Entry(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(),
                                    buf.readVarInt(), buf.readVarInt(), buf.readVarInt()));
                        }
                        int exemptCount = buf.readVarInt();
                        int[] exempt = new int[exemptCount];
                        for (int i = 0; i < exemptCount; i++) exempt[i] = buf.readVarInt();
                        int[] exemptTiers = new int[exemptCount];
                        for (int i = 0; i < exemptCount; i++) exemptTiers[i] = buf.readVarInt();
                        return new TimeStopSyncPacket(list, exempt, exemptTiers);
                    });

    @Override
    public Type<TimeStopSyncPacket> type() { return TYPE; }

    public static TimeStopSyncPacket of(TimeStopLevelState state) {
        List<Entry> list = new ArrayList<>(state.instances.size());
        for (TimeStopInstance inst : state.instances) {
            list.add(new Entry(inst.id, inst.chunkX, inst.chunkZ, inst.chunkRange,
                    inst.ownerEntityId, inst.tierRank));
        }
        return new TimeStopSyncPacket(list, state.exemptPlayers.clone(), state.exemptTiers.clone());
    }

    public static TimeStopSyncPacket empty() {
        return new TimeStopSyncPacket(List.of(), new int[0], new int[0]);
    }

    /** Клиентская половина. Вызывается только на клиенте (см. ClientPacketHandlers). */
    public static void handleClient(TimeStopSyncPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> TimeStopClientState.accept(pkt.entries(), pkt.exempt(), pkt.exemptTiers()));
    }
}
