package com.invfix.timestop;

import com.mojang.datafixers.util.Pair;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.redstone.CollectingNeighborUpdater;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Состояние остановки времени для одного ServerLevel.
 *
 * Намеренно НЕ сохраняется в NBT: остановка живёт секунды, а корректное
 * восстановление из сейва требует отложенного применения (в ROTP это открытый
 * FIXME — при загрузке эффекта сущности ещё не загружены). Перезапуск сервера
 * во время остановки просто возвращает мир в движение.
 */
public final class TimeStopLevelState {

    /** Активные зоны, в порядке добавления. Их единицы, список дешевле карты. */
    public final List<TimeStopInstance> instances = new ArrayList<>(2);

    /**
     * Наш счётчик тиков уровня. Не зависит от gameTime и от того, морозим ли мы
     * что-нибудь; растёт ровно на LevelTickEvent.Post.
     */
    public long tick = 0L;

    /**
     * id игроков, которых правила из {@link TimeStopExemptions} освободили от
     * заморозки. Пересчитывается раз в несколько тиков, чтобы горячий путь
     * обходился одним поиском int, а не чтением переменных игрока.
     */
    public int[] exemptPlayers = new int[0];

    /**
     * Ранг уровня, до которого освобождён игрок с тем же индексом в
     * exemptPlayers. Два параллельных массива, а не карта: записей обычно ноль
     * или одна, и проход по int[] дешевле любой коллекции и не боксит.
     */
    public int[] exemptTiers = new int[0];

    /** Тик последнего пересчёта исключений. */
    public long exemptRefreshedAt = Long.MIN_VALUE;

    /**
     * Памятка на одну сущность: вердикт «заморожена ли», посчитанный в этом
     * тике. Слот ровно один, и этого достаточно — вопрос про одну и ту же
     * сущность задаётся несколько раз подряд, внутри её собственного тика:
     * событие тика, затем Entity#isEffectiveAi (его цели ИИ дёргают по
     * несколько раз), затем для игрока ServerPlayer#doTick. Между разными
     * сущностями слот просто перезаписывается.
     *
     * Так закрывается единственное место, где реализация ROTP 1.21.1 была
     * дешевле: там вердикт лежит синхроданными на самой сущности и читается
     * сколько угодно раз бесплатно. Хранить своё поле на каждой сущности ради
     * этого не стоит — слот даёт тот же эффект при нулевой памяти.
     */
    public int memoEntityId = -1;
    public long memoTick = Long.MIN_VALUE;
    public boolean memoFrozen = false;

    /**
     * Сущности, которым уже отправлена фиксация позиции при заморозке
     * (TimeStopFreezePosPacket). Нужен, чтобы слать её ровно один раз на вход в
     * заморозку, а не каждый тик: состояние «заморожена» нигде не кэшируется,
     * оно вычисляется на месте, так что фронт ловится этим множеством.
     */
    public final java.util.Set<Integer> posPinned = new java.util.HashSet<>();

    /** Сколько отложенных апдейтов накоплено — для потолка из TimeStopConfig. */
    public int delayedCount = 0;

    /** Взведён, когда потолок пробит: до конца остановки апдейты идут как обычно. */
    public boolean delayOverflow = false;

    /**
     * Отложенные соседские блок-апдейты, сгруппированные по чанку, в котором они
     * возникли. Проигрываются, когда над чанком больше нет остановки.
     * Порт CollectingNeighborUpdater-логики из ROTP 1.21.1.
     */
    public final Map<ChunkPos, Collection<Pair<BlockPos, CollectingNeighborUpdater.NeighborUpdates>>>
            delayedBlockUpdates = new HashMap<>();

    public boolean isEmpty() {
        return instances.isEmpty();
    }

    public TimeStopInstance byId(int id) {
        for (int i = 0; i < instances.size(); i++) {
            TimeStopInstance inst = instances.get(i);
            if (inst.id == id) return inst;
        }
        return null;
    }

    public boolean ownedBy(int entityId) {
        for (int i = 0; i < instances.size(); i++) {
            if (instances.get(i).ownerEntityId == entityId) return true;
        }
        return false;
    }

    public void delay(BlockPos pos, CollectingNeighborUpdater.NeighborUpdates updates) {
        delayedBlockUpdates
                .computeIfAbsent(new ChunkPos(pos), ignored -> new ArrayList<>())
                .add(Pair.of(pos.immutable(), updates));
        delayedCount++;
    }
}
