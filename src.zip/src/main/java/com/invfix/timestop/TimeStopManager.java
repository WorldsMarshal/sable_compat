package com.invfix.timestop;

import com.invfix.timestop.compat.SableTimeStop;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.mojang.datafixers.util.Pair;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.redstone.CollectingNeighborUpdater;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityTeleportEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.level.LevelEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Серверное ядро остановки времени. Не зависит ни от одного мода: всё, что
 * знает о Sable/Create/CC, вынесено в com.invfix.timestop.compat и миксины.
 *
 * Отличие от ROTP: там «заморожен/не заморожен» лежит синхронизированными
 * данными на каждой сущности и пересчитывается при изменении набора зон. Здесь
 * состояние не кэшируется вовсе — принадлежность зоне считается на месте
 * (чебышёв по координатам чанка против 1-2 зон). Это убирает и рассинхрон
 * per-entity данных, и необходимость обходить всех сущностей уровня при каждом
 * старте/снятии.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class TimeStopManager {

    private TimeStopManager() {}

    private static final Logger LOGGER = LoggerFactory.getLogger("invfix/timestop");

    private static final Map<ResourceKey<Level>, TimeStopLevelState> STATES = new HashMap<>();
    private static int nextId = 1;

    /**
     * Аварийный рубильник. Взводится, когда наш код дважды падает в тике: лучше
     * выключенная механика, чем исключение на каждую сущность каждый тик —
     * такое кладёт сервер за секунды. Снимается только перезапуском или
     * командой /timestop clear.
     */
    private static volatile boolean disabled = false;
    private static int consecutiveFailures = 0;

    public static boolean isDisabled() { return disabled; }

    /**
     * Суммарное число активных зон по всем измерениям. Нужен только как
     * предохранитель: onEntityTickPre зовётся на каждую сущность каждый тик, а
     * shouldTickBlocksAt — на каждый тикающий чанк, и в сборке с c2me/lithium
     * даже один HashMap.get там лишний. Пока счётчик нулевой, обе проверки
     * выходят на первом же сравнении.
     */
    private static volatile int activeCount = 0;

    static final int[] EMPTY_IDS = new int[0];
    /** «Никакого ранга»: ниже любого зарегистрированного уровня. */
    static final int NO_RANK = Integer.MIN_VALUE;

    public static boolean anyTimeStopAnywhere() {
        return activeCount > 0;
    }

    private static void recountActive() {
        int total = 0;
        for (TimeStopLevelState state : STATES.values()) total += state.instances.size();
        activeCount = total;
    }

    // ── Состояние ──────────────────────────────────────────────────────────────

    public static @Nullable TimeStopLevelState stateOrNull(Level level) {
        if (level == null || level.isClientSide()) return null;
        return STATES.get(level.dimension());
    }

    private static TimeStopLevelState stateOrCreate(ServerLevel level) {
        return STATES.computeIfAbsent(level.dimension(), ignored -> new TimeStopLevelState());
    }

    // ── Публичное управление ───────────────────────────────────────────────────

    /**
     * Запускает остановку с центром в чанке владельца.
     * @return созданная зона, либо null если у владельца уже есть активная.
     */
    public static @Nullable TimeStopInstance start(ServerLevel level, LivingEntity owner,
                                                   int durationTicks, int chunkRange) {
        return start(level, owner, durationTicks, chunkRange, false, TimeStopTier.ABSOLUTE);
    }

    /** Бесконечная зона: держится, пока владелец её не снимет. */
    public static @Nullable TimeStopInstance startEndless(ServerLevel level, LivingEntity owner,
                                                          int chunkRange) {
        return start(level, owner, 0, chunkRange, true, TimeStopTier.ABSOLUTE);
    }

    public static @Nullable TimeStopInstance startEndless(ServerLevel level, LivingEntity owner,
                                                          int chunkRange, TimeStopTier tier) {
        return start(level, owner, 0, chunkRange, true, tier);
    }

    /**
     * Запуск зоны.
     *
     * Уровни независимы друг от друга: остановка Metroman и остановка
     * устройства сосуществуют, ни одна не гасит другую. Конфликт разбирается
     * ТОЛЬКО внутри своего уровня, и только по зонам, которые накрывают точку
     * запуска — то есть по тем, в чьём остановленном времени инициатор сейчас
     * находится:
     *
     *  - {@link TimeStopTier#interruptsSameTier} == true (устройства): чужая
     *    зона того же уровня снимается, запускается новая;
     *  - false (Metroman): поверх такой же остановки не запускается вовсе,
     *    второго поля не будет.
     *
     * Зоны других уровней не смотрятся совсем.
     *
     * @return созданная зона, либо null если запуск отклонён
     */
    public static @Nullable TimeStopInstance start(ServerLevel level, LivingEntity owner,
                                                   int durationTicks, int chunkRange,
                                                   boolean endless, TimeStopTier tier) {
        if (level == null || owner == null || disabled) return null;
        if (tier == null) tier = TimeStopTier.ABSOLUTE;

        // Предохранители: потолок длительности, вменяемый радиус, лимит зон.
        durationTicks = endless
                ? 0
                : Math.max(1, Math.min(durationTicks, TimeStopConfig.maxDurationTicks));
        chunkRange = Math.max(1, Math.min(chunkRange, 64));

        TimeStopLevelState state = stateOrCreate(level);
        if (state.ownedBy(owner.getId())) return null;

        if (!resolveTierConflict(level, state, owner, tier)) return null;

        if (state.instances.size() >= TimeStopConfig.maxInstancesPerLevel) {
            LOGGER.warn("[timestop] отклонён запуск в {}: уже {} активных зон",
                    level.dimension().location(), state.instances.size());
            return null;
        }

        ChunkPos center = owner.chunkPosition();
        TimeStopInstance inst = new TimeStopInstance(
                nextId++, center.x, center.z, chunkRange,
                owner.getId(), durationTicks, durationTicks, endless, tier.rank);
        inst.startedTick = state.tick;
        // Бессрочную зону пульта или камня держит предмет. Он обязан
        // подтверждать это каждый тик, иначе её снимет сторож — см. requiresUpkeep.
        inst.requiresUpkeep = endless && tier.heldByItem;
        inst.lastUpkeepTick = state.tick;
        state.instances.add(inst);
        recountActive();
        refreshExemptions(level, state);

        sync(level, state);
        SableTimeStop.syncFrozenShips(level);
        return inst;
    }

    /**
     * Разбирает конфликт в точке запуска — внутри своего уровня и только там.
     * @return true — запускаться можно (конфликтующие зоны уже сняты)
     */
    private static boolean resolveTierConflict(ServerLevel level, TimeStopLevelState state,
                                               LivingEntity owner, TimeStopTier tier) {
        if (state.instances.isEmpty()) return true;

        BlockPos pos = owner.blockPosition();
        List<TimeStopInstance> toAbsorb = null;
        for (int i = 0; i < state.instances.size(); i++) {
            TimeStopInstance inst = state.instances.get(i);
            // Чужой уровень — не наше дело: слои независимы.
            if (inst.tierRank != tier.rank) continue;
            if (!inst.isInRange(pos)) continue;

            // Metroman поверх Metroman: не происходит ничего.
            if (!tier.interruptsSameTier) return false;

            if (toAbsorb == null) toAbsorb = new ArrayList<>(2);
            toAbsorb.add(inst);
        }

        if (toAbsorb != null) {
            state.instances.removeAll(toAbsorb);
            recountActive();
        }
        return true;
    }

    /**
     * Подтверждение жизни зоны от того, кто её держит.
     *
     * Зовётся каждый тик, пока предмет-держатель на месте и при заряде.
     * Молчание дольше {@link TimeStopConfig#upkeepGraceTicks} — зону снимает
     * сторож в {@link #tickLevel}.
     */
    public static void heartbeat(ServerLevel level, TimeStopInstance inst) {
        TimeStopLevelState state = stateOrNull(level);
        if (state != null && inst != null) inst.lastUpkeepTick = state.tick;
    }

    /** Досрочно снимает зону (возобновление времени по команде владельца). */
    public static void stop(ServerLevel level, TimeStopInstance inst) {
        TimeStopLevelState state = stateOrNull(level);
        if (state == null || inst == null) return;
        if (state.instances.remove(inst)) {
            onSetChanged(level, state);
        }
    }

    /** Снимает все зоны, принадлежащие сущности. Возвращает, было ли что снимать. */
    public static boolean stopOwnedBy(ServerLevel level, int ownerEntityId) {
        TimeStopLevelState state = stateOrNull(level);
        if (state == null) return false;
        boolean removed = state.instances.removeIf(i -> i.ownerEntityId == ownerEntityId);
        if (removed) onSetChanged(level, state);
        return removed;
    }

    public static @Nullable TimeStopInstance ownedBy(ServerLevel level, int ownerEntityId) {
        TimeStopLevelState state = stateOrNull(level);
        if (state == null) return null;
        for (TimeStopInstance inst : state.instances) {
            if (inst.ownerEntityId == ownerEntityId) return inst;
        }
        return null;
    }

    // ── Запросы (сервер) ───────────────────────────────────────────────────────

    public static boolean hasAny(Level level) {
        if (activeCount == 0) return false;
        TimeStopLevelState state = stateOrNull(level);
        return state != null && !state.isEmpty();
    }

    public static List<TimeStopInstance> instances(Level level) {
        TimeStopLevelState state = stateOrNull(level);
        return state == null ? List.of() : state.instances;
    }

    public static boolean isStoppedAt(Level level, BlockPos worldPos) {
        if (activeCount == 0) return false;
        TimeStopLevelState state = stateOrNull(level);
        if (state == null || state.isEmpty()) return false;
        for (int i = 0; i < state.instances.size(); i++) {
            if (state.instances.get(i).isInRange(worldPos)) return true;
        }
        return false;
    }

    /** Пересекает ли мировой габарит (судно, крупный объект) какую-либо зону. */
    public static boolean isWorldBoxStopped(Level level, double minX, double minZ,
                                            double maxX, double maxZ) {
        if (activeCount == 0) return false;
        TimeStopLevelState state = stateOrNull(level);
        if (state == null || state.isEmpty()) return false;
        for (int i = 0; i < state.instances.size(); i++) {
            if (state.instances.get(i).intersects(minX, minZ, maxX, maxZ)) return true;
        }
        return false;
    }

    public static boolean isStoppedAtChunk(Level level, long packedChunkPos) {
        if (activeCount == 0) return false;
        TimeStopLevelState state = stateOrNull(level);
        if (state == null || state.isEmpty()) return false;
        for (int i = 0; i < state.instances.size(); i++) {
            if (state.instances.get(i).isInRangeChunkPacked(packedChunkPos)) return true;
        }
        return false;
    }

    // ── Заморозка сущностей ────────────────────────────────────────────────────

    /**
     * Может ли сущность действовать внутри остановленного времени.
     * Владелец зоны, наблюдатели и креатив — могут.
     */
    /**
     * Может ли сущность действовать в остановленном времени.
     * Ровно отрицание {@link #isFrozen}: кто не заморожен — тот действует.
     */
    public static boolean canAct(Entity entity) {
        return !isFrozen(entity);
    }

    /** Находится ли сущность внутри какой-либо зоны (заморожена или нет). */
    public static boolean isInside(Entity entity) {
        if (entity == null) return false;
        Level level = entity.level();
        if (level.isClientSide()) {
            return TimeStopClientState.isInside(entity.blockPosition());
        }
        return isStoppedAt(level, entity.blockPosition());
    }

    /**
     * Заморожена ли сущность прямо сейчас. Самый горячий метод ветки: зовётся
     * на каждую сущность каждый тик, на обеих сторонах.
     *
     * Состояние измерения читается ОДИН раз и передаётся вниз, список зон
     * обходится ОДИН раз. Раньше здесь было три чтения карты состояний и два
     * прохода по зонам, потому что isFrozen звал isStoppedAt и canAct, а
     * каждый из них заново искал состояние.
     */
    public static boolean isFrozen(Entity entity) {
        if (entity == null) return false;
        Level level = entity.level();

        if (level.isClientSide()) {
            if (!TimeStopClientState.hasAny()) return false;
            if (entity.isSpectator()) return false;
            if (TimeStopConfig.endermenIgnoreTimeStop && entity instanceof EnderMan) return false;
            return TimeStopClientState.isFrozenAt(entity.getId(), entity.blockPosition());
        }

        if (activeCount == 0) return false;
        TimeStopLevelState state = STATES.get(level.dimension());
        if (state == null) return false;

        final int id = entity.getId();
        if (state.memoTick == state.tick && state.memoEntityId == id) {
            return state.memoFrozen;
        }
        boolean frozen = frozenIn(entity, state);
        state.memoTick = state.tick;
        state.memoEntityId = id;
        state.memoFrozen = frozen;
        return frozen;
    }

    /**
     * Решение о заморозке при уже прочитанном состоянии.
     *
     * Порядок проверок — от самых дешёвых к самым дорогим, и всё, что касается
     * только игроков, стоит ПОСЛЕ проверки попадания в зону: мобов эти ветки
     * не касаются вовсе.
     *
     *  1. пустой список зон — выход;
     *  2. наблюдатель — сравнение флага;
     *  3. эндермен — сравнение класса (дань автору ROTP: ходит, но не
     *     телепортируется, телепорт гасится в onEnderTeleport);
     *  4. один проход по зонам: попутно ловим «сущность — владелец зоны» и
     *     считаем попадание в радиус (чебышёв по координатам чанка);
     *  5. не в зоне — выход;
     *  6. только для игроков: креатив, зависший в воздухе без mayfly
     *     (иначе сервер кикнет его за полёт), и множество исключений,
     *     посчитанное заранее в refreshExemptions;
     *  7. транспорт владельца — чтобы лодка с ним не встала под ним же.
     */
    private static boolean frozenIn(Entity entity, TimeStopLevelState state) {
        final int zones = state.instances.size();
        if (zones == 0) return false;

        if (entity.isSpectator()) return false;
        if (TimeStopConfig.endermenIgnoreTimeStop && entity instanceof EnderMan) return false;

        BlockPos pos = entity.blockPosition();
        final int chunkX = SectionPos.blockToSectionCoord(pos.getX());
        final int chunkZ = SectionPos.blockToSectionCoord(pos.getZ());
        final int id = entity.getId();
        Entity vehicle = entity.getVehicle();
        final int vehicleId = vehicle == null ? Integer.MIN_VALUE : vehicle.getId();

        boolean inside = false;
        for (int i = 0; i < zones; i++) {
            TimeStopInstance inst = state.instances.get(i);
            // Владелец любой зоны (и тот, кого везёт владелец) — уже действует.
            if (inst.ownerEntityId == id || inst.ownerEntityId == vehicleId) return false;
            if (!inside && inst.isInRange(chunkX, chunkZ)) inside = true;
        }
        if (!inside) return false;

        if (entity instanceof Player player) {
            if (player.isCreative()) return false;
            if (TimeStopConfig.exemptAirbornePlayersWithoutFlight
                    && !player.onGround() && !player.isPassenger()
                    && !player.getAbilities().mayfly) {
                return false;
            }
            if (isExempt(state, id)) return false;
        }
        return true;
    }

    /**
     * Освобождён ли игрок правилами. Исключений единицы, поэтому линейный
     * проход по int[] дешевле любой коллекции.
     *
     * Ранг правила здесь НЕ смотрится: иммунные равны между собой независимо
     * от уровня остановки, которая их накрыла. Ранги хранятся и синхронятся
     * (state.exemptTiers, TimeStopSyncPacket), но на заморозку не влияют —
     * свяжем, когда будет решено, бьёт ли один уровень другой.
     */
    static boolean isExempt(TimeStopLevelState state, int entityId) {
        final int[] ids = state.exemptPlayers;
        for (int i = 0; i < ids.length; i++) {
            if (ids[i] == entityId) return true;
        }
        return false;
    }

    /**
     * Пересчёт множества исключений. Зовётся раз в
     * TimeStopConfig#exemptRefreshIntervalTicks тиков и сразу при старте зоны.
     * @return true, если множество изменилось и клиентам нужен новый снимок
     */
    private static boolean refreshExemptions(ServerLevel level, TimeStopLevelState state) {
        int[] ids = null;
        int[] ranks = null;
        int count = 0;
        for (ServerPlayer player : level.players()) {
            int rank = TimeStopExemptions.grantedTierRank(player);
            if (rank == NO_RANK) continue;
            if (ids == null) { ids = new int[4]; ranks = new int[4]; }
            if (count == ids.length) {
                ids = java.util.Arrays.copyOf(ids, count * 2);
                ranks = java.util.Arrays.copyOf(ranks, count * 2);
            }
            ids[count] = player.getId();
            ranks[count] = rank;
            count++;
        }
        int[] resultIds = count == 0 ? EMPTY_IDS : java.util.Arrays.copyOf(ids, count);
        int[] resultRanks = count == 0 ? EMPTY_IDS : java.util.Arrays.copyOf(ranks, count);
        state.exemptRefreshedAt = state.tick;
        if (java.util.Arrays.equals(resultIds, state.exemptPlayers)
                && java.util.Arrays.equals(resultRanks, state.exemptTiers)) {
            return false;
        }
        state.exemptPlayers = resultIds;
        state.exemptTiers = resultRanks;
        return true;
    }

    // ── События ────────────────────────────────────────────────────────────────

    /**
     * Отмена тика замороженной сущности, плюс «глаза замороженного».
     *
     * Второе — про то, что видит игрок, пойманный чужой остановкой. Сервер
     * продолжает слать ему всё как обычно: иммунные ходят, стрелы вылетают,
     * блоки ломаются. Чтобы он не видел, как владелец зоны разгуливает вокруг,
     * на ЕГО клиенте не тикает вообще никто.
     *
     * Почему именно так, а не буферизацией пакетов. Придержать пакеты и
     * проиграть их после снятия — значит устроить клиенту шторм рендера на
     * выходе; выборочно их отбрасывать — значит получить фантомные блоки,
     * которых нет на сервере, потому что обновления в MC линейны и сами по
     * себе не переприсылаются. Здесь же клиент получает и применяет всё
     * штатно, не применяется только интерполяция: цель lerpTo копится, но не
     * потребляется, пока тик отменён. Сущность стоит там, где её застали.
     * tickCount тоже откатывается, поэтому не идут и анимации.
     *
     * Что при этом всё равно видно: появление новых сущностей (стрела возникает
     * и зависает) и смена блоков — их клиент применяет сразу, вне тика. Ровно
     * такая же картина была в ROTP 1.16.5.
     *
     * После снятия клиент доигрывает накопленную цель за пару тиков — иммунный
     * игрок «возникает» там, где он на самом деле.
     *
     * Работает и на клиенте, и на сервере:
     * NeoForge зовёт EntityTickEvent.Pre из ServerLevel#tickNonPassenger,
     * ClientLevel#tickNonPassenger и Entity#rideTick, и во всех трёх местах
     * tickCount инкрементится ДО события (см. патчи NeoForge 1.21.x:
     * ServerLevel.java.patch строка "p_8648_.tickCount++" перед fireEntityTickPre).
     * Поэтому счётчик откатываем вручную — иначе замороженные сущности
     * продолжали бы стареть.
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityTickPre(EntityTickEvent.Pre event) {
        if (disabled) return;
        // Быстрый выход до всего остального: этот метод зовётся на каждую
        // сущность каждый тик, на обеих сторонах.
        if (activeCount == 0 && !event.getEntity().level().isClientSide()) return;

        try {
            Entity entity = event.getEntity();

            // Глазами замороженного: на его клиенте не тикает никто, включая
            // иммунных. Подробности — в комментарии к методу.
            if (entity.level().isClientSide()
                    && TimeStopConfig.freezeWorldViewForFrozenPlayers
                    && TimeStopClientState.hasAny()
                    && TimeStopClientState.localFrozen) {
                if (entity.tickCount > 0) entity.tickCount--;
                event.setCanceled(true);
                return;
            }

            if (!isFrozen(entity)) return;

            if (entity.tickCount > 0) entity.tickCount--;
            event.setCanceled(true);
            pinClientPosition(entity);
            tickAnyway(entity);
        } catch (Throwable t) {
            // Исключение здесь повторилось бы для каждой сущности каждый тик и
            // положило бы сервер за секунды. Глушим механику целиком.
            disabled = true;
            LOGGER.error("[timestop] сбой в заморозке сущности — механика отключена до перезапуска", t);
            try {
                emergencyClearAll(event.getEntity().getServer());
            } catch (Throwable ignored) {}
        }
    }

    /**
     * При первом замороженном тике сущности отправляет клиентам её позицию с
     * обнулением интерполяции.
     *
     * Клиент рисует сущность между прошлой позицией (xo/yo/zo) и текущей. Моб,
     * замерзший на бегу, оставляет прошлую позицию позади текущей и продолжает
     * «доезжать» её на рендере — на бегущей толпе это выглядит как замедление,
     * а не остановка. ROTP решает это тем же способом: TimeStopEffect
     * #setTimeStopState шлёт EntityDirectPosNoLerpPacket с комментарием
     * «should prevent the old position desync if the entity was moving at high
     * speed». В первой версии ветки этот кусок перенесён не был.
     */
    private static void pinClientPosition(Entity entity) {
        Level level = entity.level();
        if (level.isClientSide()) return;
        TimeStopLevelState state = stateOrNull(level);
        if (state == null) return;
        if (!state.posPinned.add(entity.getId())) return;
        try {
            PacketDistributor.sendToPlayersTrackingEntityAndSelf(entity,
                    new TimeStopFreezePosPacket(entity.getId(),
                            entity.getX(), entity.getY(), entity.getZ()),
                    new CustomPacketPayload[0]);
        } catch (Throwable ignored) {}
    }

    /**
     * Что продолжает идти у замороженной сущности: окно неуязвимости. Иначе
     * владелец зоны, ударив моба, запер бы себе урон до конца остановки —
     * invulnerableTime тикается только в Entity#baseTick, который отменён.
     *
     * ItemEntity#pickupDelay намеренно НЕ трогаем (в ROTP трогают): поле
     * приватное и требует access transformer, а замороженный предмет с
     * замороженной задержкой подбора — как раз то поведение, которое нужно.
     */
    private static void tickAnyway(Entity entity) {
        if (entity.level().isClientSide()) return;
        if (entity instanceof LivingEntity && entity.invulnerableTime > 0) {
            entity.invulnerableTime--;
        }
    }

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (disabled) return;
        if (event.getLevel().isClientSide()) return;
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        TimeStopLevelState state = STATES.get(level.dimension());
        if (state == null) return;

        try {
            tickLevel(level, state);
            consecutiveFailures = 0;
        } catch (Throwable t) {
            consecutiveFailures++;
            LOGGER.error("[timestop] сбой в тике {} (подряд: {}) — аварийный сброс измерения",
                    level.dimension().location(), consecutiveFailures, t);
            emergencyClear(level);
            if (consecutiveFailures >= 2) {
                disabled = true;
                LOGGER.error("[timestop] механика отключена до перезапуска или /timestop clear");
                emergencyClearAll(level.getServer());
            }
        }
    }

    private static void tickLevel(ServerLevel level, TimeStopLevelState state) {
        state.tick++;
        long now = state.tick;
        boolean changed = false;

        Iterator<TimeStopInstance> it = state.instances.iterator();
        while (it.hasNext()) {
            TimeStopInstance inst = it.next();
            boolean expired = false;
            long age = now - inst.startedTick;

            // Зона, которую держит предмет, обязана подтверждаться каждый
            // тик. Это единственная защита от «держатель исчез способом, о
            // котором мы не подумали»: выкинули, положили в сундук, съел
            // другой мод. Один раз на этом мир завис навсегда.
            if (inst.requiresUpkeep
                    && now - inst.lastUpkeepTick > Math.max(1, TimeStopConfig.upkeepGraceTicks)) {
                LOGGER.warn("[timestop] сторож снял зону {} в {}: держатель молчит {} тиков",
                        inst.id, level.dimension().location(), now - inst.lastUpkeepTick);
                expired = true;
            }

            if (!expired && inst.endless) {
                // Бесконечную зону снимает только владелец, смерть, выход или
                // команда. Необязательный потолок — страховка от «включил и ушёл».
                if (TimeStopConfig.endlessHardCapTicks > 0
                        && age > TimeStopConfig.endlessHardCapTicks) {
                    LOGGER.warn("[timestop] бесконечная зона {} в {} снята по потолку ({} тиков)",
                            inst.id, level.dimension().location(), TimeStopConfig.endlessHardCapTicks);
                    expired = true;
                }
            } else if (!expired) {
                inst.ticksLeft--;
                if (inst.ticksLeft <= 0) expired = true;
                // Сторож: переживает и пропущенные тики, и подкрученный счётчик.
                if (!expired && (age > (long) inst.duration + TimeStopConfig.watchdogGraceTicks || age < 0)) {
                    LOGGER.warn("[timestop] сторож снял зону {} в {} (возраст {} при длительности {})",
                            inst.id, level.dimension().location(), age, inst.duration);
                    expired = true;
                }
            }

            // Владелец вышел, умер, исчез или сменил измерение. Для бесконечной
            // зоны это главный предохранитель, поэтому проверяем и живость.
            if (!expired && inst.ownerEntityId >= 0) {
                Entity owner = level.getEntity(inst.ownerEntityId);
                if (owner == null || owner.isRemoved()
                        || (owner instanceof LivingEntity living && !living.isAlive())) {
                    expired = true;
                }
            }

            if (expired) {
                it.remove();
                changed = true;
            }
        }

        if (changed) {
            onSetChanged(level, state);
        }

        if (!state.isEmpty()) {
            // Суда: сверяемся не каждый тик — обход контейнера саблевелов не
            // бесплатный, а замороженное судно никуда не денется. Интервал ловит
            // того, кто влетел в зону снаружи.
            if (now % Math.max(1, TimeStopConfig.shipSyncIntervalTicks) == 0) {
                SableTimeStop.syncFrozenShips(level);
            }

            if (now - state.exemptRefreshedAt >= Math.max(1, TimeStopConfig.exemptRefreshIntervalTicks)) {
                if (refreshExemptions(level, state)) {
                    sync(level, state);
                }
            }
        }

        releaseDelayedBlockUpdates(level, state);

        if (state.isEmpty() && state.delayedBlockUpdates.isEmpty()) {
            STATES.remove(level.dimension());
            recountActive();
        }
    }

    private static void onSetChanged(ServerLevel level, TimeStopLevelState state) {
        recountActive();
        if (state.isEmpty()) {
            state.posPinned.clear();
            state.exemptPlayers = EMPTY_IDS;
            state.exemptTiers = EMPTY_IDS;
            SableTimeStop.releaseAll(level);
        } else {
            SableTimeStop.syncFrozenShips(level);
        }
        sync(level, state);
    }

    // ── Отложенные блок-апдейты ────────────────────────────────────────────────

    /** Зовётся из миксина на CollectingNeighborUpdater. true — апдейт отложен. */
    public static boolean delayBlockUpdate(Level level, BlockPos pos,
                                           CollectingNeighborUpdater.NeighborUpdates updates) {
        if (!TimeStopConfig.delayNeighborUpdates || disabled) return false;
        TimeStopLevelState state = stateOrNull(level);
        if (state == null || state.isEmpty()) return false;
        if (state.delayOverflow) return false;
        if (state.delayedCount >= TimeStopConfig.maxDelayedBlockUpdates) {
            // Кто-то заморозил редстоун-ферму. Копить дальше — съесть память
            // сервера; отпускаем всё накопленное и до конца зоны не мешаем.
            state.delayOverflow = true;
            LOGGER.warn("[timestop] потолок отложенных блок-апдейтов ({}) пробит в {} — откладывание выключено",
                    TimeStopConfig.maxDelayedBlockUpdates, level.dimension().location());
            return false;
        }
        if (!isStoppedAt(level, pos)) return false;
        // ShapeUpdate — обновление формы соседнего блока; его откладывать нельзя,
        // иначе блоки визуально рассыпаются (то же исключение, что в ROTP).
        if (updates.getClass() == CollectingNeighborUpdater.ShapeUpdate.class) return false;
        state.delay(pos, updates);
        return true;
    }

    /** Проигрывает всё накопленное без оглядки на зоны (аварийный путь). */
    private static void flushDelayedBlockUpdates(ServerLevel level, TimeStopLevelState state) {
        if (state.delayedBlockUpdates.isEmpty()) return;
        if (level.neighborUpdater instanceof CollectingNeighborUpdater updater) {
            for (Collection<Pair<BlockPos, CollectingNeighborUpdater.NeighborUpdates>> pending
                    : state.delayedBlockUpdates.values()) {
                for (Pair<BlockPos, CollectingNeighborUpdater.NeighborUpdates> update : pending) {
                    try {
                        updater.addAndRun(update.getFirst(), update.getSecond());
                    } catch (Throwable ignored) {}
                }
            }
        }
        state.delayedBlockUpdates.clear();
        state.delayedCount = 0;
        state.delayOverflow = false;
    }

    private static void releaseDelayedBlockUpdates(ServerLevel level, TimeStopLevelState state) {
        if (state.delayedBlockUpdates.isEmpty()) {
            state.delayedCount = 0;
            state.delayOverflow = false;
            return;
        }
        if (!(level.neighborUpdater instanceof CollectingNeighborUpdater updater)) {
            state.delayedBlockUpdates.clear();
            state.delayedCount = 0;
            return;
        }
        Iterator<Map.Entry<ChunkPos, Collection<Pair<BlockPos, CollectingNeighborUpdater.NeighborUpdates>>>> it =
                state.delayedBlockUpdates.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<ChunkPos, Collection<Pair<BlockPos, CollectingNeighborUpdater.NeighborUpdates>>> entry = it.next();
            ChunkPos chunk = entry.getKey();
            boolean stillStopped = false;
            for (int i = 0; i < state.instances.size(); i++) {
                if (state.instances.get(i).isInRange(chunk)) { stillStopped = true; break; }
            }
            if (stillStopped) continue;
            for (Pair<BlockPos, CollectingNeighborUpdater.NeighborUpdates> pending : entry.getValue()) {
                try {
                    updater.addAndRun(pending.getFirst(), pending.getSecond());
                } catch (Throwable ignored) {}
            }
            state.delayedCount -= entry.getValue().size();
            it.remove();
        }
    }

    // ── Аварийные сбросы ──────────────────────────────────────────────────────

    /** Снимает всё в одном измерении: зоны, констрейнты судов, отложенные апдейты. */
    public static void emergencyClear(ServerLevel level) {
        TimeStopLevelState state = STATES.remove(level.dimension());
        recountActive();
        try {
            SableTimeStop.releaseAll(level);
        } catch (Throwable ignored) {}
        if (state != null) {
            try {
                flushDelayedBlockUpdates(level, state);
            } catch (Throwable ignored) {
                state.delayedBlockUpdates.clear();
            }
        }
        try {
            sync(level, state == null ? new TimeStopLevelState() : state);
        } catch (Throwable ignored) {}
    }

    /** То же самое по всем измерениям сервера. */
    public static void emergencyClearAll(net.minecraft.server.MinecraftServer server) {
        if (server == null) {
            STATES.clear();
            SableTimeStop.forgetEverything();
            recountActive();
            return;
        }
        for (ServerLevel level : server.getAllLevels()) {
            try {
                emergencyClear(level);
            } catch (Throwable ignored) {}
        }
        STATES.clear();
        SableTimeStop.forgetEverything();
        recountActive();
    }

    /** Снимает аварийный рубильник (команда /timestop clear). */
    public static void reenable() {
        disabled = false;
        consecutiveFailures = 0;
    }

    // ── Синхронизация ──────────────────────────────────────────────────────────

    private static void sync(ServerLevel level, TimeStopLevelState state) {
        PacketDistributor.sendToPlayersInDimension(level,
                TimeStopSyncPacket.of(state), new CustomPacketPayload[0]);
    }

    private static void syncTo(ServerPlayer player) {
        if (!(player.level() instanceof ServerLevel level)) return;
        TimeStopLevelState state = STATES.get(level.dimension());
        TimeStopSyncPacket packet = state == null
                ? TimeStopSyncPacket.empty()
                : TimeStopSyncPacket.of(state);
        PacketDistributor.sendToPlayer(player, packet, new CustomPacketPayload[0]);
    }

    /**
     * Эндермен внутри остановленного времени ходит, но не телепортируется.
     * Событие NeoForge покрывает все три вида его прыжка (случайный, к цели и
     * уклонение от снаряда), поэтому лезть миксином в EnderMan не нужно.
     */
    @SubscribeEvent
    public static void onEnderTeleport(EntityTeleportEvent.EnderEntity event) {
        if (!TimeStopConfig.endermenIgnoreTimeStop) return;
        if (activeCount == 0) return;
        try {
            if (isStoppedAt(event.getEntity().level(), event.getEntity().blockPosition())) {
                event.setCanceled(true);
            }
        } catch (Throwable ignored) {}
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) syncTo(player);
    }

    @SubscribeEvent
    public static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) syncTo(player);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) syncTo(player);
    }

    @SubscribeEvent
    public static void onLevelUnload(LevelEvent.Unload event) {
        if (event.getLevel() instanceof ServerLevel level) {
            STATES.remove(level.dimension());
            recountActive();
            try {
                SableTimeStop.releaseAll(level);
            } catch (Throwable ignored) {}
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        STATES.clear();
        SableTimeStop.forgetEverything();
        activeCount = 0;
        nextId = 1;
        disabled = false;
        consecutiveFailures = 0;
    }
}
