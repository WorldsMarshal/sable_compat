package com.invfix.timestop.compat;

import com.invfix.timestop.TimeStopApi;
import com.invfix.timestop.TimeStopConfig;
import dev.ryanhcode.sable.api.physics.PhysicsPipeline;
import dev.ryanhcode.sable.api.physics.constraint.FixedConstraintConfiguration;
import dev.ryanhcode.sable.api.physics.constraint.PhysicsConstraintHandle;
import dev.ryanhcode.sable.api.sublevel.ServerSubLevelContainer;
import dev.ryanhcode.sable.api.sublevel.SubLevelContainer;
import dev.ryanhcode.sable.companion.math.BoundingBox3dc;
import dev.ryanhcode.sable.companion.math.Pose3dc;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.sublevel.SubLevel;
import dev.ryanhcode.sable.sublevel.plot.LevelPlot;
import dev.ryanhcode.sable.sublevel.system.SubLevelPhysicsSystem;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.fml.ModList;
import org.joml.Quaterniond;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Мост к Sable: поштучная заморозка судов и перевод делянок в мировые координаты.
 *
 * Как морозим. Тем же способом, что физический посох Simulated
 * (PhysicsStaffServerHandler#addConstraint): к судну добавляется фиксированный
 * констрейнт к статическому миру —
 * {@code pipeline.addConstraint(null, subLevel, new FixedConstraintConfiguration(
 * pose.position(), pose.rotationPoint(), pose.orientation()))}. Это и есть
 * штатная «заморозка одного саблевела», глобальная пауза движка тут не нужна и
 * была бы неверна: она вешала бы все суда измерения, а не попавшие в радиус.
 *
 * Импульс сохраняем. Перед постановкой констрейнта читаем линейную и угловую
 * скорость (RapierPhysicsPipeline реализует getLinearVelocity/getAngularVelocity),
 * гасим их, а при снятии возвращаем. Иначе летящий дирижабль после остановки
 * времени продолжил бы с нуля и просто упал — для тайм-стопа это неверно, судно
 * обязано продолжить полёт с той же скоростью.
 *
 * Почему координаты отдельная история: блоки судна лежат не там, где судно
 * видно. Sable селит каждый саблевел в делянку с началом в чанке 10000/10000
 * (LevelsMixin), а мировую позицию даёт трансформом logicalPose(). Поэтому
 * проверка «этот чанк внутри зоны» для чанков делянки обязана сначала перевести
 * судно в мировые координаты. Сущности этой проблемы не имеют: EntityMixin
 * Sable держит в Entity#position() уже мировую позицию.
 */
public final class SableTimeStop {

    private SableTimeStop() {}

    /** Скорость ниже этого порога считаем нулевой и не восстанавливаем. */
    private static final double VELOCITY_EPSILON_SQR = 1.0e-6;

    /** Замороженное судно: наш констрейнт и снятый с него импульс. */
    private record Frozen(PhysicsConstraintHandle handle, Vector3d linear, Vector3d angular) {}

    private static final Map<ResourceKey<Level>, Map<UUID, Frozen>> FROZEN = new HashMap<>();

    /** 0 — ещё не спрашивали, 1 — есть, 2 — нет. Не кэшируем «нет», пока ModList не готов. */
    private static int loadedState = 0;

    public static boolean loaded() {
        if (loadedState != 0) return loadedState == 1;
        try {
            ModList list = ModList.get();
            if (list == null) return false;
            loadedState = list.isLoaded("sable") ? 1 : 2;
        } catch (Throwable t) {
            return false;
        }
        return loadedState == 1;
    }

    // ── Поштучная заморозка судов ──────────────────────────────────────────────

    /**
     * Приводит набор замороженных судов в соответствие с активными зонами.
     * Зовётся из тика менеджера; судно, влетевшее в зону снаружи, замерзает на
     * ближайшей сверке.
     */
    public static void syncFrozenShips(ServerLevel level) {
        if (!loaded() || !TimeStopConfig.freezeSableShips) return;
        try {
            ServerSubLevelContainer container = SubLevelContainer.getContainer(level);
            if (container == null) return;
            SubLevelPhysicsSystem system = container.physicsSystem();
            if (system == null) return;
            PhysicsPipeline pipeline = system.getPipeline();
            if (pipeline == null) return;

            Map<UUID, Frozen> frozen = FROZEN.computeIfAbsent(level.dimension(), key -> new HashMap<>());
            List<UUID> seen = new ArrayList<>(frozen.size());

            for (Object raw : container.getAllSubLevels()) {
                if (!(raw instanceof ServerSubLevel subLevel)) continue;
                UUID id = subLevel.getUniqueId();
                if (id == null) continue;
                boolean alreadyFrozen = frozen.containsKey(id);
                if (alreadyFrozen) seen.add(id);

                if (subLevel.isRemoved()) {
                    if (alreadyFrozen) forget(frozen, id);
                    continue;
                }

                boolean shouldFreeze = isSubLevelStopped(level, subLevel);
                if (shouldFreeze && !alreadyFrozen) {
                    freeze(pipeline, subLevel, frozen);
                } else if (!shouldFreeze && alreadyFrozen) {
                    thaw(pipeline, subLevel, frozen);
                }
            }

            // Саблевелы, исчезнувшие из контейнера: констрейнта уже нет, чистим запись.
            if (frozen.size() != seen.size()) {
                Iterator<Map.Entry<UUID, Frozen>> it = frozen.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<UUID, Frozen> entry = it.next();
                    if (!seen.contains(entry.getKey())) {
                        removeHandle(entry.getValue());
                        it.remove();
                    }
                }
            }
        } catch (Throwable t) {
            // Движок сменил API или упал — освобождаем всё, что держим,
            // и больше в этом тике не лезем.
            releaseAll(level);
        }
    }

    /** Снимает все наши констрейнты в измерении и возвращает судам импульс. */
    public static void releaseAll(ServerLevel level) {
        Map<UUID, Frozen> frozen = FROZEN.remove(level.dimension());
        if (frozen == null || frozen.isEmpty()) return;
        try {
            ServerSubLevelContainer container = SubLevelContainer.getContainer(level);
            SubLevelPhysicsSystem system = container != null ? container.physicsSystem() : null;
            PhysicsPipeline pipeline = system != null ? system.getPipeline() : null;

            for (Map.Entry<UUID, Frozen> entry : frozen.entrySet()) {
                removeHandle(entry.getValue());
                if (pipeline == null || container == null) continue;
                SubLevel subLevel = container.getSubLevel(entry.getKey());
                if (subLevel instanceof ServerSubLevel ssl && !ssl.isRemoved()) {
                    restoreVelocity(pipeline, ssl, entry.getValue());
                }
            }
        } catch (Throwable ignored) {
            // Констрейнты живут только в рантайме физической сцены и в сейв не
            // попадают — даже если снять не удалось, перезапуск их не воскресит.
        }
    }

    /** Полная очистка состояния (остановка сервера, аварийный сброс). */
    public static void forgetEverything() {
        FROZEN.clear();
    }

    public static int frozenShipCount(ServerLevel level) {
        Map<UUID, Frozen> frozen = FROZEN.get(level.dimension());
        return frozen == null ? 0 : frozen.size();
    }

    private static void freeze(PhysicsPipeline pipeline, ServerSubLevel subLevel, Map<UUID, Frozen> frozen) {
        Vector3d linear = new Vector3d();
        Vector3d angular = new Vector3d();
        try {
            pipeline.getLinearVelocity(subLevel, linear);
            pipeline.getAngularVelocity(subLevel, angular);
        } catch (Throwable t) {
            linear.zero();
            angular.zero();
        }

        PhysicsConstraintHandle handle;
        try {
            Pose3dc pose = subLevel.logicalPose();
            // Копии, а не живые ссылки на позу: она мутирует по ходу симуляции.
            handle = pipeline.addConstraint(null, subLevel, new FixedConstraintConfiguration(
                    new Vector3d(pose.position()),
                    new Vector3d(pose.rotationPoint()),
                    new Quaterniond(pose.orientation())));
        } catch (Throwable t) {
            return;
        }
        // Пайплайн-заглушка (StaticPhysicsPipeline) вернёт null — морозить нечего.
        if (handle == null) return;

        // Гасим остаточную скорость, чтобы солвер не дёргал судно об констрейнт.
        try {
            pipeline.resetVelocity(subLevel);
        } catch (Throwable ignored) {}

        frozen.put(subLevel.getUniqueId(), new Frozen(handle, linear, angular));
    }

    private static void thaw(PhysicsPipeline pipeline, ServerSubLevel subLevel, Map<UUID, Frozen> frozen) {
        Frozen record = frozen.remove(subLevel.getUniqueId());
        if (record == null) return;
        removeHandle(record);
        if (!subLevel.isRemoved()) restoreVelocity(pipeline, subLevel, record);
    }

    private static void forget(Map<UUID, Frozen> frozen, UUID id) {
        Frozen record = frozen.remove(id);
        if (record != null) removeHandle(record);
    }

    private static void removeHandle(Frozen record) {
        try {
            if (record.handle() != null && record.handle().isValid()) {
                record.handle().remove();
            }
        } catch (Throwable ignored) {}
    }

    private static void restoreVelocity(PhysicsPipeline pipeline, ServerSubLevel subLevel, Frozen record) {
        double lin = record.linear().lengthSquared();
        double ang = record.angular().lengthSquared();
        // Судно и так стояло — не трогаем. Сюда же попадает случай, когда его
        // держит физический посох Simulated: у залоченного судна скорость нулевая,
        // и мы не дадим ему импульс поверх чужого констрейнта.
        if (lin < VELOCITY_EPSILON_SQR && ang < VELOCITY_EPSILON_SQR) return;
        try {
            pipeline.wakeUp(subLevel);
            pipeline.resetVelocity(subLevel);
            pipeline.addLinearAndAngularVelocity(subLevel, record.linear(), record.angular());
        } catch (Throwable ignored) {}
    }

    // ── Делянка → мир ──────────────────────────────────────────────────────────

    /**
     * Попадает ли чанк делянки в зону остановки, если судить по мировому
     * положению судна. Возвращает null, если чанк не принадлежит делянке —
     * тогда вызывающий проверяет чанк как обычный.
     *
     * Работает на обеих сторонах: SubLevel есть и в ClientSubLevelContainer.
     * Без клиентской половины блок-сущности судна продолжали бы крутиться на
     * экране при замершем сервере.
     */
    public static Boolean isPlotChunkStopped(Level level, long packedChunkPos) {
        if (!loaded()) return null;
        // Дешёвая отсечка для горячего пути: shouldTickBlocksAt зовётся на
        // каждый тикающий чанк каждый тик, а разбор делянки стоит двух
        // обращений к контейнеру саблевелов. Если в этом измерении не
        // заморожено ни одного судна, ни один чанк делянки остановленным быть
        // не может — возвращаем null, и вызывающий проверит чанк обычным
        // путём (координаты делянки заведомо далеко от любой зоны, ответ тот же).
        if (level instanceof ServerLevel serverLevel) {
            Map<UUID, Frozen> frozen = FROZEN.get(serverLevel.dimension());
            if (frozen == null || frozen.isEmpty()) return null;
        }
        try {
            SubLevelContainer container = SubLevelContainer.getContainer(level);
            if (container == null) return null;
            LevelPlot plot = container.getPlot(new ChunkPos(packedChunkPos));
            if (plot == null) return null;
            SubLevel subLevel = plot.getSubLevel();
            if (subLevel == null || subLevel.isRemoved()) return Boolean.FALSE;
            return isSubLevelStopped(level, subLevel);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Мировая позиция блока делянки, или сам pos, если это не делянка. */
    public static BlockPos toWorldPos(Level level, BlockPos pos) {
        if (!loaded() || pos == null) return pos;
        try {
            SubLevelContainer container = SubLevelContainer.getContainer(level);
            if (container == null) return pos;
            LevelPlot plot = container.getPlot(new ChunkPos(pos));
            if (plot == null) return pos;
            SubLevel subLevel = plot.getSubLevel();
            if (subLevel == null || subLevel.isRemoved()) return pos;
            Vec3 world = subLevel.logicalPose().transformPosition(
                    new Vec3(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5));
            return BlockPos.containing(world);
        } catch (Throwable t) {
            return pos;
        }
    }

    private static boolean isSubLevelStopped(Level level, SubLevel subLevel) {
        // Габарит судна в мировых координатах — так замирает и стометровый
        // дирижабль, чей центр остался за краем зоны.
        BoundingBox3dc bounds = subLevel.boundingBox();
        if (bounds != null) {
            return TimeStopApi.isWorldBoxStopped(level,
                    bounds.minX(), bounds.minZ(), bounds.maxX(), bounds.maxZ());
        }
        Vec3 origin = subLevel.logicalPose().transformPosition(Vec3.ZERO);
        return TimeStopApi.isWorldBoxStopped(level, origin.x, origin.z, origin.x, origin.z);
    }
}
