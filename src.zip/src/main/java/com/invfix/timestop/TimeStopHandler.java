package com.invfix.timestop;

import com.invfix.altrumite.AltrumiteRace;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Способность «Остановка времени» у расы Alien(Metroman).
 *
 * Поведение: бесконечная зона, без кулдауна, тот же слот её и выключает.
 *
 * Почему тумблер сделан на фронте нажатия. AbilityCallProcedure зовётся не по
 * нажатию, а КАЖДЫЙ тик игрока — из OnplayerTickProcedure (там она идёт второй
 * строкой, сразу после BattleModeOnOffPotionProcedure), и дополнительно по
 * приходу Ability1..5Message с type == 0. Если реагировать на «слот нажат», за
 * полсекунды удержания клавиши остановка включится и выключится десяток раз.
 * Поэтому состояние клавиши отслеживается само, и действие происходит ровно на
 * переходе «не нажата → нажата».
 *
 * Запуск зоны живёт в {@link TimeStopManager}, который про расы ничего не знает:
 * пульт Рика и камень времени подключатся туда же, минуя этот класс.
 */
public final class TimeStopHandler {

    private TimeStopHandler() {}

    public static final String ABILITY = "§b§lTime Stop";

    /** Порог уровня для открытия способности. */
    public static int lvlRequired = 350;

    private static final Set<String> ELIGIBLE = Set.of(AltrumiteRace.RACE);

    /** Состояние клавиши слота на прошлом тике — для детекта фронта. */
    private static final Map<UUID, Boolean> KEY_DOWN = new ConcurrentHashMap<>();
    /** Момент последнего включения, для необязательного кулдауна. */
    private static final Map<UUID, Long> LAST_USE = new ConcurrentHashMap<>();

    public static boolean isEligible(String race) {
        return race != null && ELIGIBLE.contains(race);
    }

    /**
     * Зовётся каждый тик из AbilityCallProcedureMixin, в том числе когда клавиша
     * отпущена — иначе фронт не на чем было бы построить.
     *
     * @param pressed нажат ли прямо сейчас слот, в котором лежит эта способность
     */
    public static void handleKeyState(ServerPlayer player, boolean pressed) {
        if (player == null) return;
        UUID id = player.getUUID();
        boolean was = Boolean.TRUE.equals(KEY_DOWN.put(id, pressed));
        if (pressed && !was) {
            if (player.isShiftKeyDown()) {
                shiftPress(player);
            } else {
                toggle(player);
            }
        }
    }

    /**
     * Шифт + кнопка. Раскладка ровно как в ROTP (TimeResume#getVisibleAction):
     *  - своё время стоит — снятие остановки;
     *  - стоит чужое — ничего;
     *  - не стоит — мгновенная остановка. Её выполняет пакет от клиента
     *    ({@link com.invfix.timestop.blink.TimeStopBlinkPacket}), потому что
     *    цель берётся из прицела клиента; здесь для неё делать нечего.
     */
    private static void shiftPress(ServerPlayer player) {
        if (!(player.level() instanceof ServerLevel level)) return;
        if (TimeStopManager.ownedBy(level, player.getId()) != null) {
            TimeStopManager.stopOwnedBy(level, player.getId());
        }
    }

    /**
     * Мгновенная остановка Metroman. Бесконечное время остановки и никакой
     * цены — поэтому потолок подразумеваемых тиков не ограничен, и
     * дистанцию режет только предел ROTP в 192 блока. Кулдауна нет, как и у
     * основной остановки.
     */
    public static boolean blink(ServerPlayer player, com.invfix.timestop.blink.BlinkTarget target) {
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (!isEligible(vars.Race)) return false;
            if (vars.Lvl < lvlRequired) return false;
            if (!TimeStopExemptions.hasAbilityInSlots(vars, ABILITY)) return false;
            if (!com.invfix.timestop.blink.TimeStopBlink.allowedAt(player)) return false;

            var plan = com.invfix.timestop.blink.TimeStopBlink.plan(player, target, Integer.MAX_VALUE);
            com.invfix.timestop.blink.TimeStopBlink.perform(player, plan);
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    /** Есть зона — снять, нет — запустить. */
    public static boolean toggle(ServerPlayer player) {
        try {
            if (!(player.level() instanceof ServerLevel level)) return false;

            InvincibleIncModVariables.PlayerVariables vars =
                    player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (!isEligible(vars.Race)) return false;
            if (vars.Lvl < lvlRequired) return false;

            // Своя зона висит — выключаем. Кулдаун на выключение не влияет.
            if (TimeStopManager.ownedBy(level, player.getId()) != null) {
                return TimeStopManager.stopOwnedBy(level, player.getId());
            }

            if (TimeStopConfig.cooldownTicks > 0) {
                long now = level.getGameTime();
                Long last = LAST_USE.get(player.getUUID());
                if (last != null && now - last < TimeStopConfig.cooldownTicks) return false;
            }

            TimeStopInstance inst = TimeStopManager.start(level, player,
                    TimeStopConfig.abilityEndless ? 0 : TimeStopConfig.durationTicks,
                    TimeStopConfig.chunkRange, TimeStopConfig.abilityEndless, TIER);
            // Отказ по уровню (Metroman поверх Metroman) кулдаун не жжёт.
            if (inst == null) return false;
            if (TimeStopConfig.cooldownTicks > 0) {
                LAST_USE.put(player.getUUID(), level.getGameTime());
            }
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * Уровень остановки расы. ABSOLUTE — непрерываемый: Metroman поверх
     * Metroman не запускается вовсе. С устройственными зонами не пересекается
     * никак — слои независимы, ни одна из остановок не гасит другую.
     */
    public static final TimeStopTier TIER = TimeStopTier.ABSOLUTE;

    /** Досрочное возобновление времени владельцем. */
    public static boolean resume(LivingEntity owner) {
        if (!(owner.level() instanceof ServerLevel level)) return false;
        return TimeStopManager.stopOwnedBy(level, owner.getId());
    }

    /** Сколько тиков кулдауна осталось. При cooldownTicks == 0 всегда 0. */
    public static long cooldownLeft(ServerPlayer player) {
        if (TimeStopConfig.cooldownTicks <= 0) return 0;
        if (!(player.level() instanceof ServerLevel level)) return 0;
        Long last = LAST_USE.get(player.getUUID());
        if (last == null) return 0;
        long passed = level.getGameTime() - last;
        return Math.max(0, TimeStopConfig.cooldownTicks - passed);
    }

    public static void forget(UUID playerId) {
        LAST_USE.remove(playerId);
        KEY_DOWN.remove(playerId);
    }
}
