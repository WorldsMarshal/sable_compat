package com.invfix.util;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.rick.RickBloodline;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Отладочные оверрайды расы для закреплённых QA-аккаунтов.
 *
 * Логика вынесена сюда из {@code RaceRandomizerMixin}, чтобы отладочные
 * сценарии можно было расширять централизованно, не трогая саму процедуру
 * рандомизации. Каждый оверрайд — это пара «имя игрока → действие над
 * переменными игрока». Действие напрямую пишет в
 * {@link InvincibleIncModVariables.PlayerVariables} и помечает их dirty.
 *
 * Чтобы добавить новый отладочный аккаунт — зарегистрируй его в
 * статическом блоке через {@link #register(String, Consumer)}.
 */
public final class DebugUtils {

    private DebugUtils() {}

    /** Имя игрока (по GameProfile) → действие над его переменными. */
    private static final Map<String, Consumer<InvincibleIncModVariables.PlayerVariables>> OVERRIDES =
            new LinkedHashMap<>();

    static {
        // QA-аккаунт: принудительный Altrumite с бладлайном Argall.
        register("HoustonWTF", vars -> {
            vars.Race = AltrumiteRace.RACE;
            vars.Power = AltrumiteRace.POWER;
            vars.racePower = AltrumiteRace.POWER;
            vars.RaceStatMultiplier = AltrumiteRace.RACE_STAT_MULTIPLIER;
            vars.Bloodline = RickBloodline.RICK;
        });
    }

    /**
     * Регистрирует отладочный оверрайд для конкретного игрока.
     *
     * @param playerName имя игрока (точное совпадение по GameProfile)
     * @param action     действие, применяемое к переменным игрока
     */
    public static void register(String playerName,
                                Consumer<InvincibleIncModVariables.PlayerVariables> action) {
        OVERRIDES.put(playerName, action);
    }

    /**
     * Пытается применить отладочный оверрайд к сущности.
     *
     * @param entity сущность, для которой выполняется рандомизация расы
     * @return {@code true}, если оверрайд применён (рандомизацию нужно
     *         прервать), иначе {@code false}
     */
    public static boolean tryApply(Entity entity) {
        if (!(entity instanceof ServerPlayer sp)) return false;

        Consumer<InvincibleIncModVariables.PlayerVariables> action =
                OVERRIDES.get(sp.getGameProfile().getName());
        if (action == null) return false;

        InvincibleIncModVariables.PlayerVariables vars =
                entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        action.accept(vars);
        vars.markSyncDirty();
        return true;
    }
}