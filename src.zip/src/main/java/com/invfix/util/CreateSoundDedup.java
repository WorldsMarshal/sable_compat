package com.invfix.util;

import com.mojang.logging.LogUtils;
import com.simibubi.create.AllSoundEvents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import org.slf4j.Logger;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Проверка того, что звуковое событие Create-записи уже лежит в реестре.
 *
 * Вынесено из миксина в обычный класс осознанно: обращения к ванильному
 * реестру ({@link BuiltInRegistries}) выполняются в незатронутом ремаппером
 * коде, поэтому миксины на классы Create можно держать с {@code remap = false}
 * без риска NoSuchMethodError в продакшене.
 *
 * @see com.invfix.mixin.create.CreateSoundEntryDuplicateMixin
 */
public final class CreateSoundDedup {

    private static final Logger INVFIX_LOGGER = LogUtils.getLogger();

    /** Уже отчитавшиеся id — чтобы не засорять лог на каждом дубликате. */
    private static final Set<ResourceLocation> INVFIX_REPORTED =
            Collections.synchronizedSet(new HashSet<>());

    private CreateSoundDedup() {}

    /**
     * @param entry экземпляр {@code AllSoundEvents.SoundEntry} (передаётся как
     *              {@code Object}, т.к. миксины целятся в приватные вложенные
     *              классы Create и не наследуют её тип на этапе компиляции)
     * @return {@code true}, если основной id записи уже зарегистрирован и
     *         повторный проход нужно пропустить
     */
    public static boolean isAlreadyRegistered(Object entry) {
        if (!(entry instanceof AllSoundEvents.SoundEntry soundEntry)) {
            return false;
        }

        ResourceLocation id;
        try {
            id = soundEntry.getId();
        } catch (Throwable t) {
            return false;
        }

        if (id == null || !BuiltInRegistries.SOUND_EVENT.containsKey(id)) {
            return false;
        }

        if (INVFIX_REPORTED.add(id)) {
            INVFIX_LOGGER.info("Skipped duplicate sound event registration for {}", id);
        }
        return true;
    }
}
