package com.invfix.heatdisruption;

import net.minecraft.world.phys.Vec3;

/**
 * Геометрия выжигания Heat Disruption — общая для сервера (снос блоков, урон)
 * и клиента (горячие стенки в heat_disruption.fsh, тот же профиль в P2).
 *
 * Параболический конус по линии прицела: у глаз радиус 0 (первые
 * {@link #CLEAR} блока не трогаются вовсе, чтобы луч не снёс землю под ногами),
 * дальше растёт как корень из расстояния — параболоид — и к {@link #FLARE}
 * блокам выходит на полный радиус; так до конца длины.
 *
 * Два размера: обычный ({@link #NORMAL}: радиус 9, длина 500, луч 2) и в режиме
 * The Whole Sentry Power ({@link #SENTRY}: радиус 18, длина 1000, луч 3).
 */
public final class HeatDisruptionShape {

    /** Столько блоков от глаз не трогается. */
    public static final double CLEAR = 3.5;
    /** На таком расстоянии от глаз параболоид выходит на полный радиус. */
    public static final double FLARE = 32.0;

    public static final HeatDisruptionShape NORMAL = new HeatDisruptionShape(9.0, 500.0, 2.0);
    public static final HeatDisruptionShape SENTRY = new HeatDisruptionShape(18.0, 1000.0, 3.0);

    /** Полный радиус выжигания, блоков. */
    public final double radius;
    /** Длина выжигания, блоков. */
    public final double length;
    /** Радиус самого видимого луча (клиент: P3.y), блоков. */
    public final double beamRadius;

    private HeatDisruptionShape(double radius, double length, double beamRadius) {
        this.radius = radius;
        this.length = length;
        this.beamRadius = beamRadius;
    }

    public static HeatDisruptionShape of(boolean sentry) {
        return sentry ? SENTRY : NORMAL;
    }

    /** Радиус выжигания на расстоянии s от глаз по лучу. */
    public double radiusAt(double s) {
        if (s < CLEAR || s > length) return 0.0;
        double k = Math.min(1.0, (s - CLEAR) / (FLARE - CLEAR));
        return radius * Math.sqrt(k);
    }

    /**
     * Внутри ли точка выжигания (до головы луча head): origin — глаза при
     * выстреле, dir — единичное направление, extra — запас к радиусу.
     */
    public boolean inside(Vec3 origin, Vec3 dir, double head, Vec3 p, double extra) {
        double px = p.x - origin.x, py = p.y - origin.y, pz = p.z - origin.z;
        double s = px * dir.x + py * dir.y + pz * dir.z;
        if (s < CLEAR || s > Math.min(head, length)) return false;
        double perp2 = px * px + py * py + pz * pz - s * s;
        double r = radiusAt(s) + extra;
        return perp2 <= r * r;
    }

    /**
     * Попадание по сущности: как {@link #inside}, только и в первых блоках у
     * глаз — там, где земля не сносится, сам луч всё равно бьёт.
     */
    public boolean hits(Vec3 origin, Vec3 dir, double head, Vec3 p, double extra) {
        double px = p.x - origin.x, py = p.y - origin.y, pz = p.z - origin.z;
        double s = px * dir.x + py * dir.y + pz * dir.z;
        if (s < 0.3 || s > Math.min(head, length)) return false;
        double perp2 = px * px + py * py + pz * pz - s * s;
        double r = Math.max(radiusAt(s), beamRadius) + extra;
        return perp2 <= r * r;
    }
}
