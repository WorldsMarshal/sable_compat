package com.invfix.heatdisruption;

import com.invfix.heatdisruption.client.HeatDisruptionClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Сервер → клиенты: игрок casterId нажал Heat Disruption. Глаза на момент
 * нажатия (x, y, z), направление (dx, dy, dz), зерно эффекта, сносит ли луч
 * блоки (геймрул) — от этого зависят горячие стенки после выстрела. Дальше
 * клиент ведёт свой таймлайн сам (HeatDisruptionHandler: те же тики).
 */
public record HeatDisruptionPacket(int casterId, double x, double y, double z, float dx, float dy, float dz,
                                   float seed, boolean carve, boolean sentry) implements CustomPacketPayload {

    public static final Type<HeatDisruptionPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "heat_disruption"));

    public static final StreamCodec<FriendlyByteBuf, HeatDisruptionPacket> STREAM_CODEC = StreamCodec.of(
            (buf, m) -> {
                buf.writeVarInt(m.casterId());
                buf.writeDouble(m.x());
                buf.writeDouble(m.y());
                buf.writeDouble(m.z());
                buf.writeFloat(m.dx());
                buf.writeFloat(m.dy());
                buf.writeFloat(m.dz());
                buf.writeFloat(m.seed());
                buf.writeBoolean(m.carve());
                buf.writeBoolean(m.sentry());
            },
            buf -> new HeatDisruptionPacket(buf.readVarInt(), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                    buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readBoolean(),
                    buf.readBoolean()));

    @Override
    public Type<HeatDisruptionPacket> type() {
        return TYPE;
    }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(HeatDisruptionPacket p, IPayloadContext context) {
        context.enqueueWork(() -> HeatDisruptionClient.start(p.casterId, p.x, p.y, p.z, p.dx, p.dy, p.dz,
                p.seed, p.carve, p.sentry));
    }
}
