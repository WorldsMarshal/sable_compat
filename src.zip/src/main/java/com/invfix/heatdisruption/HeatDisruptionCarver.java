package com.invfix.heatdisruption;

import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ThreadedLevelLightEngine;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Снос блоков Heat Disruption — так же, как Carving у The Shooting Star:
 * прямо в секциях чанка, без обновлений соседей и дропа, потом пересвет и
 * свежий пакет чанка игрокам. Идёт за головой луча: каждый тик берутся
 * колонки чанков, до которых луч уже дошёл, не больше {@link #CHUNKS_PER_TICK}.
 *
 * Трогаются только прогруженные чанки (непрогруженные луч не грузит, как и
 * Heat Vision). Сносится всё, кроме бедрока — включая обсидиан, воду и лаву.
 */
final class HeatDisruptionCarver {

    static final int CHUNKS_PER_TICK = 12;
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    /** Полудиагональ секции 16³: секция дальше от оси, чем RADIUS + это, не задета. */
    private static final double SECTION_HALF_DIAGONAL = 13.86;

    private final ServerLevel level;
    private final Vec3 origin;
    private final Vec3 dir;
    private final HeatDisruptionShape shape;
    /** Колонки чанков в порядке, в каком до них доходит луч, и где он их впервые задевает. */
    private final List<ChunkPos> columns = new ArrayList<>();
    private final List<Double> reach = new ArrayList<>();
    private int next;
    private long removed;

    HeatDisruptionCarver(ServerLevel level, Vec3 origin, Vec3 dir, HeatDisruptionShape shape) {
        this.shape = shape;
        this.level = level;
        this.origin = origin;
        this.dir = dir;

        // колонки, которые задевает параболоид: идём по оси шагом 4 блока
        Map<Long, Double> first = new HashMap<>();
        for (double s = HeatDisruptionShape.CLEAR; s <= shape.length + 4.0; s += 4.0) {
            double at = Math.min(s, shape.length);
            double r = Math.max(shape.radiusAt(at), 1.0) + 4.0;
            Vec3 p = origin.add(dir.scale(at));
            int x0 = SectionPos.blockToSectionCoord(p.x - r), x1 = SectionPos.blockToSectionCoord(p.x + r);
            int z0 = SectionPos.blockToSectionCoord(p.z - r), z1 = SectionPos.blockToSectionCoord(p.z + r);
            for (int x = x0; x <= x1; x++) {
                for (int z = z0; z <= z1; z++) {
                    long key = ChunkPos.asLong(x, z);
                    double was = first.getOrDefault(key, Double.MAX_VALUE);
                    if (at - r < was) first.put(key, Math.max(0.0, at - r));
                }
            }
        }
        first.entrySet().stream()
                .sorted(Map.Entry.comparingByValue())
                .forEach(e -> {
                    columns.add(new ChunkPos(e.getKey()));
                    reach.add(e.getValue());
                });
    }

    boolean done() {
        return next >= columns.size();
    }

    /** Режет колонки, до которых дошла голова луча (front, блоков от глаз). */
    void tick(double front) {
        int budget = CHUNKS_PER_TICK;
        while (budget > 0 && next < columns.size() && reach.get(next) <= front) {
            ChunkPos pos = columns.get(next++);
            LevelChunk chunk = level.getChunkSource().getChunkNow(pos.x, pos.z);
            if (chunk == null) continue; // не прогружен — луч его не грузит
            if (cut(chunk)) budget--;
        }
    }

    /** Дорезать всё сразу (способность прервалась). */
    void finish() {
        while (!done()) tick(Double.MAX_VALUE);
    }

    private boolean cut(LevelChunk chunk) {
        ChunkPos pos = chunk.getPos();
        ThreadedLevelLightEngine light = level.getChunkSource().getLightEngine();
        LevelChunkSection[] sections = chunk.getSections();
        boolean any = false;
        double ox = origin.x, oy = origin.y, oz = origin.z;
        double dx = dir.x, dy = dir.y, dz = dir.z;
        int bx = pos.getMinBlockX(), bz = pos.getMinBlockZ();

        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection section = sections[i];
            if (section.hasOnlyAir()) continue;
            int by = SectionPos.sectionToBlockCoord(level.getSectionYFromSectionIndex(i));

            // секция целиком мимо параболоида — дальше
            double cx = bx + 8.0 - ox, cy = by + 8.0 - oy, cz = bz + 8.0 - oz;
            double cs = Math.max(HeatDisruptionShape.CLEAR, Math.min(shape.length,
                    cx * dx + cy * dy + cz * dz));
            double ex = cx - dx * cs, ey = cy - dy * cs, ez = cz - dz * cs;
            double reachR = shape.radius + SECTION_HALF_DIAGONAL;
            if (ex * ex + ey * ey + ez * ez > reachR * reachR) continue;

            boolean changed = false;
            for (int ly = 0; ly < 16; ly++) {
                double py = by + ly + 0.5 - oy;
                for (int lx = 0; lx < 16; lx++) {
                    double px = bx + lx + 0.5 - ox;
                    for (int lz = 0; lz < 16; lz++) {
                        double pz = bz + lz + 0.5 - oz;
                        double s = px * dx + py * dy + pz * dz;
                        if (s < HeatDisruptionShape.CLEAR || s > shape.length) continue;
                        double r = shape.radiusAt(s);
                        if (px * px + py * py + pz * pz - s * s > r * r) continue;
                        BlockState state = section.getBlockState(lx, ly, lz);
                        if (state.isAir() || state.is(Blocks.BEDROCK)) continue;
                        section.setBlockState(lx, ly, lz, AIR, false);
                        removed++;
                        changed = true;
                    }
                }
            }
            if (changed) {
                any = true;
                light.updateSectionStatus(SectionPos.of(pos, level.getSectionYFromSectionIndex(i)),
                        sections[i].hasOnlyAir());
            }
        }
        if (!any) return false;

        // блок-сущности на месте снесённого
        for (BlockPos at : new ArrayList<>(chunk.getBlockEntitiesPos())) {
            if (chunk.getBlockState(at).isAir()) chunk.removeBlockEntity(at);
        }
        relight(chunk);
        return true;
    }

    /** Как Carving.relight у The Shooting Star: карты высот, свет, свежий чанк игрокам. */
    private void relight(LevelChunk chunk) {
        ChunkPos pos = chunk.getPos();
        ThreadedLevelLightEngine light = level.getChunkSource().getLightEngine();
        Heightmap.primeHeightmaps(chunk, EnumSet.allOf(Heightmap.Types.class));
        chunk.initializeLightSources();
        light.propagateLightSources(pos);
        chunk.setUnsaved(true);
        ClientboundLevelChunkWithLightPacket packet =
                new ClientboundLevelChunkWithLightPacket(chunk, light, (BitSet) null, (BitSet) null);
        for (ServerPlayer player : level.getChunkSource().chunkMap.getPlayers(pos, false)) {
            player.connection.send(packet);
        }
    }

    long removed() {
        return removed;
    }
}
