package com.invfix.heatdisruption;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.heatvision.HeatVisionGeometry;
import net.mcreator.invincibleinc.init.InvincibleIncModGameRules;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Heat Disruption — способность Metroman (Alien(Metroman)), LVL 500.
 *
 * Таймлайн, тиков от нажатия:
 *  0–7    зарядка 0.35 с: голова и тело заблокированы, глаза разгораются красным;
 *  7–47   луч 2 с по направлению взгляда на момент нажатия. Голова луча уходит
 *         на {@link HeatDisruptionShape#LENGTH} блоков за 5 тиков; за ней
 *         сносится параболический конус радиусом до 9 блоков
 *         ({@link HeatDisruptionShape}); всё живое внутри получает половину
 *         Attackpwr стрелявшего раз в 2 тика (0.1 с);
 *  47–55  луч сужается и гаснет; блокировка снимается на 55-м тике.
 * После — на стенках выжженного ещё ~30 с светится остывающий жар (клиент).
 *
 * Блокировка: голова — мышь на клиенте стрелявшего (HeatDisruptionMouseLockMixin),
 * тело — ввод движения (HeatDisruptionInputLockMixin) и удержание на месте
 * нажатия без скорости (HeatDisruptionClient). Тело инертно: при нажатии
 * скорость обнуляется сразу, как бы игрок ни двигался (бег, полёт). Сервер
 * держит то же самое — поворот, нулевую скорость и место, уход дальше
 * {@link #ANCHOR_SLACK} возвращает телепортом.
 *
 * Сносится всё, кроме бедрока. Снос включается геймрулом invincibleBlockDestruction,
 * как остальные разрушения Invincible.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class HeatDisruptionHandler {

    public static final String ABILITY = "§4§lHeat Disruption";
    public static final int LVL_REQUIRED = 500;

    public static final int CHARGE_TICKS = 7;
    public static final int FIRE_TICKS = 40;
    public static final int COLLAPSE_TICKS = 8;
    /** Вся способность (и блокировка головы), тиков. */
    public static final int TOTAL_TICKS = CHARGE_TICKS + FIRE_TICKS + COLLAPSE_TICKS;
    /** Скорость головы луча, блоков за тик: 500 блоков за 5 тиков. */
    public static final double HEAD_SPEED = 100.0;
    /** Урон раз в столько тиков. */
    private static final int DAMAGE_INTERVAL = 2;
    /** После конца способности — столько тиков до следующего нажатия (удержание клавиши не стреляет очередью). */
    private static final int REARM_TICKS = 20;
    /** Насколько тело может уйти от места нажатия, прежде чем сервер вернёт его телепортом, блоков. */
    private static final double ANCHOR_SLACK = 0.75;
    /** Кому слать пакет: от середины луча в таком радиусе. */
    private static final double SEND_RANGE = 640.0;

    private static final ResourceKey<DamageType> DAMAGE = ResourceKey.create(Registries.DAMAGE_TYPE,
            ResourceLocation.parse("sable_compat:heat_disruption"));

    private static final class Cast {
        final ServerLevel level;
        final Vec3 origin;
        final Vec3 dir;
        final float yRot, xRot;
        /** Где стояло тело при нажатии — его держит на месте всю способность. */
        final Vec3 anchor;
        final HeatDisruptionCarver carver;
        /** Размер выжигания: обычный или режима Sentry (кратно больше). */
        final HeatDisruptionShape shape;
        final boolean sentry;
        int age;

        Cast(ServerLevel level, Vec3 origin, Vec3 dir, float yRot, float xRot, Vec3 anchor, HeatDisruptionCarver carver,
             boolean sentry) {
            this.sentry = sentry;
            this.shape = HeatDisruptionShape.of(sentry);
            this.level = level;
            this.origin = origin;
            this.dir = dir;
            this.yRot = yRot;
            this.xRot = xRot;
            this.anchor = anchor;
            this.carver = carver;
        }
    }

    private static final Map<UUID, Cast> CASTS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> ENDED = new ConcurrentHashMap<>();

    private HeatDisruptionHandler() {}

    public static boolean isEligible(String race) {
        return AltrumiteRace.isAltrumite(race);
    }

    public static boolean isActive(ServerPlayer player) {
        return CASTS.containsKey(player.getUUID());
    }

    // ── нажатие ────────────────────────────────────────────────────────────

    public static void activate(ServerPlayer player) {
        try {
            InvincibleIncModVariables.PlayerVariables v = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (!isEligible(v.Race) || v.Lvl < LVL_REQUIRED) return;
            if (CASTS.containsKey(player.getUUID())) return;
            ServerLevel level = (ServerLevel) player.level();
            Long ended = ENDED.get(player.getUUID());
            if (ended != null && level.getGameTime() - ended < REARM_TICKS) return;

            Vec3 look = player.getLookAngle();
            if (look.lengthSqr() < 1.0E-6) return;
            Vec3 dir = look.normalize();
            Vec3 origin = HeatVisionGeometry.getDynamicEyeBase(player, 1.0F);
            boolean carve = level.getGameRules().getBoolean(InvincibleIncModGameRules.INVINCIBLE_BLOCK_DESTRUCTION);

            // The Whole Sentry Power: кратно сильнее — радиус и длина ×2, луч толще, урон ещё ×2, палитра нейтронной звезды
            boolean sentry = com.invfix.sentry.SentryHandler.isActive(player);
            HeatDisruptionShape shape = HeatDisruptionShape.of(sentry);
            Cast cast = new Cast(level, origin, dir, player.getYRot(), player.getXRot(), player.position(),
                    carve ? new HeatDisruptionCarver(level, origin, dir, shape) : null, sentry);
            // инертно: что бы ни делало тело, оно встаёт сразу
            player.setDeltaMovement(Vec3.ZERO);
            player.hurtMarked = true;
            CASTS.put(player.getUUID(), cast);

            float seed = (float) (level.random.nextInt(65536) / 65535.0);
            Vec3 mid = origin.add(dir.scale(shape.length * 0.5));
            PacketDistributor.sendToPlayersNear(level, null, mid.x, mid.y, mid.z, SEND_RANGE,
                    new HeatDisruptionPacket(player.getId(), origin.x, origin.y, origin.z,
                            (float) dir.x, (float) dir.y, (float) dir.z, seed, carve, sentry));
        } catch (Exception ignored) {}
    }

    // ── тик ────────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (CASTS.isEmpty()) return;
        Iterator<Map.Entry<UUID, Cast>> it = CASTS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Cast> e = it.next();
            Cast cast = e.getValue();
            if (cast.level != level) continue;
            ServerPlayer player = level.getServer().getPlayerList().getPlayer(e.getKey());
            try {
                if (!tick(cast, player)) {
                    if (cast.carver != null) cast.carver.finish();
                    it.remove();
                    ENDED.put(e.getKey(), level.getGameTime());
                }
            } catch (Exception ex) {
                it.remove();
                ENDED.put(e.getKey(), level.getGameTime());
            }
        }
    }

    /** false — способность закончилась. */
    private static boolean tick(Cast cast, ServerPlayer player) {
        int age = cast.age++;
        boolean alive = player != null && player.isAlive() && player.level() == cast.level;

        // голова держится там, куда смотрела при нажатии
        if (alive && age < TOTAL_TICKS) {
            player.setYRot(cast.yRot);
            player.setXRot(cast.xRot);
            player.setYHeadRot(cast.yRot);
            // тело стоит там, где было при нажатии: без скорости, без падения
            player.setDeltaMovement(Vec3.ZERO);
            player.fallDistance = 0.0F;
            if (player.position().distanceToSqr(cast.anchor) > ANCHOR_SLACK * ANCHOR_SLACK) {
                player.connection.teleport(cast.anchor.x, cast.anchor.y, cast.anchor.z, cast.yRot, cast.xRot);
            }
        }

        int fire = age - CHARGE_TICKS;
        double head = fire < 0 ? 0.0 : Math.min(cast.shape.length, HEAD_SPEED * (fire + 1));
        if (cast.carver != null && fire >= 0) cast.carver.tick(head);

        if (alive && fire >= 0 && fire < FIRE_TICKS && fire % DAMAGE_INTERVAL == 0) {
            burn(cast, player, head);
        }

        boolean carving = cast.carver != null && !cast.carver.done();
        return age < TOTAL_TICKS || carving;
    }

    /** Всё живое в конусе — половина Attackpwr стрелявшего; выпавшие предметы сгорают. */
    private static void burn(Cast cast, ServerPlayer player, double head) {
        double ap;
        try {
            ap = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES).attackPower;
        } catch (Exception e) {
            return;
        }
        // в режиме Sentry — ещё ×2 сверх общего ×2 режима (SentryHandler)
        float damage = (float) (ap * 0.5 * (cast.sentry ? 2.0 : 1.0));
        Vec3 origin = HeatVisionGeometry.getDynamicEyeBase(player, 1.0F);
        Vec3 dir = cast.dir;
        Vec3 end = origin.add(dir.scale(head));
        AABB box = new AABB(origin, end).inflate(cast.shape.radius + 2.0);
        ServerLevel level = cast.level;

        if (damage > 0.0F) {
            DamageSource source = new DamageSource(level.holderOrThrow(DAMAGE), player);
            for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box,
                    t -> t != player && t.isAlive())) {
                Vec3 c = target.getBoundingBox().getCenter();
                if (!cast.shape.hits(origin, dir, head, c, target.getBbWidth() * 0.5)) continue;
                target.invulnerableTime = 0;
                target.hurtTime = 0;
                target.hurt(source, damage);
            }
        }
        for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, box, i -> !i.isRemoved())) {
            if (cast.shape.hits(origin, dir, head, item.position(), 0.5)) item.discard();
        }
    }
}
