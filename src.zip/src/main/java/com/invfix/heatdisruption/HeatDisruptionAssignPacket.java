package com.invfix.heatdisruption;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Клиент → Сервер: выбрать Heat Disruption как текущую способность (для назначения в слот). */
public record HeatDisruptionAssignPacket(int x, int y, int z) implements CustomPacketPayload {

    public static final Type<HeatDisruptionAssignPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "hd_assign"));

    public static final StreamCodec<FriendlyByteBuf, HeatDisruptionAssignPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, m) -> { buf.writeInt(m.x()); buf.writeInt(m.y()); buf.writeInt(m.z()); },
                    buf -> new HeatDisruptionAssignPacket(buf.readInt(), buf.readInt(), buf.readInt()));

    @Override public Type<HeatDisruptionAssignPacket> type() { return TYPE; }

    public static void handleServer(HeatDisruptionAssignPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer player)) return;
            try {
                InvincibleIncModVariables.PlayerVariables vars =
                        player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                if (!HeatDisruptionHandler.isEligible(vars.Race)) return;
                if (vars.Lvl < HeatDisruptionHandler.LVL_REQUIRED) return;
                vars.AbilitySet = HeatDisruptionHandler.ABILITY;
                vars.abilityDescription = HeatDisruptionHandler.ABILITY + " | LVL:"
                        + HeatDisruptionHandler.LVL_REQUIRED + " | Тепловой луч";
                vars.markSyncDirty();
            } catch (Exception ignored) {}
        });
    }
}
