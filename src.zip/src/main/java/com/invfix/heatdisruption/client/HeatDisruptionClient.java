package com.invfix.heatdisruption.client;

import com.invfix.heatdisruption.HeatDisruptionHandler;
import com.invfix.heatvision.client.HeatVisionRenderer;
import com.invfix.fx.FxManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Клиент Heat Disruption: запуск эффекта по пакету, блокировка у стрелявшего —
 * головы (HeatDisruptionMouseLockMixin) и тела (HeatDisruptionInputLockMixin
 * плюс удержание на месте нажатия с нулевой скоростью: тело инертно, бег или
 * полёт обрываются сразу) — и красное свечение глаз — то же
 * свечение, что у Heat Vision (HeatVisionRenderer, внешний источник), пока
 * идёт зарядка и луч.
 */
@OnlyIn(Dist.CLIENT)
public final class HeatDisruptionClient {

    /** id игрока → сколько тиков ещё гореть глазам. */
    private static final Map<Integer, Integer> GLOW = new ConcurrentHashMap<>();
    /** Чьи глаза горят бело-голубым (Heat Disruption в режиме Sentry). */
    private static final java.util.Set<Integer> BLUE = ConcurrentHashMap.newKeySet();
    /** Сколько тиков ещё заблокированы своя голова и тело. */
    private static int lockTicks;
    /** Где своё тело стояло при нажатии. */
    private static Vec3 anchor;

    private HeatDisruptionClient() {}

    public static void start(int casterId, double x, double y, double z, float dx, float dy, float dz,
                             float seed, boolean carve, boolean sentry) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        Vec3 dir = new Vec3(dx, dy, dz);
        if (dir.lengthSqr() < 1.0E-6) return;
        dir = dir.normalize();
        boolean mine = mc.player != null && mc.player.getId() == casterId;
        if (mine) {
            lockTicks = HeatDisruptionHandler.TOTAL_TICKS;
            anchor = mc.player.position();
            mc.player.setDeltaMovement(Vec3.ZERO);
        }
        if (sentry) BLUE.add(casterId); else BLUE.remove(casterId);
        GLOW.put(casterId, HeatDisruptionHandler.CHARGE_TICKS + HeatDisruptionHandler.FIRE_TICKS
                + HeatDisruptionHandler.COLLAPSE_TICKS / 2);
        FxManager.add(new HeatDisruptionFx(level, casterId, new Vec3(x, y, z), dir, seed, carve, mine, sentry));
    }

    /** Своя голова и тело заблокированы (мышь не крутит камеру, клавиши не двигают). */
    public static boolean headLocked() {
        return lockTicks > 0;
    }

    /** Глаза горят бело-голубым, а не красным. */
    public static boolean eyesBlue(int entityId) {
        return BLUE.contains(entityId) && GLOW.containsKey(entityId);
    }

    public static boolean eyesGlowing(int entityId) {
        return GLOW.containsKey(entityId);
    }

    private static void reset() {
        GLOW.clear();
        BLUE.clear();
        lockTicks = 0;
        anchor = null;
    }

    /** Тело — на месте нажатия, без скорости (до и после тика игрока, чтобы не дёргалось). */
    private static void hold() {
        Minecraft mc = Minecraft.getInstance();
        if (lockTicks <= 0 || anchor == null || mc.player == null) return;
        mc.player.setDeltaMovement(Vec3.ZERO);
        mc.player.setPos(anchor.x, anchor.y, anchor.z);
        mc.player.fallDistance = 0.0F;
    }

    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
    public static final class GameBus {

        @SubscribeEvent
        public static void onClientTickPre(ClientTickEvent.Pre event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null || mc.isPaused()) return;
            hold();
        }

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) {
                reset();
                return;
            }
            if (mc.isPaused()) return;
            hold();
            if (lockTicks > 0) lockTicks--;
            if (lockTicks <= 0) anchor = null;
            GLOW.replaceAll((id, t) -> t - 1);
            GLOW.values().removeIf(t -> t <= 0);
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            reset();
        }
    }

    @EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {

        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {
            event.enqueueWork(() -> HeatVisionRenderer.addGlowSource(p -> eyesGlowing(p.getId())));
        }
    }
}
