package com.invfix.heatdisruption.client;

import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.function.Supplier;

/**
 * Звук, который каждый тик переезжает в точку where (у луча — ближайшая к
 * камере точка луча, как «ухо» у StarFx) и может плавно стихнуть. Громкость
 * больше 1 — дальность: как в The Shooting Star, range = 16 × volume.
 */
@OnlyIn(Dist.CLIENT)
final class HeatDisruptionSound extends AbstractTickableSoundInstance {

    private final Supplier<Vec3> where;
    private final float baseVolume;
    private int fadeTicks = -1;
    private int fadeLeft;

    HeatDisruptionSound(SoundEvent event, float volume, Supplier<Vec3> where) {
        super(event, SoundSource.PLAYERS, SoundInstance.createUnseededRandom());
        this.where = where;
        this.baseVolume = volume;
        this.volume = volume;
        this.pitch = 1.0F;
        this.looping = false;
        this.delay = 0;
        Vec3 p = where.get();
        this.x = p.x;
        this.y = p.y;
        this.z = p.z;
    }

    /** Стихнуть за ticks тиков и остановиться. */
    void fadeOut(int ticks) {
        if (fadeTicks >= 0) return;
        fadeTicks = Math.max(1, ticks);
        fadeLeft = fadeTicks;
    }

    @Override
    public void tick() {
        Vec3 p = where.get();
        if (p == null) {
            stop();
            return;
        }
        this.x = p.x;
        this.y = p.y;
        this.z = p.z;
        if (fadeTicks >= 0) {
            fadeLeft--;
            if (fadeLeft <= 0) {
                stop();
                return;
            }
            this.volume = baseVolume * fadeLeft / (float) fadeTicks;
        }
    }
}
