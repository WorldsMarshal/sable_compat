package com.invfix.heatdisruption.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import com.invfix.heatdisruption.HeatDisruptionHandler;
import com.invfix.heatdisruption.HeatDisruptionShape;
import com.invfix.heatdisruption.HeatDisruptionSounds;
import com.invfix.heatvision.HeatVisionGeometry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.List;

/**
 * Heat Disruption на клиенте — по образцу рельсотрона The Shooting Star
 * (StarFx + star_beam.fsh): мировой проход heat_disruption.fsh, ударная волна
 * первых мгновений (тот же shockwave.fsh, что у тяжёлых ударов, алая),
 * параметры композита по таймлайну и звуки The Shooting Star.
 *
 * Таймлайн, тиков (как у сервера, HeatDisruptionHandler):
 *  0–7      зарядка: глаза разгораются (свечение Heat Vision), у самого
 *           стрелявшего от первого лица — красная виньетка;
 *  7        выстрел: голова луча уходит на 500 блоков за 5 тиков; вспышка у
 *           глаз, импакт-кадры 0.3 с (белое и красное, рисунок рельсотрона),
 *           ударная волна — кольца по лучу, сфера, волна пыли, цилиндрический
 *           скачок вдоль всего луча; тряска;
 *  7–47     луч: жирный, белый в сердце, красный к краю, по нему бежит энергия;
 *           воздух вокруг светится, мир рядом подсвечен красным, остальное
 *           уходит в тёмно-красную тень;
 *  47–55    луч сужается в нить и гаснет;
 *  55–655   стенки выжженного светятся и остывают (если луч сносил блоки).
 */
@OnlyIn(Dist.CLIENT)
public final class HeatDisruptionFx extends FxEffect {

    private static final int CHARGE = HeatDisruptionHandler.CHARGE_TICKS;
    private static final int FIRE_END = CHARGE + HeatDisruptionHandler.FIRE_TICKS;
    private static final int GONE = HeatDisruptionHandler.TOTAL_TICKS;
    /** Сколько живут горячие стенки после луча, тиков. */
    private static final int COOL_TICKS = 600;
    /** Импакт-кадры выстрела видны ближе этого к лучу. */
    private static final double FRAMES_RANGE = 128.0;

    private final ClientLevel level;
    private final int casterId;
    private final Vec3 origin;
    private final Vec3 dir;
    private final float seed;
    private final boolean carve;
    private final boolean mine;
    /** Режим The Whole Sentry Power: размер кратно больше, палитра нейтронной звезды. */
    private final boolean sentry;
    private final HeatDisruptionShape shape;

    private HeatDisruptionSound beamSound;

    HeatDisruptionFx(ClientLevel level, int casterId, Vec3 origin, Vec3 dir, float seed, boolean carve, boolean mine,
                     boolean sentry) {
        this.sentry = sentry;
        this.shape = HeatDisruptionShape.of(sentry);
        this.level = level;
        this.casterId = casterId;
        this.origin = origin;
        this.dir = dir;
        this.seed = seed;
        this.carve = carve;
        this.mine = mine;
    }

    @Override
    protected int duration() {
        return carve ? GONE + COOL_TICKS : GONE + 20;
    }

    @Override
    public boolean finished() {
        return super.finished() || Minecraft.getInstance().level != level;
    }

    @Override
    protected void onRemoved() {
        if (beamSound != null) beamSound.fadeOut(1);
    }

    @Override
    public Vec3 focus() {
        return origin.add(dir.scale(shape.length * 0.5));
    }

    @Override
    public double range() {
        return shape.length * 0.5 + 400.0;
    }

    // ── где сейчас луч ─────────────────────────────────────────────────────

    /** Откуда луч выходит сейчас: глаза стрелявшего (если он рядом), иначе — глаза при нажатии. */
    private Vec3 muzzle(float partial) {
        Entity e = level.getEntity(casterId);
        if (e instanceof LivingEntity le && le.isAlive()) {
            return HeatVisionGeometry.getDynamicEyeBase(le, partial).add(dir.scale(0.2));
        }
        return origin;
    }

    private double head(float t) {
        return Mth.clamp((t - CHARGE) * HeatDisruptionHandler.HEAD_SPEED, 0.0, shape.length);
    }

    /** Ближайшая к камере точка луча — туда ставится звук, как «ухо» у StarFx. */
    private Vec3 ear(Vec3 from, double length) {
        Vec3 a = muzzle(1.0F);
        double s = Mth.clamp(from.subtract(a).dot(dir), 0.0, Math.max(length, 0.0));
        return a.add(dir.scale(s));
    }

    // ── звук ───────────────────────────────────────────────────────────────

    private void play(SoundEvent event, Vec3 at, float volume) {
        Minecraft.getInstance().getSoundManager().play(new SimpleSoundInstance(event.getLocation(), SoundSource.PLAYERS,
                volume * 16.0F, 1.0F, SoundInstance.createUnseededRandom(), false, 0,
                SoundInstance.Attenuation.LINEAR, at.x, at.y, at.z, false));
    }

    @Override
    protected void onTick(Minecraft minecraft, ClientLevel level, int t) {
        Vec3 cam = FxManager.camera();
        if (t == 0) {
            play(HeatDisruptionSounds.CHARGE.get(), muzzle(1.0F), 0.8F);
            // в начале star_beam 0.4 с тишины — рёв приходится ровно на выстрел
            beamSound = new HeatDisruptionSound(HeatDisruptionSounds.BEAM.get(), 16.0F,
                    () -> ear(FxManager.camera(), head(age)));
            minecraft.getSoundManager().play(beamSound);
        }
        if (t == CHARGE) {
            Vec3 m = muzzle(1.0F);
            play(HeatDisruptionSounds.FIRE.get(), m, 1.0F);
            play(HeatDisruptionSounds.IMPACT.get(), m, 1.0F);
            FxManager.shake(m, 1.0F, 220.0);
        }
        if (t == FIRE_END && beamSound != null) {
            beamSound.fadeOut(GONE - FIRE_END);
            play(HeatDisruptionSounds.COLLAPSE.get(), ear(cam, shape.length), 1.0F);
        }
        if (t == GONE && carve) {
            play(HeatDisruptionSounds.AFTER.get(), ear(cam, shape.length), 0.6F);
        }
        if (t > CHARGE && t < FIRE_END && t % 5 == 0) {
            FxManager.shake(ear(cam, head(t)), 0.18F, 160.0);
        }
    }

    // ── проходы ────────────────────────────────────────────────────────────

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        float t = ticks(frame);
        float since = (t - CHARGE) / 20.0F;
        float beam = window(t, CHARGE, CHARGE + 0.5F, GONE - 1.0F, GONE + 0.5F);
        float collapse = Mth.clamp((t - FIRE_END) / (GONE - FIRE_END), 0.0F, 1.0F);
        float charge = t < CHARGE ? smooth(t / CHARGE) : 1.0F - smooth((t - CHARGE) / 4.0F);
        float head = (float) head(t);
        boolean firstPerson = mine && frame.minecraft().options.getCameraType().isFirstPerson();
        float own = firstPerson ? 1.0F : 0.0F;
        // стенки: разгораются, пока луч гаснет, и остывают ~10 с (tau), к концу — в ноль
        float heat = carve ? smooth((t - FIRE_END + 3.0F) / 10.0F) * (float) Math.exp(-Math.max(0.0F, t - GONE) / 200.0F)
                * (1.0F - smooth((t - GONE - COOL_TICKS + 60.0F) / 60.0F)) : 0.0F;
        float muzzleFlare = t < CHARGE ? 0.0F : (0.55F + 0.45F * (float) Math.exp(-since / 0.15F)) * beam;

        if (beam <= 0.001F && heat <= 0.001F && charge <= 0.001F) return;

        Vec3 a = frame.rel(muzzle(frame.partial()));
        Vec3 c = frame.rel(origin);
        float seconds = t / 20.0F;
        out.add(new FxPass("heat_disruption", u -> {
            u.v3("Target", a);
            u.v3("Caster", c);
            u.v3("Facing", dir);
            u.f4("P0", seconds, since, seed, beam);
            u.f4("P1", head, collapse, charge, own);
            u.f4("P2", heat, (float) HeatDisruptionShape.CLEAR, (float) HeatDisruptionShape.FLARE,
                    (float) shape.radius);
            u.f4("P3", (float) shape.length, (float) shape.beamRadius, muzzleFlare, sentry ? 1.0F : 0.0F);
        }));

        // ударная волна первых мгновений: кольца по лучу, сфера, волна пыли — алая
        if (since >= 0.0F && since < 2.0F) {
            float s = since;
            float ring = 2.0F + 26.0F * (1.0F - (float) Math.exp(-s / 0.25F));
            float travel = 34.0F * (1.0F - (float) Math.exp(-s / 0.4F));
            float thick = 0.6F + s * 1.2F;
            float shell = 3.0F + s * 70.0F;
            float ground = 2.0F + 40.0F * (1.0F - (float) Math.exp(-s / 0.45F));
            float band = 2.0F + s * 4.0F;
            // своя камера от первого лица — у самых глаз: волна отнесена дальше по лучу, вспышка слабее
            boolean ownView = mine && frame.minecraft().options.getCameraType().isFirstPerson();
            float flash = (ownView ? 0.6F : 2.2F) * (float) Math.exp(-s / 0.08F);
            float k = 1.0F - smooth((s - 0.8F) / 1.0F);
            Vec3 shockAt = frame.rel(muzzle(frame.partial()).add(dir.scale(ownView ? 8.0 : 3.0)));
            Vec3 cam = frame.camera();
            float ox = (float) (cam.x - 2048.0 * Math.floor(cam.x / 2048.0));
            float oy = (float) (cam.y - 2048.0 * Math.floor(cam.y / 2048.0));
            float oz = (float) (cam.z - 2048.0 * Math.floor(cam.z / 2048.0));
            float sd = seed;
            out.add(new FxPass("shockwave", u -> {
                u.v3("Target", shockAt);
                u.v3("Facing", dir);
                u.f3("Origin", ox, oy, oz);
                u.f4("P0", s, 2.0F, sd, k);
                u.f4("P1", ring, shell, ground, flash);
                u.f4("P2", sentry ? 0.0F : 1.0F, thick, band, travel);
                u.f4("P3", 0.0F, 0.0F, 0.0F, 0.0F);
            }));
        }

        // The Whole Sentry Power: белые разряды вокруг луча у глаз, пока он бьёт
        if (sentry && beam > 0.01F) {
            boolean ownView = mine && frame.minecraft().options.getCameraType().isFirstPerson();
            Vec3 arcAt = frame.rel(muzzle(frame.partial()).add(dir.scale(ownView ? 6.0 : 1.5)));
            Vec3 cam = frame.camera();
            float ox = (float) (cam.x - 2048.0 * Math.floor(cam.x / 2048.0));
            float oy = (float) (cam.y - 2048.0 * Math.floor(cam.y / 2048.0));
            float oz = (float) (cam.z - 2048.0 * Math.floor(cam.z / 2048.0));
            float sd = seed;
            float k = beam * (ownView ? 0.6F : 1.0F);
            out.add(new FxPass("sentry", u -> {
                u.v3("Target", arcAt);
                u.f3("Origin", ox, oy, oz);
                u.f4("P0", (float) shape.beamRadius + 1.5F, 0.0F, seconds, sd);
                u.f4("P1", k, 0.0F, 0.7F, 1.0F);
            }));
        }
    }

    // ── композит ───────────────────────────────────────────────────────────

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        float t = ticks(frame);
        float since = (t - CHARGE) / 20.0F;
        Vec3 cam = frame.camera();
        double length = head(t);
        Vec3 a = muzzle(frame.partial());
        double s = Mth.clamp(cam.subtract(a).dot(dir), 0.0, Math.max(length, 0.0));
        double toBeam = cam.distanceTo(a.add(dir.scale(s)));
        float near = (float) Mth.clamp(1.0 - toBeam / 400.0, 0.15, 1.0);
        boolean firstPerson = mine && frame.minecraft().options.getCameraType().isFirstPerson();

        // зарядка: у самого стрелявшего от первого лица — глаза «горят» по краям кадра
        if (t < CHARGE + 4.0F && firstPerson) {
            float charge = t < CHARGE ? smooth(t / CHARGE) : 1.0F - smooth((t - CHARGE) / 4.0F);
            screen.addVignette(sentry ? 0x8CC0FF : 0x8A0010, charge * 0.5F);
            screen.aberration = Math.max(screen.aberration, charge * 0.3F);
        }

        if (since >= 0.0F && t < GONE + 20.0F) {
            // выстрел: импакт-кадры рельсотрона (белое и красное; в режиме Sentry — белое и голубое), тряска, размытие
            if (toBeam < FRAMES_RANGE || mine) {
                if (sentry) impactSequence(screen, since, a.add(dir.scale(12.0)), 1.0F, 0.05F, 42, 42, 43, 42, 43, 43);
                else impactSequence(screen, since, a.add(dir.scale(12.0)), 1.0F, 0.05F, 7, 7, 8, 7, 8, 8);
            }
            screen.shake = Math.max(screen.shake, window(since, 0.0F, 0.05F, 1.2F, 2.5F) * 0.9F * near);
            screen.aberration = Math.max(screen.aberration, window(since, 0.0F, 0.05F, 0.5F, 1.8F) * near);
            screen.zoomBlur = Math.max(screen.zoomBlur, window(since, 0.0F, 0.03F, 0.35F, 1.2F) * 0.55F * near);
            // луч держит кадр
            float hold = window(t, CHARGE, CHARGE + 5.0F, FIRE_END, GONE);
            screen.bloom = Math.max(screen.bloom, 1.4F * hold);
            screen.bloomRadius = Math.max(screen.bloomRadius, 1.0F + 1.2F * hold);
            screen.addVignette(sentry ? 0x1A2E5A : 0x4A0008, hold * 0.35F * near);
            screen.shake = Math.max(screen.shake, hold * 0.22F * near);
            screen.aberration = Math.max(screen.aberration, hold * 0.12F * near);
            // луч гаснет — вспышка
            float snap = window(t, GONE - 3.0F, GONE, GONE + 2.0F, GONE + 14.0F);
            screen.addFlash(sentry ? 0xD9EDFF : 0xFF3040, snap * 0.3F * near);
            screen.shake = Math.max(screen.shake, snap * 0.4F * near);
        }
    }
}
