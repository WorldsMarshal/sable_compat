package com.invfix.heatdisruption;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Звуки Heat Disruption — файлы как есть (assets/sable_compat/sounds/heat_disruption/):
 *  charge   ← Invincible, atomic sound1 (зарядка, глаза разгораются);
 * остальные — The Shooting Star:
 *  fire     ← star_fire     (выстрел);
 *  impact   ← star_impact   (удар в первый миг луча);
 *  beam     ← star_beam     (рёв луча; в начале файла 0.4 с тишины — его запускают с нажатием,
 *                            рёв приходится ровно на выстрел);
 *  collapse ← star_collapse (луч гаснет);
 *  after    ← star_after    (гул после).
 */
public final class HeatDisruptionSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, "sable_compat");

    public static final DeferredHolder<SoundEvent, SoundEvent> CHARGE = register("heat_disruption_charge");
    public static final DeferredHolder<SoundEvent, SoundEvent> FIRE = register("heat_disruption_fire");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMPACT = register("heat_disruption_impact");
    public static final DeferredHolder<SoundEvent, SoundEvent> BEAM = register("heat_disruption_beam");
    public static final DeferredHolder<SoundEvent, SoundEvent> COLLAPSE = register("heat_disruption_collapse");
    public static final DeferredHolder<SoundEvent, SoundEvent> AFTER = register("heat_disruption_after");

    private static DeferredHolder<SoundEvent, SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath("sable_compat", name)));
    }

    private HeatDisruptionSounds() {}
}
