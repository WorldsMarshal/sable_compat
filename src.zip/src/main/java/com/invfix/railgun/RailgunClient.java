package com.invfix.railgun;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import dev.engine_room.flywheel.lib.visualization.SimpleBlockEntityVisualizer;
import dev.engine_room.flywheel.api.visualization.VisualizerRegistry;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.breech.MediumcannonBreechRenderer;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.breech.MediumcannonBreechVisual;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.recoil_barrel.MediumcannonRecoilBarrelRenderer;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.recoil_barrel.MediumcannonRecoilBarrelVisual;
import riftyboi.cbcmodernwarfare.index.CBCModernWarfareBlockPartials;

/**
 * Клиентская часть рельсовой пушки: падающая часть казённика.
 *
 * Эта деталь нигде не существует как предмет - Modern Warfare рисует её
 * отдельной partial-моделью поверх блока, выбирая модель по материалу пушки.
 * Для незнакомого материала выбор скатывается к чугунной, а у нас казённик
 * оставался вовсе без неё, потому что своей мы не заявили.
 *
 * Заявляется при конструировании мода, а не в клиентской настройке. Партиалы
 * Create должны быть созданы раньше, чем начнётся загрузка моделей: созданная
 * позже просто не попадает в список на загрузку, и рисовать оказывается нечего.
 * Именно так деталь и пропадала, хотя регистрация формально проходила.
 *
 * Класс трогается только на клиенте, поэтому чужие клиентские классы на сервер
 * не тянутся.
 */
@EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class RailgunClient {

    private RailgunClient() {}

    public static void registerPartials() {
        ModList mods = ModList.get();
        if (mods == null || !mods.isLoaded("cbcmodernwarfare")) return;
        CBCModernWarfareBlockPartials.mediumcannonEjectorPartial(
                RailgunMaterial.RAILGUN,
                ResourceLocation.fromNamespaceAndPath(
                        "sable_compat", "item/medium_railgun_falling_breech"));
    }

    /**
     * Рендереры блок-сущностей.
     *
     * Modern Warfare вешает их на свои типы, а типы у нас свои - без этого
     * казённик не рисует ни падающую часть, ни анимацию открытия, а откатный
     * ствол не смещается при выстреле. Классы берутся их же: поведение должно
     * совпадать до мелочей.
     *
     * У простого ствола рендерера нет и у оригинала: он целиком рисуется своей
     * моделью.
     */
    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        ModList mods = ModList.get();
        if (mods == null || !mods.isLoaded("cbcmodernwarfare")) return;
        event.registerBlockEntityRenderer(RailgunRegistry.BREECH_BE.get(),
                MediumcannonBreechRenderer::new);
        event.registerBlockEntityRenderer(RailgunRegistry.RECOIL_BE.get(),
                MediumcannonRecoilBarrelRenderer::new);

        // Внутри контрапции рисует не рендерер, а визуал Flywheel.
        //
        // Пока пушка стоит блоком, затвор рисует BlockEntityRenderer - он у нас
        // теперь есть, и затвор появился. Как только пушка собирается, блок
        // уезжает в контрапцию, а там Create спрашивает визуал по типу
        // блок-сущности. У Modern Warfare визуалы привязаны к их типам, наши им
        // незнакомы - и затвор пропадал ровно в момент сборки.
        //
        // Регистрируем те же визуалы на свои типы. Предикат - тот же, что у них:
        // false означает "не рисовать этот блок обычной моделью поверх визуала".
        VisualizerRegistry.setVisualizer(RailgunRegistry.BREECH_BE.get(),
                new SimpleBlockEntityVisualizer<>(MediumcannonBreechVisual::new, be -> false));
        VisualizerRegistry.setVisualizer(RailgunRegistry.RECOIL_BE.get(),
                new SimpleBlockEntityVisualizer<>(MediumcannonRecoilBarrelVisual::new, be -> false));
    }
}
