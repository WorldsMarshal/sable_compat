package com.invfix.railgun;

import net.minecraft.resources.ResourceLocation;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.material.MediumcannonMaterial;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.material.MediumcannonMaterialProperties;

/**
 * Материал рельсовой пушки.
 *
 * Всё, что отличает рельсотрон от обычной средней пушки, оказалось числами в
 * свойствах материала - ни одного миксина в расчёт не потребовалось. Незеритовая
 * средняя пушка устроена так: база 3 блока в тик, плюс единица за ствол, потолок
 * четырнадцать стволов. Отсюда её 17 блоков в тик, то есть 340 в секунду.
 *
 * Здесь прибавка за ствол одиннадцать вместо единицы. На тех же четырнадцати
 * стволах выходит 3 + 154 = 157 блоков в тик, 3140 в секунду. Число в float
 * точное: 157 представимо без остатка, и скорость, которую получает снаряд,
 * ровно такая, какую считает прицел.
 *
 * Разброс гаснет к третьему стволу: 3 минус 2 за каждый, и ниже нуля он не
 * опускается. На полной длине снаряд вылетает строго по оси, без случайного
 * отклонения, поэтому точность здесь целиком вопрос расчёта.
 *
 * Отдача ноль, и это тоже просто число: рельсовому ускорителю нечем отдавать,
 * пороха в нём нет. Разброс оставлен незеритовый - точность даёт длина ствола, а
 * не способ разгона, и делать оружие ещё и безошибочным было бы перебором.
 *
 * Сварка разрешена, и это не послабление, а необходимость. Незеритовая пушка
 * не сваривается и не соединяется в выживании: её отливают целиком в большой
 * форме. У нас формы нет, детали переделываются поштучно из готовых - и без
 * сварки они не соединились бы ничем, каждая осталась бы отдельной пушкой. Это
 * и есть причина отказа "одно отверстие и один закрытый конец": ствол и
 * казённик просто не считались одной пушкой.
 *
 * Свойства читаются из датапака, как и у остальных материалов, поэтому числа
 * потом правятся без пересборки.
 */
public final class RailgunMaterial {

    private RailgunMaterial() {}

    public static final MediumcannonMaterial RAILGUN = MediumcannonMaterial.register(
            ResourceLocation.fromNamespaceAndPath("sable_compat", "railgun"),
            MediumcannonMaterialProperties.builder()
                    .maxBarrelLength(14)
                    .weight(4.5F)
                    .baseSpread(3.0F)
                    .spreadReductionPerBarrel(2.0F)
                    .baseSpeed(3.0F)
                    .speedIncreasePerBarrel(11.0F)
                    .maxSpeedIncreases(14)
                    .baseRecoil(0.0F)
                    .connectsInSurvival(false)
                    .isWeldable(true)
                    .weldDamage(2)
                    .weldStressPenalty(2)
                    .build());

    /** Заставляет статический блок отработать. Зовётся из регистрации блоков. */
    public static void init() {}
}