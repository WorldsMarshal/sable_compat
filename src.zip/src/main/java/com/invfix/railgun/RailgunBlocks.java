package com.invfix.railgun;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.MediumcannonBarrelBlock;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.MediumcannonBlockEntity;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.breech.MediumcannonBreechBlock;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.breech.MediumcannonBreechBlockEntity;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.material.MediumcannonMaterial;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.recoil_barrel.MediumcannonRecoilBarrelBlock;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.recoil_barrel.MediumcannonRecoilBarrelBlockEntity;

/**
 * Блоки рельсовой пушки.
 *
 * Поведение целиком чужое: сборка, наведение, откат и выстрел - это классы
 * средней пушки Modern Warfare без единой правки. Отличаются только числа
 * материала и то, какой тип блок-сущности блок себе просит.
 *
 * Тип приходится переопределять потому, что оригиналы жёстко возвращают типы из
 * {@code CBCModernWarfareBlockEntities}, а списки допустимых блоков у тех типов
 * закрыты и нашего блока в них нет. Сущность создалась бы и тут же была бы
 * отброшена как чужая.
 */
public final class RailgunBlocks {

    private RailgunBlocks() {}

    /** Ствол. */
    public static class Barrel extends MediumcannonBarrelBlock {
        public Barrel(BlockBehaviour.Properties properties, MediumcannonMaterial material) {
            super(properties, material);
        }

        @Override
        public BlockEntityType<? extends MediumcannonBlockEntity> getBlockEntityType() {
            return RailgunRegistry.BARREL_BE.get();
        }
    }

    /** Казённик. */
    public static class Breech extends MediumcannonBreechBlock {
        public Breech(BlockBehaviour.Properties properties, MediumcannonMaterial material) {
            super(properties, material);
        }

        @Override
        public BlockEntityType<? extends MediumcannonBreechBlockEntity> getBlockEntityType() {
            return RailgunRegistry.BREECH_BE.get();
        }
    }

    /**
     * Ствол с откатом.
     *
     * Функция подвижного блока задана лямбдой прямо здесь, а не приходит
     * параметром. Её тип - {@code NonNullFunction} из Registrate, и называть его
     * в нашем коде незачем: у лямбды целевой тип выводится из сигнатуры
     * конструктора.
     */
    public static class RecoilBarrel extends MediumcannonRecoilBarrelBlock {
        public RecoilBarrel(BlockBehaviour.Properties properties, MediumcannonMaterial material) {
            super(properties, material,
                    facing -> RailgunRegistry.BARREL.get().defaultBlockState()
                            .setValue(MediumcannonBarrelBlock.FACING, facing));
        }

        @Override
        public BlockEntityType<? extends MediumcannonRecoilBarrelBlockEntity> getBlockEntityType() {
            return RailgunRegistry.RECOIL_BE.get();
        }
    }
}
