package com.invfix.railgun;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.MediumcannonBlockEntity;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.breech.MediumcannonBreechBlockEntity;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.recoil_barrel.MediumcannonRecoilBarrelBlockEntity;

/**
 * Регистрация рельсовой пушки.
 *
 * Три блока и три типа блок-сущности, все под нашим пространством имён. Классы
 * блок-сущностей взяты у Modern Warfare как есть - поведение должно совпадать до
 * мелочей, - а типы заводятся свои, потому что списки допустимых блоков у их
 * типов закрыты.
 */
public final class RailgunRegistry {

    private static final String MODID = "sable_compat";

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MODID);

    private RailgunRegistry() {}

    private static BlockBehaviour.Properties props() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_BLACK)
                .strength(8.0F, 12.0F)
                .sound(SoundType.NETHERITE_BLOCK)
                .noOcclusion();
    }

    public static final DeferredBlock<RailgunBlocks.Barrel> BARREL =
            BLOCKS.register("medium_railgun_barrel",
                    () -> new RailgunBlocks.Barrel(props(), RailgunMaterial.RAILGUN));

    public static final DeferredBlock<RailgunBlocks.RecoilBarrel> RECOIL_BARREL =
            BLOCKS.register("medium_railgun_recoil_barrel",
                    () -> new RailgunBlocks.RecoilBarrel(props(), RailgunMaterial.RAILGUN));

    public static final DeferredBlock<RailgunBlocks.Breech> BREECH =
            BLOCKS.register("medium_railgun_breech",
                    () -> new RailgunBlocks.Breech(props(), RailgunMaterial.RAILGUN));

    public static final DeferredItem<BlockItem> BARREL_ITEM =
            ITEMS.register("medium_railgun_barrel",
                    () -> new BlockItem(BARREL.get(), new Item.Properties()));
    public static final DeferredItem<BlockItem> RECOIL_BARREL_ITEM =
            ITEMS.register("medium_railgun_recoil_barrel",
                    () -> new BlockItem(RECOIL_BARREL.get(), new Item.Properties()));
    public static final DeferredItem<BlockItem> BREECH_ITEM =
            ITEMS.register("medium_railgun_breech",
                    () -> new BlockItem(BREECH.get(), new Item.Properties()));

    // Тип передаётся сущности первым аргументом, а не берётся ею самой.
    //
    // Конструкторы Modern Warfare принимают (тип, позиция, состояние), поэтому
    // ссылка на конструктор сюда не подходит - {@code BlockEntitySupplier} даёт
    // только два последних. Лямбда достаёт тип из этого же поля: к моменту
    // первого вызова оно уже заполнено, потому что сущности создаются много
    // позже регистрации.
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MediumcannonBlockEntity>> BARREL_BE =
            BLOCK_ENTITIES.register("medium_railgun_barrel", () -> BlockEntityType.Builder.of(
                    (pos, state) -> new MediumcannonBlockEntity(RailgunRegistry.BARREL_BE.get(), pos, state),
                    BARREL.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MediumcannonRecoilBarrelBlockEntity>> RECOIL_BE =
            BLOCK_ENTITIES.register("medium_railgun_recoil_barrel", () -> BlockEntityType.Builder.of(
                    (pos, state) -> new MediumcannonRecoilBarrelBlockEntity(RailgunRegistry.RECOIL_BE.get(), pos, state),
                    RECOIL_BARREL.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MediumcannonBreechBlockEntity>> BREECH_BE =
            BLOCK_ENTITIES.register("medium_railgun_breech", () -> BlockEntityType.Builder.of(
                    (pos, state) -> new MediumcannonBreechBlockEntity(RailgunRegistry.BREECH_BE.get(), pos, state),
                    BREECH.get()).build(null));

    public static void register(IEventBus modEventBus) {
        // Партиалы Create создаются до загрузки моделей, иначе их не грузят.
        // Клиентский класс трогается только на клиенте.
        if (net.neoforged.fml.loading.FMLEnvironment.dist.isClient()) {
            RailgunClient.registerPartials();
        }
        // Материал должен существовать раньше блоков: они спрашивают его в
        // конструкторе.
        RailgunMaterial.init();
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
    }
}
