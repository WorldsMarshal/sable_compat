package com.invfix.missile;

import dan200.computercraft.api.lua.LuaException;
import dan200.computercraft.api.lua.LuaFunction;
import dan200.computercraft.api.peripheral.IPeripheral;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import rbasamoyai.createbigcannons.munitions.config.DimensionMunitionProperties;
import rbasamoyai.createbigcannons.munitions.config.DimensionMunitionPropertiesHandler;
import rbasamoyai.createbigcannons.munitions.config.components.BallisticPropertiesComponent;

/**
 * The airframe, as the program sees it.
 *
 * Everything here is an actuator or a sensor reading off the missile's own body.
 * There is no setTarget, no waypoint, no lead calculation - if the missile is to
 * hit something, the program computes where to point and writes steer every
 * tick. That is the whole point of these three rockets: the interesting part is
 * the code, and a built-in autopilot would take it away.
 *
 * The same peripheral is present before launch, where it reports the rail's
 * position and refuses to move anything, so a program can spin the motor up,
 * run its checks and arm itself while still a block.
 */
public class MissileControlPeripheral implements IPeripheral {

    private final MissileHost host;

    public MissileControlPeripheral(MissileHost host) {
        this.host = host;
    }

    @Override
    public String getType() {
        return "missile";
    }

    @Override
    public boolean equals(@Nullable IPeripheral other) {
        return other instanceof MissileControlPeripheral p && p.host == this.host;
    }

    private MissileControlState state() {
        return host.controlState();
    }

    // ---- actuators ----

    /**
     * Тяга, 0..1. Без второго аргумента держится, пока не скажут иначе.
     *
     * {@code setThrust(1, 40)} - полный газ ровно на 40 тиков работы двигателя,
     * потом ноль. Отсечку делает сервер, в тиках полёта, так что импульс не
     * зависит от того, когда программа успеет прислать следующую команду.
     * Тики, в которые ракета стоит в ожидании чанков, не считаются.
     * Без топлива тяги нет.
     */
    @LuaFunction
    public final void setThrust(double value, Optional<Integer> ticks) {
        state().setThrust(value, ticks.orElse(-1));
    }

    /**
     * Commanded body rates, each -1 to 1, scaled by the airframe's turn
     * authority. Held until changed - this is a stick position, not an impulse.
     */
    @LuaFunction
    public final void setSteer(double pitch, double yaw) {
        state().setSteer(pitch, yaw);
    }

    /**
     * Команда рулям вектором в мировых осях, в долях предела поворота.
     *
     * Составляющая вдоль направления полёта отбрасывается - рули её дать не
     * могут, - остаток ограничивается длиной 1. Отменяет setSteer и наоборот.
     * Удобна тем, что не вырождается при вертикальном полёте.
     */
    @LuaFunction
    public final void setSteerVector(double x, double y, double z) {
        state().setSteerVector(x, y, z);
    }

    /** Cut the motor and centre the fins in one call. */
    @LuaFunction
    public final void coast() {
        state().neutral();
    }

    /**
     * Пуск с места, по решению программы.
     *
     * Редстоун ракету больше не поднимает: сигнал доходит до компьютера как у
     * любого компьютера ComputerCraft, и что он значит, решает программа.
     *
     * Сразу после возврата ракета ещё не в воздухе: сущность появится и
     * подхватит компьютер на ближайшем тике. До isFlying() == true команды
     * уже пересылаются летящей ракете, но телеметрия может отставать на тик.
     */
    @LuaFunction(mainThread = true)
    public final void launch() throws LuaException {
        if (host.isFlying()) throw new LuaException("already launched");
        if (!host.launch()) throw new LuaException("cannot launch");
    }

    /**
     * Safety. A disarmed warhead ignores detonate() and any self destruct that
     * is already counting down, and can be armed again.
     */
    @LuaFunction
    public final void setArmed(boolean armed) {
        state().armed = armed;
    }

    @LuaFunction
    public final boolean isArmed() {
        return state().armed;
    }

    /** Blow up now. Throws while the missile is still a block on the rail. */
    @LuaFunction(mainThread = true)
    public final void detonate() throws LuaException {
        if (!host.isFlying()) throw new LuaException("not launched");
        if (!state().armed) throw new LuaException("warhead is safe");
        host.detonateNow();
    }

    /** Arm a countdown in ticks, or pass a negative number to cancel it. */
    @LuaFunction
    public final void selfDestruct(int ticks) {
        state().selfDestruct = ticks;
    }

    // ---- sensors on the missile's own body ----

    @LuaFunction
    public final boolean isFlying() {
        return host.isFlying();
    }

    @LuaFunction
    public final Map<String, Object> getPosition() {
        return vec(host.currentPosition());
    }

    @LuaFunction
    public final Map<String, Object> getVelocity() {
        return vec(host.currentVelocity());
    }

    /** Unit vector the nose points along. Equal to velocity direction in flight. */
    @LuaFunction
    public final Map<String, Object> getOrientation() {
        return vec(host.currentOrientation());
    }

    /** Ticks of motor burn left, or -1 before launch when it is not yet fixed. */
    @LuaFunction
    public final int getFuel() {
        return state().fuel;
    }

    /** Полное время работы двигателя этого корпуса, в тиках. Известно и на земле. */
    @LuaFunction
    public final int getBurnTime() {
        return host.burnTicks();
    }

    /**
     * Постоянные, по которым считается полёт, уже с множителями измерения.
     *
     * За тик: скорость += сила, позиция += скорость + сила / 2, где сила -
     * это (0, gravity, 0) - drag * скорость + thrust * дроссель * нос
     * + turn * руль. Нос равен направлению скорости. Двигатель и рули работают,
     * только пока топливо не ноль; топливо тратит только двигатель.
     */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getBallistics() {
        BallisticPropertiesComponent b = host.ballistics();
        Level level = host.hostLevel();
        DimensionMunitionProperties dim = level != null
                ? DimensionMunitionPropertiesHandler.getProperties(level)
                : new DimensionMunitionProperties(1.0, 1.0);
        Map<String, Object> m = new HashMap<>();
        m.put("gravity", b.gravity() * dim.gravityMultiplier());
        m.put("drag", b.drag() * dim.dragMultiplier());
        m.put("quadratic", b.isQuadraticDrag());
        m.put("thrust", MissileProjectile.THRUST_ACCEL);
        m.put("turn", MissileProjectile.TURN_AUTHORITY);
        m.put("burn", host.burnTicks());
        return m;
    }

    /** Ticks since launch, or -1 on the rail. */
    @LuaFunction
    public final int getAge() {
        return host.flightAge();
    }

    @LuaFunction
    public final double getSpeed() {
        return host.currentVelocity().length();
    }

    /** Everything above in one call, for a control loop that wants one round trip. */
    @LuaFunction
    public final Map<String, Object> getTelemetry() {
        Vec3 p = host.currentPosition();
        Vec3 v = host.currentVelocity();
        Vec3 o = host.currentOrientation();
        Map<String, Object> m = new HashMap<>();
        m.put("x", p.x); m.put("y", p.y); m.put("z", p.z);
        m.put("vx", v.x); m.put("vy", v.y); m.put("vz", v.z);
        m.put("ox", o.x); m.put("oy", o.y); m.put("oz", o.z);
        m.put("speed", v.length());
        m.put("fuel", state().fuel);
        m.put("age", host.flightAge());
        m.put("flying", host.isFlying());
        m.put("armed", state().armed);
        m.put("thrust", state().thrust);
        m.put("thrustTicks", state().thrustTicks);
        m.put("burn", host.burnTicks());
        return m;
    }

    private static Map<String, Object> vec(Vec3 v) {
        Map<String, Object> m = new HashMap<>();
        m.put("x", v.x);
        m.put("y", v.y);
        m.put("z", v.z);
        return m;
    }
}
