package com.invfix.missile;

import dan200.computercraft.api.lua.LuaFunction;
import dan200.computercraft.api.peripheral.IPeripheral;
import dan200.computercraft.shared.peripheral.modem.ModemState;
import dan200.computercraft.shared.peripheral.modem.wireless.WirelessModemPeripheral;
import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.companion.math.BoundingBox3d;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.sublevel.SubLevel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3d;
import org.joml.Vector3dc;

/**
 * The two things that turn a programmable rocket into a guided one.
 */
public final class MissilePeripherals {

    private MissilePeripherals() {}

    /**
     * The datalink.
     *
     * An advanced wireless modem, which is to say an ender modem: interdimensional
     * and effectively unlimited in range, on the same packet network as every
     * other modem in the world. That is all it is. Whether the missile trusts
     * what arrives on it is entirely the program's problem - if you want a
     * command channel that cannot be hijacked by anyone with a modem and a
     * channel scanner, you write the authentication yourself.
     */
    public static class Modem extends WirelessModemPeripheral {

        private final MissileHost host;

        public Modem(MissileHost host, ModemState state) {
            super(state, true);
            this.host = host;
        }

        @Override
        public @Nullable Level getLevel() {
            return host.hostLevel();
        }

        @Override
        public Vec3 getPosition() {
            return host.currentPosition();
        }

        @Override
        public boolean equals(@Nullable IPeripheral other) {
            return other instanceof Modem m && m.host == this.host;
        }

        @Override
        public Object getTarget() {
            return host;
        }
    }

    /**
     * The seeker.
     *
     * Reports what is in front of the nose in the same shape Create Radar's
     * peripherals use - a list of tracks with position, velocity and distance -
     * so a program written against a ground radar needs no changes to run on the
     * missile. It finds two kinds of thing: Sable sub-levels, which is what a
     * ship or another missile actually is, and ordinary entities large enough to
     * return anything.
     *
     * It does not lock, it does not filter and it does not choose. It answers
     * "what is out there" and hands the list over; deciding which of those
     * contacts is the target, and staying on it when a second one crosses the
     * beam, is the interesting part and it belongs in Lua.
     */
    public static class Radar implements IPeripheral {

        /** Beam half-angle in degrees. A real seeker cannot see behind itself. */
        private static final double CONE_DEGREES = 45.0;
        private static final double RANGE = 512.0;

        private final MissileHost host;

        public Radar(MissileHost host) {
            this.host = host;
        }

        @Override
        public String getType() {
            return "missile_radar";
        }

        @Override
        public boolean equals(@Nullable IPeripheral other) {
            return other instanceof Radar r && r.host == this.host;
        }

        @LuaFunction
        public final double getRange() {
            return RANGE;
        }

        @LuaFunction
        public final double getConeAngle() {
            return CONE_DEGREES;
        }

        @LuaFunction(mainThread = true)
        public final List<Map<String, Object>> getTracks() {
            List<Map<String, Object>> out = new ArrayList<>();
            Level level = host.hostLevel();
            if (level == null || level.isClientSide) return out;

            Vec3 origin = host.currentPosition();
            Vec3 look = host.currentOrientation();
            if (look.lengthSqr() < 1.0E-9) return out;
            look = look.normalize();
            double cosLimit = Math.cos(Math.toRadians(CONE_DEGREES));

            AABB box = new AABB(origin, origin).inflate(RANGE);
            for (Entity e : level.getEntities((Entity) null, box, x -> !x.isSpectator())) {
                if (e == host) continue;
                Vec3 to = e.position().subtract(origin);
                double dist = to.length();
                if (dist < 1.0E-6 || dist > RANGE) continue;
                if (to.scale(1.0 / dist).dot(look) < cosLimit) continue;
                out.add(track(e.getStringUUID(), e.getType().toString(), e.position(),
                        e.getDeltaMovement(), dist));
            }

            // A ship is not an entity - it is a sub-level - so it has to be found
            // separately or the seeker would be blind to the only targets worth
            // shooting at. Whatever the missile is itself sitting inside is
            // skipped, otherwise it would lock onto its own launcher.
            try {
                SubLevel self = Sable.HELPER.getContaining(level, origin.x, origin.z);
                BoundingBox3d bounds = new BoundingBox3d(
                        origin.x - RANGE, origin.y - RANGE, origin.z - RANGE,
                        origin.x + RANGE, origin.y + RANGE, origin.z + RANGE);
                for (Object o : Sable.HELPER.getAllIntersecting(level, bounds)) {
                    if (!(o instanceof ServerSubLevel sub) || sub == self) continue;
                    Vector3dc p = sub.logicalPose().position();
                    Vec3 pos = new Vec3(p.x(), p.y(), p.z());
                    Vec3 to = pos.subtract(origin);
                    double dist = to.length();
                    if (dist < 1.0E-6 || dist > RANGE) continue;
                    if (to.scale(1.0 / dist).dot(look) < cosLimit) continue;
                    Vector3d v = sub.latestLinearVelocity;
                    out.add(track(sub.getUniqueId().toString(), "sublevel", pos,
                            new Vec3(v.x, v.y, v.z), dist));
                }
            } catch (Throwable ignored) {
                // Sable absent or mid-teardown: entity contacts still stand
            }
            return out;
        }

        private static Map<String, Object> track(String id, String type, Vec3 pos, Vec3 vel, double dist) {
            Map<String, Object> m = new HashMap<>();
            m.put("id", id);
            m.put("type", type);
            m.put("x", pos.x);
            m.put("y", pos.y);
            m.put("z", pos.z);
            m.put("vx", vel.x);
            m.put("vy", vel.y);
            m.put("vz", vel.z);
            m.put("distance", dist);
            return m;
        }
    }
}
