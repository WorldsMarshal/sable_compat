package com.invfix.missile;

import net.minecraft.world.entity.EntityType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import rbasamoyai.createbigcannons.munitions.big_cannon.BigCannonProjectileRenderer;

/**
 * Рендерер для летящих ракет.
 *
 * Без него клиент падает, и падает не в момент выстрела, а на первом же кадре,
 * в котором ракета попадает в поле зрения: {@code EntityRenderDispatcher}
 * берёт рендерер по типу сущности, получает null и разыменовывает его без
 * проверки. В отчёте это выглядит как NullPointerException глубоко внутри
 * ванильного рендера уровня, без единого упоминания нашего мода.
 *
 * До сих пор это не всплывало по простой причине: ракета ни разу не взлетала.
 * Собрать её сущность умел только казённик, а с земли по красному сигналу она
 * поднялась впервые - и сразу показала дыру.
 *
 * Берётся рендерер самого Create Big Cannons, тот же, которым рисуются все
 * снаряды большой пушки. Ракета от них не отличается ничем, что касается
 * отрисовки: у неё есть блочное состояние, есть ориентация, и рисуется она этим
 * блоком, развёрнутым по направлению полёта.
 */
@EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class MissileClient {

    private MissileClient() {}

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        for (DeferredHolder<EntityType<?>, EntityType<MissileProjectile>> holder
                : MissileRegistry.allEntityTypes()) {
            event.registerEntityRenderer(holder.get(), BigCannonProjectileRenderer::new);
        }
    }
}