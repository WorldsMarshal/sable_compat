package com.invfix.missile;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import rbasamoyai.createbigcannons.munitions.AbstractCannonProjectile;
import rbasamoyai.createbigcannons.index.CBCMunitionPropertiesHandlers;
import rbasamoyai.createbigcannons.munitions.config.MunitionPropertiesHandler;

/**
 * Регистрация восемнадцати ракет: шесть корпусов на три варианта наведения.
 *
 * Всё живёт в пространстве имён {@code cbcmoreshells}, а не в нашем. Так и
 * задумано: модели, текстуры и сами корпуса взяты у этого мода, ракеты
 * попадают в его вкладку и стоят в списках рядом с родственниками. Идентификаторы
 * начинаются с приставки наведения ({@code programmable_}, {@code sarh_},
 * {@code arh_}), которой у автора нет, так что столкнуться с его будущими
 * предметами они не могут.
 *
 * Тип блок-сущности один на все восемнадцать - компьютер везде одинаковый, а
 * корпус и наведение читаются из блока. Типы сущностей приходится заводить
 * отдельно на каждую комбинацию: CBC привязывает баллистику и заряд боеприпаса
 * именно к типу сущности, а бронебойная пушечная и фугасная стеллажная должны
 * отличаться.
 */
public final class MissileRegistry {

    /** Чужое пространство имён - см. комментарий к классу. */
    public static final String MODID = "cbcmoreshells";

    /** Вкладка cbcmoreshells. Её содержимое задано списком, поэтому дописываемся событием. */
    private static final ResourceKey<CreativeModeTab> TAB =
            ResourceKey.create(Registries.CREATIVE_MODE_TAB,
                    ResourceLocation.fromNamespaceAndPath(MODID, "shells"));

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MODID);
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MODID);

    /** Ключ карты - пара наведения и корпуса. */
    public record Key(MissileVariant variant, MissileChassis chassis) {}

    private static final Map<Key, DeferredBlock<MissileBlock>> BLOCKS_BY_KEY = new LinkedHashMap<>();
    private static final Map<Key, DeferredItem<BlockItem>> ITEMS_BY_KEY = new LinkedHashMap<>();
    private static final Map<Key, DeferredHolder<EntityType<?>, EntityType<MissileProjectile>>>
            ENTITIES_BY_KEY = new LinkedHashMap<>();

    static {
        for (MissileVariant variant : MissileVariant.values()) {
            for (MissileChassis chassis : MissileChassis.values()) {
                Key key = new Key(variant, chassis);
                String id = variant.id(chassis);

                BLOCKS_BY_KEY.put(key, BLOCKS.register(id,
                        () -> new MissileBlock(BlockBehaviour.Properties.of()
                                .mapColor(MapColor.METAL)
                                .strength(3.0F)
                                .sound(SoundType.NETHERITE_BLOCK)
                                .noOcclusion(), variant, chassis)));

                ITEMS_BY_KEY.put(key, ITEMS.register(id,
                        () -> new BlockItem(BLOCKS_BY_KEY.get(key).get(), new Item.Properties())));

                ENTITIES_BY_KEY.put(key, ENTITIES.register(id, () -> {
                    EntityType.Builder<MissileProjectile> builder =
                            EntityType.Builder.of(MissileProjectile::new, MobCategory.MISC);
                    AbstractCannonProjectile.build(builder);
                    EntityType<MissileProjectile> type = builder.build(MODID + ":" + id);
                    invfix$bindMunitionProperties(type);
                    return type;
                }));
            }
        }
    }

    /**
     * Один тип на все ракеты.
     *
     * Блок-сущность узнаёт и корпус, и наведение из блока, которым её поставили,
     * поэтому размножать тип не за чем.
     */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MissileBlockEntity>> BLOCK_ENTITY =
            BLOCK_ENTITIES.register("missile_computer", () -> BlockEntityType.Builder.of(
                    MissileBlockEntity::new,
                    BLOCKS_BY_KEY.values().stream().map(DeferredBlock::get)
                            .toArray(net.minecraft.world.level.block.Block[]::new)).build(null));

    private MissileRegistry() {}

    public static MissileBlock block(MissileVariant variant, MissileChassis chassis) {
        return BLOCKS_BY_KEY.get(new Key(variant, chassis)).get();
    }

    public static DeferredHolder<EntityType<?>, EntityType<MissileProjectile>> entityType(
            MissileVariant variant, MissileChassis chassis) {
        return ENTITIES_BY_KEY.get(new Key(variant, chassis));
    }

    /**
     * Связать тип снаряда с обработчиком свойств боеприпаса Create Big Cannons.
     *
     * Без этого ракета летит без физики вообще. Свойства - тяжесть,
     * сопротивление, масса, пробитие - лежат в json рядом с остальными
     * снарядами, но берёт их не файл и не имя типа: {@code getPropertiesOf}
     * ищет тип в карте обработчиков, а типы попадают в эту карту только через
     * явную регистрацию. Незарегистрированный тип получает
     * {@code BallisticPropertiesComponent.DEFAULT}, а это нули по всем полям.
     *
     * Ноль тяжести и ноль сопротивления означают, что скорость ракеты не
     * меняется никогда. Она уходит вверх со скоростью схода и идёт так, пока
     * её что-нибудь не остановит, не реагируя ни на тягу, ни на рули - потому
     * что тяга и рули складываются с этими самыми силами, а складывать их не с
     * чем: обработчик свойств для нашего типа просто отсутствует.
     *
     * Сам Create Big Cannons делает это одной строкой в {@code onRegister} для
     * каждого своего снаряда; у него это спрятано внутри Registrate, а мы
     * регистрируем типы вручную, и шаг потерялся.
     */
    private static void invfix$bindMunitionProperties(EntityType<MissileProjectile> type) {
        MunitionPropertiesHandler.registerProjectileHandler(type,
                CBCMunitionPropertiesHandlers.COMMON_SHELL_BIG_CANNON_PROJECTILE);
    }

    /** Все типы ракет - для клиентской регистрации рендереров. */
    public static Collection<DeferredHolder<EntityType<?>, EntityType<MissileProjectile>>> allEntityTypes() {
        return ENTITIES_BY_KEY.values();
    }

    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
        ENTITIES.register(modEventBus);
        modEventBus.addListener(MissileRegistry::onBuildCreativeTabs);
    }

    /**
     * Дописываемся во вкладку cbcmoreshells.
     *
     * Она перечисляет содержимое явным списком, а не собирает всё из своего
     * пространства имён, поэтому просто зарегистрироваться под их modid
     * недостаточно - предметы бы туда не попали.
     */
    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (!TAB.equals(event.getTabKey())) return;
        for (DeferredItem<BlockItem> item : ITEMS_BY_KEY.values()) event.accept(item);
    }
}