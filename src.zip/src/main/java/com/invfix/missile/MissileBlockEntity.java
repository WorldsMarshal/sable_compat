package com.invfix.missile;

import dan200.computercraft.core.computer.ComputerSide;
import dan200.computercraft.shared.computer.blocks.ComputerBlockEntity;
import dan200.computercraft.shared.computer.core.ComputerFamily;
import dan200.computercraft.shared.computer.core.ComputerState;
import dan200.computercraft.shared.computer.core.ServerComputer;
import dan200.computercraft.shared.peripheral.modem.ModemState;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.Vec3;
import rbasamoyai.createbigcannons.index.CBCMunitionPropertiesHandlers;
import rbasamoyai.createbigcannons.munitions.big_cannon.config.BigCannonCommonShellProperties;
import rbasamoyai.createbigcannons.munitions.config.components.BallisticPropertiesComponent;

/**
 * The missile on the rail.
 *
 * An advanced computer in a warhead. The terminal opens like any other computer,
 * the filesystem is a real filesystem, and the program the player writes here is
 * the program that will be flying in a moment - it is not copied, uploaded or
 * restarted at launch, the running computer itself moves across.
 *
 * Redstone is deliberately left as ordinary computer redstone rather than being
 * wired to anything. A rocket that launches because a lever was flipped is a
 * firework; here the signal simply appears on a side and the program decides
 * what, if anything, it means. The launch itself is a peripheral call.
 */
public class MissileBlockEntity extends ComputerBlockEntity implements MissileHost {

    /** The face the flight controls occupy. Nothing external may claim it. */
    public static final ComputerSide CONTROL_SIDE = ComputerSide.BACK;
    /** The datalink, on SARH and ARH. */
    public static final ComputerSide MODEM_SIDE = ComputerSide.TOP;
    /** The seeker, on ARH. */
    public static final ComputerSide RADAR_SIDE = ComputerSide.FRONT;

    private static final String NBT_INSTANCE = "MissileInstance";

    private final MissileVariant variant;
    private final MissileControlState control = new MissileControlState();
    private final MissileControlPeripheral controls = new MissileControlPeripheral(this);
    private final ModemState modemState = new ModemState();
    private @Nullable MissilePeripherals.Modem modem;
    private @Nullable MissilePeripherals.Radar radar;

    /**
     * The live computer's instance id, written to disk every save.
     *
     * This is the whole handoff. When the rack fires it hands the block's saved
     * NBT to the block class, by which point this block entity is already gone;
     * the id lets that code find the still-running ServerComputer in the registry
     * and give it to the entity, so the program never notices it was launched.
     */
    private @Nullable UUID instance;

    public MissileBlockEntity(BlockPos pos, BlockState state) {
        super(MissileRegistry.BLOCK_ENTITY.get(), pos, state, ComputerFamily.ADVANCED);
        this.variant = variantOf(state.getBlock());
    }

    private static MissileVariant variantOf(Block block) {
        return block instanceof MissileBlock mb ? mb.variant() : MissileVariant.PROGRAMMABLE;
    }

    /**
     * Куда «смотрит» компьютер ракеты.
     *
     * Переопределять обязательно. Родительский {@code ComputerBlockEntity}
     * читает {@code ComputerBlock.FACING} — горизонтальное свойство на четыре
     * стороны, которое есть у компьютера ComputerCraft. У нашего блока свойство
     * другое: {@code ProjectileBlock} наследует {@code DirectionalBlock} с
     * полным {@code BlockStateProperties.FACING} на шесть направлений. Это
     * разные объекты свойств, поэтому чтение чужого валилось с
     * «property does not exist in Block» на первом же тике.
     *
     * Вертикальные направления приводятся к северу: локальные стороны
     * компьютера считаются от горизонтали, и «лево» у ракеты, направленной в
     * зенит, смысла не имеет. На занятые нами грани это не влияет — они заданы
     * локально и от поворота блока не зависят.
     */
    @Override
    public Direction getDirection() {
        Direction facing = getBlockState().getValue(BlockStateProperties.FACING);
        return facing.getAxis().isHorizontal() ? facing : Direction.NORTH;
    }

    /**
     * Экрана у ракеты нет, поэтому и состояние показывать негде.
     *
     * Родитель на каждом тике пишет в блок свойство {@code ComputerBlock.STATE}
     * со значениями off/on/blinking — у компьютера ComputerCraft от него зависит
     * текстура лицевой панели. У нашего блока такого свойства нет и быть не
     * должно: модель взята у ракеты cbcmoreshells, никакой панели на ней не
     * нарисовано, а добавлять свойство ради трёх одинаковых моделей — плодить
     * состояния впустую.
     *
     * Это второе и последнее место, где {@code ComputerBlockEntity} обращается к
     * свойствам блока; первое — {@code getDirection} выше. Больше в
     * {@code AbstractComputerBlockEntity} обращений к состоянию блока нет:
     * стороны считаются через {@code DirectionUtil.FACINGS}, имя берётся из
     * {@code getDescriptionId}, а проверка на командный блок — обычный
     * instanceof.
     */
    @Override
    protected void updateBlockState(ComputerState newState) {
        // намеренно пусто
    }

    @Override
    protected boolean isPeripheralBlockedOnSide(ComputerSide localSide) {
        if (localSide == CONTROL_SIDE) return true;
        if (variant.hasModem() && localSide == MODEM_SIDE) return true;
        if (variant.hasRadar() && localSide == RADAR_SIDE) return true;
        return super.isPeripheralBlockedOnSide(localSide);
    }

    @Override
    public void serverTick() {
        super.serverTick();
        if (level == null || level.isClientSide) return;
        ServerComputer computer = getServerComputer();
        if (computer == null) return;

        instance = computer.getInstanceUUID();

        computer.setPeripheral(CONTROL_SIDE, controls);
        if (variant.hasModem()) {
            if (modem == null) modem = new MissilePeripherals.Modem(this, modemState);
            computer.setPeripheral(MODEM_SIDE, modem);
        }
        if (variant.hasRadar()) {
            if (radar == null) radar = new MissilePeripherals.Radar(this);
            computer.setPeripheral(RADAR_SIDE, radar);
        }
    }

    // ---- handoff ----

    /**
     * Detach the running computer so the entity can take it.
     *
     * The computer is deliberately not closed: it keeps ticking through the
     * launch, and the entity re-registers itself as its owner on the next tick.
     * Everything the block entity owns beyond the computer - the peripherals, the
     * modem state - is rebuilt on the entity, because those are bolted to the
     * airframe rather than to the machine.
     */
    public @Nullable UUID computerInstance() {
        ServerComputer computer = getServerComputer();
        return computer != null ? computer.getInstanceUUID() : instance;
    }

    public MissileControlState control() {
        return control;
    }

    /**
     * Компьютер уходит в полёт живым, а не заново.
     *
     * Снос блока закрывает его компьютер - так устроен ComputerCraft, и для
     * обычной машины это правильно. Для ракеты это означало, что в воздухе
     * поднимается новый компьютер на том же номере, и пока он проходит
     * собственную загрузку, ракета летит без программы. По журналу это около
     * ста тиков: пять с лишним секунд, за которые ракета ближнего боя успевает
     * слетать и упасть.
     *
     * Поэтому перед пуском блок помечается, и закрытие пропускается. Снаряд
     * находит работающий экземпляр в реестре и подхватывает его вместе с
     * состоянием программы - та даже не замечает, что под ней сменился носитель.
     *
     * Флаг ставится только пуском. Поломка блока, выгрузка чанка и выход из мира
     * идут прежним путём и компьютер закрывают.
     */
    private boolean handedOver = false;

    public void handOverComputer() {
        handedOver = true;
    }

    /**
     * Ракета, в которую ушёл этот блок.
     *
     * Пульт на компьютере меняется на пульт ракеты только на её первом тике, а
     * программа, вызвавшая launch(), продолжает работать сразу. Всё, что она
     * успеет сказать в этот промежуток, раньше уходило в состояние снятого
     * блока и терялось: ракета скопировала его в момент пуска. Теперь снятый
     * блок пересылает вопросы и команды своей ракете.
     */
    private @Nullable MissileProjectile launched;

    public void markLaunched(MissileProjectile projectile) {
        launched = projectile;
    }

    @Override
    protected void unload() {
        if (handedOver) return;
        super.unload();
    }

    @Override
    public void saveAdditional(CompoundTag nbt, HolderLookup.Provider registries) {
        super.saveAdditional(nbt, registries);
        UUID id = computerInstance();
        if (id != null) nbt.putUUID(NBT_INSTANCE, id);
        control.save(nbt);
    }

    @Override
    protected void loadServer(CompoundTag nbt, HolderLookup.Provider registries) {
        super.loadServer(nbt, registries);
        if (nbt.hasUUID(NBT_INSTANCE)) instance = nbt.getUUID(NBT_INSTANCE);
        control.load(nbt);
    }

    public static @Nullable UUID readInstance(@Nullable CompoundTag nbt) {
        return nbt != null && nbt.hasUUID(NBT_INSTANCE) ? nbt.getUUID(NBT_INSTANCE) : null;
    }

    // ---- MissileHost, answered from the rail ----

    @Override
    public MissileVariant variant() {
        return variant;
    }

    @Override
    public MissileControlState controlState() {
        return launched != null ? launched.controlState() : control;
    }

    @Override
    public Level hostLevel() {
        return launched != null ? launched.hostLevel() : level;
    }

    @Override
    public Vec3 currentPosition() {
        return launched != null ? launched.currentPosition() : Vec3.atCenterOf(getBlockPos());
    }

    @Override
    public Vec3 currentVelocity() {
        return launched != null ? launched.currentVelocity() : Vec3.ZERO;
    }

    @Override
    public Vec3 currentOrientation() {
        if (launched != null) return launched.currentOrientation();
        return Vec3.atLowerCornerOf(
                getBlockState().getValue(BlockStateProperties.FACING).getNormal());
    }

    @Override
    public boolean isFlying() {
        return launched != null && launched.isFlying();
    }

    @Override
    public int flightAge() {
        return launched != null ? launched.flightAge() : -1;
    }

    @Override
    public void detonateNow() {
        if (launched != null) launched.detonateNow();
        // на рельсе недостижимо: пульт не зовёт это, пока isFlying() == false
    }

    @Override
    public int burnTicks() {
        if (launched != null) return launched.burnTicks();
        return getBlockState().getBlock() instanceof MissileBlock mb
                ? mb.variant().burnTicks() + mb.chassis().extraBurnTicks()
                : variant.burnTicks();
    }

    @Override
    public BallisticPropertiesComponent ballistics() {
        if (launched != null) return launched.ballistics();
        if (getBlockState().getBlock() instanceof MissileBlock mb) {
            return ((BigCannonCommonShellProperties) CBCMunitionPropertiesHandlers
                    .COMMON_SHELL_BIG_CANNON_PROJECTILE.getPropertiesOf(mb.getAssociatedEntityType()))
                    .ballistics();
        }
        return BallisticPropertiesComponent.DEFAULT;
    }

    @Override
    public boolean launch() {
        if (launched != null || level == null || level.isClientSide || isRemoved()) return false;
        BlockState state = getBlockState();
        if (!(state.getBlock() instanceof MissileBlock block)) return false;
        return block.launchFromBlock(level, getBlockPos(), state) != null;
    }
}