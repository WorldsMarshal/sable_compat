package com.invfix.missile;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;

/**
 * What the program has asked the airframe to do.
 *
 * Deliberately dumb. There is no autopilot here, no target, no guidance law -
 * just the numbers a motor and a set of fins can act on, plus the arming
 * state. The missile applies these and nothing else, which means a program that
 * writes zeros flies a pure ballistic arc and a program that wants to hit
 * something has to compute it and push the result down every tick.
 *
 * Held on the block entity before launch and handed to the entity with the
 * computer, so a program that has already spun the motor up on the rail does not
 * see its commands reset the moment the rocket leaves it.
 */
public class MissileControlState {

    /** Fraction of rated motor thrust, 0 to 1. */
    public double thrust = 0.0;
    /** Commanded pitch rate, -1 to 1, scaled by the airframe's turn authority. */
    public double steerPitch = 0.0;
    /** Commanded yaw rate, same scale. */
    public double steerYaw = 0.0;
    /**
     * Команда рулям вектором в мировых осях, в долях от предела поворота.
     *
     * Альтернатива паре тангаж/рыскание, и они взаимоисключающие: установка
     * одного обнуляет другое. Нужна потому, что у ракеты нет собственного крена,
     * и оси тангажа/рыскания приходится выводить из направления полёта и
     * мировой вертикали. Когда нос смотрит почти вертикально, эта пара осей
     * вырождается и начинает крутиться вместе с малейшим боковым сносом - так
     * получалась спираль в тесте с вертикальным пуском. Мировой вектор такой
     * особенности не имеет: физика убирает из него составляющую вдоль полёта и
     * ограничивает остаток пределом поворота.
     */
    public double steerX = 0.0;
    public double steerY = 0.0;
    public double steerZ = 0.0;
    /**
     * Сколько тиков ещё держать тягу, после чего она сама падает в ноль;
     * -1 - держать, пока не скажут иначе.
     *
     * Отсечка считается на сервере, в тех же тиках, что и полёт. Программа
     * работает в своём потоке и может опоздать с командой на тик-другой, а на
     * полном газу это 0.55 блока за тик скорости - промах в десятки блоков на
     * дальности. Так импульс получается ровно той длины, которую заказали.
     */
    public int thrustTicks = -1;
    /** Ticks of motor burn left. Refuses thrust once empty. */
    public int fuel = -1;
    /** A disarmed warhead ignores detonate() - the safety a program can set. */
    public boolean armed = true;
    /** Ticks until an unconditional detonation, or -1 for none. */
    public int selfDestruct = -1;

    public void setThrust(double value) {
        setThrust(value, -1);
    }

    /** Тяга на заданное число тиков работы двигателя; ticks <= 0 - без отсечки. */
    public synchronized void setThrust(double value, int ticks) {
        thrustTicks = ticks > 0 ? ticks : -1;
        thrust = finite(Mth.clamp(value, 0.0, 1.0));
    }

    /**
     * Учёт одного тика полёта: топливо и отсечка. Только с серверного потока.
     *
     * Тяга в этом тике уже приложена - CBC зовёт getForces раньше, - поэтому
     * здесь списывается ровно то, что сгорело.
     */
    public synchronized void burnTick() {
        if (thrust <= 0.0 || fuel <= 0) return;
        fuel--;
        if (thrustTicks > 0 && --thrustTicks == 0) {
            thrust = 0.0;
            thrustTicks = -1;
        }
    }

    public void setSteer(double pitch, double yaw) {
        steerPitch = finite(Mth.clamp(pitch, -1.0, 1.0));
        steerYaw = finite(Mth.clamp(yaw, -1.0, 1.0));
        steerX = steerY = steerZ = 0.0;
    }

    public void setSteerVector(double x, double y, double z) {
        steerX = finite(x);
        steerY = finite(y);
        steerZ = finite(z);
        steerPitch = steerYaw = 0.0;
    }

    public boolean hasSteerVector() {
        return steerX != 0.0 || steerY != 0.0 || steerZ != 0.0;
    }

    /** Команды двигателю и рулям в ноль; запал, взведение и топливо не трогаются. */
    public synchronized void neutral() {
        thrust = 0.0;
        thrustTicks = -1;
        steerPitch = steerYaw = 0.0;
        steerX = steerY = steerZ = 0.0;
    }

    public void copyFrom(MissileControlState other) {
        thrust = other.thrust;
        thrustTicks = other.thrustTicks;
        steerPitch = other.steerPitch;
        steerYaw = other.steerYaw;
        steerX = other.steerX;
        steerY = other.steerY;
        steerZ = other.steerZ;
        armed = other.armed;
        selfDestruct = other.selfDestruct;
    }

    // NaN из Lua пролез бы в скорость сущности и сделал бы её координаты NaN.
    private static double finite(double v) {
        return Double.isFinite(v) ? v : 0.0;
    }

    public void save(CompoundTag tag) {
        CompoundTag t = new CompoundTag();
        t.putDouble("Thrust", thrust);
        t.putInt("ThrustTicks", thrustTicks);
        t.putDouble("Pitch", steerPitch);
        t.putDouble("Yaw", steerYaw);
        t.putDouble("VecX", steerX);
        t.putDouble("VecY", steerY);
        t.putDouble("VecZ", steerZ);
        t.putInt("Fuel", fuel);
        t.putBoolean("Armed", armed);
        t.putInt("SelfDestruct", selfDestruct);
        tag.put("MissileControl", t);
    }

    public void load(CompoundTag tag) {
        if (!tag.contains("MissileControl")) return;
        CompoundTag t = tag.getCompound("MissileControl");
        thrust = t.getDouble("Thrust");
        thrustTicks = t.contains("ThrustTicks") ? t.getInt("ThrustTicks") : -1;
        steerPitch = t.getDouble("Pitch");
        steerYaw = t.getDouble("Yaw");
        steerX = t.getDouble("VecX");
        steerY = t.getDouble("VecY");
        steerZ = t.getDouble("VecZ");
        fuel = t.contains("Fuel") ? t.getInt("Fuel") : -1;
        armed = !t.contains("Armed") || t.getBoolean("Armed");
        selfDestruct = t.contains("SelfDestruct") ? t.getInt("SelfDestruct") : -1;
    }
}
