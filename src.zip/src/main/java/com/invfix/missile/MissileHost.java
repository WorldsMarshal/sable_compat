package com.invfix.missile;

import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import rbasamoyai.createbigcannons.munitions.config.components.BallisticPropertiesComponent;

/**
 * What a missile looks like to the things bolted onto it.
 *
 * The same computer, the same control peripheral and the same modem exist twice
 * over the life of one missile - once on a block sitting in a rack, once on an
 * entity in flight - and neither peripheral should care which it is attached to.
 * This is the seam. The block answers "not flying, here is the rail's position,
 * no you may not detonate"; the entity answers for real.
 */
public interface MissileHost {

    MissileVariant variant();

    MissileControlState controlState();

    Level hostLevel();

    Vec3 currentPosition();

    Vec3 currentVelocity();

    Vec3 currentOrientation();

    /** False while the missile is still a block. */
    boolean isFlying();

    /** Ticks since launch, or -1 on the rail. */
    int flightAge();

    /** Only ever called when isFlying() is true and the warhead is armed. */
    void detonateNow();

    /** Полное время работы двигателя этого корпуса, в тиках. */
    int burnTicks();

    /** Баллистика из json снаряда, без множителей измерения. */
    BallisticPropertiesComponent ballistics();

    /**
     * Пуск с места. Вызывается только на главном потоке.
     *
     * @return false, если пустить нельзя: уже летит, блок снят или не наш
     */
    boolean launch();
}
