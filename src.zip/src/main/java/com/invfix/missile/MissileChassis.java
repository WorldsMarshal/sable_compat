package com.invfix.missile;

import java.util.Locale;

/**
 * Корпус ракеты: боевая часть плюс способ запуска.
 *
 * Взято один в один с семейств cbcmoreshells, потому что модели и текстуры мы
 * берём оттуда же. Каждый корпус существует в трёх вариантах наведения, так что
 * всего получается восемнадцать ракет.
 *
 * Спаренных (dual) корпусов здесь нет намеренно: одна пусковая с двумя ракетами
 * и одним компьютером внутри - это не ракета, а стойка, и управлять ей пришлось
 * бы совсем иначе.
 */
public enum MissileChassis {

    /** Стеллажная фугасная. Базовый корпус, лёгкий и дешёвый. */
    HE_ROCKET("he_rocket", "he_rocket", false, 9.0F, 1.2F),
    /** Стеллажная бронебойно-фугасная. Тяжелее, пробивает лучше. */
    APHE_ROCKET("aphe_rocket", "aphe_rocket", true, 7.0F, 3.0F),
    /** Пушечная фугасная: заряжается в ствол, стартовая скорость выше. */
    HE_CANNON_ROCKET("he_cannon_rocket", "he_cannon_rocket", false, 10.0F, 1.4F),
    /** Пушечная бронебойно-фугасная. */
    APHE_CANNON_ROCKET("aphe_cannon_rocket", "aphe_cannon_rocket", true, 8.0F, 3.4F),
    /**
     * Барражирующая фугасная.
     *
     * У cbcmoreshells барражирующая версия сама ищет саблевел в конусе и ведёт
     * его. Здесь это заменено на компьютер: корпус тот же, топлива больше,
     * решения принимает программа.
     */
    HE_LOITERING_ROCKET("he_loitering_rocket", "he_rocket", false, 9.0F, 1.2F),
    /** Барражирующая бронебойно-фугасная. */
    APHE_LOITERING_ROCKET("aphe_loitering_rocket", "aphe_rocket", true, 7.0F, 3.0F);

    private final String id;
    private final String model;
    private final boolean armourPiercing;
    private final float explosivePower;
    private final float penetration;

    MissileChassis(String id, String model, boolean armourPiercing,
                   float explosivePower, float penetration) {
        this.id = id;
        this.model = model;
        this.armourPiercing = armourPiercing;
        this.explosivePower = explosivePower;
        this.penetration = penetration;
    }

    /** Хвост идентификатора: {@code programmable_} + это. */
    public String id() {
        return id;
    }

    /**
     * Модель блока у cbcmoreshells, которую мы переиспользуем.
     *
     * Барражирующие корпуса своей модели не имеют - у автора они тоже смотрят на
     * модель обычной ракеты, - поэтому здесь она совпадает со стеллажной.
     */
    public String model() {
        return model;
    }

    public boolean isArmourPiercing() {
        return armourPiercing;
    }

    public float explosivePower() {
        return explosivePower;
    }

    public float penetration() {
        return penetration;
    }

    /** Дольше горит то, что задумано летать дольше. */
    public int extraBurnTicks() {
        return switch (this) {
            case HE_LOITERING_ROCKET, APHE_LOITERING_ROCKET -> 800;
            case HE_CANNON_ROCKET, APHE_CANNON_ROCKET -> 120;
            default -> 0;
        };
    }

    public String lowerName() {
        return name().toLowerCase(Locale.ROOT);
    }
}
