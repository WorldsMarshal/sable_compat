package com.invfix.missile;

import dan200.computercraft.shared.computer.core.ComputerFamily;
import dan200.computercraft.shared.computer.core.ServerComputer;
import dan200.computercraft.shared.computer.core.ServerContext;
import dan200.computercraft.shared.peripheral.modem.ModemState;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import java.util.stream.Stream;
import java.util.Comparator;
import java.nio.file.Path;
import java.nio.file.Files;
import java.io.IOException;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.Vec3;
import rbasamoyai.createbigcannons.CreateBigCannons;
import rbasamoyai.createbigcannons.config.CBCCfgMunitions;
import rbasamoyai.createbigcannons.config.CBCConfigs;
import rbasamoyai.createbigcannons.index.CBCMunitionPropertiesHandlers;
import rbasamoyai.createbigcannons.munitions.ShellExplosion;
import rbasamoyai.createbigcannons.munitions.big_cannon.AbstractBigCannonProjectile;
import rbasamoyai.createbigcannons.munitions.big_cannon.config.BigCannonCommonShellProperties;
import rbasamoyai.createbigcannons.munitions.big_cannon.config.BigCannonProjectilePropertiesComponent;
import rbasamoyai.createbigcannons.munitions.config.components.BallisticPropertiesComponent;
import rbasamoyai.createbigcannons.munitions.config.components.EntityDamagePropertiesComponent;
import net.minecraft.core.BlockPos;
import rbasamoyai.ritchiesprojectilelib.RitchiesProjectileLib;

/**
 * The missile in flight.
 *
 * A Create Big Cannons projectile in every respect that matters to the world -
 * it is loaded, fired, drags, penetrates and explodes exactly like any other
 * shell - with a running ComputerCraft computer riding inside it.
 *
 * The computer is not a copy. When the rack fires, the block class looks the
 * still-live ServerComputer up in CC's registry by the instance id the block
 * entity had been saving, and hands the object itself over; from the program's
 * point of view the world simply started moving. If that lookup fails - the item
 * was loaded straight into a cannon, or the chunk went through a save and
 * reload - a fresh computer is opened on the same computer id, so the filesystem
 * survives even when the running program does not.
 *
 * Steering is applied in getForces, which is where CBC lets a projectile add to
 * gravity and drag. Thrust pushes along the nose; the commanded body rates push
 * sideways, bounded by the airframe's authority. Only the motor burns fuel, but
 * the fins are powered by it too: once the tank reads zero the missile coasts
 * and cannot turn, so a program that wants to steer to the end keeps a reserve.
 */
public class MissileProjectile extends AbstractBigCannonProjectile implements MissileHost {

    /** Acceleration per tick at full throttle. */
    static final double THRUST_ACCEL = 0.55;
    /** Lateral acceleration available at full stick. */
    static final double TURN_AUTHORITY = 0.35;

    private static final String NBT_COMPUTER_ID = "MissileComputerId";
    private static final String NBT_INSTANCE = "MissileInstance";
    private static final String NBT_VARIANT = "MissileVariant";
    private static final String NBT_CHASSIS = "MissileChassis";
    private static final String NBT_AGE = "MissileAge";

    private final MissileControlState control = new MissileControlState();

    private MissileVariant variant = MissileVariant.PROGRAMMABLE;
    private MissileChassis chassis = MissileChassis.HE_ROCKET;
    private int computerId = -1;
    private @Nullable UUID adoptInstance;
    private @Nullable ServerComputer computer;
    private int flightAge = 0;

    private final MissileControlPeripheral controls = new MissileControlPeripheral(this);
    private final ModemState modemState = new ModemState();
    private @Nullable MissilePeripherals.Modem modem;
    private @Nullable MissilePeripherals.Radar radar;

    public MissileProjectile(EntityType<? extends MissileProjectile> type, Level level) {
        super(type, level);
    }

    /** Called by the block the instant before the rack lets go. */
    public void inherit(MissileVariant variant, MissileChassis chassis, int computerId,
                        @Nullable UUID instance, @Nullable MissileControlState state) {
        this.variant = variant;
        this.chassis = chassis;
        this.computerId = computerId;
        this.adoptInstance = instance;
        if (state != null) control.copyFrom(state);
    }

    // ---- the computer ----

    private @Nullable ServerComputer computer() {
        if (!(level() instanceof ServerLevel server)) return null;
        // Мёртвой ракете компьютер не положен. remove() уже закрыл настоящий и
        // обнулил поле, поэтому без этой проверки следующий вызов поднял бы на
        // том же номере новый: он загружается, запускает startup заново, тот
        // стирает отчёт настоящего полёта и пишет поверх него показания
        // уничтоженной сущности. Через сто тиков без keepAlive реестр CC
        // выгружает этого сироту, и от полёта не остаётся ничего.
        if (isRemoved()) return null;
        if (computer != null) {
            if (ServerContext.get(server.getServer()).registry().get(computer.getInstanceUUID()) == computer) {
                return computer;
            }
            // Реестр CC выкинул компьютер: сто тиков без keepAlive. Так бывает,
            // если сущность долго не тикала, но и не выгружалась. Старый объект
            // уже выгружен и мёртв, а поле продолжало на него указывать - ракета
            // летела бы дальше без программы и без шанса её поднять. Открываем
            // заново на том же номере; программа стартует с начала.
            computerId = computer.getID();
            computer = null;
        }

        if (adoptInstance != null) {
            ServerComputer existing = ServerContext.get(server.getServer())
                    .registry().get(adoptInstance);
            adoptInstance = null;
            if (existing != null) {
                computer = existing;
                computerId = existing.getID();
                invfix$adopted = true;
                return computer;
            }
        }

        ServerComputer fresh = new ServerComputer(server, blockPosition(),
                ServerComputer.properties(computerId, ComputerFamily.ADVANCED)
                        .label("missile"));
        fresh.register();
        fresh.turnOn();
        computerId = fresh.getID();
        computer = fresh;
        return computer;
    }

    // ---- flight ----

    /**
     * Сколько тиков полёта вперёд заказывать чанки, сверх одного чанка запаса.
     *
     * Заказ не мгновенный. RPL обрабатывает очередь в конце тика мира, ставит
     * тикет принудительной загрузки, а сущности чанка поднимаются асинхронно -
     * у RPL на это заложен таймаут entityLoadTimeout, по умолчанию 10 тиков.
     * Заказ на три тика вперёд обычно успевает; когда не успевает, срабатывает
     * удержание в {@link #invfix$nextStepReady}.
     */
    private static final int LOOKAHEAD_TICKS = 3;

    /** Подряд тиков удержания: ждём, пока впереди поднимется чанк. */
    private int invfix$heldTicks = 0;

    @Override
    public void tick() {
        // Before anything else, and whether or not the flight is going to be
        // able to run this tick.
        //
        // CBC already force-loads the chunk a projectile is in, but it does so
        // from inside its own hasChunk guard, so a projectile that somehow ends
        // up in an unloaded chunk never asks for it. Asking first,
        // unconditionally, means the missile digs itself out instead.
        requestFlightChunks();

        // Удержание: не входить в чанк, где сущности ещё не тикают.
        //
        // Сущность в таком чанке перестаёт тикать совсем. Тогда перестаёт
        // заказываться и коридор, чанк за спиной через три тика отпускается
        // RPL, и ракета уезжает на диск вместе с чанком, в котором застряла, -
        // навсегда, пока туда не придёт игрок. Поэтому лучше постоять на месте
        // тик-другой, пока заказанный чанк не поднимется. Компьютер всё это
        // время живёт, а часы полёта, топливо и запал стоят.
        boolean hold = !level().isClientSide && !isRemoved() && !invfix$nextStepReady();
        if (hold) {
            if (++invfix$heldTicks == 200) {
                com.mojang.logging.LogUtils.getLogger().warn(
                        "[invfix missile] id={} waiting {} ticks for chunks ahead at {}",
                        computerId, invfix$heldTicks, blockPosition());
            }
        } else {
            invfix$heldTicks = 0;
            super.tick();
        }
        // CBC уничтожает снаряд прямо внутри своего tick: попадание в
        // clipAndDamage -> onImpact -> detonateNow -> discard, либо
        // removeNextTick. Управление после этого всё равно возвращается сюда, и
        // остаток тика шёл бы уже по мёртвой сущности.
        if (level().isClientSide || isRemoved()) return;

        ServerComputer c = computer();
        if (c == null) return;

        // Deliberately outside the frozen check below. The computer is not part
        // of the flight: it is registered with CC's own registry, which ticks it
        // globally and drops it after a hundred ticks without a ping.
        c.setPosition((ServerLevel) level(), blockPosition());
        c.keepAlive();

        // Только при изменении, и здесь это важнее всего: ракета тикается
        // каждый тик, а замки те же самые, что держит поток компьютера, пока
        // ждёт задачу главного потока. Безусловная установка на каждом тике -
        // прямая дорога к взаимной блокировке сервера.
        if (c.getPeripheral(MissileBlockEntity.CONTROL_SIDE) != controls) {
            c.setPeripheral(MissileBlockEntity.CONTROL_SIDE, controls);
        }
        if (variant.hasModem()) {
            if (modem == null) modem = new MissilePeripherals.Modem(this, modemState);
            if (c.getPeripheral(MissileBlockEntity.MODEM_SIDE) != modem) {
                c.setPeripheral(MissileBlockEntity.MODEM_SIDE, modem);
            }
        }
        if (variant.hasRadar()) {
            if (radar == null) radar = new MissilePeripherals.Radar(this);
            if (c.getPeripheral(MissileBlockEntity.RADAR_SIDE) != radar) {
                c.setPeripheral(MissileBlockEntity.RADAR_SIDE, radar);
            }
        }

        // Flight bookkeeping only advances on ticks the flight actually ran.
        // Burning fuel or counting down a self destruct while the missile is
        // held waiting for terrain would make the range depend on how loaded
        // the server happens to be.
        boolean running = !hold && isFlightRunning();
        if (!hold) invfix$trace(c, running);
        if (!running) return;
        flightAge++;

        if (control.fuel < 0) control.fuel = burnTicks();
        control.burnTick();

        if (control.selfDestruct >= 0 && control.armed && --control.selfDestruct <= 0) {
            detonateNow();
        }
    }

    /**
     * Можно ли сделать следующий шаг: тикают ли сущности во всех чанках, через
     * которые он пройдёт.
     *
     * Отрезок тот же, что проверяет на столкновения сам CBC в clipAndDamage:
     * от позиции на скорость плюс силы этого тика.
     */
    private boolean invfix$nextStepReady() {
        ServerLevel server = (ServerLevel) level();
        Vec3 from = position();
        Vec3 v = getDeltaMovement();
        Vec3 to = from.add(v.add(getForces(from, v)));
        return walkChunks(from, to, (cx, cz) ->
                server.isPositionEntityTicking(new BlockPos(cx << 4, 0, cz << 4)));
    }

    /**
     * Заказать коридор у RPL - той же очереди, через которую грузят чанки все
     * снаряды CBC.
     *
     * Коридор - все чанки, которые задевает отрезок от ракеты вперёд по
     * скорости на {@link #LOOKAHEAD_TICKS} тиков плюс один чанк, включая
     * срезанные углы. Прежний вариант брал точки через каждые 16 блоков и при
     * полёте по диагонали пропускал чанк, через угол которого ракета проходила.
     *
     * Через RPL, а не своими тикетами, потому что у RPL общий бюджет:
     * maxChunksForceLoaded (64) и maxChunksLoadedEachTick (32), и залп из
     * десятка ракет делит его, а не берёт сколько хочет. Загруженный чанк живёт
     * projectileChunkAge (3) тика после последнего заказа. И это SavedData:
     * коридор, открытый при остановке сервера, после запуска открывается снова.
     *
     * Генерацию RPL не запрещает: {@code loadChunkNoGenerate} при недостроенном
     * чанке просит его в статусе FULL с разрешением создать, то есть ракета над
     * неисследованной местностью её сгенерирует.
     */
    private void requestFlightChunks() {
        if (!(level() instanceof ServerLevel server) || isRemoved()) return;
        Vec3 from = position();
        Vec3 v = getDeltaMovement();
        double speed = v.length();
        Vec3 to = speed < 1.0E-6
                ? from
                : from.add(v.scale((LOOKAHEAD_TICKS * speed + 16.0) / speed));
        walkChunks(from, to, (cx, cz) -> {
            RitchiesProjectileLib.queueForceLoad(server, cx, cz);
            return true;
        });
    }

    @FunctionalInterface
    interface ChunkVisitor {
        /** @return false, чтобы остановить обход */
        boolean visit(int chunkX, int chunkZ);
    }

    /**
     * Обойти по порядку все чанки, которые задевает отрезок, в плоскости XZ.
     *
     * Шаг по сетке чанков (Amanatides-Woo). Если отрезок проходит ровно через
     * угол, в обход добавляются оба соседа по углу: по какую сторону угла
     * пройдёт ракета с учётом округления, заранее не сказать.
     *
     * @return false, если обход остановил посетитель
     */
    static boolean walkChunks(Vec3 from, Vec3 to, ChunkVisitor visitor) {
        double x0 = from.x / 16.0, z0 = from.z / 16.0;
        double x1 = to.x / 16.0, z1 = to.z / 16.0;
        int cx = Mth.floor(x0), cz = Mth.floor(z0);
        int ex = Mth.floor(x1), ez = Mth.floor(z1);
        if (!visitor.visit(cx, cz)) return false;

        double dx = x1 - x0, dz = z1 - z0;
        int sx = dx > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;
        double tdx = dx != 0 ? Math.abs(1.0 / dx) : Double.POSITIVE_INFINITY;
        double tdz = dz != 0 ? Math.abs(1.0 / dz) : Double.POSITIVE_INFINITY;
        double tx = dx > 0 ? (cx + 1 - x0) * tdx : dx < 0 ? (x0 - cx) * tdx : Double.POSITIVE_INFINITY;
        double tz = dz > 0 ? (cz + 1 - z0) * tdz : dz < 0 ? (z0 - cz) * tdz : Double.POSITIVE_INFINITY;

        int guard = Math.abs(ex - cx) + Math.abs(ez - cz) + 1;
        while ((cx != ex || cz != ez) && guard-- > 0) {
            if (tx < tz) {
                cx += sx;
                tx += tdx;
            } else if (tz < tx) {
                cz += sz;
                tz += tdz;
            } else {
                if (!visitor.visit(cx + sx, cz) || !visitor.visit(cx, cz + sz)) return false;
                cx += sx;
                cz += sz;
                tx += tdx;
                tz += tdz;
            }
            if (!visitor.visit(cx, cz)) return false;
        }
        return true;
    }

    /**
     * Диагностика полёта в журнал сервера.
     *
     * Снаружи не видно ничего: терминала у летящей ракеты нет, файл на её диске
     * остаётся пустым, если ракету уничтожили с незакрытым дескриптором, а по
     * траектории «программа не работает» и «программа работает не так» выглядят
     * одинаково. Здесь пишется то, что различает эти два случая: жив ли
     * компьютер, включён ли он, идёт ли полёт вообще, и какие именно значения
     * тяги и рулей читает физика.
     *
     * Включается флагом, а не остаётся навсегда: раз в секунду на ракету это
     * терпимо для отладки и лишнее в обычной игре.
     */
    private static final boolean INVFIX_TRACE = false;

    /** Подобрали работающий компьютер блока, или подняли новый на его номере. */
    private boolean invfix$adopted = false;

    private void invfix$trace(@Nullable ServerComputer c, boolean running) {
        if (!INVFIX_TRACE) return;
        if (tickCount % 20 != 0) return;
        com.mojang.logging.LogUtils.getLogger().info(
                "[invfix missile] tick={} flightAge={} running={} held={} computer={} on={} id={} "
                        + "adopted={} ctrlPerip={} label={} thrust={}x{} steer={}/{} vec={}/{}/{} fuel={} sd={} "
                        + "pos={}/{}/{} v={}",
                tickCount, flightAge, running, invfix$heldTicks,
                c != null, c != null && c.isOn(), computerId,
                invfix$adopted,
                // Видит ли компьютер наш пульт на своей грани. Если нет,
                // peripheral.find на борту ничего не находит, программа падает
                // на первой же строке и файл остаётся таким, каким его оставил
                // компьютер на рельсе.
                c != null && c.getPeripheral(MissileBlockEntity.CONTROL_SIDE) == controls,
                c != null ? c.getLabel() : "-",
                control.thrust, control.thrustTicks, control.steerPitch, control.steerYaw,
                String.format("%.2f", control.steerX), String.format("%.2f", control.steerY),
                String.format("%.2f", control.steerZ),
                control.fuel, control.selfDestruct,
                String.format("%.1f", getX()), String.format("%.1f", getY()),
                String.format("%.1f", getZ()),
                String.format("%.2f", getDeltaMovement().length()));
    }

    /** Mirrors the guard the base class uses to decide whether to move at all. */
    private boolean isFlightRunning() {
        ChunkPos cpos = new ChunkPos(blockPosition());
        return level().hasChunk(cpos.x, cpos.z);
    }

    /**
     * Gravity and drag from the base class, plus whatever the program asked for.
     *
     * Thrust goes along the current heading rather than a separately tracked
     * body axis, because a fin-stabilised rocket points where it is going; the
     * steering commands are what change that heading, applied perpendicular to
     * it so they turn the missile instead of speeding it up.
     */
    @Override
    protected Vec3 getForces(Vec3 position, Vec3 velocity) {
        Vec3 natural = super.getForces(position, velocity);
        if (level().isClientSide) return natural;
        if (control.fuel == 0) return natural;

        Vec3 heading = velocity.lengthSqr() > 1.0E-9 ? velocity.normalize() : new Vec3(0, 1, 0);
        Vec3 forces = natural;

        if (control.thrust > 0.0) {
            forces = forces.add(heading.scale(THRUST_ACCEL * control.thrust));
        }

        if (control.hasSteerVector()) {
            // мировой вектор: убрать продольную часть, остаток не длиннее 1
            Vec3 cmd = new Vec3(control.steerX, control.steerY, control.steerZ);
            Vec3 lateral = cmd.subtract(heading.scale(cmd.dot(heading)));
            double len = lateral.length();
            if (len > 1.0) lateral = lateral.scale(1.0 / len);
            forces = forces.add(lateral.scale(TURN_AUTHORITY));
        } else if (control.steerPitch != 0.0 || control.steerYaw != 0.0) {
            // a yaw axis that stays horizontal, and a pitch axis square to both,
            // so the two sticks stay independent whatever attitude we are in
            Vec3 right = heading.cross(new Vec3(0, 1, 0));
            if (right.lengthSqr() < 1.0E-9) right = new Vec3(1, 0, 0);
            right = right.normalize();
            Vec3 up = right.cross(heading).normalize();
            forces = forces
                    .add(right.scale(TURN_AUTHORITY * control.steerYaw))
                    .add(up.scale(TURN_AUTHORITY * control.steerPitch));
        }
        return forces;
    }

    @Override
    public void detonateNow() {
        if (level().isClientSide || !control.armed) return;
        BigCannonCommonShellProperties p = getAllProperties();
        ShellExplosion explosion = new ShellExplosion(level(), this,
                indirectArtilleryFire(false), getX(), getY(), getZ(),
                p.explosion().blockDamagePower(), p.explosion().entityDamagePower(), false,
                ((CBCCfgMunitions.GriefState) CBCConfigs.server().munitions.damageRestriction.get())
                        .explosiveInteraction());
        CreateBigCannons.handleCustomExplosion(level(), explosion);
        discard();
    }

    @Override
    protected boolean onImpact(net.minecraft.world.phys.HitResult hitResult,
                               ImpactResult impactResult,
                               rbasamoyai.createbigcannons.munitions.ProjectileContext ctx) {
        boolean handled = super.onImpact(hitResult, impactResult, ctx);
        if (!level().isClientSide && control.armed) {
            // impact always ends the flight; a program that wanted a proximity
            // burst had its chance on the way in
            detonateNow();
        }
        return handled;
    }

    /**
     * Chunk unload is not death.
     *
     * A missile whose chunk goes away is saved to disk and will come back, so
     * the computer is only unregistered - not shut down - and the id that points
     * at its filesystem goes into NBT with it. On reload it opens again on the
     * same id: the files are all there, the running program is not, which is
     * exactly what happens to any computer whose chunk unloads. Detonation and
     * an explicit discard are the real end, and there the computer is shut down
     * properly first.
     */
    @Override
    public void remove(RemovalReason reason) {
        super.remove(reason);
        if (level().isClientSide) return;
        boolean unloading = reason == RemovalReason.UNLOADED_TO_CHUNK
                || reason == RemovalReason.UNLOADED_WITH_PLAYER;
        // Номер нужен и после закрытия компьютера - по нему ищется каталог.
        if (computer != null && computerId < 0) computerId = computer.getID();
        if (computer != null) {
            if (unloading) {
                computer.close();
            } else {
                computer.shutdown();
                computer.close();
            }
            computer = null;
        }
        if (!unloading) deleteComputerFiles();
    }

    /**
     * Стереть папку компьютера этой ракеты с диска мира.
     *
     * ComputerCraft заводит каталог на каждый номер компьютера и не убирает его
     * никогда: сломанный компьютер оставляет файлы лежать, чтобы их подобрал
     * компьютер с тем же номером. Для стационарной машины это правильно, а для
     * расходника - нет. Ракеты уходят десятками, каждая по дороге получает свой
     * номер, и в saves/<мир>/computercraft/computer накапливается по каталогу на
     * выстрел, в каждом - копия startup и отчёт о полёте. Через сотню пусков это
     * сотня каталогов, которые никто никогда не откроет.
     *
     * Поэтому конец полёта - подрыв, попадание, самоликвидация - уносит файлы с
     * собой. Выгрузка чанка сюда не попадает: ракета вернётся и её файлы ей ещё
     * понадобятся.
     *
     * Номер при этом не переиспользуется: счётчик номеров у ComputerCraft свой и
     * только растёт. Мы убираем мусор, а не изображаем сборщик.
     */
    private void deleteComputerFiles() {
        // Раньше это было привязано к INVFIX_TRACE: отчёт о полёте лежит на
        // диске самой ракеты, а уборка сносит этот диск ровно в тот момент,
        // когда отчёт становится полным - при подрыве. Поэтому на время
        // разбора полётов уборку держали выключенной вместе с трассировкой.
        // Разбор окончен, и оставлять её выключенной значит копить в
        // saves/<мир>/computercraft/computer по каталогу на каждый пуск
        // навсегда - см. комментарий класса ниже. Уборка снова работает
        // всегда, независимо от INVFIX_TRACE.
        if (computerId < 0) return;
        MinecraftServer server = level().getServer();
        if (server == null) return;
        Path dir = ServerContext.get(server).storageDir().resolve("computer")
                .resolve(Integer.toString(computerId));
        computerId = -1;
        if (!Files.isDirectory(dir)) return;
        try (Stream<Path> walk = Files.walk(dir)) {
            // файлы раньше каталогов, иначе каталог не пуст и не удалится
            for (Path path : walk.sorted(Comparator.reverseOrder()).toList()) {
                Files.deleteIfExists(path);
            }
        } catch (IOException e) {
            com.mojang.logging.LogUtils.getLogger()
                    .warn("[invfix] could not remove missile computer files at {}", dir, e);
        }
    }

    // ---- persistence ----

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt(NBT_COMPUTER_ID, computer != null ? computer.getID() : computerId);
        tag.putString(NBT_VARIANT, variant.name());
        tag.putString(NBT_CHASSIS, chassis.name());
        tag.putInt(NBT_AGE, flightAge);
        if (computer != null) tag.putUUID(NBT_INSTANCE, computer.getInstanceUUID());
        control.save(tag);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        computerId = tag.getInt(NBT_COMPUTER_ID);
        flightAge = tag.getInt(NBT_AGE);
        if (tag.contains(NBT_VARIANT)) {
            try {
                variant = MissileVariant.valueOf(tag.getString(NBT_VARIANT));
            } catch (IllegalArgumentException ignored) {
            }
        }
        if (tag.contains(NBT_CHASSIS)) {
            try {
                chassis = MissileChassis.valueOf(tag.getString(NBT_CHASSIS));
            } catch (IllegalArgumentException ignored) {
            }
        }
        if (tag.hasUUID(NBT_INSTANCE)) adoptInstance = tag.getUUID(NBT_INSTANCE);
        control.load(tag);
        // Загрузка из NBT - это всегда возврат после выгрузки чанка или
        // перезапуска сервера. Работавший компьютер при этом закрыт, программа
        // стартует заново и секунду-другую ничего не скажет. Лететь это время на
        // старых командах - значит держать рули и газ, выставленные под
        // положение, которого уже нет. Поэтому до первой новой команды ракета
        // летит по баллистике; запал, взведение и топливо сохраняются.
        control.neutral();
    }

    // ---- MissileHost ----

    @Override
    public MissileVariant variant() {
        return variant;
    }

    public MissileChassis chassis() {
        return chassis;
    }

    @Override
    public MissileControlState controlState() {
        return control;
    }

    @Override
    public Level hostLevel() {
        return level();
    }

    @Override
    public Vec3 currentPosition() {
        return position();
    }

    @Override
    public Vec3 currentVelocity() {
        return getDeltaMovement();
    }

    @Override
    public Vec3 currentOrientation() {
        Vec3 v = getDeltaMovement();
        return v.lengthSqr() > 1.0E-9 ? v.normalize() : getOrientation();
    }

    /**
     * Летит ли ещё.
     *
     * Не «является ли снарядом»: после подрыва или удара сущность уничтожена, но
     * пульт продолжает отвечать на вызовы, а программа - крутиться. Вечное
     * «да» превращало это в тихий обман: телеметрия застывала на последних
     * значениях, и цикл ожидания полёта не заканчивался никогда.
     */
    @Override
    public boolean isFlying() {
        return !isRemoved();
    }

    @Override
    public int flightAge() {
        return flightAge;
    }

    @Override
    public int burnTicks() {
        return variant.burnTicks() + chassis.extraBurnTicks();
    }

    @Override
    public BallisticPropertiesComponent ballistics() {
        return getBallisticProperties();
    }

    @Override
    public boolean launch() {
        return false;
    }

    // ---- CBC plumbing ----

    @Override
    public BlockState getRenderedBlockState() {
        return MissileRegistry.block(variant, chassis).getDefaultState()
                .setValue(BlockStateProperties.FACING, Direction.NORTH);
    }

    @Nonnull
    @Override
    protected BigCannonProjectilePropertiesComponent getBigCannonProjectileProperties() {
        return getAllProperties().bigCannonProperties();
    }

    @Nonnull
    @Override
    public EntityDamagePropertiesComponent getDamageProperties() {
        return getAllProperties().damage();
    }

    @Nonnull
    @Override
    protected BallisticPropertiesComponent getBallisticProperties() {
        return getAllProperties().ballistics();
    }

    protected BigCannonCommonShellProperties getAllProperties() {
        return (BigCannonCommonShellProperties) CBCMunitionPropertiesHandlers
                .COMMON_SHELL_BIG_CANNON_PROJECTILE.getPropertiesOf(this);
    }
}