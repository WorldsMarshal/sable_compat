package com.invfix.missile;

import java.util.Locale;

/**
 * The three missiles, which differ only in what the computer on board can see.
 *
 * All three are the same airframe and the same computer. PROGRAMMABLE is deaf
 * once it leaves the rail - whatever it was told before launch is all it will
 * ever know. SARH adds an ender modem, so a computer on the ground can keep
 * talking to it in flight and illuminate a target for it; the missile itself
 * still cannot see anything. ARH adds a seeker of its own, so it can find and
 * hold a target with nobody helping it.
 *
 * None of them steer themselves. Every one of these is a bare computer bolted
 * to a motor with a set of raw actuators - the guidance law, the datalink
 * protocol, the authentication on that datalink and the decision to detonate
 * are all things the player writes in Lua.
 */
/**
 * Головы ракеты и время работы двигателя под каждой.
 *
 * ВРЕМЯ ГОРЕНИЯ И ДАЛЬНОСТЬ. Топливо тратится только на тиках, когда тяга
 * включена, поэтому число здесь - это секунды работы двигателя, а не срок
 * жизни. Тяга даёт 0.55 блока за тик в квадрате, сопротивление линейное с
 * коэффициентом 0.02, отсюда установившаяся скорость 27.5 блока в тик, и на
 * разгон до неё уходит около пятидесяти тиков.
 *
 * Отсюда и числа. Вертикальный пуск, разворот на высоте, крейсер на тяге и
 * планирование после выгорания дают по расчёту:
 *
 *     300 тиков горения - около 8000 блоков
 *     400 тиков         - около 10800
 *     500 тиков         - около 13500
 *     800 тиков         - около 21500
 *
 * Сначала было четыреста - под требование «дальше семи тысяч» с запасом на
 * неоптимальный профиль: настоящая программа не летит идеальным крейсером, а
 * тратит топливо на довороты и на набор высоты. Потом запас удвоен у всех
 * ракет: 800, 880 и 960 тиков по вариантам, надбавки корпусов тоже вдвое.
 *
 * Важная оговорка для того, кто пишет программу: рули работают, только пока
 * топливо не кончилось. Тяга при этом расходует его, а нулевая - нет, поэтому
 * выключенный двигатель сохраняет управление сколько угодно долго, а вот
 * выгоревшая досуха ракета превращается в болванку и рулей не имеет. Запас на
 * терминальный участок оставляет программа, а не корпус.
 */
public enum MissileVariant {

    PROGRAMMABLE(false, false, 800),
    SARH(true, false, 880),
    ARH(true, true, 960);

    private final boolean modem;
    private final boolean radar;
    private final int burnTicks;

    MissileVariant(boolean modem, boolean radar, int burnTicks) {
        this.modem = modem;
        this.radar = radar;
        this.burnTicks = burnTicks;
    }

    /** Приставка идентификатора: {@code sarh_} + корпус. */
    public String prefix() {
        return name().toLowerCase(Locale.ROOT);
    }

    /** Полный путь регистрации, например {@code sarh_aphe_rocket}. */
    public String id(MissileChassis chassis) {
        return prefix() + "_" + chassis.id();
    }

    /** Whether an ender modem is built into the airframe. */
    public boolean hasModem() {
        return modem;
    }

    /** Whether the airframe carries its own seeker. */
    public boolean hasRadar() {
        return radar;
    }

    /**
     * Ticks the motor will burn for.
     *
     * Lives here rather than in the munition properties file because CBC has no
     * such field - its ballistics describe gravity, drag and penetration, and
     * nothing about how long something thrusts, for the good reason that
     * ordinary shells do not. The heavier airframes carry more propellant, so
     * the number grows with the equipment they haul.
     */
    public int burnTicks() {
        return burnTicks;
    }
}