package com.invfix.missile;

import com.mojang.serialization.MapCodec;
import com.simibubi.create.foundation.block.IBE;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.BlockHitResult;
import dan200.computercraft.shared.computer.blocks.AbstractComputerBlockEntity;
import dan200.computercraft.shared.computer.core.ServerComputer;
import dan200.computercraft.shared.network.container.ComputerContainerData;
import dan200.computercraft.shared.platform.PlatformHelper;
import rbasamoyai.createbigcannons.munitions.big_cannon.ProjectileBlock;

/**
 * The missile as a block: a munition that can be racked, rammed and fired like
 * any other, and a computer terminal while it sits there.
 *
 * Two things happen here that do not happen on an ordinary shell. Right-clicking
 * opens the computer rather than doing nothing, which is how the missile is
 * programmed - and only while it is a block, because there is no terminal to
 * open on something moving at Mach 2. And getProjectile, which CBC calls when
 * the launcher lets go, is where the computer changes owner.
 */
public class MissileBlock extends ProjectileBlock<MissileProjectile> implements IBE<MissileBlockEntity> {

    /**
     * Скорость схода с места, блоков в тик.
     *
     * У стеллажных ракет Military Supplement это 0.3 плюс {@code initial_vel} из
     * их свойств, а у обычной he_rocket там двойка, то есть 2.3. Здесь столько
     * же: программируемая ракета от них отличается головой, а не двигателем, и
     * разная скорость схода сбивала бы сравнение.
     */
    private static final float LAUNCH_SPEED = 2.3F;

    private final MissileVariant variant;
    private final MissileChassis chassis;
    private final MapCodec<MissileBlock> codec;

    public MissileBlock(BlockBehaviour.Properties properties, MissileVariant variant,
                        MissileChassis chassis) {
        super(properties);
        this.variant = variant;
        this.chassis = chassis;
        this.codec = simpleCodec(p -> new MissileBlock(p, variant, chassis));
    }

    public MissileVariant variant() {
        return variant;
    }

    public MissileChassis chassis() {
        return chassis;
    }

    @Override
    protected MapCodec<MissileBlock> codec() {
        return codec;
    }

    @Override
    public EntityType<MissileProjectile> getAssociatedEntityType() {
        return MissileRegistry.entityType(variant, chassis).get();
    }

    @Override
    public Class<MissileBlockEntity> getBlockEntityClass() {
        return MissileBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends MissileBlockEntity> getBlockEntityType() {
        return MissileRegistry.BLOCK_ENTITY.get();
    }

    /**
     * Тикер блок-сущности. Без него компьютер ракеты живёт ровно пять секунд.
     *
     * Тикер сюда должен был прийти по наследству, но не пришёл ни от кого.
     * У ComputerCraft он раздаётся из {@code AbstractComputerBlock}, а мы
     * наследуемся от {@code ProjectileBlock} — это боеприпас, а не компьютер.
     * У Create {@code IBE.getTicker} возвращает тикер только если блок-сущность
     * является {@code SmartBlockEntity}; наша наследует {@code ComputerBlockEntity}
     * от CC и таковой не является, поэтому там честный null.
     *
     * В итоге {@code serverTick} не вызывался никогда, а значит не вызывался и
     * {@code keepAlive}. Реестр ComputerCraft выбрасывает компьютер, не
     * подавший признаков жизни сотню тиков, — отсюда и терминал, гаснущий через
     * пять секунд, и необходимость кликать дважды: первый клик поднимал
     * компьютер заново, второй успевал открыть по нему меню.
     */
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                  BlockEntityType<T> type) {
        if (level.isClientSide) return null;
        return (lvl, pos, st, be) -> {
            if (be instanceof MissileBlockEntity missile) missile.serverTick();
        };
    }

    // ---- programming the thing ----

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                               Player player, BlockHitResult hit) {
        if (player.isCrouching()) return super.useWithoutItem(state, level, pos, player, hit);
        BlockEntity be = level.getBlockEntity(pos);
        if (!(be instanceof AbstractComputerBlockEntity computer)) {
            return super.useWithoutItem(state, level, pos, player, hit);
        }
        if (!level.isClientSide && computer.isUsable(player)) {
            ServerComputer server = computer.createServerComputer();
            server.turnOn();
            // Без копирования компонентов: collectSafeComponents у CC защищён и
            // снаружи недоступен. Стек нужен меню только для показа предмета,
            // и голого хватает - метка компьютера приходит отдельно, через
            // getName.
            PlatformHelper.get().openMenu(player, computer.getName(), computer,
                    new ComputerContainerData(server, new ItemStack(this)));
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    // ---- launch ----

    /**
     * Fired from a rack or a cannon that had the block loaded.
     *
     * The block entity is already gone by now, but its NBT is in hand, and that
     * NBT carries the id of the ServerComputer that was running in it a tick ago.
     * Handing that id to the entity is the entire trick: the entity finds the
     * live computer in CC's registry and adopts it, so the program that was
     * counting down to launch simply keeps counting.
     */
    @Override
    public MissileProjectile getProjectile(Level level, List<StructureTemplate.StructureBlockInfo> projectileBlocks) {
        CompoundTag nbt = projectileBlocks.isEmpty() ? null : projectileBlocks.get(0).nbt();
        return build(level, MissileBlockEntity.readInstance(nbt), nbt);
    }

    @Override
    public MissileProjectile getProjectile(Level level, ItemStack itemStack) {
        // loaded straight from the item: no live computer, but the id the item
        // remembers still points at the same filesystem
        return build(level, null, null);
    }

    @Override
    public MissileProjectile getProjectile(Level level, BlockPos pos, BlockState state) {
        UUID instance = null;
        MissileControlState control = null;
        int id = -1;
        if (level.getBlockEntity(pos) instanceof MissileBlockEntity be) {
            instance = be.computerInstance();
            control = be.control();
            // Номер компьютера, а не только ссылка на работающий экземпляр.
            //
            // Ссылка - это удача: блок-сущность при сносе закрывает свой
            // компьютер, и если она успеет сделать это раньше, чем ракета его
            // подберёт, подбирать будет нечего. Номер же переживает что угодно,
            // а вместе с ним переживает и файловая система - то есть startup,
            // ради которого всё и затевалось. Без него ракета взлетала бы с
            // пустым диском и молчала.
            id = be.getComputerID();
        }
        MissileProjectile projectile = build(level, instance, null);
        if (projectile != null) {
            projectile.inherit(variant, chassis, id, instance, control);
        }
        return projectile;
    }

    // ---- соседи ----

    /**
     * Изменения соседей - компьютеру, как у любого компьютера ComputerCraft.
     *
     * Раньше здесь был пуск по редстоуну, а до компьютера сигнал не доходил
     * вовсе: у CC входы обновляются из {@code AbstractComputerBlock.neighborChanged},
     * а мы наследуемся от снаряда CBC. Компьютер видел только то, что было
     * вокруг в момент своего создания, и {@code redstone.getInput} врал.
     *
     * Теперь сигнал - это просто вход компьютера. Пускает ракету программа,
     * вызовом {@code launch()} на пульте, и только если сама так решила.
     */
    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block block,
                                BlockPos neighbour, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, block, neighbour, movedByPiston);
        if (level.isClientSide()) return;
        if (level.getBlockEntity(pos) instanceof MissileBlockEntity be) be.neighborChanged(neighbour);
    }

    /** То же для периферии: CC пересобирает сторону, форма соседа которой поменялась. */
    @Override
    protected BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                     LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (level.getBlockEntity(pos) instanceof MissileBlockEntity be) be.neighbourShapeChanged(direction);
        return super.updateShape(state, direction, neighborState, level, pos, neighborPos);
    }

    // ---- пуск с места ----

    /**
     * Собрать ракету, снять блок и отпустить её по направлению носа.
     *
     * Зовётся только из {@code launch()} пульта, на главном потоке. Скорость
     * схода {@link #LAUNCH_SPEED} даётся всегда, тяга здесь ни при чём.
     *
     * @return ракета, или null, если собрать не удалось
     */
    @Nullable
    MissileProjectile launchFromBlock(Level level, BlockPos pos, BlockState state) {
        MissileProjectile projectile = getProjectile(level, pos, state);
        if (projectile == null) return null;

        Direction facing = state.getValue(FACING);
        Vec3 dir = Vec3.atLowerCornerOf(facing.getNormal());

        // Появиться на блок впереди по оси: иначе ракета рождается внутри
        // собственного блока, а тот на этом же тике ещё стоит.
        projectile.setPos(pos.getX() + 0.5 + dir.x,
                pos.getY() + 0.5 + dir.y,
                pos.getZ() + 0.5 + dir.z);
        projectile.shoot(dir.x, dir.y, dir.z, LAUNCH_SPEED, 0.0F);

        // Отдать компьютер снаряду живым: снос блок-сущности его закрывает, а
        // закрытый компьютер снаряду пришлось бы поднимать заново, с полной
        // загрузкой ComputerCraft поверх уже начавшегося полёта.
        if (level.getBlockEntity(pos) instanceof MissileBlockEntity be) {
            be.handOverComputer();
            be.markLaunched(projectile);
        }
        level.removeBlock(pos, false);
        level.addFreshEntity(projectile);
        return projectile;
    }

    private @Nullable MissileProjectile build(Level level, @Nullable UUID instance, @Nullable CompoundTag nbt) {
        MissileProjectile projectile = getAssociatedEntityType().create(level);
        if (projectile == null) return null;
        int id = nbt != null && nbt.contains("ComputerId") ? nbt.getInt("ComputerId") : -1;
        MissileControlState control = null;
        if (nbt != null) {
            control = new MissileControlState();
            control.load(nbt);
        }
        projectile.inherit(variant, chassis, id, instance, control);
        return projectile;
    }

    /** Convenience for the projectile's rendered state. */
    public BlockState getDefaultState() {
        return defaultBlockState();
    }
}