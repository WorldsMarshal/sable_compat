package com.invfix.debug;

import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Диагностика зависаний сервера: если тик идёт дольше {@link #REPORT_MS} мс,
 * в latest.log пишется, чем всё это время был занят поток сервера.
 *
 * Отдельный поток раз в {@link #SAMPLE_MS} мс смотрит, не затянулся ли текущий
 * тик (дольше {@link #START_MS}), и снимает стек потока сервера. В конце
 * долгого тика одинаковые стеки складываются, и в лог уходят самые частые —
 * с числом снимков (≈ доля времени тика). Строки лога — с меткой
 * «invfix/lag».
 */
@EventBusSubscriber(modid = "sable_compat")
public final class LagSampler {

    private static final Logger LOG = LoggerFactory.getLogger("invfix/lag");

    /** Тик дольше этого — в лог. */
    private static final long REPORT_MS = 250;
    /** Стек начинают снимать, когда тик идёт дольше этого. */
    private static final long START_MS = 100;
    private static final long SAMPLE_MS = 10;
    private static final int MAX_SAMPLES = 2000;
    /** Сколько разных стеков показать и сколько строк в каждом. */
    private static final int TOP = 4;
    private static final int FRAMES = 90;
    /** По скольким верхним кадрам стеки считаются одинаковыми. */
    private static final int KEY_FRAMES = 30;

    private static volatile Thread serverThread;
    /** Начало текущего тика (System.nanoTime), 0 — сервер между тиками. */
    private static volatile long tickStart;
    private static final ConcurrentLinkedQueue<StackTraceElement[]> SAMPLES = new ConcurrentLinkedQueue<>();
    private static Thread sampler;

    private LagSampler() {}

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onTickStart(ServerTickEvent.Pre event) {
        serverThread = Thread.currentThread();
        SAMPLES.clear();
        tickStart = System.nanoTime();
        if (sampler == null) start();
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onTickEnd(ServerTickEvent.Post event) {
        long start = tickStart;
        tickStart = 0L;
        if (start == 0L) return;
        long ms = (System.nanoTime() - start) / 1_000_000L;
        if (ms < REPORT_MS) return;
        List<StackTraceElement[]> samples = new ArrayList<>(SAMPLES);
        SAMPLES.clear();
        report(ms, samples, event.getServer().getTickCount());
    }

    @SubscribeEvent
    public static void onStopped(ServerStoppedEvent event) {
        tickStart = 0L;
        serverThread = null;
        SAMPLES.clear();
    }

    private static synchronized void start() {
        if (sampler != null) return;
        Thread t = new Thread(LagSampler::loop, "invfix-lag-sampler");
        t.setDaemon(true);
        t.setPriority(Thread.MAX_PRIORITY);
        sampler = t;
        t.start();
    }

    private static void loop() {
        while (true) {
            try {
                Thread.sleep(SAMPLE_MS);
            } catch (InterruptedException e) {
                return;
            }
            long start = tickStart;
            Thread thread = serverThread;
            if (start == 0L || thread == null) continue;
            if ((System.nanoTime() - start) / 1_000_000L < START_MS) continue;
            if (SAMPLES.size() >= MAX_SAMPLES) continue;
            StackTraceElement[] stack = thread.getStackTrace();
            // тик мог кончиться, пока снимали стек, — такой снимок не про этот тик
            if (tickStart == start) SAMPLES.add(stack);
        }
    }

    private static void report(long ms, List<StackTraceElement[]> samples, int tick) {
        Map<String, Integer> counts = new HashMap<>();
        Map<String, StackTraceElement[]> stacks = new HashMap<>();
        for (StackTraceElement[] s : samples) {
            StringBuilder key = new StringBuilder();
            for (int i = 0; i < Math.min(KEY_FRAMES, s.length); i++) key.append(s[i]).append('\n');
            String k = key.toString();
            counts.merge(k, 1, Integer::sum);
            stacks.putIfAbsent(k, s);
        }
        List<Map.Entry<String, Integer>> sorted = new ArrayList<>(counts.entrySet());
        sorted.sort((a, b) -> b.getValue() - a.getValue());

        StringBuilder out = new StringBuilder();
        out.append("Долгий тик сервера: ").append(ms).append(" мс (тик ").append(tick).append("), снимков стека: ")
                .append(samples.size()).append(" (раз в ").append(SAMPLE_MS).append(" мс после первых ")
                .append(START_MS).append(" мс)");
        for (int n = 0; n < Math.min(TOP, sorted.size()); n++) {
            Map.Entry<String, Integer> e = sorted.get(n);
            StackTraceElement[] s = stacks.get(e.getKey());
            out.append("\n--- стек #").append(n + 1).append(": ").append(e.getValue()).append(" из ")
                    .append(samples.size()).append(" снимков ---");
            for (int i = 0; i < Math.min(FRAMES, s.length); i++) out.append("\n\tat ").append(s[i]);
            if (s.length > FRAMES) out.append("\n\t... ещё ").append(s.length - FRAMES);
        }
        // самые «горячие» методы по всем снимкам (верхние 3 кадра — что именно крутилось)
        Map<String, Integer> top = new HashMap<>();
        for (StackTraceElement[] s : samples) {
            for (int i = 0; i < Math.min(3, s.length); i++) top.merge(s[i].getClassName() + "." + s[i].getMethodName(), 1, Integer::sum);
        }
        List<Map.Entry<String, Integer>> hot = new ArrayList<>(top.entrySet());
        hot.sort((a, b) -> b.getValue() - a.getValue());
        out.append("\n--- верх стека по всем снимкам ---");
        for (int i = 0; i < Math.min(15, hot.size()); i++) {
            out.append("\n\t").append(hot.get(i).getValue()).append("  ").append(hot.get(i).getKey());
        }
        // все наши и Invincible-кадры, встреченные в снимках (кто вызвал)
        Map<String, Integer> ours = new HashMap<>();
        for (StackTraceElement[] s : samples) {
            java.util.Set<String> seen = new java.util.HashSet<>();
            for (StackTraceElement f : s) {
                String c = f.getClassName();
                if (c.startsWith("com.invfix.") || c.startsWith("net.mcreator.")) {
                    String k = c + "." + f.getMethodName() + ":" + f.getLineNumber();
                    if (seen.add(k)) ours.merge(k, 1, Integer::sum);
                }
            }
        }
        List<Map.Entry<String, Integer>> oursSorted = new ArrayList<>(ours.entrySet());
        oursSorted.sort((a, b) -> b.getValue() - a.getValue());
        out.append("\n--- кадры sable_compat / Invincible в снимках ---");
        for (int i = 0; i < Math.min(25, oursSorted.size()); i++) {
            out.append("\n\t").append(oursSorted.get(i).getValue()).append("  ").append(oursSorted.get(i).getKey());
        }
        LOG.warn(out.toString());
    }
}
