package com.invfix.debug;

import com.invfix.ip.core.mixin.client.particle.IEParticle;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.client.particle.ParticleRenderType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

/**
 * Временная диагностика «пропадают все частицы и анимация подбора»: раз в тик клиента
 * смотрит, дошёл ли ParticleEngine#tick до конца, растёт ли очередь новых частиц
 * (particlesToAdd — её рост привёл к OutOfMemoryError), тот ли мир у движка частиц, что у
 * игры, и не уехала ли камера от игрока (частицы дальше 32 блоков от камеры не создаются).
 * Пишет в лог «invfix/particles» только при входе в сбой, раз в 30 с пока он длится и при
 * выходе из него. Ничего не исправляет.
 */
@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class ParticleWatchdog {

    private static final Logger LOG = LoggerFactory.getLogger("invfix/particles");

    /** Сколько тиков подряд признак держится, прежде чем считать это сбоем (2 с). */
    private static final int CONFIRM = 40;
    /** Повтор снимка, пока сбой длится, тиков (30 с). */
    private static final int REPEAT = 600;
    /** Камера дальше этого от глаз игрока — признак, блоков (F5 — около 4). */
    private static final double CAMERA_FAR = 32.0;
    /** Очередь новых частиц больше этого — признак. */
    private static final int QUEUE_BIG = 20000;

    /** Доступ к полям движка (ParticleEngineWatchMixin). */
    public interface Engine {
        ClientLevel invfix$watchLevel();
        Queue<Particle> invfix$watchQueued();
        Map<ParticleRenderType, Queue<Particle>> invfix$watchLive();
    }

    private static int ticksDone;
    private static int rendersDone;
    private static int rendersSinceTick;
    private static int noTick, wrongLevel, cameraFar, queueBig;
    private static boolean failing;
    private static long failingSince;
    private static int repeat;
    private static boolean hooksLogged;

    private ParticleWatchdog() {}

    public static void tickCompleted() {
        ticksDone++;
    }

    public static void renderCompleted() {
        rendersDone++;
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.isPaused() || !(mc.particleEngine instanceof Engine engine)) {
            ticksDone = 0;
            rendersDone = 0;
            return;
        }
        try {
            check(mc, engine);
        } catch (Throwable t) {
            LOG.warn("[particles] проверка упала", t);
        }
    }

    private static void check(Minecraft mc, Engine engine) {
        int ticks = ticksDone;
        rendersSinceTick = rendersDone;
        ticksDone = 0;
        rendersDone = 0;

        Camera camera = mc.gameRenderer.getMainCamera();
        double camDist = camera.getPosition().distanceTo(mc.player.getEyePosition());
        int queued = engine.invfix$watchQueued().size();

        noTick = ticks == 0 ? noTick + 1 : 0;
        wrongLevel = engine.invfix$watchLevel() != mc.level ? wrongLevel + 1 : 0;
        cameraFar = camDist > CAMERA_FAR ? cameraFar + 1 : 0;
        queueBig = queued > QUEUE_BIG ? queueBig + 1 : 0;

        boolean bad = noTick >= CONFIRM || wrongLevel >= CONFIRM || cameraFar >= CONFIRM || queueBig >= CONFIRM;
        if (bad && !failing) {
            failing = true;
            failingSince = System.currentTimeMillis();
            repeat = 0;
            LOG.warn("[particles] СБОЙ частиц начался: {}", snapshot(mc, engine, ticks, camDist, queued, true));
            if (!hooksLogged) {
                hooksLogged = true;
                LOG.warn("[particles] миксины в ParticleEngine: {}", hooks(ParticleEngine.class, null));
                LOG.warn("[particles] миксины в Minecraft (tick): {}", hooks(Minecraft.class, "tick"));
            }
        } else if (bad) {
            if (++repeat >= REPEAT) {
                repeat = 0;
                LOG.warn("[particles] сбой длится {} с: {}", (System.currentTimeMillis() - failingSince) / 1000,
                        snapshot(mc, engine, ticks, camDist, queued, false));
            }
        } else if (failing) {
            failing = false;
            LOG.warn("[particles] сбой частиц закончился через {} с: {}", (System.currentTimeMillis() - failingSince) / 1000,
                    snapshot(mc, engine, ticks, camDist, queued, true));
        }
    }

    private static String snapshot(Minecraft mc, Engine engine, int ticks, double camDist, int queued, boolean full) {
        StringBuilder sb = new StringBuilder();
        sb.append("tick движка за тик=").append(ticks).append(" (подряд без него ").append(noTick).append(')')
                .append(", render за тик=").append(rendersSinceTick)
                .append(", в очереди particlesToAdd=").append(queued);
        ClientLevel engineLevel = engine.invfix$watchLevel();
        sb.append(", мир движка ").append(engineLevel == mc.level ? "= мир игры" : "≠ мир игры (" + name(engineLevel) + " вместо " + name(mc.level) + ")");
        sb.append(", камера от глаз=").append(String.format("%.1f", camDist))
                .append(" (камера ").append(mc.gameRenderer.getMainCamera().getPosition()).append(')');
        sb.append(", настройка частиц=").append(mc.options.particles().get());
        sb.append(", Time Stop внутри=").append(com.invfix.timestop.TimeStopClientState.localInsideTimeStop);
        sb.append(", проход портала=").append(com.invfix.portal.client.PortalPassCompat.inPortalPass());
        if (full) {
            int live = 0, alien = 0;
            for (Queue<Particle> q : engine.invfix$watchLive().values()) {
                for (Particle p : q) {
                    live++;
                    if (((IEParticle) p).portal_getWorld() != mc.level) alien++;
                }
            }
            sb.append(", живых частиц=").append(live).append(" (из чужого мира ").append(alien).append(')');
        }
        return sb.toString();
    }

    private static String name(ClientLevel level) {
        return level == null ? "null" : level.dimension().location() + "@" + Integer.toHexString(System.identityHashCode(level));
    }

    /** Методы, добавленные миксинами (в имени — id мода), по желанию — только с подстрокой в имени. */
    private static String hooks(Class<?> type, String filter) {
        List<String> out = new ArrayList<>();
        for (Method m : type.getDeclaredMethods()) {
            String n = m.getName();
            if (!n.contains("$")) continue;
            if (filter != null && !n.toLowerCase().contains(filter)) continue;
            out.add(n);
        }
        return out.toString();
    }
}
