package com.invfix.mixin.simulated;

import com.invfix.simulated.IAnalogTransmissionControl;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.infrastructure.config.AllConfigs;
import dev.simulated_team.simulated.content.blocks.analog_transmission.AnalogTransmissionBlockEntity;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Прямое задание оборотов умной передаче.
 *
 * Штатно передача работает как редуктор с шестнадцатью ступенями: редстоун даёт
 * множитель {@code 1 - (signal+1)/16}, ведомая сторона получает скорость
 * ведущей, умноженную на него. Регулятор скорости из Create устроен похоже —
 * задаётся отношение, а не результат.
 *
 * Здесь всё наоборот. Компьютер называет обороты, которые должны быть на ведомой
 * стороне, а множитель считается сам, от фактической скорости ведущей: если вход
 * замедлился, множитель вырастет и выход останется на заданном. Это уже не
 * редуктор, а регулятор.
 *
 * Какая сторона ведомая — определяется не настройкой, а тем, откуда пришло
 * вращение. Create зовёт {@code propagateRotationTo} в направлении
 * распространения, поэтому цель вызова и есть ведомая сторона: пришло на
 * шестерню — управляем шестернёй, пришло на вал — валом.
 *
 * Потолок — только {@code maxRotationSpeed} из конфига Create, а не шестнадцать
 * ступеней вниз. Ускорение при этом ничего не даёт бесплатно: чем быстрее
 * крутится ведомая сторона, тем больше нагрузка, и если ведущее вращение её не
 * тянет, сеть встаёт по обычным правилам Create. Мы только задаём обороты,
 * платить за них приходится мощностью.
 */
@Mixin(value = AnalogTransmissionBlockEntity.class, remap = false)
public abstract class AnalogTransmissionControlMixin extends KineticBlockEntity
        implements IAnalogTransmissionControl {

    @Unique
    private @Nullable Float invfix$target;

    public AnalogTransmissionControlMixin(net.minecraft.world.level.block.entity.BlockEntityType<?> type,
                                          BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    @Unique
    private AnalogTransmissionBlockEntity invfix$self() {
        return (AnalogTransmissionBlockEntity) (Object) this;
    }

    @Unique
    private KineticBlockEntity invfix$cog() {
        return invfix$self().getExtraKinetics();
    }

    // ---- сам расчёт ----

    /**
     * Подменить множитель, пока управляет компьютер.
     *
     * Отношение считается от скорости ведущей стороны на этом же шаге
     * распространения — ровно там, где ванильный код читает
     * {@code extraWheel.getTheoreticalSpeed()} для своей проверки на перебор,
     * так что момент вызова заведомо подходящий.
     *
     * Обратной связи здесь нет: выход не влияет на вход, поэтому пересчёт
     * множителя при изменении входа не раскачивается.
     */
    @Inject(method = "propagateRotationTo", at = @At("HEAD"), cancellable = true, require = 0)
    private void invfix$computerRatio(KineticBlockEntity target, BlockState stateFrom,
                                      BlockState stateTo, BlockPos diff, boolean viaAxes,
                                      boolean viaCogs, CallbackInfoReturnable<Float> cir) {
        Float wanted = invfix$target;
        if (wanted == null) return;

        // ноль — это остановленная ведомая сторона, а не разорванная передача
        if (wanted == 0.0F) {
            cir.setReturnValue(0.0F);
            return;
        }

        KineticBlockEntity source = target == invfix$cog() ? this : invfix$cog();
        float in = Math.abs(source.getTheoreticalSpeed());
        if (in < 1.0E-4F) {
            cir.setReturnValue(0.0F);
            return;
        }

        float max = AllConfigs.server().kinetics.maxRotationSpeed.get();
        float out = Math.min(Math.abs(wanted), max);
        cir.setReturnValue(Math.signum(wanted) * out / in);
    }

    // ---- управление ----

    @Override
    public @Nullable Float invfix$targetSpeed() {
        return invfix$target;
    }

    /**
     * Сменить задание и заново собрать кинетическую сеть.
     *
     * Тот же порядок, которым передача отрабатывает изменение редстоуна: без
     * пересборки Create не узнает, что отношение поменялось, и продолжит крутить
     * по старому до ближайшего постороннего изменения.
     */
    @Override
    public void invfix$setTargetSpeed(@Nullable Float rpm) {
        Float previous = invfix$target;
        if (rpm == null) {
            invfix$target = null;
        } else {
            float max = AllConfigs.server().kinetics.maxRotationSpeed.get();
            invfix$target = Math.max(-max, Math.min(max, rpm));
        }
        if (java.util.Objects.equals(previous, invfix$target)) return;

        AnalogTransmissionBlockEntity self = invfix$self();
        KineticBlockEntity cog = invfix$cog();
        self.detachKinetics();
        cog.detachKinetics();
        self.removeSource();
        cog.removeSource();
        cog.attachKinetics();
        self.attachKinetics();
        self.setChanged();
    }

    @Override
    public float invfix$shaftSpeed() {
        return invfix$self().getSpeed();
    }

    @Override
    public float invfix$cogSpeed() {
        return invfix$cog().getSpeed();
    }

    @Override
    public boolean invfix$shaftDriven() {
        return !invfix$self().hasSource() && invfix$cog().hasSource();
    }

    // ---- сохранение ----

    @Inject(method = "write", at = @At("TAIL"), require = 0)
    private void invfix$write(CompoundTag tag, HolderLookup.Provider registries,
                              boolean clientPacket, CallbackInfo ci) {
        if (invfix$target != null) tag.putFloat("InvfixTargetSpeed", invfix$target);
    }

    @Inject(method = "read", at = @At("TAIL"), require = 0)
    private void invfix$read(CompoundTag tag, HolderLookup.Provider registries,
                             boolean clientPacket, CallbackInfo ci) {
        invfix$target = tag.contains("InvfixTargetSpeed") ? tag.getFloat("InvfixTargetSpeed") : null;
    }
}
