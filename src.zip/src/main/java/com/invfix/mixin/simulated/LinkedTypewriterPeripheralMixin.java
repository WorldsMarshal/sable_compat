package com.invfix.mixin.simulated;

import dan200.computercraft.api.lua.LuaException;
import dan200.computercraft.api.lua.LuaFunction;
import dev.simulated_team.simulated.content.blocks.redstone.linked_typewriter.LinkedTypewriterBlockEntity;
import dev.simulated_team.simulated.content.blocks.redstone.linked_typewriter.LinkedTypewriterEntries;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/**
 * Даёт компьютеру полное управление печатной машинкой.
 *
 * Своя периферия тут не подошла бы: CC разрешает ровно одну периферию на блок,
 * а Simulated уже вешает свою через {@code SimPeripheralService}. Поэтому методы
 * дописываются прямо в их класс — с точки зрения Lua это та же самая
 * {@code linked_typewriter}, просто умеющая больше. Существующие
 * {@code getPressedKeyCodes} и события {@code key}/{@code key_up} остаются как
 * были, ничего не ломается.
 *
 * Обратная связь у машинки уже была — она шлёт {@code key} и {@code key_up} при
 * нажатиях игрока. Не хватало ровно противоположного: компьютер не мог нажать
 * сам, не мог посмотреть привязки клавиш к частотам редстоун-линка и не мог
 * узнать, кто за ней сидит. Теперь может всё это, и ретрансляция получается в
 * обе стороны: комп читает нажатия игрока событиями, а свои шлёт вызовами.
 *
 * {@code press}/{@code release} идут через те же {@code pressKey} и
 * {@code releaseKey}, что и игрок, поэтому активируются те же частоты, набирается
 * тот же текст и остальным подключённым компьютерам приходят те же события —
 * машинка не отличает, кто нажал.
 */
@Mixin(value = dev.simulated_team.simulated.compat.computercraft.peripherals.LinkedTypewriterPeripheral.class,
        remap = false)
public abstract class LinkedTypewriterPeripheralMixin {

    /**
     * Поле лежит в родительском SimPeripheral, а не здесь, поэтому @Shadow его
     * не находит - ищет он только в самом целевом классе. Достаём через
     * аксессор, поставленный на родителя.
     */
    @Unique
    private LinkedTypewriterBlockEntity invfix$typewriter() throws LuaException {
        BlockEntity be = ((SimPeripheralAccessor) this).invfix$blockEntity();
        if (be instanceof LinkedTypewriterBlockEntity typewriter) return typewriter;
        throw new LuaException("typewriter is gone");
    }

    // ---- нажатия со стороны компьютера ----

    /** Зажать клавишу по GLFW-коду. Держится, пока не отпустят. */
    @LuaFunction(mainThread = true)
    public final void press(int key) throws LuaException {
        LinkedTypewriterBlockEntity be = invfix$typewriter();
        if (be.getPressedKeys().contains(key)) return;
        be.pressKey(key);
        be.notifyUpdate();
    }

    @LuaFunction(mainThread = true)
    public final void release(int key) throws LuaException {
        LinkedTypewriterBlockEntity be = invfix$typewriter();
        if (!be.getPressedKeys().contains(key)) return;
        be.releaseKey(key);
        be.notifyUpdate();
    }

    /**
     * Нажать и сразу отпустить.
     *
     * Один тик удержания: этого хватает, чтобы редстоун-линк успел щёлкнуть, а
     * машинка — набрать символ, но клавиша не залипает, если программа упадёт
     * между press и release.
     */
    @LuaFunction(mainThread = true)
    public final void tap(int key) throws LuaException {
        LinkedTypewriterBlockEntity be = invfix$typewriter();
        if (!be.getPressedKeys().contains(key)) be.pressKey(key);
        be.releaseKey(key);
        be.notifyUpdate();
    }

    /** Отпустить всё разом — страховка на случай оборванной программы. */
    @LuaFunction(mainThread = true)
    public final void releaseAll() throws LuaException {
        LinkedTypewriterBlockEntity be = invfix$typewriter();
        for (Object key : new ArrayList<>(be.getPressedKeys())) {
            be.releaseKey((Integer) key);
        }
        be.notifyUpdate();
    }

    /** Набрать строку посимвольно. Возвращает, сколько символов ушло. */
    @LuaFunction(mainThread = true)
    public final int type(String text) throws LuaException {
        LinkedTypewriterBlockEntity be = invfix$typewriter();
        int sent = 0;
        for (int i = 0; i < text.length(); i++) {
            int key = text.charAt(i);
            if (!be.getPressedKeys().contains(key)) be.pressKey(key);
            be.releaseKey(key);
            sent++;
        }
        if (sent > 0) be.notifyUpdate();
        return sent;
    }

    // ---- чтение состояния ----

    /** Строка, набранная на машинке, последние 25 символов. */
    @LuaFunction
    public final String getTypedEntry() throws LuaException {
        return invfix$typewriter().getTypedEntry();
    }

    @LuaFunction
    public final boolean isKeyDown(int key) throws LuaException {
        return invfix$typewriter().getPressedKeys().contains(key);
    }

    /** Занята ли машинка игроком. Компьютеру это не мешает, но знать полезно. */
    @LuaFunction
    public final boolean isInUse() throws LuaException {
        return invfix$typewriter().isInUse();
    }

    /** Выгнать игрока из машинки. */
    @LuaFunction(mainThread = true)
    public final void disconnectUser() throws LuaException {
        invfix$typewriter().disconnectUser();
    }

    /**
     * Привязки клавиш к частотам редстоун-линка.
     *
     * Для каждой занятой клавиши — её GLFW-код, активна ли она сейчас и пара
     * предметов-частот, по которым она вещает. Без этого программа не могла
     * узнать, что вообще делает нажатие, и приходилось держать соответствие
     * где-то у себя в коде.
     */
    @LuaFunction
    public final List<Map<String, Object>> getBindings() throws LuaException {
        LinkedTypewriterEntries entries = invfix$typewriter().getTypewriterEntries();
        List<Map<String, Object>> out = new ArrayList<>();
        for (Object raw : entries.getEntries()) {
            if (!(raw instanceof LinkedTypewriterEntries.KeyboardEntry entry)) continue;
            Map<String, Object> m = new HashMap<>();
            m.put("key", entry.getGLFWKeyCode());
            m.put("active", entry.isAlive());
            m.put("first", entry.getFirstAsItemStack().getItem().toString());
            m.put("second", entry.getSecondAsItemStack().getItem().toString());
            out.add(m);
        }
        return out;
    }

    @LuaFunction
    public final int getBindingCount() throws LuaException {
        return invfix$typewriter().getTypewriterEntries().getSize();
    }

    /** Снять все привязки. Сами клавиши остаются, вещать перестают. */
    @LuaFunction(mainThread = true)
    public final void clearBindings() throws LuaException {
        LinkedTypewriterBlockEntity be = invfix$typewriter();
        be.getTypewriterEntries().deactivateAll();
        be.getTypewriterEntries().clearAll();
        be.notifyUpdate();
    }
}
