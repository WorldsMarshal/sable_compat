package com.invfix.mixin.simulated;

import dev.simulated_team.simulated.compat.computercraft.peripherals.SimPeripheral;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Открывает защищённое поле {@code blockEntity} у базовой периферии Simulated.
 *
 * {@code @Shadow} умеет видеть только поля самого целевого класса и не ищет их в
 * родителях. Поле объявлено в {@code SimPeripheral}, а миксин с новыми методами
 * висит на наследнике - отсюда и падение на применении с формулировкой "field
 * blockEntity was not located in the target class".
 *
 * Аксессор ставится на тот класс, где поле действительно объявлено, и оттуда
 * его уже видно всем. Методов для Lua здесь нарочно нет: миксин на
 * {@code SimPeripheral} задел бы заодно и рычаг тяги, и всё остальное, что
 * Simulated отдаёт компьютерам.
 */
@Mixin(value = SimPeripheral.class, remap = false)
public interface SimPeripheralAccessor {

    @Accessor("blockEntity")
    BlockEntity invfix$blockEntity();
}
