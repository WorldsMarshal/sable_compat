package com.invfix.mixin.simulated;

import dev.simulated_team.simulated.compat.computercraft.AttachedComputerHandler;
import dev.simulated_team.simulated.content.blocks.redstone.linked_typewriter.LinkedTypewriterBlockEntity;
import java.util.UUID;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Досылает компьютеру то, о чём машинка раньше молчала.
 *
 * События нажатий она отправляла и сама, а вот факт того, что за неё сел или
 * встал игрок, оставался невидимым: программа могла узнать об этом только
 * опросом {@code isInUse} в цикле. Для ретрансляции управления это важно —
 * автопилоту надо понимать момент, когда человек взялся за штурвал, чтобы
 * отдать управление, и момент, когда отпустил, чтобы забрать обратно.
 *
 * Событие {@code typewriter_user} с UUID игрока и признаком подключения.
 */
@Mixin(value = LinkedTypewriterBlockEntity.class, remap = false)
public abstract class LinkedTypewriterUserEventsMixin {

    // Поле объявлено final, поэтому одного @Shadow мало: без @Final миксин
    // падает на применении, а не на компиляции - искать потом дольше.
    @Shadow
    @Final
    public AttachedComputerHandler computerHandler;

    @Inject(method = "checkAndStartUsing", at = @At("RETURN"), require = 0)
    private void invfix$onStartUsing(UUID userID, CallbackInfoReturnable<Boolean> cir) {
        if (Boolean.TRUE.equals(cir.getReturnValue()) && computerHandler != null) {
            computerHandler.queueEvent("typewriter_user", userID.toString(), true);
        }
    }

    @Inject(method = "sendDisconnectMessage", at = @At("HEAD"), require = 0)
    private void invfix$onStopUsing(Player player, CallbackInfo ci) {
        if (computerHandler != null) {
            computerHandler.queueEvent("typewriter_user", player.getStringUUID(), false);
        }
    }
}
