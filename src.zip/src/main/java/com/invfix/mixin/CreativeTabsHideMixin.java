package com.invfix.mixin;

import net.mcreator.invincibleinc.InvincibleIncMod;
import net.mcreator.invincibleinc.init.InvincibleIncModTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredRegister;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Полностью убирает Invincible Inc из креативного инвентаря: вещи мода больше
 * нельзя достать мышкой — только через команды (/give и т.п.).
 *
 * Делается в два захода, потому что мод раскидывает вещи в ДВА места:
 *   1) шесть своих вкладок (race / power / bloodline / armor_suits_and_drip /
 *      blue_prints / invincible_np_cs) — их вообще не регистрируем, поэтому
 *      вкладки не появляются совсем (а не просто пустые);
 *   2) вшивание вещей в ванильные вкладки (Spawn Eggs, Ingredients,
 *      Functional/Building/Redstone Blocks, Tools) через @SubscribeEvent —
 *      этот обработчик отменяем.
 */
public final class CreativeTabsHideMixin {

    private CreativeTabsHideMixin() {}

    /**
     * В конструкторе мода пропускаем ровно одну строку —
     * {@code InvincibleIncModTabs.REGISTRY.register(modEventBus)} — определяя её
     * по идентичности самого DeferredRegister. Все прочие реестры (items, blocks,
     * entities, effects, ...) регистрируются как обычно.
     */
    @Mixin(value = InvincibleIncMod.class, remap = false)
    public static class SkipTabRegistry {

        @Redirect(
                method = "<init>(Lnet/neoforged/bus/api/IEventBus;)V",
                at = @At(
                        value = "INVOKE",
                        target = "Lnet/neoforged/neoforge/registries/DeferredRegister;register(Lnet/neoforged/bus/api/IEventBus;)V"
                ),
                remap = false
        )
        private void invfix_skipCreativeTabRegistry(DeferredRegister registry, IEventBus bus) {
            if (registry == InvincibleIncModTabs.REGISTRY) {
                return; // вкладки мода не регистрируем
            }
            registry.register(bus);
        }
    }

    /**
     * Отменяем добавление вещей мода в ванильные вкладки.
     */
    @Mixin(value = InvincibleIncModTabs.class, remap = false)
    public static class NoVanillaTabItems {

        @Inject(method = "buildTabContentsVanilla", at = @At("HEAD"), cancellable = true, remap = false)
        private static void invfix_noVanillaTabItems(BuildCreativeModeTabContentsEvent tabData, CallbackInfo ci) {
            ci.cancel();
        }
    }
}