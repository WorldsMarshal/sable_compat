package com.invfix.mixin;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.heatvision.HeatVisionHandler;
import com.invfix.kineticstrike.KineticStrikeHandler;
import com.invfix.timestop.TimeStopHandler;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.procedures.AbilityCallProcedure;
import net.mcreator.invincibleinc.util.InputState;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Диспетчер кастомных способностей по нажатой клавише слота:
 *  - Heat Vision / Neutron Beam — только Altrumite (луч);
 *  - Kinetic Strike — Viltrumite + Altrumite (рывок);
 *  - Time Stop — только Altrumite (зона остановки времени, тумблер);
 *  - Heat Disruption — только Alien(Metroman), LVL 500 (тепловой луч).
 */
@Mixin(value = AbilityCallProcedure.class, remap = false)
public class AbilityCallProcedureMixin {

    /** Unlimited Void: под эффектом способности не работают — ни мода, ни наши. */
    @Inject(method = "execute", at = @At("HEAD"), cancellable = true, remap = false)
    private static void invfix_unlimitedVoidBlock(
            LevelAccessor world, double x, double y, double z, Entity entity, CallbackInfo ci) {
        if (!world.isClientSide() && com.invfix.unlimitedvoid.UnlimitedVoid.frozen(entity)) ci.cancel();
    }

    @Inject(method = "execute", at = @At("TAIL"), remap = false)
    private static void invfix_dispatchAbility(
            LevelAccessor world, double x, double y, double z, Entity entity, CallbackInfo ci) {

        if (world.isClientSide()) return;
        if (!(entity instanceof ServerPlayer player)) return;

        try {
            InvincibleIncModVariables.PlayerVariables v =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);

            // Имя способности в нажатом слоте
            String pressed = pressedAbility(entity, v);

            // Time Stop — тумблер по фронту нажатия, поэтому состояние клавиши
            // нужно и тогда, когда она отпущена (pressed == null). Процедура
            // крутится каждый тик из OnplayerTickProcedure, так что фронт ловится
            // надёжно, а удержание клавиши не мигает остановкой.
            TimeStopHandler.handleKeyState(player, TimeStopHandler.ABILITY.equals(pressed));
            // The Whole Sentry Power — тумблер по фронту нажатия
            com.invfix.sentry.SentryHandler.handleKeyState(player,
                    com.invfix.sentry.SentryHandler.ABILITY.equals(pressed));
            // Thermal Sense — тумблер по фронту нажатия
            com.invfix.thermal.ThermalHandler.handleKeyState(player,
                    com.invfix.thermal.ThermalHandler.ABILITY.equals(pressed));
            // Six Eyes — тумблер по фронту нажатия
            com.invfix.sixeyes.SixEyesHandler.handleKeyState(player,
                    com.invfix.sixeyes.SixEyesHandler.ABILITY.equals(pressed));
            // Energy Blast — заряд, пока клавиша зажата, выстрел — когда отпущена:
            // состояние клавиши нужно и при отпущенной (pressed == null)
            com.invfix.energyblast.EnergyBlastHandler.handleKeyState(player,
                    com.invfix.energyblast.EnergyBlastHandler.ABILITY.equals(pressed));

            // Shapeshifter (Kitsune) — превращение по фронту нажатия (Shift — меню на клиенте);
            // Morph Ability — активная способность морфа
            com.invfix.shapeshift.ShapeshiftHandler.handleKeyState(player,
                    com.invfix.shapeshift.ShapeshiftHandler.ABILITY.equals(pressed));
            com.invfix.shapeshift.ShapeshiftHandler.handleMorphAbilityKey(player,
                    com.invfix.shapeshift.ShapeshiftHandler.ABILITY_MORPH.equals(pressed));
            // Size Difference (Kitsune) — размер вкл/выкл по фронту нажатия (Shift — меню на клиенте)
            com.invfix.sizediff.SizeHandler.handleKeyState(player,
                    com.invfix.sizediff.SizeHandler.ABILITY.equals(pressed));
            // Fox Hole (Kitsune) — войти / выйти / перенести цель по фронту нажатия (Shift — меню на клиенте)
            com.invfix.foxhole.FoxHoleHandler.handleKeyState(player,
                    com.invfix.foxhole.FoxHole.ABILITY.equals(pressed));
            // Domain Expansion: Unlimited Void (Kitsune) — раскрыть / закрыть территорию по фронту нажатия
            com.invfix.unlimitedvoid.UnlimitedVoidHandler.handleKeyState(player,
                    com.invfix.unlimitedvoid.UnlimitedVoid.ABILITY.equals(pressed));
            // 3D-2D (Kitsune) — войти в 2D / выйти по фронту нажатия (Shift — меню на клиенте)
            com.invfix.flat.FlatHandler.handleKeyState(player,
                    com.invfix.flat.Flat.ABILITY.equals(pressed));
            // 3D-2D: Attack (Kitsune) — цель под прицелом в 2D по фронту нажатия (Shift — меню режима)
            com.invfix.flat.FlatAttack.handleKeyState(player,
                    com.invfix.flat.FlatAttack.ABILITY.equals(pressed));
            // 4D Offset (Kitsune) — сместиться в 4D / вернуться по фронту нажатия
            com.invfix.fourd.FourDHandler.handleKeyState(player,
                    com.invfix.fourd.FourD.ABILITY.equals(pressed));

            if (pressed == null) return;

            // Heat Vision / Neutron — только Altrumite
            if (HeatVisionHandler.ABILITY_RED.equals(pressed)) {
                invfix_fireOrCharge(player, v, HeatVisionHandler.MODE_RED);
                return;
            }
            if (HeatVisionHandler.ABILITY_BLUE.equals(pressed)) {
                invfix_fireOrCharge(player, v, HeatVisionHandler.MODE_BLUE);
                return;
            }
            // Kinetic Strike — Viltrumite + Altrumite
            if (KineticStrikeHandler.ABILITY.equals(pressed)) {
                KineticStrikeHandler.activate(player);
                return;
            }
            // Space Fold — только Alien(Metroman), LVL 1000 (одно нажатие — один разлом; Shift — меню угла)
            if (com.invfix.spacefold.SpaceFoldHandler.ABILITY.equals(pressed)) {
                com.invfix.spacefold.SpaceFoldHandler.onKeyHeld(player);
                return;
            }
            // Prism Ward — только Alien(Metroman), LVL 40 (одно нажатие — один щит; Shift — меню на клиенте)
            if (com.invfix.prismward.PrismWardHandler.ABILITY.equals(pressed)) {
                com.invfix.prismward.PrismWardHandler.onKeyHeld(player);
                return;
            }
            // Mystic Portal — только Alien(Metroman), LVL 200 (одно нажатие — один портал; Shift — меню на клиенте)
            if (com.invfix.mysticportal.MysticPortalHandler.ABILITY.equals(pressed)) {
                com.invfix.mysticportal.MysticPortalHandler.onKeyHeld(player);
                return;
            }
            // Dismantle — только Alien(Metroman), LVL 100 (одно нажатие — один разрез; Shift — меню на клиенте)
            if (com.invfix.dismantle.DismantleHandler.ABILITY.equals(pressed)) {
                com.invfix.dismantle.DismantleHandler.onKeyHeld(player);
                return;
            }
            // Heat Disruption — только Alien(Metroman), LVL 500
            if (com.invfix.heatdisruption.HeatDisruptionHandler.ABILITY.equals(pressed)) {
                com.invfix.heatdisruption.HeatDisruptionHandler.activate(player);
                return;
            }
        } catch (Exception ignored) {}
    }

    /**
     * Зажат Alt → зарядка (только свечение, без лазера); отпущен → реальный луч.
     * AbilityCallProcedure крутится каждый тик, поэтому переход «отпустил Alt →
     * выстрел» отрабатывает сам собой на текущем состоянии флага.
     */
    private static void invfix_fireOrCharge(ServerPlayer player,
                                            InvincibleIncModVariables.PlayerVariables v, int mode) {
        if (!AltrumiteRace.isAltrumiteLike(v.Race)) return;
        if (HeatVisionHandler.isChargeHeld(player)) {
            HeatVisionHandler.markCharging(player, mode);
        } else {
            HeatVisionHandler.activate(player, mode);
        }
    }

    /** Возвращает строку способности из нажатого слота (текущий ряд), либо null. */
    private static String pressedAbility(Entity entity, InvincibleIncModVariables.PlayerVariables v) {
        boolean row1 = v.AbilityRow == 1.0;
        if (InputState.ability1(entity)) return row1 ? v.AbilitySlot1 : v.AbilitySlot1_row2;
        if (InputState.ability2(entity)) return row1 ? v.AbilitySlot2 : v.AbilitySlot2_row2;
        if (InputState.ability3(entity)) return row1 ? v.AbilitySlot3 : v.AbilitySlot3_row2;
        if (InputState.ability4(entity)) return row1 ? v.AbilitySlot4 : v.AbilitySlot4_row2;
        if (InputState.ability5(entity)) return row1 ? v.AbilitySlot5 : v.AbilitySlot5_row2;
        return null;
    }
}