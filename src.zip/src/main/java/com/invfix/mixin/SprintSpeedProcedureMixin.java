package com.invfix.mixin;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Правки эффекта скорости при беге.
 *
 * 1) Блокирует эффект скорости при беге для расы Human ниже 10 уровня
 *    (остальные расы не затронуты).
 *
 * 2) Срезает самый нижний тир скорости: на «скорости 1» эффекта скорости больше
 *    нет, эффект начинается со «скорости 2» и выше.
 *
 *    В оригинале эффект вешается как
 *    {@code addEffect(MOVEMENT_SPEED, 20, (int)Speed, ...)}, то есть амплитуда
 *    эффекта = (int)Speed (значение скорости из оверлея). Значит:
 *      Speed == 1 → amplifier 1 → режем (эффекта нет);
 *      Speed >= 2 → amplifier >= 2 → пропускаем как было.
 *    Магнитуду эффекта при этом НЕ трогаем — просто отсекаем единицу.
 */
@Mixin(value = net.mcreator.invincibleinc.procedures.SprintSpeedProcedure.class, remap = false)
public class SprintSpeedProcedureMixin {

    @Inject(
            method = "execute(Lnet/minecraft/world/entity/Entity;)V",
            at = @At("HEAD"),
            cancellable = true,
            remap = false
    )
    private static void invfix_blockHumanSprintSpeed(Entity entity, CallbackInfo ci) {
        if (entity == null) return;
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            boolean isHuman = vars.Race.equals("§f§lHuman") || vars.Race.equals("§lHuman");
            if (isHuman && vars.Lvl < 10.0) {
                ci.cancel();
            }
        } catch (Exception ignored) {}
    }

    /**
     * Перехватываем навешивание эффекта скорости: если итоговая скорость == 1
     * (amplifier 1), эффект не выдаём вовсе. Со скорости 2 (amplifier >= 2)
     * — всё как в оригинале.
     */
    @Redirect(
            method = "execute(Lnet/minecraft/world/entity/Entity;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/LivingEntity;addEffect(Lnet/minecraft/world/effect/MobEffectInstance;)Z"
            ),
            remap = false
    )
    private static boolean invfix_noSpeedEffectAtLevel1(LivingEntity self, MobEffectInstance effect) {
        if (effect.getAmplifier() < 2) {
            return false; // скорость 1 (и ниже) — без эффекта скорости
        }
        return self.addEffect(effect);
    }
}