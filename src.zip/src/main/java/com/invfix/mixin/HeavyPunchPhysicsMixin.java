package com.invfix.mixin;

import com.invfix.physics.RacialPunch;
import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.companion.math.JOMLConversion;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.sublevel.SubLevel;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Heavy Punch (ПКМ в боевом режиме) по физической постройке.
 *
 * Оригинальная HeavyAttackProcedure бьёт только по сущностям в AABB и
 * вообще не трогает sable-постройки. Здесь мы добавляем толчок постройки,
 * на которую смотрит игрок, в ПОЛНУЮ силу (HEAVY_MULT), с потолком 600 м/с,
 * только для не-людских рас в боевом режиме.
 *
 * Рейкаст идёт через {@code level.clip(...)} — sable перекрывает clip и
 * возвращает попадание уже в ЛОКАЛЬНОЙ системе постройки, что и нужно
 * для applyImpulse.
 */
@Mixin(value = net.mcreator.invincibleinc.procedures.HeavyAttackProcedure.class, remap = false)
public class HeavyPunchPhysicsMixin {

    private static final double INVFIX_REACH = 5.0;

    @Inject(
            method = "execute(Lnet/minecraft/world/level/LevelAccessor;DDDLnet/minecraft/world/entity/Entity;)V",
            at = @At("TAIL"),
            remap = false
    )
    private static void invfix_heavyPunchPhysics(LevelAccessor world,
                                                 double x, double y, double z,
                                                 Entity entity,
                                                 CallbackInfo ci) {
        if (!(world instanceof ServerLevel level)) return;
        if (!(entity instanceof LivingEntity le)) return;

        InvincibleIncModVariables.PlayerVariables vars =
                entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        if (!RacialPunch.qualifies(vars)) return;   // людская раса / вне боя — выходим

        Vec3 eye  = le.getEyePosition(1.0F);
        Vec3 view = le.getViewVector(1.0F);
        Vec3 to   = eye.add(view.scale(INVFIX_REACH));

        BlockHitResult hit = level.clip(new ClipContext(
                eye, to, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, le));
        if (hit.getType() != HitResult.Type.BLOCK) return;

        // sable вернул попадание уже в локальной системе постройки
        Vector3d localHit = JOMLConversion.toJOML(hit.getLocation());

        SubLevel sl = Sable.HELPER.getContaining(level, (Vector3dc) localHit);
        if (!(sl instanceof ServerSubLevel target)) return;      // не постройка — пропускаем
        if (target == Sable.HELPER.getTrackingSubLevel(le)) return; // на чём стоим — не бьём

        Vector3d localDir = target.logicalPose()
                .transformNormalInverse(JOMLConversion.toJOML(view), new Vector3d());

        double delta = RacialPunch.targetDelta(vars, RacialPunch.HEAVY_MULT);
        RacialPunch.applyLocal(target, localHit, localDir, delta);
    }
}
