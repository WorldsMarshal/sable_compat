package com.invfix.mixin.powergrid;

import com.mojang.logging.LogUtils;
import net.minecraft.network.FriendlyByteBuf;
import org.patryk3211.powergrid.electricity.base.ElectricBehaviour;
import org.patryk3211.powergrid.electricity.base.ISynchronizedElement;
import org.patryk3211.powergrid.kinetics.generator.winding.WindingBlockEntity;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Фикс Create: Power Grid 0.5.5.1 (клиент):
 *   WARN  Buffer read overrun (Entry of 4 bytes, read 12 bytes) for ElectricBehaviour(be=...WindingBlockEntity@...)
 *   ERROR Error executing task on Client
 *   java.lang.IndexOutOfBoundsException: readerIndex(116) + length(4) exceeds writerIndex(116)
 *     at ElectricBehaviour.readFromSync
 *     at StateS2CPacket.handle
 *
 * ── ПРИЧИНА ─────────────────────────────────────────────────────────────────
 * WorldNetworks для обмотки генератора синхронизирует через WindingBlockEntity.forSync:
 * свой ElectricBehaviour + ThermalBehaviour каждой собранной катушки. ThermalBehaviour
 * пишет 4 байта (температура) под ключом StateS2CPacket.PosKey(позиция катушки).
 * Но PosKey.resolve на клиенте всегда ищет по позиции ElectricBehaviour.TYPE —
 * и находит ProxyElectricBehaviour той же катушки. Тот читает температуру (4 байта,
 * значение верное) и дальше — напряжения своих узлов (ещё 8 байт), залезая в
 * следующую запись пакета. Если запись последняя — чтение выходит за конец буфера,
 * handle() падает с исключением, и data.release() в его конце не вызывается
 * (утечка direct-буфера из пула на каждое падение).
 *
 * ── ФИКС ────────────────────────────────────────────────────────────────────
 * Протокол не трогаем (клиентский фикс, сервер без изменений). Каждый вызов
 * readFromSync внутри handle() получает буфер-срез ровно длиной своей записи
 * (длина — int, прочитанный handle() прямо перед resolve/readFromSync). Лишнее
 * чтение упирается в конец среза и гасится здесь же: температура катушки
 * применяется, узлы прокси не получают мусор (исключение летит при чтении
 * аргумента, до setStateValue), следующая запись читается с правильной позиции,
 * handle() доходит до release(). Позиция основного буфера выставляется на
 * start + прочитанное, поэтому штатные проверки overrun/underrun мода работают как раньше.
 */
@Mixin(targets = "org.patryk3211.powergrid.network.packets.StateS2CPacket", remap = false)
public abstract class PowergridStateSyncBoundsMixin {

    @Unique private static final Logger INVFIX_LOG = LogUtils.getLogger();
    @Unique private static final Set<Class<?>> INVFIX_REPORTED = ConcurrentHashMap.newKeySet();

    @Redirect(
            method = "handle",
            at = @At(
                    value = "INVOKE",
                    target = "Lorg/patryk3211/powergrid/electricity/base/ISynchronizedElement;readFromSync(Lnet/minecraft/network/FriendlyByteBuf;Z)V"
            ),
            remap = false
    )
    private void invfix$boundedReadFromSync(ISynchronizedElement element, FriendlyByteBuf buf, boolean useDoubles) {
        int start = buf.readerIndex();
        // handle(): entryLength = readInt(); element = key.resolve(level); start = readerIndex();
        // resolve() буфер не трогает — длина записи лежит в 4 байтах прямо перед start.
        int entryLength = start >= 4 ? buf.getInt(start - 4) : 0;
        int bounded = Math.max(0, Math.min(entryLength, buf.writerIndex() - start));

        FriendlyByteBuf entry = new FriendlyByteBuf(buf.slice(start, bounded));
        int consumed;
        try {
            element.readFromSync(entry, useDoubles);
            consumed = entry.readerIndex();
        } catch (IndexOutOfBoundsException overrun) {
            consumed = bounded;
            if (!invfix$isWindingCoilThermal(element, entryLength)
                    && INVFIX_REPORTED.add(element.getClass())) {
                INVFIX_LOG.warn("[sable_compat] Power Grid sync entry of {} bytes is shorter than {} expects; "
                        + "read clamped to the entry (reported once per class)", entryLength, element);
            }
        }
        buf.readerIndex(start + consumed);
    }

    /** Известный случай: 4-байтовая запись температуры катушки, разрешённая в её ProxyElectricBehaviour. */
    @Unique
    private static boolean invfix$isWindingCoilThermal(ISynchronizedElement element, int entryLength) {
        return entryLength == Float.BYTES
                && element instanceof ElectricBehaviour eb
                && eb.blockEntity instanceof WindingBlockEntity;
    }
}
