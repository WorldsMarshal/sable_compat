package com.invfix.mixin;

import com.invfix.theboys.BornForVPowers;
import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Иммунитет расы §a§lHuman(Born for V) к негативным эффектам Temp V из The Boys.
 *
 * Негатив Temp V в моде = «withdrawal» (ломка) и «overload» (передоз): штрафы к
 * макс. HP / скорости / атаке, истощение, замедление копки и срез HP при истечении.
 * Всё это запускается из двух точек в {@code TempVSideEffectHandler}:
 *   - onTemporaryVInjected → копит V-load и включает overload;
 *   - onTemporaryVExpired  → стартует withdrawal (+срез HP, +модификаторы).
 *
 * Отменяя обе для Born for V, мы добиваемся того, что withdrawal/overload НИКОГДА
 * не включаются. После этого штатный onPlayerTick видит withdrawalActive=false и
 * isTemporaryVOverloaded=false → идёт в ветки удаления модификаторов (т.е. сам
 * подчищает любые остаточные), а onBreakSpeed даёт множитель 1.0. Самих скиллов
 * Temp V это не трогает — отменяются только сайд-эффекты.
 *
 * Применяется только при наличии theboysmod (гейт в InvincibleIncMixinTransformer).
 * Параметр SkillData берётся как {@code @Coerce Object} — тип The Boys в миксине
 * не импортируется (как в TheBoysHumanVMixins).
 */
public final class TheBoysBornForVMixins {

    private TheBoysBornForVMixins() {}

    /** Born for V не копит V-load и не уходит в overload. */
    @Pseudo
    @Mixin(targets = "net.benniao.theboysmod.server.TempVSideEffectHandler", remap = false)
    public static class TempVInjectImmunity {
        @Inject(
                method = "onTemporaryVInjected",
                at = @At("HEAD"),
                cancellable = true,
                remap = false,
                require = 0
        )
        private static void invfix_bornForVNoLoad(ServerPlayer player, @Coerce Object data,
                                                  long gameTime, CallbackInfo ci) {
            if (BornForVPowers.isBornForV(player)) {
                ci.cancel();
            }
        }
    }

    /** У Born for V не стартует ломка при истечении Temp V (нет срезов и модификаторов). */
    @Pseudo
    @Mixin(targets = "net.benniao.theboysmod.server.TempVSideEffectHandler", remap = false)
    public static class TempVExpiryImmunity {
        @Inject(
                method = "onTemporaryVExpired",
                at = @At("HEAD"),
                cancellable = true,
                remap = false,
                require = 0
        )
        private static void invfix_bornForVNoWithdrawal(ServerPlayer player, @Coerce Object data,
                                                        long gameTime, CallbackInfo ci) {
            if (BornForVPowers.isBornForV(player)) {
                ci.cancel();
            }
        }
    }
}