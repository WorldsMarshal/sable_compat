package com.invfix.mixin;

import com.invfix.RaceCapsUtil;
import com.invfix.humanlike.HumanLikeRaces;
import com.invfix.theboyscompat.VBonusBridge;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Хардкап статов расы Human и человекоподобных рас (Born for V / Predisposition).
 *
 * ── Почему клэмп вообще нужен (а не «рояль») ──────────────────────────────────
 * У этих рас множитель XP в XpGiveProcedure = 0, но опыт/статы они всё равно могут
 * растить НЕ через бой: спортзал (WorkOutXpProcedure → strengthXP/defenseXP, без
 * расового гейта) и адреналин (currentStr/currentDura ×1.2, без гейта). Старение
 * трогает только вильтрумитов. Из currentDura каждые 20 тиков в StatAutomation
 * заново считается DTstat — без зануления у человека появился бы щит. Поэтому
 * капы приходится держать принудительно.
 *
 * ── Оптимизация TPS ──────────────────────────────────────────────────────────
 * «Пробивающие» поля для игроков пишутся только в теле StatAutomation под гейтом
 * {@code !isClientSide && tickCount % 20 == 0} (DTstat, DurabilityStatMultiplier),
 * либо сами держатся базой на DTstat (DamageTolerance клэмпится в OnplayerTick),
 * либо игрокам не пишутся вовсе (DamageReduction). Значит клэмп достаточно гонять
 * на ТОМ ЖЕ такте, что и пересчёт — раз в 20 тиков, а не каждый. TAIL-инжект
 * срабатывает каждый тик, поэтому тем же условием отсекаем лишние проходы (×20).
 * Возможный косметический перелёт currentStr/currentDura на ≤1 c (после тренировки)
 * щит не пробивает: DTstat зануляется в тот же такт, что и пересчёт.
 *
 * ── V-бонус ──────────────────────────────────────────────────────────────────
 * Humanlike-расы под активным Compound V (есть перм-скилл The Boys) получают
 * повышенные капы Durability/Damage Tolerance:
 *   Predisposition → currentDura/trueDura 25, DTstat 25;
 *   Born for V     → currentDura/trueDura 50, DTstat 80.
 * DamageTolerance не пиннится — копится регеном и тратится в бою (clamp до DTstat).
 * При снятии V провайдер вернёт false → отработает обычный человеческий клэмп и
 * бонус снимется сам собой.
 */
@Mixin(value = net.mcreator.invincibleinc.procedures.StatAutomationProcedure.class, remap = false)
public class HumanCapsMixin {

    private static final String HUMAN_RACE = "§f§lHuman";
    private static final double MAX_LEVEL  = 10.0;
    private static final double MAX_STAT   = 5.0;

    @Inject(
            method = "execute(Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/entity/Entity;)V",
            at = @At("TAIL"), remap = false
    )
    private static void invfix_applyHumanCaps(LevelAccessor world, Entity entity, CallbackInfo ci) {
        if (entity == null) return;
        // Тот же такт, что и пересчёт StatAutomation — иначе работы зря (×20 к TPS).
        if (world.isClientSide() || entity.tickCount % 20 != 0) return;
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);

            double uiCap = RaceCapsUtil.getLvlMaxForUI(vars.Race);
            if (vars.LvlMax != uiCap) vars.LvlMax = uiCap;

            boolean human     = HUMAN_RACE.equals(vars.Race);
            boolean humanlike = HumanLikeRaces.isHumanLike(vars.Race);
            if (!human && !humanlike) {
                vars.markSyncDirty();
                return;
            }

            // V-бонус только для humanlike под активным Compound V.
            if (humanlike && VBonusBridge.isCompoundVActive(entity)) {
                applyVBonus(vars);
                return;
            }

            // Кибер-бонус: Сердце наномашин (фаза 10). Активность — по пингам моста,
            // гаснет сама при снятии импланта (кап вернёт нули следующим тактом).
            if (entity instanceof net.minecraft.world.entity.LivingEntity living
                    && com.invfix.cybercompat.CyberBonusBridge.isHeartActive(living)) {
                applyHeartBonus(vars, com.invfix.cybercompat.CyberBonusBridge.isUnleashed(living));
                return;
            }

            // Обычный человеческий хардкап.
            boolean dirty = false;
            if (vars.Lvl > MAX_LEVEL)              { vars.Lvl          = MAX_LEVEL; dirty = true; }
            if (vars.currentStr   > MAX_STAT)      { vars.currentStr   = MAX_STAT;  dirty = true; }
            if (vars.currentDura  > MAX_STAT)      { vars.currentDura  = MAX_STAT;  dirty = true; }
            if (vars.currendSpeed > MAX_STAT)      { vars.currendSpeed = MAX_STAT;  dirty = true; }
            if (vars.trueStr      > MAX_STAT)      { vars.trueStr      = MAX_STAT;  dirty = true; }
            if (vars.trueDura     > MAX_STAT)      { vars.trueDura     = MAX_STAT;  dirty = true; }
            if (vars.trueSpeed    > MAX_STAT)      { vars.trueSpeed    = MAX_STAT;  dirty = true; }
            if (vars.DamageTolerance   != 0.0)     { vars.DamageTolerance   = 0.0;  dirty = true; }
            if (vars.DTstat            != 0.0)     { vars.DTstat            = 0.0;  dirty = true; }
            if (vars.DamageReduction   != 0.0)     { vars.DamageReduction   = 0.0;  dirty = true; }
            if (vars.DamageReduced     != 0.0)     { vars.DamageReduced     = 0.0;  dirty = true; }
            if (vars.DurabilityStatMultiplier != 1.0) { vars.DurabilityStatMultiplier = 1.0; dirty = true; }
            if (dirty) vars.markSyncDirty();

        } catch (Exception ignored) {}
    }

    /**
     * Кибер-капы Сердца наномашин: щит Invincible вместо человеческого нуля.
     * Пассив — Dura 30 / DTstat 40; Unleashed (Сердце+Gen3) — Dura 50 / DTstat 80
     * (уровень Born for V). Урон Unleashed идёт атрибутом в NanoHeartItem —
     * Str-переменные остаются на человеческом капе, формулы Invincible не трогаем.
     */
    private static void applyHeartBonus(InvincibleIncModVariables.PlayerVariables vars, boolean unleashed) {
        double targetDura = unleashed ? 50.0 : 30.0;
        double targetTol  = unleashed ? 80.0 : 40.0;

        boolean dirty = false;
        if (vars.Lvl > MAX_LEVEL)        { vars.Lvl          = MAX_LEVEL; dirty = true; }
        if (vars.currentStr   > MAX_STAT){ vars.currentStr   = MAX_STAT;  dirty = true; }
        if (vars.currendSpeed > MAX_STAT){ vars.currendSpeed = MAX_STAT;  dirty = true; }
        if (vars.trueStr      > MAX_STAT){ vars.trueStr      = MAX_STAT;  dirty = true; }
        if (vars.trueSpeed    > MAX_STAT){ vars.trueSpeed    = MAX_STAT;  dirty = true; }
        if (vars.currentDura != targetDura) { vars.currentDura = targetDura; dirty = true; }
        if (vars.trueDura    != targetDura) { vars.trueDura    = targetDura; dirty = true; }
        if (vars.DTstat != targetTol)        { vars.DTstat = targetTol; dirty = true; }
        if (vars.DamageTolerance > targetTol){ vars.DamageTolerance = targetTol; dirty = true; }
        if (vars.DamageReduction != 0.0)     { vars.DamageReduction = 0.0; dirty = true; }
        if (vars.DamageReduced   != 0.0)     { vars.DamageReduced   = 0.0; dirty = true; }
        if (vars.DurabilityStatMultiplier != 1.0) { vars.DurabilityStatMultiplier = 1.0; dirty = true; }
        if (dirty) vars.markSyncDirty();
    }

    /** Повышенные капы Durability/Damage Tolerance для humanlike под Compound V. */
    private static void applyVBonus(InvincibleIncModVariables.PlayerVariables vars) {
        double targetDura;
        double targetTol;
        if (HumanLikeRaces.BORN_FOR_V.equals(vars.Race)) {
            targetDura = 50.0; targetTol = 80.0;
        } else { // PREDISPOSITION
            targetDura = 25.0; targetTol = 25.0;
        }

        boolean dirty = false;
        // Сила/скорость остаются на человеческом капе.
        if (vars.Lvl > MAX_LEVEL)        { vars.Lvl          = MAX_LEVEL; dirty = true; }
        if (vars.currentStr   > MAX_STAT){ vars.currentStr   = MAX_STAT;  dirty = true; }
        if (vars.currendSpeed > MAX_STAT){ vars.currendSpeed = MAX_STAT;  dirty = true; }
        if (vars.trueStr      > MAX_STAT){ vars.trueStr      = MAX_STAT;  dirty = true; }
        if (vars.trueSpeed    > MAX_STAT){ vars.trueSpeed    = MAX_STAT;  dirty = true; }
        // Durability фиксируем на V-значении (currentDura:trueDura в UI).
        if (vars.currentDura != targetDura) { vars.currentDura = targetDura; dirty = true; }
        if (vars.trueDura    != targetDura) { vars.trueDura    = targetDura; dirty = true; }
        // Потолок щита. DamageTolerance не зануляем — копится регеном, тратится в бою.
        if (vars.DTstat != targetTol)        { vars.DTstat = targetTol; dirty = true; }
        if (vars.DamageTolerance > targetTol){ vars.DamageTolerance = targetTol; dirty = true; }
        // %-резисты у humanlike нулевые, как у Human.
        if (vars.DamageReduction != 0.0)     { vars.DamageReduction = 0.0; dirty = true; }
        if (vars.DamageReduced   != 0.0)     { vars.DamageReduced   = 0.0; dirty = true; }
        if (vars.DurabilityStatMultiplier != 1.0) { vars.DurabilityStatMultiplier = 1.0; dirty = true; }
        if (dirty) vars.markSyncDirty();
    }
}