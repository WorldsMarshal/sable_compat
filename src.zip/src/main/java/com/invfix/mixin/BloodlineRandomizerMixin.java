package com.invfix.mixin;

import com.invfix.rick.RickBloodline;
import com.invfix.util.DebugUtils;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.random.RandomGenerator;
import java.util.random.RandomGeneratorFactory;

/**
 * Полная замена таблицы родословных Invincible Inc.
 *
 * Оригинал катал 1/20 на вильтрумите (четыре именные) и 1/10 на Beast / Human /
 * Unopan / Demon — то есть родословную получал каждый третий вильтрумит. Здесь
 * шансы срезаны до RARE_DENOM, Human и все человекоподобные подрасы (в т.ч.
 * The Boys-ветка) исключены полностью, и добавлен расо-независимый Rick C137.
 *
 * Точек входа у процедуры две — WhenjoinFirstTimeProcedure (строка 35, сразу после
 * рандома расы) и FullResetProcedure. Один этот миксин закрывает обе.
 *
 * Порядок бросков важен: Rick катается ПЕРВЫМ и вне зависимости от расы. Если
 * катать его после расовой таблицы, вильтрумит с четырьмя своими бросками будет
 * забирать почти все попытки.
 */
@Mixin(value = net.mcreator.invincibleinc.procedures.BloodlineRandomizerProcedure.class, remap = false)
public class BloodlineRandomizerMixin {

    // ── Настройка шансов. Всё, что нужно крутить — здесь. ───────────────────
    /** Rick C137 — 1 к 150000. Для ЛЮБОЙ расы. */
    private static final int RICK_DENOM = 150_000;
    /** Каждая именная родословная внутри своей расы — 1 к этому числу. */
    private static final int RARE_DENOM = 200;

    private static final String VILTRUMITE = "\u00a74\u00a7lViltrumite";
    private static final String BEAST      = "\u00a74\u00a7lBeast";
    private static final String UNOPAN     = "\u00a76\u00a7lUnopan";
    private static final String DEMON      = "\u00a7c\u00a7lDemon";

    @Inject(
            method = "execute(Lnet/minecraft/world/entity/Entity;)V",
            at = @At("HEAD"),
            cancellable = true,
            remap = false
    )
    private static void invfix_replaceBloodlineRandomizer(Entity entity, CallbackInfo ci) {
        ci.cancel();
        if (entity == null) return;
        if (DebugUtils.tryApply(entity)) return;

        InvincibleIncModVariables.PlayerVariables vars =
                entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        if (vars == null) return;

        long seed = System.nanoTime() ^ (entity.getId() * 0x9E3779B97F4A7C15L);
        RandomGenerator rng = RandomGeneratorFactory.of("SplittableRandom").create(seed);

        String result = roll(rng, vars.Race);
        if (result == null) {
            // Безродный: в поле пишется собственный ник, как в оригинале.
            result = "\u00a7f\u00a7l" + vars.IGN;
        }
        vars.Bloodline = result;
        vars.markSyncDirty();
    }

    /** @return строку родословной или {@code null}, если игрок остаётся безродным. */
    private static String roll(RandomGenerator rng, String race) {
        // 1. Rick C137 — вне рас. Катается всем, включая Human и все подрасы The Boys.
        if (rng.nextInt(RICK_DENOM) == 0) return RickBloodline.RICK;

        // 2. Расовые именные родословные. Human и человекоподобные подрасы
        //    (Human-Viltrumite, Thraxan-Viltrumite, Born for V, Predisposition,
        //    Alien(Metroman)) в таблице отсутствуют — они дают +статы, а этим расам
        //    добавка не положена.
        if (race == null) return null;

        if (race.equals(VILTRUMITE)) {
            if (rng.nextInt(RARE_DENOM) == 0) return "\u00a74\u00a7lArgall";
            if (rng.nextInt(RARE_DENOM) == 0) return "\u00a74\u00a7lThragg";
            if (rng.nextInt(RARE_DENOM) == 0) return "\u00a7b\u00a7lAnissa";
            if (rng.nextInt(RARE_DENOM) == 0) return "\u00a76\u00a7lConquest";
            return null;
        }
        if (race.equals(BEAST)) {
            return rng.nextInt(RARE_DENOM) == 0 ? "\u00a74\u00a7lThokk" : null;
        }
        if (race.equals(UNOPAN)) {
            return rng.nextInt(RARE_DENOM) == 0 ? "\u00a76\u00a7lAllen" : null;
        }
        if (race.equals(DEMON)) {
            return rng.nextInt(RARE_DENOM) == 0 ? "\u00a74\u00a7lClan Darkblood" : null;
        }
        return null;
    }
}