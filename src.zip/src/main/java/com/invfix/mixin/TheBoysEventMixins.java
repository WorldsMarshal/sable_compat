package com.invfix.mixin;

import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Отключение всех скриптовых событий The Boys, мешающих обычному выживанию.
 * Каждый tick-обработчик отменяется в HEAD.
 *
 * @Pseudo + require=0 + проверка в плагине (shouldApplyMixin) → без мода The Boys
 * миксины не применяются и ничего не ломают.
 *
 * Отключаются:
 *  - HomelanderIntroHandler  — принудительный спавн Homelander + мобов через 3 мин
 *  - ATrainDrugEventHandler  — спавн A-Train у деревни
 *  - ATrainDrugAftermathHandler — пост-событие компенсаций/NDA
 *  - GuangdongVillaPartyHandler — событие виллы
 *
 * НЕ трогаем HomelanderCleanupHandler — это уборщик стрей-сущностей, не событие.
 */
public final class TheBoysEventMixins {

    private TheBoysEventMixins() {}

    @Pseudo
    @Mixin(targets = "net.benniao.theboysmod.server.HomelanderIntroHandler", remap = false)
    public static class HomelanderIntro {
        @Inject(method = "onServerTick", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
        private void invfix_off(ServerTickEvent.Post event, CallbackInfo ci) { ci.cancel(); }
    }

    @Pseudo
    @Mixin(targets = "net.benniao.theboysmod.server.ATrainDrugEventHandler", remap = false)
    public static class ATrainDrug {
        @Inject(method = "onServerTick", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
        private void invfix_off(ServerTickEvent.Post event, CallbackInfo ci) { ci.cancel(); }
    }

    @Pseudo
    @Mixin(targets = "net.benniao.theboysmod.server.ATrainDrugAftermathHandler", remap = false)
    public static class ATrainAftermath {
        @Inject(method = "onServerTick", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
        private void invfix_off(ServerTickEvent.Post event, CallbackInfo ci) { ci.cancel(); }
    }

    @Pseudo
    @Mixin(targets = "net.benniao.theboysmod.server.GuangdongVillaPartyHandler", remap = false)
    public static class VillaParty {
        @Inject(method = "onLevelTick", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
        private static void invfix_off(LevelTickEvent.Post event, CallbackInfo ci) { ci.cancel(); }
    }
}