package com.invfix.mixin;

import com.invfix.humanlike.HumanLikeRaces;
import com.invfix.scourge.ScourgeVirusState;
import net.mcreator.invincibleinc.init.InvincibleIncModMobEffects;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.Event;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Полная замена приватного execute() в XpGiveProcedure.
 *
 * ── Логика прокачки ──────────────────────────────────────────────────────────
 * Формула уровня в моде (для всех статов и общего Lvl одинаковая):
 *     while (statXP >= statXPcap) { stat += 1; statXP -= statXPcap;
 *                                   statXPcap += rand(1..10); }  // капа растёт линейно
 * То есть с каждым уровнем капа увеличивается в среднем на 5.5 — прокачка
 * естественно замедляется на высоких уровнях.
 *
 * ── Combat mode ──────────────────────────────────────────────────────────────
 * ВНЕ combat mode: множитель у всех рас 1.0 (человек 1/9), прокачка ПЛОСКАЯ —
 *   она замедляется с ростом капы, как ванильная.
 *
 * В combat mode: применяются расовые множители, и прокачка ДИНАМИЧЕСКАЯ —
 *   прибавка XP домножается на (текущая_капа / REFERENCE_CAP), что компенсирует
 *   рост капы. Поэтому множитель x3 ощущается одинаково на 10 и на 1000 уровне.
 *
 * Защита (damage tolerance) качается через defenseXP → currentDura → DTstat,
 * поэтому расовый множитель влияет и на защиту автоматически.
 */
@Mixin(value = net.mcreator.invincibleinc.procedures.XpGiveProcedure.class, remap = false)
public class XpGiveProcedureMixin {

    /**
     * Референсная капа — средняя стартовая (мод даёт rand(15..30) ≈ 22.5).
     * В combat mode прибавка домножается на cap/REFERENCE_CAP:
     * на стартовом уровне это ×1, дальше растёт вместе с капой → скорость постоянна.
     */
    private static final double REFERENCE_CAP = 22.5;

    @Inject(
            method = "execute(Lnet/neoforged/bus/api/Event;" +
                    "Lnet/minecraft/world/entity/Entity;" +
                    "Lnet/minecraft/world/entity/Entity;)V",
            at = @At("HEAD"),
            cancellable = true,
            remap = false
    )
    private static void invfix_replaceXpGive(
            Event event, Entity entity, Entity sourceentity, CallbackInfo ci) {
        ci.cancel();
        if (entity == null || sourceentity == null) return;
        if (!(sourceentity instanceof Player || sourceentity instanceof ServerPlayer)) return;

        // Заражённые Scourge Virus не получают XP — прокачка заморожена.
        if (sourceentity instanceof Player srcPlayer && ScourgeVirusState.isInfected(srcPlayer)) return;

        try {
            double xpgive = entity
                    .getData(InvincibleIncModVariables.PLAYER_VARIABLES)
                    .mobXPdrop;
            if (xpgive <= 0) return;

            InvincibleIncModVariables.PlayerVariables a =
                    sourceentity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);

            boolean inCombat = isInCombat(sourceentity);
            double mult = inCombat ? combatMultiplier(a.Race) : outsideMultiplier(a.Race);

            if (inCombat) {
                // Динамическая компенсация: прибавка ∝ текущей капе стата
                a.xp         += xpgive * 0.40 * mult * (a.xpCap         / REFERENCE_CAP);
                a.strengthXP += xpgive * 0.20 * mult * (a.strengthXPcap / REFERENCE_CAP);
                a.defenseXP  += xpgive * 0.20 * mult * (a.defenseXPcap  / REFERENCE_CAP);
                a.healthXP   += xpgive * 0.15 * mult * (a.healthXPcap   / REFERENCE_CAP);
                a.speedXP    += xpgive * 0.15 * mult * (a.speedXPcap    / REFERENCE_CAP);
            } else {
                // Плоская ванильная прокачка — замедляется с ростом капы
                a.xp         += xpgive * 0.40 * mult;
                a.strengthXP += xpgive * 0.20 * mult;
                a.defenseXP  += xpgive * 0.20 * mult;
                a.healthXP   += xpgive * 0.15 * mult;
                a.speedXP    += xpgive * 0.15 * mult;
            }
            a.markSyncDirty();
        } catch (Exception ignored) {}
    }

    private static boolean isInCombat(Entity e) {
        if (!(e instanceof LivingEntity le)) return false;
        return le.hasEffect(InvincibleIncModMobEffects.COMBAT_MODE);
    }

    /** Множители В combat mode (динамические). */
    private static double combatMultiplier(String race) {
        if (race == null) return 1.0;
        return switch (race) {
            case "§1§lAlien(Metroman)"          -> 310.0;
            case "§4§lViltrumite"         -> 8.0;
            case "§4§lBeast"              -> 5.0;
            case "§f§lHuman-Viltrumite"   -> 1.3;
            case "§1§lThraxan-Viltrumite" -> 1.1;
            case "§6§lUnopan"             -> 3.0;
            case "§f§lHuman", "§lHuman"   -> 0.0;
            case HumanLikeRaces.BORN_FOR_V,
                 HumanLikeRaces.PREDISPOSITION -> 0.0;
            default                       -> 0.0;
        };
    }

    /** Множители ВНЕ combat mode (плоские). Все 1.0, человек 1/9. */
    private static double outsideMultiplier(String race) {
        if (race == null) return 1.0;
        return switch (race) {
            case "§f§lHuman", "§lHuman" -> 0.0;
            case HumanLikeRaces.BORN_FOR_V,
                 HumanLikeRaces.PREDISPOSITION -> 0.0;
            default                     -> 0.0;
        };
    }
}