package com.invfix.mixin;

import com.invfix.physics.RacialPunch;
import dev.ryanhcode.sable.api.physics.PhysicsPipeline;
import dev.ryanhcode.sable.api.physics.PhysicsPipelineBody;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import foundry.veil.api.network.handler.PacketContext;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3dc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * ЛКМ-удар по физической постройке (sable punch-пакет).
 *
 * Перехватываем ЛЮБОЙ applyImpulse внутри handle (без ordinal — чтобы наверняка
 * поймать удар по постройке независимо от того, какой по счёту это вызов в
 * байткоде; в обычном случае «с земли» исполняется только удар по постройке).
 *
 * Для не-людской расы в бою задаём постройке скорость в ПОЛОВИНУ силы (LMB_MULT,
 * кап 600 м/с) по направлению взгляда. Если получить физ-хэндл не удалось —
 * откатываемся на импульсный applyLocal (тот же путь, что у рабочего Heavy).
 * Иначе — оригинальное поведение sable.
 */
@Mixin(
        targets = "dev.ryanhcode.sable.network.packets.tcp.ServerboundPunchSubLevelPacket",
        remap = false
)
public abstract class RacialPunchPacketMixin {

    @Redirect(
            method = "handle",
            at = @At(
                    value = "INVOKE",
                    target = "Ldev/ryanhcode/sable/api/physics/PhysicsPipeline;applyImpulse("
                            + "Ldev/ryanhcode/sable/api/physics/PhysicsPipelineBody;"
                            + "Lorg/joml/Vector3dc;Lorg/joml/Vector3dc;)V"
            ),
            remap = false
    )
    private void invfix_racialLmbPunch(PhysicsPipeline pipeline,
                                       PhysicsPipelineBody body,
                                       Vector3dc localPos,
                                       Vector3dc localForce,
                                       PacketContext context) {
        Player player = context != null ? context.player() : null;
        if (!(body instanceof ServerSubLevel target) || player == null) {
            pipeline.applyImpulse(body, localPos, localForce);
            return;
        }
        InvincibleIncModVariables.PlayerVariables vars =
                player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        if (!RacialPunch.qualifies(vars)) {
            pipeline.applyImpulse(body, localPos, localForce);
            return;
        }

        double delta = RacialPunch.targetDelta(vars, RacialPunch.LMB_MULT);
        Vec3 look = player.getLookAngle();
        // 1) скорость по взгляду (кап 600); 2) фолбэк — импульс по локальному направлению удара
        if (!RacialPunch.pushWorld(target, look.x, look.y, look.z, delta)) {
            RacialPunch.applyLocal(target, localPos, localForce, delta);
        }
    }
}