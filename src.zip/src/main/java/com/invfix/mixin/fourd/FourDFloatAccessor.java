package com.invfix.mixin.fourd;

import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** 4D Offset: счётчик «парит над землёй» (кик за полёт) — сбрасывается, пока игрок в 4D. */
@Mixin(ServerGamePacketListenerImpl.class)
public interface FourDFloatAccessor {

    @Accessor("aboveGroundTickCount")
    void invfix$setAboveGroundTickCount(int ticks);
}
