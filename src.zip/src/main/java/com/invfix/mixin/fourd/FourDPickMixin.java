package com.invfix.mixin.fourd;

import com.invfix.fourd.client.FourDClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 4D Offset: прицел сквозь стены — существа и контейнеры, блоки не выбираются (FourDClient#pick). */
@Mixin(GameRenderer.class)
public abstract class FourDPickMixin {

    @Shadow @Final Minecraft minecraft;

    @Inject(method = "pick(F)V", at = @At("TAIL"))
    private void invfix$fourDPick(float partialTicks, CallbackInfo ci) {
        FourDClient.pick(minecraft, partialTicks);
    }
}
