package com.invfix.mixin.fourd;

import com.invfix.fourd.client.FourDClient;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 4D Offset: свой шаг в 4D — сквозь стены, по верхам блоков, Пробел / Shift — вверх / вниз (FourDClient#move). */
@Mixin(LocalPlayer.class)
public abstract class FourDMoveMixin {

    @Inject(method = "move", at = @At("HEAD"), cancellable = true)
    private void invfix$fourDMove(MoverType type, Vec3 pos, CallbackInfo ci) {
        if (FourDClient.move((LocalPlayer) (Object) this, type, pos)) ci.cancel();
    }
}
