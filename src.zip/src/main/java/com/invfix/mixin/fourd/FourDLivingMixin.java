package com.invfix.mixin.fourd;

import com.invfix.fourd.FourD;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 4D Offset: смещённого не задеть — прицел (свой и чужой) его не берёт, снаряды пролетают насквозь
 * (Entity#canBeHitByProjectile идёт через isPickable), существа не толкают и не толкаются.
 */
@Mixin(LivingEntity.class)
public abstract class FourDLivingMixin {

    @Inject(method = "isPickable", at = @At("HEAD"), cancellable = true)
    private void invfix$fourDPickable(CallbackInfoReturnable<Boolean> cir) {
        if (FourD.in((LivingEntity) (Object) this)) cir.setReturnValue(false);
    }

    @Inject(method = "isPushable", at = @At("HEAD"), cancellable = true)
    private void invfix$fourDPushable(CallbackInfoReturnable<Boolean> cir) {
        if (FourD.in((LivingEntity) (Object) this)) cir.setReturnValue(false);
    }
}
