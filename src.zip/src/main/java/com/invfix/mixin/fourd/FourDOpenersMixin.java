package com.invfix.mixin.fourd;

import com.invfix.fourd.FourD;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.ContainerOpenersCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.ArrayList;
import java.util.List;

/** 4D Offset: при перепроверке открывших контейнер смещённые в 4D не считаются — крышка не поднимается. */
@Mixin(ContainerOpenersCounter.class)
public abstract class FourDOpenersMixin {

    @ModifyReturnValue(method = "getPlayersWithContainerOpen", at = @At("RETURN"))
    private List<Player> invfix$fourDNotOpeners(List<Player> players) {
        if (players.isEmpty()) return players;
        List<Player> out = new ArrayList<>(players.size());
        for (Player p : players) if (!FourD.in(p)) out.add(p);
        return out;
    }
}
