package com.invfix.mixin.fourd;

import com.invfix.fourd.FourD;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * 4D Offset: контейнер, открытый из 4D, крышку не поднимает (и не закрывает) — как у наблюдателя:
 * startOpen / stopOpen сундука, бочки и шалкера считают открывшего, только если он не наблюдатель.
 */
@Mixin({ChestBlockEntity.class, BarrelBlockEntity.class, ShulkerBoxBlockEntity.class})
public abstract class FourDLidMixin {

    @ModifyExpressionValue(method = {"startOpen", "stopOpen"},
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;isSpectator()Z"))
    private boolean invfix$fourDNoLid(boolean spectator, Player player) {
        return spectator || FourD.in(player);
    }
}
