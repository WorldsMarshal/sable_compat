package com.invfix.mixin.computercraft;

import com.invfix.dbw.CableHub;
import com.invfix.dbw.ICableLinked;
import dan200.computercraft.api.network.wired.WiredNode;
import dan200.computercraft.core.computer.ComputerSide;
import dan200.computercraft.shared.computer.blocks.AbstractComputerBlockEntity;
import javax.annotation.Nullable;
import net.minecraft.core.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Обычный компьютер ComputerCraft тоже говорит по кабелю DriveByWire.
 *
 * Наш саблевел-компьютер умел это с рождения, потому что у него узел проводной
 * сети встроен, а у ванильного компьютера присоединять было нечего. Теперь есть:
 * узел, модем и вся логика живут в общем {@link CableHub}, а миксин только
 * заводит его и вовремя дёргает.
 *
 * Модем появляется на той грани, к которой игрок подвёл провод, — ровно как
 * проводной модем, который вешается на любую сторону. Грань известна оттуда, что
 * приёмник связи у DBW её хранит; если компьютер оказался источником, начало
 * провода висит на блоке целиком и грани нет, тогда берётся задняя.
 *
 * Занимается грань не всегда, а только пока провод действительно подведён. Иначе
 * мы бы молча отобрали сторону у каждого компьютера в мире, включая те, где на
 * ней уже что-то висит. Провода нет - компьютер о кабеле не знает и ведёт себя
 * ровно как раньше.
 *
 * Это относится и к продвинутому, и к обычному, и к командному: все они наследуют
 * {@code AbstractComputerBlockEntity}. Черепахи и карманные - нет, у них своя
 * ветка, и провод к ним всё равно не протянешь.
 */
@Mixin(value = AbstractComputerBlockEntity.class, remap = false)
public abstract class ComputerCableMixin implements ICableLinked {

    @Unique
    private @Nullable CableHub invfix$cable;

    @Shadow
    protected abstract ComputerSide remapToLocalSide(Direction globalSide);

    @Unique
    private CableHub invfix$hub() {
        if (invfix$cable == null) {
            invfix$cable = new CableHub((AbstractComputerBlockEntity) (Object) this,
                    this::remapToLocalSide);
        }
        return invfix$cable;
    }

    @Override
    public @Nullable WiredNode invfix$cableNode() {
        return invfix$hub().node();
    }

    @Inject(method = "serverTick", at = @At("TAIL"), require = 0)
    private void invfix$tickCable(CallbackInfo ci) {
        AbstractComputerBlockEntity self = (AbstractComputerBlockEntity) (Object) this;
        if (self.getLevel() == null || self.getLevel().isClientSide) return;
        invfix$hub().tick(self.getServerComputer());
    }

    /**
     * Занятая кабелем грань принадлежит кабелю.
     *
     * Без этого базовый класс переписывал бы модем при каждом изменении соседа.
     * Занята ровно та грань, к которой игрок подвёл провод, и только пока провод
     * там есть - в остальное время компьютер отдаёт все шесть сторон обратно.
     */
    @Inject(method = "isPeripheralBlockedOnSide", at = @At("HEAD"), cancellable = true, require = 0)
    private void invfix$reserveCableSide(ComputerSide side, CallbackInfoReturnable<Boolean> cir) {
        if (invfix$cable != null && side == invfix$cable.side()) cir.setReturnValue(true);
    }

    @Inject(method = "setRemoved", at = @At("TAIL"), require = 0)
    private void invfix$removeCable(CallbackInfo ci) {
        if (invfix$cable != null) {
            invfix$cable.remove();
            invfix$cable = null;
        }
    }
}
