package com.invfix.mixin;

import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.DirectionalPayloadHandler;
import net.neoforged.neoforge.network.handling.IPayloadHandler;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.benniao.theboysmod.network.BloodBurstPacket;
import net.benniao.theboysmod.network.DetachPartPacket;
import net.benniao.theboysmod.network.DossierUnlockSyncPacket;
import net.benniao.theboysmod.network.EntityAnimationPlaySyncPacket;
import net.benniao.theboysmod.network.FireTimerSyncPacket;
import net.benniao.theboysmod.network.FleshRegenSyncPacket;
import net.benniao.theboysmod.network.FleshStrengthSyncPacket;
import net.benniao.theboysmod.network.FlightPosePacket;
import net.benniao.theboysmod.network.FlightPoseSyncPacket;
import net.benniao.theboysmod.network.FlightTogglePacket;
import net.benniao.theboysmod.network.GrabPacket;
import net.benniao.theboysmod.network.GrabSyncPacket;
import net.benniao.theboysmod.network.InjectVPacket;
import net.benniao.theboysmod.network.LaserEyeHitPosSyncPacket;
import net.benniao.theboysmod.network.NpcSupportRequestPacket;
import net.benniao.theboysmod.network.NpcSupportSyncPacket;
import net.benniao.theboysmod.network.OpenSupeDialoguePacket;
import net.benniao.theboysmod.network.PhoneBatterySyncPacket;
import net.benniao.theboysmod.network.PhoneEvidenceCapturePacket;
import net.benniao.theboysmod.network.PhoneEvidenceReportPacket;
import net.benniao.theboysmod.network.PhoneEvidenceReportResultPacket;
import net.benniao.theboysmod.network.PhoneEvidenceSyncPacket;
import net.benniao.theboysmod.network.PhoneNewsSyncPacket;
import net.benniao.theboysmod.network.PhonePowerDrainPacket;
import net.benniao.theboysmod.network.PhoneShopActionPacket;
import net.benniao.theboysmod.network.PhoneShopSyncPacket;
import net.benniao.theboysmod.network.PhoneSmsActionPacket;
import net.benniao.theboysmod.network.PhoneSmsImageDownloadPacket;
import net.benniao.theboysmod.network.PhoneSmsSyncPacket;
import net.benniao.theboysmod.network.PlayerAnimationPlaySyncPacket;
import net.benniao.theboysmod.network.PlayerAnimationStopSyncPacket;
import net.benniao.theboysmod.network.ScaleSetPacket;
import net.benniao.theboysmod.network.SkillActiveSyncPacket;
import net.benniao.theboysmod.network.SkillDamageAdjustPacket;
import net.benniao.theboysmod.network.SkillSetActivePacket;
import net.benniao.theboysmod.network.SkillSyncPacket;
import net.benniao.theboysmod.network.SkillTogglePacket;
import net.benniao.theboysmod.network.SpeedAdjustPacket;
import net.benniao.theboysmod.network.SupeDialogueChoicePacket;
import net.benniao.theboysmod.network.SupeDialogueStatePacket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/*
 * DEDICATED SERVER регистрация каналов The Boys.
 *  - serverbound: настоящие хендлеры (классы server-safe).
 *  - laser_eye: bidirectional (no-op клиентская половина + настоящий handleServer), чтобы форма
 *    канала совпала с клиентом (тот регистрирует bidirectional).
 *  - clientbound: регистрируем с no-op хендлером, чтобы сервер МОГ их отправлять
 *    (иначе серверные синки The Boys на логине кидают UnsupportedOperationException и кикают игрока).
 *    Каждая такая регистрация в своём try/catch: если конкретный класс пакета не загрузится под
 *    RuntimeDistCleaner — он пропускается, а старт сервера не падает (клиент терпит отсутствие
 *    такого канала за счёт .optional() в TheBoysNetworkClientOptionalMixin).
 */
@Mixin(value = net.benniao.theboysmod.network.ModNetworking.class, remap = false)
public abstract class TheBoysNetworkServerFixMixin {

    private static final Logger INVFIX_LOG = LoggerFactory.getLogger("invfix/theboys-net");
    @SuppressWarnings("rawtypes")
    private static final IPayloadHandler INVFIX_NOOP = (payload, context) -> {};

    @Inject(method = "register", at = @At("HEAD"), cancellable = true, remap = false)
    private static void invfix_serverOnlyRegister(RegisterPayloadHandlersEvent event, CallbackInfo ci) {
        PayloadRegistrar registrar = event.registrar("theboysmod");

        // --- serverbound (server-safe handlers) ---
        registrar.playToServer(DetachPartPacket.TYPE, DetachPartPacket.STREAM_CODEC, DetachPartPacket::handle);
        registrar.playToServer(BloodBurstPacket.TYPE, BloodBurstPacket.STREAM_CODEC, BloodBurstPacket::handle);
        registrar.playToServer(SkillTogglePacket.TYPE, SkillTogglePacket.STREAM_CODEC, SkillTogglePacket::handle);
        registrar.playToServer(SkillSetActivePacket.TYPE, SkillSetActivePacket.STREAM_CODEC, SkillSetActivePacket::handle);
        registrar.playToServer(FlightTogglePacket.TYPE, FlightTogglePacket.STREAM_CODEC, FlightTogglePacket::handle);
        registrar.playToServer(FlightPosePacket.TYPE, FlightPosePacket.STREAM_CODEC, FlightPosePacket::handle);
        registrar.playToServer(SkillDamageAdjustPacket.TYPE, SkillDamageAdjustPacket.STREAM_CODEC, SkillDamageAdjustPacket::handle);
        registrar.playToServer(GrabPacket.TYPE, GrabPacket.STREAM_CODEC, GrabPacket::handle);
        registrar.playToServer(SpeedAdjustPacket.TYPE, SpeedAdjustPacket.STREAM_CODEC, SpeedAdjustPacket::handle);
        registrar.playToServer(ScaleSetPacket.TYPE, ScaleSetPacket.STREAM_CODEC, ScaleSetPacket::handle);
        registrar.playToServer(InjectVPacket.TYPE, InjectVPacket.STREAM_CODEC, InjectVPacket::handle);
        registrar.playToServer(PhoneSmsActionPacket.TYPE, PhoneSmsActionPacket.STREAM_CODEC, PhoneSmsActionPacket::handle);
        registrar.playToServer(NpcSupportRequestPacket.TYPE, NpcSupportRequestPacket.STREAM_CODEC, NpcSupportRequestPacket::handle);
        registrar.playToServer(SupeDialogueStatePacket.TYPE, SupeDialogueStatePacket.STREAM_CODEC, SupeDialogueStatePacket::handle);
        registrar.playToServer(SupeDialogueChoicePacket.TYPE, SupeDialogueChoicePacket.STREAM_CODEC, SupeDialogueChoicePacket::handle);
        registrar.playToServer(PhoneEvidenceCapturePacket.TYPE, PhoneEvidenceCapturePacket.STREAM_CODEC, PhoneEvidenceCapturePacket::handle);
        registrar.playToServer(PhoneEvidenceReportPacket.TYPE, PhoneEvidenceReportPacket.STREAM_CODEC, PhoneEvidenceReportPacket::handle);
        registrar.playToServer(PhonePowerDrainPacket.TYPE, PhonePowerDrainPacket.STREAM_CODEC, PhonePowerDrainPacket::handle);
        registrar.playToServer(PhoneShopActionPacket.TYPE, PhoneShopActionPacket.STREAM_CODEC, PhoneShopActionPacket::handle);

        // --- laser_eye: bidirectional, no-op client half ---
        registrar.playBidirectional(LaserEyeHitPosSyncPacket.TYPE, LaserEyeHitPosSyncPacket.STREAM_CODEC, new DirectionalPayloadHandler<LaserEyeHitPosSyncPacket>((payload, context) -> {}, LaserEyeHitPosSyncPacket::handleServer));

        // --- clientbound: no-op handler, each isolated so a bad class can't abort startup ---
        @SuppressWarnings("unchecked")
        PayloadRegistrar reg = registrar;
        try { reg.playToClient(FleshRegenSyncPacket.TYPE, FleshRegenSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:flesh_regen_sync on server: {}", t.toString()); }
        try { reg.playToClient(PlayerAnimationPlaySyncPacket.TYPE, PlayerAnimationPlaySyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:player_animation_play_sync on server: {}", t.toString()); }
        try { reg.playToClient(EntityAnimationPlaySyncPacket.TYPE, EntityAnimationPlaySyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:entity_animation_play_sync on server: {}", t.toString()); }
        try { reg.playToClient(PlayerAnimationStopSyncPacket.TYPE, PlayerAnimationStopSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:player_animation_stop_sync on server: {}", t.toString()); }
        try { reg.playToClient(SkillSyncPacket.TYPE, SkillSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:skill_sync on server: {}", t.toString()); }
        try { reg.playToClient(SkillActiveSyncPacket.TYPE, SkillActiveSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:skill_active_sync on server: {}", t.toString()); }
        try { reg.playToClient(FlightPoseSyncPacket.TYPE, FlightPoseSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:flight_pose_sync on server: {}", t.toString()); }
        try { reg.playToClient(FleshStrengthSyncPacket.TYPE, FleshStrengthSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:flesh_strength_sync on server: {}", t.toString()); }
        try { reg.playToClient(GrabSyncPacket.TYPE, GrabSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:grab_sync on server: {}", t.toString()); }
        try { reg.playToClient(FireTimerSyncPacket.TYPE, FireTimerSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:fire_timer_sync on server: {}", t.toString()); }
        try { reg.playToClient(PhoneSmsSyncPacket.TYPE, PhoneSmsSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:phone_sms_sync on server: {}", t.toString()); }
        try { reg.playToClient(PhoneSmsImageDownloadPacket.TYPE, PhoneSmsImageDownloadPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:phone_sms_image_download on server: {}", t.toString()); }
        try { reg.playToClient(OpenSupeDialoguePacket.TYPE, OpenSupeDialoguePacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:open_supe_dialogue on server: {}", t.toString()); }
        try { reg.playToClient(NpcSupportSyncPacket.TYPE, NpcSupportSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:npc_support_sync on server: {}", t.toString()); }
        try { reg.playToClient(PhoneEvidenceSyncPacket.TYPE, PhoneEvidenceSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:phone_evidence_sync on server: {}", t.toString()); }
        try { reg.playToClient(PhoneBatterySyncPacket.TYPE, PhoneBatterySyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:phone_battery_sync on server: {}", t.toString()); }
        try { reg.playToClient(PhoneEvidenceReportResultPacket.TYPE, PhoneEvidenceReportResultPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:phone_evidence_report_result on server: {}", t.toString()); }
        try { reg.playToClient(PhoneNewsSyncPacket.TYPE, PhoneNewsSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:phone_news_sync on server: {}", t.toString()); }
        try { reg.playToClient(PhoneShopSyncPacket.TYPE, PhoneShopSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:phone_shop_sync on server: {}", t.toString()); }
        try { reg.playToClient(DossierUnlockSyncPacket.TYPE, DossierUnlockSyncPacket.STREAM_CODEC, INVFIX_NOOP); } catch (Throwable t) { INVFIX_LOG.warn("skip clientbound theboysmod:dossier_unlock_sync on server: {}", t.toString()); }

        ci.cancel();
    }
}