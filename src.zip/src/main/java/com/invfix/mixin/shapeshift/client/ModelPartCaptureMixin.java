package com.invfix.mixin.shapeshift.client;

import com.invfix.shapeshift.client.MorphCapture;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/** Shapeshifter: снимок формы модели для перетекания ({@link MorphCapture}). */
@Mixin(ModelPart.class)
public abstract class ModelPartCaptureMixin {

    @Shadow @Final private List<ModelPart.Cube> cubes;

    @Inject(method = "compile", at = @At("HEAD"), cancellable = true)
    private void invfix$captureForMorph(PoseStack.Pose pose, VertexConsumer buffer, int light, int overlay, int color,
                                        CallbackInfo ci) {
        if (!MorphCapture.recording()) return;
        MorphCapture.record(pose, cubes);
        ci.cancel();
    }
}
