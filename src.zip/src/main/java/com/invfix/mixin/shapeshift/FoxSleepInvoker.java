package com.invfix.mixin.shapeshift;

import net.minecraft.world.entity.animal.Fox;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Shapeshifter: поза сна лисы-морфа (Fox#setSleeping закрыт). */
@Mixin(Fox.class)
public interface FoxSleepInvoker {

    @Invoker("setSleeping")
    void invfix$setSleeping(boolean sleeping);
}
