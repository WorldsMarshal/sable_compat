package com.invfix.mixin.shapeshift;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Шаги куклы морфа (защищённый Entity#playStepSound). */
@Mixin(Entity.class)
public interface EntityStepSoundInvoker {

    @Invoker("playStepSound")
    void invfix$playStepSound(BlockPos pos, BlockState state);
}
