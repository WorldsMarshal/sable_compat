package com.invfix.mixin.shapeshift;

import com.invfix.shapeshift.MorphState;
import com.invfix.shapeshift.ShapeshiftSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Shapeshifter: игрок в морфе — с хитбоксом и высотой глаз моба (getDefaultDimensions —
 * через него идут и refreshDimensions, и проверки «влезет ли в позу»), его шагами,
 * голосом при ударе и смерти.
 */
@Mixin(Player.class)
public abstract class ShapeshiftPlayerMixin {

    @Inject(method = "getDefaultDimensions", at = @At("RETURN"), cancellable = true)
    private void invfix$morphDimensions(Pose pose, CallbackInfoReturnable<EntityDimensions> cir) {
        Player self = (Player) (Object) this;
        if (self.level() == null) return;
        MorphState state = MorphState.get(self);
        if (state == null || !state.active()) return;
        EntityDimensions dims = state.dimensions(self, pose, cir.getReturnValue());
        if (dims != null) cir.setReturnValue(dims);
    }

    @Inject(method = "getHurtSound", at = @At("HEAD"), cancellable = true)
    private void invfix$morphHurtSound(DamageSource source, CallbackInfoReturnable<SoundEvent> cir) {
        ShapeshiftSounds.Result<SoundEvent> r = ShapeshiftSounds.hurt((Player) (Object) this, source);
        if (r != null) cir.setReturnValue(r.value());
    }

    @Inject(method = "getDeathSound", at = @At("HEAD"), cancellable = true)
    private void invfix$morphDeathSound(CallbackInfoReturnable<SoundEvent> cir) {
        ShapeshiftSounds.Result<SoundEvent> r = ShapeshiftSounds.death((Player) (Object) this);
        if (r != null) cir.setReturnValue(r.value());
    }

    @Inject(method = "playStepSound", at = @At("HEAD"), cancellable = true)
    private void invfix$morphStepSound(BlockPos pos, BlockState blockState, CallbackInfo ci) {
        if (ShapeshiftSounds.step((Player) (Object) this, pos, blockState)) ci.cancel();
    }
}
