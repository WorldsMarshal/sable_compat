package com.invfix.mixin.shapeshift.client;

import com.invfix.shapeshift.client.ShapeshiftClient;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.HumanoidArm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Shapeshifter: от первого лица в морфе рук нет — видны только предметы. Гасятся
 * только сами руки (пустая рука и руки с картой), предметы рисуются как обычно.
 */
@Mixin(ItemInHandRenderer.class)
public abstract class ItemInHandArmsMixin {

    @Inject(method = "renderPlayerArm", at = @At("HEAD"), cancellable = true)
    private void invfix$noArmInMorph(PoseStack poseStack, MultiBufferSource buffer, int light, float equipped,
                                     float swing, HumanoidArm side, CallbackInfo ci) {
        if (ShapeshiftClient.hideOwnArms()) ci.cancel();
    }

    @Inject(method = "renderMapHand", at = @At("HEAD"), cancellable = true)
    private void invfix$noMapHandInMorph(PoseStack poseStack, MultiBufferSource buffer, int light, HumanoidArm side,
                                         CallbackInfo ci) {
        if (ShapeshiftClient.hideOwnArms()) ci.cancel();
    }
}
