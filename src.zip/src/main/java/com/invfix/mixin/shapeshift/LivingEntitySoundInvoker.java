package com.invfix.mixin.shapeshift;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Звуки куклы морфа (защищённые методы LivingEntity). */
@Mixin(LivingEntity.class)
public interface LivingEntitySoundInvoker {

    @Invoker("getHurtSound")
    SoundEvent invfix$hurtSound(DamageSource source);

    @Invoker("getDeathSound")
    SoundEvent invfix$deathSound();

    @Invoker("getSoundVolume")
    float invfix$soundVolume();
}
