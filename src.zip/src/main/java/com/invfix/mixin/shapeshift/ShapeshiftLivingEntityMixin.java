package com.invfix.mixin.shapeshift;

import com.invfix.shapeshift.ShapeshiftSounds;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Shapeshifter: громкость и высота голоса игрока в морфе — как у моба. */
@Mixin(LivingEntity.class)
public abstract class ShapeshiftLivingEntityMixin {

    @Inject(method = "getSoundVolume", at = @At("HEAD"), cancellable = true)
    private void invfix$morphVolume(CallbackInfoReturnable<Float> cir) {
        if (!((Object) this instanceof Player player)) return;
        ShapeshiftSounds.Result<Float> r = ShapeshiftSounds.volume(player);
        if (r != null) cir.setReturnValue(r.value());
    }

    @Inject(method = "getVoicePitch", at = @At("HEAD"), cancellable = true)
    private void invfix$morphPitch(CallbackInfoReturnable<Float> cir) {
        if (!((Object) this instanceof Player player)) return;
        ShapeshiftSounds.Result<Float> r = ShapeshiftSounds.pitch(player);
        if (r != null) cir.setReturnValue(r.value());
    }
}
