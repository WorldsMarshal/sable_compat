package com.invfix.mixin.shapeshift;

import net.minecraft.world.entity.WalkAnimationState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Shapeshifter: кукла морфа шагает в такт игроку (копия состояния анимации ходьбы). */
@Mixin(WalkAnimationState.class)
public interface WalkAnimationStateAccessor {

    @Accessor("speedOld") float invfix$speedOld();
    @Accessor("speedOld") void invfix$setSpeedOld(float v);
    @Accessor("speed") float invfix$speed();
    @Accessor("speed") void invfix$setSpeed(float v);
    @Accessor("position") float invfix$position();
    @Accessor("position") void invfix$setPosition(float v);
}
