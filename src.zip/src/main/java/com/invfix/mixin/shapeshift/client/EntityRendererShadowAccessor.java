package com.invfix.mixin.shapeshift.client;

import net.minecraft.client.renderer.entity.EntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Shapeshifter: тень игрока в морфе — размером с тень моба. */
@Mixin(EntityRenderer.class)
public interface EntityRendererShadowAccessor {

    @Accessor("shadowRadius") float invfix$shadowRadius();
    @Accessor("shadowRadius") void invfix$setShadowRadius(float v);
}
