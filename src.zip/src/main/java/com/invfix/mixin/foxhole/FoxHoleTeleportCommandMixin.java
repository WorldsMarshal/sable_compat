package com.invfix.mixin.foxhole;

import com.invfix.foxhole.FoxHoleAccess;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.server.commands.TeleportCommand;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.RelativeMovement;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Set;

/**
 * Fox Hole: телепорт командой (/tp, /teleport, /execute in … run tp) пускает в Fox Hole и
 * выпускает из него — эти команды и так только для OP.
 */
@Mixin(TeleportCommand.class)
public abstract class FoxHoleTeleportCommandMixin {

    @WrapOperation(method = "performTeleport", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/entity/Entity;teleportTo(Lnet/minecraft/server/level/ServerLevel;DDDLjava/util/Set;FF)Z"))
    private static boolean invfix$commandAccess(Entity entity, ServerLevel level, double x, double y, double z,
                                                Set<RelativeMovement> relative, float yRot, float xRot,
                                                Operation<Boolean> original) {
        return FoxHoleAccess.command(() -> original.call(entity, level, x, y, z, relative, yRot, xRot));
    }
}
