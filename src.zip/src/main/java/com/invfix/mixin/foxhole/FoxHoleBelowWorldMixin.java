package com.invfix.mixin.foxhole;

import com.invfix.foxhole.FoxHoleVoid;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Fox Hole: упавший в пустоту ниже Y -164 возвращается на ближайший целый блок (FoxHoleVoid). */
@Mixin(Entity.class)
public abstract class FoxHoleBelowWorldMixin {

    @Inject(method = "checkBelowWorld", at = @At("HEAD"), cancellable = true)
    private void invfix$foxHoleVoid(CallbackInfo ci) {
        if (FoxHoleVoid.rescue((Entity) (Object) this)) ci.cancel();
    }
}
