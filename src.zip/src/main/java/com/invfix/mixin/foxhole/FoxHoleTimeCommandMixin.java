package com.invfix.mixin.foxhole;

import com.invfix.foxhole.FoxHole;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.server.commands.TimeCommand;
import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Fox Hole: время там только своё — /time set и /time add (они проходят по всем мирам)
 * его не трогают; меняет его хозяйка из меню.
 */
@Mixin(TimeCommand.class)
public abstract class FoxHoleTimeCommandMixin {

    @WrapOperation(method = {"setTime", "addTime"}, at = @At(value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerLevel;setDayTime(J)V"))
    private static void invfix$skipFoxHole(ServerLevel level, long time, Operation<Void> original) {
        if (!FoxHole.is(level)) original.call(level, time);
    }
}
