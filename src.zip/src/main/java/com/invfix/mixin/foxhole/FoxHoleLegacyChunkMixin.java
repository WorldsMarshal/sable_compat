package com.invfix.mixin.foxhole;

import com.invfix.foxhole.FoxHole;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.storage.ChunkStorage;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Fox Hole: остров теперь лежит в моде уже в формате 1.21.1 и конвертации не требует.
 * Этот миксин — для миров, где остров успела поставить прошлая сборка: там чанки карты
 * 2012 года (до 1.13). DataFixer помечает такие чанки hasLegacyStructureData, и
 * ChunkStorage#upgradeChunkTag берёт для них LegacyStructureDataHandler — а тот знает
 * только Overworld, Ад и Энд и для любого другого измерения бросает исключение (сервер
 * падает на первом таком чанке). Старых структур у Fox Hole нет — шаг пропускается.
 */
@Mixin(ChunkStorage.class)
public abstract class FoxHoleLegacyChunkMixin {

    @WrapOperation(method = "upgradeChunkTag", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/nbt/CompoundTag;getBoolean(Ljava/lang/String;)Z"))
    private boolean invfix$noLegacyStructures(CompoundTag tag, String key, Operation<Boolean> original,
                                              @Local(argsOnly = true) ResourceKey<Level> levelKey) {
        if (FoxHole.is(levelKey)) return false;
        return original.call(tag, key);
    }
}
