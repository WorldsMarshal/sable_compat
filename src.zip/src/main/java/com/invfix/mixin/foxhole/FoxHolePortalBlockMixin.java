package com.invfix.mixin.foxhole;

import com.invfix.foxhole.FoxHole;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.EndGatewayBlock;
import net.minecraft.world.level.block.EndPortalBlock;
import net.minecraft.world.level.block.NetherPortalBlock;
import net.minecraft.world.level.block.Portal;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Fox Hole: блоки порталов в Ад и в Энд внутри измерения не переносят (и не дают
 * эффекта входа в портал). Зажечь рамку Ада там нельзя (FoxHoleGuard), а это — для
 * блоков, поставленных командой.
 */
@Mixin(Entity.class)
public abstract class FoxHolePortalBlockMixin {

    @Inject(method = "setAsInsidePortal", at = @At("HEAD"), cancellable = true)
    private void invfix$noPortalsInFoxHole(Portal portal, BlockPos pos, CallbackInfo ci) {
        if ((portal instanceof NetherPortalBlock || portal instanceof EndPortalBlock || portal instanceof EndGatewayBlock)
                && FoxHole.is(((Entity) (Object) this).level())) {
            ci.cancel();
        }
    }
}
