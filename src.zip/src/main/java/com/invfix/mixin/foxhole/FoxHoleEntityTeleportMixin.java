package com.invfix.mixin.foxhole;

import com.invfix.foxhole.FoxHole;
import com.invfix.foxhole.FoxHoleGuard;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.RelativeMovement;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Set;

/**
 * Fox Hole: межмировой Entity#teleportTo не-игрока (команды, моды) создаёт копию сущности
 * в новом мире, минуя changeDimension и событие NeoForge. Вход в Fox Hole — по тем же
 * правилам, что и через событие (FoxHoleGuard#mayEnter). Игроков не касается:
 * ServerPlayer переопределяет этот метод и идёт через changeDimension.
 */
@Mixin(Entity.class)
public abstract class FoxHoleEntityTeleportMixin {

    @Inject(method = "teleportTo(Lnet/minecraft/server/level/ServerLevel;DDDLjava/util/Set;FF)Z",
            at = @At("HEAD"), cancellable = true)
    private void invfix$foxHoleTeleport(ServerLevel level, double x, double y, double z, Set<RelativeMovement> relative,
                                        float yRot, float xRot, CallbackInfoReturnable<Boolean> cir) {
        Entity self = (Entity) (Object) this;
        if (level != self.level() && FoxHole.is(level) && !FoxHole.is(self.level()) && !FoxHoleGuard.mayEnter(self)) {
            cir.setReturnValue(false);
        }
    }
}
