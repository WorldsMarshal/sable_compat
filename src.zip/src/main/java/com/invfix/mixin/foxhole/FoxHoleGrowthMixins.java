package com.invfix.mixin.foxhole;

import com.invfix.foxhole.FoxHoleGrowth;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.lighting.LevelLightEngine;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Рост растений в Fox Hole — см. FoxHoleGrowth. */
public final class FoxHoleGrowthMixins {

    private FoxHoleGrowthMixins() {}

    /** Случайный тик и «может ли стоять» у растений Fox Hole. */
    @Mixin(BlockBehaviour.BlockStateBase.class)
    public abstract static class BlockStateHooks {

        @Inject(method = "randomTick", at = @At("HEAD"), cancellable = true)
        private void invfix$foxHoleGrowthStart(ServerLevel level, BlockPos pos, RandomSource random, CallbackInfo ci) {
            if (FoxHoleGrowth.beforeRandomTick((BlockState) (Object) this, level, random)) ci.cancel();
        }

        @Inject(method = "randomTick", at = @At("RETURN"))
        private void invfix$foxHoleGrowthEnd(ServerLevel level, BlockPos pos, RandomSource random, CallbackInfo ci) {
            FoxHoleGrowth.afterRandomTick(level, pos, random);
        }

        @Inject(method = "canSurvive", at = @At("HEAD"))
        private void invfix$foxHoleSurviveStart(LevelReader level, BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
            FoxHoleGrowth.beforeSurvive((BlockState) (Object) this, level);
        }

        @Inject(method = "canSurvive", at = @At("RETURN"))
        private void invfix$foxHoleSurviveEnd(LevelReader level, BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
            FoxHoleGrowth.afterSurvive();
        }
    }

    /** Ночное затемнение неба — 0 на время тика растения с «ростом ночью». */
    @Mixin(Level.class)
    public abstract static class SkyDarken {

        @Inject(method = "getSkyDarken", at = @At("HEAD"), cancellable = true)
        private void invfix$foxHoleNightGrowth(CallbackInfoReturnable<Integer> cir) {
            if (FoxHoleGrowth.ignoreNight()) cir.setReturnValue(0);
        }
    }

    /** Освещённость 15 для растения с «ростом без света» (и в мире, и на участках кораблей Sable). */
    @Mixin(LevelLightEngine.class)
    public abstract static class Brightness {

        @Inject(method = "getRawBrightness", at = @At("HEAD"), cancellable = true)
        private void invfix$foxHoleLightless(BlockPos pos, int amount, CallbackInfoReturnable<Integer> cir) {
            if (FoxHoleGrowth.ignoreDarkness()) cir.setReturnValue(15);
        }
    }
}
