package com.invfix.mixin.foxhole;

import com.invfix.foxhole.FoxHoleGrowth;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Рост растений в Fox Hole — см. FoxHoleGrowth. */
public final class FoxHoleGrowthMixins {

    private FoxHoleGrowthMixins() {}

    /** Случайный тик блока: у растений Fox Hole — множитель роста и рост ночью. */
    @Mixin(BlockBehaviour.BlockStateBase.class)
    public abstract static class RandomTick {

        @WrapMethod(method = "randomTick")
        private void invfix$foxHoleGrowth(ServerLevel level, BlockPos pos, RandomSource random, Operation<Void> original) {
            FoxHoleGrowth.randomTick((BlockState) (Object) this, level, pos, random,
                    () -> original.call(level, pos, random));
        }
    }

    /** Ночное затемнение неба — 0 на время тика растения с «ростом ночью». */
    @Mixin(Level.class)
    public abstract static class SkyDarken {

        @Inject(method = "getSkyDarken", at = @At("HEAD"), cancellable = true)
        private void invfix$foxHoleNightGrowth(CallbackInfoReturnable<Integer> cir) {
            if (FoxHoleGrowth.ignoreNight()) cir.setReturnValue(0);
        }
    }
}
