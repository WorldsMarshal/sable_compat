package com.invfix.mixin.foxhole;

import com.invfix.foxhole.FoxHole;
import com.invfix.foxhole.FoxHoleLevelData;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.progress.ChunkProgressListener;
import net.minecraft.world.RandomSequences;
import net.minecraft.world.level.CustomSpawner;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.LevelStem;
import net.minecraft.world.level.storage.LevelStorageSource;
import net.minecraft.world.level.storage.ServerLevelData;
import net.minecraft.world.level.storage.WorldData;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import java.util.concurrent.Executor;

/**
 * Fox Hole: своё время и погода. Ванильный createLevels даёт всем измерениям, кроме
 * Overworld, общий с Overworld DerivedLevelData — для Fox Hole подменяется на
 * FoxHoleLevelData (тот же DerivedLevelData, но со своим временем и погодой).
 */
@Mixin(MinecraftServer.class)
public abstract class FoxHoleLevelDataMixin {

    @Shadow @Final protected WorldData worldData;

    @WrapOperation(method = "createLevels", at = @At(value = "NEW", target = "net/minecraft/server/level/ServerLevel"))
    private ServerLevel invfix$foxHoleLevelData(MinecraftServer server, Executor executor,
                                                LevelStorageSource.LevelStorageAccess access, ServerLevelData data,
                                                ResourceKey<Level> dimension, LevelStem stem, ChunkProgressListener listener,
                                                boolean debug, long biomeZoomSeed, List<CustomSpawner> spawners,
                                                boolean tickTime, RandomSequences sequences, Operation<ServerLevel> original) {
        if (FoxHole.is(dimension)) {
            data = new FoxHoleLevelData(this.worldData, this.worldData.overworldData());
        }
        return original.call(server, executor, access, data, dimension, stem, listener, debug, biomeZoomSeed,
                spawners, tickTime, sequences);
    }
}
