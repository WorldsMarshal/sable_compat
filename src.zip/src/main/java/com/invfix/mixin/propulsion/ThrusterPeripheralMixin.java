package com.invfix.mixin.propulsion;

import com.invfix.flight.FlightCore;
import dan200.computercraft.api.lua.LuaException;
import dan200.computercraft.api.lua.LuaFunction;
import dev.propulsionteam.propulsionsimulated.content.thruster.AbstractThrusterBlockEntity;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/**
 * Flight-computer methods on ThrusterPeripheral - fixed thruster: no gimbal, but the body state and force-load still apply.
 *
 * Adds them to Create Propulsion's own peripheral, so a modem on a thruster sees setVector, setThrustNormalized AND
 * getBody, getMotion, getMount, getGround, setLoaded on the same object.
 *
 * WHY NOT A GENERIC SOURCE. That was the obvious answer and it is wrong: CC
 * resolves the peripheral capability first and only falls back to generic
 * sources when the block has none -
 *
 *     IPeripheral result = super.get(direction);
 *     if (result != null) return result;
 *     return Peripherals.getGenericPeripheral(...);
 *
 * These thrusters do publish a capability, so generic methods are never
 * reached. That is exactly why the survey found no thrusters "with flight
 * methods" while the modems were plainly attached.
 *
 * WHY NOT A COMPETING CAPABILITY. Registering our own provider for the same
 * block entity type would take setVector and setThrust away, and which provider
 * wins depends on mod load order.
 *
 * Merging methods into their peripheral class has neither problem: CC scans the
 * live peripheral object for @LuaFunction, and a mixin-merged method is a real
 * method with its annotations intact.
 *
 * The methods are deliberately NOT final. CreativeVectorThrusterPeripheral
 * extends VectorThrusterPeripheral, so putting the same final method on both
 * would leave a subclass trying to override a final parent method - the class
 * fails verification, ComputerBehaviour's static initialiser dies with it, and
 * then every thruster in the world crashes the tick that builds one.
 */
@Mixin(value = dev.propulsionteam.propulsionsimulated.compat.computercraft.ThrusterPeripheral.class,
        remap = false)
public class ThrusterPeripheralMixin {

    /**
     * The block entity, found by reflection rather than @Shadow.
     *
     * @Shadow needs the field's exact erased descriptor, and this one lives on
     * Create's generic SyncedPeripheral<T>, three mods up. Getting that type
     * wrong makes the mixin fail to apply - and it fails while ComputerBehaviour
     * is running its static initialiser, so the whole class fails to
     * initialise and every thruster in the world crashes the tick that tries
     * to build one. That is exactly what happened.
     *
     * A field scan cannot be wrong about a type it never names, and it survives
     * Create renaming or re-typing the field.
     */
    @Unique
    private static final Map<Class<?>, Field> invfix$FIELD = new ConcurrentHashMap<>();

    @Unique
    private AbstractThrusterBlockEntity invfix$be() throws LuaException {
        Field f = invfix$FIELD.computeIfAbsent(this.getClass(), c -> {
            for (Class<?> k = c; k != null; k = k.getSuperclass()) {
                for (Field candidate : k.getDeclaredFields()) {
                    if (AbstractThrusterBlockEntity.class.isAssignableFrom(candidate.getType())
                            || candidate.getName().equals("blockEntity")) {
                        candidate.setAccessible(true);
                        return candidate;
                    }
                }
            }
            return null;
        });
        if (f == null) throw new LuaException("cannot reach the thruster block entity");
        try {
            Object be = f.get(this);
            if (be instanceof AbstractThrusterBlockEntity t) return t;
            throw new LuaException("not a thruster");
        } catch (IllegalAccessException e) {
            throw new LuaException("cannot read the thruster block entity");
        }
    }

    @LuaFunction(mainThread = true)
    public Map<String, Object> getBody() throws LuaException {
        return FlightCore.getBody(invfix$be());
    }

    @LuaFunction(mainThread = true)
    public Map<String, Object> getMotion() throws LuaException {
        return FlightCore.getMotion(invfix$be());
    }

    @LuaFunction(mainThread = true)
    public Map<String, Object> getMount() throws LuaException {
        return FlightCore.getMount(invfix$be());
    }

    @LuaFunction(mainThread = true)
    public Map<String, Object> getEnv() throws LuaException {
        return FlightCore.getEnv(invfix$be());
    }

    @LuaFunction(mainThread = true)
    public Map<String, Object> getGround() throws LuaException {
        return FlightCore.getGround(invfix$be());
    }

    @LuaFunction(mainThread = true)
    public boolean setLoaded(boolean load) throws LuaException {
        return FlightCore.setLoaded(invfix$be(), load);
    }

    @LuaFunction(mainThread = true)
    public boolean isLoaded() throws LuaException {
        return FlightCore.isLoaded(invfix$be());
    }

    @LuaFunction
    public Map<String, Object> getLoadSupport() throws LuaException {
        return FlightCore.getLoadSupport(invfix$be());
    }

    @LuaFunction(mainThread = true)
    public Map<String, Object> toWorld(double x, double y, double z, boolean asDirection)
            throws LuaException {
        return FlightCore.toWorld(invfix$be(), x, y, z, asDirection);
    }

    @LuaFunction(mainThread = true)
    public Map<String, Object> toLocal(double x, double y, double z, boolean asDirection)
            throws LuaException {
        return FlightCore.toLocal(invfix$be(), x, y, z, asDirection);
    }

    @LuaFunction(mainThread = true)
    public void armDeadman(int ticks) throws LuaException {
        AbstractThrusterBlockEntity be = invfix$be();
        // the countdown lives on the block entity, so it keeps running even
        // when the computer that armed it has stopped
        // A NEGATIVE value disarms. Clamping it to zero, as this did, meant
        // "expired" - and an expired deadman forces the throttle to zero every
        // tick forever. A dead flight program therefore left the engine
        // permanently disabled, and the next run could not even read its
        // thrust: c came out 0.0 and nothing would launch.
        ((com.invfix.flight.Deadman) be).invfix$armDeadman(ticks);
    }

    @LuaFunction(mainThread = true)
    public int deadmanLeft() throws LuaException {
        return ((com.invfix.flight.Deadman) invfix$be()).invfix$deadmanLeft();
    }

    @LuaFunction(mainThread = true)
    public Map<String, Object> getState() throws LuaException {
        return FlightCore.getState(invfix$be());
    }

    @LuaFunction(mainThread = true)
    public void setControl(double vx, double vy, double throttle) throws LuaException {
        FlightCore.setControl(invfix$be(), vx, vy, throttle);
    }

    @LuaFunction(mainThread = true)
    public Map<String, Object> getDwAccum() throws LuaException {
        double[] d = ((com.invfix.flight.Deadman) invfix$be()).invfix$dwAccum();
        Map<String, Object> m = new HashMap<>();
        m.put("x", d[0]); m.put("y", d[1]); m.put("z", d[2]);
        m.put("mag", Math.sqrt(d[0]*d[0] + d[1]*d[1] + d[2]*d[2]));
        return m;
    }

    @LuaFunction(mainThread = true)
    public void resetDwAccum() throws LuaException {
        ((com.invfix.flight.Deadman) invfix$be()).invfix$resetDw();
    }
}