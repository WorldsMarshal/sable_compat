package com.invfix.mixin.propulsion;

import dev.propulsionteam.propulsionsimulated.content.thruster.AbstractThrusterBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * A deadman timer on the thruster itself.
 *
 * The problem it solves is not a control problem. A vehicle massing 7 with this
 * much thrust reached 1114 blocks per second, and the only way to stop it was
 * to delete the entity by id - because nothing on board was still running. The
 * computer had terminated, or the chunk had gone, and the throttle simply
 * stayed where it was last set. No Lua safety can cover that case: Lua is the
 * thing that stopped.
 *
 * So the countdown lives in the block entity's own tick. The flight program
 * refreshes it every loop; if the program dies, is terminated, or the sub-level
 * stops being ticked coherently, the count runs out and the engine shuts down
 * on its own within a second.
 *
 * Disarmed by default, so nothing changes for anyone who does not ask for it.
 */
@Mixin(value = AbstractThrusterBlockEntity.class, remap = false)
public abstract class ThrusterDeadmanMixin implements com.invfix.flight.Deadman {

    /** Ticks of authority remaining. -1 means the timer is not in use. */
    @Unique
    private int invfix$deadman = -1;

    /** Angular impulse this engine has delivered since the last reset. */
    @Unique private double invfix$dwx = 0;
    @Unique private double invfix$dwy = 0;
    @Unique private double invfix$dwz = 0;

    @Override
    public double[] invfix$dwAccum() {
        return new double[] { this.invfix$dwx, this.invfix$dwy, this.invfix$dwz };
    }

    @Override
    public void invfix$resetDw() {
        this.invfix$dwx = 0; this.invfix$dwy = 0; this.invfix$dwz = 0;
    }

    /** Negative disarms the timer entirely; zero means it has just expired. */
    @Override
    public void invfix$armDeadman(int ticks) {
        this.invfix$deadman = ticks;
    }

    @Override
    public int invfix$deadmanLeft() {
        return this.invfix$deadman;
    }

    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void invfix$deadmanTick(CallbackInfo ci) {
        // accumulate the exact angular effect of this tick before anything else
        AbstractThrusterBlockEntity me = (AbstractThrusterBlockEntity) (Object) this;
        if (me.getLevel() != null && !me.getLevel().isClientSide) {
            double[] d = com.invfix.flight.FlightCore.perTickDw(me);
            if (d != null) {
                this.invfix$dwx += d[0];
                this.invfix$dwy += d[1];
                this.invfix$dwz += d[2];
            }
        }
        if (this.invfix$deadman < 0) return;
        if (this.invfix$deadman > 0) {
            this.invfix$deadman--;
            return;
        }
        // expired: cut thrust every tick until someone re-arms it, because the
        // engine can be re-commanded by anything and this must keep winning
        // setDigitalInput is the public route to the same place: the CC helper
        // that would normally be used (ThrusterComputerHelpers) is
        // package-private, and it does nothing more than clamp a redstone level
        // and call this.
        AbstractThrusterBlockEntity self = (AbstractThrusterBlockEntity) (Object) this;
        if (self.getThrottle() > 0.0F) {
            self.setDigitalInput(0.0F);
        }
    }
}