package com.invfix.mixin;

import com.invfix.grab.GrabHandler;
import net.mcreator.invincibleinc.init.InvincibleIncModMobEffects;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Заменяет родной ThrowPProcedure на бросок из автономного GrabHandler (механика The Boys).
 * Вызывается через GrabnThrow0Procedure при shift + кнопке способности. После броска
 * снимаем GRABN_THROW_ACTIVE, чтобы захват не возобновился в оставшемся окне эффекта.
 */
@Mixin(value = net.mcreator.invincibleinc.procedures.ThrowPProcedure.class, remap = false)
public class ThrowPProcedureMixin {

    @Inject(method = "execute(Lnet/minecraft/world/level/LevelAccessor;DDDLnet/minecraft/world/entity/Entity;)V",
            at = @At("HEAD"), cancellable = true, remap = false)
    private static void invfix_throw(LevelAccessor world, double x, double y, double z, Entity entity, CallbackInfo ci) {
        ci.cancel();
        if (!world.isClientSide() && entity instanceof ServerPlayer sp) {
            GrabHandler.handleThrow(sp);
            sp.removeEffect(InvincibleIncModMobEffects.GRABN_THROW_ACTIVE);
        }
    }
}