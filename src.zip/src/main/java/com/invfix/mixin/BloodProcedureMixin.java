package com.invfix.mixin;

import com.invfix.threatmode.ThreatModeState;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import net.neoforged.bus.api.Event;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Патч BloodProcedure: кровяные партиклы только при attackPower атакующего >= 80.
 *
 * BloodProcedure целиком занимается только спавном кровяных партиклов (photon:world_blood1).
 * Никакой игровой логики там нет — безопасно отменять execute() целиком.
 *
 * Анонимный класс с timedLoop внутри процедуры делает @Redirect ненадёжным,
 * поэтому используем @Inject + cancel на HEAD — чисто и без риска промаха.
 */
@Mixin(value = net.mcreator.invincibleinc.procedures.BloodProcedure.class, remap = false)
public class BloodProcedureMixin {

    @Inject(
            method = "execute(Lnet/neoforged/bus/api/Event;" +
                    "Lnet/minecraft/world/level/LevelAccessor;" +
                    "Lnet/minecraft/world/damagesource/DamageSource;" +
                    "Lnet/minecraft/world/entity/Entity;)V",
            at = @At("HEAD"),
            cancellable = true,
            remap = false
    )
    private static void invfix_guardBloodParticle(
            Event event, LevelAccessor world, DamageSource damagesource,
            Entity entity, CallbackInfo ci) {
        Entity attacker = damagesource.getEntity();
        if (attacker == null) {
            // Урон без атакующего (падение, огонь и т.д.) — кровь не нужна
            ci.cancel();
            return;
        }
        // Сдерживание (Threatening/Playful Mode): удар считается человеческим —
        // кровь выдавала бы реальную силу, глушим симметрично ударной волне.
        if (ThreatModeState.isHeld(attacker)) {
            ci.cancel();
            return;
        }
        try {
            double ap = attacker
                    .getData(InvincibleIncModVariables.PLAYER_VARIABLES)
                    .attackPower;
            if (ap < 80.0) {
                ci.cancel();
            }
        } catch (Exception e) {
            // Если getData не поддерживается для этой сущности — без крови
            ci.cancel();
        }
    }
}