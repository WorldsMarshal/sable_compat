package com.invfix.mixin.spawncontrol;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.List;

/**
 * Фикс краша SpawnControl 3.1.0:
 * java.lang.ArrayIndexOutOfBoundsException: Index N out of bounds for length M
 *   at Int2ObjectLinkedOpenHashMap$MapIterator.nextEntry(...)
 *   at PerformanceWatchdog.runBanEnforcement(PerformanceWatchdog.java:50)
 *
 * Причина: PerformanceWatchdog итерирует живой итератор level.getAllEntities()
 * (внутри — Int2ObjectLinkedOpenHashMap хранилища сущностей), а тело цикла
 * может модифицировать эту карту. Главный виновник — getBiome(level, mob):
 * запрос биома по позиции моба на краю прогруженной зоны инициирует подгрузку
 * чанка, вместе с чанком в карту добавляются его сущности, и итератор ломается
 * с ArrayIndexOutOfBoundsException. Тот же риск есть и в runLagCleanup.
 *
 * Фикс: перед итерацией снимаем моментальную копию списка сущностей в ArrayList.
 * Дальше вся логика мода (whitelist/blocklist, лаг-чистка) работает без изменений —
 * просто по снапшоту, который никто не может изменить под ногами.
 */
@Mixin(targets = "com.titammods.spawncontrol.event.PerformanceWatchdog", remap = false)
public abstract class SpawnControlWatchdogMixin {

    @Redirect(
            method = "runBanEnforcement",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/level/ServerLevel;getAllEntities()Ljava/lang/Iterable;"
            )
    )
    private static Iterable<Entity> invfix$snapshotForBanEnforcement(ServerLevel level) {
        return invfix$snapshotEntities(level);
    }

    @Redirect(
            method = "runLagCleanup",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/level/ServerLevel;getAllEntities()Ljava/lang/Iterable;"
            )
    )
    private static Iterable<Entity> invfix$snapshotForLagCleanup(ServerLevel level) {
        return invfix$snapshotEntities(level);
    }

    /**
     * Снимает копию списка сущностей уровня. Копирование выполняется на серверном
     * потоке одним непрерывным проходом (никакой чужой код между элементами не
     * исполняется), поэтому карта под ним измениться не может. На случай
     * экзотических модов, трогающих хранилище с других потоков, обёрнуто
     * в try-catch: при сбое прогон просто пропускается до следующего интервала
     * (бан-чистка — раз в 5 секунд, лаг-чистка — раз в 30), потерь логики нет.
     */
    private static List<Entity> invfix$snapshotEntities(ServerLevel level) {
        List<Entity> snapshot = new ArrayList<>(512);
        try {
            for (Entity entity : level.getAllEntities()) {
                snapshot.add(entity);
            }
        } catch (ArrayIndexOutOfBoundsException | ConcurrentModificationException ex) {
            snapshot.clear();
        }
        return snapshot;
    }
}