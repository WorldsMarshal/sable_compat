package com.invfix.mixin;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Глушит приветственное actionbar-сообщение «Welcome ... To The Great World
 * of Invincible!», которое мод Invincible Inc показывает в
 * WhenjoinFirstTimeProcedure при первом входе игрока в мир.
 *
 * Перехватываем ЕДИНСТВЕННЫЙ вызов Player#displayClientMessage внутри
 * execute() и не пробрасываем его дальше. Вся остальная логика первого входа
 * (рандом расы, bloodline, выставление XP-капов) выполняется как обычно —
 * мы трогаем только показ сообщения.
 */
@Mixin(value = net.mcreator.invincibleinc.procedures.WhenjoinFirstTimeProcedure.class, remap = false)
public class WelcomeMessageSuppressMixin {

    @Redirect(
            method = "execute(Lnet/neoforged/bus/api/Event;" +
                    "Lnet/minecraft/world/level/LevelAccessor;" +
                    "Lnet/minecraft/world/entity/Entity;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/player/Player;" +
                            "displayClientMessage(Lnet/minecraft/network/chat/Component;Z)V"
            ),
            remap = false
    )
    private static void invfix_suppressWelcome(Player player, Component message, boolean actionBar) {
        // no-op — приветствие не показываем
    }
}