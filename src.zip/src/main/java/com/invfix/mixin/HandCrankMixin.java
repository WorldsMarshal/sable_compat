package com.invfix.mixin;

import com.invfix.IHandCrankStrength;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.kinetics.crank.HandCrankBlock;
import com.simibubi.create.content.kinetics.crank.HandCrankBlockEntity;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public class HandCrankMixin {

    // ─────────────────────────────────────────────────────────────────────────
    // 1. Блок — подавляет голод для не-людей, записывает mult в BE до turn().
    // ─────────────────────────────────────────────────────────────────────────
    @Mixin(value = HandCrankBlock.class, remap = false)
    public static class HandCrankBlockMixin {

        @Inject(
            method = "useItemOn",
            at = @At("HEAD"),
            remap = false
        )
        private void invfix_prepareStrengthMult(
                ItemStack stack, BlockState state, Level level, BlockPos pos,
                Player player, InteractionHand hand, BlockHitResult hit,
                CallbackInfoReturnable<ItemInteractionResult> cir) {

            if (player.isSpectator() || level.isClientSide) return;

            try {
                BlockEntity rawBe = level.getBlockEntity(pos);
                if (!(rawBe instanceof IHandCrankStrength hcs)) return;

                InvincibleIncModVariables.PlayerVariables vars =
                        player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);

                double mult = isHuman(vars.Race) ? 1.0 : Math.max(1.0, vars.currentStr);
                hcs.invfix$setStrengthMult(mult);

            } catch (Exception ignored) {}
        }

        @Redirect(
            method = "useItemOn",
            at = @At(
                value = "INVOKE",
                target = "Lnet/minecraft/world/entity/player/Player;causeFoodExhaustion(F)V"
            ),
            remap = false
        )
        private void invfix_suppressHunger(Player player, float exhaustion) {
            try {
                InvincibleIncModVariables.PlayerVariables vars =
                        player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                if (isHuman(vars.Race)) {
                    player.causeFoodExhaustion(exhaustion);
                }
                // не-люди: голод не тратится
            } catch (Exception e) {
                player.causeFoodExhaustion(exhaustion);
            }
        }

        private static boolean isHuman(String race) {
            return race == null || "§f§lHuman".equals(race) || "§lHuman".equals(race);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 2. BlockEntity — хранит mult, синхронизирует через NBT на клиент.
    //    write/read — это то, что Create шлёт через sendData() при каждом
    //    updateGeneratedRotation(), поэтому клиент всегда получает свежее
    //    значение и очки рендерят правильные SU.
    // ─────────────────────────────────────────────────────────────────────────
    @Mixin(value = HandCrankBlockEntity.class, remap = false)
    public static abstract class HandCrankBEMixin implements IHandCrankStrength {

        @Unique
        private double invfix_strengthMult = 1.0;

        @Override
        public void invfix$setStrengthMult(double mult) {
            this.invfix_strengthMult = mult;
        }

        @Override
        public double invfix$getStrengthMult() {
            return this.invfix_strengthMult;
        }

        // Пишем mult в NBT (вызывается при sendData → clientPacket=true тоже)
        @Inject(
            method = "write(Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/core/HolderLookup$Provider;Z)V",
            at = @At("TAIL"),
            remap = false
        )
        private void invfix_writeStrengthMult(
                CompoundTag compound, HolderLookup.Provider registries,
                boolean clientPacket, CallbackInfo ci) {
            compound.putDouble("invfix_StrMult", invfix_strengthMult);
        }

        // Читаем mult из NBT (вызывается при получении пакета на клиенте)
        @Inject(
            method = "read(Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/core/HolderLookup$Provider;Z)V",
            at = @At("TAIL"),
            remap = false
        )
        private void invfix_readStrengthMult(
                CompoundTag compound, HolderLookup.Provider registries,
                boolean clientPacket, CallbackInfo ci) {
            if (compound.contains("invfix_StrMult")) {
                invfix_strengthMult = compound.getDouble("invfix_StrMult");
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 3. KineticBlockEntity — умножает ёмкость (SU/RPM) на mult.
    //    Работает и на сервере (сеть), и на клиенте (очки, тултип).
    // ─────────────────────────────────────────────────────────────────────────
    @Mixin(value = KineticBlockEntity.class, remap = false)
    public static class KineticBECapMixin {

        @Inject(
            method = "calculateAddedStressCapacity",
            at = @At("RETURN"),
            cancellable = true,
            remap = false
        )
        private void invfix_multiplyHandCrankCapacity(CallbackInfoReturnable<Float> cir) {
            Object self = this;
            if (!(self instanceof HandCrankBlockEntity)) return;
            if (!(self instanceof IHandCrankStrength hcs)) return;

            double mult = hcs.invfix$getStrengthMult();
            if (mult <= 1.0) return;

            cir.setReturnValue(cir.getReturnValue() * (float) mult);
        }
    }
}
