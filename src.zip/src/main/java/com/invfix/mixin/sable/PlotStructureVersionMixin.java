package com.invfix.mixin.sable;

import com.invfix.thing.ISubLevelStructureVersion;
import dev.ryanhcode.sable.sublevel.plot.LevelPlot;
import dev.ryanhcode.sable.sublevel.plot.PlotChunkHolder;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Ставит на плот счётчик изменений структуры.
 *
 * Саблевел уже проводит каждую установку и каждый снос блока внутри плота через
 * {@code LevelPlot.onBlockChange} — это ровно то событие, которое нужно шине
 * компьютера, чтобы понять, что состав корабля поменялся. Вместо того чтобы
 * каждый тик обходить все блок-сущности и сравнивать, что изменилось, компьютер
 * сравнивает два long'а, а обход делает только на том тике, когда счётчик
 * сдвинулся.
 *
 * {@code addChunkHolder} учтён отдельно: при загрузке саблевела чанки приезжают
 * с уже готовыми блок-сущностями, и {@code onBlockChange} на них не срабатывает.
 * Без этого инжекта шина после перезахода в мир ждала бы страховочного скана.
 *
 * Счётчик только монотонный — смысл имеет исключительно равенство двух подряд
 * снятых значений, не сама величина. Переполнение long'а здесь недостижимо.
 */
@Mixin(value = LevelPlot.class, remap = false)
public abstract class PlotStructureVersionMixin implements ISubLevelStructureVersion {

    @Unique
    private long invfix$structureVersion = 1L;

    @Override
    public long invfix$structureVersion() {
        return invfix$structureVersion;
    }

    @Override
    public void invfix$bumpStructureVersion() {
        invfix$structureVersion++;
    }

    @Inject(method = "onBlockChange", at = @At("TAIL"), require = 0)
    private void invfix$onBlockChange(BlockPos pos, BlockState state, CallbackInfo ci) {
        invfix$structureVersion++;
    }

    @Inject(method = "addChunkHolder", at = @At("TAIL"), require = 0)
    private void invfix$onAddChunkHolder(ChunkPos localChunkPos, PlotChunkHolder holder,
                                         boolean initializeLighting, CallbackInfo ci) {
        invfix$structureVersion++;
    }

    @Inject(method = "onRemove", at = @At("TAIL"), require = 0)
    private void invfix$onRemove(CallbackInfo ci) {
        invfix$structureVersion++;
    }
}
