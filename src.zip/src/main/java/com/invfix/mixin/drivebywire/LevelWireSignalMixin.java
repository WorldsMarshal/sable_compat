package com.invfix.mixin.drivebywire;

import com.invfix.dbw.WireRedstoneBridge;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Заставляет ванильный редстоун видеть сигнал провода.
 *
 * До этого сигнал, доставленный проводом, лежал в узле менеджера и был виден
 * только тем блокам, которые DBW специально пропатчил под себя через
 * {@code WireRedstoneCompat}. Обычная лампа, поршень, дверь или пыль о нём не
 * знали ничего. Провод при этом уже умел брать любой блок источником — канал для
 * не-хаба по умолчанию {@code world}, — так что не хватало ровно двух половин:
 * этой и опроса источника.
 *
 * {@code getSignal} — единственная точка, через которую ванилла спрашивает
 * «сколько блок выдаёт в эту сторону»: {@code getBestNeighborSignal} и
 * {@code hasNeighborSignal} сводятся к ней. Поэтому одного инжекта хватает,
 * чтобы провод заработал со всем, что потребляет редстоун.
 *
 * Слабое питание, не сильное. {@code getDirectSignal} намеренно не трогается:
 * провод питает грань блока, а не проталкивает сигнал сквозь него дальше в пыль,
 * и это же держит связь односторонней.
 */
@Mixin(Level.class)
public abstract class LevelWireSignalMixin {

    @Inject(method = "getSignal", at = @At("RETURN"), cancellable = true, require = 0)
    private void invfix$addWireSignal(BlockPos pos, Direction direction,
                                      CallbackInfoReturnable<Integer> cir) {
        int wire = WireRedstoneBridge.wireSignalAt((Level) (Object) this, pos, direction);
        if (wire > cir.getReturnValueI()) cir.setReturnValue(wire);
    }
}
