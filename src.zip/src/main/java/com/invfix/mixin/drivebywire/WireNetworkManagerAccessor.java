package com.invfix.mixin.drivebywire;

import edn.stratodonut.drivebywire.wire.WireNetworkManager;
import java.util.Map;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Доступ к таблице источников провода без копии.
 *
 * У менеджера есть публичный {@code getNetwork}, но он делает глубокий
 * {@code Map.copyOf} на каждый вызов. Опрос источников идёт каждый тик, поэтому
 * копия здесь была бы мусором на ровном месте — читаем оригинал и ничего в нём
 * не меняем.
 */
@Mixin(value = WireNetworkManager.class, remap = false)
public interface WireNetworkManagerAccessor {

    /** Источник (упакованная позиция) -> канал -> приёмники. */
    @Accessor("sinks")
    Map<Long, Map<String, ?>> invfix$sinks();
}
