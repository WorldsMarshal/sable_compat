package com.invfix.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

/**
 * Фикс несовместимости Synaxis 1.3.x ↔ Sable 2.0.1.
 *
 * Synaxis объявляет accessor-интерфейс RapierConstraintHandleAccessor на
 * RapierConstraintHandle с двумя @Accessor:
 *   @Accessor("sceneID") int  synaxis$getSceneId();   // поля sceneID в Sable 2.0.1 НЕТ
 *   @Accessor("handle")  long synaxis$getNativeHandle();
 * Поле sceneID в Sable 2.0.1 переименовано в sceneHandle (long). @Accessor падает
 * с InvalidAccessorException и валит ВЕСЬ accessor-миксин атомарно — то есть НЕ
 * генерируется ни getSceneId, ни getNativeHandle. Сам интерфейс к классу при этом
 * добавлен (фаза сбора интерфейсов проходит раньше), поэтому при удалении
 * constraint'а Synaxis вызывает эти методы на наследнике и ловит AbstractMethodError.
 *
 * Поэтому реализуем ОБА метода сами, на базовом RapierConstraintHandle (там
 * объявлены оба поля — sceneHandle и handle). Конкретные методы наследуются всеми
 * Rapier*ConstraintHandle и закрывают абстрактные методы интерфейса.
 *
 * remap=false обязателен и на @Mixin, и на каждом @Shadow: поля модовые, не из
 * обфускации Minecraft (иначе Mixin лезет в refmap и валит миксин).
 *
 * Если Synaxis когда-нибудь починят (@Accessor на sceneHandle) — этот миксин надо
 * убрать, иначе будет конфликт двух реализаций одних и тех же методов.
 */
@Mixin(
        targets = "dev.ryanhcode.sable.physics.impl.rapier.constraint.RapierConstraintHandle",
        remap = false
)
public abstract class SynaxisConstraintIdFixMixin {

    @Shadow(remap = false)
    @Final
    protected long sceneHandle;

    @Shadow(remap = false)
    @Final
    protected long handle;

    /**
     * Реализация synaxis$getSceneId(). Имена методов должны совпадать в точности;
     * НЕ помечать @Unique. Long.hashCode даёт стабильный int на сцену.
     */
    public int synaxis$getSceneId() {
        return Long.hashCode(this.sceneHandle);
    }

    /**
     * Реализация synaxis$getNativeHandle() — просто нативный handle constraint'а.
     */
    public long synaxis$getNativeHandle() {
        return this.handle;
    }
}