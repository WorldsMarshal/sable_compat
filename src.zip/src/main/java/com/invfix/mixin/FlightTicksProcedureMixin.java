package com.invfix.mixin;

import com.invfix.altrumite.AltrumiteRace;
import net.mcreator.invincibleinc.procedures.FlightTicksProcedure;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Slice;

/**
 * Разрушение блоков при полёте для расы Altrumite.
 *
 * РАНЬШЕ: механику разрушения портировали вручную (TAIL-инъекция + своя сфера).
 * Это ломалось — инъекция срабатывала вне контекста активного полёта (рассинхрон
 * позиции «врезаюсь -> потом ломается», разрушение даже при простом включённом
 * полёте на скорости 3 без движения).
 *
 * ТЕПЕРЬ: не изобретаем велосипед. Оригинальный FlightTicksProcedure уже содержит
 * полноценное разрушение блоков в правильной ветке активного полёта, но гейтит его
 * белым списком рас:
 *   gamerule INVINCIBLE_BLOCK_DESTRUCTION && flightSpeed >= 3 &&
 *     (Race == Viltrumite || Human-Viltrumite || Thraxan-Viltrumite
 *      || Unopan || Power == Tech Jacket)
 *
 * Мы просто ДОБАВЛЯЕМ Altrumite в этот список. Первое сравнение в цепочке —
 * Race.equals("§4§lViltrumite"); через @Redirect возвращаем true ещё и когда раса
 * Altrumite. Цепочка ИЛИ замыкается, и срабатывает РОДНОЕ разрушение оригинала —
 * в правильном контексте, с родными партиклами/звуком, идентично Вильтрумитам.
 *
 * Слайс привязан к единственному в методе вызову GameRules#getBoolean
 * (гейт разрушения), поэтому ordinal=0 для String.equals внутри слайса попадает
 * ровно в проверку Viltrumite, а не в другие .equals по всему методу.
 *
 * Визуал полёта — целиком FlightFx (клиент, шейдеры). Отсюда убраны прежний
 * серверный циклон из частиц и облако частиц каждого тика; Photon-всплески
 * звуковых ударов глушит FlightPhotonFilter.
 */
@Mixin(value = FlightTicksProcedure.class, remap = false)
public class FlightTicksProcedureMixin {

    /**
     * Добавляет Altrumite в whitelist разрушения блоков оригинального FlightTicksProcedure.
     * Перехватывает Race.equals("§4§lViltrumite") (первый .equals после гейт-геймрула).
     */
    @Redirect(
            method = "execute",
            slice = @Slice(
                    from = @At(
                            value = "INVOKE",
                            target = "Lnet/minecraft/world/level/GameRules;getBoolean(Lnet/minecraft/world/level/GameRules$Key;)Z",
                            remap = false
                    )
            ),
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/lang/String;equals(Ljava/lang/Object;)Z",
                    ordinal = 0,
                    remap = false
            ),
            remap = false
    )
    private static boolean invfix_altrumiteInWhitelist(String race, Object viltrumite) {
        return race.equals(viltrumite) || AltrumiteRace.RACE.equals(race);
    }

    // ===================== облако частиц каждого тика =====================

    /**
     * Оригинал на flightSpeed >= 3 каждый тик шлёт облако частиц CLOUD вокруг
     * игрока (разброс 3.0 по осям). Теперь полёт рисует FlightFx (конус Маха,
     * след, удары) — облако убрано. Только оно: облако разрушения в жидкости
     * (CLOUD, разброс 10.0) и дым разрушения (WHITE_SMOKE) идут как были.
     */
    @Redirect(
            method = "execute",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/level/ServerLevel;sendParticles(Lnet/minecraft/core/particles/ParticleOptions;DDDIDDDD)I",
                    remap = false
            ),
            require = 1,
            remap = false
    )
    private static int invfix_dropFlightCloud(ServerLevel level, ParticleOptions type, double x, double y, double z,
                                              int count, double xDist, double yDist, double zDist, double speed) {
        if (type == ParticleTypes.CLOUD && xDist == 3.0 && yDist == 3.0 && zDist == 3.0) return 0;
        return level.sendParticles(type, x, y, z, count, xDist, yDist, zDist, speed);
    }
}