package com.invfix.mixin.cbc;

import com.invfix.cbc.SmartCannonMount;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.sublevel.SubLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaterniond;
import org.joml.Quaterniondc;
import org.joml.Vector3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rbasamoyai.createbigcannons.cannon_control.cannon_mount.CannonMountBlockEntity;
import rbasamoyai.createbigcannons.cannon_control.cannon_mount.CannonMountInterfaceBlockEntity;
import rbasamoyai.createbigcannons.cannon_control.contraption.PitchOrientedContraptionEntity;

/**
 * Computer-controlled laying for the CBC cannon mount.
 *
 * OWNERSHIP: while at least one ComputerCraft computer is attached, the mount
 * stops listening to the vanilla kinetic integration entirely - otherwise CBC
 * spins the barrel every tick and the controller has to drag it back, so the
 * two fight each other. The angles are captured at the head of tick() and
 * restored at the tail, which cancels whatever vanilla did, and then the
 * controller applies its own motion. Unplug the modem (or call setHold(false))
 * and stock behaviour returns untouched.
 *
 * SPEED still comes from the shafts: an axis with no rotation on its interface
 * cannot be laid, and the traverse rate is the same getAngularSpeed() the mount
 * uses under manual control - capped by whatever the computer asked for.
 */
@Mixin(value = CannonMountBlockEntity.class, remap = false)
public abstract class CannonMountAimMixin implements SmartCannonMount {

    @Shadow protected float cannonYaw;
    @Shadow protected float cannonPitch;
    @Shadow protected PitchOrientedContraptionEntity mountedContraption;
    @Shadow protected CannonMountInterfaceBlockEntity pitchInterface;
    @Shadow protected CannonMountInterfaceBlockEntity yawInterface;

    @Shadow protected abstract void applyRotation();

    @Shadow public abstract float getAngularSpeed(float value, float clientDiff);

    @Unique private Float   invfix$targetYaw   = null;
    @Unique private Float   invfix$targetPitch = null;
    @Unique private float   invfix$slewRate    = 1.0F;
    @Unique private float   invfix$rampTicks   = 10.0F;
    @Unique private boolean invfix$aiming      = false;
    @Unique private boolean invfix$hold        = true;   // suppress vanilla while attached
    // Правится из потока компьютера, читается из серверного - отсюда volatile
    // и отдельный замок ниже.
    @Unique private volatile int invfix$computers = 0;

    /** Свой замок: подключение приходит из чужого потока и не должно ждать мир. */
    @Unique private final Object invfix$computerLock = new Object();

    @Unique private volatile boolean invfix$attachChanged = false;
    @Unique private boolean invfix$syncedOwned = false;  // mirror of the above on the client
    @Unique private float   invfix$vYaw        = 0.0F;
    @Unique private float   invfix$vPitch      = 0.0F;
    @Unique private float   invfix$preYaw      = 0.0F;
    @Unique private float   invfix$prePitch    = 0.0F;
    // absolute world direction to hold, re-solved every tick
    @Unique private Double  invfix$holdAz      = null;
    @Unique private Double  invfix$holdEl      = null;
    // self-timed trigger: verified and pulled inside one tick
    @Unique private double  invfix$fireTol     = 0.0;
    // Per-axis tolerance. A single scalar on sqrt(az^2+elev^2) is the wrong
    // shape: a degree of elevation and a degree of azimuth do not cost the same
    // number of blocks, and the ratio changes with range and arc. Given both,
    // the gate becomes an ellipse sized in BLOCKS of miss rather than degrees.
    @Unique private double  invfix$fireTolAz   = 0.0;
    @Unique private double  invfix$fireTolEl   = 0.0;
    @Unique private int     invfix$fireTicks   = 0;
    @Unique private int     invfix$fireState   = 0;
    // previous tick's pointing error, for one-tick-ahead prediction
    @Unique private double  invfix$prevErrAz   = Double.NaN;
    @Unique private double  invfix$prevErrEl   = Double.NaN;
    @Unique private double  invfix$lastRate    = 0.0;
    @Unique private double  invfix$fireLead    = 0.75;
    @Unique private double[] invfix$shotLog    = new double[] {0,0,0,0,0,0,0,0,0,0,0,0};
    // Servo / hull handling. On a marginally buoyant airframe the gun and the
    // hull feed each other: traversing shifts the centre of mass, the hull
    // rolls, the controller corrects, the mass shifts again. These three knobs
    // exist to break that loop.
    @Unique private boolean invfix$servo       = true;   // false = barrel frozen
    @Unique private float   invfix$deadband    = 0.0F;   // deg of error to ignore
    @Unique private double  invfix$poseLead    = 1.0;    // ticks of hull extrapolation
    @Unique private final Quaterniond invfix$prevPose = new Quaterniond();
    @Unique private boolean invfix$havePose    = false;
    // How much angular travel per tick the tracking loop is ASKING for, versus
    // what the shafts can deliver. If demand exceeds supply the barrel is being
    // outrun by the hull and no amount of prediction will close the error.
    @Unique private float   invfix$demandYaw   = 0.0F;
    @Unique private float   invfix$demandPitch = 0.0F;
    @Unique private float   invfix$supplyYaw   = 0.0F;
    @Unique private float   invfix$supplyPitch = 0.0F;
    // LEVITITE PHYSICS.
    // Sable's kickEntity adds the sublevel's velocity AT THE SHELL'S POSITION to
    // the shell as it leaves (CBC opts into this explicitly, see
    // EntitySubLevelUtilMixin). That velocity is linearVelocity + omega x r, in
    // blocks per SECOND, scaled by 0.05 to per-tick. On a hull that is drifting
    // and rolling it is a few hundredths of a block per tick - which sounds like
    // nothing until you notice the shell keeps it for the whole flight: a lateral
    // 0.015 b/t decaying at 0.99 integrates to about 1.5 blocks.
    // It also depends on WHERE the muzzle is, because of the omega x r term, so
    // the geometry has to be known here and not just in Lua.
    @Unique private double  invfix$v0        = 17.0;
    @Unique private double  invfix$geomUp    = 2.0;
    @Unique private double  invfix$geomLen   = 13.5;
    @Unique private boolean invfix$launchMode = false;
    @Unique private double  invfix$launchSpeed = 0.0;
    @Unique private final double[] invfix$lastVp = new double[3];

    /**
     * Опорное решение для поправки на каждом тике, или null.
     *
     * Lua решает баллистику честно, но раз в несколько тиков, а корабль за это
     * время успевает сместить дульный срез, чуть сменить скорость и повернуть.
     * На пятнадцати тысячах блоков сотая блока в тик сноса стоит десятую блока
     * промаха, и никакая частота опроса из Lua этого не догонит: между тем, что
     * он посчитал, и тиком выстрела всегда проходит один-два тика.
     *
     * Поэтому Lua отдаёт сюда не только углы, но и то, как угол места зависит от
     * дальности, превышения и скорости в окрестности решения. Маунт на каждом
     * тике меряет настоящие дальность, превышение и скорость от настоящего
     * дульного среза и сдвигает угол по этой линейной модели, а азимут
     * пересчитывает точно. Ошибка линеаризации - второго порядка малости от
     * смещения за несколько тиков, то есть ничтожна.
     *
     * Раскладка: tx ty tz, tvx tvy tvz, t0, az0 el0, R0 dy0 s0, cR cDy cS.
     * Цель движется со своей скоростью от тика t0: для неподвижной точки она
     * нулевая.
     */
    @Unique private double[] invfix$ref = null;

    /** Что поправка сделала на этом тике: dEl, dR, dDy, dS. Только для отладки. */
    @Unique private final double[] invfix$refState = new double[4];

    /**
     * Направление вылета спуск берёт у самой сущности пушки, теми же вызовами,
     * что fireShot, а не по формуле.
     *
     * Так была найдена ступенька: CBC поворачивал ствол через табличные синусы
     * Mth с шагом 0.0055 градуса, и гладкая формула видела ствол там, где его не
     * было. Ступеньку убирает CannonExactRotationMixin. Проверка по сущности
     * остаётся: спуск должен смотреть на то, что получит снаряд, а не на то, что
     * мы о нём думаем, - что бы там ни поменялось в CBC или catnip потом.
     *
     * Пока флаг стоит, launchBore спрашивает саму сущность пушки.
     */
    @Unique private boolean invfix$exact = false;

    /** Точная ошибка вылета последнего взведённого тика, для телеметрии Lua. */
    @Unique private double[] invfix$xErr = null;
    @Unique private long invfix$xErrTick = -1L;
    @Unique private boolean invfix$inTick = false;

    @Unique
    private static float invfix$wrap180(float a) {
        a = a % 360.0F;
        if (a > 180.0F)  a -= 360.0F;
        if (a < -180.0F) a += 360.0F;
        return a;
    }

    /**
     * One axis of a trapezoidal profile: ramp up, cruise, brake so the axis
     * lands exactly on the target instead of snapping to it.
     */
    @Unique
    private static float invfix$profile(float err, float v, float vmax, float accel) {
        if (vmax <= 0.0F) return 0.0F;
        if (accel <= 0.0F) accel = vmax;
        float brakeDist = (v * v) / (2.0F * accel);
        boolean sameWay = (v == 0.0F) || (Math.signum(v) == Math.signum(err));
        if (!sameWay || Math.abs(err) <= brakeDist) {
            float nv = v - Math.signum(v == 0.0F ? err : v) * accel;
            if (v != 0.0F && Math.signum(nv) != Math.signum(v)) nv = 0.0F;
            v = nv;
        } else {
            v += Math.signum(err) * accel;
        }
        if (Math.abs(v) > vmax) v = Math.signum(v) * vmax;
        if (Math.abs(v) > Math.abs(err)) v = err;
        return v;
    }

    @Unique
    private boolean invfix$ownedFlag() {
        CannonMountBlockEntity self = (CannonMountBlockEntity) (Object) this;
        Level level = self.getLevel();
        if (level != null && level.isClientSide) return this.invfix$syncedOwned;
        return this.invfix$computers > 0 && this.invfix$hold;
    }

    @Unique
    private boolean invfix$owns() {
        return this.invfix$ownedFlag() && this.mountedContraption != null;
    }

    /** Push the ownership flag and the targets to clients so both sides agree. */
    @Unique
    private void invfix$sync() {
        CannonMountBlockEntity self = (CannonMountBlockEntity) (Object) this;
        Level level = self.getLevel();
        if (level == null || level.isClientSide) return;
        ((SmartBlockEntity) (Object) this).notifyUpdate();
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void invfix$capture(CallbackInfo ci) {
        // Отложенная работа за attach и detach: подключение приходит из чужого
        // потока и оставляет только флаг, а мир трогается здесь, где положено.
        boolean changed;
        int computers;
        synchronized (this.invfix$computerLock) {
            changed = this.invfix$attachChanged;
            this.invfix$attachChanged = false;
            computers = this.invfix$computers;
        }
        if (changed) {
            if (computers == 0) this.invfix$clearTargets();   // отдаём маунт обратно
            this.invfix$sync();
        }

        this.invfix$preYaw   = this.cannonYaw;
        this.invfix$prePitch = this.cannonPitch;
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void invfix$computerAim(CallbackInfo ci) {
        CannonMountBlockEntity self = (CannonMountBlockEntity) (Object) this;
        Level level = self.getLevel();
        if (level == null) return;
        // NOTE: this runs on the client too. The client integrates the same
        // kinetic rotation, so if only the server suppressed it the barrel
        // would judder between the client's prediction and the server's value.
        // Both sides cancel vanilla and run the identical profile instead.
        if (!this.invfix$owns()) { this.invfix$aiming = false; return; }

        // undo whatever the kinetic integration just did - the computer owns
        // these angles now, so the barrel does not drift on its own
        this.cannonYaw   = this.invfix$preYaw;
        this.cannonPitch = this.invfix$prePitch;

        // A world hold is re-solved from the CURRENT hull pose on every tick.
        // Lua can only correct a few times a second; the platform moves at 20
        // Hz, so anything slower ends up chasing an old pose and the gun and
        // the airframe fight each other. Doing it here removes that lag.
        // Hull pose, and where it will be next tick. Both are needed: the CHECK
        // uses the pose as it is now, the SETPOINT has to use the predicted one.
        // The shell inherits the barrel angles from the end of THIS tick and
        // meets the hull pose of the NEXT one, so aiming at the current pose
        // bakes in one tick of hull rotation as error. On a hull that never
        // stops moving that error never goes away by waiting.
        SubLevel sub0 = this.invfix$subLevel();
        Quaterniond posePred = null;
        if (sub0 != null) {
            Quaterniond now = new Quaterniond(sub0.logicalPose().orientation());
            if (this.invfix$havePose && this.invfix$poseLead != 0.0) {
                Quaterniond d = new Quaterniond(this.invfix$prevPose).invert().premul(now);
                if (this.invfix$poseLead != 1.0) {
                    d = new Quaterniond().slerp(d, this.invfix$poseLead);
                }
                posePred = new Quaterniond(now).premul(d);
            } else {
                posePred = new Quaterniond(now);
            }
            this.invfix$prevPose.set(now);
            this.invfix$havePose = true;
        }

        if (this.invfix$holdAz != null && this.invfix$holdEl != null) {
            double aimAz = this.invfix$holdAz;
            double aimEl = this.invfix$holdEl;
            if (this.invfix$launchMode && this.invfix$ref != null && !level.isClientSide) {
                // Два решения из одной опоры. Первое - для этого тика: его видит
                // спуск, потому что выстрел, если он случится, случится сейчас и
                // из нынешнего положения среза. Второе - на тик вперёд: углы,
                // выставленные сейчас, встретят уже следующее положение корпуса,
                // и если целиться в нынешнее, ствол будет вечно отставать ровно
                // на один тик сноса и спуск не откроется никогда.
                double[] v0 = this.invfix$hullVelocity();
                double[] now = this.invfix$refSolve(level, 0.0, v0);
                if (now != null) {
                    this.invfix$holdAz = now[0];
                    this.invfix$holdEl = now[1];
                }
                double[] next = this.invfix$refSolve(level, this.invfix$poseLead, v0);
                if (next != null) {
                    aimAz = next[0];
                    aimEl = next[1];
                } else {
                    aimAz = this.invfix$holdAz;
                    aimEl = this.invfix$holdEl;
                }
            }
            Vector3d want = invfix$dirOf(aimAz, aimEl);
            if (this.invfix$launchMode) {
                // holdAz/holdEl describe where the SHELL must go, not where the
                // barrel must point. Back out the hull's contribution first.
                double[] v = this.invfix$hullVelocity();
                this.invfix$lastVp[0] = v[0];
                this.invfix$lastVp[1] = v[1];
                this.invfix$lastVp[2] = v[2];
                want = this.invfix$boreForLaunch(want, new Vector3d(v[0], v[1], v[2]));
            }
            if (posePred != null) posePred.transformInverse(want);
            this.invfix$targetYaw   = (float) Math.toDegrees(Math.atan2(-want.x, want.z));
            this.invfix$targetPitch = (float) Math.toDegrees(Math.asin(Mth.clamp(want.y, -1.0, 1.0)));
        }

        // available speed still comes from the shafts
        float yawMax   = Math.abs(this.getAngularSpeed(-this.yawInterface.getSpeed(), 0.0F));
        float pitchMax = Math.abs(this.getAngularSpeed(this.pitchInterface.getSpeed(), 0.0F));
        float cap  = Math.max(0.001F, this.invfix$slewRate);
        yawMax   = Math.min(yawMax,   cap);
        pitchMax = Math.min(pitchMax, cap);
        float ramp = Math.max(1.0F, this.invfix$rampTicks);
        this.invfix$supplyYaw   = yawMax;
        this.invfix$supplyPitch = pitchMax;

        boolean moving = false;

        // TWO REGIMES.
        //
        // Point-to-point (aim / aimWorld): trapezoid. Ramp up, cruise, brake, so
        // a long traverse does not slam into the stop.
        //
        // Tracking (holdWorld): the setpoint moves every tick, and a trapezoid
        // is the wrong tool for that - its braking distance is computed for a
        // target standing still, so against a moving one it brakes early and
        // trails behind permanently. Here the axis just takes the largest step
        // the shaft allows toward the setpoint. That is the fastest a physical
        // shaft can follow, and it is what makes "outrun the hull" work.
        boolean tracking = this.invfix$isHoldingWorld();

        if (this.invfix$servo && this.invfix$targetYaw != null && yawMax > 0.0F) {
            float err = invfix$wrap180(this.invfix$targetYaw - this.cannonYaw);
            if (Math.abs(err) <= this.invfix$deadband) {
                this.invfix$vYaw = 0.0F;
            } else if (tracking) {
                this.invfix$demandYaw = Math.abs(err);
                float step = Mth.clamp(err, -yawMax, yawMax);
                this.cannonYaw = (this.cannonYaw + step) % 360.0F;
                this.invfix$vYaw = step;
                if (step != 0.0F) moving = true;
            } else {
                this.invfix$vYaw = invfix$profile(err, this.invfix$vYaw, yawMax, yawMax / ramp);
                if (this.invfix$vYaw != 0.0F) {
                    this.cannonYaw = (this.cannonYaw + this.invfix$vYaw) % 360.0F;
                    moving = true;
                } else if (Math.abs(err) > 0.0005F) {
                    // never jump further than the shaft could actually turn
                    this.cannonYaw = (this.cannonYaw + Mth.clamp(err, -yawMax, yawMax)) % 360.0F;
                }
            }
        } else {
            this.invfix$vYaw = 0.0F;
        }

        if (this.invfix$servo && this.invfix$targetPitch != null && pitchMax > 0.0F) {
            float lo = -this.mountedContraption.maximumDepression();
            float hi = this.mountedContraption.maximumElevation();
            float want = Mth.clamp(this.invfix$targetPitch, lo, hi);
            float err = want - this.cannonPitch;
            if (Math.abs(err) <= this.invfix$deadband) {
                this.invfix$vPitch = 0.0F;
            } else if (tracking) {
                this.invfix$demandPitch = Math.abs(err);
                float step = Mth.clamp(err, -pitchMax, pitchMax);
                this.cannonPitch = Mth.clamp(this.cannonPitch + step, lo, hi);
                this.invfix$vPitch = step;
                if (step != 0.0F) moving = true;
            } else {
                this.invfix$vPitch = invfix$profile(err, this.invfix$vPitch, pitchMax, pitchMax / ramp);
                if (this.invfix$vPitch != 0.0F) {
                    this.cannonPitch = this.cannonPitch + this.invfix$vPitch;
                    moving = true;
                } else if (Math.abs(err) > 0.0005F) {
                    this.cannonPitch = this.cannonPitch + Mth.clamp(err, -pitchMax, pitchMax);
                }
                this.cannonPitch = Mth.clamp(this.cannonPitch, lo, hi);
            }
        } else {
            this.invfix$vPitch = 0.0F;
        }

        this.invfix$aiming = moving;
        this.applyRotation();
        if (!level.isClientSide) self.setChanged();

        // TRIGGER.
        //
        // The shell does not leave along the angles we just applied. CBC spawns
        // it with toGlobalVector(muzzle, 0.0F), and partialTick 0 resolves to
        // the contraption's prevPitch / prevYaw - the orientation from the END
        // OF THE PREVIOUS TICK. The contraption entity copies prev = current at
        // the top of its own tick, and entities tick before block entities, so
        // by the time we get here the shell is already committed to the old
        // angles no matter what we do next.
        //
        // Judging the shot on the angles we just set is therefore measuring the
        // wrong instant: whatever the barrel moved this tick becomes pure aiming
        // error, and the log still prints 0.0000 because the log is measuring
        // the wrong instant too. A 0.369 deg final step - one ordinary slew
        // snap - was worth 10 blocks at 580.
        //
        // So the whole decision runs on invfix$launchError(), which is built
        // from the captured pre-tick angles. A consequence worth knowing: the
        // gun now has to be settled for one full tick before it will fire, and
        // that is correct, because a barrel that is still moving cannot deliver
        // the angle it is pointing at.
        if (!level.isClientSide) {
            this.invfix$inTick = true;
            double[] err = this.invfix$launchError();
            this.invfix$inTick = false;
            double rAz = Double.isNaN(this.invfix$prevErrAz) ? 0.0 : err[0] - this.invfix$prevErrAz;
            double rEl = Double.isNaN(this.invfix$prevErrEl) ? 0.0 : err[1] - this.invfix$prevErrEl;
            this.invfix$prevErrAz = err[0];
            this.invfix$prevErrEl = err[1];
            this.invfix$lastRate = Math.sqrt(rAz*rAz + rEl*rEl);

            if (this.invfix$fireTicks > 0) {
                // Решение принимается в том же состоянии, в каком из него уйдёт
                // выстрел: ствол возвращается на углы прошлого тика, и
                // направление берётся у самой сущности пушки, теми же вызовами,
                // что делает fireShot. Какой бы угол сущность ни прочла - старый
                // или текущий, - в этом состоянии они совпадают, и спуск видит
                // ровно то направление, которое получит снаряд.
                float setYaw = this.cannonYaw, setPitch = this.cannonPitch;
                double[] cmd = this.invfix$boreWorld();   // what we just set
                this.cannonYaw   = this.invfix$preYaw;
                this.cannonPitch = this.invfix$prePitch;
                this.applyRotation();
                this.invfix$inTick = true;
                this.invfix$exact = true;
                err = this.invfix$launchError();
                this.invfix$exact = false;
                this.invfix$inTick = false;
                this.invfix$xErr = err;
                this.invfix$xErrTick = level.getGameTime();
                // Lead stays available but is now extrapolating a quantity that
                // is already one tick behind, so it should normally be 0.
                double pAz = err[0] + rAz * this.invfix$fireLead;
                double pEl = err[1] + rEl * this.invfix$fireLead;
                boolean ellipse = this.invfix$fireTolAz > 0.0 && this.invfix$fireTolEl > 0.0;
                double actual, predicted, gate;
                if (ellipse) {
                    double ra = err[0] / this.invfix$fireTolAz;
                    double re = err[1] / this.invfix$fireTolEl;
                    actual = Math.sqrt(ra*ra + re*re);
                    double qa = pAz / this.invfix$fireTolAz;
                    double qe = pEl / this.invfix$fireTolEl;
                    predicted = Math.sqrt(qa*qa + qe*qe);
                    gate = 1.0;
                } else {
                    actual = Math.sqrt(err[0]*err[0] + err[1]*err[1]);
                    predicted = Math.sqrt(pAz*pAz + pEl*pEl);
                    gate = this.invfix$fireTol;
                }
                if (this.invfix$isHoldingWorld()
                        && actual <= gate
                        && predicted <= gate) {
                    this.invfix$fireTicks = 0;
                    this.invfix$fireState = 2;

                    // The barrel already sits where the shell thinks it is: the
                    // decision above was taken in that state, and it stays.
                    this.invfix$exact = true;
                    double[] bw = this.invfix$launchBore();   // what the shell gets
                    this.invfix$exact = false;
                    double[] mp = this.invfix$worldPos();
                    double[] vp = this.invfix$hullVelocity();
                    this.invfix$shotLog = new double[] {
                            bw[0], bw[1], err[0], err[1], mp[0], mp[1], mp[2],
                            cmd[0], cmd[1], vp[0], vp[1], vp[2] };
                    this.invfix$fire();
                } else {
                    // no shot: the barrel goes on to this tick's setpoint
                    this.cannonYaw   = setYaw;
                    this.cannonPitch = setPitch;
                    this.applyRotation();
                    if (--this.invfix$fireTicks <= 0) this.invfix$fireState = 3;
                }
            }
        }
    }

    // ---- SmartCannonMount ----

    @Override public float invfix$yaw()   { return this.cannonYaw; }
    // NOTE: deliberately NOT getDisplayPitch() - that snaps to 0 whenever
    // |cannonPitch| < 0.1, a display dead zone that would corrupt the loop.
    @Override public float invfix$pitch() { return this.cannonPitch; }
    @Override public boolean invfix$isAiming() { return this.invfix$aiming; }

    @Override
    public void invfix$setTargetYaw(Float yawDeg) {
        this.invfix$targetYaw = yawDeg;
        if (yawDeg != null) this.invfix$aiming = true;
        this.invfix$sync();
    }

    @Override
    public void invfix$setTargetPitch(Float pitchDeg) {
        this.invfix$targetPitch = pitchDeg;
        if (pitchDeg != null) this.invfix$aiming = true;
        this.invfix$sync();
    }

    @Override public Float invfix$targetYaw()   { return this.invfix$targetYaw; }
    @Override public Float invfix$targetPitch() { return this.invfix$targetPitch; }

    @Override
    public void invfix$clearTargets() {
        this.invfix$ref = null;
        this.invfix$holdAz = null;
        this.invfix$holdEl = null;
        this.invfix$targetYaw = null;
        this.invfix$targetPitch = null;
        this.invfix$aiming = false;
        this.invfix$vYaw = 0.0F;
        this.invfix$vPitch = 0.0F;
        this.invfix$sync();
    }

    @Override
    public void invfix$setSlewRate(float degPerTick) {
        this.invfix$slewRate = Mth.clamp(degPerTick, 0.01F, 20.0F);
    }

    @Override public float invfix$slewRate() { return this.invfix$slewRate; }

    @Override
    public void invfix$setRampTicks(float ticks) {
        this.invfix$rampTicks = Mth.clamp(ticks, 1.0F, 200.0F);
    }

    @Override public float invfix$rampTicks() { return this.invfix$rampTicks; }

    @Override
    public float[] invfix$axisSpeeds() {
        return new float[] {
                Math.abs(this.getAngularSpeed(-this.yawInterface.getSpeed(), 0.0F)),
                Math.abs(this.getAngularSpeed(this.pitchInterface.getSpeed(), 0.0F))
        };
    }

    @Override
    public void invfix$computerAttached(boolean attached) {
        // Здесь нельзя трогать мир. Метод зовётся из потока компьютера, пока
        // ComputerCraft держит замок обёртки периферии, и любое обращение к
        // уровню отсюда - notifyUpdate, setChanged, рассылка обновлений блока -
        // упирается в структуры серверного потока. А серверный поток в этот
        // момент ждёт как раз тот замок, который держит поток компьютера.
        // Встречное ожидание, и мир встаёт целиком: watchdog насчитывал тик
        // длиной в две минуты.
        //
        // Поэтому здесь только счётчик и флаг. Всё, что требует мира, делает
        // тик - он идёт каждые пятьдесят миллисекунд, и задержка на один тик
        // тут незаметна.
        synchronized (this.invfix$computerLock) {
            if (attached) this.invfix$computers++;
            else if (this.invfix$computers > 0) this.invfix$computers--;
            this.invfix$attachChanged = true;
        }
    }

    @Override public boolean invfix$hasComputer() { return this.invfix$computers > 0; }

    @Override
    public void invfix$setHold(boolean hold) {
        this.invfix$hold = hold;
        if (!hold) this.invfix$clearTargets();
        this.invfix$sync();
    }

    @Override public boolean invfix$hold() { return this.invfix$hold; }

    @Override
    public float[] invfix$pitchLimits() {
        if (this.mountedContraption == null) return null;
        return new float[] { -this.mountedContraption.maximumDepression(),
                this.mountedContraption.maximumElevation() };
    }

    @Override
    public boolean invfix$isAssembled() { return this.mountedContraption != null; }

    // ---- world pose (Sable aware) ----

    /**
     * The sublevel this mount rides, or null when it sits in the world.
     * Looked up lazily: a rig can be assembled and disassembled at runtime.
     */
    @Unique
    private SubLevel invfix$subLevel() {
        try {
            return Sable.HELPER.getContaining((CannonMountBlockEntity) (Object) this);
        } catch (Throwable ignored) {
            return null;   // Sable absent or the API moved
        }
    }

    @Override
    public boolean invfix$onSublevel() { return this.invfix$subLevel() != null; }

    @Override
    public double[] invfix$worldPos() {
        CannonMountBlockEntity self = (CannonMountBlockEntity) (Object) this;
        Vec3 pos = Vec3.atCenterOf(self.getBlockPos());
        SubLevel sub = this.invfix$subLevel();
        if (sub != null) pos = sub.logicalPose().transformPosition(pos);
        return new double[] { pos.x, pos.y, pos.z };
    }

    /**
     * Muzzle position in SUBLEVEL-LOCAL coordinates - which is what
     * Sable.HELPER.getVelocity wants, since it looks up the containing sublevel
     * from the point it is given.
     */
    @Unique
    private Vector3d invfix$muzzleLocal() {
        CannonMountBlockEntity self = (CannonMountBlockEntity) (Object) this;
        Vector3d d = invfix$dirOf(this.cannonYaw, this.cannonPitch);
        return new Vector3d(
                self.getBlockPos().getX() + 0.5 + d.x * this.invfix$geomLen,
                self.getBlockPos().getY() + 0.5 + this.invfix$geomUp + d.y * this.invfix$geomLen,
                self.getBlockPos().getZ() + 0.5 + d.z * this.invfix$geomLen);
    }

    /**
     * Muzzle velocity from the poses, blocks per tick: where the muzzle point is
     * now versus where it was last tick. This is Sable's own fallback formula
     * and it needs nothing but the sublevel, so it works when the physics-handle
     * path returns nothing.
     */
    @Unique
    private double[] invfix$hullVelocityFd() {
        SubLevel sub = this.invfix$subLevel();
        if (sub == null) return new double[] { 0, 0, 0 };
        Vector3d p = this.invfix$muzzleLocal();
        Vec3 local = new Vec3(p.x, p.y, p.z);
        Vec3 now  = sub.logicalPose().transformPosition(local);
        Vec3 was  = sub.lastPose().transformPosition(local);
        return new double[] { now.x - was.x, now.y - was.y, now.z - was.z };
    }

    /**
     * The velocity the hull will hand the shell, world frame, blocks per tick.
     *
     * Sable's getVelocity is the authority - it is literally what kickEntity
     * calls - but it only returns the rigid-body velocity when it can find a
     * physics handle for the sublevel. When it comes back empty and the poses
     * say otherwise, believe the poses: a silent zero here means no compensation
     * at all, which is the failure mode that looks like everything working.
     */
    @Override
    public double[] invfix$hullVelocity() {
        Vector3d out = new Vector3d();
        Level lvl = ((CannonMountBlockEntity) (Object) this).getLevel();
        if (lvl != null) {
            try {
                Sable.HELPER.getVelocity(lvl, this.invfix$muzzleLocal(), out);
                out.mul(0.05);   // Sable reports per second
            } catch (Throwable t) {
                out.zero();
            }
        }
        if (out.lengthSquared() < 1.0E-14) {
            double[] fd = this.invfix$hullVelocityFd();
            if (fd[0]*fd[0] + fd[1]*fd[1] + fd[2]*fd[2] > 1.0E-12) return fd;
        }
        return new double[] { out.x, out.y, out.z };
    }

    /** Both estimates side by side: {sableX,Y,Z, fdX,Y,Z}. For diagnosis. */
    @Override
    public double[] invfix$hullVelocitySources() {
        Vector3d out = new Vector3d();
        Level lvl = ((CannonMountBlockEntity) (Object) this).getLevel();
        if (lvl != null) {
            try {
                Sable.HELPER.getVelocity(lvl, this.invfix$muzzleLocal(), out);
                out.mul(0.05);
            } catch (Throwable t) { out.zero(); }
        }
        double[] fd = this.invfix$hullVelocityFd();
        return new double[] { out.x, out.y, out.z, fd[0], fd[1], fd[2] };
    }

    /**
     * Bore direction (world, unit) that makes V0*bore + hullVelocity point along
     * d. Solving |s*d - vp| = V0 for s gives the launch speed as a side effect,
     * which the ballistics needs: the shell does not leave at V0 when the hull
     * is moving.
     */
    @Unique
    private Vector3d invfix$boreForLaunch(Vector3d d, Vector3d vp) {
        double dvp  = d.dot(vp);
        double disc = dvp * dvp + this.invfix$v0 * this.invfix$v0 - vp.lengthSquared();
        if (disc < 0.0) {           // hull faster than the shell: nothing to aim
            this.invfix$launchSpeed = this.invfix$v0;
            return new Vector3d(d);
        }
        double s = dvp + Math.sqrt(disc);
        this.invfix$launchSpeed = s;
        Vector3d bore = new Vector3d(d).mul(s).sub(vp);
        double len = bore.length();
        if (len < 1.0E-9) { return new Vector3d(d); }
        return bore.div(len);
    }

    /** unit direction for a yaw/elevation pair, Minecraft convention (yaw 0 = +Z) */
    /**
     * Скорость вылета и направление ствола для заданного направления вылета,
     * без побочных эффектов.
     *
     * Та же формула, что в boreForLaunch, но не трогает поле скорости: поправка
     * пробует несколько направлений за тик, и телеметрия должна показывать
     * скорость того направления, которое действительно ушло в ствол.
     *
     * @return {bx, by, bz, s}
     */
    @Unique
    private static double[] invfix$launchSolve(Vector3d d, Vector3d vp, double v0) {
        double dvp  = d.dot(vp);
        double disc = dvp * dvp + v0 * v0 - vp.lengthSquared();
        if (disc < 0.0) return new double[] { d.x, d.y, d.z, v0 };
        double sp = dvp + Math.sqrt(disc);
        Vector3d bore = new Vector3d(d).mul(sp).sub(vp);
        double len = bore.length();
        if (len < 1.0E-9) return new double[] { d.x, d.y, d.z, sp };
        bore.div(len);
        return new double[] { bore.x, bore.y, bore.z, sp };
    }

    /**
     * Направление вылета на тик {@code dt} вперёд по опорному решению.
     *
     * Азимут считается точно, от настоящего дульного среза на настоящую цель.
     * Угол места - линейной поправкой от опорного: dEl = cR*dR + cDy*dDy + cS*dS.
     * Срез берётся по стволу, а не по направлению вылета: на ходу они
     * расходятся на угол сноса, и снаряд появляется там, куда смотрит ствол.
     *
     * Скорость корпуса передаётся снаружи, потому что тот же замер нужен и для
     * расчёта ствола ниже: два замера за тик могли бы разойтись.
     *
     * @return {az, el} или null, если поправка вышла за разумные пределы и
     *         верить линейной модели нельзя - тогда держится опорный угол, а Lua
     *         на следующем опросе решит заново
     */
    @Unique
    private double[] invfix$refSolve(Level level, double dt, double[] vHull) {
        double[] r = this.invfix$ref;
        if (r == null) return null;
        double age = (double) (level.getGameTime() - (long) r[6]) + dt;
        double tx = r[0] + r[3] * age;
        double ty = r[1] + r[4] * age;
        double tz = r[2] + r[5] * age;
        Vector3d vp = new Vector3d(vHull[0], vHull[1], vHull[2]);
        double[] piv = this.invfix$pivotPos(this.invfix$geomUp);
        double az = r[7], el = r[8];
        double dR = 0.0, dDy = 0.0, dS = 0.0;
        for (int i = 0; i < 3; i++) {
            double[] b = invfix$launchSolve(invfix$dirOf(az, el), vp, this.invfix$v0);
            double mx = piv[0] + b[0] * this.invfix$geomLen + vHull[0] * dt;
            double my = piv[1] + b[1] * this.invfix$geomLen + vHull[1] * dt;
            double mz = piv[2] + b[2] * this.invfix$geomLen + vHull[2] * dt;
            double dx = tx - mx, dz = tz - mz;
            double range = Math.sqrt(dx * dx + dz * dz);
            if (range < 1.0) return null;
            dR  = range - r[9];
            dDy = (ty - my) - r[10];
            dS  = b[3] - r[11];
            az = Math.toDegrees(Math.atan2(-dx, dz));
            el = r[8] + r[12] * dR + r[13] * dDy + r[14] * dS;
            if (!Double.isFinite(el) || Math.abs(el - r[8]) > 2.0) return null;
        }
        if (dt == 0.0) {
            this.invfix$refState[0] = el - r[8];
            this.invfix$refState[1] = dR;
            this.invfix$refState[2] = dDy;
            this.invfix$refState[3] = dS;
        }
        return new double[] { az, el };
    }

    /**
     * Удержание по опорному решению одним вызовом.
     *
     * Сначала ставится удержание вылета на опорные углы, потом сама опора - и
     * всё это в одном задании серверного потока. Раздельные holdLaunch и
     * опора из Lua легли бы в разные тики, и между ними был бы тик с
     * удержанием без поправки, на котором спуск вполне может открыться.
     */
    @Override
    public void invfix$setLaunchRef(double[] ref) {
        if (ref != null && ref.length >= 15) {
            this.invfix$holdLaunch(ref[7], ref[8]);   // сбрасывает старую опору
            // Не ref.clone(): Mixin не умеет переносить в цель вызов метода у
            // массива - ищет класс "[D", не находит и падает при загрузке.
            // Копия через Arrays делает то же самое обычным статическим вызовом.
            this.invfix$ref = java.util.Arrays.copyOf(ref, ref.length);
        } else {
            this.invfix$ref = null;
        }
        java.util.Arrays.fill(this.invfix$refState, 0.0);
    }

    @Override
    public double[] invfix$launchRefState() {
        return new double[] { this.invfix$ref != null ? 1.0 : 0.0,
                this.invfix$refState[0], this.invfix$refState[1],
                this.invfix$refState[2], this.invfix$refState[3] };
    }

    @Unique
    private static Vector3d invfix$dirOf(double azDeg, double elDeg) {
        double a = Math.toRadians(azDeg), e = Math.toRadians(elDeg);
        double ce = Math.cos(e);
        return new Vector3d(-Math.sin(a) * ce, Math.sin(e), Math.cos(a) * ce);
    }

    @Unique
    private double[] invfix$boreWorldOf(float yawDeg, float pitchDeg) {
        Vector3d local = invfix$dirOf(yawDeg, pitchDeg);
        SubLevel sub = this.invfix$subLevel();
        if (sub != null) sub.logicalPose().orientation().transform(local);
        double az = Math.toDegrees(Math.atan2(-local.x, local.z));
        double el = Math.toDegrees(Math.asin(Mth.clamp(local.y, -1.0, 1.0)));
        return new double[] { az, el };
    }

    @Override
    public double[] invfix$boreWorld() {
        return this.invfix$boreWorldOf(this.cannonYaw, this.cannonPitch);
    }

    /**
     * The direction the SHELL will actually leave along if we fire this tick.
     *
     * CBC spawns the projectile with entity.toGlobalVector(muzzle, 0.0F). A
     * partialTick of 0 resolves to getViewXRot(0) / getViewYRot(0), which are
     * the contraption's prevPitch / prevYaw - and PitchOrientedContraptionEntity
     * copies prev = current at the top of its entity tick, which happens BEFORE
     * block entities tick. So by the time this block entity moves the barrel and
     * pulls the trigger in the same tick, the shell is already committed to the
     * orientation the barrel had at the END OF THE PREVIOUS TICK.
     *
     * invfix$preYaw / prePitch are captured at the head of this tick, so they
     * are exactly that orientation. Aiming decisions have to be made on these,
     * not on the angles we just applied - otherwise the shot carries the whole
     * size of the last slew step as error, and the log cheerfully reports
     * 0.0000 because it is measuring the wrong instant.
     */
    /** {demandYaw, demandPitch, supplyYaw, supplyPitch} in deg/tick. */
    @Override
    public double[] invfix$trackLoad() {
        return new double[] { this.invfix$demandYaw, this.invfix$demandPitch,
                this.invfix$supplyYaw, this.invfix$supplyPitch };
    }

    @Override
    public void invfix$setServo(boolean on) {
        this.invfix$servo = on;
        if (!on) { this.invfix$vYaw = 0.0F; this.invfix$vPitch = 0.0F; this.invfix$aiming = false; }
    }

    @Override public boolean invfix$servoOn() { return this.invfix$servo; }

    @Override
    public void invfix$setDeadband(double deg) {
        this.invfix$deadband = (float) Math.max(0.0, deg);
    }

    @Override public double invfix$deadband() { return this.invfix$deadband; }

    @Override
    public void invfix$setPoseLead(double ticks) { this.invfix$poseLead = ticks; }

    @Override public double invfix$poseLead() { return this.invfix$poseLead; }

    /** Angular speed of the hull itself, deg/tick - not of the barrel. */
    @Override
    public double invfix$hullRate() {
        SubLevel sub = this.invfix$subLevel();
        if (sub == null || !this.invfix$havePose) return 0.0;
        Quaterniond now = new Quaterniond(sub.logicalPose().orientation());
        Quaterniond d = new Quaterniond(this.invfix$prevPose).invert().premul(now);
        double w = Math.min(1.0, Math.abs(d.w));
        return Math.toDegrees(2.0 * Math.acos(w));
    }

    @Override
    public double[] invfix$launchBore() {
        if (this.invfix$exact && this.mountedContraption != null) {
            double[] x = this.invfix$exactBore();
            if (x != null) return x;
        }
        return this.invfix$boreWorldOf(this.invfix$preYaw, this.invfix$prePitch);
    }

    /**
     * Направление ствола в мире, посчитанное сущностью пушки.
     *
     * fireShot берёт направление как разность двух точек, пропущенных через
     * toGlobalVector(..., 0.0F): центра якоря и блока за дульным срезом. Обе
     * лежат на оси ствола, перенос между ними сокращается, и остаётся
     * applyRotation от единичного вектора исходной ориентации - с той же
     * таблицей синусов и теми же float-углами. Длина после поворота табличными
     * синусами не ровно единица, поэтому нормировка, как и у CBC.
     *
     * На саблевеле сущность живёт в координатах плота; в мир направление
     * переводит поза - так же, как Sable поворачивает скорость снаряда при
     * выбросе из плота.
     */
    @Unique
    private double[] invfix$exactBore() {
        Direction dir = this.mountedContraption.getInitialOrientation();
        if (dir == null) return null;
        Vec3 p = this.mountedContraption.applyRotation(
                new Vec3(dir.getStepX(), dir.getStepY(), dir.getStepZ()), 0.0F);
        double len = p.length();
        if (!(len > 1.0E-9)) return null;
        Vector3d local = new Vector3d(p.x / len, p.y / len, p.z / len);
        SubLevel sub = this.invfix$subLevel();
        if (sub != null) sub.logicalPose().orientation().transform(local);
        return new double[] {
                Math.toDegrees(Math.atan2(-local.x, local.z)),
                Math.toDegrees(Math.asin(Mth.clamp(local.y, -1.0, 1.0))) };
    }

    @Override
    public void invfix$aimWorld(double azDeg, double elDeg) {
        Vector3d want = invfix$dirOf(azDeg, elDeg);
        SubLevel sub = this.invfix$subLevel();
        // rotate the desired world direction back into hull space
        if (sub != null) sub.logicalPose().orientation().transformInverse(want);
        double yaw = Math.toDegrees(Math.atan2(-want.x, want.z));
        double pitch = Math.toDegrees(Math.asin(Mth.clamp(want.y, -1.0, 1.0)));
        this.invfix$setTargetYaw((float) yaw);
        this.invfix$setTargetPitch((float) pitch);
    }

    @Override
    public void invfix$holdWorld(Double azDeg, Double elDeg) {
        this.invfix$launchMode = false;
        // Новое удержание - новая опора. Старая относилась к другому решению, и
        // применять её поправки к чужим углам нельзя. holdLaunch зовёт сюда же,
        // так что Lua отдаёт опору после него.
        this.invfix$ref = null;
        this.invfix$holdAz = azDeg;
        this.invfix$holdEl = elDeg;
        if (azDeg == null || elDeg == null) {
            this.invfix$clearTargets();
        } else {
            this.invfix$aiming = true;
            this.invfix$sync();
        }
    }

    /**
     * Hold so the SHELL leaves along this direction, hull motion included.
     * Same arguments as holdWorld, different meaning: holdWorld points the
     * barrel there, holdLaunch points the shell there.
     */
    @Override
    public void invfix$holdLaunch(Double azDeg, Double elDeg) {
        this.invfix$holdWorld(azDeg, elDeg);
        this.invfix$launchMode = (azDeg != null && elDeg != null);
    }

    @Override
    public void invfix$setBallistics(double v0, double pivotUp, double barrelLen) {
        if (v0 > 0.0) this.invfix$v0 = v0;
        this.invfix$geomUp  = pivotUp;
        this.invfix$geomLen = barrelLen;
    }

    /** Launch speed the last solve implies: |V0*bore + hullVelocity|. */
    @Override
    public double invfix$launchSpeed() {
        return this.invfix$launchSpeed > 0.0 ? this.invfix$launchSpeed : this.invfix$v0;
    }

    @Override
    public boolean invfix$isHoldingWorld() {
        return this.invfix$holdAz != null && this.invfix$holdEl != null;
    }

    @Override
    public double[] invfix$worldError() {
        if (!this.invfix$isHoldingWorld()) return new double[] { 0.0, 0.0 };
        double[] now = this.invfix$boreWorld();
        double dAz = ((now[0] - this.invfix$holdAz + 540.0) % 360.0) - 180.0;
        return new double[] { dAz, now[1] - this.invfix$holdEl };
    }

    /**
     * Error of what the SHELL will actually do, not of where the barrel points.
     *
     * In launch mode that is the direction of V0*bore + hullVelocity, evaluated
     * with the bore from the previous tick (the one CBC hands the projectile)
     * and the hull velocity as of now. Those are the two things the shell is
     * built from, so this is the only error worth gating the trigger on.
     */
    @Override
    public double[] invfix$launchError() {
        if (!this.invfix$isHoldingWorld()) return new double[] { 0.0, 0.0 };
        // Вызов из Lua, а не из тика: отдать точную ошибку последнего
        // взведённого тика, если она свежая. Сама сущность в этот момент может
        // стоять уже на новых углах, и спрашивать её отсюда бессмысленно.
        if (!this.invfix$inTick && !this.invfix$exact && this.invfix$xErr != null) {
            Level lvl = ((CannonMountBlockEntity) (Object) this).getLevel();
            if (lvl != null && lvl.getGameTime() - this.invfix$xErrTick <= 1L) {
                return new double[] { this.invfix$xErr[0], this.invfix$xErr[1] };
            }
        }
        double az, el;
        if (this.invfix$launchMode) {
            double[] t = this.invfix$launchVector();
            az = t[0];
            el = t[1];
        } else {
            double[] b = this.invfix$launchBore();
            az = b[0];
            el = b[1];
        }
        double dAz = ((az - this.invfix$holdAz + 540.0) % 360.0) - 180.0;
        return new double[] { dAz, el - this.invfix$holdEl };
    }

    /** {az, elev, speed} of V0*bore(prev tick) + hullVelocity. */
    /**
     * Firing gate as an ellipse, degrees per axis. Pass the tolerance that each
     * axis is worth the same miss in blocks, and the trigger stops being tighter
     * than it needs to be on one axis and looser than it should be on the other.
     * Zero on either axis falls back to the scalar tolerance.
     */
    @Override
    public void invfix$setFireTolAxes(double tolAz, double tolEl) {
        this.invfix$fireTolAz = Math.max(0.0, tolAz);
        this.invfix$fireTolEl = Math.max(0.0, tolEl);
    }

    @Override
    public double[] invfix$launchVector() {
        double[] b = this.invfix$launchBore();
        Vector3d dir = invfix$dirOf(b[0], b[1]).mul(this.invfix$v0);
        double[] v = this.invfix$hullVelocity();
        dir.add(v[0], v[1], v[2]);
        double sp = dir.length();
        if (sp < 1.0E-9) return new double[] { b[0], b[1], 0.0 };
        return new double[] {
                Math.toDegrees(Math.atan2(-dir.x, dir.z)),
                Math.toDegrees(Math.asin(Mth.clamp(dir.y / sp, -1.0, 1.0))),
                sp };
    }

    @Override
    public void invfix$armAutoFire(double tolDeg, int timeoutTicks) {
        this.invfix$fireTol = Math.max(0.0, tolDeg);
        this.invfix$fireTicks = Math.max(0, timeoutTicks);
        this.invfix$fireState = this.invfix$fireTicks > 0 ? 1 : 0;
    }

    @Override public boolean invfix$isArmed() { return this.invfix$fireTicks > 0; }

    @Override public int invfix$autoFireState() { return this.invfix$fireState; }

    @Override public double invfix$errorRate() { return this.invfix$lastRate; }

    @Override
    public void invfix$setFireLead(double ticks) {
        this.invfix$fireLead = Math.max(0.0, Math.min(20.0, ticks));
    }

    @Override public double invfix$fireLead() { return this.invfix$fireLead; }

    @Override
    public double[] invfix$lastShot() {
        // NOTE: no array .clone() here. Mixin's transformer chokes on the
        // synthetic INVOKEVIRTUAL [D::clone()Ljava/lang/Object; and dies with
        // an NPE while applying the class, which takes the whole mod load with
        // it (the visible symptom was an unrelated "Sodium mod config not
        // found" further down the startup chain).
        double[] v = this.invfix$shotLog;
        return new double[] { v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8],
                v[9], v[10], v[11] };
    }

    @Override
    public boolean invfix$fire() {
        CannonMountBlockEntity self = (CannonMountBlockEntity) (Object) this;
        Level level = self.getLevel();
        if (level == null || level.isClientSide || this.mountedContraption == null) return false;
        // same path a redstone rising edge takes
        self.onRedstoneUpdate(false, false, true, false, 15);
        self.onRedstoneUpdate(false, false, false, true, 0);
        return true;
    }

    @Override
    public double[] invfix$pivotPos(double up) {
        CannonMountBlockEntity self = (CannonMountBlockEntity) (Object) this;
        Vector3d local = new Vector3d(0.0, up, 0.0);
        SubLevel sub = this.invfix$subLevel();
        if (sub != null) sub.logicalPose().orientation().transform(local);
        double[] base = this.invfix$worldPos();
        return new double[] { base[0] + local.x, base[1] + local.y, base[2] + local.z };
    }

    @Override
    public double invfix$hullYaw() {
        SubLevel sub = this.invfix$subLevel();
        if (sub == null) return 0.0;
        // orientation() hands back the read-only view, not Quaterniond
        Quaterniondc rot = sub.logicalPose().orientation();
        // Hull forward is local +Z: cannonYaw starts at HORIZONTAL_FACING.toYRot()
        // and Minecraft yaw 0 points at +Z, so the mount's zero is that axis.
        Vector3d fwd = rot.transform(new Vector3d(0.0, 0.0, 1.0));
        return Math.toDegrees(Math.atan2(-fwd.x, fwd.z));
    }

    // ---- persistence ----

    @Inject(method = "write", at = @At("TAIL"), require = 0)
    private void invfix$write(CompoundTag tag, HolderLookup.Provider registry,
                              boolean clientPacket, CallbackInfo ci) {
        if (this.invfix$targetYaw != null)   tag.putFloat("invfixTargetYaw", this.invfix$targetYaw);
        if (this.invfix$targetPitch != null) tag.putFloat("invfixTargetPitch", this.invfix$targetPitch);
        tag.putFloat("invfixSlewRate", this.invfix$slewRate);
        tag.putFloat("invfixRamp", this.invfix$rampTicks);
        tag.putDouble("invfixLead", this.invfix$fireLead);
        tag.putBoolean("invfixHold", this.invfix$hold);
        tag.putBoolean("invfixOwned", this.invfix$computers > 0 && this.invfix$hold);
    }

    @Inject(method = "read", at = @At("TAIL"), require = 0)
    private void invfix$read(CompoundTag tag, HolderLookup.Provider registry,
                             boolean clientPacket, CallbackInfo ci) {
        this.invfix$targetYaw   = tag.contains("invfixTargetYaw")   ? tag.getFloat("invfixTargetYaw")   : null;
        this.invfix$targetPitch = tag.contains("invfixTargetPitch") ? tag.getFloat("invfixTargetPitch") : null;
        if (tag.contains("invfixSlewRate")) this.invfix$slewRate = tag.getFloat("invfixSlewRate");
        if (tag.contains("invfixRamp"))     this.invfix$rampTicks = tag.getFloat("invfixRamp");
        if (tag.contains("invfixLead"))     this.invfix$fireLead = tag.getDouble("invfixLead");
        if (tag.contains("invfixHold"))     this.invfix$hold = tag.getBoolean("invfixHold");
        this.invfix$syncedOwned = tag.getBoolean("invfixOwned");
    }
}