package com.invfix.mixin.cbc;

import net.createmod.catnip.math.VecHelper;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rbasamoyai.createbigcannons.cannon_control.contraption.PitchOrientedContraptionEntity;

/**
 * Поворот ствола пушки без таблицы синусов.
 *
 * CBC поворачивает всё, что относится к установленной пушке, через
 * VecHelper.rotate из catnip, а тот берёт синус и косинус из ванильной таблицы
 * Mth: 65536 значений на круг, шаг 0.0055 градуса, индекс отбрасыванием дробной
 * части. Направление, по которому MountedMediumcannonContraption выпускает
 * снаряд, строится этим же поворотом. Значит, ствол физически мог смотреть
 * только в узлы сетки с шагом 0.0055 градуса по азимуту и по углу места, как бы
 * точно маунт ни выставлял угол. На навесе около четырёх тысяч блоков один шаг
 * по углу места - полтора блока, по азимуту на пятнадцати тысячах - тоже
 * полтора. Никакая скорость доворота этого не лечит: это не отставание, а
 * разрешение самого поворота.
 *
 * Здесь те же три поворота, в том же порядке, по тем же осям и формулам, что в
 * VecHelper.rotate, только угол не сжимается во float и синус с косинусом
 * считаются честно. Дальше точность ограничена float-углами самой сущности:
 * около 1e-5 градуса, тысячные доли блока на максимальной дальности.
 *
 * Меняется и applyRotation, и обратный ему reverseRotation, и на обеих сторонах:
 * столкновения, посадочные места и выстрел считаются согласованно, как и
 * раньше, просто без ступенек.
 */
@Mixin(value = PitchOrientedContraptionEntity.class, remap = false)
public abstract class CannonExactRotationMixin {

    @Redirect(method = { "applyRotation", "reverseRotation" },
            at = @At(value = "INVOKE",
                    target = "Lnet/createmod/catnip/math/VecHelper;rotate(Lnet/minecraft/world/phys/Vec3;DLnet/minecraft/core/Direction$Axis;)Lnet/minecraft/world/phys/Vec3;"))
    private Vec3 invfix$exactRotate(Vec3 vec, double deg, Direction.Axis axis) {
        // те же ранние выходы, что у VecHelper.rotate
        if (deg == 0.0) return vec;
        if (vec == Vec3.ZERO) return vec;
        double angle = deg / 180.0 * Math.PI;
        double sin = Math.sin(angle);
        double cos = Math.cos(angle);
        double x = vec.x, y = vec.y, z = vec.z;
        if (axis == Direction.Axis.X) {
            return new Vec3(x, y * cos - z * sin, z * cos + y * sin);
        } else if (axis == Direction.Axis.Y) {
            return new Vec3(x * cos + z * sin, y, z * cos - x * sin);
        } else if (axis == Direction.Axis.Z) {
            return new Vec3(x * cos - y * sin, y * cos + x * sin, z);
        }
        return vec;
    }
}