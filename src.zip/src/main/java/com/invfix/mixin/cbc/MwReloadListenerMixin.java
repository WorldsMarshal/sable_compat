package com.invfix.mixin.cbc;

import java.util.function.BiConsumer;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.material.MediumcannonMaterialPropertiesHandler;
import riftyboi.cbcmodernwarfare.cannons.munitions_contraption_launcher.material.MunitionsLauncherMaterialPropertiesHandler;
import riftyboi.cbcmodernwarfare.cannons.rotarycannon.material.RotarycannonMaterialPropertiesHandler;
import riftyboi.cbcmodernwarfare.content.CBCModernWarfareCommonEvents;

/**
 * Registers the three cannon-material reload listeners CBC Modern Warfare
 * forgot to hook up.
 *
 * MediumcannonMaterialPropertiesHandler.ReloadListener (and the rotarycannon /
 * munitions-launcher equivalents) exist and are fully written, but
 * CBCModernWarfareCommonEvents#onAddReloadListeners only ever registers the
 * projectile handler:
 *
 *     cons.accept(ReloadListenerProjectiles.INSTANCE, ...("projectile_properties_handler"));
 *
 * So nothing reads data/<ns>/mediumcannon_materials/, MediumcannonMaterial#properties()
 * never finds a datapack entry, and the hardcoded defaults always win - which
 * is why nethersteel stays unweldable no matter what a datapack says.
 *
 * With this in place the folders below become live and all cannon material
 * stats (barrel length, velocity, spread, recoil, is_weldable,
 * connects_in_survival, weld costs) are datapack-driven as intended:
 *
 *     data/<namespace>/mediumcannon_materials/<material>.json
 *     data/<namespace>/rotarycannon_materials/<material>.json
 *     data/<namespace>/munitions_launcher_types/<type>.json
 */
@Mixin(value = CBCModernWarfareCommonEvents.class, remap = false)
public abstract class MwReloadListenerMixin {

    @Inject(method = "onAddReloadListeners", at = @At("TAIL"), require = 0)
    private static void invfix$addMissingMaterialListeners(BiConsumer cons, CallbackInfo ci) {
        cons.accept(MediumcannonMaterialPropertiesHandler.ReloadListener.INSTANCE,
                ResourceLocation.fromNamespaceAndPath("sable_compat", "mediumcannon_materials_handler"));
        cons.accept(RotarycannonMaterialPropertiesHandler.ReloadListener.INSTANCE,
                ResourceLocation.fromNamespaceAndPath("sable_compat", "rotarycannon_materials_handler"));
        cons.accept(MunitionsLauncherMaterialPropertiesHandler.ReloadListener.INSTANCE,
                ResourceLocation.fromNamespaceAndPath("sable_compat", "munitions_launcher_types_handler"));
    }
}