package com.invfix.mixin.cbc;

import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rbasamoyai.createbigcannons.base.CBCRegistries;
import rbasamoyai.createbigcannons.crafting.casting.CannonCastMouldBlock;
import rbasamoyai.createbigcannons.crafting.casting.CannonCastShape;

/**
 * Fixes copy-paste errors in CBC Modern Warfare's cast mould registration.
 *
 * CBCModernWarfareBlocks hands three of its four moulds the wrong cast shape:
 *
 *   MEDIUMCANNON_BARREL_CAST_MOULD  -> MEDIUMCANNON_BREECH         (wrong)
 *   ROTARYCANNON_BREECH_CAST_MOULD  -> MEDIUMCANNON_BREECH         (wrong)
 *   ROTARYCANNON_BARREL_CAST_MOULD  -> MEDIUMCANNON_BREECH         (wrong)
 *   ROTARYCANNON_BEARING_CAST_MOULD -> MEDIUMCANNON_RECOIL_BARREL  (wrong)
 *
 * so pouring metal into a barrel mould yields a breech and the barrel cannot
 * be obtained at all. The shape is picked in code when the cast is built, so
 * no datapack can correct it.
 *
 * Rather than mutate the final field, we intercept the two places the block
 * reads its shape and substitute the one matching the mould's own registry
 * name. Moulds that are already correct pass through untouched, and any mould
 * we do not recognise (including CBC's own) is left alone.
 */
@Mixin(value = CannonCastMouldBlock.class, remap = false)
public abstract class CastMouldShapeMixin {

    /** mould registry path (minus the _cast_mould suffix) -> expected shape id */
    @Unique
    private static final Map<String, String> INVFIX_EXPECTED = Map.of(
            "mediumcannon_barrel",        "mediumcannon_barrel",
            "mediumcannon_breech",        "mediumcannon_breech",
            "mediumcannon_recoil_barrel", "mediumcannon_recoil_barrel",
            "rotarycannon_barrel",        "rotarycannon_barrel",
            "rotarycannon_breech",        "rotarycannon_breech",
            "rotarycannon_bearing",       "rotarycannon_bearing");

    @Unique
    private Object invfix$correctShape(Supplier<?> original) {
        Object fallback = original == null ? null : original.get();

        ResourceLocation id = BuiltInRegistries.BLOCK.getKey((Block) (Object) this);
        if (id == null || !"cbcmodernwarfare".equals(id.getNamespace())) return fallback;

        String path = id.getPath();
        if (!path.endsWith("_cast_mould")) return fallback;
        String base = path.substring(0, path.length() - "_cast_mould".length());

        String wantId = INVFIX_EXPECTED.get(base);
        if (wantId == null) return fallback;

        try {
            // MW registers its shapes under the createbigcannons namespace
            Registry<CannonCastShape> reg = CBCRegistries.cannonCastShapes();
            CannonCastShape want = reg.get(
                    ResourceLocation.fromNamespaceAndPath("createbigcannons", wantId));
            return want != null ? want : fallback;
        } catch (Throwable ignored) {
            return fallback;
        }
    }

    @Redirect(
            method = "useWithoutItem",
            at = @At(value = "INVOKE", target = "Ljava/util/function/Supplier;get()Ljava/lang/Object;"),
            require = 0)
    private Object invfix$fixShapeOnUse(Supplier<?> original) {
        return invfix$correctShape(original);
    }

    @Redirect(
            method = "useItemOn",
            at = @At(value = "INVOKE", target = "Ljava/util/function/Supplier;get()Ljava/lang/Object;"),
            require = 0)
    private Object invfix$fixShapeOnUseItem(Supplier<?> original) {
        return invfix$correctShape(original);
    }
}