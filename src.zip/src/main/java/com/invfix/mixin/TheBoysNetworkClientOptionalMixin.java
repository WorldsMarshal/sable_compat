package com.invfix.mixin;

import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.DirectionalPayloadHandler;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.benniao.theboysmod.network.BloodBurstPacket;
import net.benniao.theboysmod.network.DetachPartPacket;
import net.benniao.theboysmod.network.DossierUnlockSyncPacket;
import net.benniao.theboysmod.network.EntityAnimationPlaySyncPacket;
import net.benniao.theboysmod.network.FireTimerSyncPacket;
import net.benniao.theboysmod.network.FleshRegenSyncPacket;
import net.benniao.theboysmod.network.FleshStrengthSyncPacket;
import net.benniao.theboysmod.network.FlightPosePacket;
import net.benniao.theboysmod.network.FlightPoseSyncPacket;
import net.benniao.theboysmod.network.FlightTogglePacket;
import net.benniao.theboysmod.network.GrabPacket;
import net.benniao.theboysmod.network.GrabSyncPacket;
import net.benniao.theboysmod.network.InjectVPacket;
import net.benniao.theboysmod.network.LaserEyeHitPosSyncPacket;
import net.benniao.theboysmod.network.NpcSupportRequestPacket;
import net.benniao.theboysmod.network.NpcSupportSyncPacket;
import net.benniao.theboysmod.network.OpenSupeDialoguePacket;
import net.benniao.theboysmod.network.PhoneBatterySyncPacket;
import net.benniao.theboysmod.network.PhoneEvidenceCapturePacket;
import net.benniao.theboysmod.network.PhoneEvidenceReportPacket;
import net.benniao.theboysmod.network.PhoneEvidenceReportResultPacket;
import net.benniao.theboysmod.network.PhoneEvidenceSyncPacket;
import net.benniao.theboysmod.network.PhoneNewsSyncPacket;
import net.benniao.theboysmod.network.PhonePowerDrainPacket;
import net.benniao.theboysmod.network.PhoneShopActionPacket;
import net.benniao.theboysmod.network.PhoneShopSyncPacket;
import net.benniao.theboysmod.network.PhoneSmsActionPacket;
import net.benniao.theboysmod.network.PhoneSmsImageDownloadPacket;
import net.benniao.theboysmod.network.PhoneSmsSyncPacket;
import net.benniao.theboysmod.network.PlayerAnimationPlaySyncPacket;
import net.benniao.theboysmod.network.PlayerAnimationStopSyncPacket;
import net.benniao.theboysmod.network.ScaleSetPacket;
import net.benniao.theboysmod.network.SkillActiveSyncPacket;
import net.benniao.theboysmod.network.SkillDamageAdjustPacket;
import net.benniao.theboysmod.network.SkillSetActivePacket;
import net.benniao.theboysmod.network.SkillSyncPacket;
import net.benniao.theboysmod.network.SkillTogglePacket;
import net.benniao.theboysmod.network.SpeedAdjustPacket;
import net.benniao.theboysmod.network.SupeDialogueChoicePacket;
import net.benniao.theboysmod.network.SupeDialogueStatePacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/*
 * CLIENT: перерегистрируем все каналы The Boys как OPTIONAL.
 * Тогда при коннекте к выделенному серверу, у которого отсутствуют clientbound-каналы The Boys,
 * негоциация не падает (optional-каналы не требуют наличия на сервере). Хендлеры настоящие —
 * на клиенте классы пакетов грузятся нормально, приём пакетов работает.
 */
@Mixin(value = net.benniao.theboysmod.network.ModNetworking.class, remap = false)
public abstract class TheBoysNetworkClientOptionalMixin {

    @Inject(method = "register", at = @At("HEAD"), cancellable = true, remap = false)
    private static void invfix_clientOptionalRegister(RegisterPayloadHandlersEvent event, CallbackInfo ci) {
        PayloadRegistrar registrar = event.registrar("theboysmod").optional();
        registrar.playToClient(FleshRegenSyncPacket.TYPE, FleshRegenSyncPacket.STREAM_CODEC, FleshRegenSyncPacket::handle);
        registrar.playToServer(DetachPartPacket.TYPE, DetachPartPacket.STREAM_CODEC, DetachPartPacket::handle);
        registrar.playToServer(BloodBurstPacket.TYPE, BloodBurstPacket.STREAM_CODEC, BloodBurstPacket::handle);
        registrar.playToClient(PlayerAnimationPlaySyncPacket.TYPE, PlayerAnimationPlaySyncPacket.STREAM_CODEC, PlayerAnimationPlaySyncPacket::handleClient);
        registrar.playToClient(EntityAnimationPlaySyncPacket.TYPE, EntityAnimationPlaySyncPacket.STREAM_CODEC, EntityAnimationPlaySyncPacket::handleClient);
        registrar.playToClient(PlayerAnimationStopSyncPacket.TYPE, PlayerAnimationStopSyncPacket.STREAM_CODEC, PlayerAnimationStopSyncPacket::handleClient);
        registrar.playToClient(SkillSyncPacket.TYPE, SkillSyncPacket.STREAM_CODEC, SkillSyncPacket::handle);
        registrar.playToServer(SkillTogglePacket.TYPE, SkillTogglePacket.STREAM_CODEC, SkillTogglePacket::handle);
        registrar.playToServer(SkillSetActivePacket.TYPE, SkillSetActivePacket.STREAM_CODEC, SkillSetActivePacket::handle);
        registrar.playToClient(SkillActiveSyncPacket.TYPE, SkillActiveSyncPacket.STREAM_CODEC, SkillActiveSyncPacket::handle);
        registrar.playToServer(FlightTogglePacket.TYPE, FlightTogglePacket.STREAM_CODEC, FlightTogglePacket::handle);
        registrar.playToServer(FlightPosePacket.TYPE, FlightPosePacket.STREAM_CODEC, FlightPosePacket::handle);
        registrar.playToClient(FlightPoseSyncPacket.TYPE, FlightPoseSyncPacket.STREAM_CODEC, FlightPoseSyncPacket::handle);
        registrar.playToServer(SkillDamageAdjustPacket.TYPE, SkillDamageAdjustPacket.STREAM_CODEC, SkillDamageAdjustPacket::handle);
        registrar.playBidirectional(LaserEyeHitPosSyncPacket.TYPE, LaserEyeHitPosSyncPacket.STREAM_CODEC, new DirectionalPayloadHandler<LaserEyeHitPosSyncPacket>(LaserEyeHitPosSyncPacket::handleClient, LaserEyeHitPosSyncPacket::handleServer));
        registrar.playToClient(FleshStrengthSyncPacket.TYPE, FleshStrengthSyncPacket.STREAM_CODEC, FleshStrengthSyncPacket::handle);
        registrar.playToServer(GrabPacket.TYPE, GrabPacket.STREAM_CODEC, GrabPacket::handle);
        registrar.playToClient(GrabSyncPacket.TYPE, GrabSyncPacket.STREAM_CODEC, GrabSyncPacket::handleClient);
        registrar.playToServer(SpeedAdjustPacket.TYPE, SpeedAdjustPacket.STREAM_CODEC, SpeedAdjustPacket::handle);
        registrar.playToServer(ScaleSetPacket.TYPE, ScaleSetPacket.STREAM_CODEC, ScaleSetPacket::handle);
        registrar.playToServer(InjectVPacket.TYPE, InjectVPacket.STREAM_CODEC, InjectVPacket::handle);
        registrar.playToClient(FireTimerSyncPacket.TYPE, FireTimerSyncPacket.STREAM_CODEC, FireTimerSyncPacket::handle);
        registrar.playToServer(PhoneSmsActionPacket.TYPE, PhoneSmsActionPacket.STREAM_CODEC, PhoneSmsActionPacket::handle);
        registrar.playToClient(PhoneSmsSyncPacket.TYPE, PhoneSmsSyncPacket.STREAM_CODEC, PhoneSmsSyncPacket::handle);
        registrar.playToClient(PhoneSmsImageDownloadPacket.TYPE, PhoneSmsImageDownloadPacket.STREAM_CODEC, PhoneSmsImageDownloadPacket::handle);
        registrar.playToServer(NpcSupportRequestPacket.TYPE, NpcSupportRequestPacket.STREAM_CODEC, NpcSupportRequestPacket::handle);
        registrar.playToServer(SupeDialogueStatePacket.TYPE, SupeDialogueStatePacket.STREAM_CODEC, SupeDialogueStatePacket::handle);
        registrar.playToServer(SupeDialogueChoicePacket.TYPE, SupeDialogueChoicePacket.STREAM_CODEC, SupeDialogueChoicePacket::handle);
        registrar.playToClient(OpenSupeDialoguePacket.TYPE, OpenSupeDialoguePacket.STREAM_CODEC, OpenSupeDialoguePacket::handle);
        registrar.playToClient(NpcSupportSyncPacket.TYPE, NpcSupportSyncPacket.STREAM_CODEC, NpcSupportSyncPacket::handle);
        registrar.playToServer(PhoneEvidenceCapturePacket.TYPE, PhoneEvidenceCapturePacket.STREAM_CODEC, PhoneEvidenceCapturePacket::handle);
        registrar.playToClient(PhoneEvidenceSyncPacket.TYPE, PhoneEvidenceSyncPacket.STREAM_CODEC, PhoneEvidenceSyncPacket::handle);
        registrar.playToServer(PhoneEvidenceReportPacket.TYPE, PhoneEvidenceReportPacket.STREAM_CODEC, PhoneEvidenceReportPacket::handle);
        registrar.playToClient(PhoneBatterySyncPacket.TYPE, PhoneBatterySyncPacket.STREAM_CODEC, PhoneBatterySyncPacket::handle);
        registrar.playToServer(PhonePowerDrainPacket.TYPE, PhonePowerDrainPacket.STREAM_CODEC, PhonePowerDrainPacket::handle);
        registrar.playToClient(PhoneEvidenceReportResultPacket.TYPE, PhoneEvidenceReportResultPacket.STREAM_CODEC, PhoneEvidenceReportResultPacket::handle);
        registrar.playToClient(PhoneNewsSyncPacket.TYPE, PhoneNewsSyncPacket.STREAM_CODEC, PhoneNewsSyncPacket::handle);
        registrar.playToServer(PhoneShopActionPacket.TYPE, PhoneShopActionPacket.STREAM_CODEC, PhoneShopActionPacket::handle);
        registrar.playToClient(PhoneShopSyncPacket.TYPE, PhoneShopSyncPacket.STREAM_CODEC, PhoneShopSyncPacket::handle);
        registrar.playToClient(DossierUnlockSyncPacket.TYPE, DossierUnlockSyncPacket.STREAM_CODEC, DossierUnlockSyncPacket::handle);
        ci.cancel();
    }
}