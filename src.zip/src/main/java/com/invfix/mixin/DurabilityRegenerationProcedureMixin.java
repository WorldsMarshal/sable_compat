package com.invfix.mixin;

import net.mcreator.invincibleinc.init.InvincibleIncModMobEffects;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Патч DurabilityRegenerationProcedure — реген щита больше не останавливается боем.
 *
 * Отличия от оригинала:
 *  • Накопление тика (DamageReductionRegenTick) идёт ВСЕГДА, пока щит не полон
 *    (DamageTolerance < DTstat). Эффект IN_COMBAT больше НЕ обнуляет прогресс.
 *  • Когда тик добивает до TimeMax и происходит долив:
 *      – если в этот момент висит IN_COMBAT → доливается 10% обычного объёма;
 *      – если боя нет → доливается полный обычный объём.
 *  Базовый объём долива сохранён из оригинала: currentDura * 0.5 * 0.2.
 */
@Mixin(value = net.mcreator.invincibleinc.procedures.DurabilityRegenerationProcedure.class, remap = false)
public class DurabilityRegenerationProcedureMixin {

    /** Доля обычного долива, действующая во время эффекта «в бою». */
    private static final double IN_COMBAT_REGEN_FACTOR = 0.2;

    @Inject(
            method = "execute(Lnet/minecraft/world/level/LevelAccessor;" +
                    "Lnet/minecraft/world/entity/Entity;)V",
            at = @At("HEAD"),
            cancellable = true,
            remap = false
    )
    private static void invfix_combatAwareRegen(
            LevelAccessor world, Entity entity, CallbackInfo ci) {

        ci.cancel();

        if (entity == null) return;
        if (world.isClientSide()) return;

        InvincibleIncModVariables.PlayerVariables vars;
        try {
            vars = entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        } catch (Exception ignored) {
            return;
        }

        boolean inCombat = entity instanceof LivingEntity le
                && le.hasEffect(InvincibleIncModMobEffects.IN_COMBAT);

        // ── Накопление тика: только по «щит не полон», бой больше не сбрасывает ──
        if (vars.DamageTolerance < vars.DTstat) {
            vars.DamageReductionRegenTick += vars.DamageReductionRegenNumber;
        } else {
            vars.DamageReductionRegenTick = 0.0;
        }
        vars.markSyncDirty();

        // ── Долив при срабатывании таймера ──
        if (vars.DamageReductionRegenTick >= vars.DamageReductionRegenTimeMax) {
            double restore = vars.currentDura * 0.5 * 0.2;   // базовый объём оригинала
            if (inCombat) {
                restore *= IN_COMBAT_REGEN_FACTOR;           // в бою — 10%
            }
            vars.DamageTolerance = Math.min(vars.DTstat, vars.DamageTolerance + restore);
            vars.DamageReductionRegenTick = 0.0;
            vars.markSyncDirty();
        }

        // ── Инвариант blockHealth из оригинала (потолок 50) ──
        if (vars.blockHealth >= 50.0) {
            vars.blockHealth = 50.0;
            vars.markSyncDirty();
        }
    }
}