package com.invfix.mixin;

import com.invfix.theboyscompat.SyringeRaceRule;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Единый бэкстоп на саму инъекцию: {@code InjectVPacket.injectTarget} — общая точка
 * для self-use, инъекции ударом и клика по блоку (последний минует useOn, поэтому
 * без этого перехвата нечеловеческая раса смогла бы вколоть себе V кликом по блоку).
 *
 * Проверяется ДНК ПОЛУЧАТЕЛЯ (target). Если ему нельзя V — инъекция и расход шприца
 * отменяются (возврат false до shrink), инъектору шлётся то же сообщение.
 *
 * @Pseudo + require=0 + гейт в InvincibleIncMixinTransformer → без The Boys не применяется.
 */
@Pseudo
@Mixin(targets = "net.benniao.theboysmod.network.InjectVPacket", remap = false)
public class InjectVRaceGateMixin {

    @Inject(method = "injectTarget", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void invfix_gateInject(ServerPlayer injector, ServerPlayer target,
                                          String syringeType, ItemStack syringeStack,
                                          CallbackInfoReturnable<Boolean> cir) {
        String msg = SyringeRaceRule.blockMessage(target, syringeStack);
        if (msg != null) {
            if (injector != null) injector.displayClientMessage(Component.literal(msg), true);
            cir.setReturnValue(false);
        }
    }
}
