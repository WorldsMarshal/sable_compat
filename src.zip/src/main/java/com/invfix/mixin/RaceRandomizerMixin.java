package com.invfix.mixin;

import com.invfix.humanlike.HumanLikeRaces;
import com.invfix.util.DebugUtils;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.random.RandomGenerator;
import java.util.random.RandomGeneratorFactory;


@Mixin(value = net.mcreator.invincibleinc.procedures.RaceRanomizerItemProcedure.class, remap = false)
public class RaceRandomizerMixin {

    @Inject(
            method = "execute(Lnet/minecraft/world/entity/Entity;)V",
            at = @At("HEAD"),
            cancellable = true,
            remap = false
    )
    private static void invfix_replaceRaceRandomizer(Entity entity, CallbackInfo ci) {
        ci.cancel();
        if (entity == null) return;
        if (DebugUtils.tryApply(entity)) return;

        long seed = System.nanoTime() ^ (entity.getId() * 0x9E3779B97F4A7C15L);
        RandomGenerator rng = RandomGeneratorFactory.of("SplittableRandom").create(seed);

        String race = rollRace(rng);

        InvincibleIncModVariables.PlayerVariables vars =
                entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        vars.Race = race;
        vars.markSyncDirty();
    }

    /**
     * Бросок расы, от самой редкой к самой частой.
     *
     * Броски идут цепочкой и каждый независим: {@code nextInt(N)} даёт число от
     * нуля до N-1, так что условие {@code == 0} проходит с вероятностью 1/N.
     * Но это вероятность ДОЙТИ до строки и пройти её, а не итоговый шанс расы:
     * до каждой следующей строки доживает только то, что не выпало раньше.
     * Поэтому число в скобках и процент в комментарии - разные величины, и
     * пересчитывать одно в другое на глаз не стоит.
     *
     * Итог по цепочке:
     *
     *     Alien(Metroman)      0.00020%
     *     Viltrumite           0.00100%
     *     Beast                0.00100%
     *     Unopan               0.00500%
     *     Human-Viltrumite     0.00600%
     *     Thraxan-Viltrumite   0.01000%
     *     Born for V           2.00000%
     *     Predisposition      19.59545%
     *     Human               78.38181%
     *
     * Predisposition выходит 19.6, а не ровно двадцать: его бросок идёт после
     * отсева Born for V, и целым делителем круглая двадцатка там не берётся.
     * Ближайшее целое даёт 19.6 - если однажды понадобится ровно 20, бросок
     * придётся считать порогом, а не делителем.
     *
     * И ещё одно, на чём тут уже обжигались: {@code nextInt(1)} всегда
     * возвращает ноль. Единица в скобках - это не «половина», это «всегда», и
     * всё, что стоит ниже такой строки, становится недостижимым.
     */
    private static String rollRace(RandomGenerator rng) {

        // ── Редкие расы ────────────────────────────────────────────────────
        // Alien(Metroman) — в пять раз реже Вильтрумита
        if (rng.nextInt(500000) == 0) return "§1§lAlien(Metroman)";
        if (rng.nextInt(100000) == 0) return "§4§lViltrumite";
        if (rng.nextInt(100000) == 0) return "§4§lBeast";
        if (rng.nextInt(20000) == 0) return "§6§lUnopan";
        if (rng.nextInt(16670) == 0) return "§f§lHuman-Viltrumite";
        if (rng.nextInt(10000) == 0) return "§1§lThraxan-Viltrumite";

        // ── Человеческий tier ──────────────────────────────────────────────
        // Human(Born for V) — 2.000% (зелёный)
        if (rng.nextInt(50) == 0) return HumanLikeRaces.BORN_FOR_V;
        // Human(Predisposition to V) — 19.595% (жёлтый)
        if (rng.nextInt(5) == 0)  return HumanLikeRaces.PREDISPOSITION;
        // Human — оставшиеся 78.382%
        return "§f§lHuman";
    }
}