package com.invfix.mixin.flat;

import com.invfix.flat.Flat;
import com.invfix.flat.FlatState;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 3D-2D: коробка отсечения — весь рисунок (Flat#drawingBox), а не хитбокс в 0,01 блока. По ней игра
 * проверяет, в кадре ли сущность, а EntityCulling — не закрыта ли она блоками.
 */
@Mixin(LivingEntity.class)
public abstract class FlatCullingMixin {

    @Inject(method = "getBoundingBoxForCulling", at = @At("HEAD"), cancellable = true)
    private void invfix$flatCullingBox(CallbackInfoReturnable<AABB> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        FlatState s = Flat.state(self);
        if (s != null) cir.setReturnValue(Flat.drawingBox(s, self.position()));
    }
}
