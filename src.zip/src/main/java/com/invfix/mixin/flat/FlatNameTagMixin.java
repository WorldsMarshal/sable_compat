package com.invfix.mixin.flat;

import com.invfix.flat.Flat;
import com.invfix.fourd.FourD;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Ник рисунка 3D-2D и смещённого в 4D не виден нигде — и сквозь блоки тоже. RenderNameTagEvent
 * (FlatRender, FourDRender) прячет его в обычной отрисовке, но EntityCulling рисует ники закрытых блоками
 * сущностей сам (renderNametagsThroughWalls: shouldShowName → renderNameTag напрямую, мимо события) —
 * поэтому ник гасится в самих рендерерах.
 */
public final class FlatNameTagMixin {

    // проверка — в каждом миксине своя: классы пакета миксинов нельзя загружать из кода напрямую
    private FlatNameTagMixin() {}

    @Mixin(LivingEntityRenderer.class)
    public abstract static class Living {
        @Inject(method = "shouldShowName(Lnet/minecraft/world/entity/LivingEntity;)Z", at = @At("HEAD"), cancellable = true)
        private void invfix$noName(LivingEntity entity, CallbackInfoReturnable<Boolean> cir) {
            if (Flat.flat(entity) || FourD.in(entity)) cir.setReturnValue(false);
        }
    }

    @Mixin(EntityRenderer.class)
    public abstract static class Any {
        @Inject(method = "renderNameTag", at = @At("HEAD"), cancellable = true)
        private void invfix$noName(Entity entity, Component name, PoseStack pose, MultiBufferSource buffers, int light,
                                   float partial, CallbackInfo ci) {
            if (Flat.flat(entity) || FourD.in(entity)) ci.cancel();
        }
    }

    @Mixin(PlayerRenderer.class)
    public abstract static class Player {
        @Inject(method = "renderNameTag(Lnet/minecraft/client/player/AbstractClientPlayer;Lnet/minecraft/network/chat/Component;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IF)V",
                at = @At("HEAD"), cancellable = true)
        private void invfix$noName(AbstractClientPlayer player, Component name, PoseStack pose, MultiBufferSource buffers,
                                   int light, float partial, CallbackInfo ci) {
            if (Flat.flat(player) || FourD.in(player)) ci.cancel();
        }
    }
}
