package com.invfix.mixin.flat;

import com.invfix.flat.Flat;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 3D-2D: рисунок без столкновений и без своей физики. Player#tick каждый тик ставит
 * noPhysics = isSpectator() — в 2D там true (сервер принимает положение без проверки столкновений,
 * клиент не выталкивается из блоков); travel (ходьба, гравитация) — не идёт: рисунок двигает
 * client.FlatClient.
 */
@Mixin(Player.class)
public abstract class FlatPlayerMixin {

    @ModifyExpressionValue(method = "tick",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;isSpectator()Z", ordinal = 0))
    private boolean invfix$flatNoPhysics(boolean spectator) {
        // 4D Offset — тоже без столкновений: ходит сквозь стены (движение — client.FourDClient)
        return spectator || Flat.flat((Player) (Object) this) || com.invfix.fourd.FourD.in((Player) (Object) this);
    }

    /** 4D Offset: в любую позу «помещается» — стены вокруг не заставляют ползти или пригибаться. */
    @org.spongepowered.asm.mixin.injection.Inject(method = "canPlayerFitWithinBlocksAndEntitiesWhen", at = @At("HEAD"), cancellable = true)
    private void invfix$fourDFits(net.minecraft.world.entity.Pose pose,
                                  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<Boolean> cir) {
        if (com.invfix.fourd.FourD.in((Player) (Object) this)) cir.setReturnValue(true);
    }

    @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
    private void invfix$flatTravel(Vec3 travelVector, CallbackInfo ci) {
        if (Flat.flat((Player) (Object) this)) ci.cancel();
    }
}
