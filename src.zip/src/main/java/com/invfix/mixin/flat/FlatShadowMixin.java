package com.invfix.mixin.flat;

import com.invfix.flat.Flat;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** 3D-2D: у рисунка нет тени (LivingEntityRenderer умножает этот радиус — тоже 0). */
@Mixin(EntityRenderer.class)
public abstract class FlatShadowMixin {

    @Inject(method = "getShadowRadius", at = @At("HEAD"), cancellable = true)
    private void invfix$flatShadow(Entity entity, CallbackInfoReturnable<Float> cir) {
        if (Flat.flat(entity)) cir.setReturnValue(0.0F);
    }
}
