package com.invfix.mixin.flat;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * 3D-2D: Attack — здоровье прямо в данных сущности, мимо getHealth / setHealth: моды переопределяют их у
 * «читерных» существ (вечное здоровье, потолок урона), а граффити должно умирать всегда.
 */
@Mixin(LivingEntity.class)
public interface FlatHealthAccessor {

    @Accessor("DATA_HEALTH_ID")
    static EntityDataAccessor<Float> invfix$healthId() {
        throw new AssertionError();
    }
}
