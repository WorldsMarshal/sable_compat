package com.invfix.mixin.flat;

import com.invfix.flat.Flat;
import com.invfix.flat.FlatAttack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 3D-2D: Attack — сущность-рисунок (не игрок; у игрока — FlatPlayerMixin):
 *  - travel (ходьба, гравитация) не идёт: на сервере рисунок ведёт FlatAttack#travel по поверхностям;
 *  - тело исчезает без облачка частиц (рисунок не «пыхает»).
 */
@Mixin(LivingEntity.class)
public abstract class FlatLivingMixin {

    @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
    private void invfix$flatTravel(Vec3 travelVector, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self instanceof Player || !Flat.flat(self)) return;
        if (!self.level().isClientSide()) FlatAttack.travel(self);
        ci.cancel();
    }

    @Inject(method = "makePoofParticles", at = @At("HEAD"), cancellable = true)
    private void invfix$flatNoPoof(CallbackInfo ci) {
        if (Flat.flat((LivingEntity) (Object) this)) ci.cancel();
    }
}
