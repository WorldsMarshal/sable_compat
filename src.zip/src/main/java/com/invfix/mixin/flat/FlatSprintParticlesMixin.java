package com.invfix.mixin.flat;

import com.invfix.flat.Flat;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** 3D-2D: у рисунка нет частиц бега из блока под ногами (LocalPlayer зовёт сюда через super). */
@Mixin(Entity.class)
public abstract class FlatSprintParticlesMixin {

    @Inject(method = "canSpawnSprintParticle", at = @At("HEAD"), cancellable = true)
    private void invfix$flatNoSprintParticles(CallbackInfoReturnable<Boolean> cir) {
        if (Flat.flat((Entity) (Object) this)) cir.setReturnValue(false);
    }
}
