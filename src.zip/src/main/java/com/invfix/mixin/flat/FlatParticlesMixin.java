package com.invfix.mixin.flat;

import com.invfix.flat.Flat;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 3D-2D: у рисунка нет крошек еды (они сыпались из пола — «рот» у самой поверхности). */
@Mixin(LivingEntity.class)
public abstract class FlatParticlesMixin {

    @Inject(method = "spawnItemParticles", at = @At("HEAD"), cancellable = true)
    private void invfix$flatNoItemParticles(ItemStack stack, int amount, CallbackInfo ci) {
        if (Flat.flat((LivingEntity) (Object) this)) ci.cancel();
    }
}
