package com.invfix.mixin.flat;

import com.invfix.flat.Flat;
import com.invfix.flat.FlatState;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 3D-2D: глаза рисунка — у его головы над поверхностью (Flat#eye), а не над положением: лёжа голова
 * в стороне от ног. Отсюда же — луч взгляда (что под прицелом) и проверки дальности взаимодействия
 * на сервере; камера (FlatCameraMixin) ставится сюда же.
 */
@Mixin(Entity.class)
public abstract class FlatEntityEyeMixin {

    @Inject(method = "getEyePosition()Lnet/minecraft/world/phys/Vec3;", at = @At("HEAD"), cancellable = true)
    private void invfix$flatEye(CallbackInfoReturnable<Vec3> cir) {
        Entity self = (Entity) (Object) this;
        FlatState s = Flat.state(self);
        if (s != null) cir.setReturnValue(Flat.eye(s, self.position()));
    }

    @Inject(method = "getEyePosition(F)Lnet/minecraft/world/phys/Vec3;", at = @At("HEAD"), cancellable = true)
    private void invfix$flatEyeLerp(float partialTicks, CallbackInfoReturnable<Vec3> cir) {
        Entity self = (Entity) (Object) this;
        FlatState s = Flat.state(self);
        if (s == null) return;
        Vec3 pos = new Vec3(Mth.lerp(partialTicks, self.xo, self.getX()), Mth.lerp(partialTicks, self.yo, self.getY()),
                Mth.lerp(partialTicks, self.zo, self.getZ()));
        cir.setReturnValue(Flat.eye(s, pos));
    }
}
