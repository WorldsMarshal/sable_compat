package com.invfix.mixin.flat;

import com.invfix.flat.Flat;
import com.invfix.flat.FlatState;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 3D-2D: глаза рисунка — у его головы над поверхностью (Flat#eye), а не над положением: лёжа голова
 * в стороне от ног. Отсюда же — луч взгляда (что под прицелом) и проверки дальности взаимодействия
 * на сервере; камера (FlatCameraMixin) ставится сюда же.
 *
 * И дальность отрисовки: игра берёт её из размера хитбокса (× 64, у чужих игроков × 640), а у рисунка
 * хитбокс 0,01 блока — он пропадал из виду в паре шагов. Рисунок рисуется на любом расстоянии, пока
 * игрок отслеживается (как и обычный игрок такого же размера).
 */
@Mixin(Entity.class)
public abstract class FlatEntityEyeMixin {

    /**
     * Лёжа («пол как стена») взгляд — в системе рисунка (Flat#toWorld): луч прицела, взаимодействие и
     * всё, что берёт направление взгляда, совпадают с повёрнутой камерой. На обеих сторонах.
     */
    @Inject(method = "calculateViewVector", at = @At("RETURN"), cancellable = true)
    private void invfix$flatViewVector(float xRot, float yRot, CallbackInfoReturnable<Vec3> cir) {
        FlatState s = Flat.state((Entity) (Object) this);
        if (Flat.tilted(s)) cir.setReturnValue(Flat.toWorld(s, cir.getReturnValue()));
    }

    @Inject(method = "shouldRender(DDD)Z", at = @At("HEAD"), cancellable = true)
    private void invfix$flatRenderDistance(double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        if (Flat.flat((Entity) (Object) this)) cir.setReturnValue(true);
    }

    @Inject(method = "getEyePosition()Lnet/minecraft/world/phys/Vec3;", at = @At("HEAD"), cancellable = true)
    private void invfix$flatEye(CallbackInfoReturnable<Vec3> cir) {
        Entity self = (Entity) (Object) this;
        FlatState s = Flat.state(self);
        if (s != null) cir.setReturnValue(Flat.eye(s, self.position()));
    }

    @Inject(method = "getEyePosition(F)Lnet/minecraft/world/phys/Vec3;", at = @At("HEAD"), cancellable = true)
    private void invfix$flatEyeLerp(float partialTicks, CallbackInfoReturnable<Vec3> cir) {
        Entity self = (Entity) (Object) this;
        FlatState s = Flat.state(self);
        if (s == null) return;
        Vec3 pos = new Vec3(Mth.lerp(partialTicks, self.xo, self.getX()), Mth.lerp(partialTicks, self.yo, self.getY()),
                Mth.lerp(partialTicks, self.zo, self.getZ()));
        cir.setReturnValue(Flat.eye(s, pos));
    }
}
