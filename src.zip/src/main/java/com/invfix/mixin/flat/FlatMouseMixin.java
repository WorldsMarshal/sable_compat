package com.invfix.mixin.flat;

import com.invfix.flat.Flat;
import com.invfix.flat.FlatState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 3D-2D: Attack, граффити — мышь не поворачивает голову (рисунок неподвижен). */
@Mixin(MouseHandler.class)
public abstract class FlatMouseMixin {

    @Inject(method = "turnPlayer", at = @At("HEAD"), cancellable = true)
    private void invfix$flatFrozenTurn(double movementTime, CallbackInfo ci) {
        FlatState s = Flat.state(Minecraft.getInstance().player);
        if (s != null && s.frozen) ci.cancel();
    }
}
