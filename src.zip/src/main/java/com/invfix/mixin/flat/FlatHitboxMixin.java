package com.invfix.mixin.flat;

import com.invfix.flat.Flat;
import com.invfix.fourd.FourD;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 3D-2D (рисунок) и 4D Offset (срез): хитбокс не виден и в F3+B — объёма у них в этом мире нет. */
@Mixin(EntityRenderDispatcher.class)
public abstract class FlatHitboxMixin {

    @Inject(method = "renderHitbox", at = @At("HEAD"), cancellable = true)
    private static void invfix$hideHitbox(PoseStack poseStack, VertexConsumer buffer, Entity entity, float red, float green,
                                          float blue, float alpha, CallbackInfo ci) {
        if (Flat.flat(entity) || FourD.in(entity)) ci.cancel();
    }
}
