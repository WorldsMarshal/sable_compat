package com.invfix.mixin.flat;

import com.invfix.flat.Flat;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 3D-2D: камера — у головы рисунка, чуть над поверхностью (Entity#getEyePosition, FlatEntityEyeMixin),
 * без сглаживания высоты глаз. Вид от третьего лица отодвигается уже от этой точки.
 *
 * Лёжа («пол как стена») поворот камеры — в системе рисунка (Flat#tilt): ко всему повороту из yaw /
 * pitch / roll спереди домножается поворот системы, как у модов со сменой гравитации, — верх экрана
 * к голове рисунка. Векторы «вперёд / вверх / влево» (по ним отодвигается вид от третьего лица)
 * пересчитываются следом.
 */
@Mixin(Camera.class)
public abstract class FlatCameraMixin {

    @Shadow
    private Entity entity;
    @Shadow
    @Final
    private Quaternionf rotation;
    @Shadow
    @Final
    private Vector3f forwards;
    @Shadow
    @Final
    private Vector3f up;
    @Shadow
    @Final
    private Vector3f left;

    @Shadow
    protected abstract void setPosition(Vec3 pos);

    @Inject(method = "setup",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;setPosition(DDD)V", ordinal = 0, shift = At.Shift.AFTER))
    private void invfix$flatCamera(BlockGetter level, Entity entity, boolean detached, boolean thirdPersonReverse,
                                   float partialTick, CallbackInfo ci) {
        if (Flat.flat(entity)) setPosition(entity.getEyePosition(partialTick));
    }

    @Inject(method = "setRotation(FFF)V", at = @At("RETURN"))
    private void invfix$flatTilt(float yRot, float xRot, float roll, CallbackInfo ci) {
        Quaternionf tilt = Flat.tilt(Flat.state(entity));
        if (tilt == null) return;
        rotation.premul(tilt);
        forwards.set(0.0F, 0.0F, -1.0F).rotate(rotation);
        up.set(0.0F, 1.0F, 0.0F).rotate(rotation);
        left.set(-1.0F, 0.0F, 0.0F).rotate(rotation);
    }
}
