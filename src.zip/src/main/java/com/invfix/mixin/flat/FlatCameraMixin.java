package com.invfix.mixin.flat;

import com.invfix.flat.Flat;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 3D-2D: камера — у головы рисунка, чуть над поверхностью (Entity#getEyePosition, FlatEntityEyeMixin),
 * без сглаживания высоты глаз. Вид от третьего лица отодвигается уже от этой точки.
 */
@Mixin(Camera.class)
public abstract class FlatCameraMixin {

    @Shadow
    protected abstract void setPosition(Vec3 pos);

    @Inject(method = "setup",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;setPosition(DDD)V", ordinal = 0, shift = At.Shift.AFTER))
    private void invfix$flatCamera(BlockGetter level, Entity entity, boolean detached, boolean thirdPersonReverse,
                                   float partialTick, CallbackInfo ci) {
        if (Flat.flat(entity)) setPosition(entity.getEyePosition(partialTick));
    }
}
