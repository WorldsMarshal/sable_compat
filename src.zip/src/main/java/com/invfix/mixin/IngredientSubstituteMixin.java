package com.invfix.mixin;

import com.invfix.cybercompat.SubstituteRegistry;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Делает синтетические материалы (кристалл, незеритовый обломок) валидными
 * ингредиентами ВЕЗДЕ, где ванильный {@link Ingredient} проверяет предмет —
 * то есть в любом крафте любого мода, построенном на стандартном механизме
 * рецептов, включая моды, чьих датапаков у нас нет и никогда не будет.
 *
 * <p>Если оригинальная проверка не прошла (предмет не совпал напрямую), пробуем
 * ещё раз с «настоящим» эквивалентом синтетического материала
 * ({@link SubstituteRegistry#realEquivalent(ItemStack)}). Рекурсии нет: сам
 * ванильный предмет (аметист/незерит-лом) не имеет эквивалента в реестре,
 * поэтому второй вызов {@code test(...)} просто возвращает обычный результат
 * ванильного сравнения и не заходит в эту ветку снова.
 */
@Mixin(Ingredient.class)
public abstract class IngredientSubstituteMixin {

    @Inject(method = "test", at = @At("RETURN"), cancellable = true)
    private void sable$substitute(ItemStack stack, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValueZ()) return; // уже совпало напрямую — ничего не трогаем

        ItemStack real = SubstituteRegistry.realEquivalent(stack);
        if (real == null) return; // не наш синтетический материал

        if (((Ingredient) (Object) this).test(real)) {
            cir.setReturnValue(true);
        }
    }
}
