package com.invfix.mixin.sizediff.client;

import com.invfix.sizediff.SizeState;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Size Difference: модель масштабируется плавно по кадрам, а не ступеньками по тикам
 * (за секунду рост может быть ×25 — по тикам это заметные скачки).
 */
@Mixin(LivingEntityRenderer.class)
public abstract class ScaleRenderMixin {

    @Redirect(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getScale()F"),
            require = 0)
    private float invfix$smoothScale(LivingEntity entity) {
        float base = entity.getScale();
        if (!(entity instanceof Player player)) return base;
        SizeState st = SizeState.get(player);
        if (st == null || !st.transitioning()) return base;
        float tick = st.scale();
        if (tick <= 0.0F) return base;
        java.util.function.Supplier<Float> p = SizeState.partial;
        float pt = p != null ? p.get() : 1.0F;
        return base / tick * st.renderScale(pt);
    }
}
