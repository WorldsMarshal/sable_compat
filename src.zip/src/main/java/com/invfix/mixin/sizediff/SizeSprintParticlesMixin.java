package com.invfix.mixin.sizediff;

import com.invfix.sizediff.SizeHandler;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Size Difference: меньше 0.4 — бег без частиц земли из-под ног (они крупнее самого игрока). */
@Mixin(Entity.class)
public abstract class SizeSprintParticlesMixin {

    @Inject(method = "canSpawnSprintParticle", at = @At("HEAD"), cancellable = true)
    private void invfix$noSprintDustWhenTiny(CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof Player player && SizeHandler.scaleOf(player) < SizeHandler.NO_GROUND_PARTICLES_BELOW) {
            cir.setReturnValue(false);
        }
    }
}
