package com.invfix.mixin.sizediff.client;

import com.invfix.sizediff.SizeHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

/**
 * Size Difference: у маленького игрока ближняя плоскость отсечения камеры (0.05 блока)
 * уменьшается вместе с ним — иначе камера «видит» сквозь стены и блоки рядом
 * (как в Pehkui, GameRendererMixin#getBasicProjectionMatrix).
 */
@Mixin(GameRenderer.class)
public abstract class ScaleNearPlaneMixin {

    @ModifyConstant(method = "getProjectionMatrix", constant = @Constant(floatValue = 0.05F), require = 0)
    private float invfix$nearPlaneForSmall(float near) {
        if (!(Minecraft.getInstance().getCameraEntity() instanceof LivingEntity e)) return near;
        float s = SizeHandler.scaleOf(e);
        return s < 1.0F ? Math.max(near * s, 0.001F) : near;
    }
}
