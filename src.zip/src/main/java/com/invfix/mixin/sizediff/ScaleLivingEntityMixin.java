package com.invfix.mixin.sizediff;

import com.invfix.sizediff.SizeState;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Size Difference: масштаб игрока поверх ванильного атрибута scale. Через getScale идут
 * хитбокс и высота глаз (LivingEntity#getDimensions), модель и тень, камера от третьего
 * лица, точки посадки пассажиров — поэтому достаточно умножить здесь.
 */
@Mixin(LivingEntity.class)
public abstract class ScaleLivingEntityMixin {

    @Inject(method = "getScale", at = @At("RETURN"), cancellable = true)
    private void invfix$sizeDifference(CallbackInfoReturnable<Float> cir) {
        if (!((Object) this instanceof Player player) || player.level() == null) return;
        SizeState st = SizeState.get(player);
        if (st == null) return;
        float s = st.scale();
        if (s != 1.0F) cir.setReturnValue(cir.getReturnValueF() * s);
    }
}
