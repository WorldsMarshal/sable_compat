package com.invfix.mixin.sizediff;

import com.invfix.sizediff.SizeHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Size Difference:
 *  - шаг ног считается от пройденного расстояния в «своих» шагах (расстояние ÷ размер),
 *    как в Pehkui: маленький семенит быстро, а не еле двигает ногами, большой шагает
 *    размашисто и медленно;
 *  - меньше {@link SizeHandler#NO_GROUND_PARTICLES_BELOW} — без облака частиц земли при
 *    приземлении (частицы в десятки раз крупнее игрока).
 */
@Mixin(LivingEntity.class)
public abstract class SizeWalkAnimationMixin {

    @ModifyVariable(method = "updateWalkAnimation", at = @At("HEAD"), argsOnly = true)
    private float invfix$walkPerSize(float distance) {
        if (!((Object) this instanceof Player player)) return distance;
        float s = SizeHandler.scaleOf(player);
        return s == 1.0F || s <= 0.0F ? distance : distance / s;
    }

    @Redirect(method = "checkFallDamage", require = 0,
            at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;sendParticles(Lnet/minecraft/core/particles/ParticleOptions;DDDIDDDD)I"))
    private <T extends ParticleOptions> int invfix$noLandingDustWhenTiny(ServerLevel level, T type, double x, double y, double z,
                                                                       int count, double dx, double dy, double dz, double speed) {
        if ((Object) this instanceof Player player && SizeHandler.scaleOf(player) < SizeHandler.NO_GROUND_PARTICLES_BELOW) return 0;
        return level.sendParticles(type, x, y, z, count, dx, dy, dz, speed);
    }
}
