package com.invfix.mixin.perf;

import com.invfix.perf.RespawnChunkReuse;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.PlayerChunkSender;
import net.minecraft.server.players.PlayerList;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Респавн без повторной пересылки чанков — см. RespawnChunkReuse. Не нашлась точка — ванильный респавн. */
public final class RespawnChunkReuseMixins {

    private RespawnChunkReuseMixins() {}

    @Mixin(PlayerList.class)
    public abstract static class Respawn {

        @Inject(method = "respawn", at = @At("HEAD"), require = 0)
        private void invfix$reuseBegin(ServerPlayer player, boolean keepInventory, Entity.RemovalReason reason,
                                       CallbackInfoReturnable<ServerPlayer> cir) {
            RespawnChunkReuse.begin(player);
        }

        @WrapOperation(method = "respawn", require = 0, at = @At(value = "INVOKE",
                target = "Lnet/minecraft/server/level/ServerLevel;addRespawnedPlayer(Lnet/minecraft/server/level/ServerPlayer;)V"))
        private void invfix$reuseAdd(ServerLevel level, ServerPlayer player, Operation<Void> original) {
            RespawnChunkReuse.addRespawned(level, () -> original.call(level, player));
        }

        @Inject(method = "respawn", at = @At("RETURN"), require = 0)
        private void invfix$reuseFinish(ServerPlayer player, boolean keepInventory, Entity.RemovalReason reason,
                                        CallbackInfoReturnable<ServerPlayer> cir) {
            RespawnChunkReuse.finish(cir.getReturnValue());
        }
    }

    @Mixin(PlayerChunkSender.class)
    public abstract static class Sender {

        @Inject(method = "markChunkPendingToSend", at = @At("HEAD"), cancellable = true, require = 0)
        private void invfix$reuseSkip(LevelChunk chunk, CallbackInfo ci) {
            if (RespawnChunkReuse.skip((PlayerChunkSender) (Object) this, chunk)) ci.cancel();
        }
    }
}
