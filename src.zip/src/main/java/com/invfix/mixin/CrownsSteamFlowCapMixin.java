package com.invfix.mixin;

import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Предохранитель против дисконнекта «Failed to decode create:update_steam_flow».
 *
 * Create: Crowns хранит все паровые потоки (SteamCurrent от градирен/турбин)
 * в глобальном SavedData "steam_currents" и каждый тик рассылает весь блоб
 * NBT каждому игроку одним пакетом. Инжектор пересоздаёт поток, если не видит
 * существующий в своих границах, а старый «валидный» фантом остаётся в списке
 * навсегда. Фантомы (а) складывают свою мощность в турбины, раздувая ЕН до
 * миллионов, и (б) раздувают пакет синхронизации свыше ванильного клиентского
 * лимита 2 MiB — клиент не может декодировать пакет и вылетает при входе.
 *
 * Фикс в два эшелона, перед каждым тиком менеджера:
 * 1) ДЕДУПЛИКАЦИЯ: на каждый injectorPos в измерении остаётся только самый
 *    новый поток (именно к нему привязан живой инжектор — новый создаётся
 *    лишь когда старый выпал из зоны видимости, т.е. старший заведомо
 *    фантом). Легитимные потоки не трогаются вообще, сколько бы реакторов
 *    и турбин ни построили игроки.
 * 2) СТРАХОВОЧНЫЙ КАП {@value #SABLE_HARD_CAP} потоков на измерение (срез
 *    самых старых) — на случай, если утечка когда-нибудь пойдёт по пути,
 *    не ловящемуся дедупликацией. 250 потоков = 250 одновременно живых
 *    инжекторов в одном измерении; пакет при этом ~1 MiB, вдвое ниже лимита.
 *
 * Доступ через рефлексию, чтобы не требовать crowns в compile classpath;
 * миксин применяется только при загруженном crowns
 * (см. {@link com.invfix.compat.InvincibleIncMixinTransformer}).
 */
@Mixin(targets = "com.rae.crowns.content.thermodynamics.turbine.SteamFlowManager", remap = false)
public abstract class CrownsSteamFlowCapMixin {

    /** Жёсткий потолок потоков на измерение — последний рубеж. */
    @Unique private static final int SABLE_HARD_CAP = 250;

    @Unique private static Field invfix$storageField;
    @Unique private static Field invfix$currentsField;
    @Unique private static Field invfix$injectorPosField;
    @Unique private static long invfix$lastWarn;
    @Unique private static final Logger INVFIX_LOGGER = LogUtils.getLogger();

    @Inject(method = "tick", at = @At("HEAD"))
    private static void invfix$pruneSteamCurrents(CallbackInfo ci) {
        try {
            if (invfix$storageField == null) {
                Class<?> mgr = Class.forName(
                        "com.rae.crowns.content.thermodynamics.turbine.SteamFlowManager");
                invfix$storageField = mgr.getDeclaredField("storage");
                invfix$storageField.setAccessible(true);
                Class<?> data = Class.forName(
                        "com.rae.crowns.content.thermodynamics.turbine.SteamFlowData");
                invfix$currentsField = data.getDeclaredField("steamCurrents");
                invfix$currentsField.setAccessible(true);
                Class<?> current = Class.forName(
                        "com.rae.crowns.content.thermodynamics.turbine.SteamCurrent");
                invfix$injectorPosField = current.getDeclaredField("injectorPos");
                invfix$injectorPosField.setAccessible(true);
            }
            Object storage = invfix$storageField.get(null);
            if (storage == null) {
                return;
            }
            Map<?, ?> currents = (Map<?, ?>) invfix$currentsField.get(storage);
            int deduped = 0;
            int capped = 0;
            for (Object value : currents.values()) {
                List<?> list = (List<?>) value;

                // 1) Дедупликация: идём с хвоста (новейшие добавляются в конец),
                //    первый встреченный injectorPos — живой, остальные — фантомы.
                Set<Object> seen = new HashSet<>();
                for (int i = list.size() - 1; i >= 0; i--) {
                    Object pos = invfix$injectorPosField.get(list.get(i));
                    if (pos != null && !seen.add(pos)) {
                        list.remove(i);
                        deduped++;
                    }
                }

                // 2) Страховочный кап: срезаем самые старые сверх потолка.
                while (list.size() > SABLE_HARD_CAP) {
                    list.remove(0);
                    capped++;
                }
            }
            if ((deduped > 0 || capped > 0)
                    && System.currentTimeMillis() - invfix$lastWarn > 60_000L) {
                invfix$lastWarn = System.currentTimeMillis();
                INVFIX_LOGGER.warn(
                        "[sable_compat] Паровые потоки Crowns: удалено {} фантомов-"
                        + "дубликатов по injectorPos{} — защита от переполнения "
                        + "пакета update_steam_flow (> 2 MiB = дисконнект) и "
                        + "накрутки мощности турбин",
                        deduped,
                        capped > 0 ? " и " + capped + " сверх капа " + SABLE_HARD_CAP : "");
            }
        } catch (Throwable t) {
            // Не даём предохранителю уронить тик: молча выходим,
            // в худшем случае поведение = ванильному поведению crowns.
        }
    }
}
