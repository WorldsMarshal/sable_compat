package com.invfix.mixin.pointblank;

import com.invfix.compat.pointblank.PointBlankDamageMarker;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Совместимость с PointBlank. Оборачивает единственный вызов
 * {@code hitEntity.hurt(damageSource, amount)} внутри
 * {@code HurtingItem#hurtEntity} (через него идёт весь урон по сущностям
 * и от хитскана, и от снарядов) и выставляет маркер PointBlankDamageMarker
 * на время этого вызова. Снятие маркера — в finally, поэтому исключение
 * в hurt() не оставит маркер «висящим».
 *
 * Применяется только если загружен мод pointblank (гейт в
 * InvincibleIncMixinTransformer). Логика самого PointBlank не меняется:
 * оригинальный вызов hurt() выполняется без изменений.
 */
@Mixin(targets = "com.vicmatskiv.pointblank.item.HurtingItem", remap = false)
public class PointBlankHurtMarkerMixin {

    @WrapOperation(
            method = "hurtEntity",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/Entity;hurt(Lnet/minecraft/world/damagesource/DamageSource;F)Z"
            )
    )
    private boolean invfix_markPointBlankHurt(
            Entity hitEntity, DamageSource source, float amount,
            Operation<Boolean> original) {
        PointBlankDamageMarker.begin();
        try {
            return original.call(hitEntity, source, amount);
        } finally {
            PointBlankDamageMarker.end();
        }
    }
}