package com.invfix.mixin.endertransmission;

import com.forsteri.createendertransmission.blocks.energyTransmitter.EnergyTransmitterBlockEntity;
import com.invfix.endertransmission.CrossDimEnergy;
import com.invfix.endertransmission.CrossDimTransmitter;
import com.simibubi.create.content.kinetics.KineticNetwork;
import com.simibubi.create.content.kinetics.base.IRotate;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Energy Transmitter между измерениями (CrossDimEnergy). У мода передатчики одного канала и пароля соединяются
 * только в своём мире (isCustomConnection) — сеть Create не выходит за пределы мира. Мост сшивает сети миров так,
 * чтобы они вели себя как одна сеть Create:
 *  - порт мира-ведущего (FOLLOW) крутится своей сетью; его генерируемая скорость — его же скорость, пока у него есть
 *    источник (ведомый генератор Create: сам сеть не крутит и не держит);
 *  - порт остальных миров (DRIVE) — генератор со скоростью ведущего; запуск, смена скорости, «перехват» более
 *    быстрым источником своего мира и повторный запуск после потери источника — как у GeneratingKineticBlockEntity
 *    (updateGeneratedRotation / applyNewSpeed / reActivateSource);
 *  - каждый порт вносит в свою сеть мощность и нагрузку остальных миров: в каждом мире мощность и нагрузка сети —
 *    общие, перегрузка — общая.
 * Мощность в Create — «на оборот» × |генерируемая скорость|, нагрузка — «на оборот» × |скорость|: порт пересчитывает
 * свои значения «на оборот», когда меняется скорость. Состояние моста хранится в блоке (сеть при загрузке вычитает
 * сохранённые мощность и нагрузку), раз в тик его выставляет CrossDimEnergy.
 *
 * Соседи для распространения вращения — только передатчики своего мира: у мода сюда попадали координаты
 * передатчиков из других миров, и RotationPropagator читал по ним блоки в своём мире (синхронная загрузка
 * чанка, а на тех же координатах мог оказаться посторонний передатчик того же канала).
 */
@Mixin(value = EnergyTransmitterBlockEntity.class, remap = false)
public abstract class EnergyTransmitterCrossDimMixin extends KineticBlockEntity implements CrossDimTransmitter {

    @Unique
    private int invfix$bridgeMode;
    @Unique
    private float invfix$bridgeSpeed;
    @Unique
    private float invfix$bridgeCapacity;
    @Unique
    private float invfix$bridgeLoad;

    private EnergyTransmitterCrossDimMixin(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    @Shadow
    public abstract List<KineticBlockEntity> getConnectedTransmitters();

    @Inject(method = "addPropagationLocations", at = @At("HEAD"), cancellable = true)
    private void invfix$sameLevelOnly(IRotate block, BlockState state, List<BlockPos> neighbours,
                                      CallbackInfoReturnable<List<BlockPos>> cir) {
        for (KineticBlockEntity tile : new ArrayList<>(this.getConnectedTransmitters())) {
            if (tile.getLevel() != this.level) continue;
            if (tile.getBlockPos() != this.getBlockPos() && !neighbours.contains(tile.getBlockPos())) {
                neighbours.add(tile.getBlockPos());
            }
        }
        cir.setReturnValue(super.addPropagationLocations(block, state, neighbours));
    }

    /** Смена канала или пароля: мост сбрасывается (передатчик и так отсоединяется), дальше решает CrossDimEnergy. */
    @Inject(method = "reloadSettings", at = @At("HEAD"))
    private void invfix$resetBridgeOnReload(CallbackInfo ci) {
        this.invfix$bridgeMode = NONE;
        this.invfix$bridgeSpeed = 0.0F;
        this.invfix$bridgeCapacity = 0.0F;
        this.invfix$bridgeLoad = 0.0F;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level != null && !this.level.isClientSide) CrossDimEnergy.track(this);
    }

    @Override
    public float getGeneratedSpeed() {
        return switch (this.invfix$bridgeMode) {
            case DRIVE -> this.invfix$bridgeSpeed;
            // ведомый: без источника не генерирует — сам себя не крутит
            case FOLLOW -> this.hasSource() ? this.speed : 0.0F;
            default -> 0.0F;
        };
    }

    @Override
    public float calculateAddedStressCapacity() {
        float gen = this.getGeneratedSpeed();
        if (this.invfix$bridgeMode == NONE || gen == 0.0F) return super.calculateAddedStressCapacity();
        float capacity = this.invfix$bridgeCapacity / Math.abs(gen);
        this.lastCapacityProvided = capacity;
        return capacity;
    }

    @Override
    public float calculateStressApplied() {
        float impact = super.calculateStressApplied();
        float speed = Math.abs(this.getTheoreticalSpeed());
        if (this.invfix$bridgeMode != NONE && this.invfix$bridgeLoad > 0.0F && speed > 0.0F) {
            impact += this.invfix$bridgeLoad / speed;
            this.lastStressApplied = impact;
        }
        return impact;
    }

    /**
     * Смена сети: порт убирается из источников прежней сети. KineticNetwork#remove убирает оттуда только блоки с
     * isSource, а у ведомого порта генерируемая скорость обнуляется вместе со скоростью раньше, чем Create его
     * отсоединяет, — без этого он остался бы в прежней сети источником.
     */
    @Override
    public void setNetwork(@Nullable Long networkIn) {
        if (this.level != null && !this.level.isClientSide && this.network != null && !Objects.equals(this.network, networkIn)) {
            this.getOrCreateNetwork().sources.remove(this);
        }
        super.setNetwork(networkIn);
    }

    @Override
    public int invfix$bridgeMode() {
        return this.invfix$bridgeMode;
    }

    @Override
    public float invfix$bridgeSpeed() {
        return this.invfix$bridgeSpeed;
    }

    @Override
    public float invfix$capacityContribution() {
        return this.invfix$bridgeMode != NONE && this.getGeneratedSpeed() != 0.0F ? this.invfix$bridgeCapacity : 0.0F;
    }

    @Override
    public float invfix$loadContribution() {
        return this.invfix$bridgeMode != NONE && this.speed != 0.0F ? this.invfix$bridgeLoad : 0.0F;
    }

    @Override
    public float invfix$networkCapacity() {
        return this.capacity;
    }

    @Override
    public float invfix$networkStress() {
        return this.stress;
    }

    @Override
    public void invfix$applyBridge(int mode, float speed, float capacity, float load) {
        if (this.level == null || this.level.isClientSide) return;
        if (mode != DRIVE) speed = 0.0F;
        if (mode == NONE) {
            capacity = 0.0F;
            load = 0.0F;
        }
        int prevMode = this.invfix$bridgeMode;
        if (mode == NONE && prevMode == NONE) return;
        float prevGen = this.getGeneratedSpeed();
        boolean changed = mode != prevMode || speed != this.invfix$bridgeSpeed;
        this.invfix$bridgeMode = mode;
        this.invfix$bridgeSpeed = speed;
        if (invfix$differs(capacity, this.invfix$bridgeCapacity)) {
            this.invfix$bridgeCapacity = capacity;
            changed = true;
        }
        if (invfix$differs(load, this.invfix$bridgeLoad)) {
            this.invfix$bridgeLoad = load;
            changed = true;
        }
        float gen = this.getGeneratedSpeed();

        if (mode == DRIVE) {
            // смена скорости — GeneratingKineticBlockEntity#updateGeneratedRotation; reActivateSource — генератор
            // без источника встал (его сеть разобрали) или его ведёт более медленный источник
            boolean reactivate = this.speed == 0.0F || (this.hasSource() && Math.abs(this.speed) < Math.abs(gen));
            if (gen != prevGen || prevMode != DRIVE || reactivate) {
                this.invfix$updateGeneratedRotation(gen);
                this.setChanged();
                return;
            }
        } else if (prevMode == DRIVE && !this.hasSource()) {
            // ведущий генератор перестаёт генерировать: как генератор Create со скоростью 0 — сеть встаёт, источники
            // своего мира запустят её сами (FOLLOW без источника сам себя не крутит)
            this.invfix$updateGeneratedRotation(0.0F);
            this.setChanged();
            return;
        }

        // Мощность и нагрузка порта в сети. Сверяются каждый тик: Create добавляет блок в сеть (KineticNetwork#add)
        // в момент setSource, когда скорость ещё прежняя (часто 0), — значения «на оборот» тогда неверны; у FOLLOW
        // они меняются и вместе со скоростью сети.
        if (this.hasNetwork()) {
            KineticNetwork network = this.getOrCreateNetwork();
            Object have = network.sources.get(this);
            if (gen != 0.0F) {
                float want = this.calculateAddedStressCapacity();
                if (!(have instanceof Float f) || invfix$differs(f, want)) network.updateCapacityFor(this, want);
            } else if (have != null) {
                network.sources.remove(this);
                network.updateCapacity();
            }
            if (network.members.get(this) instanceof Float f) {
                float want = this.calculateStressApplied();
                if (invfix$differs(f, want)) network.updateStressFor(this, want);
            }
        }
        if (changed) this.setChanged();
    }

    /** Изменение меньше миллионной доли не передаётся: иначе погрешность вычитания пересчитывала бы сеть каждый тик. */
    @Unique
    private static boolean invfix$differs(float a, float b) {
        return Math.abs(a - b) > 1.0E-6F * Math.max(1.0F, Math.max(Math.abs(a), Math.abs(b)));
    }

    /** GeneratingKineticBlockEntity#updateGeneratedRotation. */
    @Unique
    private void invfix$updateGeneratedRotation(float speed) {
        float prevSpeed = this.speed;
        if (prevSpeed != speed) {
            if (!this.hasSource()) {
                IRotate.SpeedLevel levelBefore = IRotate.SpeedLevel.of(this.speed);
                IRotate.SpeedLevel levelAfter = IRotate.SpeedLevel.of(speed);
                if (levelBefore != levelAfter) this.effects.queueRotationIndicators();
            }
            this.invfix$applyNewSpeed(prevSpeed, speed);
        }
        if (this.hasNetwork() && speed != 0.0F) {
            KineticNetwork network = this.getOrCreateNetwork();
            network.updateCapacityFor(this, this.calculateAddedStressCapacity());
            network.updateStressFor(this, this.calculateStressApplied());
            network.updateStress();
        }
        this.onSpeedChanged(prevSpeed);
        this.sendData();
    }

    /** GeneratingKineticBlockEntity#applyNewSpeed. */
    @Unique
    private void invfix$applyNewSpeed(float prevSpeed, float speed) {
        if (speed == 0.0F) {
            if (this.hasSource()) {
                this.getOrCreateNetwork().updateCapacityFor(this, 0.0F);
                this.getOrCreateNetwork().updateStressFor(this, this.calculateStressApplied());
            } else {
                this.detachKinetics();
                this.setSpeed(0.0F);
                this.setNetwork(null);
            }
        } else if (prevSpeed == 0.0F) {
            this.setSpeed(speed);
            this.setNetwork(this.worldPosition.asLong());
            this.attachKinetics();
        } else if (this.hasSource()) {
            if (Math.abs(prevSpeed) >= Math.abs(speed)) {
                if (Math.signum(prevSpeed) != Math.signum(speed)) this.level.destroyBlock(this.worldPosition, true);
            } else {
                this.detachKinetics();
                this.setSpeed(speed);
                this.source = null;
                this.setNetwork(this.worldPosition.asLong());
                this.attachKinetics();
            }
        } else {
            this.detachKinetics();
            this.setSpeed(speed);
            this.attachKinetics();
        }
    }

    @Override
    protected void write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(tag, registries, clientPacket);
        if (this.invfix$bridgeMode != NONE) {
            tag.putByte("InvfixBridgeMode", (byte) this.invfix$bridgeMode);
            if (this.invfix$bridgeSpeed != 0.0F) tag.putFloat("InvfixBridgeSpeed", this.invfix$bridgeSpeed);
            if (this.invfix$bridgeCapacity != 0.0F) tag.putFloat("InvfixBridgeCapacity", this.invfix$bridgeCapacity);
            if (this.invfix$bridgeLoad != 0.0F) tag.putFloat("InvfixBridgeLoad", this.invfix$bridgeLoad);
        }
    }

    @Override
    protected void read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        this.invfix$bridgeSpeed = tag.getFloat("InvfixBridgeSpeed");
        // сохранения прежней версии моста: приёмник (скорость ≠ 0) — DRIVE, остальное — обычный передатчик
        this.invfix$bridgeMode = tag.contains("InvfixBridgeMode") ? tag.getByte("InvfixBridgeMode")
                : this.invfix$bridgeSpeed != 0.0F ? DRIVE : NONE;
        if (this.invfix$bridgeMode != DRIVE) this.invfix$bridgeSpeed = 0.0F;
        if (this.invfix$bridgeMode != NONE) {
            this.invfix$bridgeCapacity = tag.getFloat("InvfixBridgeCapacity");
            this.invfix$bridgeLoad = tag.getFloat("InvfixBridgeLoad");
        } else {
            this.invfix$bridgeCapacity = 0.0F;
            this.invfix$bridgeLoad = 0.0F;
        }
        super.read(tag, registries, clientPacket);
    }
}
