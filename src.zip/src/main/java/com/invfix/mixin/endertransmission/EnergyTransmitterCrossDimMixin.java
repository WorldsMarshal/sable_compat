package com.invfix.mixin.endertransmission;

import com.forsteri.createendertransmission.blocks.energyTransmitter.EnergyTransmitterBlockEntity;
import com.invfix.endertransmission.CrossDimEnergy;
import com.invfix.endertransmission.CrossDimTransmitter;
import com.simibubi.create.content.kinetics.KineticNetwork;
import com.simibubi.create.content.kinetics.base.IRotate;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;

/**
 * Energy Transmitter между измерениями (CrossDimEnergy). У мода передатчики одного канала и пароля соединяются
 * только в своём мире (isCustomConnection) — сеть Create не выходит за пределы мира. Здесь мост:
 *  - приёмник (мир без своего источника) — генератор: getGeneratedSpeed — скорость ведущего, мощность — остаток
 *    ведущей сети; запуск и смена скорости — как GeneratingKineticBlockEntity#updateGeneratedRotation;
 *  - ведущий (мир с настоящим источником) несёт нагрузку сетей-приёмников: calculateStressApplied + нагрузка.
 * Состояние моста хранится в блоке (как у генераторов Create — сеть при загрузке вычитает сохранённые мощность
 * и нагрузку), раз в тик его выставляет CrossDimEnergy.
 *
 * Соседи для распространения вращения — только передатчики своего мира: у мода сюда попадали координаты
 * передатчиков из других миров, и RotationPropagator читал по ним блоки в своём мире (синхронная загрузка
 * чанка, а на тех же координатах мог оказаться посторонний передатчик того же канала).
 */
@Mixin(value = EnergyTransmitterBlockEntity.class, remap = false)
public abstract class EnergyTransmitterCrossDimMixin extends KineticBlockEntity implements CrossDimTransmitter {

    @Unique
    private float invfix$bridgeSpeed;
    @Unique
    private float invfix$bridgeCapacity;
    @Unique
    private float invfix$bridgeLoad;

    private EnergyTransmitterCrossDimMixin(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    @Shadow
    public abstract List<KineticBlockEntity> getConnectedTransmitters();

    @Inject(method = "addPropagationLocations", at = @At("HEAD"), cancellable = true)
    private void invfix$sameLevelOnly(IRotate block, BlockState state, List<BlockPos> neighbours,
                                      CallbackInfoReturnable<List<BlockPos>> cir) {
        for (KineticBlockEntity tile : new ArrayList<>(this.getConnectedTransmitters())) {
            if (tile.getLevel() != this.level) continue;
            if (tile.getBlockPos() != this.getBlockPos() && !neighbours.contains(tile.getBlockPos())) {
                neighbours.add(tile.getBlockPos());
            }
        }
        cir.setReturnValue(super.addPropagationLocations(block, state, neighbours));
    }

    /** Смена канала или пароля: мост сбрасывается (передатчик и так отсоединяется), дальше решает CrossDimEnergy. */
    @Inject(method = "reloadSettings", at = @At("HEAD"))
    private void invfix$resetBridgeOnReload(CallbackInfo ci) {
        this.invfix$bridgeSpeed = 0.0F;
        this.invfix$bridgeCapacity = 0.0F;
        this.invfix$bridgeLoad = 0.0F;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level != null && !this.level.isClientSide) CrossDimEnergy.track(this);
    }

    @Override
    public float getGeneratedSpeed() {
        return this.invfix$bridgeSpeed;
    }

    @Override
    public float calculateAddedStressCapacity() {
        if (this.invfix$bridgeSpeed == 0.0F) return super.calculateAddedStressCapacity();
        float capacity = this.invfix$bridgeCapacity / Math.abs(this.invfix$bridgeSpeed);
        this.lastCapacityProvided = capacity;
        return capacity;
    }

    @Override
    public float calculateStressApplied() {
        float impact = super.calculateStressApplied();
        float speed = Math.abs(this.getTheoreticalSpeed());
        if (this.invfix$bridgeLoad > 0.0F && speed > 0.0F) {
            impact += this.invfix$bridgeLoad / speed;
            this.lastStressApplied = impact;
        }
        return impact;
    }

    @Override
    public float invfix$bridgeSpeed() {
        return this.invfix$bridgeSpeed;
    }

    @Override
    public float invfix$bridgeLoad() {
        return this.invfix$bridgeLoad;
    }

    @Override
    public void invfix$applyBridge(float speed, float capacity, float load) {
        if (this.level == null || this.level.isClientSide) return;
        boolean speedChanged = speed != this.invfix$bridgeSpeed;
        boolean capacityChanged = capacity != this.invfix$bridgeCapacity;
        boolean loadChanged = load != this.invfix$bridgeLoad;
        if (!speedChanged && !capacityChanged && !loadChanged) return;
        this.invfix$bridgeCapacity = capacity;
        this.invfix$bridgeLoad = load;
        if (speedChanged) {
            this.invfix$bridgeSpeed = speed;
            this.invfix$updateGeneratedRotation();
        } else if (this.hasNetwork()) {
            KineticNetwork network = this.getOrCreateNetwork();
            if (this.isSource()) network.updateCapacityFor(this, this.calculateAddedStressCapacity());
            network.updateStressFor(this, this.calculateStressApplied());
        }
        this.setChanged();
    }

    /** GeneratingKineticBlockEntity#updateGeneratedRotation. */
    @Unique
    private void invfix$updateGeneratedRotation() {
        float speed = this.getGeneratedSpeed();
        float prevSpeed = this.speed;
        if (prevSpeed != speed) {
            if (!this.hasSource()) {
                IRotate.SpeedLevel levelBefore = IRotate.SpeedLevel.of(this.speed);
                IRotate.SpeedLevel levelAfter = IRotate.SpeedLevel.of(speed);
                if (levelBefore != levelAfter) this.effects.queueRotationIndicators();
            }
            this.invfix$applyNewSpeed(prevSpeed, speed);
        }
        if (this.hasNetwork() && speed != 0.0F) {
            KineticNetwork network = this.getOrCreateNetwork();
            network.updateCapacityFor(this, this.calculateAddedStressCapacity());
            network.updateStressFor(this, this.calculateStressApplied());
            network.updateStress();
        }
        this.onSpeedChanged(prevSpeed);
        this.sendData();
    }

    /**
     * GeneratingKineticBlockEntity#applyNewSpeed, кроме одного: при встречном вращении от другого источника сети
     * генератор Create ломается (destroyBlock) — передатчик не ломается, просто не меняет скорость.
     */
    @Unique
    private void invfix$applyNewSpeed(float prevSpeed, float speed) {
        if (speed == 0.0F) {
            if (this.hasSource()) {
                this.getOrCreateNetwork().updateCapacityFor(this, 0.0F);
                this.getOrCreateNetwork().updateStressFor(this, this.calculateStressApplied());
            } else {
                this.detachKinetics();
                this.setSpeed(0.0F);
                this.setNetwork(null);
            }
        } else if (prevSpeed == 0.0F) {
            this.setSpeed(speed);
            this.setNetwork(this.worldPosition.asLong());
            this.attachKinetics();
        } else if (this.hasSource()) {
            if (Math.abs(prevSpeed) < Math.abs(speed)) {
                this.detachKinetics();
                this.setSpeed(speed);
                this.source = null;
                this.setNetwork(this.worldPosition.asLong());
                this.attachKinetics();
            }
        } else {
            this.detachKinetics();
            this.setSpeed(speed);
            this.attachKinetics();
        }
    }

    @Override
    protected void write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(tag, registries, clientPacket);
        if (this.invfix$bridgeSpeed != 0.0F) tag.putFloat("InvfixBridgeSpeed", this.invfix$bridgeSpeed);
        if (this.invfix$bridgeCapacity != 0.0F) tag.putFloat("InvfixBridgeCapacity", this.invfix$bridgeCapacity);
        if (this.invfix$bridgeLoad != 0.0F) tag.putFloat("InvfixBridgeLoad", this.invfix$bridgeLoad);
    }

    @Override
    protected void read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        this.invfix$bridgeSpeed = tag.getFloat("InvfixBridgeSpeed");
        this.invfix$bridgeCapacity = tag.getFloat("InvfixBridgeCapacity");
        this.invfix$bridgeLoad = tag.getFloat("InvfixBridgeLoad");
        super.read(tag, registries, clientPacket);
    }
}
