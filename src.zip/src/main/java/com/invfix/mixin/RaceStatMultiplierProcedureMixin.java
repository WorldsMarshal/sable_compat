package com.invfix.mixin;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.humanlike.HumanLikeRaces;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.procedures.RaceStatMultiplierProcedure;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Добавляет коэффициент расы Altrumite (10x от Viltrumite).
 * Оригинальная процедура не знает про Altrumite, поэтому дописываем в TAIL.
 */
@Mixin(value = RaceStatMultiplierProcedure.class, remap = false)
public class RaceStatMultiplierProcedureMixin {

    @Inject(method = "execute", at = @At("TAIL"), remap = false)
    private static void invfix_altrumiteMultiplier(Entity entity, CallbackInfo ci) {
        if (entity == null) return;
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (AltrumiteRace.isAltrumite(vars.Race)) {
                vars.RaceStatMultiplier = AltrumiteRace.RACE_STAT_MULTIPLIER;
                vars.markSyncDirty();
                return;
            }
            // Расы-затычки идентичны Human: расовый множитель статов = 0.0.
            // Оригинальная процедура не знает их строк и оставила бы дефолт (1.0),
            // что дало бы скрытый бонус — поэтому форсим явно, как для §f§lHuman.
            if (HumanLikeRaces.isHumanLike(vars.Race) && vars.RaceStatMultiplier != 0.0) {
                vars.RaceStatMultiplier = 0.0;
                vars.markSyncDirty();
            }
        } catch (Exception ignored) {}
    }
}