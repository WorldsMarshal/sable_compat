package com.invfix.mixin;

import com.invfix.grab.GrabHandler;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Отключает родной GrabTicksProcedure (телепорт-снэппинг по сетке блоков) и направляет
 * его в автономный GrabHandler (механика из The Boys): первый тик активного эффекта —
 * захват цели перед игроком, далее — плавное держание на руке.
 *
 * Вызывается каждый тик, пока на игроке висит эффект GRABN_THROW_ACTIVE (из invincible).
 */
@Mixin(value = net.mcreator.invincibleinc.procedures.GrabTicksProcedure.class, remap = false)
public class GrabTicksProcedureMixin {

    @Inject(method = "execute(Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/entity/Entity;)V",
            at = @At("HEAD"), cancellable = true, remap = false)
    private static void invfix_grabTick(LevelAccessor world, Entity entity, CallbackInfo ci) {
        ci.cancel();
        if (!world.isClientSide() && entity instanceof ServerPlayer sp) {
            if (GrabHandler.isGrabbing(sp.getUUID())) {
                GrabHandler.handleHoldTick(sp);
            } else {
                GrabHandler.handleGrab(sp);
            }
        }
    }
}