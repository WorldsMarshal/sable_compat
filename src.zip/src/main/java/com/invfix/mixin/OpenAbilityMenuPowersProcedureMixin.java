package com.invfix.mixin;

import com.invfix.altrumite.AltrumiteRace;
import io.netty.buffer.Unpooled;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.procedures.OpenAbilityMenuPowersProcedure;
import net.mcreator.invincibleinc.world.inventory.AbilitiesMenuPowerViltrumiteMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Когда Altrumite открывает меню Power — показываем меню Вильтрумитов
 * (тот же набор способностей). Heat Vision-кнопку добавляет ScreenMixin.
 * Расы V без своей PWR — то же меню со способностями V (см. invfix_vPowerMenu).
 */
@Mixin(value = OpenAbilityMenuPowersProcedure.class, remap = false)
public class OpenAbilityMenuPowersProcedureMixin {

    @Inject(method = "execute", at = @At("HEAD"), remap = false)
    private static void invfix_altrumiteMenu(
            LevelAccessor world, double x, double y, double z, Entity entity, CallbackInfo ci) {
        if (entity == null) return;
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (!AltrumiteRace.isAltrumiteLike(vars.Race)) return;
            if (!(entity instanceof ServerPlayer sp)) return;

            final BlockPos bpos = BlockPos.containing(x, y, z);
            sp.openMenu(new MenuProvider() {
                public Component getDisplayName() {
                    return Component.literal("AbilitiesMenuPowerViltrumite");
                }
                public boolean shouldTriggerClientSideContainerClosingOnOpen() { return false; }
                public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
                    return new AbilitiesMenuPowerViltrumiteMenu(
                            id, inv, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(bpos));
                }
            }, bpos);
        } catch (Exception ignored) {}
    }

    /**
     * Расы V без своей вкладки PWR (Human, Human(Predisposition to V), Human(Born for V) без силы Invincible):
     * PWR — лист Вильтрумитов только со способностями V (VPowerMenu). Родная процедура для них открыла бы
     * Combos — отменяется.
     */
    @Inject(method = "execute", at = @At("HEAD"), cancellable = true, remap = false)
    private static void invfix_vPowerMenu(
            LevelAccessor world, double x, double y, double z, Entity entity, CallbackInfo ci) {
        if (!(entity instanceof ServerPlayer sp) || !com.invfix.vpower.VPowerMenu.ownPwr(sp)) return;
        final BlockPos bpos = BlockPos.containing(x, y, z);
        sp.openMenu(new MenuProvider() {
            public Component getDisplayName() {
                return Component.literal("AbilitiesMenuPowerViltrumite");
            }
            public boolean shouldTriggerClientSideContainerClosingOnOpen() { return false; }
            public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
                return new AbilitiesMenuPowerViltrumiteMenu(
                        id, inv, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(bpos));
            }
        }, bpos);
        ci.cancel();
    }
}