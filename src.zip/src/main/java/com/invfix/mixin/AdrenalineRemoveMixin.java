package com.invfix.mixin;

import com.invfix.humanlike.HumanLikeRaces;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.procedures.AdrenalizedProcedure;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Полностью выпиливает механику Adrenaline у Human и человекоподобных рас.
 *
 * Adrenaline целиком живёт в {@link AdrenalizedProcedure#execute}: именно там
 * (и только там) при ХП <= 30% навешивается эффект {@code ADRENALINE_EFFECT}
 * (1200 тиков, +20% к Str/Dura и Regen II через Start/End-процедуры эффекта).
 * Если процедура не отрабатывает — эффект не вешается, Start/End не срабатывают,
 * адреналина нет вообще.
 *
 * Поэтому на HEAD отменяем процедуру для:
 *   §f§lHuman                       — обычный Human;
 *   Human(Born for V) / (Predisposition to V) — наши расы-затычки.
 *
 * §f§lHuman-Viltrumite НЕ трогаем — у него Adrenalized сидит в racePassive4 и по
 * задаче должен остаться рабочим. Пассивку «Adrenalized» в меню НЕ снимаем
 * (PassiveUnlock не трогается), так что в UI она остаётся как и просили — просто
 * больше ничего не делает.
 */
@Mixin(value = AdrenalizedProcedure.class, remap = false)
public class AdrenalineRemoveMixin {

    private static final String HUMAN = "\u00a7f\u00a7lHuman";

    @Inject(method = "execute", at = @At("HEAD"), cancellable = true, remap = false)
    private static void invfix_noAdrenalineForHumans(LevelAccessor world, Entity entity, CallbackInfo ci) {
        if (entity == null) return;
        try {
            InvincibleIncModVariables.PlayerVariables v =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            String race = v.Race;
            if (HUMAN.equals(race) || HumanLikeRaces.isHumanLike(race)) {
                ci.cancel();
            }
        } catch (Exception ignored) {
            // нет PLAYER_VARIABLES / не игрок — оставляем оригинальное поведение
        }
    }
}