package com.invfix.mixin.aeroworks;

import com.invfix.aeroworks.HeavyGyroscopeBlockEntity;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.mred231.aeroworks.content.gyroscope.GyroscopeBlockEntity;
import com.mred231.aeroworks.content.gyroscope.GyroscopeController;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Делает авторитет гироскопа персональным.
 *
 * В Aeroworks он общий: {@code gyroAuthority(rpmScale)} умножает обороты на
 * единственное число из конфига, одинаковое для всех гироскопов флота. Тяжёлому
 * этого мало — ему нужно 4 000 000 против 5000 у обычного, а потолок конфига
 * вообще 1 000 000, так что настройкой файла задачу не решить.
 *
 * Перехватываем результат вызова и, если конкретный гироскоп в этой итерации
 * цикла оказался тяжёлым, пересчитываем по его собственной ставке. Локальная
 * переменная {@code gyro} достаётся через @Local из MixinExtras — обычный
 * @Redirect до неё не дотянулся бы, потому что видит только параметры метода.
 *
 * Обычные гироскопы проходят насквозь и работают ровно как раньше.
 */
@Mixin(value = GyroscopeController.class, remap = false)
public class GyroscopeControllerMixin {

    @ModifyExpressionValue(
            method = "computeFleetState",
            at = @At(value = "INVOKE",
                    target = "Lcom/mred231/aeroworks/content/gyroscope/GyroscopeController;gyroAuthority(D)D"),
            require = 0
    )
    private double invfix$heavyAuthority(double authority, @Local GyroscopeBlockEntity gyro) {
        if (!(gyro instanceof HeavyGyroscopeBlockEntity)) return authority;
        // authority = rpmScale * конфиг. Возвращаем ту же долю оборотов, но по
        // своей ставке, а не по общей.
        return gyro.currentRpmScale() * HeavyGyroscopeBlockEntity.AUTHORITY_PER_UNIT;
    }
}
