package com.invfix.mixin;

import com.invfix.combo.ComboImpact;
import net.mcreator.invincibleinc.procedures.BBThrownOnEffectActiveTickProcedure;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Тик эффекта BB_THROWN (цель, брошенная ударом): если цель бросил удар
 * Attackpwr > 1500 (ComboImpact пометил её), родной туннель заменяется
 * ComboImpact.heavyThrowTick. Остальные броски — родные.
 */
@Mixin(value = BBThrownOnEffectActiveTickProcedure.class, remap = false)
public class BBThrownProcedureMixin {

    @Inject(method = "execute", at = @At("HEAD"), cancellable = true, remap = false)
    private static void invfix_heavyThrow(LevelAccessor world, double x, double y, double z, Entity entity, CallbackInfo ci) {
        if (entity == null || !(world instanceof ServerLevel level)) return;
        if (ComboImpact.heavyThrowTick(level, entity, x, y, z)) ci.cancel();
    }
}
