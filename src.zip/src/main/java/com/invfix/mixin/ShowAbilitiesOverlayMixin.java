package com.invfix.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.mcreator.invincibleinc.client.screens.ShowAbilitiesOverlay;
import net.mcreator.invincibleinc.procedures.ShowAbilitiesDisplayOverlayIngameProcedure;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = ShowAbilitiesOverlay.class, remap = false)
public class ShowAbilitiesOverlayMixin {

    private static final float SCALE = 0.85f;

    @Inject(
            method = "eventHandler(Lnet/neoforged/neoforge/client/event/RenderGuiEvent$Pre;)V",
            at = @At("HEAD"), cancellable = true, remap = false
    )
    private static void invfix_scaleAbilitiesOverlay(RenderGuiEvent.Pre event, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui) { ci.cancel(); return; }

        Player entity = mc.player;
        if (entity == null) return;
        if (!ShowAbilitiesDisplayOverlayIngameProcedure.execute(entity)) return;

        GuiGraphics graphics = event.getGuiGraphics();
        PoseStack pose = graphics.pose();

        pose.pushPose();
        pose.scale(SCALE, SCALE, 1.0f);

        int x = 6;
        int baseY = 8;
        int step = 18;
        var font = mc.font;

        graphics.drawString(font, net.mcreator.invincibleinc.procedures.Ability1ShowProcedure.execute(entity),  x, baseY + step * 0, -1, false);
        graphics.drawString(font, net.mcreator.invincibleinc.procedures.Ability2ShowProcedure.execute(entity),  x, baseY + step * 1, -1, false);
        graphics.drawString(font, net.mcreator.invincibleinc.procedures.Ability3ShowProcedure.execute(entity),  x, baseY + step * 2, -1, false);
        graphics.drawString(font, net.mcreator.invincibleinc.procedures.Ability4ShowProcedure.execute(entity),  x, baseY + step * 3, -1, false);
        graphics.drawString(font, net.mcreator.invincibleinc.procedures.Ability5ShowProcedure.execute(entity),  x, baseY + step * 4, -1, false);
        graphics.drawString(font, net.mcreator.invincibleinc.procedures.Ability6ShowProcedure.execute(entity),  x, baseY + step * 5, -1, false);
        graphics.drawString(font, net.mcreator.invincibleinc.procedures.Ability7ShowProcedure.execute(entity),  x, baseY + step * 6, -1, false);
        graphics.drawString(font, net.mcreator.invincibleinc.procedures.Ability8ShowProcedure.execute(entity),  x, baseY + step * 7, -1, false);
        graphics.drawString(font, net.mcreator.invincibleinc.procedures.Ability9ShowProcedure.execute(entity),  x, baseY + step * 8, -1, false);
        graphics.drawString(font, net.mcreator.invincibleinc.procedures.Ability10ShowProcedure.execute(entity), x, baseY + step * 9, -1, false);

        pose.popPose();
        ci.cancel();
    }
}