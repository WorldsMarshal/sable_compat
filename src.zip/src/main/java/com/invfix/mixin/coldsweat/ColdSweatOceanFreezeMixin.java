package com.invfix.mixin.coldsweat;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.biome.Biome;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Реализм замерзания воды для Cold Sweat: океаны не замерзают.
 *
 * При включённом "Custom Freezing Behavior" Cold Sweat полностью подменяет ванильный
 * {@code Biome.shouldFreeze} своим {@code WorldHelper.shouldFreeze}, в котором:
 *   1) вода, окружённая льдом, замерзает БЕЗУСЛОВНО ({@code surroundedByBlock(..., ICE)});
 *   2) иначе — по температуре мира, БЕЗ какой-либо проверки биома.
 * Итог: одна опорная точка в океане зимой (сезонный оффсет из [Compatibility.Seasons])
 * запускает цепную реакцию — лёд разрастается от кромки лавинообразно и никогда не тает,
 * т.к. {@code shouldMelt} зимой всегда false. В реальности океан не замерзает из-за
 * перемешивания огромных масс воды и течений.
 *
 * Чиним оба метода у корня ({@code WorldHelper.shouldFreeze} / {@code shouldMelt}) —
 * они вызываются ТОЛЬКО из {@code MixinFreezingWater} (замерзание воды в мире и
 * {@code IceBlock.randomTick}), поэтому правка хирургическая: температура игрока,
 * айсбокс, hearth и прочее не затронуты.
 *
 * Список «незамерзающих» биомов — тег {@code #sable_compat:no_freeze}
 * (data/sable_compat/tags/worldgen/biome/no_freeze.json). Из коробки в нём все океаны,
 * КРОМЕ frozen_ocean / deep_frozen_ocean — полярные океаны мёрзнут, это тоже реализм.
 *
 * Бонус от melt-хука: уже наросший лёд в этих биомах сам постепенно растает
 * на random tick'ах (self-cleanup) — чистить существующие ледяные поля вручную не нужно.
 *
 * Реки/озёра/континентальная вода в тег НЕ входят и зимой мёрзнут как раньше.
 *
 * @Pseudo + require=0 + гейт в InvincibleIncMixinTransformer → без cold_sweat не применяется.
 */
@Pseudo
@Mixin(targets = "com.momosoftworks.coldsweat.util.world.WorldHelper", remap = false)
public class ColdSweatOceanFreezeMixin {

    @Unique
    private static final TagKey<Biome> INVFIX_NO_FREEZE = TagKey.create(
            Registries.BIOME,
            ResourceLocation.fromNamespaceAndPath("sable_compat", "no_freeze"));

    /**
     * Вода в биомах из тега не замерзает никогда.
     * HEAD-инжект срабатывает ДО безусловного surroundedByBlock(ICE) — цепная реакция
     * от опорных точек обрубается на корню.
     */
    @Inject(
            method = "shouldFreeze(Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;Z)Z",
            at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void invfix_noOceanFreeze(LevelAccessor levelReader, BlockPos pos, boolean mustBeAtEdge,
                                             CallbackInfoReturnable<Boolean> cir) {
        if (levelReader instanceof ServerLevel level && level.getBiome(pos).is(INVFIX_NO_FREEZE)) {
            cir.setReturnValue(false);
        }
    }

    /**
     * Лёд в биомах из тега всегда «хочет» растаять → существующие ледяные поля
     * в океанах постепенно исчезают сами, даже зимой.
     */
    @Inject(
            method = "shouldMelt(Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;Z)Z",
            at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void invfix_thawOceanIce(LevelAccessor levelReader, BlockPos pos, boolean mustBeAtEdge,
                                            CallbackInfoReturnable<Boolean> cir) {
        if (levelReader instanceof ServerLevel level && level.getBiome(pos).is(INVFIX_NO_FREEZE)) {
            cir.setReturnValue(true);
        }
    }
}