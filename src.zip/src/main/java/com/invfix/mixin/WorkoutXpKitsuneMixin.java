package com.invfix.mixin;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.procedures.WorkoutRightclickProcedure;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Тренировки (гантели, штанга): XP силы и защиты за подход = случайное число ×
 * XpMultiplier. Для всех рас одинаково, Kitsune качается в 3 раза быстрее
 * Metroman — значит и здесь ×3.
 */
@Mixin(value = WorkoutRightclickProcedure.class, remap = false)
public class WorkoutXpKitsuneMixin {

    @Redirect(
            method = "execute",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/mcreator/invincibleinc/network/InvincibleIncModVariables$PlayerVariables;XpMultiplier:D",
                    opcode = org.objectweb.asm.Opcodes.GETFIELD,
                    remap = false
            ),
            remap = false
    )
    private static double invfix$kitsuneWorkoutXp(InvincibleIncModVariables.PlayerVariables vars) {
        double mult = vars.XpMultiplier;
        if (com.invfix.kitsune.KitsuneRace.isKitsune(vars.Race)) mult *= com.invfix.kitsune.KitsuneRace.XP_FACTOR;
        return mult;
    }
}
