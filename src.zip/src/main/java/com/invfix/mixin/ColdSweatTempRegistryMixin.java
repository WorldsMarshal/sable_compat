package com.invfix.mixin;

import com.momosoftworks.coldsweat.api.registry.TempModifierRegistry;
import com.momosoftworks.coldsweat.api.registry.TempModifierRegistry.TempModifierHolder;
import com.momosoftworks.coldsweat.api.temperature.modifier.TempModifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ConcurrentModificationException;

/**
 * Заплатка над потокобезопасностью Cold Sweat.
 *
 * {@code TempModifierRegistry.getHolder} итерирует общий статический HashBiMap-реестр
 * ({@code TEMP_MODIFIERS}) напрямую и без всякой защиты. Если реестр в этот момент
 * структурно меняют (register/clear при reload датапаков/конфига или из другого мода-
 * аддона), гуавовский итератор кидает {@link ConcurrentModificationException} прямо в
 * тике температуры → краш сервера («Ticking entity»). Стек:
 *   HashBiMap$Itr.hasNext → TempModifierRegistry.getHolder → getKey → TempModifier.getID
 *   → Temperature.getImmunityToModifier → EntityTempManager.tickTemperature.
 *
 * Чиним сам {@code getHolder}: вместо прямой итерации берём НЕИЗМЕНЯЕМЫЙ снапшот
 * {@code getEntries()} (ImmutableBiMap) и ретраим, если снапшот не успел сняться из-за
 * параллельной правки. Это не лечит первопричину (Cold Sweat стоило бы синхронизировать
 * реестр), но убирает краш: в худшем случае — null (нет иммунитета в этот тик).
 *
 * @Pseudo + require=0 + гейт в InvincibleIncMixinTransformer → без cold_sweat не применяется.
 */
@Pseudo
@Mixin(targets = "com.momosoftworks.coldsweat.api.registry.TempModifierRegistry", remap = false)
public class ColdSweatTempRegistryMixin {

    @Inject(method = "getHolder", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void invfix_safeGetHolder(TempModifier modifier,
                                             CallbackInfoReturnable<TempModifierHolder> cir) {
        if (modifier == null) {
            cir.setReturnValue(null);
            return;
        }
        Class<?> wanted = modifier.getClass();

        for (int attempt = 0; attempt < 5; attempt++) {
            try {
                for (Object o : TempModifierRegistry.getEntries().values()) {
                    TempModifierHolder holder = (TempModifierHolder) o;
                    if (holder.getModifierClass() == wanted) {
                        cir.setReturnValue(holder);
                        return;
                    }
                }
                cir.setReturnValue(null);
                return;
            } catch (ConcurrentModificationException retry) {
                // реестр меняют прямо сейчас — пробуем ещё раз снять снапшот
            }
        }
        cir.setReturnValue(null); // не смогли снять чистый снапшот — без краша
    }
}
