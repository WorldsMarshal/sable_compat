package com.invfix.mixin.vanilla;

import com.invfix.rick.RickBloodline;
import com.invfix.rick.RickPanel;
import com.invfix.rick.RickVariantPackets;
import com.invfix.rick.client.RickPanelRenderer;
import com.invfix.rick.client.RickVariantsClient;
import net.neoforged.neoforge.network.PacketDistributor;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.InventoryMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Дорисовывает панель Рика НАД ванильным экраном инвентаря. Сам экран не
 * подменяется и не переписывается: книга рецептов, кнопки Curios и всё, что
 * другие моды навешивают на InventoryScreen, работает как работало.
 *
 * Единственное вмешательство в раскладку — сдвиг вниз, и только когда панели не
 * хватает места сверху. На широком GUI-масштабе сдвиг равен нулю и экран стоит
 * ровно там же, где стоял.
 */
@Mixin(InventoryScreen.class)
public abstract class InventoryScreenRickMixin extends AbstractContainerScreen<InventoryMenu> {

    protected InventoryScreenRickMixin() { super(null, null, null); }

    /** На сколько пикселей пришлось опустить окно, чтобы панель влезла. */
    @Unique private int invfix$shift;

    @Unique
    private boolean invfix$active() {
        return this.minecraft != null && this.minecraft.player != null
                && RickBloodline.is(this.minecraft.player);
    }

    @Inject(method = "init", at = @At("HEAD"))
    private void invfix$computeShift(CallbackInfo ci) {
        this.invfix$shift = 0;
        if (!invfix$active()) return;
        int natural = (this.height - 166) / 2;
        this.invfix$shift = Math.max(0, RickPanel.PANEL_H + 4 - natural);
    }

    /**
     * Книга рецептов позиционируется от переданной ей высоты экрана, а не от
     * topPos. Раздуваем высоту на удвоенный сдвиг — центр уезжает ровно на
     * величину сдвига, и книга остаётся вровень с инвентарём.
     *
     * require = 0 намеренно: если сигнатура RecipeBookComponent.init в этой версии
     * иная, инжект просто не применится, книга останется по центру, и хуже от
     * этого станет только выравнивание на маленьком масштабе.
     */
    @ModifyArg(
            method = "init",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/screens/recipebook/RecipeBookComponent;init(IILnet/minecraft/client/Minecraft;ZLnet/minecraft/world/inventory/RecipeBookMenu;)V"),
            index = 1,
            require = 0
    )
    private int invfix$shiftRecipeBook(int height) {
        return height + 2 * this.invfix$shift;
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void invfix$applyShift(CallbackInfo ci) {
        if (this.invfix$shift > 0) this.topPos += this.invfix$shift;
    }

    @Inject(method = "renderBg", at = @At("TAIL"))
    private void invfix$renderPanel(GuiGraphics g, float partialTick, int mouseX, int mouseY, CallbackInfo ci) {
        if (!invfix$active()) return;
        RickPanelRenderer.renderBackground(g, this.leftPos, this.topPos);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void invfix$renderPanelOverlay(GuiGraphics g, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        if (!invfix$active()) return;
        RickPanelRenderer.renderVariantControls(g, this.font, this.leftPos, this.topPos, mouseX, mouseY);
        RickPanelRenderer.renderTankTooltip(g, this.font, this.leftPos, this.topPos, mouseX, mouseY);
    }

    /**
     * Клик по стрелкам выбора варианта.
     *
     * Перехват идёт на HEAD и гасит клик целиком: стрелки нарисованы поверх
     * панели, и без отмены тот же клик ушёл бы дальше в обработку слотов.
     */
    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void invfix$variantClick(double mouseX, double mouseY, int button,
                                     CallbackInfoReturnable<Boolean> cir) {
        if (!invfix$active() || button != 0) return;

        int direction = RickPanelRenderer.arrowAt(this.leftPos, this.topPos, mouseX, mouseY);
        if (direction == 0) return;

        int next = RickVariantsClient.index() + direction;
        PacketDistributor.sendToServer(new RickVariantPackets.Select(next));

        if (this.minecraft != null) {
            this.minecraft.getSoundManager().play(
                    net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
                            net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK, 1.0F));
        }
        cir.setReturnValue(true);
    }
}