package com.invfix.mixin.vanilla;

import com.invfix.rick.RickEnchant;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.EnchantmentMenu;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Стол зачарований: у Rick C137 уровни перекатываются с потолком в десять
 * ванильных максимумов и случайным разбросом под ним.
 *
 * Ловим момент ПОСЛЕ того, как ваниль всё сделала — на RETURN из
 * {@code clickMenuButton(Player, int)} — и правим уже готовый предмет в слоте 0.
 * Так мы не завязаны на то, какими вызовами ваниль записывает зачарования
 * внутри метода: в 1.21.1 они стали дата-компонентом, и прежний перехват
 * ItemStack.enchant() не находил цели.
 *
 * Игрок берётся из параметра метода, поэтому приватные поля EnchantmentMenu не
 * нужны. Слот 0 в этом меню — сам зачаровываемый предмет (слот 1 — лазурит);
 * если на входе была книга, там уже лежит зачарованная книга, и её уровни
 * живут в STORED_ENCHANTMENTS — RickEnchant это учитывает.
 *
 * Побочный эффект, который тут кстати: потолок в 30 уровней обходится сам
 * собой, потому что умножение идёт после отбора зачарований, а не до.
 */
@Mixin(EnchantmentMenu.class)
public abstract class EnchantmentMenuRickMixin {

    @Inject(method = "clickMenuButton", at = @At("RETURN"))
    private void invfix_tripleEnchantLevel(Player player, int buttonId,
                                           CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue() == null || !cir.getReturnValue()) return;
        if (!RickEnchant.applies(player)) return;

        AbstractContainerMenu self = (AbstractContainerMenu) (Object) this;
        if (self.slots.isEmpty()) return;

        ItemStack enchanted = self.getSlot(0).getItem();
        RickEnchant.boostAll(enchanted, player.getRandom());
        self.getSlot(0).setChanged();
        self.broadcastChanges();
    }
}