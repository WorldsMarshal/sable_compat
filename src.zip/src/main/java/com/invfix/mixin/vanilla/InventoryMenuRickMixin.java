package com.invfix.mixin.vanilla;

import com.invfix.rick.RickMenuAccess;
import com.invfix.rick.RickPocket;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.InventoryMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Пристраивает слоты панели Рика к ванильному инвентарю — В КОНЕЦ, следом за
 * последним существующим слотом.
 *
 * Слоты добавляются ВСЕМ игрокам и ВСЕГДА, прямо в конструкторе. У не-Рика они
 * неактивны (см. RickPocket): экран их не рисует, кликнуть нельзя, mayPlace и
 * mayPickup закрыты. Функционально их для него нет.
 *
 * ПОЧЕМУ ИМЕННО ТАК, а не «добавлять только Рику».
 *
 * Условное добавление на лету разъезжается между сторонами и роняет клиент:
 *   IndexOutOfBoundsException: Index 48 out of bounds for length 48
 *   at AbstractContainerMenu.initializeContents
 * Сервер прислал содержимое на большее число слотов, чем есть у клиента.
 * Синхронизировать это пакетом невозможно надёжно: InventoryMenu создаётся в
 * конструкторе Player, до загрузки NBT, а пересоздаётся при респавне и смене
 * измерения — на клиенте и сервере в разные моменты. Любое окно между
 * добавлением слотов на одной стороне и на другой ловит ClientboundContainerSetContentPacket
 * и падает.
 *
 * Конструктор же выполняется на обеих сторонах одинаково и безусловно, поэтому
 * число слотов совпадает всегда. Цена — 33 пустых слота в контейнере у игроков
 * без родословной; они не сохраняются, не рисуются и стоят ровно ничего.
 *
 * Ванильные индексы (0 результат, 1-4 крафт, 5-8 броня, 9-35 инвентарь,
 * 36-44 хотбар, 45 офхенд) не сдвигаются, поэтому ванильный quickMoveStack,
 * книга рецептов и моды, лезущие в слоты по индексу, ничего не замечают. Моды,
 * которые сами дописывают слоты в конец (например createcybernetics), встанут
 * до или после нас в зависимости от порядка миксинов — но одинаково на обеих
 * сторонах, так что рассинхрона это не даёт.
 */
@Mixin(InventoryMenu.class)
public abstract class InventoryMenuRickMixin extends AbstractContainerMenu
        implements RickMenuAccess.PocketHolder {

    @Unique private RickPocket invfix$pocket;

    protected InventoryMenuRickMixin() { super(null, 0); }

    @Inject(method = "<init>", at = @At("RETURN"))
    private void invfix$addRickSlots(Inventory inventory, boolean active, Player owner, CallbackInfo ci) {
        this.invfix$pocket = new RickPocket((AbstractContainerMenu) (Object) this, owner);
        this.invfix$pocket.addSlots(this::addSlot);
    }

    @Override
    public RickPocket invfix$pocket() { return this.invfix$pocket; }

    @Inject(method = "slotsChanged", at = @At("HEAD"), cancellable = true)
    private void invfix$gridChanged(Container container, CallbackInfo ci) {
        if (this.invfix$pocket == null) return;
        if (container == this.invfix$pocket.grid()) {
            this.invfix$pocket.onGridChanged();
            ci.cancel();
        }
    }

    @Inject(method = "removed", at = @At("TAIL"))
    private void invfix$dropRickContents(Player player, CallbackInfo ci) {
        if (this.invfix$pocket != null) this.invfix$pocket.dropAll(player);
    }
}
