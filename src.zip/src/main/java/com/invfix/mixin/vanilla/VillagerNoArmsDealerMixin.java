package com.invfix.mixin.vanilla;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerData;
import net.minecraft.world.entity.npc.VillagerProfession;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Полная блокировка профессии Arms Dealer из Pointblank.
 *
 * Профессия регистрируется как {@code pointblank:arms_dealer} и привязана к POI
 * того же имени поверх блока-верстака мода. В сборке оружие достаётся тяжело, а
 * торговля с этим жителем обходит всю цепочку — поэтому профессия режется.
 *
 * Хук стоит на {@code Villager.setVillagerData}, через которую проходят ОБА пути:
 * и получение профессии живым жителем у рабочего места, и восстановление
 * профессии из NBT при загрузке чанка. Поэтому уже существующие Arms Dealer'ы
 * теряют профессию при повторной прогрузке — ровно то поведение, что нужно, без
 * ковыряния в сохранениях.
 *
 * Сравнение идёт по строке ResourceLocation, прямых ссылок на классы Pointblank
 * нет — миксин безвреден, если мода в сборке не окажется.
 *
 * Дополнительно из тега acquirable_job_site убран сам POI (см. датапак-оверрайд
 * в data/minecraft/tags/point_of_interest_type). Без этого житель бесконечно
 * пытался бы занять верстак, каждый раз получая отказ здесь.
 */
@Mixin(Villager.class)
public abstract class VillagerNoArmsDealerMixin {

    @Unique
    private static final ResourceLocation invfix$ARMS_DEALER =
            ResourceLocation.fromNamespaceAndPath("pointblank", "arms_dealer");

    @ModifyVariable(method = "setVillagerData", at = @At("HEAD"), argsOnly = true)
    private VillagerData invfix$blockArmsDealer(VillagerData data) {
        if (data == null) return null;

        VillagerProfession profession = data.getProfession();
        if (profession == null) return data;

        ResourceLocation id = BuiltInRegistries.VILLAGER_PROFESSION.getKey(profession);
        if (!invfix$ARMS_DEALER.equals(id)) return data;

        // Профессия снимается, уровень откатывается на первый — иначе останется
        // безработный житель с пятым уровнем торговли.
        return new VillagerData(data.getType(), VillagerProfession.NONE, 1);
    }
}