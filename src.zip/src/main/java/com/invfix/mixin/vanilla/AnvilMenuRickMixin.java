package com.invfix.mixin.vanilla;

import com.invfix.rick.RickEnchant;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Наковальня: у Rick C137 потолок объединения втрое выше.
 *
 * Работаем на TAIL из {@code createResult()} — ваниль уже собрала результат и
 * обрезала уровни по ванильному максимуму, а мы пересчитываем их по своему
 * правилу и дописываем обратно. Перехватывать сам кламп внутри метода не стали
 * намеренно: это привязка к конкретной строке ванильного кода, а она между
 * версиями переезжает.
 *
 * Правило слияния повторяет ванильное: равные уровни дают +1, разные — больший
 * из двух. Совместимость зачарований проверять не нужно — если зачарование
 * дошло до результата, ваниль его уже пропустила.
 *
 * Игрок берётся через ItemCombinerMenuPlayerAccessor: поле player объявлено в
 * ItemCombinerMenu, и @Shadow из миксина на AnvilMenu его не видит.
 *
 * Слоты ItemCombinerMenu: 0 — левый предмет, 1 — жертва, 2 — результат.
 * Стоимость в уровнях не пересчитываем: получается дешевле, чем «честно», и
 * это осознанная поблажка, а не недосмотр.
 */
@Mixin(AnvilMenu.class)
public abstract class AnvilMenuRickMixin {

    @Inject(method = "createResult", at = @At("TAIL"))
    private void invfix_tripleAnvilCap(CallbackInfo ci) {
        Player player = ((ItemCombinerMenuPlayerAccessor) (Object) this).invfix$player();
        if (!RickEnchant.applies(player)) return;

        AbstractContainerMenu self = (AbstractContainerMenu) (Object) this;
        if (self.slots.size() < 3) return;

        ItemStack left = self.getSlot(0).getItem();
        ItemStack right = self.getSlot(1).getItem();
        ItemStack result = self.getSlot(2).getItem();
        if (result.isEmpty() || left.isEmpty()) return;

        DataComponentType<ItemEnchantments> type =
                result.has(DataComponents.STORED_ENCHANTMENTS)
                        ? DataComponents.STORED_ENCHANTMENTS
                        : DataComponents.ENCHANTMENTS;

        ItemEnchantments current = result.getOrDefault(type, ItemEnchantments.EMPTY);
        if (current.isEmpty()) return;

        ItemEnchantments.Mutable mutable = new ItemEnchantments.Mutable(current);
        boolean changed = false;

        for (Holder<Enchantment> holder : current.keySet()) {
            int have = current.getLevel(holder);
            int l = levelOf(left, holder);
            int r = levelOf(right, holder);
            if (l == 0 && r == 0) continue;

            int want = RickEnchant.mergedLevel(l, r, holder.value().getMaxLevel());
            if (want > have) {
                mutable.set(holder, want);
                changed = true;
            }
        }

        if (changed) {
            result.set(type, mutable.toImmutable());
            self.getSlot(2).setChanged();
        }
    }

    /** Уровень зачарования на предмете, с учётом того, что у книг он в STORED. */
    private static int levelOf(ItemStack stack, Holder<Enchantment> holder) {
        if (stack.isEmpty()) return 0;
        DataComponentType<ItemEnchantments> type =
                stack.has(DataComponents.STORED_ENCHANTMENTS)
                        ? DataComponents.STORED_ENCHANTMENTS
                        : DataComponents.ENCHANTMENTS;
        return stack.getOrDefault(type, ItemEnchantments.EMPTY).getLevel(holder);
    }
}