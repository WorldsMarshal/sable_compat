package com.invfix.mixin.vanilla;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Gives Silk Touch drops to blocks registered with {@code noLootTable()}.
 *
 * Create Aeronautics does exactly that for levitite:
 *
 *     REGISTRATE.block("levitite", Block::new)
 *               .properties(BlockBehaviour.Properties::noLootTable)
 *
 * With an EMPTY loot table vanilla returns an empty drop list immediately, so
 * neither a datapack loot table nor a BlockDropsEvent listener can put the
 * block back - the short circuit happens first. Block#getDrops is the one
 * place every break path goes through, so we answer there.
 *
 * Which blocks this applies to is a tag, so it needs no recompiling to extend:
 *     data/sable_compat/tags/block/silk_touch_drops.json
 */
@Mixin(Block.class)
public class BlockSilkDropsMixin {

    @Unique
    private static final TagKey<Block> INVFIX_SILK_DROPS = BlockTags.create(
            ResourceLocation.fromNamespaceAndPath("sable_compat", "silk_touch_drops"));

    @Inject(
            method = "getDrops(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/item/ItemStack;)Ljava/util/List;",
            at = @At("HEAD"),
            cancellable = true)
    private static void invfix$silkTouchDrops(BlockState state, ServerLevel level, BlockPos pos,
                                              @Nullable BlockEntity be, @Nullable Entity entity,
                                              ItemStack tool,
                                              CallbackInfoReturnable<List<ItemStack>> cir) {
        if (tool == null || tool.isEmpty()) return;
        if (!state.is(INVFIX_SILK_DROPS)) return;

        var silk = level.registryAccess()
                .lookupOrThrow(Registries.ENCHANTMENT)
                .getOrThrow(Enchantments.SILK_TOUCH);
        if (EnchantmentHelper.getItemEnchantmentLevel(silk, tool) <= 0) return;

        ItemStack drop = new ItemStack(state.getBlock());
        if (drop.isEmpty()) return;      // no item form: leave vanilla alone
        cir.setReturnValue(List.of(drop));
    }
}