package com.invfix.mixin.vanilla;

import net.minecraft.world.level.levelgen.structure.pools.SinglePoolElement;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Шаблон элемента пула — тот же, по которому он ставит блоки (TattooistHutStructureMixin). */
@Mixin(SinglePoolElement.class)
public interface SinglePoolElementTemplateInvoker {

    @Invoker("getTemplate")
    StructureTemplate invfix$getTemplate(StructureTemplateManager structureTemplateManager);
}
