package com.invfix.mixin.vanilla;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ItemCombinerMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Доступ к полю {@code player} наковальни.
 *
 * Поле объявлено в {@link ItemCombinerMenu}, а не в AnvilMenu, и {@code @Shadow}
 * из миксина, нацеленного на AnvilMenu, его не находит — Mixin резолвит шадоу
 * строго в целевом классе, а не по иерархии. Поэтому аксессор вешается на тот
 * класс, где поле реально объявлено, а AnvilMenuRickMixin просто кастуется к
 * этому интерфейсу.
 */
@Mixin(ItemCombinerMenu.class)
public interface ItemCombinerMenuPlayerAccessor {

    @Accessor("player")
    Player invfix$player();
}
