package com.invfix.mixin.createcybernetics;

import com.invfix.mixin.vanilla.SinglePoolElementTemplateInvoker;
import com.perigrine3.createcybernetics.entity.ModEntities;
import com.perigrine3.createcybernetics.entity.custom.TatHogEntity;
import com.perigrine3.createcybernetics.event.custom.TattooistHutChunkLoadHandler;
import com.perigrine3.createcybernetics.world.TattooistHutSpawnData;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.structure.PoolElementStructurePiece;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.StructureStart;
import net.minecraft.world.level.levelgen.structure.pools.SinglePoolElement;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.level.ChunkEvent;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Хижина татуировщика — по данным структуры, без перебора блоков.
 *
 * Мод на каждый новый чанк перебирал все его блоки по высоте мира (384 × 16 × 16 вызовов level.getBlockState),
 * искал нижнюю половину искажённой двери и проверял вокруг неё стволы, незерак и грибосвет. Хижина — структура
 * createcybernetics:tattooist_hut (worldgen/structure/tattooist_hut.json): один кусок пула
 * createcybernetics:tattooist_hut_pool, шаблон createcybernetics:tattooist_hut (5×5×5, проекция rigid, без
 * процессоров), дверь в шаблоне одна.
 *
 * Здесь: в новом чанке — ссылки на эту структуру из самого чанка (getReferencesForStructure, без чтения блоков).
 * Нет ссылок — хижины в чанке нет, дальше ничего. Есть — как у мода, обработка отложена на основной поток:
 * старты структуры (ванильный StructureManager), у каждого куска — нижняя половина искажённой двери из его
 * шаблона с поворотом и позицией куска (StructureTemplate.filterBlocks — та же формула, по которой кусок ставит
 * блоки). Дверь в этом чанке и в мире на месте — якорь. Дальше без изменений: учёт TattooistHutSpawnData по
 * тому же ключу (позиция нижней половины двери — уже записанные хижины остаются записанными), проверка TatHog
 * рядом, то же место появления (findSpawnSpot мода) и та же выдача TatHog.
 */
@Mixin(value = TattooistHutChunkLoadHandler.class, remap = false)
public abstract class TattooistHutStructureMixin {

    @Unique
    private static final ResourceKey<Structure> INVFIX$HUT =
            ResourceKey.create(Registries.STRUCTURE, ResourceLocation.fromNamespaceAndPath("createcybernetics", "tattooist_hut"));

    @Shadow
    @Nullable
    private static BlockPos findSpawnSpot(ServerLevel level, BlockPos anchor) {
        throw new AssertionError();
    }

    @Inject(method = "onChunkLoad", at = @At("HEAD"), cancellable = true, require = 0)
    private static void invfix$byStructure(ChunkEvent.Load event, CallbackInfo ci) {
        ci.cancel();
        if (!event.isNewChunk() || !(event.getLevel() instanceof ServerLevel level)) return;
        Structure hut = level.registryAccess().registryOrThrow(Registries.STRUCTURE).get(INVFIX$HUT);
        if (hut == null) return;
        LongSet refs = event.getChunk().getReferencesForStructure(hut);
        if (refs.isEmpty()) return;
        ChunkPos chunkPos = event.getChunk().getPos();
        LongSet starts = new LongOpenHashSet(refs);
        level.getServer().execute(() -> invfix$process(level, hut, chunkPos, starts));
    }

    @Unique
    private static void invfix$process(ServerLevel level, Structure hut, ChunkPos chunkPos, LongSet starts) {
        level.structureManager().fillStartsForStructure(hut, starts, start -> {
            BlockPos anchor = invfix$doorInChunk(level, start, chunkPos);
            if (anchor != null) invfix$spawn(level, anchor);
        });
    }

    /** Нижняя половина искажённой двери из шаблона куска, если она в этом чанке и стоит в мире. */
    @Unique
    @Nullable
    private static BlockPos invfix$doorInChunk(ServerLevel level, StructureStart start, ChunkPos chunkPos) {
        for (StructurePiece piece : start.getPieces()) {
            if (!(piece instanceof PoolElementStructurePiece poolPiece)
                    || !(poolPiece.getElement() instanceof SinglePoolElement element)) continue;
            StructureTemplate template =
                    ((SinglePoolElementTemplateInvoker) element).invfix$getTemplate(level.getStructureManager());
            StructurePlaceSettings settings = new StructurePlaceSettings().setRotation(poolPiece.getRotation());
            List<StructureTemplate.StructureBlockInfo> doors =
                    template.filterBlocks(poolPiece.getPosition(), settings, Blocks.WARPED_DOOR);
            for (StructureTemplate.StructureBlockInfo door : doors) {
                BlockPos pos = door.pos();
                if (!invfix$lowerDoor(door.state())
                        || SectionPos.blockToSectionCoord(pos.getX()) != chunkPos.x
                        || SectionPos.blockToSectionCoord(pos.getZ()) != chunkPos.z) continue;
                if (invfix$lowerDoor(level.getChunk(chunkPos.x, chunkPos.z).getBlockState(pos))) return pos.immutable();
            }
        }
        return null;
    }

    /** Выдача TatHog — как TattooistHutChunkLoadHandler.processNewChunk после нахождения якоря. */
    @Unique
    private static void invfix$spawn(ServerLevel level, BlockPos anchor) {
        TattooistHutSpawnData data = TattooistHutSpawnData.get(level);
        long anchorKey = anchor.asLong();
        if (data.hasSpawnedAt(anchorKey)) return;
        List<TatHogEntity> existing = level.getEntitiesOfClass(TatHogEntity.class, new AABB(anchor).inflate(8.0));
        if (!existing.isEmpty()) {
            data.markSpawned(anchorKey);
            return;
        }
        BlockPos spawnPosBlock = findSpawnSpot(level, anchor);
        if (spawnPosBlock == null) return;
        TatHogEntity tatHog = ModEntities.TATHOG.get().create(level);
        if (tatHog == null) return;
        Vec3 spawnPos = Vec3.atBottomCenterOf(spawnPosBlock).add(0.0, 0.1, 0.0);
        tatHog.setPersistenceRequired();
        tatHog.moveTo(spawnPos.x, spawnPos.y, spawnPos.z, 180.0F, 0.0F);
        DifficultyInstance difficulty = level.getCurrentDifficultyAt(spawnPosBlock);
        tatHog.finalizeSpawn(level, difficulty, MobSpawnType.STRUCTURE, null);
        if (level.addFreshEntity(tatHog)) data.markSpawned(anchorKey);
    }

    @Unique
    private static boolean invfix$lowerDoor(BlockState state) {
        return state.is(Blocks.WARPED_DOOR)
                && state.hasProperty(DoorBlock.HALF)
                && state.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER;
    }
}
