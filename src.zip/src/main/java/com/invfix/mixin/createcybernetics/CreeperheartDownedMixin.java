package com.invfix.mixin.createcybernetics;

import com.invfix.compat.LovsDowned;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Creeperheart взрывается на смерти владельца — и на «падении» LovsPlayer тоже (та же отменённая позже
 * смерть). Пока смерть превращается в «падение» (LovsDowned#willDown) — не взрывается; взорвётся при
 * окончательной смерти.
 */
@Mixin(targets = "com.perigrine3.createcybernetics.item.cyberware.heart.CreeperheartItem$Events", remap = false)
public abstract class CreeperheartDownedMixin {

    @Inject(method = "onLivingDeath", at = @At("HEAD"), cancellable = true, require = 0)
    private static void invfix$notWhileDowned(LivingDeathEvent event, CallbackInfo ci) {
        if (event.getEntity() instanceof ServerPlayer player && LovsDowned.willDown(player, event.getSource())) ci.cancel();
    }
}
