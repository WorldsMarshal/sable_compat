package com.invfix.mixin.createcybernetics;

import com.perigrine3.createcybernetics.loot.AddItemModifier;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Set;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Убирает импланты Create Cybernetics из сундуков.
 *
 * Весь лут мод раздаёт одним типом глобального модификатора,
 * {@code createcybernetics:add_item}, — полторы сотни файлов с одним и тем же
 * классом внутри. Перебивать их по одному нашими датапак-файлами можно, но это
 * полторы сотни копий, зависящих от порядка загрузки ресурсов; одна точка входа
 * надёжнее и переживает обновление мода, пока класс называется так же.
 *
 * Режется только импланты и только из неживого лута. Части тел с мобов - мозг,
 * печень, сухожилия - остаются: это сырьё для крафта, а не готовые импланты, и
 * без них ломается вся производственная цепочка мода. Нейропозин, осколки данных
 * и компоненты тоже остаются по той же причине.
 */
@Mixin(value = AddItemModifier.class, remap = false)
public abstract class AddItemModifierMixin {

    @Shadow
    private Item item;

    /**
     * Семейства предметов, которые считаются готовыми имплантами.
     *
     * По префиксу, а не списком: мод регулярно добавляет новые железки в те же
     * семейства, и список пришлось бы догонять каждое обновление.
     */
    @Unique
    private static final Set<String> INVFIX$IMPLANT_PREFIXES = Set.of(
            "scavenged_", "basecyberware_", "armupgrades_", "legupgrades_",
            "boneupgrades_", "brainupgrades_", "heartupgrades_", "organsupgrades_",
            "organsupgrade_", "skinupgrades_", "eyeupgrades_", "lungupgrades_",
            "chipware_");

    @Inject(method = "doApply", at = @At("HEAD"), cancellable = true, require = 0)
    private void invfix$dropImplantLoot(ObjectArrayList<ItemStack> generatedLoot,
                                        LootContext context,
                                        CallbackInfoReturnable<ObjectArrayList<ItemStack>> cir) {
        if (item == null) return;

        ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
        if (id == null || !"createcybernetics".equals(id.getNamespace())) return;

        String path = id.getPath();
        boolean implant = false;
        for (String prefix : INVFIX$IMPLANT_PREFIXES) {
            if (path.startsWith(prefix)) {
                implant = true;
                break;
            }
        }
        if (!implant) return;

        // лут с существ не трогаем: там имплантов и так нет, а лишний отказ
        // однажды съел бы что-нибудь нужное
        ResourceLocation table = context.getQueriedLootTableId();
        if (table != null && table.getPath().startsWith("entities/")) return;

        cir.setReturnValue(generatedLoot);
    }
}
