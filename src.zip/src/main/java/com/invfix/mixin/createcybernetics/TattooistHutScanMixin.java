package com.invfix.mixin.createcybernetics;

import com.perigrine3.createcybernetics.event.custom.TattooistHutChunkLoadHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Поиск хижины татуировщика в новом чанке. Мод перебирает все блоки чанка по высоте мира (384 × 16 × 16)
 * через level.getBlockState — каждый вызов заново ищет чанк в кэше сервера; после респавна и при полёте
 * это сотни новых чанков подряд на основном потоке (spark: ~1,2 с в минуту с респавном).
 * Здесь тот же обход в том же порядке (y, затем x, затем z) и та же проверка, но блоки читаются прямо из
 * секций этого чанка, а секции без нижней половины искажённой двери в палитре пропускаются целиком —
 * результат тот же, что у мода. В мире отладки (у LevelChunk там свои блоки) — родной поиск.
 */
@Mixin(value = TattooistHutChunkLoadHandler.class, remap = false)
public abstract class TattooistHutScanMixin {

    @Shadow
    private static boolean looksLikeTattooistHut(ServerLevel level, BlockPos doorPos) {
        throw new AssertionError();
    }

    @Inject(method = "findTattooistHutAnchor", at = @At("HEAD"), cancellable = true, require = 0)
    private static void invfix$scanSections(ServerLevel level, LevelChunk chunk, CallbackInfoReturnable<BlockPos> cir) {
        if (level.isDebug()) return;
        ChunkPos chunkPos = chunk.getPos();
        int minX = chunkPos.getMinBlockX();
        int minZ = chunkPos.getMinBlockZ();
        int minY = level.getMinBuildHeight();
        int maxY = level.getMaxBuildHeight();
        BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();
        LevelChunkSection[] sections = chunk.getSections();
        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection section = sections[i];
            if (section == null || section.hasOnlyAir() || !section.maybeHas(state -> invfix$lowerDoor(state))) continue;
            int baseY = chunk.getSectionYFromSectionIndex(i) << 4;
            for (int ly = 0; ly < 16; ly++) {
                int y = baseY + ly;
                if (y < minY || y >= maxY) continue;
                for (int lx = 0; lx < 16; lx++) {
                    for (int lz = 0; lz < 16; lz++) {
                        if (!invfix$lowerDoor(section.getBlockState(lx, ly, lz))) continue;
                        mutable.set(minX + lx, y, minZ + lz);
                        if (looksLikeTattooistHut(level, mutable)) {
                            cir.setReturnValue(mutable.immutable());
                            return;
                        }
                    }
                }
            }
        }
        cir.setReturnValue(null);
    }

    /** Условие мода для якоря: нижняя половина искажённой двери. */
    @Unique
    private static boolean invfix$lowerDoor(BlockState state) {
        return state.is(Blocks.WARPED_DOOR)
                && state.hasProperty(DoorBlock.HALF)
                && state.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER;
    }
}
