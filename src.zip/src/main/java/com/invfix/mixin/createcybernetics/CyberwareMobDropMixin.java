package com.invfix.mixin.createcybernetics;

import com.perigrine3.createcybernetics.common.organs.CyberwareDeathReset;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Мобы с имплантами больше их не роняют.
 *
 * Киберзомби и киберскелет отдавали снятые импланты, смэшер, хогбой, панклин и
 * пигстром - целые. Всё это идёт через один {@code dropInstalledCyberware},
 * поэтому хватает одной отмены: путь игрока в том же обработчике отдельный и
 * сюда не заходит, но проверка на игрока стоит на случай, если мод однажды
 * сведёт ветки вместе.
 *
 * Остальное на смерти моба не трогается - опыт, обычный лут, сброс данных
 * киберware у игрока работают как работали.
 */
@Mixin(value = CyberwareDeathReset.class, remap = false)
public abstract class CyberwareMobDropMixin {

    @Inject(method = "dropInstalledCyberware", at = @At("HEAD"), cancellable = true, require = 0)
    private static void invfix$noMobImplantDrops(LivingEntity entity, boolean scavenged,
                                                 CallbackInfo ci) {
        if (entity instanceof Player) return;
        ci.cancel();
    }
}
