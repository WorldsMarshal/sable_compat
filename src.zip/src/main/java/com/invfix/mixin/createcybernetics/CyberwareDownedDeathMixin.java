package com.invfix.mixin.createcybernetics;

import com.invfix.compat.LovsDowned;
import com.perigrine3.createcybernetics.common.organs.CyberwareDeathReset;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Импланты и органы игрока (и труп Corpse, капсула опыта, содержимое имплантов) выпадают только при
 * настоящей смерти. Мод роняет их на LivingDeathEvent обычного приоритета, а LovsPlayer отменяет смерть
 * от другого игрока позже (LOWEST) — «падение»: раньше всё высыпалось из ещё живого игрока. Если LovsPlayer
 * эту смерть отменит (LovsDowned#willDown), обработчик не идёт; окончательная смерть упавшего
 * (DownedServer#finalDeath — снова LivingDeathEvent) роняет всё как обычно.
 */
@Mixin(value = CyberwareDeathReset.class, remap = false)
public abstract class CyberwareDownedDeathMixin {

    @Inject(method = "onPlayerDeath", at = @At("HEAD"), cancellable = true, require = 0)
    private static void invfix$notWhileDowned(LivingDeathEvent event, CallbackInfo ci) {
        if (event.getEntity() instanceof ServerPlayer player && LovsDowned.willDown(player, event.getSource())) ci.cancel();
    }
}
