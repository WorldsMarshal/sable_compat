package com.invfix.mixin;

import com.invfix.RaceCapsUtil;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public class RaceCapsMixin {

    // ── Уровень ───────────────────────────────────────────
    @Mixin(value = net.mcreator.invincibleinc.procedures.LvlStatUpProcedure.class, remap = false)
    public static class LvlCapMixin {
        @Inject(
                method = "execute(Lnet/minecraft/world/level/LevelAccessor;DDDLnet/minecraft/world/entity/Entity;)V",
                at = @At("HEAD"), cancellable = true, remap = false
        )
        private static void invfix_capLevel(
                LevelAccessor world, double x, double y, double z,
                Entity entity, CallbackInfo ci) {
            if (entity == null) return;
            try {
                InvincibleIncModVariables.PlayerVariables vars =
                        entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                double cap = RaceCapsUtil.getLevelCap(vars.Race);
                if (cap > 0 && vars.Lvl >= cap) {
                    vars.xp = 0;
                    vars.markSyncDirty();
                    ci.cancel();
                }
            } catch (Exception ignored) {}
        }
    }

    // ── Сила ──────────────────────────────────────────────
    @Mixin(value = net.mcreator.invincibleinc.procedures.StrStatUpProcedure.class, remap = false)
    public static class StrCapMixin {
        @Inject(
                method = "execute(Lnet/minecraft/world/level/LevelAccessor;DDDLnet/minecraft/world/entity/Entity;)V",
                at = @At("HEAD"), cancellable = true, remap = false
        )
        private static void invfix_capStr(
                LevelAccessor world, double x, double y, double z,
                Entity entity, CallbackInfo ci) {
            if (RaceCapsUtil.isAtCap(entity)) {
                try {
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES).strengthXP = 0;
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES).markSyncDirty();
                } catch (Exception ignored) {}
                ci.cancel();
            }
        }
    }

    // ── Стойкость ─────────────────────────────────────────
    @Mixin(value = net.mcreator.invincibleinc.procedures.DuraStatUpProcedure.class, remap = false)
    public static class DuraCapMixin {
        @Inject(
                method = "execute(Lnet/minecraft/world/level/LevelAccessor;DDDLnet/minecraft/world/entity/Entity;)V",
                at = @At("HEAD"), cancellable = true, remap = false
        )
        private static void invfix_capDura(
                LevelAccessor world, double x, double y, double z,
                Entity entity, CallbackInfo ci) {
            if (RaceCapsUtil.isAtCap(entity)) {
                try {
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES).defenseXP = 0;
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES).markSyncDirty();
                } catch (Exception ignored) {}
                ci.cancel();
            }
        }
    }

    // ── Здоровье ──────────────────────────────────────────
    @Mixin(value = net.mcreator.invincibleinc.procedures.HealthStatUpProcedure.class, remap = false)
    public static class HealthCapMixin {

        /**
         * HEAD: если игрок уже на капе уровней — сбрасываем healthXP и отменяем.
         * Если вильтрумит/Beast на HP-капе (currentHealth >= 200) — тоже отменяем.
         *
         * Зачем HEAD достаточно для HP-капы:
         * HealthStatUpProcedure — это while-цикл «пока healthXP >= healthXPcap».
         * Мы обнуляем healthXP ДО входа в цикл, поэтому условие while сразу
         * ложно и процедура не добавит ни одной единицы HP.
         */
        @Inject(
                method = "execute(Lnet/minecraft/world/level/LevelAccessor;DDDLnet/minecraft/world/entity/Entity;)V",
                at = @At("HEAD"), cancellable = true, remap = false
        )
        private static void invfix_capHealth(
                LevelAccessor world, double x, double y, double z,
                Entity entity, CallbackInfo ci) {
            if (entity == null) return;
            try {
                InvincibleIncModVariables.PlayerVariables v =
                        entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);

                // 1. Уровневая капа (общая)
                if (RaceCapsUtil.isAtCap(entity)) {
                    v.healthXP = 0;
                    v.markSyncDirty();
                    ci.cancel();
                    return;
                }

                // 2. HP-капа для вильтрумитов и Beast: currentHealth >= 200
                //    currentHealth — это именно тот счётчик, который процедура
                //    инкрементирует на 1 за итерацию while.
                String race = v.Race;
                if (("§4§lViltrumite".equals(race) || "§4§lBeast".equals(race))
                        && v.currentHealth >= 200) {
                    v.healthXP = 0;
                    v.markSyncDirty();
                    ci.cancel();
                }
            } catch (Exception ignored) {}
        }

        /**
         * TAIL: страховочный зажим после того как while-цикл отработал.
         * Нужен на случай если процедура каким-то образом всё же проскочила HEAD
         * (например первый вход когда currentHealth был 199 и цикл сделал 1 шаг).
         * Обрезаем currentHealth и синхронизируем атрибут MAX_HEALTH.
         */
        @Inject(
                method = "execute(Lnet/minecraft/world/level/LevelAccessor;DDDLnet/minecraft/world/entity/Entity;)V",
                at = @At("TAIL"), remap = false
        )
        private static void invfix_clampHealth(
                LevelAccessor world, double x, double y, double z,
                Entity entity, CallbackInfo ci) {
            if (entity == null) return;
            try {
                InvincibleIncModVariables.PlayerVariables v =
                        entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                String race = v.Race;
                if (!"§4§lViltrumite".equals(race) && !"§4§lBeast".equals(race)) return;

                if (v.currentHealth > 200) {
                    double overshoot = v.currentHealth - 200;
                    v.currentHealth = 200;
                    v.healthXP = 0;
                    v.markSyncDirty();

                    // Синхронизируем атрибут MAX_HEALTH обратно
                    if (entity instanceof LivingEntity living) {
                        var attr = living.getAttribute(Attributes.MAX_HEALTH);
                        if (attr != null) {
                            attr.setBaseValue(attr.getBaseValue() - overshoot);
                        }
                    }
                }
            } catch (Exception ignored) {}
        }
    }

    // ── Скорость ──────────────────────────────────────────
    @Mixin(value = net.mcreator.invincibleinc.procedures.SpeedStatUpProcedure.class, remap = false)
    public static class SpeedCapMixin {
        @Inject(
                method = "execute(Lnet/minecraft/world/level/LevelAccessor;DDDLnet/minecraft/world/entity/Entity;)V",
                at = @At("HEAD"), cancellable = true, remap = false
        )
        private static void invfix_capSpeed(
                LevelAccessor world, double x, double y, double z,
                Entity entity, CallbackInfo ci) {
            if (RaceCapsUtil.isAtCap(entity)) {
                try {
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES).speedXP = 0;
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES).markSyncDirty();
                } catch (Exception ignored) {}
                ci.cancel();
            }
        }
    }
}