package com.invfix.mixin;

import com.invfix.compat.pointblank.PointBlankDamageMarker;
import com.invfix.threatmode.ThreatModeState;
import net.mcreator.invincibleinc.init.InvincibleIncModMobEffects;
import com.invfix.heatvision.HeatVisionHandler;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LevelAccessor;
import net.neoforged.bus.api.Event;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Патч AttackDuraProcedure — ТОЛЬКО АТАКА.
 *
 * ИЗМЕНЕНИЕ ОТНОСИТЕЛЬНО ПРЕЖНЕЙ ВЕРСИИ:
 * защита отсюда убрана полностью. Раньше здесь стояло плоское вычитание
 * DamageTolerance, а снаряды смягчались отдельным обработчиком с другими
 * правилами — две несогласованные ветки, плюс тип invincible_inc:powers
 * не смягчался нигде.
 *
 * Теперь миксин выставляет СЫРОЙ исходящий урон (ванильный + бонус attackPower),
 * а всё смягчение делает ViltrumiteImmunityHandler#onIncomingDamage на
 * EventPriority.LOWEST через DamageMath. Одна формула на все типы урона.
 */
@Mixin(value = net.mcreator.invincibleinc.procedures.AttackDuraProcedure.class, remap = false)
public class AttackDuraProcedureMixin {

    @Inject(
            method = "execute(Lnet/neoforged/bus/api/Event;" +
                    "Lnet/minecraft/world/level/LevelAccessor;" +
                    "Lnet/minecraft/world/damagesource/DamageSource;" +
                    "Lnet/minecraft/world/entity/Entity;" +
                    "Lnet/minecraft/world/entity/Entity;)V",
            at = @At("HEAD"),
            cancellable = true,
            remap = false
    )
    private static void invfix_hybridDamage(
            Event event, LevelAccessor world, DamageSource damagesource,
            Entity entity, Entity sourceentity, CallbackInfo ci) {

        ci.cancel();

        if (damagesource == null || entity == null || sourceentity == null) return;
        if (world.isClientSide()) return;

        boolean isPhysicalAttack = (sourceentity instanceof Mob || sourceentity instanceof Player)
                && (damagesource.is(DamageTypes.PLAYER_ATTACK)
                || damagesource.is(ResourceKey.create(Registries.DAMAGE_TYPE,
                ResourceLocation.parse("invincible_inc:attack_power"))));

        // Heat Disruption, Dismantle и Energy Blast бьют своими типами (свои сообщения о смерти),
        // но в остальном это тот же урон способностями, что invincible_inc:powers
        boolean isPowerAttack = sourceentity instanceof Player
                && (damagesource.is(ResourceKey.create(Registries.DAMAGE_TYPE,
                ResourceLocation.parse("invincible_inc:powers")))
                || damagesource.is(ResourceKey.create(Registries.DAMAGE_TYPE,
                ResourceLocation.parse("sable_compat:heat_disruption")))
                || damagesource.is(ResourceKey.create(Registries.DAMAGE_TYPE,
                ResourceLocation.parse("sable_compat:dismantle")))
                || damagesource.is(ResourceKey.create(Registries.DAMAGE_TYPE,
                ResourceLocation.parse("sable_compat:energy_blast")))
                || damagesource.is(ResourceKey.create(Registries.DAMAGE_TYPE,
                ResourceLocation.parse("sable_compat:space_fold"))));

        if (isPhysicalAttack && event instanceof LivingIncomingDamageEvent lie) {

            // ── Урон: ванильный + бонус от attackPower ───────────────────
            float vanillaAmount = lie.getAmount();
            double attackBonus = 0;
            double attackPower = 0;

            try {
                attackPower = sourceentity.getData(InvincibleIncModVariables.PLAYER_VARIABLES).attackPower;
                attackBonus = Math.max(0.0, attackPower - 1.0);
            } catch (Exception ignored) {}

            // Threatening/Playful Mode: пока зажат бинд, обычная атака ЛКМ бьёт
            // как у ваниль-игрока — без силового скейла.
            if (damagesource.is(DamageTypes.PLAYER_ATTACK) && ThreatModeState.isHeld(sourceentity)) {
                attackBonus = 0.0;
                attackPower = 0.0;
            }

            // PointBlank: выстрелы не получают силовой стат-бонус атаки.
            if (PointBlankDamageMarker.isActive()) {
                attackBonus = 0.0;
                attackPower = 0.0;
            }

            // Сырой исходящий урон. Смягчение — в ViltrumiteImmunityHandler.
            lie.setAmount((float) (vanillaAmount + attackBonus));

            // ── Партиклы (attackPower >= 80) ──────────────────────────────
            if (attackPower >= 80.0) {
                boolean skipParticle = false;
                if (sourceentity instanceof LivingEntity living) {
                    skipParticle = living.hasEffect(InvincibleIncModMobEffects.BARRAGE_PUNCH)
                            || living.hasEffect(InvincibleIncModMobEffects.HEAVY_PUNCH_CD);
                }
                if (HeatVisionHandler.isActive(sourceentity)) {
                    skipParticle = true;
                }
                if (!skipParticle && sourceentity.getServer() != null
                        && sourceentity.level() instanceof ServerLevel sl) {
                    sourceentity.getServer().getCommands().performPrefixedCommand(
                            new CommandSourceStack(CommandSource.NULL,
                                    sourceentity.position(), sourceentity.getRotationVector(),
                                    sl, 4, sourceentity.getName().getString(),
                                    sourceentity.getDisplayName(),
                                    sourceentity.level().getServer(), sourceentity),
                            "particle invincible_inc:hit_particle ^ ^1.5 ^1.2"
                    );
                }
            }

            applyInCombat(entity);
            applyInCombat(sourceentity);
            setCombatTarget(entity, sourceentity);
            setCombatTarget(sourceentity, entity);
        }

        if (isPowerAttack) {
            try {
                InvincibleIncModVariables.PlayerVariables v =
                        sourceentity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                v.masteryXP += Mth.nextInt(RandomSource.create(), 1, 5);
                v.markSyncDirty();
            } catch (Exception ignored) {}

            applyInCombat(entity);
            applyInCombat(sourceentity);
            setCombatTarget(entity, sourceentity);
            setCombatTarget(sourceentity, entity);
        }
    }

    private static void applyInCombat(Entity e) {
        if (e instanceof LivingEntity le && !le.level().isClientSide()) {
            le.addEffect(new MobEffectInstance(
                    InvincibleIncModMobEffects.IN_COMBAT, 200, 1, false, false));
        }
    }

    private static void setCombatTarget(Entity target, Entity attacker) {
        try {
            InvincibleIncModVariables.PlayerVariables v =
                    target.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            v.InCombatWith = attacker.getDisplayName().getString();
            v.markSyncDirty();
        } catch (Exception ignored) {}
    }
}
