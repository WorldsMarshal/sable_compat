package com.invfix.mixin;

import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Аксессор к приватным final-полям {@link RangedAttribute}.
 *
 * Ванильные атрибуты объявлены как RangedAttribute с жёстко зашитым диапазоном:
 *   MAX_HEALTH     — [1.0, 1024.0]
 *   MAX_ABSORPTION — [0.0, 2048.0]
 *   ATTACK_DAMAGE  — [0.0, 2048.0]
 *
 * Диапазон применяется в RangedAttribute#sanitizeValue(double), который вызывается
 * из AttributeInstance#calculateValue(). Важная деталь: setBaseValue() НЕ санитайзит
 * значение при записи — оно хранится сырым и сырым же уходит в NBT. Санитайз
 * происходит только на чтении через getValue().
 *
 * Практическое следствие для invincible_inc: HealthStatUpProcedure честно накрутила
 * baseValue до 38445, но getMaxHealth() возвращал clamp(38445, 1, 1024) = 1024.
 * То есть данные не потеряны — достаточно поднять потолок, и реальное HP встанет
 * на своё место без миграции сейвов.
 *
 * @Mutable нужен, потому что поля объявлены final.
 */
@Mixin(RangedAttribute.class)
public interface RangedAttributeAccessor {

    @Mutable
    @Accessor("maxValue")
    void invfix$setMaxValue(double value);

    @Mutable
    @Accessor("minValue")
    void invfix$setMinValue(double value);

    @Accessor("maxValue")
    double invfix$getMaxValue();

    @Accessor("minValue")
    double invfix$getMinValue();
}
