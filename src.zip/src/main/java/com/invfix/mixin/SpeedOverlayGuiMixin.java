package com.invfix.mixin;

import net.mcreator.invincibleinc.client.screens.ShowFlightSpeedOverlayGUIOverlay;
import net.mcreator.invincibleinc.client.screens.ShowSpeedOverlayGUIOverlay;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public class SpeedOverlayGuiMixin {

    @Mixin(value = ShowSpeedOverlayGUIOverlay.class, remap = false)
    public static class SpeedMixin {
        @Inject(
                method = "eventHandler(Lnet/neoforged/neoforge/client/event/RenderGuiEvent$Pre;)V",
                at = @At("HEAD"), cancellable = true, remap = false
        )
        private static void invfix_checkGuiFlag(RenderGuiEvent.Pre event, CallbackInfo ci) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options.hideGui) { ci.cancel(); return; }
            Player player = mc.player;
            if (player == null) return;
            try {
                if (!player.getData(InvincibleIncModVariables.PLAYER_VARIABLES).showabilityGUI)
                    ci.cancel();
            } catch (Exception ignored) {}
        }
    }

    @Mixin(value = ShowFlightSpeedOverlayGUIOverlay.class, remap = false)
    public static class FlightSpeedMixin {
        @Inject(
                method = "eventHandler(Lnet/neoforged/neoforge/client/event/RenderGuiEvent$Pre;)V",
                at = @At("HEAD"), cancellable = true, remap = false
        )
        private static void invfix_checkGuiFlag(RenderGuiEvent.Pre event, CallbackInfo ci) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options.hideGui) { ci.cancel(); return; }
            Player player = mc.player;
            if (player == null) return;
            try {
                if (!player.getData(InvincibleIncModVariables.PLAYER_VARIABLES).showabilityGUI)
                    ci.cancel();
            } catch (Exception ignored) {}
        }
    }
}