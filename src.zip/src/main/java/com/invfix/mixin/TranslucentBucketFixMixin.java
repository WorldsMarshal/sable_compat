package com.invfix.mixin;

import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Фикс розлива жидкостей при установленном The Boys.
 *
 * Оригинальный TranslucentPowderRevealHandler глобально перехватывает ПКМ с
 *   - ведром воды   (WATER_BUCKET)
 *   - ведром молока (MILK_BUCKET)
 *   - костной мукой (BONE_MEAL)
 * и всегда отменяет событие (setCanceled(true)), тратя предмет на "облако
 * проявления" невидимого супа (TranslucentEntity) — даже если рядом НЕТ ни
 * одного такого супа. Из-за этого нельзя вылить воду/молоко из ведра и нельзя
 * нормально использовать костную муку.
 *
 * Решение: в HEAD обоих обработчиков проверяем, есть ли рядом живой
 * TranslucentEntity. Если нет — отменяем сам callback (ci.cancel()), оригинал
 * не выполняется, событие НЕ отменяется → срабатывает ванильное поведение
 * (розлив ведра / удобрение). Если суп рядом есть — пропускаем дальше, и
 * механика проявления работает как задумано.
 *
 * Класс TranslucentEntity не доступен на этапе компиляции (@Pseudo-таргет),
 * поэтому ищем его по имени класса через иерархию суперклассов, обращаясь
 * только к ванильному Entity.
 *
 * @Pseudo + require=0 + проверка в плагине (shouldApplyMixin) → без мода
 * The Boys миксин не применяется и ничего не ломает.
 */
@Pseudo
@Mixin(targets = "net.benniao.theboysmod.server.TranslucentPowderRevealHandler", remap = false)
public class TranslucentBucketFixMixin {

    private static final String TRANSLUCENT_CLASS =
            "net.benniao.theboysmod.entity.supe.TranslucentEntity";

    @Inject(method = "onRightClickItem", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void invfix_fixBucketItem(PlayerInteractEvent.RightClickItem event, CallbackInfo ci) {
        invfix_gate(event.getEntity(), event.getItemStack(), event.getLevel(), ci);
    }

    @Inject(method = "onRightClickBlock", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void invfix_fixBucketBlock(PlayerInteractEvent.RightClickBlock event, CallbackInfo ci) {
        invfix_gate(event.getEntity(), event.getItemStack(), event.getLevel(), ci);
    }

    private static void invfix_gate(Player player, ItemStack stack, Level level, CallbackInfo ci) {
        // Оригинал работает только на сервере и только с этими тремя предметами.
        if (!(player instanceof ServerPlayer)) {
            return;
        }
        if (stack == null
                || !(stack.is(Items.WATER_BUCKET)
                || stack.is(Items.MILK_BUCKET)
                || stack.is(Items.BONE_MEAL))) {
            return;
        }
        if (!invfix_translucentNearby(player, level)) {
            // Рядом нет невидимого супа → проявлять некого → отдаём предмет ванили.
            ci.cancel();
        }
    }

    private static boolean invfix_translucentNearby(Player player, Level level) {
        if (level == null) {
            return false;
        }
        // Облако проявления уходит до ~3 блоков вперёд и имеет радиус ~2.75/1.85,
        // поэтому берём запас 6 блоков по горизонтали и 4 по вертикали.
        AABB box = player.getBoundingBox().inflate(6.0, 4.0, 6.0);
        List<Entity> found = level.getEntitiesOfClass(
                Entity.class, box, e -> e.isAlive() && invfix_isTranslucent(e));
        return !found.isEmpty();
    }

    private static boolean invfix_isTranslucent(Entity e) {
        for (Class<?> c = e.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            if (TRANSLUCENT_CLASS.equals(c.getName())) {
                return true;
            }
        }
        return false;
    }
}