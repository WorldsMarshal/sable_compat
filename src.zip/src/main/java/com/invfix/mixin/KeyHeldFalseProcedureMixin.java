package com.invfix.mixin;

import com.invfix.heatvision.HeatVisionHandler;
import net.mcreator.invincibleinc.procedures.KeyHeldFalseProcedure;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Когда игрок отпускает клавишу способности — деактивируем Heat Vision.
 */
@Mixin(value = KeyHeldFalseProcedure.class, remap = false)
public class KeyHeldFalseProcedureMixin {

    @Inject(method = "execute", at = @At("HEAD"), remap = false)
    private static void invfix_heatVisionDeactivate(Entity entity, CallbackInfo ci) {
        if (entity != null && !entity.level().isClientSide()) {
            HeatVisionHandler.deactivate(entity);
        }
    }
}