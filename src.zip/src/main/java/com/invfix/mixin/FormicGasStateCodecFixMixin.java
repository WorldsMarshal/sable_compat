package com.invfix.mixin;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import net.minecraft.nbt.CompoundTag;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/**
 * Фикс невалидного кодека термодинамического состояния FormicAPI.
 *
 * Симптом: вход в мир падает с «Packet handling error» по цепочке
 * HeatExchangerBlockEntity.read → FluidTank.readFromNBT → FluidStack.parse →
 * OptionalFieldCodec.decode → RecordCodecBuilder$Instance.ap3 →
 * DataResult$Success.result → Optional.of → NPE. Один блок с «неудачным»
 * состоянием воды делает мир недоступным: пакет block_entity_data не
 * skippable и валит клиент до появления в игре.
 *
 * Причина: SpecificRealGasState.CODEC объявляет необязательные поля как
 * Codec.FLOAT.optionalFieldOf("temperature", (Object) null) — то есть с
 * дефолтом null. DFU это не поддерживает: при отсутствии поля декодер
 * отдаёт Success(null), а RecordCodecBuilder оборачивает результат в
 * Optional.of и мгновенно ловит NPE.
 *
 * Поля temperature / specific_entropy / vapor_quality заполняются лениво и
 * штатно бывают null: таков DEFAULT_STATE, его же возвращает
 * FullTableBased.mix() при NaN или T > 20000 K, и его же подставляет
 * StateFluidTank.getState() в стек без компонента. serialize() такие поля
 * просто не пишет — и следующее чтение из NBT становится фатальным.
 * Обычно спасает то, что DEFAULT_STATE — общий изменяемый синглтон и первый
 * же вызов temperature() заполняет его поля навсегда; краш ловит тот, у кого
 * стек ушёл в сохранение или синхронизацию раньше этого момента.
 *
 * Фикс: подменяем CODEC на пару serialize() / конструктор от CompoundTag —
 * собственные методы мода, которые с null-полями работают корректно (через
 * них же устроен рабочий STREAM_CODEC). Формат данных на диске не меняется:
 * те же имена и типы полей, отсутствующие поля читаются как null. Совместимо
 * в обе стороны — уже сохранённые миры читаются без правки NBT.
 *
 * Реализация через рефлексию, чтобы не требовать formicapi в compile
 * classpath; миксин применяется только при загруженном formicapi
 * (см. {@link com.invfix.compat.InvincibleIncMixinTransformer}).
 */
@Mixin(targets = "com.rae.formicapi.content.thermal_utilities.SpecificRealGasState", remap = false)
public abstract class FormicGasStateCodecFixMixin {

    @Unique private static final Logger INVFIX_LOGGER = LogUtils.getLogger();

    @Shadow @Final @Mutable public static Codec CODEC;

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Inject(method = "<clinit>", at = @At("TAIL"))
    private static void invfix$replaceBrokenCodec(CallbackInfo ci) {
        try {
            Class<?> stateClass = Class.forName(
                    "com.rae.formicapi.content.thermal_utilities.SpecificRealGasState");
            final Constructor<?> fromTag = stateClass.getConstructor(CompoundTag.class);
            final Method serialize = stateClass.getMethod("serialize");

            CODEC = CompoundTag.CODEC.xmap(
                    tag -> {
                        try {
                            return fromTag.newInstance(tag);
                        } catch (Throwable t) {
                            throw new IllegalStateException(
                                    "invfix: не удалось собрать состояние из NBT", t);
                        }
                    },
                    state -> {
                        try {
                            return (CompoundTag) serialize.invoke(state);
                        } catch (Throwable t) {
                            throw new IllegalStateException(
                                    "invfix: не удалось сериализовать состояние", t);
                        }
                    });

            INVFIX_LOGGER.info(
                    "[sable_compat] Кодек SpecificRealGasState заменён: необязательные "
                            + "поля (temperature/specific_entropy/vapor_quality) больше не "
                            + "роняют декодирование при отсутствии в NBT");
        } catch (Throwable t) {
            // Несовместимая версия formicapi — оставляем оригинальный кодек,
            // поведение возвращается к ванильному поведению библиотеки.
            INVFIX_LOGGER.warn(
                    "[sable_compat] Не удалось заменить кодек SpecificRealGasState "
                            + "(несовместимая версия formicapi?): {}", t.toString());
        }
    }
}