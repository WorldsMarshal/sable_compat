package com.invfix.mixin;

import com.invfix.theboys.BornForVPowers;
import com.invfix.theboys.HumanCompoundV;
import com.invfix.theboys.TheBoysSkillState;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Поведение препарата V для расы Human, встроенное в The Boys.
 *
 * @Pseudo + require=0 + remap=false + гейт в InvincibleIncMixinTransformer
 * (shouldApplyMixin) → без мода The Boys миксины не применяются, и расы
 * остаются обычными людьми.
 *
 * Сами таргет-методы оперируют только ванильными типами (ServerPlayer/String/
 * ItemStack), поэтому здесь нет ни одного прямого импорта классов The Boys.
 * Параметр SkillData недоступен по типу — берём его как {@code @Coerce Object}.
 */
public final class TheBoysHumanVMixins {

    private TheBoysHumanVMixins() {}

    /**
     * Перехват самой инъекции. injectTarget — единая точка для всех шприцев.
     * Сигнатура: boolean injectTarget(ServerPlayer injector, ServerPlayer target,
     *                                 String syringeType, ItemStack syringeStack)
     */
    @Pseudo
    @Mixin(targets = "net.benniao.theboysmod.network.InjectVPacket", remap = false)
    public static class InjectV {
        @Inject(
                method = "injectTarget",
                at = @At("HEAD"),
                cancellable = true,
                remap = false,
                require = 0
        )
        private static void invfix_humanV(ServerPlayer injector, ServerPlayer target,
                                          String syringeType, ItemStack syringeStack,
                                          CallbackInfoReturnable<Boolean> cir) {
            if (target == null || syringeType == null) return;

            // Born for V — фиксированный набор сил Хоумлендера на максимуме.
            // Только перманентный Compound V; Temp V у этой расы остаётся штатным.
            if ("compound_v_syringe".equals(syringeType)
                    && BornForVPowers.isBornForV(target)) {
                int result = BornForVPowers.grantHomelanderKit(target);
                if (result == BornForVPowers.RESULT_DEFER) {
                    return; // под Temp V — пусть отрабатывает штатная механика
                }
                if (result == BornForVPowers.RESULT_GRANTED) {
                    if (syringeStack != null && !syringeStack.isEmpty()) {
                        syringeStack.shrink(1);
                    }
                    cir.setReturnValue(true);
                } else { // RESULT_ALREADY_MAXED — шприц не тратим
                    cir.setReturnValue(false);
                }
                return;
            }

            if (!HumanCompoundV.isHuman(target)) return;

            boolean cancel;
            switch (syringeType) {
                case "compound_v_syringe":
                    // V уже прижился (есть перм-скилл) — второй укол идёт лишь на
                    // прокачку, шанса на провал быть не должно. Отдаём штатной
                    // логике прокачки без броска на смерть/тошноту.
                    if (TheBoysSkillState.hasPermanentSkill(target)) {
                        return;
                    }
                    cancel = HumanCompoundV.handleCompoundV(target, syringeStack);
                    break;
                case "compound_v_temp_syringe":
                    cancel = HumanCompoundV.handleTempV(target);
                    break;
                default:
                    return; // remove-шприц и прочее — без изменений
            }
            if (cancel) {
                cir.setReturnValue(false);
            }
        }
    }

    /**
     * Хвост обработчика распада Temp V — накладываем Critical Poisoning для Human.
     * Покрывает все пути истечения (тик, перед новой инъекцией, debug-команда).
     * Сигнатура: void onTemporaryVExpired(ServerPlayer player, SkillData data, long gameTime)
     */
    @Pseudo
    @Mixin(targets = "net.benniao.theboysmod.server.TempVSideEffectHandler", remap = false)
    public static class TempVExpiry {
        @Inject(
                method = "onTemporaryVExpired",
                at = @At("TAIL"),
                remap = false,
                require = 0
        )
        private static void invfix_humanSideEffects(ServerPlayer player, @Coerce Object data,
                                                    long gameTime, CallbackInfo ci) {
            HumanCompoundV.onTempVExpired(player);
        }
    }
}