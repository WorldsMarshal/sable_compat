package com.invfix.mixin.pointblank;

import com.invfix.compat.pointblank.FlaxanBlasterEnergy;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Заряд бластера сразу виден в счётчике патронов.
 *
 * Point Blank ведёт патроны на клиенте сам: выстрел уменьшает локальный счётчик
 * GunClientState, а значение со стека (серверное) он берёт только в syncAmmo —
 * не во время стрельбы/перезарядки и не раньше чем через 100 тиков после
 * последней синхронизации или выстрела (updateState, clientSyncTimeout = 100).
 * Для патронов это верно: сервер пополняет их только перезарядкой, а у неё свой
 * путь (reloadAmmo). Но заряд Рика идёт прямо в руках, 45 000 FE/т — почти по
 * выстрелу в тик: на сервере бластер полон, а клиент продолжает считать вниз,
 * доходит до нуля и не даёт стрелять, пока не выждет эти 100 тиков.
 *
 * Правка: у бластера, как только патронов на стеке стало больше, чем в прошлый
 * тик (пополнить их может только заряд), счётчик сразу берётся со стека. Стек во
 * время стрельбы отстаёт от клиента лишь на выстрелы «в пути», и без заряда число
 * на нём только убывает — тогда всё идёт по-старому.
 */
@Mixin(targets = "com.vicmatskiv.pointblank.client.GunClientState", remap = false)
public abstract class PointBlankBlasterAmmoSyncMixin {

    @Unique
    private int invfix$lastStackShots = -1;

    @Inject(method = "updateState", at = @At("TAIL"), remap = false)
    private void invfix$followBlasterCharge(LivingEntity player, ItemStack itemStack, boolean isSelected,
                                            CallbackInfo ci) {
        if (!FlaxanBlasterEnergy.isBlaster(itemStack)) return;
        if (player != Minecraft.getInstance().player) return;   // как в самом updateState

        int shots = FlaxanBlasterEnergy.shots(itemStack);
        int previous = invfix$lastStackShots;
        invfix$lastStackShots = shots;
        if (previous < 0 || shots <= previous) return;

        PointBlankGunClientStateInvoker self = (PointBlankGunClientStateInvoker) (Object) this;
        if (self.invfix$isReloading()) return;
        self.invfix$syncAmmo(player.level(), itemStack);
    }
}
