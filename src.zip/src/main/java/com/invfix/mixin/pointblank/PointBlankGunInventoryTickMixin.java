package com.invfix.mixin.pointblank;

import com.invfix.compat.pointblank.FlaxanBlasterEnergy;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * После inventoryTick пушки Point Blank (он же при первом тике инициализирует
 * стек и выставляет ammo = 0) переносим в патроны энергию, влитую в бластер
 * до инициализации, и выбираем встроенный прицел (без этого Point Blank не
 * рисует PIP-линзу). См. {@link FlaxanBlasterEnergy}.
 */
@Mixin(targets = "com.vicmatskiv.pointblank.item.GunItem", remap = false)
public class PointBlankGunInventoryTickMixin {

    @Inject(method = "inventoryTick", at = @At("TAIL"), remap = false)
    private void invfix$foldBlasterEnergy(ItemStack stack, Level level, Entity entity, int slot, boolean selected,
                                          CallbackInfo ci) {
        if (level.isClientSide || !FlaxanBlasterEnergy.isBlaster(stack)) return;
        FlaxanBlasterEnergy.ensureBuiltInScopeSelected(stack);
        if (FlaxanBlasterEnergy.pending(stack) >= FlaxanBlasterEnergy.FE_PER_SHOT) {
            FlaxanBlasterEnergy.fold(stack);
        }
    }
}
