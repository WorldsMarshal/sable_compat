package com.invfix.mixin.pointblank;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Доступ к клиентскому состоянию пушки Point Blank (GunClientState, 1.11.1):
 * {@code private void syncAmmo(Level, ItemStack)} — переписывает предсказанный
 * клиентом счётчик патронов значением из стека (то есть с сервера);
 * {@code public boolean isReloading()}.
 */
@Mixin(targets = "com.vicmatskiv.pointblank.client.GunClientState", remap = false)
public interface PointBlankGunClientStateInvoker {

    @Invoker(value = "syncAmmo", remap = false)
    void invfix$syncAmmo(Level level, ItemStack itemStack);

    @Invoker(value = "isReloading", remap = false)
    boolean invfix$isReloading();
}
