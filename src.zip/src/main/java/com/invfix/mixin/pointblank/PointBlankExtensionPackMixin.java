package com.invfix.mixin.pointblank;

import com.invfix.compat.pointblank.SableWeaponsPack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Перед поиском паков расширений Point Blank кладём в его папку наш пак оружия
 * (см. {@link SableWeaponsPack}). discoverExtensions вызывается один раз, из
 * PointBlankInitializer при конструировании мода, — раньше регистрации предметов.
 */
@Mixin(targets = "com.vicmatskiv.pointblank.registry.ExtensionRegistry", remap = false)
public class PointBlankExtensionPackMixin {

    @Inject(method = "discoverExtensions", at = @At("HEAD"))
    private void invfix$installSableWeapons(CallbackInfo ci) {
        SableWeaponsPack.install();
    }
}
