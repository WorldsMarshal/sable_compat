package com.invfix.mixin.pointblank;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Ребаланс PointBlank — этап 1.
 *
 * Полностью отключает выпадение {@code GUNMETAL_NUGGET} из мобов.
 * В оригинале это единственный источник появления gunmetal в мире:
 * {@code CommonEventHandler#onLivingDrops} с шансом {@code Config.itemDropChance}
 * (по умолчанию 0.35) навешивает самородок на любого {@code Monster}.
 * Других путей попадания gunmetal в мир (лут-таблицы, трейды) в PointBlank нет.
 *
 * Метод {@code onLivingDrops} в оригинале не делает ничего, кроме добавления
 * этого дропа, поэтому отмена всего тела на HEAD безопасна и не затрагивает
 * прочую логику мода. Решение зашито в сборку и не зависит от конфига PointBlank.
 *
 * Применяется только если загружен мод pointblank (гейт в
 * InvincibleIncMixinTransformer).
 */
@Mixin(targets = "com.vicmatskiv.pointblank.CommonEventHandler", remap = false)
public class GunmetalDropSuppressMixin {

    @Inject(method = "onLivingDrops", at = @At("HEAD"), cancellable = true, remap = false)
    private void invfix_suppressGunmetalDrop(CallbackInfo ci) {
        ci.cancel();
    }
}
