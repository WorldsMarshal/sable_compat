package com.invfix.mixin;

import com.invfix.stats.ShieldConfig;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Глобальный предохранитель скорости сущностей.
 *
 * ── ПРИЧИНА ──────────────────────────────────────────────────────────────────
 * HeavyAttackProcedure (и родственные SonicPunch/BarragePunch) считает нокбек как
 *
 *     knockback = (currentStr атакующего − currentDura цели) × 0.07
 *     target.setDeltaMovement(look × knockback)
 *
 * Кламп в процедуре есть (>=10 → 5.0), но стоит ДО пересчёта в той же итерации
 * цикла — в setDeltaMovement всегда уходит свежее, неклампленное значение.
 * При currentStr ~1.5M цель получает скорость ~105 000 блоков/тик; Entity.move()
 * делает свип-проверку коллизий вдоль всего вектора и тянет генерацию чанков по
 * траектории — ТПС умирает с одного удара ПКМ. Удар площадной, целей может быть
 * несколько за раз.
 *
 * ── ПОЧЕМУ ГЛОБАЛЬНО, А НЕ В ПРОЦЕДУРЕ ───────────────────────────────────────
 * Запуск сидит в лямбдах внутри queueServerWork 432-строчной MCreator-процедуры,
 * продублирован в двух ветках (полёт/земля) и в соседних панчах — точечные
 * миксины в синтетические методы хрупкие. Кап на самом сеттере скорости закрывает
 * все ветки разом и ничего легитимного не задевает: ни один ванильный или модовый
 * механизм (снаряды, взрывы, элитры, поршни) не выдаёт и доли VELOCITY_CAP.
 *
 * ── ВЫБОР ЗНАЧЕНИЯ ───────────────────────────────────────────────────────────
 * Кап откалиброван по последней эпохе, в которой игрок эмпирически НЕ ловил
 * отмирание ТПС: attackPower ~50 000 → по формуле статов
 * currentStr = 1 + 49 999/(0.25 × 4.5) = 44 445 → нокбек 44 445 × 0.07 ≈ 3 111.
 * Направление сохраняется, режется только длина вектора.
 */
@Mixin(Entity.class)
public class EntityVelocityCapMixin {

    @ModifyVariable(
            method = "setDeltaMovement(Lnet/minecraft/world/phys/Vec3;)V",
            at = @At("HEAD"),
            argsOnly = true
    )
    private Vec3 invfix$capVelocity(Vec3 motion) {
        if (motion == null) return null;

        double capSq = ShieldConfig.VELOCITY_CAP * ShieldConfig.VELOCITY_CAP;
        double lenSq = motion.lengthSqr();

        if (!(lenSq > capSq) || !Double.isFinite(lenSq)) {
            // NaN/Infinity тоже гасим — ноль безопаснее ракеты в никуда.
            if (!Double.isFinite(lenSq)) return Vec3.ZERO;
            return motion;
        }

        return motion.scale(ShieldConfig.VELOCITY_CAP / Math.sqrt(lenSq));
    }
}
