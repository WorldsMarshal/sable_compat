package com.invfix.mixin;

import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Термодинамический предохранитель: не даёт воде набрать энтальпию выше
 * домена паровых таблиц FormicAPI.
 *
 * Нагрев в обменнике идёт через FullTableBased.isobaricTransfer — голую
 * арифметику «h += тепло/масса» без ограничений. Всё остальное (T, x,
 * расширение в турбине) считается из таблиц, у которых конечный домен.
 * За его границей: отображаемая температура зажимается у потолка
 * (~2905 °C), обменник вечно видит положительную ΔT и вечно качает
 * энтальпию в невидимое число, а нулевая ступень турбины через разницу
 * «безлимитный вход − зажатый выход» выгребает сотни миллионов ЕН,
 * пока float не деградирует до NaN и всё не встанет.
 *
 * Фикс: после каждого isobaricTransfer проверяем, «переваривает» ли ещё
 * таблица получившуюся энтальпию (пар x=1 и dT/dh == 0 — значит упёрлись
 * в потолок). Если упёрлись — бинарным поиском находим максимальную
 * энтальпию, которую таблица ещё различает при этом давлении, и зажимаем
 * состояние на ней. Потолок кэшируется по ведру давления (1 кПа), так что
 * в установившемся режиме цена — два табличных запроса на вызов.
 *
 * Физика мода не трогается: внутри домена всё считается как раньше,
 * перегретое ядро просто не может впихнуть в воду больше, чем существует
 * в её уравнении состояния — обменник остывает к потолку воды, ΔT → 0,
 * система выходит на равновесие на границе таблиц вместо ухода в бесконечность.
 *
 * Реализация через рефлексию (formicapi не в compile classpath); миксин
 * применяется только при загруженном formicapi
 * (см. {@link com.invfix.compat.InvincibleIncMixinTransformer}).
 */
@Mixin(targets = "com.rae.formicapi.content.thermal_utilities.FullTableBased", remap = false)
public abstract class FormicEnthalpyClampMixin {

    @Unique private static final Logger INVFIX_LOGGER = LogUtils.getLogger();

    /** Шаг проверки производной dT/dh, Дж/кг. */
    @Unique private static final float SABLE_DELTA_H = 2000.0F;
    /** Порог «температура ещё растёт», K. */
    @Unique private static final float SABLE_T_EPS = 1.0E-3F;

    @Unique private static Method invfix$getT;
    @Unique private static Method invfix$getX;
    @Unique private static Method invfix$pressure;
    @Unique private static Method invfix$enthalpy;
    @Unique private static Constructor<?> invfix$stateCtor;
    @Unique private static boolean invfix$reflectionBroken;
    @Unique private static long invfix$lastWarn;

    /** Потолок энтальпии по ведру давления (кПа) → h_max, Дж/кг. */
    @Unique private static final ConcurrentHashMap<Integer, Float> INVFIX_CEILING_CACHE =
            new ConcurrentHashMap<>();

    @Inject(method = "isobaricTransfer", at = @At("RETURN"), cancellable = true)
    private static void invfix$clampToTableDomain(CallbackInfoReturnable<Object> cir) {
        if (invfix$reflectionBroken) {
            return;
        }
        try {
            Object state = cir.getReturnValue();
            if (state == null) {
                return;
            }
            invfix$initReflection(state.getClass());

            float p = (Float) invfix$pressure.invoke(state);
            float h = (Float) invfix$enthalpy.invoke(state);
            if (invfix$canAbsorb(p, h)) {
                return; // внутри домена — не вмешиваемся
            }

            int bucket = Math.round(p / 1000.0F);
            Float cached = INVFIX_CEILING_CACHE.get(bucket);
            float ceiling;
            if (cached != null && cached < h) {
                ceiling = cached;
            } else {
                ceiling = invfix$findCeiling(p, h);
                if (INVFIX_CEILING_CACHE.size() < 4096) {
                    INVFIX_CEILING_CACHE.put(bucket, ceiling);
                }
            }
            if (ceiling >= h) {
                return;
            }
            Object clamped = invfix$stateCtor.newInstance(p, ceiling, null, null, null);
            cir.setReturnValue(clamped);

            if (System.currentTimeMillis() - invfix$lastWarn > 300_000L) {
                invfix$lastWarn = System.currentTimeMillis();
                INVFIX_LOGGER.info(
                        "[sable_compat] Энтальпия воды зажата у потолка паровых таблиц "
                        + "({} -> {} Дж/кг при {} Па) — теплоноситель насыщен, "
                        + "дальнейший нагрев физически не принимается",
                        h, ceiling, p);
            }
        } catch (Throwable t) {
            // Любая несовместимость версии formicapi — отключаемся насовсем,
            // поведение возвращается к ванильному поведению мода.
            invfix$reflectionBroken = true;
            INVFIX_LOGGER.warn(
                    "[sable_compat] Ограничитель энтальпии отключён (несовместимая "
                    + "версия formicapi?): {}", t.toString());
        }
    }

    @Unique
    private static void invfix$initReflection(Class<?> stateClass) throws Exception {
        if (invfix$getT != null) {
            return;
        }
        Class<?> tables = Class.forName(
                "com.rae.formicapi.content.thermal_utilities.FullTableBased");
        invfix$getT = tables.getMethod("getT", float.class, float.class);
        invfix$getX = tables.getMethod("getX", float.class, float.class);
        invfix$pressure = stateClass.getMethod("pressure");
        invfix$enthalpy = stateClass.getMethod("specificEnthalpy");
        invfix$stateCtor = stateClass.getConstructor(
                Float.class, Float.class, Float.class, Float.class, Float.class);
    }

    /**
     * Таблица ещё «переваривает» эту энтальпию?
     * Внутри купола (x < 1) — да: там T плоская по физике, а не из-за края.
     * В перегретом паре — да, пока dT/dh > 0. Плоская T при x = 1 — потолок.
     */
    @Unique
    private static boolean invfix$canAbsorb(float p, float h) throws Exception {
        float x = (Float) invfix$getX.invoke(null, p, h);
        if (x < 0.999F) {
            return true;
        }
        float t1 = (Float) invfix$getT.invoke(null, p, h);
        float t2 = (Float) invfix$getT.invoke(null, p, h + SABLE_DELTA_H);
        return t2 > t1 + SABLE_T_EPS;
    }

    /** Бинарный поиск максимальной энтальпии внутри домена при давлении p. */
    @Unique
    private static float invfix$findCeiling(float p, float hOver) throws Exception {
        float lo = hOver / 2.0F;
        int guard = 0;
        while (!invfix$canAbsorb(p, lo) && lo > 1000.0F && guard++ < 40) {
            lo /= 2.0F;
        }
        float hi = hOver;
        for (int i = 0; i < 32; i++) {
            float mid = (lo + hi) / 2.0F;
            if (invfix$canAbsorb(p, mid)) {
                lo = mid;
            } else {
                hi = mid;
            }
        }
        return lo;
    }
}
