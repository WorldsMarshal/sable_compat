package com.invfix.mixin.client;

import com.invfix.xcoin.XCoin;
import com.invfix.xcoin.client.XCoinClient;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Фокус X Coin от третьего лица: монета в главной руке не рисуется слоем предмета — её рисует XCoinFx у кончиков
 * пальцев, лицом к смотрящему, с прыжком и вращением фокуса (иначе на поднятой руке она смотрела бы в небо).
 */
@Mixin(ItemInHandLayer.class)
public class XCoinHeldItemMixin {

    @Inject(method = "renderArmWithItem", at = @At("HEAD"), cancellable = true)
    private void invfix$xCoinHidden(LivingEntity entity, ItemStack stack, ItemDisplayContext context, HumanoidArm arm,
                                    PoseStack pose, MultiBufferSource buffers, int light, CallbackInfo ci) {
        if (!(entity instanceof Player player) || !XCoin.isCoin(stack) || arm != player.getMainArm()) return;
        if (XCoinClient.age(player.getId(), Minecraft.getInstance().getTimer().getGameTimeDeltaPartialTick(false)) >= 0.0F) ci.cancel();
    }
}
