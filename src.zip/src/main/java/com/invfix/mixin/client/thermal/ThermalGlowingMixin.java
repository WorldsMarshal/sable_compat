package com.invfix.mixin.client.thermal;

import com.invfix.thermal.client.ThermalMask;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Пока Thermal Sense рисует силуэты (и только тогда), всё «светится» — так
 * рендер невидимой сущности (зелье невидимости) отдаёт её модель типом outline,
 * и тепло невидимки тоже видно. В остальное время ничего не меняется.
 */
@Mixin(Minecraft.class)
public abstract class ThermalGlowingMixin {

    @Inject(method = "shouldEntityAppearGlowing", at = @At("HEAD"), cancellable = true)
    private void invfix$thermalGlow(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (ThermalMask.drawing()) cir.setReturnValue(true);
    }
}
