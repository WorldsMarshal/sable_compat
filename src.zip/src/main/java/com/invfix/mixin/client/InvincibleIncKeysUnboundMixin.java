package com.invfix.mixin.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings;
import net.minecraft.client.KeyMapping;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.settings.KeyModifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Клавиши Invincible Inc по умолчанию не назначены.
 *
 * Мод раздаёт своим двенадцати привязкам Z, X, C, V, B, G, H, 0, N, R, Y - это
 * ходовые клавиши, и на сборке они почти гарантированно с чем-нибудь
 * конфликтуют. Правильное значение по умолчанию для мода, который ставят в
 * сборку, - «не назначено»: кому нужно, тот назначит сам.
 *
 * ЧТО С УЖЕ НАСТРОЕННЫМИ ИГРОКАМИ. У них ничего не слетит. Порядок такой:
 * сначала объект привязки создаётся со значением по умолчанию, потом он
 * регистрируется в событии, и только потом к нему применяется строка
 * {@code key_key.invincible_inc.*} из options.txt. Иначе привязки модов вообще
 * не переживали бы перезапуск, а они переживают. Правка сидит до вызова
 * {@code register}, то есть раньше применения сохранённых настроек: у кого
 * строка в options.txt есть, тот получит свою клавишу, а у кого нет - «не
 * назначено» вместо Z.
 *
 * Меняются оба поля. Одного {@code key} хватило бы, чтобы клавиша была пустой,
 * но тогда «Сброс» в настройках управления вернул бы ту же Z, и кнопка сброса
 * показывала бы привязку изменённой.
 *
 * Перехватывается не список полей, а сам вызов регистрации: если в моде
 * появится тринадцатая привязка, она попадёт сюда сама.
 */
@Mixin(value = InvincibleIncModKeyMappings.class, remap = false)
public class InvincibleIncKeysUnboundMixin {

    @Redirect(method = "registerKeyMappings",
            at = @At(value = "INVOKE",
                    target = "Lnet/neoforged/neoforge/client/event/RegisterKeyMappingsEvent;register(Lnet/minecraft/client/KeyMapping;)V"),
            remap = false)
    private static void invfix_unbindByDefault(RegisterKeyMappingsEvent event, KeyMapping mapping) {
        KeyMappingAccessor access = (KeyMappingAccessor) (Object) mapping;
        access.invfix$setDefaultKey(InputConstants.UNKNOWN);
        // Не прямая запись в поле key: конструктор KeyMapping уже положил
        // привязку в статический MAP (KeyMappingLookup) под Z. Голая запись
        // поля оставила бы её там, и при отсутствии options.txt (Options#load
        // тогда выходит сразу и ничего не пересобирает) Z продолжал бы
        // срабатывать, хотя в меню клавиша пустая. setKeyModifierAndCode
        // сначала снимает привязку из MAP по текущей клавише, потом кладёт
        // под новую — так в патче NeoForge 1.21.1 (KeyMapping.java.patch).
        mapping.setKeyModifierAndCode(KeyModifier.NONE, InputConstants.UNKNOWN);
        event.register(mapping);
    }
}