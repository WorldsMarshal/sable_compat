package com.invfix.mixin.client.thermal;

import com.mojang.blaze3d.pipeline.RenderTarget;
import net.minecraft.client.renderer.LevelRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Цель ванильного контура светящихся сущностей (поле LevelRenderer#entityTarget):
 * в неё пишут типы рендера outline — без теста глубины, то есть сквозь стены.
 * Thermal Sense рисует туда силуэты и сразу забирает их себе (ThermalMask).
 */
@Mixin(LevelRenderer.class)
public interface LevelRendererEntityTargetAccessor {

    @Accessor("entityTarget")
    RenderTarget invfix$entityTarget();
}
