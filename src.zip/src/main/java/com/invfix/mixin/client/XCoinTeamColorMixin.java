package com.invfix.mixin.client;

import com.invfix.xcoin.client.XCoinAimClient;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Цвет контура цели Aim flight — тусклое пульсирующее золото (LevelRenderer берёт цвет свечения из
 * Entity#getTeamColor). Сравнение по ссылке на клиентскую сущность — серверные (одиночная игра) не задеты.
 */
@Mixin(Entity.class)
public abstract class XCoinTeamColorMixin {

    @Inject(method = "getTeamColor", at = @At("HEAD"), cancellable = true)
    private void invfix$xCoinTargetColor(CallbackInfoReturnable<Integer> cir) {
        if (XCoinAimClient.highlighted((Entity) (Object) this)) cir.setReturnValue(XCoinAimClient.color());
    }
}
