package com.invfix.mixin.client;

import com.invfix.grab.client.GrabClientState;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Разворачивает правую руку держателя вперёд во время захвата (порт The Boys GrabArmMixin),
 * и так же — пока заряжается и бросается Energy Blast (шар в этой руке).
 * Сама жертва ставится перед игроком сервером (GrabHandler.teleportEntityToHand),
 * поэтому отдельный рендер жертвы не нужен — рука просто «держит» её визуально.
 */
@Mixin(value = PlayerModel.class, priority = 3000)
public class GrabArmMixin {

    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At("RETURN"))
    private void invfix_forceGrabArmPose(LivingEntity entity, float limbSwing, float limbSwingAmount,
                                         float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo ci) {
        if (entity instanceof Player player && (GrabClientState.isGrabbing(player.getId())
                || com.invfix.energyblast.client.EnergyBlastClient.armForward(player.getId()))) {
            ModelPart rightArm = ((HumanoidModel<?>) (Object) this).rightArm;
            float pitchRad = (float) Math.toRadians(headPitch);
            float yawRad = (float) Math.toRadians(netHeadYaw);
            rightArm.xRot = -1.5708F + pitchRad;
            rightArm.yRot = yawRad;
            rightArm.zRot = 0.0F;
            ModelPart rightSleeve = ((PlayerModel<?>) (Object) this).rightSleeve;
            rightSleeve.xRot = rightArm.xRot;
            rightSleeve.yRot = rightArm.yRot;
            rightSleeve.zRot = rightArm.zRot;
        }
    }
}