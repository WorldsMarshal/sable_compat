package com.invfix.mixin.client.fx;

import com.invfix.fx.FxManager;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Тряска камеры от эффектов — там же, где ванильная тряска от удара (bobHurt). */
@Mixin(GameRenderer.class)
public abstract class FxGameRendererMixin {

    @Inject(method = "bobHurt", at = @At("HEAD"))
    private void invfix$fxShake(PoseStack poseStack, float partialTick, CallbackInfo ci) {
        FxManager.applyShake(poseStack, partialTick);
    }
}
