package com.invfix.mixin.client;

import com.invfix.xcoin.client.XCoinAimClient;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Цель Aim flight (XCoinAimClient) светится контуром — и EntityCulling её не отсекает (смотрит сюда же). */
@Mixin(Minecraft.class)
public abstract class XCoinGlowMixin {

    @Inject(method = "shouldEntityAppearGlowing", at = @At("HEAD"), cancellable = true)
    private void invfix$xCoinTarget(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (XCoinAimClient.highlighted(entity)) cir.setReturnValue(true);
    }
}
