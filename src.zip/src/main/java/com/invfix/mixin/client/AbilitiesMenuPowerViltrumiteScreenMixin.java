package com.invfix.mixin.client;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.heatvision.HeatVisionAssignPacket;
import com.invfix.heatvision.HeatVisionHandler;
import com.invfix.kineticstrike.KineticStrikeAssignPacket;
import com.invfix.kineticstrike.KineticStrikeHandler;
import com.invfix.timestop.TimeStopAssignPacket;
import com.invfix.timestop.TimeStopHandler;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.world.inventory.AbilitiesMenuPowerViltrumiteMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.neoforged.neoforge.network.PacketDistributor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Кнопки-картинки в меню Вильтрумитов:
 *  - Heat Vision (LVL 30) / Neutron Beam (LVL 50) — только Altrumite;
 *  - Kinetic Strike (LVL 80) — Viltrumite + Altrumite;
 *  - Time Stop — только Altrumite;
 *  - Heat Disruption (LVL 500) — только Alien(Metroman);
 *  - Dismantle (LVL 100) — только Alien(Metroman);
 *  - Energy Blast (LVL 200) — только Alien(Metroman);
 *  - The Whole Sentry Power (LVL 750) — только Alien(Metroman).
 *  - Thermal Sense (LVL 60) — только Alien(Metroman).
 *  - Space Fold (LVL 1000) — только Alien(Metroman).
 *  - Mystic Portal (LVL 200) — только Alien(Metroman).
 *  - Prism Ward (LVL 40) — только Alien(Metroman).
 */
@Mixin(value = net.mcreator.invincibleinc.client.gui.AbilitiesMenuPowerViltrumiteScreen.class, remap = false)
public abstract class AbilitiesMenuPowerViltrumiteScreenMixin
        extends AbstractContainerScreen<AbilitiesMenuPowerViltrumiteMenu> {

    public AbilitiesMenuPowerViltrumiteScreenMixin(
            AbilitiesMenuPowerViltrumiteMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
    }

    private static final WidgetSprites HEAT_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_heat_vision.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_heat_vision_hover.png"));
    private static final WidgetSprites NEUTRON_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_neutron_beam.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_neutron_beam_hover.png"));
    private static final WidgetSprites KINETIC_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_kinetic_strike.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_kinetic_strike_hover.png"));
    private static final WidgetSprites TIME_STOP_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_time_stop.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_time_stop_hover.png"));

    private static final WidgetSprites DISRUPTION_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_heat_disruption.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_heat_disruption_hover.png"));

    private static final WidgetSprites DISMANTLE_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_dismantle.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_dismantle_hover.png"));

    private static final WidgetSprites ENERGY_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_energy_blast.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_energy_blast_hover.png"));

    private static final WidgetSprites SPACE_FOLD_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_space_fold.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_space_fold_hover.png"));

    private static final WidgetSprites THERMAL_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_thermal_sense.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_thermal_sense_hover.png"));

    private static final WidgetSprites SENTRY_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_sentry.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_sentry_hover.png"));

    private static final WidgetSprites MYSTIC_PORTAL_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_mystic_portal.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_mystic_portal_hover.png"));

    private static final WidgetSprites PRISM_WARD_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_prism_ward.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_prism_ward_hover.png"));

    @Inject(method = "init", at = @At("TAIL"), remap = true)
    private void invfix_addAbilityButtons(CallbackInfo ci) {
        var entity = this.menu.entity;
        if (entity == null) return;

        final double lvl;
        final String race;
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            race = vars.Race;
            lvl = vars.Lvl;
        } catch (Exception e) { return; }

        final int bx = this.menu.x, by = this.menu.y, bz = this.menu.z;
        boolean altrumite = AltrumiteRace.isAltrumite(race);

        // ── Heat Vision / Neutron Beam — только Altrumite ──
        if (altrumite) {
            ImageButton heat = makeButton(this.leftPos + 302, this.topPos + 100, HEAT_SPRITES,
                    () -> { if (lvl >= HeatVisionHandler.LVL_RED)
                        PacketDistributor.sendToServer(new HeatVisionAssignPacket(bx, by, bz, HeatVisionHandler.MODE_RED), new CustomPacketPayload[0]); });
            heat.setTooltip(Tooltip.create(Component.literal(
                    lvl >= HeatVisionHandler.LVL_RED ? "§cHeat Vision" : "§8Heat Vision §7(LVL 30)")));
            this.addRenderableWidget(heat);

            ImageButton neutron = makeButton(this.leftPos + 327, this.topPos + 100, NEUTRON_SPRITES,
                    () -> { if (lvl >= HeatVisionHandler.LVL_BLUE)
                        PacketDistributor.sendToServer(new HeatVisionAssignPacket(bx, by, bz, HeatVisionHandler.MODE_BLUE), new CustomPacketPayload[0]); });
            neutron.setTooltip(Tooltip.create(Component.literal(
                    lvl >= HeatVisionHandler.LVL_BLUE ? "§9Neutron Beam" : "§8Neutron Beam §7(LVL 50)")));
            this.addRenderableWidget(neutron);
        }

        // ── Heat Disruption — только Alien(Metroman), LVL 500 ──
        if (altrumite) {
            int need = com.invfix.heatdisruption.HeatDisruptionHandler.LVL_REQUIRED;
            ImageButton disruption = makeButton(this.leftPos + 352, this.topPos + 100, DISRUPTION_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.heatdisruption.HeatDisruptionAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            disruption.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§4Heat Disruption" : "§8Heat Disruption §7(LVL " + need + ")")));
            this.addRenderableWidget(disruption);
        }

        // ── Dismantle — только Alien(Metroman), LVL 100 ──
        if (altrumite) {
            int need = com.invfix.dismantle.DismantleHandler.LVL_REQUIRED;
            ImageButton dismantle = makeButton(this.leftPos + 352, this.topPos + 124, DISMANTLE_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.dismantle.DismantleAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            dismantle.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§fDismantle §7(Shift + клавиша — настройка)" : "§8Dismantle §7(LVL " + need + ")")));
            this.addRenderableWidget(dismantle);
        }

        // ── Energy Blast — только Alien(Metroman), LVL 200 ──
        if (altrumite) {
            int need = com.invfix.energyblast.EnergyBlastHandler.LVL_REQUIRED;
            ImageButton energy = makeButton(this.leftPos + 302, this.topPos + 148, ENERGY_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.energyblast.EnergyBlastPackets.Assign(bx, by, bz), new CustomPacketPayload[0]); });
            energy.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§bEnergy Blast §7(держать — заряд)" : "§8Energy Blast §7(LVL " + need + ")")));
            this.addRenderableWidget(energy);
        }

        // ── The Whole Sentry Power — только Alien(Metroman), LVL 750 ──
        if (altrumite) {
            int need = com.invfix.sentry.SentryHandler.LVL_REQUIRED;
            ImageButton sentry = makeButton(this.leftPos + 327, this.topPos + 148, SENTRY_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.sentry.SentryAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            sentry.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§fThe Whole Sentry Power §7(режим, тумблер)" : "§8The Whole Sentry Power §7(LVL " + need + ")")));
            this.addRenderableWidget(sentry);
        }

        // ── Space Fold — только Alien(Metroman), LVL 1000 ──
        if (altrumite) {
            int need = com.invfix.spacefold.SpaceFoldHandler.LVL_REQUIRED;
            ImageButton fold = makeButton(this.leftPos + 302, this.topPos + 172, SPACE_FOLD_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.spacefold.SpaceFoldAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            fold.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§5Space Fold §7(Shift + клавиша — угол разлома)" : "§8Space Fold §7(LVL " + need + ")")));
            this.addRenderableWidget(fold);
        }

        // ── Mystic Portal — только Alien(Metroman), LVL 200 ──
        if (altrumite) {
            int need = com.invfix.mysticportal.MysticPortalHandler.LVL_REQUIRED;
            ImageButton portal = makeButton(this.leftPos + 327, this.topPos + 172, MYSTIC_PORTAL_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.mysticportal.MysticPortalPackets.Assign(bx, by, bz), new CustomPacketPayload[0]); });
            portal.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§6Mystic Portal §7(Shift + клавиша — настройка)" : "§8Mystic Portal §7(LVL " + need + ")")));
            this.addRenderableWidget(portal);
        }

        // ── Prism Ward — только Alien(Metroman), LVL 40 ──
        if (altrumite) {
            int need = com.invfix.prismward.PrismWardHandler.LVL_REQUIRED;
            ImageButton ward = makeButton(this.leftPos + 352, this.topPos + 172, PRISM_WARD_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.prismward.PrismWardPackets.Assign(bx, by, bz), new CustomPacketPayload[0]); });
            ward.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§ePrism Ward §7(Shift + клавиша — настройка)" : "§8Prism Ward §7(LVL " + need + ")")));
            this.addRenderableWidget(ward);
        }

        // ── Thermal Sense — только Alien(Metroman) ──
        if (altrumite) {
            int need = com.invfix.thermal.ThermalHandler.LVL_REQUIRED;
            ImageButton thermal = makeButton(this.leftPos + 352, this.topPos + 148, THERMAL_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.thermal.ThermalAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            thermal.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§6Thermal Sense §7(режим восприятия, тумблер)" : "§8Thermal Sense §7(LVL " + need + ")")));
            this.addRenderableWidget(thermal);
        }

        // ── Time Stop — только Altrumite ──
        if (altrumite) {
            ImageButton timeStop = makeButton(this.leftPos + 327, this.topPos + 124, TIME_STOP_SPRITES,
                    () -> { if (lvl >= TimeStopHandler.lvlRequired)
                        PacketDistributor.sendToServer(new TimeStopAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            timeStop.setTooltip(Tooltip.create(Component.literal(
                    lvl >= TimeStopHandler.lvlRequired
                            ? "§bTime Stop" : "§8Time Stop §7(LVL " + TimeStopHandler.lvlRequired + ")")));
            this.addRenderableWidget(timeStop);
        }

        // ── Kinetic Strike — Viltrumite + Altrumite ──
        if (KineticStrikeHandler.isEligible(race)) {
            ImageButton kinetic = makeButton(this.leftPos + 302, this.topPos + 124, KINETIC_SPRITES,
                    () -> { if (lvl >= KineticStrikeHandler.LVL_REQUIRED)
                        PacketDistributor.sendToServer(new KineticStrikeAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            kinetic.setTooltip(Tooltip.create(Component.literal(
                    lvl >= KineticStrikeHandler.LVL_REQUIRED ? "§eKinetic Strike" : "§8Kinetic Strike §7(LVL 80)")));
            this.addRenderableWidget(kinetic);
        }
    }

    private ImageButton makeButton(int x, int y, WidgetSprites sprites, Runnable onPress) {
        return new ImageButton(x, y, 20, 20, sprites, (e) -> onPress.run()) {
            @Override
            public void renderWidget(GuiGraphics g, int mx, int my, float pt) {
                g.blit(this.sprites.get(this.isActive(), this.isHoveredOrFocused()),
                        this.getX(), this.getY(), 0.0F, 0.0F, this.width, this.height, this.width, this.height);
            }
        };
    }
}