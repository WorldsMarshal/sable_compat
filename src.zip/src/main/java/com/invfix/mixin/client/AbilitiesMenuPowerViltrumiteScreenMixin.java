package com.invfix.mixin.client;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.heatvision.HeatVisionAssignPacket;
import com.invfix.heatvision.HeatVisionHandler;
import com.invfix.kineticstrike.KineticStrikeAssignPacket;
import com.invfix.kineticstrike.KineticStrikeHandler;
import com.invfix.timestop.TimeStopAssignPacket;
import com.invfix.timestop.TimeStopHandler;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.world.inventory.AbilitiesMenuPowerViltrumiteMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.neoforged.neoforge.network.PacketDistributor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Кнопки-картинки в меню Вильтрумитов:
 *  - Heat Vision (LVL 30) / Neutron Beam (LVL 50) — Alien(Metroman) + Kitsune;
 *  - Kinetic Strike (LVL 80) — Viltrumite + Alien(Metroman) + Kitsune;
 *  - Time Stop — Alien(Metroman) + Kitsune;
 *  - Thermal Sense (LVL 60) — Alien(Metroman) + Kitsune;
 *  - только Kitsune (dev-раса): Heat Disruption (LVL 500), Dismantle (LVL 100),
 *    Energy Blast (LVL 200), The Whole Sentry Power (LVL 750), Space Fold
 *    (LVL 1000), Mystic Portal (LVL 200), Prism Ward (LVL 40), Six Eyes (LVL 40),
 *    Shapeshifter, Morph Ability, Size Difference и Fox Hole (LVL 30), Unlimited Void (LVL 1000),
 *    3D-2D и 3D-2D: Attack (LVL 100), X Teleport (LVL 50), X Coin (LVL 10), Fallen Pagoda (LVL 300).
 */
@Mixin(value = net.mcreator.invincibleinc.client.gui.AbilitiesMenuPowerViltrumiteScreen.class, remap = false)
public abstract class AbilitiesMenuPowerViltrumiteScreenMixin
        extends AbstractContainerScreen<AbilitiesMenuPowerViltrumiteMenu> {

    public AbilitiesMenuPowerViltrumiteScreenMixin(
            AbilitiesMenuPowerViltrumiteMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
    }

    private static final WidgetSprites HEAT_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_heat_vision.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_heat_vision_hover.png"));
    private static final WidgetSprites NEUTRON_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_neutron_beam.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_neutron_beam_hover.png"));
    private static final WidgetSprites KINETIC_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_kinetic_strike.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_kinetic_strike_hover.png"));
    private static final WidgetSprites TIME_STOP_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_time_stop.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_time_stop_hover.png"));

    private static final WidgetSprites DISRUPTION_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_heat_disruption.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_heat_disruption_hover.png"));

    private static final WidgetSprites DISMANTLE_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_dismantle.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_dismantle_hover.png"));

    private static final WidgetSprites ENERGY_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_energy_blast.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_energy_blast_hover.png"));

    private static final WidgetSprites SPACE_FOLD_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_space_fold.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_space_fold_hover.png"));

    private static final WidgetSprites THERMAL_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_thermal_sense.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_thermal_sense_hover.png"));

    private static final WidgetSprites SENTRY_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_sentry.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_sentry_hover.png"));

    private static final WidgetSprites MYSTIC_PORTAL_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_mystic_portal.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_mystic_portal_hover.png"));

    private static final WidgetSprites PRISM_WARD_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_prism_ward.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_prism_ward_hover.png"));

    private static final WidgetSprites SIX_EYES_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_six_eyes.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_six_eyes_hover.png"));

    private static final WidgetSprites SHAPESHIFTER_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_shapeshifter.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_shapeshifter_hover.png"));

    private static final WidgetSprites SIZE_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_size_difference.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_size_difference_hover.png"));

    private static final WidgetSprites FOX_HOLE_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_fox_hole.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_fox_hole_hover.png"));

    private static final WidgetSprites UNLIMITED_VOID_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_unlimited_void.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_unlimited_void_hover.png"));
    private static final WidgetSprites FLAT_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_flat.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_flat_hover.png"));
    private static final WidgetSprites FLAT_ATTACK_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_flat_attack.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_flat_attack_hover.png"));
    private static final WidgetSprites X_COIN_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_x_coin.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_x_coin_hover.png"));
    private static final WidgetSprites FALLEN_PAGODA_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_fallen_pagoda.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_fallen_pagoda_hover.png"));
    private static final WidgetSprites X_TELEPORT_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_x_teleport.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_x_teleport_hover.png"));
    private static final WidgetSprites FOUR_D_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_four_d.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_four_d_hover.png"));

    private static final WidgetSprites MORPH_ABILITY_SPRITES = new WidgetSprites(
            ResourceLocation.parse("sable_compat:textures/screens/ab_morph_ability.png"),
            ResourceLocation.parse("sable_compat:textures/screens/ab_morph_ability_hover.png"));

    @Inject(method = "init", at = @At("TAIL"), remap = true)
    private void invfix_addAbilityButtons(CallbackInfo ci) {
        var entity = this.menu.entity;
        if (entity == null) return;

        final double lvl;
        final String race;
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            race = vars.Race;
            lvl = vars.Lvl;
        } catch (Exception e) { return; }

        final int bx = this.menu.x, by = this.menu.y, bz = this.menu.z;
        invfix$slot = 0;
        // Способности Metroman — у Metroman и Kitsune; dev-способности — только у Kitsune
        boolean altrumite = AltrumiteRace.isAltrumiteLike(race);
        boolean kitsune = com.invfix.kitsune.KitsuneRace.isKitsune(race);

        // ── Kinetic Strike — Viltrumite + Alien(Metroman) + Kitsune ──
        if (KineticStrikeHandler.isEligible(race)) {
            ImageButton kinetic = makeButton(invfix$sx(), invfix$sy(), KINETIC_SPRITES,
                    () -> { if (lvl >= KineticStrikeHandler.LVL_REQUIRED)
                        PacketDistributor.sendToServer(new KineticStrikeAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            kinetic.setTooltip(Tooltip.create(Component.literal(
                    lvl >= KineticStrikeHandler.LVL_REQUIRED ? "§eKinetic Strike" : "§8Kinetic Strike §7(LVL 80)")));
            this.addRenderableWidget(kinetic);
        }

        // ── Heat Vision / Neutron Beam — Alien(Metroman) + Kitsune ──
        if (altrumite) {
            ImageButton heat = makeButton(invfix$sx(), invfix$sy(), HEAT_SPRITES,
                    () -> { if (lvl >= HeatVisionHandler.LVL_RED)
                        PacketDistributor.sendToServer(new HeatVisionAssignPacket(bx, by, bz, HeatVisionHandler.MODE_RED), new CustomPacketPayload[0]); });
            heat.setTooltip(Tooltip.create(Component.literal(
                    lvl >= HeatVisionHandler.LVL_RED ? "§cHeat Vision" : "§8Heat Vision §7(LVL 30)")));
            this.addRenderableWidget(heat);

            ImageButton neutron = makeButton(invfix$sx(), invfix$sy(), NEUTRON_SPRITES,
                    () -> { if (lvl >= HeatVisionHandler.LVL_BLUE)
                        PacketDistributor.sendToServer(new HeatVisionAssignPacket(bx, by, bz, HeatVisionHandler.MODE_BLUE), new CustomPacketPayload[0]); });
            neutron.setTooltip(Tooltip.create(Component.literal(
                    lvl >= HeatVisionHandler.LVL_BLUE ? "§9Neutron Beam" : "§8Neutron Beam §7(LVL 50)")));
            this.addRenderableWidget(neutron);
        }

        // ── Time Stop — Alien(Metroman) + Kitsune ──
        if (altrumite) {
            ImageButton timeStop = makeButton(invfix$sx(), invfix$sy(), TIME_STOP_SPRITES,
                    () -> { if (lvl >= TimeStopHandler.lvlRequired)
                        PacketDistributor.sendToServer(new TimeStopAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            timeStop.setTooltip(Tooltip.create(Component.literal(
                    lvl >= TimeStopHandler.lvlRequired
                            ? "§bTime Stop" : "§8Time Stop §7(LVL " + TimeStopHandler.lvlRequired + ")")));
            this.addRenderableWidget(timeStop);
        }

        // ── Thermal Sense — Alien(Metroman) + Kitsune ──
        if (altrumite) {
            int need = com.invfix.thermal.ThermalHandler.LVL_REQUIRED;
            ImageButton thermal = makeButton(invfix$sx(), invfix$sy(), THERMAL_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.thermal.ThermalAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            thermal.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§6Thermal Sense §7(режим восприятия, тумблер)" : "§8Thermal Sense §7(LVL " + need + ")")));
            this.addRenderableWidget(thermal);
        }

        // ── Heat Disruption — только Kitsune, LVL 500 ──
        if (kitsune) {
            int need = com.invfix.heatdisruption.HeatDisruptionHandler.LVL_REQUIRED;
            ImageButton disruption = makeButton(invfix$sx(), invfix$sy(), DISRUPTION_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.heatdisruption.HeatDisruptionAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            disruption.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§4Heat Disruption" : "§8Heat Disruption §7(LVL " + need + ")")));
            this.addRenderableWidget(disruption);
        }

        // ── Dismantle — только Kitsune, LVL 100 ──
        if (kitsune) {
            int need = com.invfix.dismantle.DismantleHandler.LVL_REQUIRED;
            ImageButton dismantle = makeButton(invfix$sx(), invfix$sy(), DISMANTLE_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.dismantle.DismantleAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            dismantle.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§fDismantle §7(Shift + клавиша — настройка)" : "§8Dismantle §7(LVL " + need + ")")));
            this.addRenderableWidget(dismantle);
        }

        // ── Energy Blast — только Kitsune, LVL 200 ──
        if (kitsune) {
            int need = com.invfix.energyblast.EnergyBlastHandler.LVL_REQUIRED;
            ImageButton energy = makeButton(invfix$sx(), invfix$sy(), ENERGY_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.energyblast.EnergyBlastPackets.Assign(bx, by, bz), new CustomPacketPayload[0]); });
            energy.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§bEnergy Blast §7(держать — заряд)" : "§8Energy Blast §7(LVL " + need + ")")));
            this.addRenderableWidget(energy);
        }

        // ── The Whole Sentry Power — только Kitsune, LVL 750 ──
        if (kitsune) {
            int need = com.invfix.sentry.SentryHandler.LVL_REQUIRED;
            ImageButton sentry = makeButton(invfix$sx(), invfix$sy(), SENTRY_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.sentry.SentryAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            sentry.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§fThe Whole Sentry Power §7(режим, тумблер)" : "§8The Whole Sentry Power §7(LVL " + need + ")")));
            this.addRenderableWidget(sentry);
        }

        // ── Space Fold — только Kitsune, LVL 1000 ──
        if (kitsune) {
            int need = com.invfix.spacefold.SpaceFoldHandler.LVL_REQUIRED;
            ImageButton fold = makeButton(invfix$sx(), invfix$sy(), SPACE_FOLD_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.spacefold.SpaceFoldAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            fold.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§5Space Fold §7(Shift + клавиша — угол разлома)" : "§8Space Fold §7(LVL " + need + ")")));
            this.addRenderableWidget(fold);
        }

        // ── Mystic Portal — только Kitsune, LVL 200 ──
        if (kitsune) {
            int need = com.invfix.mysticportal.MysticPortalHandler.LVL_REQUIRED;
            ImageButton portal = makeButton(invfix$sx(), invfix$sy(), MYSTIC_PORTAL_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.mysticportal.MysticPortalPackets.Assign(bx, by, bz), new CustomPacketPayload[0]); });
            portal.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§6Mystic Portal §7(Shift + клавиша — настройка)" : "§8Mystic Portal §7(LVL " + need + ")")));
            this.addRenderableWidget(portal);
        }

        // ── Prism Ward — только Kitsune, LVL 40 ──
        if (kitsune) {
            int need = com.invfix.prismward.PrismWardHandler.LVL_REQUIRED;
            ImageButton ward = makeButton(invfix$sx(), invfix$sy(), PRISM_WARD_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.prismward.PrismWardPackets.Assign(bx, by, bz), new CustomPacketPayload[0]); });
            ward.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§ePrism Ward §7(Shift + клавиша — настройка)" : "§8Prism Ward §7(LVL " + need + ")")));
            this.addRenderableWidget(ward);
        }

        // ── Six Eyes — только Kitsune, LVL 40 ──
        if (kitsune) {
            int need = com.invfix.sixeyes.SixEyesHandler.LVL_REQUIRED;
            ImageButton sixEyes = makeButton(invfix$sx(), invfix$sy(), SIX_EYES_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.sixeyes.SixEyesAssignPacket(bx, by, bz), new CustomPacketPayload[0]); });
            sixEyes.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§bSix Eyes §7(режим восприятия, тумблер)" : "§8Six Eyes §7(LVL " + need + ")")));
            this.addRenderableWidget(sixEyes);
        }

        // ── Shapeshifter — только Kitsune, LVL 30 (клавиша — морф/обратно, Shift + клавиша — выбор моба) ──
        if (kitsune) {
            int need = com.invfix.shapeshift.ShapeshiftHandler.LVL_REQUIRED;
            ImageButton shift = makeButton(invfix$sx(), invfix$sy(), SHAPESHIFTER_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.shapeshift.ShapeshiftPackets.Assign(0), new CustomPacketPayload[0]); });
            shift.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§6Shapeshifter §7(клавиша — превращение, Shift + клавиша — выбор моба)"
                            : "§8Shapeshifter §7(LVL " + need + ")")));
            this.addRenderableWidget(shift);

            ImageButton morphAbility = makeButton(invfix$sx(), invfix$sy(), MORPH_ABILITY_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.shapeshift.ShapeshiftPackets.Assign(1), new CustomPacketPayload[0]); });
            morphAbility.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§6Morph Ability §7(способность морфа: фаербол, телепорт, сон или сидеть)"
                            : "§8Morph Ability §7(LVL " + need + ")")));
            this.addRenderableWidget(morphAbility);
        }

        // ── Size Difference — только Kitsune, LVL 30 (клавиша — размер вкл/выкл, Shift + клавиша — настройка) ──
        if (kitsune) {
            int need = com.invfix.sizediff.SizeHandler.LVL_REQUIRED;
            ImageButton size = makeButton(invfix$sx(), invfix$sy(), SIZE_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.sizediff.SizePackets.Assign(), new CustomPacketPayload[0]); });
            size.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§aSize Difference §7(клавиша — размер / обычный, Shift + клавиша — настройка)"
                            : "§8Size Difference §7(LVL " + need + ")")));
            this.addRenderableWidget(size);
        }

        // ── Fox Hole — только Kitsune, LVL 100 (клавиша — войти / выйти / перенести цель, Shift + клавиша — настройки) ──
        if (kitsune) {
            int need = com.invfix.foxhole.FoxHole.LVL_REQUIRED;
            ImageButton foxHole = makeButton(invfix$sx(), invfix$sy(), FOX_HOLE_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.foxhole.FoxHolePackets.Assign(), new CustomPacketPayload[0]); });
            foxHole.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§dFox Hole §7(клавиша — войти / выйти, Shift + клавиша — настройки)"
                            : "§8Fox Hole §7(LVL " + need + ")")));
            this.addRenderableWidget(foxHole);
        }

        // ── Domain Expansion: Unlimited Void — только Kitsune, LVL 1000 (клавиша — раскрыть / закрыть территорию) ──
        if (kitsune) {
            int need = com.invfix.unlimitedvoid.UnlimitedVoid.LVL_REQUIRED;
            ImageButton unlimitedVoid = makeButton(invfix$sx(), invfix$sy(), UNLIMITED_VOID_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.unlimitedvoid.UnlimitedVoidPackets.Assign(), new CustomPacketPayload[0]); });
            unlimitedVoid.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§bDomain Expansion: Unlimited Void §7(клавиша — раскрыть / закрыть территорию, Shift + клавиша — радиус и Fast Domain)"
                            : "§8Domain Expansion: Unlimited Void §7(LVL " + need + ")")));
            this.addRenderableWidget(unlimitedVoid);
        }

        // ── 3D-2D — только Kitsune, LVL 100 (клавиша — войти в 2D / выйти) ──
        if (kitsune) {
            int need = com.invfix.flat.Flat.LVL_REQUIRED;
            ImageButton flat = makeButton(invfix$sx(), invfix$sy(), FLAT_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.flat.FlatPackets.Assign(), new CustomPacketPayload[0]); });
            flat.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§d3D-2D §7(клавиша — войти в 2D / выйти, Shift + клавиша — режим пола)"
                            : "§83D-2D §7(LVL " + need + ")")));
            this.addRenderableWidget(flat);
        }

        // ── 3D-2D: Attack — только Kitsune, LVL 100 (клавиша — цель под прицелом в 2D) ──
        if (kitsune) {
            int need = com.invfix.flat.FlatAttack.LVL_REQUIRED;
            ImageButton flatAttack = makeButton(invfix$sx(), invfix$sy(), FLAT_ATTACK_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.flat.FlatPackets.AttackAssign(), new CustomPacketPayload[0]); });
            flatAttack.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§d3D-2D: Attack §7(клавиша — цель под прицелом в 2D, Shift + клавиша — режим: на 60 с / граффити)"
                            : "§83D-2D: Attack §7(LVL " + need + ")")));
            this.addRenderableWidget(flatAttack);
        }

        // ── 4D Offset — только Kitsune, LVL 500 (клавиша — сместиться в 4D / вернуться) ──
        if (kitsune) {
            int need = com.invfix.fourd.FourD.LVL_REQUIRED;
            ImageButton fourD = makeButton(invfix$sx(), invfix$sy(), FOUR_D_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.fourd.FourDPackets.Assign(), new CustomPacketPayload[0]); });
            fourD.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§54D Offset §7(клавиша — сместиться по 4-й координате / вернуться; в 4D: Пробел / Shift — вверх / вниз сквозь перекрытия, ПКМ — контейнер или карманы сквозь стены)"
                            : "§84D Offset §7(LVL " + need + ")")));
            this.addRenderableWidget(fourD);
        }

        // ── X Teleport — только Kitsune, LVL 50 (клавиша — щелчок и телепорт) ──
        if (kitsune) {
            int need = com.invfix.xteleport.XTeleport.LVL_REQUIRED;
            ImageButton xTeleport = makeButton(invfix$sx(), invfix$sy(), X_TELEPORT_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.xteleport.XTeleportPackets.Assign(), new CustomPacketPayload[0]); });
            xTeleport.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§dX Teleport §7(клавиша — щелчок и телепорт, Shift + клавиша — режим: по взгляду / точка)"
                            : "§8X Teleport §7(LVL " + need + ")")));
            this.addRenderableWidget(xTeleport);
        }

        // ── X Coin — только Kitsune, LVL 10 (клавиша — монета появляется в руке / исчезает) ──
        if (kitsune) {
            int need = com.invfix.xcoin.XCoin.LVL_REQUIRED;
            ImageButton xCoin = makeButton(invfix$sx(), invfix$sy(), X_COIN_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.xcoin.XCoinPackets.Assign(), new CustomPacketPayload[0]); });
            xCoin.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§6X Coin §7(клавиша — фокус: монета появляется в руке; в руке — исчезает. ПКМ монетой — её способность, Shift+ПКМ — следующая)"
                            : "§8X Coin §7(LVL " + need + ")")));
            this.addRenderableWidget(xCoin);
        }

        // ── Fallen Pagoda — только Kitsune, LVL 300 (клавиша — портал над целью, из него падает башня) ──
        if (kitsune) {
            int need = com.invfix.pagoda.Pagoda.LVL_REQUIRED;
            ImageButton pagoda = makeButton(invfix$sx(), invfix$sy(), FALLEN_PAGODA_SPRITES,
                    () -> { if (lvl >= need)
                        PacketDistributor.sendToServer(new com.invfix.pagoda.PagodaPackets.Assign(), new CustomPacketPayload[0]); });
            pagoda.setTooltip(Tooltip.create(Component.literal(
                    lvl >= need ? "§6Fallen Pagoda §7(клавиша — цель под прицелом до 90 блоков: над ней открывается портал, из него падает башня)"
                            : "§8Fallen Pagoda §7(LVL " + need + ")")));
            this.addRenderableWidget(pagoda);
        }
    }

    /**
     * Свободные места под наши кнопки в листе меню (относительно leftPos/topPos), в порядке
     * заполнения — снизу вверх, чтобы новые способности добавлялись сверху и ничего не
     * перекрывали: второй ряд синей панели «PWR» под рядом способностей мода (до строки
     * описания), затем правый край ряда мода, затем чёрная полоса над панелью.
     *
     * Дальше — поля экрана вокруг листа (экран 435×300, лист — с +46,+29, 351×234; мод там
     * ничего не рисует): правая колонка (без ряда на высоте строки описания — длинное
     * описание выходит за лист), левая колонка, полоса под листом, полоса над ним.
     */
    @Unique
    private static final int[][] INVFIX_SLOTS = invfix$slots();

    @Unique
    private int invfix$slot;

    @Unique
    private static int[][] invfix$slots() {
        java.util.List<int[]> out = new java.util.ArrayList<>();
        for (int x = 149; x <= 349; x += 25) out.add(new int[]{x, 124});
        for (int x = 299; x <= 349; x += 25) out.add(new int[]{x, 99});
        for (int x = 149; x <= 349; x += 25) out.add(new int[]{x, 55});
        for (int y = 35; y <= 235; y += 25) if (y + 20 <= 154 || y >= 172) out.add(new int[]{405, y});
        for (int y = 35; y <= 235; y += 25) out.add(new int[]{20, y});
        for (int x = 46; x <= 371; x += 25) out.add(new int[]{x, 270});
        for (int x = 46; x <= 371; x += 25) out.add(new int[]{x, 5});
        return out.toArray(new int[0][]);
    }

    @Unique
    private int invfix$sx() {
        int i = Math.min(invfix$slot, INVFIX_SLOTS.length - 1);
        return this.leftPos + INVFIX_SLOTS[i][0];
    }

    /** y места и переход к следующему (вызывается после invfix$sx). */
    @Unique
    private int invfix$sy() {
        int i = Math.min(invfix$slot, INVFIX_SLOTS.length - 1);
        invfix$slot++;
        return this.topPos + INVFIX_SLOTS[i][1];
    }

    private ImageButton makeButton(int x, int y, WidgetSprites sprites, Runnable onPress) {
        return new ImageButton(x, y, 20, 20, sprites, (e) -> onPress.run()) {
            @Override
            public void renderWidget(GuiGraphics g, int mx, int my, float pt) {
                g.blit(this.sprites.get(this.isActive(), this.isHoveredOrFocused()),
                        this.getX(), this.getY(), 0.0F, 0.0F, this.width, this.height, this.width, this.height);
            }
        };
    }
}