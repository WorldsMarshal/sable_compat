package com.invfix.mixin.client.fx;

import com.invfix.fx.FxManager;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Три точки кадра для эффектов — те же, что у The Shooting Star
 * (mc1211.client.mixin.LevelRendererMixin):
 *  - HEAD renderLevel: матрицы вида и проекции этого кадра;
 *  - перед PostChain#process (прозрачность «Fabulous»): копия глубины, пока
 *    её не испортил ванильный пост-проход;
 *  - RETURN renderLevel: эффекты поверх готового мира, до руки и GUI.
 *
 * Вторая точка необязательна (require = 0): без неё теряется только глубина
 * при «Fabulous», а промах при defaultRequire = 1 ронял бы запуск.
 */
@Mixin(LevelRenderer.class)
public abstract class FxLevelRendererMixin {

    @Inject(method = "renderLevel", at = @At("HEAD"))
    private void invfix$fxCapture(DeltaTracker deltaTracker, boolean outline, Camera camera,
                                  GameRenderer gameRenderer, LightTexture lightTexture,
                                  Matrix4f view, Matrix4f projection, CallbackInfo ci) {
        // проход портала (ядро IP): эффекты рисуются один раз — в основном кадре, поверх портала
        if (com.invfix.portal.client.PortalPassCompat.inPortalPass()) return;
        FxManager.capture(view, projection);
    }

    @Inject(method = "renderLevel",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/PostChain;process(F)V"),
            require = 0, expect = 0)
    private void invfix$fxKeepDepth(DeltaTracker deltaTracker, boolean outline, Camera camera,
                                    GameRenderer gameRenderer, LightTexture lightTexture,
                                    Matrix4f view, Matrix4f projection, CallbackInfo ci) {
        if (com.invfix.portal.client.PortalPassCompat.inPortalPass()) return;
        FxManager.beforePostChain();
    }

    @Inject(method = "renderLevel", at = @At("RETURN"))
    private void invfix$fxRender(DeltaTracker deltaTracker, boolean outline, Camera camera,
                                 GameRenderer gameRenderer, LightTexture lightTexture,
                                 Matrix4f view, Matrix4f projection, CallbackInfo ci) {
        if (com.invfix.portal.client.PortalPassCompat.inPortalPass()) return;
        FxManager.render(camera, deltaTracker.getGameTimeDeltaPartialTick(true));
    }
}
