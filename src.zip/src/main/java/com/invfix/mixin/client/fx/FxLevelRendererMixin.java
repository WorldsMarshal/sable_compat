package com.invfix.mixin.client.fx;

import com.invfix.fx.FxManager;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Три точки кадра для эффектов — те же, что у The Shooting Star
 * (mc1211.client.mixin.LevelRendererMixin):
 *  - HEAD renderLevel: матрицы вида и проекции этого кадра;
 *  - перед PostChain#process (прозрачность «Fabulous»): копия глубины, пока
 *    её не испортил ванильный пост-проход;
 *  - RETURN renderLevel: эффекты поверх готового мира, до руки и GUI.
 * В проходе портала ядра IP — свои матрицы и эффекты «по ту сторону» (FxManager#renderPortalPass).
 *
 * Вторая точка необязательна (require = 0): без неё теряется только глубина
 * при «Fabulous», а промах при defaultRequire = 1 ронял бы запуск.
 */
@Mixin(LevelRenderer.class)
public abstract class FxLevelRendererMixin {

    @Inject(method = "renderLevel", at = @At("HEAD"))
    private void invfix$fxCapture(DeltaTracker deltaTracker, boolean outline, Camera camera,
                                  GameRenderer gameRenderer, LightTexture lightTexture,
                                  Matrix4f view, Matrix4f projection, CallbackInfo ci) {
        // проход портала (ядро IP): свои матрицы, эффекты «по ту сторону» — FxManager#renderPortalPass
        if (com.invfix.portal.client.PortalPassCompat.inPortalPass()) {
            FxManager.capturePortal(view, projection);
            return;
        }
        FxManager.capture(view, projection);
    }

    @Inject(method = "renderLevel",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/PostChain;process(F)V"),
            require = 0, expect = 0)
    private void invfix$fxKeepDepth(DeltaTracker deltaTracker, boolean outline, Camera camera,
                                    GameRenderer gameRenderer, LightTexture lightTexture,
                                    Matrix4f view, Matrix4f projection, CallbackInfo ci) {
        if (com.invfix.portal.client.PortalPassCompat.inPortalPass()) return;
        FxManager.beforePostChain();
    }

    @Inject(method = "renderLevel", at = @At("RETURN"))
    private void invfix$fxRender(DeltaTracker deltaTracker, boolean outline, Camera camera,
                                 GameRenderer gameRenderer, LightTexture lightTexture,
                                 Matrix4f view, Matrix4f projection, CallbackInfo ci) {
        if (com.invfix.portal.client.PortalPassCompat.inPortalPass()) {
            // ободки Mystic Portal внутри портала — статичной обводкой (полная графика — только в основном кадре)
            com.invfix.mysticportal.client.MysticPortalOutline.render(view, camera.getPosition(),
                    deltaTracker.getGameTimeDeltaPartialTick(true), clipPos(), clipNormal());
            FxManager.renderPortalPass(camera, deltaTracker.getGameTimeDeltaPartialTick(true),
                    com.invfix.ip.core.render.context_management.PortalRendering.getPortalLayer(),
                    clipPos(), clipNormal(), portalWindow());
            return;
        }
        // повязка на глаза: мир — в чёрное до эффектов (сквозь неё видно только Thermal Sense и Six Eyes)
        // Six Eyes видит без глаз: кадр остаётся (текстуры блоков видны в её цветах), чёрное — только вне волны включения
        if (com.invfix.blindfold.client.BlindfoldClient.blind()
                && !com.invfix.sixeyes.client.SixEyesClient.viewVisible()) {
            com.invfix.blindfold.client.BlindfoldClient.clearScene();
        }
        FxManager.render(camera, deltaTracker.getGameTimeDeltaPartialTick(true));
    }

    private static net.minecraft.world.phys.Vec3 clipPos() {
        com.invfix.ip.misc.my_util.Plane plane = activeClip();
        return plane == null ? null : plane.pos();
    }

    private static net.minecraft.world.phys.Vec3 clipNormal() {
        com.invfix.ip.misc.my_util.Plane plane = activeClip();
        return plane == null ? null : plane.normal();
    }

    /** Окно портала, через который идёт проход: его прямоугольник с той стороны (в мире прохода). */
    private static net.minecraft.world.phys.AABB portalWindow() {
        if (!com.invfix.ip.core.render.context_management.PortalRendering.isRendering()) return null;
        com.invfix.ip.core.portal.Portal portal =
                com.invfix.ip.core.render.context_management.PortalRendering.getRenderingPortal();
        net.minecraft.world.phys.Vec3 o = portal.getOriginPos();
        net.minecraft.world.phys.Vec3 w = portal.getAxisW().scale(portal.getWidth() * 0.5);
        net.minecraft.world.phys.Vec3 h = portal.getAxisH().scale(portal.getHeight() * 0.5);
        net.minecraft.world.phys.Vec3 a = portal.transformPoint(o.add(w).add(h));
        net.minecraft.world.phys.Vec3 b = portal.transformPoint(o.add(w).subtract(h));
        net.minecraft.world.phys.Vec3 c = portal.transformPoint(o.subtract(w).add(h));
        net.minecraft.world.phys.Vec3 d = portal.transformPoint(o.subtract(w).subtract(h));
        return new net.minecraft.world.phys.AABB(a, b).minmax(new net.minecraft.world.phys.AABB(c, d)).inflate(0.05);
    }

    private static com.invfix.ip.misc.my_util.Plane activeClip() {
        if (!com.invfix.ip.core.render.context_management.PortalRendering.isRendering()) return null;
        return com.invfix.ip.core.render.context_management.PortalRendering.getActiveClippingPlane();
    }
}
