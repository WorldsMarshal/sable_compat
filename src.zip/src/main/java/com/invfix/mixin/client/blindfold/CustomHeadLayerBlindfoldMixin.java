package com.invfix.mixin.client.blindfold;

import com.invfix.blindfold.Blindfold;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.CustomHeadLayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Повязка в слоте шлема — не броня, и CustomHeadLayer рисовал бы над головой её иконку
 * (предмет в виде HEAD). Сама повязка на голове — BlindfoldLayer, иконка не нужна.
 */
@Mixin(CustomHeadLayer.class)
public abstract class CustomHeadLayerBlindfoldMixin {

    @Inject(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/entity/LivingEntity;FFFFFF)V",
            at = @At("HEAD"), cancellable = true)
    private void invfix$skipBlindfold(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                                      LivingEntity entity, float limbSwing, float limbSwingAmount,
                                      float partialTicks, float ageInTicks, float netHeadYaw, float headPitch,
                                      CallbackInfo ci) {
        if (Blindfold.isBlindfold(entity.getItemBySlot(EquipmentSlot.HEAD))) ci.cancel();
    }
}
