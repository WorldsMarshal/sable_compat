package com.invfix.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.layers.PlayerItemInHandLayer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.ArrayList;
import java.util.List;

/**
 * Перенос визуальной фичи оригинального invincible_inc
 * ({@code net.mcreator.invincibleinc.mixin.LivingEntityRendererMixin}).
 *
 * Во время кастомной анимации от первого лица модель собственного игрока нужно
 * прятать, оставляя только слой предмета в руке. Оригинал делал это через
 * {@code @Redirect} на поле {@code layers}, что в сборке с другими модами падало
 * с "Critical injection failure ... Scanned 0 target(s). No refMap loaded"
 * ({@code @Redirect} по полю эксклюзивен и конфликтует, плюс у оригинала не было
 * рабочего refmap).
 *
 * Здесь то же самое сделано через {@code @ModifyExpressionValue} (MixinExtras,
 * бандлится в NeoForge): он оборачивает значение чтения поля {@code layers} и
 * корректно стыкуется с обёртками других модов вместо жёсткого конфликта.
 * Класс-цель — ванильный, поэтому ссылка на поле проходит обычный ремап нашего
 * AP. Применение гейтится в InvincibleIncMixinTransformer по наличию
 * invincible_inc.
 *
 * Поведение идентично оригиналу. Латч через InvincibleIncModPlayerAnimationAPI
 * опущен намеренно: флаги FirstPersonAnimation/setNullRender в persistentData
 * выставляет сам invincible_inc только когда анимация реально играет, поэтому
 * без него ничего не меняется, а лишней связи с внутренностями мода нет.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererLayersMixin {

    @SuppressWarnings({"rawtypes", "unchecked"})
    @ModifyExpressionValue(
            method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;layers:Ljava/util/List;",
                    opcode = Opcodes.GETFIELD
            )
    )
    private List invfix_filterFirstPersonLayers(List original, LivingEntity entity,
                                                float entityYaw, float partialTicks,
                                                PoseStack poseStack, MultiBufferSource buffers,
                                                int packedLight) {
        if (!(entity instanceof Player player)) {
            return original;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.player != player || !mc.options.getCameraType().isFirstPerson() || mc.screen != null) {
            return original;
        }

        CompoundTag data = player.getPersistentData();

        // Активная анимация от первого лица: оставляем только слой предмета в руке
        // и взводим счётчик «пустых» кадров на отпускание.
        if (data.getBoolean("FirstPersonAnimation")) {
            data.putInt("setNullRender", 4);
            List filtered = new ArrayList();
            for (Object layer : original) {
                if (layer instanceof PlayerItemInHandLayer) {
                    filtered.add(layer);
                }
            }
            return filtered;
        }

        // Несколько кадров после завершения анимации модель полностью скрыта.
        if (data.contains("setNullRender")) {
            int left = data.getInt("setNullRender");
            if (left > 0) {
                data.putInt("setNullRender", left - 1);
                return List.of();
            }
            data.remove("setNullRender");
        }

        return original;
    }
}