package com.invfix.mixin.client;

import com.invfix.seriouspunch.client.SeriousPunchSky;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Better Clouds (betterclouds 1.7.20, com.qendolin.betterclouds.clouds.shaders.Shader): облака, разогнанные Serious
 * Punch (SeriousPunchSky).
 *  - compileShader: исходник уходит в GLCompat#shaderSource(int, String) уже с подставленными #define — покрытию
 *    (betterclouds_coverage.vsh) дописывается sp_clear (SeriousPunchSky#patch), прочие шейдеры не меняются;
 *  - bind (glUseProgram(programId)): униформы областей (SeriousPunchSky#upload; у программ без sp_count — ничего).
 *
 * Таргет — по строковому имени с remap=false: жёсткой зависимости на Better Clouds нет, применение гейтится в
 * InvincibleIncMixinTransformer по наличию мода "betterclouds".
 */
@Mixin(targets = "com.qendolin.betterclouds.clouds.shaders.Shader", remap = false)
public abstract class BetterCloudsShaderMixin {

    @Shadow
    protected int programId;

    @ModifyArg(method = "compileShader",
            at = @At(value = "INVOKE",
                    target = "Lcom/qendolin/betterclouds/compat/GLCompat;shaderSource(ILjava/lang/String;)V"),
            index = 1)
    private String invfix$seriousPunchClouds(String source) {
        try {
            return SeriousPunchSky.patch(source);
        } catch (Throwable t) {
            SeriousPunchSky.failed("Better Clouds shader source", t);
            return source;
        }
    }

    @Inject(method = "bind", at = @At("TAIL"))
    private void invfix$seriousPunchUniforms(CallbackInfo ci) {
        try {
            SeriousPunchSky.upload(programId);
        } catch (Throwable t) {
            SeriousPunchSky.failed("Better Clouds uniforms", t);
        }
    }
}
