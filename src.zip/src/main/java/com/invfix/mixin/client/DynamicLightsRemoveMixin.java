package com.invfix.mixin.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import toni.sodiumdynamiclights.DynamicLightSource;
import toni.sodiumdynamiclights.SodiumDynamicLights;

import java.util.Set;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Sodium Dynamic Lights снимает источник света при BlockEntity.setRemoved — у каждого блок-энтити, светит он
 * или нет. removeLightSource всегда берёт блокировку на запись, а потоки сборки чанков Sodium в это время
 * держат блокировку на чтение (свет для вершин) — основной поток ждёт. При замене чанков после респавна это
 * сотни ожиданий подряд (spark: 0,3–0,5 с на респавн). Здесь до этого — проверка под блокировкой на чтение
 * тем же сравнением, что у мода (equals каждого элемента): источника в наборе нет — снимать нечего, родной
 * метод и так ничего бы не сделал. Есть — дальше родной метод без изменений.
 */
@Mixin(value = SodiumDynamicLights.class, remap = false)
public abstract class DynamicLightsRemoveMixin {

    @Shadow
    @Final
    private Set<DynamicLightSource> dynamicLightSources;

    @Shadow
    @Final
    private ReentrantReadWriteLock lightSourcesLock;

    @Inject(method = "removeLightSource", at = @At("HEAD"), cancellable = true, require = 0)
    private void invfix$skipAbsent(DynamicLightSource lightSource, CallbackInfo ci) {
        boolean present = false;
        this.lightSourcesLock.readLock().lock();
        try {
            for (DynamicLightSource it : this.dynamicLightSources) {
                if (it.equals(lightSource)) {
                    present = true;
                    break;
                }
            }
        } finally {
            this.lightSourcesLock.readLock().unlock();
        }
        if (!present) ci.cancel();
    }
}
