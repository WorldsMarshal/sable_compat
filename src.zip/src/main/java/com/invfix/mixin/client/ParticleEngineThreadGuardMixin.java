package com.invfix.mixin.client;

import com.google.common.collect.Queues;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.world.entity.Entity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * «Пропадают все частицы и анимация подбора» + утечка памяти до OutOfMemoryError.
 *
 * Очередь новых частиц ParticleEngine#particlesToAdd — обычный ArrayDeque без
 * синхронизации, её сливает в живые частицы только конец tick() на потоке отрисовки.
 * Если какой-то мод зовёт add/createTrackingEmitter с другого потока (сеть, физика,
 * пул задач), гонка ломает очередь: poll() возвращает null, хотя в ней лежат частицы.
 * Тогда слив каждый тик останавливается сразу, все новые частицы (и предметы, летящие
 * при подборе — это тоже частица) копятся в ней навсегда: видно ничего не становится,
 * а очередь растёт до десятков миллионов объектов.
 *
 * Здесь: вызовы не с потока игры переносятся на него (в очередь задач Minecraft,
 * она потокобезопасна), виновник один раз пишется в лог со стеком. Если очередь всё
 * равно оказалась сломана (в конце tick() она непуста, а голова пуста — в одном потоке
 * это невозможно), она заменяется новой, и это тоже пишется в лог.
 */
@Mixin(ParticleEngine.class)
public abstract class ParticleEngineThreadGuardMixin {

    @Unique
    private static final Logger INVFIX_LOG = LoggerFactory.getLogger("invfix/particles");
    /** Больше разных виновников в лог не пишется. */
    @Unique
    private static final int INVFIX_MAX_REPORTS = 16;
    @Unique
    private static final Set<String> INVFIX_REPORTED = ConcurrentHashMap.newKeySet();
    @Unique
    private static int invfix$repairs;

    @Shadow @Final @Mutable private Queue<Particle> particlesToAdd;

    @Shadow public abstract void add(Particle effect);

    @Shadow public abstract void createTrackingEmitter(Entity entity, ParticleOptions particleData);

    @Shadow public abstract void createTrackingEmitter(Entity entity, ParticleOptions data, int lifetime);

    @Inject(method = "add", at = @At("HEAD"), cancellable = true)
    private void invfix$addOnGameThread(Particle effect, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.isSameThread()) return;
        ci.cancel();
        invfix$report("add");
        mc.execute(() -> add(effect));
    }

    @Inject(method = "createTrackingEmitter(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/particles/ParticleOptions;)V",
            at = @At("HEAD"), cancellable = true)
    private void invfix$emitterOnGameThread(Entity entity, ParticleOptions data, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.isSameThread()) return;
        ci.cancel();
        invfix$report("createTrackingEmitter");
        mc.execute(() -> createTrackingEmitter(entity, data));
    }

    @Inject(method = "createTrackingEmitter(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/particles/ParticleOptions;I)V",
            at = @At("HEAD"), cancellable = true)
    private void invfix$emitterOnGameThread(Entity entity, ParticleOptions data, int lifetime, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || mc.isSameThread()) return;
        ci.cancel();
        invfix$report("createTrackingEmitter");
        mc.execute(() -> createTrackingEmitter(entity, data, lifetime));
    }

    /**
     * Конец tick(): слив шёл до poll() == null. Непустая очередь с пустой головой — признак
     * сломанной гонкой (в целой очереди голова пуста только у пустой).
     */
    @Inject(method = "tick", at = @At("RETURN"))
    private void invfix$repairBrokenQueue(CallbackInfo ci) {
        if (particlesToAdd.isEmpty() || particlesToAdd.peek() != null) return;
        int stuck = particlesToAdd.size();
        // новая очередь, а не clear(): у сломанной мог вырасти огромный массив, он не сжимается
        particlesToAdd = Queues.newArrayDeque();
        if (invfix$repairs < INVFIX_MAX_REPORTS) {
            invfix$repairs++;
            INVFIX_LOG.warn("[particles] очередь новых частиц была сломана (после слива осталось {}), заменена новой", stuck);
        }
    }

    @Unique
    private static void invfix$report(String what) {
        Thread thread = Thread.currentThread();
        StackTraceElement[] stack = thread.getStackTrace();
        String culprit = "?";
        for (StackTraceElement e : stack) {
            String c = e.getClassName();
            if (c.startsWith("java.") || c.startsWith("jdk.") || c.startsWith("net.minecraft.")
                    || c.startsWith("com.invfix.mixin.client.ParticleEngineThreadGuardMixin")
                    || e.getMethodName().contains("invfix$")) continue;
            culprit = c + "#" + e.getMethodName();
            break;
        }
        String key = what + "|" + culprit;
        if (INVFIX_REPORTED.size() >= INVFIX_MAX_REPORTS || !INVFIX_REPORTED.add(key)) return;
        INVFIX_LOG.warn("[particles] {} вызван не с потока игры (поток \"{}\", вызвал {}) — перенесено на поток игры",
                what, thread.getName(), culprit, new Throwable("стек вызова"));
    }
}
