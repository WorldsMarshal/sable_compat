package com.invfix.mixin.client;

import com.invfix.rick.portalgun.PortalGunItem;
import com.invfix.rick.portalgun.client.PortalGunRecoilManager;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Порт ItemInHandRendererMixin из Rick's stuff 0.0.4.3: пушка в руке не
 * «ныряет» при использовании и не машет при ударе, а при выстреле получает
 * отдачу от PortalGunRecoilManager.
 */
@Mixin(ItemInHandRenderer.class)
public abstract class PortalGunItemInHandMixin {

    @Inject(method = "itemUsed", at = @At("HEAD"), cancellable = true)
    private void sable_compat$preventPortalGunItemUsedDip(InteractionHand hand, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.player.getItemInHand(hand).getItem() instanceof PortalGunItem) {
            ci.cancel();
        }
    }

    @ModifyVariable(method = "renderArmWithItem", at = @At("HEAD"), argsOnly = true, ordinal = 2)
    private float sable_compat$cancelPortalGunSwing(float swingProgress, AbstractClientPlayer player, float partialTicks,
                                                    float pitch, InteractionHand hand, float sp, ItemStack stack) {
        return stack.getItem() instanceof PortalGunItem ? 0.0F : swingProgress;
    }

    @Inject(method = "renderArmWithItem", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderItem(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;ZLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"))
    private void sable_compat$applyPortalGunRecoil(AbstractClientPlayer player, float partialTicks, float pitch,
                                                   InteractionHand hand, float swingProgress, ItemStack stack,
                                                   float equipProgress, PoseStack poseStack, MultiBufferSource buffer,
                                                   int combinedLight, CallbackInfo ci) {
        if (stack.getItem() instanceof PortalGunItem) {
            PortalGunRecoilManager.applyFirstPersonRecoil(poseStack, player, hand, partialTicks);
        }
    }
}
