package com.invfix.mixin.client.createcybernetics;

import com.invfix.cyberware.CyberwareItems;
import com.perigrine3.createcybernetics.api.CyberwareSlot;
import com.perigrine3.createcybernetics.client.skin.SkinModifier;
import com.perigrine3.createcybernetics.client.skin.SkinModifierManager;
import com.perigrine3.createcybernetics.client.skin.SkinModifierState;
import com.perigrine3.createcybernetics.common.capabilities.PlayerCyberwareData;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Отрисовка бионических протезов на теле игрока.
 *
 * Система скина createcybernetics ({@code SkinModifierManager#getPlayerSkinState})
 * добавляет текстуру конечности только для своих КОНКРЕТНЫХ предметов
 * (через {@code data.hasSpecificItem(...)}), теги она не проверяет — поэтому
 * наши протезы без этого хука не отображались.
 *
 * Метод кэширует state на игрока, но в начале каждого вызова делает
 * {@code clearModifiers()} и пересобирает — поэтому добавление наших
 * модификаторов на RETURN безопасно и не накапливается.
 *
 * Текстуры — осветлённые версии базовых ({@code bionic_*arm/leg}). Применяется
 * только при наличии createcybernetics (гейт в InvincibleIncMixinTransformer).
 */
@Mixin(value = SkinModifierManager.class, remap = false)
public abstract class BionicSkinMixin {

    private static final ResourceLocation INVFIX_LARM_WIDE =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/bionic_leftarm_wide.png");
    private static final ResourceLocation INVFIX_LARM_SLIM =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/bionic_leftarm_slim.png");
    private static final ResourceLocation INVFIX_RARM_WIDE =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/bionic_rightarm_wide.png");
    private static final ResourceLocation INVFIX_RARM_SLIM =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/bionic_rightarm_slim.png");
    private static final ResourceLocation INVFIX_LLEG =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/bionic_leftleg.png");
    private static final ResourceLocation INVFIX_RLEG =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/bionic_rightleg.png");
    private static final ResourceLocation INVFIX_MK2_LARM_WIDE =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/bionic_mk2_leftarm_wide.png");
    private static final ResourceLocation INVFIX_MK2_LARM_SLIM =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/bionic_mk2_leftarm_slim.png");
    private static final ResourceLocation INVFIX_MK2_RARM_WIDE =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/bionic_mk2_rightarm_wide.png");
    private static final ResourceLocation INVFIX_MK2_RARM_SLIM =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/bionic_mk2_rightarm_slim.png");
    private static final ResourceLocation INVFIX_MK2_LLEG =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/bionic_mk2_leftleg.png");
    private static final ResourceLocation INVFIX_MK2_RLEG =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/bionic_mk2_rightleg.png");
    private static final ResourceLocation INVFIX_TORSO =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/entity/conversion_torso.png");

    @Inject(method = "getPlayerSkinState", at = @At("RETURN"), remap = false)
    private static void invfix_addBionicSkins(AbstractClientPlayer player,
                                              CallbackInfoReturnable<SkinModifierState> cir) {
        SkinModifierState state = cir.getReturnValue();
        if (state == null) {
            return;
        }
        PlayerCyberwareData data = PlayerCyberwareData.getForVisual(player, player.registryAccess());
        if (data == null) {
            return;
        }
        if (data.hasSpecificItem(CyberwareItems.BIONIC_LEFTARM.get(), CyberwareSlot.LARM)) {
            state.addModifier(SkinModifier.leftArm(INVFIX_LARM_WIDE, INVFIX_LARM_SLIM, -1));
        }
        if (data.hasSpecificItem(CyberwareItems.BIONIC_RIGHTARM.get(), CyberwareSlot.RARM)) {
            state.addModifier(SkinModifier.rightArm(INVFIX_RARM_WIDE, INVFIX_RARM_SLIM, -1));
        }
        if (data.hasSpecificItem(CyberwareItems.BIONIC_LEFTLEG.get(), CyberwareSlot.LLEG)) {
            state.addModifier(SkinModifier.leftLeg(INVFIX_LLEG, INVFIX_LLEG, -1));
        }
        if (data.hasSpecificItem(CyberwareItems.BIONIC_RIGHTLEG.get(), CyberwareSlot.RLEG)) {
            state.addModifier(SkinModifier.rightLeg(INVFIX_RLEG, INVFIX_RLEG, -1));
        }
        // Mk2 — тонировка в палитре Райдена (тёмный сине-серый).
        if (data.hasSpecificItem(CyberwareItems.MK2_LEFTARM.get(), CyberwareSlot.LARM)) {
            state.addModifier(SkinModifier.leftArm(INVFIX_MK2_LARM_WIDE, INVFIX_MK2_LARM_SLIM, -1));
        }
        if (data.hasSpecificItem(CyberwareItems.MK2_RIGHTARM.get(), CyberwareSlot.RARM)) {
            state.addModifier(SkinModifier.rightArm(INVFIX_MK2_RARM_WIDE, INVFIX_MK2_RARM_SLIM, -1));
        }
        if (data.hasSpecificItem(CyberwareItems.MK2_LEFTLEG.get(), CyberwareSlot.LLEG)) {
            state.addModifier(SkinModifier.leftLeg(INVFIX_MK2_LLEG, INVFIX_MK2_LLEG, -1));
        }
        if (data.hasSpecificItem(CyberwareItems.MK2_RIGHTLEG.get(), CyberwareSlot.RLEG)) {
            state.addModifier(SkinModifier.rightLeg(INVFIX_MK2_RLEG, INVFIX_MK2_RLEG, -1));
        }
        // Полная конверсия: железный торс при установленном импланте конверсии кожи.
        // Голова остаётся игрока; конечности — ironplated из createcybernetics (свой визуал).
        if (data.hasSpecificItem(CyberwareItems.CONVERSION_SKIN.get(), CyberwareSlot.SKIN)) {
            state.addModifier(SkinModifier.body(INVFIX_TORSO, INVFIX_TORSO, -1));
        }
    }
}
