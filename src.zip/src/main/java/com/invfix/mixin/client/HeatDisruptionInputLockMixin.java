package com.invfix.mixin.client;

import com.invfix.heatdisruption.client.HeatDisruptionClient;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Heat Disruption: пока идёт зарядка и луч, клавиши движения не двигают тело.
 * Та же точка, что у The Shooting Star (KeyboardInputMixin, mc1211):
 * KeyboardInput.tick(boolean, float), в конце — весь ввод в ноль.
 */
@Mixin(KeyboardInput.class)
public abstract class HeatDisruptionInputLockMixin extends Input {

    @Inject(method = "tick", at = @At("TAIL"))
    private void invfix$holdForHeatDisruption(boolean slow, float slowFactor, CallbackInfo ci) {
        if (HeatDisruptionClient.headLocked()) {
            this.up = false;
            this.down = false;
            this.left = false;
            this.right = false;
            this.jumping = false;
            this.shiftKeyDown = false;
            this.leftImpulse = 0.0F;
            this.forwardImpulse = 0.0F;
        }
    }
}
