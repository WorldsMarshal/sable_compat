package com.invfix.mixin.client;

import com.invfix.compat.MinecoloniesSkinFetcher;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.UUID;

/**
 * VisitorDataView.getCustomTexture (MineColonies 1.21) без затопления
 * Util.backgroundExecutor(): та же логика, но профиль берётся через
 * {@link MinecoloniesSkinFetcher} — один запрос на UUID на своём потоке.
 * Подробности — в MinecoloniesSkinFetcher.
 *
 * Классы MineColonies не нужны при компиляции: цель — строкой, UUID — через
 * публичный getCustomTextureUUID() суперкласса CitizenDataView. Применяется только
 * при загруженном minecolonies (InvincibleIncMixinTransformer).
 */
@Mixin(targets = "com.minecolonies.core.colony.VisitorDataView", remap = false)
public abstract class MinecoloniesVisitorSkinMixin {

    @Shadow private GameProfile cachedProfile;
    @Shadow private volatile ResourceLocation cachedTexture;

    @Unique private static MethodHandle invfix$uuidGetter;
    @Unique private static boolean invfix$lookupFailed;

    @Inject(method = "getCustomTexture", at = @At("HEAD"), cancellable = true)
    private void invfix$getCustomTexture(CallbackInfoReturnable<ResourceLocation> cir) {
        UUID id = invfix$uuid(this);
        if (invfix$lookupFailed) return; // не смогли найти геттер — пусть работает оригинал
        if (id == null) {
            cir.setReturnValue(null);
            return;
        }
        if (cachedProfile == null) {
            GameProfile profile = MinecoloniesSkinFetcher.getOrRequest(id);
            if (profile != null) cachedProfile = profile;
        }
        ResourceLocation fallback = DefaultPlayerSkin.get(id).texture();
        if (cachedProfile != null && cachedTexture == null) {
            ResourceLocation texture = Minecraft.getInstance().getSkinManager().getInsecureSkin(cachedProfile).texture();
            if (texture != fallback) cachedTexture = texture;
        }
        cir.setReturnValue(cachedTexture == null ? fallback : cachedTexture);
    }

    @Unique
    private static UUID invfix$uuid(Object self) {
        if (invfix$lookupFailed) return null;
        try {
            if (invfix$uuidGetter == null) {
                Class<?> base = Class.forName("com.minecolonies.core.colony.CitizenDataView");
                invfix$uuidGetter = MethodHandles.publicLookup()
                        .findVirtual(base, "getCustomTextureUUID", MethodType.methodType(UUID.class));
            }
            return (UUID) invfix$uuidGetter.invoke(self);
        } catch (Throwable t) {
            invfix$lookupFailed = true;
            return null;
        }
    }
}
