package com.invfix.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Гонка в Veil 4.1.4 (идёт внутри Sable) при параллельном конструировании модов.
 *
 * RenderTypeShardRegistry: addShard/addGenericShard — static synchronized и
 * перебирают CREATED_RENDER_TYPES (Set поверх WeakHashMap), а inject() — НЕ
 * synchronized: его зовёт миксин Veil на каждое создание CompositeRenderType, из
 * любого потока, и он пишет в тот же Set и перебирает GENERIC_SHARDS. Если в
 * момент VeilClient.init (конструктор Veil, addGenericShard) другой мод в своём
 * потоке создаёт RenderType, перебор ловит ConcurrentModificationException и
 * загрузка падает (crash 2026-09-26 17:25:51, RenderTypeShardRegistry.java:75).
 *
 * Правка: три обращения inject() к общим коллекциям выполняются под тем же
 * монитором, что и synchronized-методы класса (объект Class самого
 * RenderTypeShardRegistry); перебор GENERIC_SHARDS идёт по снимку. Обработчики
 * вливаются в сам класс, поэтому Class.forName берёт его же загрузчик.
 */
@Mixin(targets = "foundry.veil.api.client.registry.RenderTypeShardRegistry", remap = false)
public abstract class VeilShardRegistrySyncMixin {

    @Unique
    private static Object invfix$lock() {
        try {
            return Class.forName("foundry.veil.api.client.registry.RenderTypeShardRegistry");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException(e);
        }
    }

    @Redirect(method = "inject", remap = false,
            at = @At(value = "INVOKE", target = "Ljava/util/Map;get(Ljava/lang/Object;)Ljava/lang/Object;", remap = false))
    private static Object invfix$syncGet(Map<?, ?> map, Object key) {
        synchronized (invfix$lock()) {
            Object value = map.get(key);
            // Veil копирует этот список (new ArrayList<>(shards)) уже вне монитора
            return value instanceof java.util.List<?> list ? new ArrayList<>(list) : value;
        }
    }

    @Redirect(method = "inject", remap = false,
            at = @At(value = "INVOKE", target = "Ljava/util/Set;iterator()Ljava/util/Iterator;", remap = false))
    private static Iterator<?> invfix$syncIterator(Set<?> set) {
        synchronized (invfix$lock()) {
            return new ArrayList<>(set).iterator();
        }
    }

    @Redirect(method = "inject", remap = false,
            at = @At(value = "INVOKE", target = "Ljava/util/Set;add(Ljava/lang/Object;)Z", remap = false))
    private static boolean invfix$syncAdd(Set<Object> set, Object value) {
        synchronized (invfix$lock()) {
            return set.add(value);
        }
    }
}
