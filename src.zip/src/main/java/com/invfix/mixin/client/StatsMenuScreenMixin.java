package com.invfix.mixin.client;

import com.invfix.scourge.ScourgeSyncPacket;
import com.invfix.scourge.client.ScourgeClientState;
import net.mcreator.invincibleinc.procedures.ShowDurabilityProcedure;
import net.mcreator.invincibleinc.procedures.ShowHealthProcedure;
import net.mcreator.invincibleinc.procedures.ShowSpeedProcedure;
import net.mcreator.invincibleinc.procedures.ShowStrProcedure;
import net.mcreator.invincibleinc.world.inventory.StatsMenuMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.text.DecimalFormat;

/**
 * Дорисовывает рядом с текущим статом замороженное значение в скобках,
 * пока локальный игрок заражён Scourge Virus. Значения берутся из снимка,
 * присланного сервером ({@link ScourgeSyncPacket} → {@link ScourgeClientState}).
 *
 * Формат скобки совпадает с форматом самих статов (DecimalFormat "##").
 * Координаты — те же, что у оригинальных подписей в renderLabels.
 */
@Mixin(value = net.mcreator.invincibleinc.client.gui.StatsMenuScreen.class, remap = false)
public abstract class StatsMenuScreenMixin extends AbstractContainerScreen<StatsMenuMenu> {

    @Shadow @Final private Player entity;

    private static final DecimalFormat SCOURGE_FMT = new DecimalFormat("##");
    private static final int SCOURGE_COLOR = 0x77DD77; // мягко-зелёный «вернётся»

    public StatsMenuScreenMixin(StatsMenuMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
    }

    @Inject(method = "renderLabels", at = @At("TAIL"), remap = false)
    private void invfix_scourgeFrozenLabels(GuiGraphics g, int mouseX, int mouseY, CallbackInfo ci) {
        try {
            if (entity == null) return;
            ScourgeSyncPacket s = ScourgeClientState.get(entity.getId());
            if (s == null) return;

            // Координаты совпадают с оригинальными подписями статов.
            drawFrozen(g, ShowStrProcedure.execute(entity),        258, 83,
                    pair(s.currentStr(), s.trueStr()));
            drawFrozen(g, ShowDurabilityProcedure.execute(entity), 263, 115,
                    pair(s.currentDura(), s.trueDura()));
            drawFrozen(g, ShowSpeedProcedure.execute(entity),      235, 162,
                    pair(s.currendSpeed(), s.trueSpeed()));
            drawFrozen(g, ShowHealthProcedure.execute(entity),     239, 195,
                    "(" + SCOURGE_FMT.format(s.currentHealth()) + ")");
        } catch (Exception ignored) {}
    }

    private static String pair(double a, double b) {
        return "(" + SCOURGE_FMT.format(a) + ":" + SCOURGE_FMT.format(b) + ")";
    }

    private void drawFrozen(GuiGraphics g, String actual, int x, int y, String paren) {
        if (actual == null) actual = "";
        int offset = this.font.width(actual) + 3;
        g.drawString(this.font, paren, x + offset, y, SCOURGE_COLOR, false);
    }
}