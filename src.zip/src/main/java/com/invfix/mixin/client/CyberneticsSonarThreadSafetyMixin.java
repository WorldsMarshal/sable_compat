package com.invfix.mixin.client;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.List;

/**
 * Фикс гонки потоков в сонаре Create: Cybernetics (0.4.7b).
 *
 * SonarPingManager.PINGS — несинхронизированный static ArrayList, но пишут в него
 * из ДВУХ потоков: onPlaySoundEvent приходит в клиентском тике, а
 * onPlaySoundSourceEvent / onPlayStreamingSourceEvent NeoForge стреляет из потока
 * звукового движка («Sound engine»). Параллельно клиентский тик гоняет
 * prune()/snapshotNewestFirst()/clear(). Итог — обратный цикл в pruneInvalidEntries
 * читает get(i) после того, как другой поток изменил размер списка:
 * IndexOutOfBoundsException: Index 15 out of bounds for length 15 → «дисконнект».
 *
 * Сами алгоритмы менеджера корректны, поэтому НЕ переписываем их, а даём всем
 * входам взаимное исключение: каждый публичный метод выполняется целиком под одним
 * локом. pruneInvalidEntries отдельно не оборачиваем — он вызывается только изнутри
 * push и попадает под его лок (synchronized реентерабелен).
 *
 * Цель задана строкой (remap=false) и гейтится в InvincibleIncMixinTransformer:
 * миксин применяется только если загружен createcybernetics.
 */
@Mixin(targets = "com.perigrine3.createcybernetics.client.sonar.SonarPingManager", remap = false)
public class CyberneticsSonarThreadSafetyMixin {

    @Unique
    private static final Object INVFIX_SONAR_LOCK = new Object();

    @WrapMethod(method = "push", remap = false)
    private static void invfix_syncPush(Vec3 worldPos, Operation<Void> original) {
        synchronized (INVFIX_SONAR_LOCK) {
            original.call(worldPos);
        }
    }

    @WrapMethod(method = "prune", remap = false)
    private static void invfix_syncPrune(float lifeSeconds, Operation<Void> original) {
        synchronized (INVFIX_SONAR_LOCK) {
            original.call(lifeSeconds);
        }
    }

    @SuppressWarnings("rawtypes")
    @WrapMethod(method = "snapshotNewestFirst", remap = false)
    private static List invfix_syncSnapshot(Operation<List> original) {
        synchronized (INVFIX_SONAR_LOCK) {
            return original.call();
        }
    }

    @WrapMethod(method = "clear", remap = false)
    private static void invfix_syncClear(Operation<Void> original) {
        synchronized (INVFIX_SONAR_LOCK) {
            original.call();
        }
    }
}