package com.invfix.mixin.client;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Совместимость с модом Neat.
 *
 * Neat решает, рисовать ли свою плашку HP над сущностью, в методе
 * {@code HealthBarRenderer.shouldShowPlate(LivingEntity, Entity)}. Для игроков
 * это поведение нас не устраивает (плашка не прячется в приседе и вообще
 * дублирует ванильный ник). Поэтому для любого {@link Player} сразу возвращаем
 * false — Neat полностью игнорирует игроков, остаётся чистая ванильная плашка
 * ника со всеми её механиками. На остальных мобов это никак не влияет.
 *
 * Таргетимся по строковому имени класса с remap=false: жёсткой зависимости на
 * Neat нет, а применение миксина гейтится в InvincibleIncMixinTransformer по
 * наличию мода "neat".
 */
@Mixin(targets = "vazkii.neat.HealthBarRenderer", remap = false)
public class NeatNoPlayerPlatesMixin {

    @Inject(method = "shouldShowPlate", at = @At("HEAD"), cancellable = true)
    private static void invfix_noPlatesOnPlayers(LivingEntity living, Entity cameraEntity,
                                                 CallbackInfoReturnable<Boolean> cir) {
        if (living instanceof Player) {
            cir.setReturnValue(false);
        }
    }
}