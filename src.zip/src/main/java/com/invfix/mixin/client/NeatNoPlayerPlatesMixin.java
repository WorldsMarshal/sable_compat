package com.invfix.mixin.client;

import com.invfix.shapeshift.MorphState;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Совместимость с модом Neat.
 *
 * Neat решает, рисовать ли свою плашку HP над сущностью, в методе
 * {@code HealthBarRenderer.shouldShowPlate(LivingEntity, Entity)}. Для игроков
 * это поведение нас не устраивает (плашка не прячется в приседе и вообще
 * дублирует ванильный ник, а по ХП читается раса). Поэтому для любого {@link Player}
 * сразу возвращаем false — Neat полностью игнорирует игроков, остаётся чистая
 * ванильная плашка ника со всеми её механиками. На остальных мобов это никак не влияет.
 *
 * Shapeshifter: игрок в морфе для Neat — его моб. Над ним плашка куклы морфа: имя моба
 * и ХП моба (полное — доля ХП игрока, переложенная на моба), как над настоящим мобом.
 * Для этого вызов {@code hookRender} с игроком перенаправляется на куклу, а «на кого
 * смотрит камера» (режим «только цель») отвечает куклой вместо игрока. Морф игрока —
 * кукла-игрок, и плашки у неё, как у всех игроков, нет.
 *
 * Таргетимся по строковому имени класса с remap=false: жёсткой зависимости на
 * Neat нет, а применение миксина гейтится в InvincibleIncMixinTransformer по
 * наличию мода "neat".
 */
@Mixin(targets = "vazkii.neat.HealthBarRenderer", remap = false)
public class NeatNoPlayerPlatesMixin {

    @Unique
    private static boolean invfix$redirecting;

    @Shadow
    public static void hookRender(Entity entity, PoseStack poseStack, MultiBufferSource buffers, Camera camera,
                                  EntityRenderer<? super Entity> entityRenderer, float partialTicks,
                                  double x, double y, double z) {
        throw new AssertionError();
    }

    @Inject(method = "shouldShowPlate", at = @At("HEAD"), cancellable = true)
    private static void invfix_noPlatesOnPlayers(LivingEntity living, Entity cameraEntity,
                                                 CallbackInfoReturnable<Boolean> cir) {
        if (living instanceof Player) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "hookRender", at = @At("HEAD"), cancellable = true)
    @SuppressWarnings("unchecked")
    private static void invfix_morphPlate(Entity entity, PoseStack poseStack, MultiBufferSource buffers, Camera camera,
                                          EntityRenderer<? super Entity> entityRenderer, float partialTicks,
                                          double x, double y, double z, CallbackInfo ci) {
        if (invfix$redirecting || !(entity instanceof Player player)) return;
        LivingEntity instance = invfix$morphOf(player);
        if (instance == null) return;
        ci.cancel();
        if (player == camera.getEntity()) return; // над собой плашки нет (как у Neat для камеры)
        invfix$redirecting = true;
        try {
            EntityRenderer<? super Entity> r = (EntityRenderer<? super Entity>) (Object)
                    Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(instance);
            hookRender(instance, poseStack, buffers, camera, r, partialTicks, x, y, z);
        } catch (Throwable ignored) {
        } finally {
            invfix$redirecting = false;
        }
    }

    /** Режим «плашка только у цели»: цель-игрок в морфе — это его кукла. */
    @Inject(method = "getEntityLookedAt", at = @At("RETURN"), cancellable = true)
    private static void invfix_lookedAtMorph(Entity e, CallbackInfoReturnable<Entity> cir) {
        if (cir.getReturnValue() instanceof Player player) {
            LivingEntity instance = invfix$morphOf(player);
            if (instance != null) cir.setReturnValue(instance);
        }
    }

    @Unique
    private static LivingEntity invfix$morphOf(Player player) {
        MorphState st = MorphState.get(player);
        if (st == null || !st.active()) return null;
        return st.current != null ? st.currentInstance(player) : st.prev != null ? st.prevInstance(player) : null;
    }
}
