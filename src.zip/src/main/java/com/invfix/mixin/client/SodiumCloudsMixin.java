package com.invfix.mixin.client;

import com.invfix.seriouspunch.client.SeriousPunchSky;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;

/**
 * Облака Sodium (sodium 0.8.12, net.caffeinemc.mods.sodium.client.render.immediate.CloudRenderer — заменяет ванильные,
 * когда Better Clouds их не рисует): облака, разогнанные Serious Punch (SeriousPunchSky).
 *  - render (HEAD): клетка-начало и снос ветром этого кадра (SeriousPunchSky#sodiumFrame);
 *  - render: геометрия перестраивается, только если изменились её параметры (Objects.equals(старые, новые)) — пока
 *    область меняется, ответ «не равны» (SeriousPunchSky#sodiumRebuild);
 *  - addCellGeometryToBuffer: грани клетки (x, z) от начала (локальная 7 — getCellFaces & getVisibleFaces) — в
 *    разогнанной ни одной (дальше Sodium сам выходит: «граней нет»), у края дыры — стенки к ней
 *    (SeriousPunchSky#sodiumFaces). Типы Sodium недоступны при сборке — @Coerce до Object.
 *
 * Таргет — по строковому имени с remap=false; применение гейтится в InvincibleIncMixinTransformer по наличию мода
 * "sodium"; все инъекции require = 0: другая версия Sodium — просто без выреза, без падения.
 */
@Mixin(targets = "net.caffeinemc.mods.sodium.client.render.immediate.CloudRenderer", remap = false)
public abstract class SodiumCloudsMixin {

    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void invfix$seriousPunchFrame(Camera camera, ClientLevel level, Matrix4f projection, PoseStack poseStack,
                                          float ticks, float partial, CallbackInfo ci) {
        try {
            SeriousPunchSky.sodiumFrame(camera.getPosition(), ticks, partial);
        } catch (Throwable t) {
            SeriousPunchSky.failed("Sodium clouds (frame)", t);
        }
    }

    @Redirect(method = "render",
            at = @At(value = "INVOKE", target = "Ljava/util/Objects;equals(Ljava/lang/Object;Ljava/lang/Object;)Z"),
            require = 0)
    private boolean invfix$seriousPunchRebuild(Object built, Object wanted) {
        boolean same = Objects.equals(built, wanted);
        try {
            return same && !SeriousPunchSky.sodiumRebuild();
        } catch (Throwable t) {
            SeriousPunchSky.failed("Sodium clouds (rebuild)", t);
            return same;
        }
    }

    @ModifyVariable(method = "addCellGeometryToBuffer", at = @At("STORE"), index = 7, require = 0)
    private static int invfix$seriousPunchCell(int faces, @Coerce Object writer, @Coerce Object slice, int x, int z) {
        try {
            return SeriousPunchSky.sodiumFaces(faces, x, z);
        } catch (Throwable t) {
            SeriousPunchSky.failed("Sodium clouds (cell)", t);
            return faces;
        }
    }
}
