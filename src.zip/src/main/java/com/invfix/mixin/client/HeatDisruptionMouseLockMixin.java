package com.invfix.mixin.client;

import com.invfix.heatdisruption.client.HeatDisruptionClient;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/**
 * Heat Disruption: пока идёт зарядка и луч, мышь не поворачивает голову.
 * Та же точка, что у The Shooting Star (MouseTurnMixin, mc1211): аргументы
 * LocalPlayer.turn(dx, dy) в MouseHandler.turnPlayer.
 */
@Mixin(MouseHandler.class)
public abstract class HeatDisruptionMouseLockMixin {

    @ModifyArg(method = "turnPlayer",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;turn(DD)V"),
            index = 0)
    private double invfix$lockYaw(double dx) {
        return HeatDisruptionClient.headLocked() ? 0.0 : dx;
    }

    @ModifyArg(method = "turnPlayer",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;turn(DD)V"),
            index = 1)
    private double invfix$lockPitch(double dy) {
        return HeatDisruptionClient.headLocked() ? 0.0 : dy;
    }
}
