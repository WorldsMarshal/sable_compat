package com.invfix.mixin.client;

import com.invfix.xcoin.client.XCoinClient;
import com.invfix.xcoin.client.XCoinHand;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Фокус X Coin от третьего лица: главная рука поднимается перед лицом (XCoinClient#armPose), рывок кистью
 * (поворот по Z), потом опускается; голова чуть склоняется к руке. Вес позы — XCoinClient#raise.
 * Отрисовка руки от первого лица (PlayerRenderer#renderHand зовёт setupAnim) — без позы: там свой рендер.
 */
@Mixin(value = PlayerModel.class, priority = 3000)
public class XCoinPoseMixin {

    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At("RETURN"))
    private void invfix$xCoinPose(LivingEntity entity, float limbSwing, float limbSwingAmount,
                                  float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo ci) {
        if (!(entity instanceof Player player) || XCoinHand.firstPersonArm) return;
        float partial = Minecraft.getInstance().getTimer().getGameTimeDeltaPartialTick(false);
        XCoinClient.Trick trick = XCoinClient.trick(player.getId());
        if (trick == null) return;
        float age = XCoinClient.age(player.getId(), partial);
        if (age < 0.0F) return;
        float w = XCoinClient.raise(trick.kind(), age);
        if (w <= 0.0F) return;
        float[] pose = XCoinClient.armPose(XCoinClient.flick(age));
        HumanoidModel<?> model = (HumanoidModel<?>) (Object) this;
        boolean right = trick.mainRight();
        float s = right ? 1.0F : -1.0F;
        ModelPart arm = right ? model.rightArm : model.leftArm;
        arm.xRot = Mth.lerp(w, arm.xRot, pose[0]);
        arm.yRot = Mth.lerp(w, arm.yRot, pose[1] * s);
        arm.zRot = Mth.lerp(w, arm.zRot, pose[2] * s);
        PlayerModel<?> pm = (PlayerModel<?>) (Object) this;
        (right ? pm.rightSleeve : pm.leftSleeve).copyFrom(arm);
        model.head.xRot += 0.12F * w;
        model.head.yRot += -0.18F * w * s;
        model.hat.copyFrom(model.head);
    }
}
