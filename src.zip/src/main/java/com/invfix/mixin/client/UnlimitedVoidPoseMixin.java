package com.invfix.mixin.client;

import com.invfix.unlimitedvoid.client.UnlimitedVoidClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Каст Unlimited Void — простая поза R6: правая рука вытянута вперёд (по взгляду),
 * голова чуть склонена вперёд. Плавно входит за 4 тика, держится до первого удара звука,
 * уходит за 10 тиков (UnlimitedVoidFx#castPose).
 */
@Mixin(value = PlayerModel.class, priority = 3000)
public class UnlimitedVoidPoseMixin {

    private static final float HEAD_TILT = 0.38F;

    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At("RETURN"))
    private void invfix$unlimitedVoidPose(LivingEntity entity, float limbSwing, float limbSwingAmount,
                                         float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo ci) {
        if (!(entity instanceof Player player)) return;
        float w = UnlimitedVoidClient.castPose(player.getId(),
                Minecraft.getInstance().getTimer().getGameTimeDeltaPartialTick(false));
        if (w <= 0.0F) return;
        HumanoidModel<?> model = (HumanoidModel<?>) (Object) this;
        float pitch = headPitch * Mth.DEG_TO_RAD;
        float yaw = netHeadYaw * Mth.DEG_TO_RAD;

        model.head.xRot = pitch + HEAD_TILT * w;
        model.hat.copyFrom(model.head);

        ModelPart arm = model.rightArm;
        arm.xRot = Mth.lerp(w, arm.xRot, -Mth.HALF_PI + pitch);
        arm.yRot = Mth.lerp(w, arm.yRot, -0.1F + yaw);
        arm.zRot = Mth.lerp(w, arm.zRot, 0.0F);
        ModelPart sleeve = ((PlayerModel<?>) (Object) this).rightSleeve;
        sleeve.copyFrom(arm);
    }
}
