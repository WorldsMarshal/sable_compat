package com.invfix.mixin.client;

import com.invfix.threatmode.ThreatModeClientEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Клиентская часть «Playful mode» для лазерных глаз The Boys: пока локальный игрок
 * держит бинд Threatening/Playful Mode, его собственный луч не рендерится (и не
 * шлёт hit-pos / звук) — остаётся только безвредная активация. Урон и луч для
 * наблюдателей гасит серверный LaserEyePlayfulMixin.
 *
 * Гейтим только локального игрока: состояние Playful известно лишь на его клиенте;
 * чужие лучи и так управляются сервером.
 */
@Pseudo
@Mixin(targets = "net.benniao.theboysmod.client.lasereye.LaserEyeClientHandler", remap = false)
public class LaserEyePlayfulClientMixin {

    @Inject(method = "isLaserActive", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void invfix_glowOnlyWhilePlayful(Player player, CallbackInfoReturnable<Boolean> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (player == mc.player && ThreatModeClientEvents.isHeld()) {
            cir.setReturnValue(false);
        }
    }
}
