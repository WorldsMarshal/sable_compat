package com.invfix.mixin.client.debug;

import com.invfix.debug.ParticleWatchdog;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.client.particle.ParticleRenderType;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.Queue;

/**
 * Наблюдение за движком частиц для ParticleWatchdog (временная диагностика): сколько раз
 * tick и render дошли до конца и что лежит в очередях. Ничего не меняет.
 */
@Mixin(ParticleEngine.class)
public abstract class ParticleEngineWatchMixin implements ParticleWatchdog.Engine {

    @Shadow protected ClientLevel level;
    @Shadow @Final private Queue<Particle> particlesToAdd;
    @Shadow @Final private Map<ParticleRenderType, Queue<Particle>> particles;

    @Inject(method = "tick", at = @At("RETURN"))
    private void invfix$watchTick(CallbackInfo ci) {
        ParticleWatchdog.tickCompleted();
    }

    @Inject(method = "render(Lnet/minecraft/client/renderer/LightTexture;Lnet/minecraft/client/Camera;FLnet/minecraft/client/renderer/culling/Frustum;Ljava/util/function/Predicate;)V",
            at = @At("RETURN"))
    private void invfix$watchRender(CallbackInfo ci) {
        ParticleWatchdog.renderCompleted();
    }

    @Override
    public ClientLevel invfix$watchLevel() {
        return level;
    }

    @Override
    public Queue<Particle> invfix$watchQueued() {
        return particlesToAdd;
    }

    @Override
    public Map<ParticleRenderType, Queue<Particle>> invfix$watchLive() {
        return particles;
    }
}
