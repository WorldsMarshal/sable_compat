package com.invfix.mixin.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Доступ к обоим полям привязки клавиши.
 *
 * {@code key} — на что клавиша назначена сейчас, {@code defaultKey} — значение
 * по умолчанию, к которому возвращает кнопка сброса в настройках управления.
 * Публичного способа поменять второе нет: поле final и приватное.
 */
@Mixin(KeyMapping.class)
public interface KeyMappingAccessor {

    @Accessor("key")
    void invfix$setBoundKey(InputConstants.Key key);

    @Mutable
    @Accessor("defaultKey")
    void invfix$setDefaultKey(InputConstants.Key key);
}