package com.invfix.mixin;

import com.invfix.threatmode.ThreatModeState;
import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * «Playful mode» для Heat Vision (лазерных глаз) мода The Boys.
 *
 * Пока зажат бинд Threatening/Playful Mode (по умолчанию Alt), лазер активируется
 * безвредно — как у нашего Heat Vision: луч не выпускается и урон не наносится.
 * Отпустил Playful при всё ещё зажатой кнопке лазера → луч стреляет как обычно
 * (skill остаётся active, мы перестаём подавлять).
 *
 * Серверная часть: гасим и урон (processLaserDamage), и синхронизацию луча
 * наблюдателям (syncVisualBeam). Локальный луч самого игрока глушится клиентским
 * миксином LaserEyePlayfulClientMixin.
 *
 * @Pseudo + require=0 + проверка в InvincibleIncMixinTransformer означают, что
 * без мода The Boys миксин просто не применяется.
 */
@Pseudo
@Mixin(targets = "net.benniao.theboysmod.server.LaserEyeDamageHandler", remap = false)
public class LaserEyePlayfulMixin {

    @Inject(method = "processLaserDamage", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void invfix_noDamageWhilePlayful(ServerPlayer player, int activeTicks, CallbackInfo ci) {
        if (ThreatModeState.isHeld(player)) ci.cancel();
    }

    @Inject(method = "syncVisualBeam", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void invfix_noBeamWhilePlayful(ServerPlayer player, CallbackInfo ci) {
        if (ThreatModeState.isHeld(player)) ci.cancel();
    }
}
