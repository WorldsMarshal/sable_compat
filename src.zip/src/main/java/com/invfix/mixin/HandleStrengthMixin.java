package com.invfix.mixin;

import dev.simulated_team.simulated.content.blocks.handle.HandleBlockEntity;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.UUID;

public class HandleStrengthMixin {

    @Mixin(
            targets = "dev.simulated_team.simulated.content.blocks.handle.HandleBlockEntity$HandleConstraint",
            remap = false
    )
    public static class HandleConstraintMixin {

        // ── рефлексивный кэш ──────────────────────────────────────────────────
        @Unique private static Field   invfix_f_outer        = null;
        @Unique private static Field   invfix_f_pid          = null;
        @Unique private static Field   invfix_f_chandle      = null; // constraintHandle
        @Unique private static Method  invfix_m_setMotor     = null;
        @Unique private static Object  invfix_linearAxes     = null; // ConstraintJointAxis.LINEAR
        @Unique private static Object  invfix_angularAxes    = null; // ConstraintJointAxis.ANGULAR
        @Unique private static boolean invfix_initDone       = false;

        @Unique
        private static boolean invfix_ensureFields() {
            if (invfix_initDone) return invfix_f_outer != null;
            invfix_initDone = true;
            try {
                Class<?> clsConstraint = Class.forName(
                        "dev.simulated_team.simulated.content.blocks.handle.HandleBlockEntity$HandleConstraint");
                Field f1 = clsConstraint.getDeclaredField("this$0");       f1.setAccessible(true);
                Field f2 = clsConstraint.getDeclaredField("playerId");     f2.setAccessible(true);
                Field f3 = clsConstraint.getDeclaredField("constraintHandle"); f3.setAccessible(true);

                // PhysicsConstraintHandle.setMotor(ConstraintJointAxis, double, double, double, boolean, double)
                Class<?> clsHandle = Class.forName(
                        "dev.ryanhcode.sable.api.physics.constraint.PhysicsConstraintHandle");
                Class<?> clsAxis = Class.forName(
                        "dev.ryanhcode.sable.api.physics.constraint.ConstraintJointAxis");
                Method m = clsHandle.getMethod(
                        "setMotor", clsAxis, double.class, double.class, double.class, boolean.class, double.class);

                // ConstraintJointAxis.LINEAR и ANGULAR — enum-поля или статические итерабельные
                Field fLinear  = clsAxis.getField("LINEAR");  fLinear.setAccessible(true);
                Field fAngular = clsAxis.getField("ANGULAR"); fAngular.setAccessible(true);

                invfix_f_outer     = f1;
                invfix_f_pid       = f2;
                invfix_f_chandle   = f3;
                invfix_m_setMotor  = m;
                invfix_linearAxes  = fLinear.get(null);
                invfix_angularAxes = fAngular.get(null);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        // ── 1. maxForce: кубическое масштабирование по расе ──────────────────
        @ModifyVariable(
                method = "physicsTick",
                at = @At("STORE"),
                ordinal = 2,
                remap = false
        )
        private double invfix_scaleMaxForce(double maxForce) {
            try {
                if (!invfix_ensureFields()) return maxForce;
                HandleBlockEntity outer = (HandleBlockEntity) invfix_f_outer.get(this);
                UUID pid               = (UUID)              invfix_f_pid.get(this);
                if (outer.getLevel() == null) return maxForce;
                Player player = outer.getLevel().getPlayerByUUID(pid);
                if (player == null) return maxForce;
                InvincibleIncModVariables.PlayerVariables vars =
                        player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                double mult = invfix_resolveMult(vars);
                return mult > 1.0 ? maxForce * mult : maxForce;
            } catch (Exception ignored) {}
            return maxForce;
        }

        // ── 2. жёсткость/демпфирование: перевызываем setMotor после оригинала ─
        //    Оригинал ставит stiffness=240, damping=30 (LINEAR).
        //    Мы перезаписываем их масштабированными значениями.
        //    Вызываем сразу после выхода из for-циклов (TAIL physicsTick).
        @Inject(
                method = "physicsTick",
                at = @At("TAIL"),
                remap = false
        )
        private void invfix_reapplyStiffness(
                dev.ryanhcode.sable.sublevel.ServerSubLevel subLevel,
                dev.ryanhcode.sable.api.physics.handle.RigidBodyHandle handle,
                CallbackInfo ci) {
            try {
                if (!invfix_ensureFields()) return;

                Object constraintHandle = invfix_f_chandle.get(this);
                if (constraintHandle == null) return; // constraint не был создан в этом тике

                HandleBlockEntity outer = (HandleBlockEntity) invfix_f_outer.get(this);
                UUID pid               = (UUID)              invfix_f_pid.get(this);
                if (outer.getLevel() == null) return;
                Player player = outer.getLevel().getPlayerByUUID(pid);
                if (player == null) return;

                InvincibleIncModVariables.PlayerVariables vars =
                        player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                double stiffMult = invfix_resolveStiffMult(vars);
                if (stiffMult <= 1.0) return; // человек/Beast — не трогаем

                // maxForce уже был вычислен и записан в constraintHandle оригиналом,
                // нам нужно только обновить stiffness и damping.
                // Читаем maxForce из поля чтобы не пересчитывать:
                double scaledMaxForce = invfix_scaleMaxForce(
                        (double) dev.simulated_team.simulated.service.SimConfigService
                                .INSTANCE.server().physics.handleMaxForce.getF());

                // LINEAR: stiffness 240→240*stiffMult, damping 30→30*sqrt(stiffMult)
                double newStiff  = 240.0 * stiffMult;
                double newDamp   = 30.0  * Math.sqrt(stiffMult);
                for (Object axis : (Iterable<?>) invfix_linearAxes) {
                    invfix_m_setMotor.invoke(constraintHandle,
                            axis, 0.0, newStiff, newDamp, true, scaledMaxForce);
                }

                // ANGULAR: stiffness 0 (не трогаем), damping 4.5→4.5*sqrt(stiffMult)
                double newAngDamp = 4.5 * Math.sqrt(stiffMult);
                for (Object axis : (Iterable<?>) invfix_angularAxes) {
                    invfix_m_setMotor.invoke(constraintHandle,
                            axis, 0.0, 0.0, newAngDamp, true, scaledMaxForce);
                }

            } catch (Exception ignored) {}
        }

        /**
         * Множитель жёсткости — нелинейный но не кубический, чтобы
         * не сделать физику нестабильной. Квадратная зависимость от str.
         * При str=500:
         *   Viltrumite          → 2500x stiffness (≈600 000)
         *   Unopan              → 625x
         *   Human-Viltrumite    → 156x
         *   Thraxan-Viltrumite  → 39x
         */
        @Unique
        private static double invfix_resolveStiffMult(
                InvincibleIncModVariables.PlayerVariables vars) {
            if (vars.Race == null) return 1.0;
            double str = Math.max(1.0, vars.currentStr);
            return switch (vars.Race) {
                case "§1§lAlien(Metroman)"          -> str * str * 0.02;
                case "§4§lViltrumite"         -> str * str * 0.01;
                case "§6§lUnopan"             -> str * str * 0.0025;
                case "§f§lHuman-Viltrumite"   -> str * str * 0.000625;
                case "§1§lThraxan-Viltrumite" -> str * str * 0.000156;
                default -> 1.0;
            };
        }

        /**
         * Формула maxForce: mult = C * str³
         *   Viltrumite           C=0.03923   → ~60 млн kpg при str=500
         *   Unopan               C=0.00596
         *   Human-Viltrumite     C=0.000853
         *   Thraxan-Viltrumite   C=0.0001307 → ~200 000 kpg при str=500
         */
        @Unique
        private static double invfix_resolveMult(
                InvincibleIncModVariables.PlayerVariables vars) {
            if (vars.Race == null) return 1.0;
            double str      = Math.max(1.0, vars.currentStr);
            double strCubed = str * str * str;
            return switch (vars.Race) {
                case "§1§lAlien(Metroman)"          -> str * str * 0.05;
                case "§4§lViltrumite"         -> strCubed * 0.03923;
                case "§6§lUnopan"             -> strCubed * 0.00596;
                case "§f§lHuman-Viltrumite"   -> strCubed * 0.000853;
                case "§1§lThraxan-Viltrumite" -> strCubed * 0.0001307;
                default                       -> 1.0;
            };
        }
    }
}