package com.invfix.mixin;

import com.invfix.theboyscompat.SyringeRaceRule;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Self-use V-шприца (правый клик): нечеловеческим расам нельзя вколоть себе
 * Compound V / Temp V — использование отменяется до начала (шприц не тратится),
 * показывается сообщение «… was created for human DNA.».
 *
 * Это ранний/чистый перехват для self-use в воздух. Инъекция ударом и клик по
 * блоку (минующий useOn) закрываются отдельно — см. SyringeAttackRaceGateMixin
 * и InjectVRaceGateMixin (единый бэкстоп на injectTarget).
 *
 * @Pseudo + require=0 + гейт в InvincibleIncMixinTransformer → без The Boys не применяется.
 */
@Pseudo
@Mixin(targets = "net.benniao.theboysmod.item.SyringeItem", remap = false)
public class SyringeRaceGateMixin {

    @Inject(method = "use", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void invfix_gateUse(Level level, Player player, InteractionHand hand,
                                CallbackInfoReturnable<InteractionResultHolder<ItemStack>> cir) {
        ItemStack stack = player.getItemInHand(hand);
        String msg = SyringeRaceRule.blockMessage(player, stack);
        if (msg != null) {
            if (!level.isClientSide) player.displayClientMessage(Component.literal(msg), true);
            cir.setReturnValue(InteractionResultHolder.pass(stack));
        }
    }

    @Inject(method = "useOn", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void invfix_gateUseOn(UseOnContext context, CallbackInfoReturnable<InteractionResult> cir) {
        Player player = context.getPlayer();
        if (player == null) return;
        String msg = SyringeRaceRule.blockMessage(player, context.getItemInHand());
        if (msg != null) {
            if (!context.getLevel().isClientSide) player.displayClientMessage(Component.literal(msg), true);
            cir.setReturnValue(InteractionResult.PASS);
        }
    }
}
