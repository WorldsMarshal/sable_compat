package com.invfix.mixin;

import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Отменяет выдачу стартового телефона при первом входе на сервер.
 *
 * StarterPhoneHandler.onPlayerLoggedIn при первом заходе выдаёт игроку телефон.
 * Метод НЕстатический (в отличие от VoughtDeathHandler), поэтому хендлер тоже
 * instance. Глушим весь обработчик в HEAD — телефон теперь крафтится.
 *
 * Почему не @Redirect на addItem: в исходнике переменная игрока имеет тип
 * ServerPlayer, и в байткоде вызов идёт как ServerPlayer.addItem, а не
 * Player.addItem — точка инъекции не находилась, и при require=0 миксин молча
 * не применялся. HEAD-инъекция от типа владельца не зависит и работает всегда.
 *
 * Примечание: вместе с выдачей телефона при входе глушится и повторная отправка
 * брифинга по «вилле» при ре-логине (на сам момент анлока он всё равно
 * рассылается онлайн-игрокам). Если брифинг нужен — пиши, дам точечный вариант.
 *
 * @Pseudo + require=0 + shouldApplyMixin в плагине: без мода The Boys миксин
 * просто не применяется.
 */
@Pseudo
@Mixin(targets = "net.benniao.theboysmod.server.StarterPhoneHandler", remap = false)
public class StarterPhoneHandlerMixin {

    @Inject(method = "onPlayerLoggedIn", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void invfix_noStarterPhone(PlayerEvent.PlayerLoggedInEvent event, CallbackInfo ci) {
        ci.cancel();
    }
}