package com.invfix.mixin;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LevelAccessor;
import net.neoforged.bus.api.Event;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Патч для WhenjoinProcedure из мода Invincible Inc (Reboot).
 *
 * БАГ: при входе в мир / присоединении к серверу мод безусловно
 * выставляет mayfly = true для ВСЕХ игроков, давая им возможность
 * летать как в креативе независимо от расы.
 *
 * ФИКС: перехватываем вызов onUpdateAbilities() сразу после того как
 * мод выставил mayfly = true. Перед тем как пробросить вызов дальше —
 * откатываем mayfly обратно в false, если у игрока нет пассивки "Flight"
 * ни в одном из слотов расы/силы.
 * Логика проверки зеркалит FlightOnOffProcedure (кнопка N) — тот же набор полей.
 */
@Mixin(value = net.mcreator.invincibleinc.procedures.WhenjoinProcedure.class, remap = false)
public class WhenjoinProcedureMixin {

    /**
     * Redirect перехватывает вызов Player#onUpdateAbilities() внутри
     * приватного метода execute() процедуры входа.
     *
     * Почему Redirect, а не Inject?
     * Mixin не может таргетить запись в поле (PUTFIELD) напрямую через @Inject.
     * Redirect на следующий после проблемной строки вызов метода — самый
     * чистый способ вклиниться именно в это место без Transpiler'а.
     */
    @Redirect(
        method = "execute(Lnet/neoforged/bus/api/Event;" +
                 "Lnet/minecraft/world/level/LevelAccessor;" +
                 "Lnet/minecraft/world/entity/Entity;)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/player/Player;onUpdateAbilities()V"
        ),
        remap = false
    )
    private static void invfix_fixMayflyOnJoin(Player player) {
        InvincibleIncModVariables.PlayerVariables vars =
            player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);

        // Зеркалим проверку из FlightOnOffProcedure — те же 8 полей
        boolean hasFlight =
            vars.racePassive1.equals("Flight") ||
            vars.racePassive2.equals("Flight") ||
            vars.racePassive3.equals("Flight") ||
            vars.racePassive4.equals("Flight") ||
            vars.power_Passive1.equals("Flight") ||
            vars.power_Passive2.equals("Flight") ||
            vars.power_Passive3.equals("Flight") ||
            vars.power_Passive4.equals("Flight");

        if (!hasFlight && !player.getAbilities().instabuild) {
            player.getAbilities().mayfly = false;
        }
        // Вызов оригинального метода в любом случае — он синхронизирует
        // способности с клиентом
        player.onUpdateAbilities();
    }
}
