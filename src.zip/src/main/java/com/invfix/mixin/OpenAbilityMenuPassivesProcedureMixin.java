package com.invfix.mixin;

import com.invfix.humanlike.HumanLikeRaces;
import io.netty.buffer.Unpooled;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.procedures.OpenAbilityMenuPassivesProcedure;
import net.mcreator.invincibleinc.world.inventory.HumanPassivesGUIMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Когда раса-затычка открывает меню пассивок — показываем то же меню,
 * что и у обычного Human (HumanPassivesGUI). Оригинальная процедура не знает
 * строк новых рас, поэтому им меню не открывалось бы вовсе.
 *
 * HEAD-инъекция: оригинальная процедура для этих рас ничего не делает,
 * так что отдельное открытие меню в HEAD ничего не дублирует.
 */
@Mixin(value = OpenAbilityMenuPassivesProcedure.class, remap = false)
public class OpenAbilityMenuPassivesProcedureMixin {

    @Inject(method = "execute", at = @At("HEAD"), remap = false)
    private static void invfix_humanLikePassivesMenu(
            LevelAccessor world, double x, double y, double z, Entity entity, CallbackInfo ci) {
        if (entity == null) return;
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (!HumanLikeRaces.isHumanLike(vars.Race)) return;
            if (!(entity instanceof ServerPlayer sp)) return;

            final BlockPos bpos = BlockPos.containing(x, y, z);
            sp.openMenu(new MenuProvider() {
                public Component getDisplayName() {
                    return Component.literal("HumanPassivesGUI");
                }
                public boolean shouldTriggerClientSideContainerClosingOnOpen() { return false; }
                public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
                    return new HumanPassivesGUIMenu(
                            id, inv, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(bpos));
                }
            }, bpos);
        } catch (Exception ignored) {}
    }
}