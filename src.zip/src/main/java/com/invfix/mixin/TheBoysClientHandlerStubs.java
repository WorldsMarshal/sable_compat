package com.invfix.mixin;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.minecraft.world.level.Level;
import net.benniao.theboysmod.network.FleshRegenSyncPacket;
import net.benniao.theboysmod.network.PlayerAnimationPlaySyncPacket;
import net.benniao.theboysmod.network.EntityAnimationPlaySyncPacket;
import net.benniao.theboysmod.network.PlayerAnimationStopSyncPacket;
import net.benniao.theboysmod.network.SkillSyncPacket;
import net.benniao.theboysmod.network.SkillActiveSyncPacket;
import net.benniao.theboysmod.network.FlightPoseSyncPacket;
import net.benniao.theboysmod.network.FleshStrengthSyncPacket;
import net.benniao.theboysmod.network.GrabSyncPacket;
import net.benniao.theboysmod.network.FireTimerSyncPacket;
import net.benniao.theboysmod.network.PhoneSmsSyncPacket;
import net.benniao.theboysmod.network.PhoneSmsImageDownloadPacket;
import net.benniao.theboysmod.network.OpenSupeDialoguePacket;
import net.benniao.theboysmod.network.NpcSupportSyncPacket;
import net.benniao.theboysmod.network.PhoneEvidenceSyncPacket;
import net.benniao.theboysmod.network.PhoneBatterySyncPacket;
import net.benniao.theboysmod.network.PhoneEvidenceReportResultPacket;
import net.benniao.theboysmod.network.PhoneNewsSyncPacket;
import net.benniao.theboysmod.network.PhoneShopSyncPacket;
import net.benniao.theboysmod.network.DossierUnlockSyncPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

/*
 * Server-only стабы клиентских хендлеров пакетов The Boys (top-level mixin-классы).
 * Каждый @Overwrite заменяет клиентский метод пакета на no-op ТОЛЬКО на dedicated-сервере,
 * чтобы класс пакета грузился под RuntimeDistCleaner (его тела больше не тянут net.minecraft.client.*).
 * Применяются через секцию "server" в sable_compat.mixins.json. На клиенте не применяются — там работают настоящие хендлеры.
 */


@Mixin(value = FleshRegenSyncPacket.class, remap = false)
abstract class StubFleshRegenSync {
    @Overwrite(remap = false)
    public static void handle(FleshRegenSyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = PlayerAnimationPlaySyncPacket.class, remap = false)
abstract class StubPlayerAnimationPlaySync {
    @Overwrite(remap = false)
    public static void handleClient(PlayerAnimationPlaySyncPacket a0, IPayloadContext a1) {}
    @Overwrite(remap = false)
    private static void applyOrQueue(Level a0, PlayerAnimationPlaySyncPacket a1) {}
}

@Mixin(value = EntityAnimationPlaySyncPacket.class, remap = false)
abstract class StubEntityAnimationPlaySync {
    @Overwrite(remap = false)
    public static void handleClient(EntityAnimationPlaySyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = PlayerAnimationStopSyncPacket.class, remap = false)
abstract class StubPlayerAnimationStopSync {
    @Overwrite(remap = false)
    public static void handleClient(PlayerAnimationStopSyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = SkillSyncPacket.class, remap = false)
abstract class StubSkillSync {
    @Overwrite(remap = false)
    public static void handle(SkillSyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = SkillActiveSyncPacket.class, remap = false)
abstract class StubSkillActiveSync {
    @Overwrite(remap = false)
    public static void handle(SkillActiveSyncPacket a0, IPayloadContext a1) {}
    @Overwrite(remap = false)
    private static void clearRemovedVisualCaches(SkillActiveSyncPacket a0) {}
}

@Mixin(value = FlightPoseSyncPacket.class, remap = false)
abstract class StubFlightPoseSync {
    @Overwrite(remap = false)
    public static void handle(FlightPoseSyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = FleshStrengthSyncPacket.class, remap = false)
abstract class StubFleshStrengthSync {
    @Overwrite(remap = false)
    public static void handle(FleshStrengthSyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = GrabSyncPacket.class, remap = false)
abstract class StubGrabSync {
    @Overwrite(remap = false)
    public static void handleClient(GrabSyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = FireTimerSyncPacket.class, remap = false)
abstract class StubFireTimerSync {
    @Overwrite(remap = false)
    public static void handle(FireTimerSyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = PhoneSmsSyncPacket.class, remap = false)
abstract class StubPhoneSmsSync {
    @Overwrite(remap = false)
    public static void handle(PhoneSmsSyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = PhoneSmsImageDownloadPacket.class, remap = false)
abstract class StubPhoneSmsImageDownload {
    @Overwrite(remap = false)
    public static void handle(PhoneSmsImageDownloadPacket a0, IPayloadContext a1) {}
}

@Mixin(value = OpenSupeDialoguePacket.class, remap = false)
abstract class StubOpenSupeDialogue {
    @Overwrite(remap = false)
    public static void handle(OpenSupeDialoguePacket a0, IPayloadContext a1) {}
}

@Mixin(value = NpcSupportSyncPacket.class, remap = false)
abstract class StubNpcSupportSync {
    @Overwrite(remap = false)
    public static void handle(NpcSupportSyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = PhoneEvidenceSyncPacket.class, remap = false)
abstract class StubPhoneEvidenceSync {
    @Overwrite(remap = false)
    public static void handle(PhoneEvidenceSyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = PhoneBatterySyncPacket.class, remap = false)
abstract class StubPhoneBatterySync {
    @Overwrite(remap = false)
    public static void handle(PhoneBatterySyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = PhoneEvidenceReportResultPacket.class, remap = false)
abstract class StubPhoneEvidenceReportResult {
    @Overwrite(remap = false)
    public static void handle(PhoneEvidenceReportResultPacket a0, IPayloadContext a1) {}
}

@Mixin(value = PhoneNewsSyncPacket.class, remap = false)
abstract class StubPhoneNewsSync {
    @Overwrite(remap = false)
    public static void handle(PhoneNewsSyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = PhoneShopSyncPacket.class, remap = false)
abstract class StubPhoneShopSync {
    @Overwrite(remap = false)
    public static void handle(PhoneShopSyncPacket a0, IPayloadContext a1) {}
}

@Mixin(value = DossierUnlockSyncPacket.class, remap = false)
abstract class StubDossierUnlockSync {
    @Overwrite(remap = false)
    public static void handle(DossierUnlockSyncPacket a0, IPayloadContext a1) {}
}