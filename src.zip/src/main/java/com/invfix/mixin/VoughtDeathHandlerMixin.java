package com.invfix.mixin;

import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Делает смерть в The Boys ванильной.
 *
 * Оригинальный VoughtDeathHandler на смерть игрока:
 *   - ставит табличку (death sign)
 *   - копирует и ОЧИЩАЕТ инвентарь
 *   - подавляет ванильное сообщение о смерти
 *   - на респавне/входе телепортирует в недоделанное измерение Vought
 *
 * Мы отменяем все три обработчика в HEAD → срабатывает обычная ванильная смерть.
 *
 * @Pseudo + require=0 + проверка в плагине (shouldApplyMixin) означают, что
 * без мода The Boys миксин просто не применяется и ничего не ломает.
 */
@Pseudo
@Mixin(targets = "net.benniao.theboysmod.server.VoughtDeathHandler", remap = false)
public class VoughtDeathHandlerMixin {

    @Inject(method = "onLivingDeath", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void invfix_vanillaDeath(LivingDeathEvent event, CallbackInfo ci) {
        ci.cancel();
    }

    @Inject(method = "onPlayerRespawn", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void invfix_noVoughtRespawn(PlayerEvent.PlayerRespawnEvent event, CallbackInfo ci) {
        ci.cancel();
    }

    @Inject(method = "onPlayerLoggedIn", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void invfix_noVoughtLogin(PlayerEvent.PlayerLoggedInEvent event, CallbackInfo ci) {
        ci.cancel();
    }
}