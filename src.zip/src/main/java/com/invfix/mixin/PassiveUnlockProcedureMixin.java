package com.invfix.mixin;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.humanlike.HumanLikeRaces;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.procedures.PassiveUnlockProcedure;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Выдаёт расе Altrumite те же пассивки, что и Вильтрумитам — в т.ч. Flight.
 *
 * Оригинальный PassiveUnlockProcedure не знает про Altrumite, поэтому полёт
 * (racePassive == "Flight") никогда не выдавался и FlightOnOffProcedure не включал mayfly.
 *
 * Зеркалим Viltrumite:
 *   racePassive1 = "Decelerated Aging" (Lvl >= 0)
 *   racePassive2 = "Flight"            (Lvl >= 10)
 *   racePassive3 = "Reactive Adaptation" (Lvl >= 25)
 *   racePassive4 = "None"
 */
@Mixin(value = PassiveUnlockProcedure.class, remap = false)
public class PassiveUnlockProcedureMixin {

    @Inject(method = "execute", at = @At("TAIL"), remap = false)
    private static void invfix_altrumitePassives(Entity entity, CallbackInfo ci) {
        if (entity == null) return;
        try {
            InvincibleIncModVariables.PlayerVariables v =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);

            // Расы-затычки получают тот же набор пассивок, что и §f§lHuman:
            // racePassive1 = "Adrenalized", остальные "None".
            if (HumanLikeRaces.isHumanLike(v.Race)) {
                boolean d = false;
                if (!"Adrenalized".equals(v.racePassive1)) { v.racePassive1 = "Adrenalized"; d = true; }
                if (!"None".equals(v.racePassive2))        { v.racePassive2 = "None";        d = true; }
                if (!"None".equals(v.racePassive3))        { v.racePassive3 = "None";        d = true; }
                if (!"None".equals(v.racePassive4))        { v.racePassive4 = "None";        d = true; }
                if (d) v.markSyncDirty();
                return;
            }

            if (!AltrumiteRace.isAltrumite(v.Race)) return;

            boolean dirty = false;
            if (!"Decelerated Aging".equals(v.racePassive1) && v.Lvl >= 0.0) {
                v.racePassive1 = "Decelerated Aging"; dirty = true;
            }
            if (!"Flight".equals(v.racePassive2) && v.Lvl >= 10.0) {
                v.racePassive2 = "Flight"; dirty = true;
            }
            if (!"Reactive Adaptation".equals(v.racePassive3) && v.Lvl >= 25.0) {
                v.racePassive3 = "Reactive Adaptation"; dirty = true;
            }
            if (!"None".equals(v.racePassive4)) {
                v.racePassive4 = "None"; dirty = true;
            }
            if (dirty) v.markSyncDirty();
        } catch (Exception ignored) {}
    }
}