package com.invfix.mixin.timestop;

import com.invfix.timestop.TimeStopManager;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.redstone.CollectingNeighborUpdater;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Копит соседские блок-апдейты, возникшие внутри остановленного времени, и
 * отдаёт их обратно, когда зона сходит (TimeStopManager#releaseDelayedBlockUpdates).
 *
 * Без этого владелец зоны, сломав блок, запустил бы редстоун-каскад прямо в
 * замершем мире: neighborChanged выполняется синхронно и тиками блоков не
 * ограничен. В Create-сборке это заметно сразу — обсёрверы, воронки, двери.
 *
 * count == 0 означает «апдейт пришёл снаружи, а не из уже идущего каскада»:
 * откладывать вложенные апдейты нельзя, иначе разъедется порядок. Условие и
 * исключение для ShapeUpdate перенесены из ROTP 1.21.1
 * (mixin.stand.theworld.timestop.DelayBlockUpdateMixin).
 *
 * ТРЕБУЕТ access transformer — см. META-INF/accesstransformer.cfg.
 */
@Mixin(CollectingNeighborUpdater.class)
public class TsNeighborUpdaterMixin {

    @Shadow @Final private Level level;
    @Shadow int count;

    @Inject(method = "addAndRun", at = @At("HEAD"), cancellable = true)
    private void invfix$timeStopDelayUpdate(BlockPos pos, CollectingNeighborUpdater.NeighborUpdates updates,
                                            CallbackInfo ci) {
        if (count != 0) return;
        if (TimeStopManager.delayBlockUpdate(level, pos, updates)) {
            ci.cancel();
        }
    }
}
