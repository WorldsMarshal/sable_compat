package com.invfix.mixin.timestop;

import com.invfix.timestop.TimeStopApi;
import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Остановка тиков блоков внутри зоны на сервере.
 *
 * priority = 1500 — не украшение. Sable инжектит в тот же shouldTickBlocksAt
 * (dev.ryanhcode.sable.mixin.plot.ServerLevelMixin#sable$shouldTickBlocksAt)
 * с cir.setReturnValue(true) для чанков делянок, и его конфиг идёт с приоритетом
 * по умолчанию (1000). У Mixin миксин с бо́льшим приоритетом применяется позже, а
 * при @At("HEAD") позже применённый коллбек встаёт в начало метода — то есть
 * выполняется первым. Без повышенного приоритета Sable успел бы вернуть true, и
 * кинетика на судах продолжила бы крутиться внутри остановленного времени.
 */
@Mixin(value = ServerLevel.class, priority = 1500)
public abstract class TsServerLevelMixin {

    @Inject(method = "shouldTickBlocksAt", at = @At("HEAD"), cancellable = true)
    private void invfix$timeStopBlockTicks(long chunkPos, CallbackInfoReturnable<Boolean> cir) {
        ServerLevel self = (ServerLevel) (Object) this;
        if (TimeStopApi.isTimeStoppedAtChunk(self, chunkPos)) {
            cir.setReturnValue(false);
        }
    }

    /*
     * Время уровня здесь НЕ останавливается, хотя в ROTP останавливается
     * отменой tickTime.
     *
     * tickTime двигает сразу и dayTime, и gameTime, и оба значения общие на
     * измерение. Заморозив их, мы бы остановили солнце и часы всем игрокам
     * дименсии, включая тех, кто за сотню чанков и про остановку знать не
     * должен. А на gameTime висит чужая периодика: Create FluidNetwork гоняет
     * сеть под getGameTime() %40, Crowns считает турбины под %40 и реакторные
     * сборки под %5, машины самого проекта — под %20. На застывших часах всё
     * это либо встаёт, либо начинает считаться каждый тик.
     *
     * Поэтому солнце останавливается чисто визуально и только у наблюдателя
     * внутри зоны — TsSkyTimeMixin на Level#getTimeOfDay. Мир за радиусом
     * продолжает жить как ни в чём не бывало.
     */
}
