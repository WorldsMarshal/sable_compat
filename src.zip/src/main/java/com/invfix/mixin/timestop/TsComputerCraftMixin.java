package com.invfix.mixin.timestop;

import com.invfix.timestop.TimeStopApi;
import com.invfix.timestop.TimeStopConfig;
import dan200.computercraft.shared.computer.core.ServerComputer;
import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ComputerCraft крутит Lua на собственном пуле потоков и к тику мира не привязан
 * вовсе: ServerContext#tick зовёт ServerComputerRegistry#update, а тот —
 * ServerComputer#tickServer на каждый компьютер сервера, безотносительно
 * измерения и загруженности чанка. Значит остановка времени его не касается
 * ни через тики блоков, ни через тики сущностей — только явной отменой.
 *
 * Отмена tickServer останавливает подкачку событий и таймеров в ВМ компьютера:
 * уже запущенный Lua-кусок доработает до своего yield, но новых тиков, событий
 * и обновлений терминала не получит. Заодно перестаёт расти ticksSincePing
 * (первая строка tickServer), поэтому компьютер не отвалится по таймауту за
 * время остановки.
 *
 * Позиция компьютера на судне лежит в координатах делянки Sable, поэтому
 * проверка идёт через isTimeStoppedAtBlock, а не по сырым координатам.
 */
@Mixin(value = ServerComputer.class, remap = false)
public class TsComputerCraftMixin {

    @Inject(method = "tickServer()V", at = @At("HEAD"), cancellable = true, remap = false)
    private void invfix$timeStopFreezeComputer(CallbackInfo ci) {
        if (!TimeStopConfig.freezeComputers) return;
        ServerComputer self = (ServerComputer) (Object) this;
        ServerLevel level = self.getLevel();
        if (level == null) return;
        if (TimeStopApi.isTimeStoppedAtBlock(level, self.getPosition())) {
            ci.cancel();
        }
    }
}
