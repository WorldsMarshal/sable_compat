package com.invfix.mixin.timestop;

import com.invfix.timestop.TimeStopApi;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Две дыры, которые не закрываются отменой тика.
 *
 * isEffectiveAi — мобы с реактивным ИИ (слизни, вспышка криперов) отвечают на
 * касание вне собственного тика. Правим именно её, а не Mob#isNoAi(): флаг
 * noAi сохраняется в NBT и остался бы у моба навсегда.
 *
 * updateFluidHeightAndDoFluidPushing — поток жидкости толкает сущность из тика
 * самой жидкости, а не сущности. Обе инъекции перенесены из ROTP 1.21.1
 * (mixin.stand.theworld.timestop.EntityMixin).
 */
@Mixin(Entity.class)
public abstract class TsEntityMixin {

    @Inject(method = "isEffectiveAi", at = @At("HEAD"), cancellable = true)
    private void invfix$timeStopNoAi(CallbackInfoReturnable<Boolean> cir) {
        if (TimeStopApi.isFrozen((Entity) (Object) this)) {
            cir.setReturnValue(false);
        }
    }

    // require/expect = 0: точка STORE внутри метода — самая хрупкая инъекция всей
    // ветки, а конфиг мода стоит с injectors.defaultRequire = 1, то есть промах
    // уронил бы запуск. Потеря при промахе — течение толкает замороженные
    // сущности, косметика; ронять из-за неё сборку незачем.
    @ModifyVariable(method = "updateFluidHeightAndDoFluidPushing()V",
            at = @At(value = "STORE", ordinal = 0), ordinal = 1,
            require = 0, expect = 0)
    private Vec3 invfix$timeStopNoFluidPush(Vec3 flowVec) {
        if (TimeStopApi.isInsideTimeStop((Entity) (Object) this)) {
            return Vec3.ZERO;
        }
        return flowVec;
    }
}
