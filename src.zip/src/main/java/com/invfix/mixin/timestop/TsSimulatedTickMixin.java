package com.invfix.mixin.timestop;

import com.invfix.timestop.TimeStopApi;
import com.invfix.timestop.TimeStopConfig;
import dev.simulated_team.simulated.events.SimulatedCommonEvents;
import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Simulated тикает редстоун-магниты, стыковочные замки и карту лодстоунов из
 * ServerTickEvent.Post (SimulatedCommonEvents#onServerTickEnd). Как и у
 * Aeronautics, это не тики блоков, поэтому глушится отдельно.
 */
@Mixin(value = SimulatedCommonEvents.class, remap = false)
public class TsSimulatedTickMixin {

    @Inject(method = "onServerTickEnd", at = @At("HEAD"), cancellable = true, remap = false)
    private static void invfix$timeStopFreezeSimulated(ServerLevel level, CallbackInfo ci) {
        if (!TimeStopConfig.freezeAirshipGlobalTicks) return;
        if (TimeStopApi.hasAnyTimeStop(level)) ci.cancel();
    }
}
