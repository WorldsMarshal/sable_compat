package com.invfix.mixin.timestop.client;

import com.invfix.timestop.TimeStopClientState;
import net.minecraft.client.renderer.texture.TextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Останавливает анимированные текстуры: вода, лава, огонь, порталы, дисплеи Create. */
@Mixin(TextureManager.class)
public class TsTextureManagerMixin {

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void invfix$timeStopFreezeTextures(CallbackInfo ci) {
        if (TimeStopClientState.localInsideTimeStop) {
            ci.cancel();
        }
    }
}
