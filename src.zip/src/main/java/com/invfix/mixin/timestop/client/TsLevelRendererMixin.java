package com.invfix.mixin.timestop.client;

import com.invfix.timestop.TimeStopClientState;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Клиентская часть «мир замер».
 *
 * tick — счётчик LevelRenderer'а крутит собственные эффекты кадра; его отмена
 * нужна, чтобы они не шли в остановленном времени.
 *
 * renderEntity — замороженной сущности подсовываем фиксированный partialTick.
 * Позиция и так не едет (ClientLevel#tickNonPassenger зовёт setOldPosAndRot до
 * события отмены, поэтому old == current), но анимации моделей считаются от
 * tickCount + partialTick, и без фиксации замороженные мобы мелко дрожат.
 * Сигнатура захвата перенесена из ROTP 1.21.1
 * (mixin.stand.theworld.timestop.client.LevelRendererPartialTickMixin).
 */
@Mixin(LevelRenderer.class)
public class TsLevelRendererMixin {

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void invfix$timeStopFreezeRendererTick(CallbackInfo ci) {
        if (TimeStopClientState.localInsideTimeStop) {
            ci.cancel();
        }
    }

    // require/expect = 0 по той же причине, что и у TsEntityMixin: промах стоит
    // лёгкого дрожания моделей, а не запуска игры.
    @ModifyVariable(method = "renderEntity", at = @At("HEAD"), argsOnly = true, ordinal = 0,
            require = 0, expect = 0)
    private float invfix$timeStopFreezeEntityPartialTick(float partialTick,
            Entity entity, double camX, double camY, double camZ,
            float partialTickArg, PoseStack poseStack, MultiBufferSource bufferSource) {
        if (TimeStopClientState.isFrozen(entity)) {
            return TimeStopClientState.frozenPartialTick;
        }
        return partialTick;
    }
}
