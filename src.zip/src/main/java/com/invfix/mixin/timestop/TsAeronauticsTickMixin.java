package com.invfix.mixin.timestop;

import com.invfix.timestop.TimeStopApi;
import com.invfix.timestop.TimeStopConfig;
import dev.eriksonn.aeronautics.events.AeronauticsCommonEvents;
import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Aeronautics держит подъёмную силу и кристаллизацию левитита в глобальных
 * картах уровня (LevititeCrystallizerManager#tick, BalloonMap#tick), которые
 * гоняются из ServerTickEvent.Post, а не из тиков блоков. Без отмены аэростаты
 * продолжали бы набирать/терять подъём внутри остановленного времени.
 *
 * Гранулярность — весь ServerLevel, как и у паузы физики Sable: карты
 * общие на измерение и по радиусу не режутся.
 */
@Mixin(value = AeronauticsCommonEvents.class, remap = false)
public class TsAeronauticsTickMixin {

    @Inject(method = "onServerTickEnd", at = @At("HEAD"), cancellable = true, remap = false)
    private static void invfix$timeStopFreezeAero(ServerLevel level, CallbackInfo ci) {
        if (!TimeStopConfig.freezeAirshipGlobalTicks) return;
        if (TimeStopApi.hasAnyTimeStop(level)) ci.cancel();
    }
}
