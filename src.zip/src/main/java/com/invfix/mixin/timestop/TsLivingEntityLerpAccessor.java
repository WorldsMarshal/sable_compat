package com.invfix.mixin.timestop;

import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Доступ к LivingEntity#lerpSteps — для порта TrNoMotionLerpPacket из ROTP,
 * который делает ровно это через CommonReflection.get/setLerpSteps.
 *
 * Поле в 1.21.1 — {@code protected int lerpSteps}: так его объявляет и
 * Sable (@Shadow в entities_stick_sublevels.LivingEntityMixin).
 */
@Mixin(LivingEntity.class)
public interface TsLivingEntityLerpAccessor {

    @Accessor("lerpSteps")
    int invfix$getLerpSteps();

    @Accessor("lerpSteps")
    void invfix$setLerpSteps(int steps);
}
