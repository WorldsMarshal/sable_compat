package com.invfix.mixin.timestop.client;

import com.invfix.timestop.TimeStopClientState;
import net.minecraft.client.particle.ParticleEngine;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Частицы тикаются своим движком и к тикам сущностей не привязаны — без отмены
 * дым, огонь и пар продолжали бы жить в остановленном мире.
 *
 * Отличие от ROTP: там очередь particlesToAdd вручную сливают в активные, чтобы
 * частицы от действий владельца зоны были видны сразу. Здесь очередь просто не
 * трогаем — новые частицы подождут в particlesToAdd до снятия остановки. Это
 * ближе к смыслу «мир стоит» и не требует ни @Shadow на приватные поля движка,
 * ни белого списка классов частиц.
 */
@Mixin(ParticleEngine.class)
public class TsParticleEngineMixin {

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void invfix$timeStopFreezeParticles(CallbackInfo ci) {
        if (TimeStopClientState.localInsideTimeStop) {
            ci.cancel();
        }
    }
}
