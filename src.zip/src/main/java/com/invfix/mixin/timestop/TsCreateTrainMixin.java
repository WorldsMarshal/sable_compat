package com.invfix.mixin.timestop;

import com.invfix.timestop.TimeStopApi;
import com.invfix.timestop.TimeStopConfig;
import com.simibubi.create.content.trains.entity.Carriage;
import com.simibubi.create.content.trains.entity.CarriageBogey;
import com.simibubi.create.content.trains.entity.Train;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Поезда Create — не сущности и не блок-сущности: GlobalRailwayManager#tickTrains
 * гоняет их из общего списка по LevelTickEvent.Post (CommonEvents#onServerWorldTick
 * → Create.RAILWAYS.tick(world)). Поэтому ни отмена тика сущностей, ни
 * shouldTickBlocksAt их не трогают — состав проехал бы сквозь остановленное время.
 *
 * Позицию берём у ведущей тележки первого вагона; если её нет (состав ещё
 * собирается), поезд не морозим.
 */
@Mixin(value = Train.class, remap = false)
public class TsCreateTrainMixin {

    @Inject(method = "tick(Lnet/minecraft/world/level/Level;)V", at = @At("HEAD"), cancellable = true, remap = false)
    private void invfix$timeStopTrainTick(Level level, CallbackInfo ci) {
        if (invfix$frozen(level)) ci.cancel();
    }

    @Inject(method = "earlyTick(Lnet/minecraft/world/level/Level;)V", at = @At("HEAD"), cancellable = true, remap = false)
    private void invfix$timeStopTrainEarlyTick(Level level, CallbackInfo ci) {
        if (invfix$frozen(level)) ci.cancel();
    }

    private boolean invfix$frozen(Level level) {
        if (!TimeStopConfig.freezeTrains) return false;
        if (!TimeStopApi.hasAnyTimeStop(level)) return false;
        Train self = (Train) (Object) this;
        List<Carriage> carriages = self.carriages;
        if (carriages == null || carriages.isEmpty()) return false;
        Carriage first = carriages.get(0);
        if (first == null) return false;
        CarriageBogey bogey = first.leadingBogey();
        if (bogey == null) return false;
        Vec3 anchor = bogey.getAnchorPosition();
        if (anchor == null) return false;
        return TimeStopApi.isTimeStoppedAt(level, anchor.x, anchor.z);
    }
}
