package com.invfix.mixin.timestop;

import com.invfix.timestop.TimeStopApi;
import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ServerPlayer#doTick зовётся из ServerGamePacketListenerImpl#tick, отдельно от
 * тика сущностей, поэтому отмены EntityTickEvent.Pre для замороженного игрока
 * мало: без этого у него продолжали бы идти голод, регенерация и таймеры
 * нахождения в портале.
 */
@Mixin(ServerPlayer.class)
public abstract class TsServerPlayerMixin {

    @Inject(method = "doTick", at = @At("HEAD"), cancellable = true)
    private void invfix$timeStopFreezePlayer(CallbackInfo ci) {
        ServerPlayer self = (ServerPlayer) (Object) this;
        if (TimeStopApi.isFrozen(self)) {
            ci.cancel();
        }
    }
}
