package com.invfix.mixin.timestop;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.timestop.TimeStopConfig;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.procedures.TimeStop0Procedure;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Отключает РОДНУЮ «остановку времени» invincible_inc для расы Alien(Metroman).
 *
 * В моде уже есть способность с точно такой же строкой слота — «§b§lTime Stop»,
 * это ветка спидстера (TimeStop0Procedure, LVL 25, только в боевом режиме,
 * кулдаун через эффекты CD_1..CD_10). Её механика — не остановка, а замедление:
 * TimeStopTickProcedure раз в тик собирает всех в радиусе 20 блоков, вешает
 * STUNNED и умножает их скорость на 0.1, плюс играет invincible_inc:time_vibrations.
 *
 * Отсюда и вся картина, которую было видно в игре: в боевом режиме срабатывала
 * родная версия — существа замедлялись и был звук; вне боевого режима она
 * отказывалась работать («Battle Mode Needs To Be On»), и тогда изредка
 * проходила наша — всё замирало по-настоящему и молча.
 *
 * Строку способности мы намеренно оставляем ту же: для Metroman наша реализация
 * заменяет родную целиком, а спидстерам их замедление остаётся нетронутым.
 */
@Mixin(value = TimeStop0Procedure.class, remap = false)
public class TsNativeTimeStopMixin {

    @Inject(method = "execute", at = @At("HEAD"), cancellable = true, remap = false)
    private static void invfix$replaceForMetroman(
            LevelAccessor world, double x, double y, double z, Entity entity, CallbackInfo ci) {
        if (!TimeStopConfig.replaceNativeTimeStopForMetroman) return;
        if (entity == null) return;
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (AltrumiteRace.isAltrumite(vars.Race)) {
                // Наш обработчик висит на AbilityCallProcedure и уже отработал
                // это нажатие; родную ветку просто глушим — заодно уходят
                // требование боевого режима, порог LVL 25, кулдаун и спам
                // «Battle Mode Needs To Be On».
                ci.cancel();
            }
        } catch (Throwable ignored) {}
    }
}
