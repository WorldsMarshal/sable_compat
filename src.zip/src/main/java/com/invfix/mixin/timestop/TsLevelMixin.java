package com.invfix.mixin.timestop;

import com.invfix.timestop.TimeStopApi;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Клиентская половина заморозки тиков блоков.
 *
 * ServerLevel переопределяет shouldTickBlocksAt, поэтому TsServerLevelMixin
 * серверную сторону закрывает, а этот миксин достаётся ClientLevel. Без него
 * на клиенте продолжали бы тикать блок-сущности: валы и шестерни Create,
 * дисплеи, анимации — мир на сервере стоит, а на экране крутится.
 */
@Mixin(Level.class)
public abstract class TsLevelMixin {

    @Inject(method = "shouldTickBlocksAt", at = @At("HEAD"), cancellable = true)
    private void invfix$timeStopClientBlockTicks(long chunkPos, CallbackInfoReturnable<Boolean> cir) {
        Level self = (Level) (Object) this;
        if (!self.isClientSide()) return;
        if (TimeStopApi.isTimeStoppedAtChunk(self, chunkPos)) {
            cir.setReturnValue(false);
        }
    }
}
