package com.invfix.mixin;

import net.minecraft.world.entity.animal.Fox;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;

/**
 * Пасхалка для разработчика (HoustonWTF): все лисы безусловно доверяют ему.
 *
 * Ваниль решает «бояться ли игрока» через Fox#trusts(UUID) — недоверенных
 * лиса избегает (FoxAvoidEntityGoal), от доверенных не убегает и защищает их.
 * Инжект в trusts с подменой ответа на true для UUID разработчика покрывает
 * сразу всё поведение доверия, без ковыряния в целях ИИ.
 *
 * Ник резолвится через игрока в мире по UUID — оффлайн/онлайн UUID не важны,
 * важен только текущий ник.
 */
@Mixin(Fox.class)
public abstract class FoxTrustDevMixin {

    @Inject(method = "trusts", at = @At("HEAD"), cancellable = true)
    private void invfix$kitsuneTrust(UUID uuid, CallbackInfoReturnable<Boolean> cir) {
        if (uuid == null) {
            return;
        }
        Fox self = (Fox) (Object) this;
        Player player = self.level().getPlayerByUUID(uuid);
        if (player != null
                && com.invfix.item.KitsuneFoxHandler.isDev(player)) {
            cir.setReturnValue(true);
        }
    }
}
