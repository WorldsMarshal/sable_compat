package com.invfix.mixin.create;

import com.invfix.util.CreateSoundDedup;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.RegisterEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Фикс краша загрузки CBC Military Supplement (cbcmoreshells) 2.1.0:
 * java.lang.IllegalStateException: Adding duplicate key
 *   'ResourceKey[minecraft:sound_event / cbcmoreshells:sonar_pulse]' to registry
 *   at CBCMSSoundEvents.register(...) → AllSoundEvents$CustomSoundEntry.register(...)
 *
 * Причина в аддоне: {@code CBCMSSoundEvents.CBCMSSoundEntryBuilder.build()}
 * вызывает {@code super.build()}, а билдер Create в конце {@code build()}
 * САМ кладёт готовую запись в свою глобальную карту {@code AllSoundEvents.ALL}.
 * Аддон после этого складывает ТОТ ЖЕ объект ещё и в собственную карту
 * {@code CBCMSSoundEvents.ALL}. В результате на RegisterEvent по
 * {@code Registries.SOUND_EVENT} проход по записям идёт дважды: сначала
 * листенером Create ({@code AllSoundEvents.register}), затем листенером аддона
 * ({@code CbcmoreshellsNeoForge.onRegisterSounds}) — и второй падает на первом
 * же дубликате. Конкретно sonar_pulse всплывает потому, что стоит первым
 * в порядке обхода HashMap, сам звук тут ни при чём.
 *
 * Фикс: гасим повторный вызов {@code SoundEntry.register} на стороне Create —
 * если основной id записи уже в реестре, проход пропускается. Точка выбрана
 * ниже обоих листенеров, поэтому порядок загрузки модов роли не играет:
 * кто отработал первым, тот и зарегистрировал, второй молча выходит.
 * Та же скрытая проблема закрывается для любого другого аддона, который строит
 * звуки через билдер Create (cbc_at, cbcmodernwarfare и т.п.).
 *
 * Потерь нет: и {@code CustomSoundEntry}, и {@code WrappedSoundEntry} отдают
 * звук через {@code DeferredHolder}, т.е. резолвят его из реестра, а не из
 * инстанса, переданного в {@code helper.register()}. Проигрывание, сабтитры
 * и сетевая синхронизация работают по единственной зарегистрированной копии.
 *
 * Применяется только при загруженном create
 * (гейт в {@link com.invfix.compat.InvincibleIncMixinTransformer}).
 */
public final class CreateSoundEntryDuplicateMixin {

    private CreateSoundEntryDuplicateMixin() {}

    /** Обычные звуки из файлов ресурсов (этим путём идут все записи CBCMS). */
    @Mixin(targets = "com.simibubi.create.AllSoundEvents$CustomSoundEntry", remap = false)
    public static class CustomEntry {

        @Inject(
                method = "register",
                at = @At("HEAD"),
                cancellable = true,
                remap = false
        )
        private void invfix$skipDuplicateCustomSound(RegisterEvent.RegisterHelper<SoundEvent> helper,
                                                     CallbackInfo ci) {
            if (CreateSoundDedup.isAlreadyRegistered(this)) {
                ci.cancel();
            }
        }
    }

    /** Записи-обёртки над уже существующими событиями ({@code playExisting}). */
    @Mixin(targets = "com.simibubi.create.AllSoundEvents$WrappedSoundEntry", remap = false)
    public static class WrappedEntry {

        @Inject(
                method = "register",
                at = @At("HEAD"),
                cancellable = true,
                remap = false
        )
        private void invfix$skipDuplicateWrappedSound(RegisterEvent.RegisterHelper<SoundEvent> helper,
                                                      CallbackInfo ci) {
            if (CreateSoundDedup.isAlreadyRegistered(this)) {
                ci.cancel();
            }
        }
    }
}
