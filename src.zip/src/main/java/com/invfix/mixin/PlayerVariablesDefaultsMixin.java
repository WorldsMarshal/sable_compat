package com.invfix.mixin;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = InvincibleIncModVariables.PlayerVariables.class, remap = false)
public class PlayerVariablesDefaultsMixin {

    @Shadow
    public boolean showabilityGUI;

    @Inject(method = "<init>", at = @At("TAIL"), remap = false)
    private void invfix_defaultGuiOff(CallbackInfo ci) {
        this.showabilityGUI = false;
    }
}