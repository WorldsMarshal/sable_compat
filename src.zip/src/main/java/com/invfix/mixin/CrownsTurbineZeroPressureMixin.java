package com.invfix.mixin;

import com.mojang.logging.LogUtils;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Method;

/**
 * Предохранитель от деления на ноль в пересчёте ступеней турбины Crowns.
 *
 * Симптом: лог заливает "[formicapi/] early break in isentropic computation
 * cause by derivative too small" — сотни раз в секунду, с самого первого
 * тика мира, бесконечно. За 3 часа игровой сессии — 1.6 млн строк. Каждая
 * такая строка это ещё и впустую прогнанный (несходящийся) вызов решателя
 * FormicAPI на серверном потоке — прямой вклад в просадку TPS, отдельно от
 * стоимости самой записи в лог.
 *
 * Причина: SteamCurrent.recomputeStages(Level) пересчитывает всю цепочку
 * ступеней турбины КАЖДЫЙ тик безусловно, даже когда пар вообще не идёт.
 * Входное состояние берётся из StateFluidTank.getState(), а пустой (или ни
 * разу не нагретый) бак отдаёт SpecificRealGasState.DEFAULT_STATE — у него
 * давление 0. Дальше в recomputeStages:
 *
 *     float minPressure = CROWNSConfigs.SERVER.kinetics.turbineLowPressureBound.getF(); // 2000.0F по умолчанию
 *     ...
 *     pressureRatio = minPressure / previousState.pressure();  // 2000.0F / 0.0F
 *
 * В Java это не исключение, а ровно Float.POSITIVE_INFINITY, и эта
 * бесконечность без единой проверки летит в FullTableBased.isentropicCompression(
 * previousState, Infinity) — решатель сойтись не может в принципе, ловит
 * свой собственный bailout и логирует его. Показательно, что у компрессора
 * в этом же моде (CompressorBlockEntity) аналогичная защита уже стоит —
 * весь расчёт там обёрнут в "if (realFlow > 0)". У турбины эквивалента
 * этой проверки нет: это недосмотр в одном месте, а не общий принцип мода.
 *
 * Фикс: перед пересчётом проверяем именно то, что проверяет компрессор —
 * есть ли реальный поток и ненулевое давление на входе. Если нет —
 * пересчёт этого тика просто пропускается (recomputeStages отменяется
 * целиком), без деления и без решателя. Как только в трубу реально пойдёт
 * пар с ненулевым давлением, следующий же тик пересчитает всё как обычно —
 * ничего в физике мода не меняется, просто не считаем то, что считать не на
 * чем. Отображаемая мощность ступеней при этом на один-два тика подмерзает
 * на последнем реальном значении (которое к моменту опустошения бака и так
 * уже около нуля) — цена того, что мы не лезем внутрь метода перестраивать
 * его карты состояний вручную через рефлексию.
 *
 * Реализация через рефлексию, чтобы не требовать crowns/formicapi в compile
 * classpath; миксин применяется только при загруженном crowns
 * (см. {@link com.invfix.compat.InvincibleIncMixinTransformer}).
 */
@Mixin(targets = "com.rae.crowns.content.thermodynamics.turbine.SteamCurrent", remap = false)
public abstract class CrownsTurbineZeroPressureMixin {

    @Unique private static final Logger INVFIX_LOGGER = LogUtils.getLogger();

    @Unique private static Method invfix$getFlow;
    @Unique private static Method invfix$getInputFluidState;
    @Unique private static Method invfix$pressure;
    @Unique private static boolean invfix$reflectionBroken;

    @Unique private static long invfix$suppressedCount;
    @Unique private static long invfix$lastWarn;

    @Inject(method = "recomputeStages", at = @At("HEAD"), cancellable = true)
    private void invfix$skipWhenNoSteam(Level level, CallbackInfo ci) {
        if (invfix$reflectionBroken) {
            return;
        }
        try {
            invfix$initReflection();

            float flow = (Float) invfix$getFlow.invoke(this, level);
            if (flow > 0.0F) {
                Object state = invfix$getInputFluidState.invoke(this, level);
                float pressure = (Float) invfix$pressure.invoke(state);
                if (pressure > 0.0F) {
                    return; // штатно: есть поток и есть от чего считать давление
                }
            }

            // Пара нет (или бак только что опустел и ещё отдаёт DEFAULT_STATE
            // с нулевым давлением) — считать здесь нечего, и главное, нельзя:
            // именно это давление ниже стало бы делителем на ноль.
            ci.cancel();
            invfix$suppressedCount++;

            long now = System.currentTimeMillis();
            if (now - invfix$lastWarn > 300_000L) {
                invfix$lastWarn = now;
                INVFIX_LOGGER.info(
                        "[sable_compat] Пересчёт ступеней турбины Crowns пропущен {} раз(а) "
                                + "за последние 5 минут: пар не идёт (пустой/непрогретый входной бак, "
                                + "давление 0) — без этой проверки formicapi делил бы minPressure "
                                + "на 0 и спамил \"early break in isentropic computation\" каждый тик",
                        invfix$suppressedCount);
                invfix$suppressedCount = 0;
            }
        } catch (Throwable t) {
            // Несовместимая версия crowns — отключаемся насовсем, поведение
            // возвращается к ванильному поведению мода (со спамом в лог).
            invfix$reflectionBroken = true;
            INVFIX_LOGGER.warn(
                    "[sable_compat] Защита от пустого пара в турбине Crowns отключена "
                            + "(несовместимая версия crowns?): {}", t.toString());
        }
    }

    @Unique
    private static void invfix$initReflection() throws Exception {
        if (invfix$getFlow != null) {
            return;
        }
        Class<?> currentClass = Class.forName(
                "com.rae.crowns.content.thermodynamics.turbine.SteamCurrent");
        invfix$getFlow = currentClass.getMethod("getFlow", Level.class);
        invfix$getInputFluidState = currentClass.getMethod("getInputFluidState", Level.class);
        Class<?> stateClass = Class.forName(
                "com.rae.formicapi.content.thermal_utilities.SpecificRealGasState");
        invfix$pressure = stateClass.getMethod("pressure");
    }
}