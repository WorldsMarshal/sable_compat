package com.invfix.mixin;

import com.invfix.theboyscompat.SyringeRaceRule;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Инъекция ударом: вколоть Compound V / Temp V можно только цели с человеческой
 * ДНК. Если бьющий держит V-шприц, а цель — игрок нечеловеческой расы, инъекция
 * отменяется ещё до prick-эффекта: удар гасится (без урона), шприц не тратится,
 * бьющему показывается то же сообщение «… was created for human DNA.».
 *
 * Так Виталиум не может получить V «руками» друга — расовое ограничение
 * проверяется по ДНК ПОЛУЧАТЕЛЯ, как и при self-use.
 *
 * @Pseudo + require=0 + гейт в InvincibleIncMixinTransformer → без The Boys не применяется.
 */
@Pseudo
@Mixin(targets = "net.benniao.theboysmod.server.SyringeAttackInjectionHandler", remap = false)
public class SyringeAttackRaceGateMixin {

    @Inject(method = "onAttackEntity", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void invfix_gateAttackInject(AttackEntityEvent event, CallbackInfo ci) {
        if (!(event.getEntity() instanceof ServerPlayer injector)) return;

        Entity target = event.getTarget();
        if (!(target instanceof Player recipient)) return;
        if (injector == recipient) return;

        String msg = SyringeRaceRule.blockMessage(recipient, injector.getMainHandItem());
        if (msg != null) {
            injector.displayClientMessage(Component.literal(msg), true);
            event.setCanceled(true); // без урона от удара
            ci.cancel();             // без prick/inject/расхода шприца
        }
    }
}
