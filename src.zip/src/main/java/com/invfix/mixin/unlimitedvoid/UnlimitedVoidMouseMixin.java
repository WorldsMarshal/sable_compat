package com.invfix.mixin.unlimitedvoid;

import com.invfix.unlimitedvoid.client.UnlimitedVoidInput;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Unlimited Void: под эффектом мышь не поворачивает голову (накопленный сдвиг сбрасывается сам). */
@Mixin(MouseHandler.class)
public abstract class UnlimitedVoidMouseMixin {

    @Inject(method = "turnPlayer", at = @At("HEAD"), cancellable = true)
    private void invfix$unlimitedVoidTurn(double movementTime, CallbackInfo ci) {
        if (UnlimitedVoidInput.frozen()) ci.cancel();
    }
}
