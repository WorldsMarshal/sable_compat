package com.invfix.mixin.unlimitedvoid;

import com.invfix.unlimitedvoid.client.UnlimitedVoidInput;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Unlimited Void: под эффектом из игры (без открытого экрана) открывается только меню паузы
 * (Esc) и экраны самой игры (смерть, загрузка, отключение) — ни инвентарь, ни чат, ни меню модов
 * (их открывают и в обход привязок клавиш). Из меню паузы — всё как обычно.
 */
@Mixin(Minecraft.class)
public abstract class UnlimitedVoidScreenMixin {

    @Shadow
    public Screen screen;

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void invfix$unlimitedVoidScreen(Screen next, CallbackInfo ci) {
        if (screen == null && next != null && UnlimitedVoidInput.frozen() && !UnlimitedVoidInput.allowedScreen(next)) {
            ci.cancel();
        }
    }
}
