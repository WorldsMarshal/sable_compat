package com.invfix.mixin.unlimitedvoid;

import com.invfix.unlimitedvoid.client.UnlimitedVoidInput;
import net.minecraft.client.KeyMapping;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Unlimited Void: под эффектом все привязки клавиш (ходьба, прыжок, присед, бег, атака,
 * использование, инвентарь, чат, слоты, выброс, способности модов…) молчат — кроме F-клавиш
 * (UnlimitedVoidInput#allowed). Нажатия не копятся: после эффекта ничего не «выстрелит».
 */
@Mixin(KeyMapping.class)
public abstract class UnlimitedVoidKeyMappingMixin {

    @Shadow
    private int clickCount;

    @Inject(method = "isDown", at = @At("HEAD"), cancellable = true)
    private void invfix$unlimitedVoidIsDown(CallbackInfoReturnable<Boolean> cir) {
        if (UnlimitedVoidInput.blocks((KeyMapping) (Object) this)) cir.setReturnValue(false);
    }

    @Inject(method = "consumeClick", at = @At("HEAD"), cancellable = true)
    private void invfix$unlimitedVoidConsumeClick(CallbackInfoReturnable<Boolean> cir) {
        if (UnlimitedVoidInput.blocks((KeyMapping) (Object) this)) {
            clickCount = 0;
            cir.setReturnValue(false);
        }
    }
}
