package com.invfix.mixin.unlimitedvoid;

import com.invfix.unlimitedvoid.UnlimitedVoid;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Unlimited Void: под эффектом существо в LivingEntity#aiStep считается неподвижным — как
 * спящий игрок: шаг ИИ (serverAiStep — цели, навигация, мозг, управление движением, взглядом,
 * прыжком; у игрока — ввод) не идёт, ввод движения и прыжок обнуляются. Само движение
 * (travel) остаётся: гравитация, отбрасывание, течение — как обычно.
 *
 * Точка — сам вызов isImmobile в aiStep, а не метод: его переопределяют (игрок, лошади, лиса,
 * разоритель, моды) и не все через super.
 */
@Mixin(LivingEntity.class)
public abstract class UnlimitedVoidFreezeMixin {

    @ModifyExpressionValue(method = "aiStep",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;isImmobile()Z"))
    private boolean invfix$unlimitedVoidImmobile(boolean immobile) {
        return immobile || UnlimitedVoid.frozen((LivingEntity) (Object) this);
    }
}
