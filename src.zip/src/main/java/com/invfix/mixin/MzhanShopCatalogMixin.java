package com.invfix.mixin;

import net.benniao.theboysmod.phone.MzhanShopCatalog;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Добавляет в магазин телефона (категория «药剂» / "v") два товара:
 *  - Compound V (перманентный шприц) — 20000
 *  - Очиститель Compound V (remove-шприц) — 5000
 *
 * Требует compileOnly-зависимость на настоящий theboysmod jar (ради типа Offer).
 * Без мода — миксин не применяется (shouldApplyMixin в плагине).
 *
 * offersFor("v") → дописываем оба товара (отображение в GUI).
 * findOffer(id)  → возвращаем их по id (транзакция покупки).
 */
@Pseudo
@Mixin(targets = "net.benniao.theboysmod.phone.MzhanShopCatalog", remap = false)
public class MzhanShopCatalogMixin {

    @Unique private static MzhanShopCatalog.Offer invfix_compoundV;
    @Unique private static MzhanShopCatalog.Offer invfix_remover;

    @Unique
    private static void invfix_ensureOffers() {
        if (invfix_compoundV != null) return;
        Supplier<Item> vSyringe = () ->
                BuiltInRegistries.ITEM.get(ResourceLocation.fromNamespaceAndPath("theboysmod", "compound_v_syringe"));
        Supplier<Item> removeSyringe = () ->
                BuiltInRegistries.ITEM.get(ResourceLocation.fromNamespaceAndPath("theboysmod", "compound_v_remove_syringe"));

        invfix_compoundV = new MzhanShopCatalog.Offer(
                "invfix_compound_v", "v", "永久五号",
                "永久随机能力针剂。", 35000, 1, 0xFFCC2222, vSyringe);
        invfix_remover = new MzhanShopCatalog.Offer(
                "invfix_compound_v_remove", "v", "五号清除剂",
                "移除已获得的能力。", 5000, 1, 0xFF808080, removeSyringe);
    }

    @Inject(method = "offersFor", at = @At("RETURN"), cancellable = true, remap = false, require = 0)
    private static void invfix_addOffers(String category,
                                         CallbackInfoReturnable<List<MzhanShopCatalog.Offer>> cir) {
        if (!"v".equals(category)) return;
        invfix_ensureOffers();
        List<MzhanShopCatalog.Offer> list = new ArrayList<>(cir.getReturnValue());
        list.add(invfix_compoundV);
        list.add(invfix_remover);
        cir.setReturnValue(list);
    }

    @Inject(method = "findOffer", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private static void invfix_findOffer(String offerId,
                                         CallbackInfoReturnable<MzhanShopCatalog.Offer> cir) {
        if (offerId == null) return;
        invfix_ensureOffers();
        if ("invfix_compound_v".equals(offerId))        cir.setReturnValue(invfix_compoundV);
        else if ("invfix_compound_v_remove".equals(offerId)) cir.setReturnValue(invfix_remover);
    }
}