package com.invfix.mixin;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

/**
 * Коллизия сущности, брошенной на сверхскорости (Heavy Punch и др. — до
 * VELOCITY_CAP = 3100 блоков/тик, EntityVelocityCapMixin).
 *
 * ── ПРИЧИНА (LagSampler, latest.log) ─────────────────────────────────────────
 * Каждый долгий тик (2–5 с) после Heavy Punch — это Entity.move → collide
 * брошенного моба (Zombie, Creeper, Spider): Lithium-свип перебирает каждый
 * блок в коробке «хитбокс, растянутый на весь вектор движения». При 3100
 * блоков/тик по диагонали это сотни тысяч блоков загруженного мира за один
 * вызов (плюс проверка фазирования The Boys на каждый блок).
 *
 * ── ЧТО ДЕЛАЕМ ───────────────────────────────────────────────────────────────
 * Движение длиннее {@link #FAST} блоков за тик проверяется шагами по
 * {@link #STEP} блоков: на каждом шаге — родная коллизия с блоками и границей
 * мира (Entity.collideBoundingBox) для маленькой коробки. Упёрлась ось — по
 * ней движение кончается, остальные оси идут дальше, как в ванили. Шаги, где
 * нет ни одного загруженного чанка, проходятся без проверки — ваниль там тоже
 * ничего не находит (незагруженный чанк не даёт коллизий и не грузится).
 * Итог тот же путь, но цена — по длине пути, а не по объёму коробки.
 *
 * Обычные скорости (до {@link #FAST} блоков/тик) не трогаются.
 */
@Mixin(Entity.class)
public abstract class EntityFastCollideMixin {

    /** С этой скорости (блоков за тик) коллизия идёт шагами. */
    private static final double FAST = 64.0;
    /** Длина шага, блоков. */
    private static final double STEP = 8.0;
    private static final double EPS = 1.0E-7;

    @Inject(method = "collide(Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3;",
            at = @At("HEAD"), cancellable = true)
    private void invfix$fastCollide(Vec3 movement, CallbackInfoReturnable<Vec3> cir) {
        if (!(movement.lengthSqr() > FAST * FAST) || !Double.isFinite(movement.lengthSqr())) return;
        Entity self = (Entity) (Object) this;
        Level level = self.level();
        AABB box = self.getBoundingBox();

        double rx = movement.x, ry = movement.y, rz = movement.z;
        double ox = 0.0, oy = 0.0, oz = 0.0;
        int guard = (int) Math.ceil(movement.length() / STEP) + 8;
        while (guard-- > 0) {
            double left = Math.sqrt(rx * rx + ry * ry + rz * rz);
            if (left < EPS) break;
            double k = Math.min(1.0, STEP / left);
            Vec3 step = new Vec3(rx * k, ry * k, rz * k);
            Vec3 got;
            if (anyLoaded(level, box.expandTowards(step))) {
                got = Entity.collideBoundingBox(self, step, box, level, List.of());
            } else {
                got = step;
            }
            ox += got.x;
            oy += got.y;
            oz += got.z;
            box = box.move(got);
            // ось упёрлась — по ней дальше не двигаемся
            rx = Math.abs(got.x - step.x) > EPS ? 0.0 : rx - got.x;
            ry = Math.abs(got.y - step.y) > EPS ? 0.0 : ry - got.y;
            rz = Math.abs(got.z - step.z) > EPS ? 0.0 : rz - got.z;
        }
        cir.setReturnValue(new Vec3(ox, oy, oz));
    }

    /** Есть ли в коробке хоть один загруженный чанк (углы и центр по горизонтали). */
    private static boolean anyLoaded(Level level, AABB b) {
        // вне высоты мира isLoaded всегда false — берём высоту внутри мира
        int y = Math.max(level.getMinBuildHeight(), Math.min(level.getMaxBuildHeight() - 1,
                (int) Math.floor((b.minY + b.maxY) * 0.5)));
        return level.isLoaded(BlockPos.containing(b.minX, y, b.minZ))
                || level.isLoaded(BlockPos.containing(b.maxX, y, b.minZ))
                || level.isLoaded(BlockPos.containing(b.minX, y, b.maxZ))
                || level.isLoaded(BlockPos.containing(b.maxX, y, b.maxZ))
                || level.isLoaded(BlockPos.containing((b.minX + b.maxX) * 0.5, y, (b.minZ + b.maxZ) * 0.5));
    }
}
