package com.invfix.mysticportal;

import com.invfix.ip.core.portal.Portal;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import org.jetbrains.annotations.Nullable;
import java.util.UUID;

/**
 * Портал ядра IP для Mystic Portal: вид на парный портал и переход сквозь лицо.
 * Односторонний, как все порталы IP: лицо — сторона нормали (axisW × axisH).
 *
 * Проходит только то, что целиком помещается в квадрат рамки; что не
 * помещается — для ядра IP «не может пройти», и о портал оно бьётся как о
 * плоскость (столкновение у IP разрешается только тем, кто может пройти).
 */
public class MysticPortalEntity extends Portal {

    public static final EntityType<MysticPortalEntity> ENTITY_TYPE =
            Portal.createPortalEntityType(MysticPortalEntity::new);

    /** Сервер: чей это портал в {@link MysticPortalHandler}; на клиенте не нужен. */
    @Nullable UUID holeId;

    public MysticPortalEntity(EntityType<?> entityType, Level world) {
        super(entityType, world);
    }

    @Override
    public boolean canTeleportEntity(Entity entity) {
        return super.canTeleportEntity(entity) && fits(entity);
    }

    /** Проекция хитбокса сущности на оси квадрата не больше его стороны. */
    private boolean fits(Entity entity) {
        double bw = entity.getBbWidth();
        double bh = entity.getBbHeight();
        double side = Math.min(getWidth(), getHeight()) + 1.0E-3;
        return extent(getAxisW(), bw, bh) <= side && extent(getAxisH(), bw, bh) <= side;
    }

    private static double extent(Vec3 axis, double bw, double bh) {
        return Math.abs(axis.x) * bw + Math.abs(axis.y) * bh + Math.abs(axis.z) * bw;
    }

    @Override
    public void onEntityTeleportedOnServer(Entity entity) {
        super.onEntityTeleportedOnServer(entity);
        if (holeId != null) MysticPortalHandler.onPassed(holeId);
    }

    @Override
    public void tick() {
        super.tick();
        // портал, о котором обработчик не знает (мир перезагружен), исчезает
        if (!level().isClientSide() && !isRemoved() && (holeId == null || !MysticPortalHandler.isKnownPortal(this))) {
            discard();
        }
    }
}
