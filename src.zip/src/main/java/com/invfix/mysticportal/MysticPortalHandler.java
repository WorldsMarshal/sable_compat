package com.invfix.mysticportal;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.ip.core.portal.Portal;
import com.invfix.ip.core.portal.PortalManipulation;
import com.invfix.rick.portalgun.PortalMode;
import com.invfix.rick.portalgun.PortalPoint;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.TicketType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.portal.DimensionTransition;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Mystic Portal — Metroman (Alien(Metroman)), LVL {@link #LVL_REQUIRED}.
 *
 * Магический портал: рамка из жёлтых искр (квадрат 1–5 блоков или 1×2), сквозь лицо виден и
 * проходим парный портал, изнанка тёмная и твёрдая. Нажатие — открыть портал
 * туда, куда смотришь: блок ближе дальности из настроек — на его грани, иначе
 * в воздухе на этой дальности (плоскость — по углу взгляда). Shift + клавиша —
 * меню настроек на клиенте.
 *
 * Связывание порталов — режимы портальной пушки Рика (PortalManager#applyModeLinking):
 *  - Цикл: пара, третий портал вытесняет самый старый;
 *  - Замена: пара, третий заменяет второй;
 *  - Мульти-пары: каждый чётный связывается с предыдущим (больше 10 — сброс);
 *  - База: первый — корень, все последующие ведут в него, он — в последний (больше 10 — сброс);
 *  - Точка: пара «портал ↔ выбранная точка», плоскость выхода — из настроек;
 *  - Срез пространства: пара сквозь стену — вход на поверхности, выход на её обратной стороне.
 * Лимит проходов — у каждого портала свой счётчик, проход списывается со входа
 * и с выхода; на нуле портал закрывается.
 *
 * Пара в одном измерении — порталы ядра IP ({@link MysticPortalEntity}): вид и
 * переход. В разных — только переход (вид в другое измерение — позже), его
 * делает {@link #crossTeleport}.
 *
 * Порталы живут в памяти сервера: выход владельца, перезапуск — закрывают их.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class MysticPortalHandler {

    public static final String ABILITY = "§6§lMystic Portal";
    public static final int LVL_REQUIRED = 200;
    /** Раскрытие и схлопывание, тиков (как и анимация размера у IP по умолчанию). */
    public static final int ANIM_TICKS = 10;
    /** Больше порталов в режимах «Мульти-пары» / «База» — сброс (как у пушки). */
    static final int MAX_HOLES = 10;
    /** Портал на грани блока чуть отодвинут от неё. */
    private static final double FACE_OFFSET = 0.01;
    private static final int TICKET_REFRESH = 100;
    private static final int CROSS_COOLDOWN = 20;
    /** Портал без IP-сущности (между измерениями): срабатывает, если хитбокс ближе этого к лицу. */
    private static final double CROSS_REACH = 0.3;

    static final class Hole {
        final UUID id = UUID.randomUUID();
        final UUID owner;
        final ServerLevel level;
        final Vec3 center;
        final Direction normal;
        final Direction up;
        /** Ширина (вдоль axisW) и высота (вдоль up) рамки, блоков. */
        final int width, height;
        int passesLeft;
        Hole partner;
        MysticPortalFrame frame;
        MysticPortalEntity portal;
        /** Через сколько тиков развернуть только что созданный крошечный портал IP; 0 — не нужно. */
        int growIn;
        int respawns;
        int age;
        /** Тиков до исчезновения после закрытия; -1 — открыт. */
        int closing = -1;

        Hole(UUID owner, ServerLevel level, Vec3 center, Direction normal, Direction up, int width, int height, int passes) {
            this.owner = owner;
            this.level = level;
            this.center = center;
            this.normal = normal;
            this.up = up;
            this.width = width;
            this.height = height;
            this.passesLeft = passes;
        }

        int maxSide() {
            return Math.max(width, height);
        }

        boolean open() {
            return closing < 0;
        }
    }

    private record Placement(Vec3 center, Direction normal, Direction up) {}

    private static final Map<UUID, List<Hole>> BY_OWNER = new HashMap<>();
    private static final Map<UUID, Hole> BY_ID = new HashMap<>();
    private static final Set<Entity> KNOWN = Collections.newSetFromMap(new IdentityHashMap<>());
    private static final Map<UUID, Long> HELD = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> CROSS_COOLDOWNS = new HashMap<>();

    private MysticPortalHandler() {}

    public static boolean eligible(ServerPlayer player) {
        try {
            InvincibleIncModVariables.PlayerVariables v = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            return AltrumiteRace.isAltrumite(v.Race) && v.Lvl >= LVL_REQUIRED;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean isKnownFrame(MysticPortalFrame frame) {
        return KNOWN.contains(frame);
    }

    static boolean isKnownPortal(MysticPortalEntity portal) {
        return KNOWN.contains(portal);
    }

    // ── нажатие (AbilityCallProcedureMixin, каждый тик, пока клавиша зажата) ──

    public static void onKeyHeld(ServerPlayer player) {
        long now = player.level().getGameTime();
        Long last = HELD.put(player.getUUID(), now);
        if (last != null && now - last <= 1) return; // то же нажатие
        if (player.isShiftKeyDown()) return;         // Shift — меню на клиенте
        if (!eligible(player)) return;
        try {
            open(player);
        } catch (Exception ignored) {}
    }

    private static void open(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        MysticPortalSettings s = MysticPortalSettings.of(player);
        Direction facing = facing(player);
        int w = s.width(), hgt = s.height();
        int passes = s.passLimit() == 0 ? -1 : s.passLimit();
        UUID owner = player.getUUID();
        if (s.slice()) {
            openSlice(player, level, facing, w, hgt, s.range(), passes);
            return;
        }
        Placement at = place(level, player, facing, w, hgt, s.range(), s.entry());
        PortalMode mode = s.portalMode();

        if (mode == PortalMode.POINT) {
            PortalPoint point = s.point();
            if (!point.isSet()) {
                fail(player, "Точка не задана");
                return;
            }
            ServerLevel target = level.getServer().getLevel(point.dimensionKey());
            if (target == null) {
                fail(player, "Нет такого измерения");
                return;
            }
            target.getChunk(point.pos());
            Placement exit = pointPlacement(point.pos(), at, facing, w, hgt, s.plane());
            if (target == level && exit.center().distanceTo(at.center()) < Math.max(w, hgt) + 1.0) {
                fail(player, "Точка слишком близко");
                return;
            }
            // одна пара: всё прежнее закрывается
            closeAll(owner);
            Hole a = create(owner, level, at, w, hgt, passes);
            Hole b = create(owner, target, exit, w, hgt, passes);
            if (a != null && b != null) link(a, b);
            return;
        }

        closeOverlapping(owner, level, at, Math.max(w, hgt));
        Hole hole = create(owner, level, at, w, hgt, passes);
        if (hole == null) return;
        List<Hole> active = active(owner);
        switch (mode) {
            case FIFO -> {
                if (active.size() > 2) {
                    close(active.get(0), true);
                    active = active(owner);
                }
                if (active.size() == 2) link(active.get(0), active.get(1));
            }
            case LIFO -> {
                if (active.size() > 2) {
                    close(active.get(1), true);
                    active = active(owner);
                }
                if (active.size() == 2) link(active.get(0), active.get(1));
            }
            case MULTI_PAIR -> {
                if (active.size() > MAX_HOLES) {
                    for (Hole h : active) if (h != hole) close(h, true);
                } else if (active.size() % 2 == 0) {
                    link(active.get(active.size() - 2), active.get(active.size() - 1));
                }
            }
            case ROOT -> {
                if (active.size() > MAX_HOLES) {
                    for (Hole h : active) if (h != hole) close(h, true);
                } else if (active.size() > 1) {
                    // корень — первый; прежние лучи ведут в него и дальше, сам он — в последний
                    link(active.get(0), hole);
                }
            }
            default -> {}
        }
    }

    private static void fail(ServerPlayer player, String text) {
        player.displayClientMessage(Component.literal(text).withStyle(ChatFormatting.RED), true);
    }

    /** Горизонтальное направление взгляда (по рысканию — работает и при взгляде отвесно). */
    private static Direction facing(ServerPlayer player) {
        double yaw = Math.toRadians(player.getYRot());
        return Direction.getNearest(-Math.sin(yaw), 0.0, Math.cos(yaw));
    }

    // ── где встаёт портал ───────────────────────────────────────────────────

    /** Нормаль входа из настройки; null — авто (грань блока или угол взгляда). */
    private static Direction entryNormal(int entry, Direction facing) {
        return switch (entry) {
            case MysticPortalSettings.ENTRY_UP -> Direction.UP;
            case MysticPortalSettings.ENTRY_DOWN -> Direction.DOWN;
            case MysticPortalSettings.ENTRY_TOWARD -> facing.getOpposite();
            case MysticPortalSettings.ENTRY_AWAY -> facing;
            default -> null;
        };
    }

    /**
     * Вход с заданной плоскостью. Место — то же (грань блока в пределах дальности или точка в
     * воздухе), меняется только нормаль:
     *  - на той же оси, что грань, но наоборот (лицом в блок) — портал чуть отодвинут от грани;
     *  - поперёк грани — портал стоит на грани краем (отодвинут на половину своей стороны).
     */
    private static Placement place(ServerLevel level, ServerPlayer player, Direction facing, int width, int height,
                                   int range, int entry) {
        Placement auto = place(level, player, facing, width, height, range);
        Direction forced = entryNormal(entry, facing);
        if (forced == null || forced == auto.normal()) return auto;
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getLookAngle().normalize().scale(range));
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        boolean onFace = hit.getType() == HitResult.Type.BLOCK;
        Vec3 c = onFace ? hit.getLocation() : end;
        Direction up = forced.getAxis().isVertical() ? facing : Direction.UP;
        if (onFace) {
            Direction face = hit.getDirection();
            Vec3 out = MysticPortalFrame.vec(face);
            if (face.getAxis() == forced.getAxis()) {
                c = c.add(out.scale(0.02));
            } else {
                double ext = (face.getAxis() == up.getAxis() ? height : width) * 0.5;
                c = c.add(out.scale(ext + FACE_OFFSET));
            }
        }
        return snapPlacement(level, c, forced, up, width, height, false);
    }

    private static Placement place(ServerLevel level, ServerPlayer player, Direction facing, int width, int height, int range) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle().normalize();
        Vec3 end = eye.add(look.scale(range));
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));

        Direction normal;
        Vec3 c;
        boolean onFace = hit.getType() == HitResult.Type.BLOCK;
        if (onFace) {
            normal = hit.getDirection();
            c = hit.getLocation();
        } else {
            float pitch = player.getXRot();
            normal = pitch > 45.0F ? Direction.UP : pitch < -45.0F ? Direction.DOWN : facing.getOpposite();
            c = end;
        }
        Direction up = normal.getAxis().isVertical() ? facing : Direction.UP;
        return snapPlacement(level, c, normal, up, width, height, onFace);
    }

    // ── «Срез пространства» ─────────────────────────────────────────────────

    /**
     * Пара сквозь стену. Вход — на поверхности, куда смотришь, в пределах дальности
     * (нет блока на луче — портала нет). Выход — на обратной стороне той же стены:
     * от входа вглубь, поперёк поверхности, ищется первый слой, где рамка целиком в
     * пустоте (не глубже MysticPortalSettings#SLICE_DEPTH блоков). Выход смотрит
     * наружу с той стороны — проход насквозь в том же направлении, стена цела.
     * Прежние порталы владельца закрываются: одна пара, как у «Точки».
     */
    private static void openSlice(ServerPlayer player, ServerLevel level, Direction facing,
                                  int width, int height, int range, int passes) {
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getLookAngle().normalize().scale(range));
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        if (hit.getType() != HitResult.Type.BLOCK) {
            fail(player, "Нет поверхности в пределах дальности");
            return;
        }
        Direction normal = hit.getDirection();
        Direction up = normal.getAxis().isVertical() ? facing : Direction.UP;
        Placement in = snapPlacement(level, hit.getLocation(), normal, up, width, height, true);
        Placement out = sliceExit(level, in, width, height);
        if (out == null) {
            fail(player, "Обратная сторона не найдена (до " + MysticPortalSettings.SLICE_DEPTH + " блоков)");
            return;
        }
        UUID owner = player.getUUID();
        closeAll(owner);
        Hole a = create(owner, level, in, width, height, passes);
        Hole b = create(owner, level, out, width, height, passes);
        if (a != null && b != null) link(a, b);
    }

    /**
     * Выход «Среза»: слой k — блоки на глубине k..k+1 за поверхностью входа, под всей
     * рамкой. Первый слой (k >= 1), где у всех этих блоков нет формы столкновения, —
     * пустота за стеной; обратная грань стены — на глубине k.
     */
    private static Placement sliceExit(ServerLevel level, Placement in, int width, int height) {
        Vec3 n = MysticPortalFrame.vec(in.normal());
        Vec3 wAxis = MysticPortalFrame.axisW(in.normal(), in.up());
        Vec3 hAxis = MysticPortalFrame.vec(in.up());
        Vec3 face = in.center().subtract(n.scale(FACE_OFFSET));
        for (int k = 1; k <= MysticPortalSettings.SLICE_DEPTH; k++) {
            Boolean free = layerFree(level, face, n, wAxis, hAxis, width, height, k);
            if (free == null) return null; // дальше не прогружено
            if (free) {
                Vec3 back = face.subtract(n.scale(k));
                return new Placement(back.subtract(n.scale(FACE_OFFSET)), in.normal().getOpposite(), in.up());
            }
        }
        return null;
    }

    /** Свободен ли слой k под рамкой; null — часть слоя в непрогруженных чанках. */
    private static Boolean layerFree(ServerLevel level, Vec3 face, Vec3 n, Vec3 wAxis, Vec3 hAxis,
                                     int width, int height, int k) {
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                Vec3 p = face.subtract(n.scale(k + 0.5))
                        .add(wAxis.scale(i + 0.5 - width * 0.5))
                        .add(hAxis.scale(j + 0.5 - height * 0.5));
                BlockPos pos = BlockPos.containing(p);
                if (!level.isLoaded(pos)) return null;
                if (!level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()) return false;
            }
        }
        return true;
    }

    /** Центр рамки по сетке блоков (края на гранях блоков), стоячая — на полу. */
    private static Placement snapPlacement(ServerLevel level, Vec3 c, Direction normal, Direction up,
                                           int width, int height, boolean onFace) {
        double x = coord(c.x, Direction.Axis.X, normal, up, width, height, onFace);
        double y = coord(c.y, Direction.Axis.Y, normal, up, width, height, onFace);
        double z = coord(c.z, Direction.Axis.Z, normal, up, width, height, onFace);
        if (normal.getAxis().isHorizontal()) y = restOnFloor(level, x, y, z, normal, height);
        return new Placement(new Vec3(x, y, z), normal, up);
    }

    /**
     * Координата центра по одной оси мира. Вдоль нормали — плоскость грани (чуть
     * впереди) или точка в воздухе как есть; в плоскости — по сетке блоков:
     * края рамки ложатся на грани блоков (вдоль up — по высоте, поперёк — по ширине).
     */
    private static double coord(double value, Direction.Axis axis, Direction normal, Direction up,
                                int width, int height, boolean onFace) {
        if (axis == normal.getAxis()) {
            return onFace ? value + FACE_OFFSET * normal.getAxisDirection().getStep() : value;
        }
        return snap(value, axis == up.getAxis() ? height : width);
    }

    private static double snap(double value, int size) {
        return (size & 1) == 1 ? Math.floor(value) + 0.5 : Math.round(value);
    }

    /**
     * Стоячий портал опускается на пол, если до пола меньше полутора блоков (и
     * поднимается, если ушёл в него нижним краем) — чтобы в него можно было войти.
     * Пол ищется в столбце сразу перед лицом.
     */
    private static double restOnFloor(ServerLevel level, double x, double cy, double z, Direction normal, int height) {
        double half = height * 0.5;
        double bottom = cy - half;
        double fx = x + normal.getStepX() * 0.5;
        double fz = z + normal.getStepZ() * 0.5;
        double floorTop = Double.NEGATIVE_INFINITY;
        for (int by = Mth.floor(cy); by >= Mth.floor(bottom - 1.5); by--) {
            BlockPos pos = BlockPos.containing(fx, by, fz);
            BlockState state = level.getBlockState(pos);
            VoxelShape shape = state.getCollisionShape(level, pos);
            if (shape.isEmpty()) continue;
            double top = by + shape.max(Direction.Axis.Y);
            if (top > cy + 1.0E-6) continue;
            floorTop = top;
            break;
        }
        if (floorTop > bottom - 1.5) bottom = floorTop;
        return bottom + half;
    }

    /** Выход режима «Точка»: точка — блок, где стоят (как «здесь» у пушки). */
    private static Placement pointPlacement(BlockPos pos, Placement lead, Direction facing, int width, int height, int plane) {
        Direction nA = lead.normal();
        Direction nB = switch (plane) {
            case MysticPortalSettings.PLANE_UP -> Direction.UP;
            case MysticPortalSettings.PLANE_DOWN -> Direction.DOWN;
            case MysticPortalSettings.PLANE_VERTICAL_X -> onAxis(Direction.Axis.Z, nA, facing);
            case MysticPortalSettings.PLANE_VERTICAL_Z -> onAxis(Direction.Axis.X, nA, facing);
            // как у ведущего: движение сквозь пару продолжается в ту же сторону
            default -> nA.getOpposite();
        };
        Direction up = nB.getAxis().isVertical() ? facing : Direction.UP;
        double half = height * 0.5;
        double x = nB.getAxis() == Direction.Axis.X ? pos.getX() + 0.5
                : snap(pos.getX() + 0.5, up.getAxis() == Direction.Axis.X ? height : width);
        double z = nB.getAxis() == Direction.Axis.Z ? pos.getZ() + 0.5
                : snap(pos.getZ() + 0.5, up.getAxis() == Direction.Axis.Z ? height : width);
        double y;
        if (nB == Direction.UP) y = pos.getY() + FACE_OFFSET;
        else if (nB == Direction.DOWN) y = pos.getY() + Math.max(Math.max(width, height), 2) + 0.5;
        else y = pos.getY() + half;
        return new Placement(new Vec3(x, y, z), nB, up);
    }

    /** Нормаль на заданной оси: против ведущего, если он на ней; иначе по взгляду; иначе в плюс. */
    private static Direction onAxis(Direction.Axis axis, Direction lead, Direction facing) {
        if (lead.getAxis() == axis) return lead.getOpposite();
        if (facing.getAxis() == axis) return facing;
        return axis == Direction.Axis.X ? Direction.EAST : Direction.SOUTH;
    }

    // ── порталы ─────────────────────────────────────────────────────────────

    private static Hole create(UUID owner, ServerLevel level, Placement at, int width, int height, int passes) {
        MysticPortalFrame frame = MysticPortalRegistry.FRAME.get().create(level);
        if (frame == null) return null;
        Hole hole = new Hole(owner, level, at.center(), at.normal(), at.up(), width, height, passes);
        frame.setup(at.center(), at.normal(), at.up(), width, height);
        hole.frame = frame;
        KNOWN.add(frame);
        BY_ID.put(hole.id, hole);
        BY_OWNER.computeIfAbsent(owner, k -> new ArrayList<>()).add(hole);
        ticket(hole);
        level.addFreshEntity(frame);
        return hole;
    }

    /** Открытые порталы владельца в порядке открытия. */
    private static List<Hole> active(UUID owner) {
        List<Hole> list = BY_OWNER.get(owner);
        List<Hole> out = new ArrayList<>();
        if (list != null) for (Hole h : list) if (h.open()) out.add(h);
        return out;
    }

    /** Свой портал там же, где новый, закрывается (как closeOverlappingPortals у пушки). */
    private static void closeOverlapping(UUID owner, ServerLevel level, Placement at, int size) {
        for (Hole h : active(owner)) {
            if (h.level != level || h.normal.getAxis() != at.normal().getAxis()) continue;
            Vec3 d = h.center.subtract(at.center());
            double reach = (h.maxSide() + size) * 0.5;
            double along = Math.abs(d.dot(MysticPortalFrame.vec(at.normal())));
            Vec3 flat = d.subtract(MysticPortalFrame.vec(at.normal()).scale(d.dot(MysticPortalFrame.vec(at.normal()))));
            if (along < 0.3 && Math.abs(flat.x) < reach && Math.abs(flat.y) < reach && Math.abs(flat.z) < reach) {
                close(h, true);
            }
        }
    }

    private static void link(Hole a, Hole b) {
        a.partner = b;
        b.partner = a;
        rebuild(a);
        rebuild(b);
    }

    /** Привести портал IP и состояние рамки к текущей паре. */
    private static void rebuild(Hole h) {
        if (!h.open()) return;
        removePortal(h);
        Hole p = h.partner;
        if (p == null || !p.open()) {
            h.partner = null;
            h.frame.setState(MysticPortalFrame.STATE_UNLINKED);
            return;
        }
        if (p.level != h.level) {
            h.frame.setState(MysticPortalFrame.STATE_CROSS);
            return;
        }
        h.frame.setState(MysticPortalFrame.STATE_VIEW);
        spawnPortal(h, p, h.age < ANIM_TICKS);
    }

    private static void spawnPortal(Hole h, Hole p, boolean grow) {
        MysticPortalEntity portal = MysticPortalEntity.ENTITY_TYPE.create(h.level);
        if (portal == null) return;
        Vec3 w = MysticPortalFrame.axisW(h.normal, h.up);
        Vec3 hv = MysticPortalFrame.vec(h.up);
        // только что открытый портал растёт вместе с ободком: IP сам плавно
        // анимирует клиенту смену размера (анимация по умолчанию, 10 тиков)
        double k = grow ? 0.02 : 1.0;
        portal.setOriginPos(h.center);
        portal.setOrientationAndSize(w, hv, h.width * k, h.height * k);
        portal.setDestinationDimension(p.level.dimension());
        portal.setDestination(p.center);
        portal.setOtherSideOrientation(PortalManipulation.getPortalOrientationQuaternion(
                MysticPortalFrame.axisW(p.normal, p.up), MysticPortalFrame.vec(p.up)));
        portal.holeId = h.id;
        h.portal = portal;
        h.growIn = grow ? 2 : 0;
        KNOWN.add(portal);
        h.level.addFreshEntity(portal);
    }

    private static void removePortal(Hole h) {
        if (h.portal == null) return;
        KNOWN.remove(h.portal);
        if (!h.portal.isRemoved()) h.portal.discard();
        h.portal = null;
        h.growIn = 0;
    }

    /** Закрыть портал: те, что вели в него, остаются без пары. */
    private static void close(Hole h, boolean animate) {
        if (!h.open()) return;
        h.closing = ANIM_TICKS;
        h.partner = null;
        List<Hole> list = BY_OWNER.get(h.owner);
        if (list != null) {
            for (Hole o : List.copyOf(list)) {
                if (o != h && o.partner == h) {
                    o.partner = null;
                    rebuild(o);
                }
            }
        }
        if (!animate || h.frame == null || h.frame.isRemoved()) {
            finish(h);
            return;
        }
        h.frame.setClosing();
        if (h.portal != null && !h.portal.isRemoved()) {
            h.portal.setTeleportable(false);
            h.portal.setOrientationAndSize(h.portal.getAxisW(), h.portal.getAxisH(), h.width * 0.02, h.height * 0.02);
            h.portal.reloadAndSyncToClient();
        }
    }

    private static void finish(Hole h) {
        removePortal(h);
        if (h.frame != null) {
            KNOWN.remove(h.frame);
            if (!h.frame.isRemoved()) h.frame.discard();
        }
        BY_ID.remove(h.id);
        List<Hole> list = BY_OWNER.get(h.owner);
        if (list != null) {
            list.remove(h);
            if (list.isEmpty()) BY_OWNER.remove(h.owner);
        }
    }

    public static void closeAll(UUID owner) {
        for (Hole h : active(owner)) close(h, true);
    }

    /** Держит чанки вокруг портала загруженными (сущности у выхода живут), тикет сам истекает. */
    private static void ticket(Hole h) {
        ChunkPos chunk = new ChunkPos(BlockPos.containing(h.center));
        h.level.getChunkSource().addRegionTicket(TicketType.PORTAL, chunk, 2, chunk.getWorldPosition());
    }

    // ── проходы ─────────────────────────────────────────────────────────────

    /** Кто-то прошёл через портал hole: проход списывается со входа и с выхода. */
    static void onPassed(UUID holeId) {
        Hole h = BY_ID.get(holeId);
        if (h == null || !h.open()) return;
        Hole exit = h.partner;
        spend(h);
        if (exit != null) spend(exit);
    }

    private static void spend(Hole h) {
        if (!h.open() || h.passesLeft < 0) return;
        h.passesLeft = Math.max(0, h.passesLeft - 1);
        if (h.passesLeft == 0) close(h, true);
    }

    // ── тик ─────────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        if (BY_ID.isEmpty()) return;
        for (Hole h : List.copyOf(BY_ID.values())) {
            try {
                tick(h);
            } catch (Exception e) {
                finish(h);
            }
        }
        if (!CROSS_COOLDOWNS.isEmpty()) {
            long now = event.getServer().overworld().getGameTime();
            CROSS_COOLDOWNS.values().removeIf(until -> until <= now);
        }
    }

    private static void tick(Hole h) {
        if (!h.open()) {
            if (--h.closing <= 0) finish(h);
            return;
        }
        if (h.frame == null || h.frame.isRemoved()) {
            close(h, false);
            return;
        }
        h.age++;
        if (h.age % TICKET_REFRESH == 0) ticket(h);
        if (h.portal != null && h.portal.isRemoved()) {
            // IP мог убрать портал сам (например, сочтя его неверным) — пересоздать, но не без конца
            KNOWN.remove(h.portal);
            h.portal = null;
            if (h.respawns++ < 3) rebuild(h);
        }
        if (h.growIn > 0 && --h.growIn == 0 && h.portal != null) {
            h.portal.setOrientationAndSize(h.portal.getAxisW(), h.portal.getAxisH(), h.width, h.height);
            h.portal.reloadAndSyncToClient();
        }
        if (h.frame.state() == MysticPortalFrame.STATE_CROSS) crossTeleport(h);
    }

    // ── переход между измерениями (без портала IP) ──────────────────────────

    private static void crossTeleport(Hole h) {
        Hole p = h.partner;
        if (p == null || !p.open()) return;
        Vec3 n = MysticPortalFrame.vec(h.normal);
        Vec3 w = MysticPortalFrame.axisW(h.normal, h.up);
        Vec3 hv = MysticPortalFrame.vec(h.up);
        double halfW = h.width * 0.5, halfH = h.height * 0.5;
        Vec3 ext = absv(w).scale(halfW).add(absv(hv).scale(halfH));
        AABB zone = new AABB(h.center.subtract(ext), h.center.add(ext))
                .minmax(new AABB(h.center.subtract(ext).add(n.scale(CROSS_REACH + 2.0)),
                        h.center.add(ext).add(n.scale(CROSS_REACH + 2.0))));
        long now = h.level.getGameTime();
        List<Entity> found = h.level.getEntities((Entity) null, zone,
                e -> e.isAlive() && !(e instanceof MysticPortalFrame) && !(e instanceof Portal)
                        && !e.isSpectator() && !e.isPassenger() && !e.isVehicle());
        for (Entity e : found) {
            Long until = CROSS_COOLDOWNS.get(e.getUUID());
            if (until != null && until > now) continue;
            AABB box = e.getBoundingBox();
            Vec3 rel = box.getCenter().subtract(h.center);
            double eW = extent(w, box), eH = extent(hv, box), eN = extent(n, box);
            if (eW > h.width + 1.0E-3 || eH > h.height + 1.0E-3) continue;            // не пролезает
            if (Math.abs(rel.dot(w)) + eW * 0.5 > halfW + 0.05) continue;              // не в рамке
            if (Math.abs(rel.dot(hv)) + eH * 0.5 > halfH + 0.05) continue;
            double d = rel.dot(n);
            if (d < -0.05 || d - eN * 0.5 > CROSS_REACH) continue;                     // не у лица
            if (!crossTo(e, h, p, rel, eN)) continue;
            CROSS_COOLDOWNS.put(e.getUUID(), p.level.getGameTime() + CROSS_COOLDOWN);
            onPassed(h.id);
            if (!h.open()) return;
        }
    }

    private static double extent(Vec3 axis, AABB box) {
        return Math.abs(axis.x) * box.getXsize() + Math.abs(axis.y) * box.getYsize() + Math.abs(axis.z) * box.getZsize();
    }

    private static Vec3 absv(Vec3 v) {
        return new Vec3(Math.abs(v.x), Math.abs(v.y), Math.abs(v.z));
    }

    /**
     * Поворот входа на выход, как у пары IP: ширина → минус ширина, высота → высота,
     * нормаль → минус нормаль (вошёл против лица входа — вышел вдоль лица выхода).
     */
    private static Vec3 rotate(Vec3 v, Hole from, Hole to) {
        Vec3 wA = MysticPortalFrame.axisW(from.normal, from.up), hA = MysticPortalFrame.vec(from.up), nA = MysticPortalFrame.vec(from.normal);
        Vec3 wB = MysticPortalFrame.axisW(to.normal, to.up), hB = MysticPortalFrame.vec(to.up), nB = MysticPortalFrame.vec(to.normal);
        return wB.scale(-v.dot(wA)).add(hB.scale(v.dot(hA))).add(nB.scale(-v.dot(nA)));
    }

    private static boolean crossTo(Entity e, Hole from, Hole to, Vec3 rel, double eNfrom) {
        Vec3 wA = MysticPortalFrame.axisW(from.normal, from.up), hA = MysticPortalFrame.vec(from.up);
        Vec3 wB = MysticPortalFrame.axisW(to.normal, to.up), hB = MysticPortalFrame.vec(to.up), nB = MysticPortalFrame.vec(to.normal);
        AABB box = e.getBoundingBox();
        // протяжённость хитбокса вдоль нормали выхода — после поворота это его размер по оси выхода
        double eN = extent(nB, box);
        Vec3 centre = to.center.add(wB.scale(-rel.dot(wA))).add(hB.scale(rel.dot(hA)))
                .add(nB.scale(eN * 0.5 + CROSS_REACH + 0.05));
        double x = centre.x, y = centre.y - box.getYsize() * 0.5, z = centre.z;

        Vec3 look = rotate(e.getLookAngle(), from, to);
        float yaw = (float) Math.toDegrees(Math.atan2(-look.x, look.z));
        float pitch = (float) Math.toDegrees(Math.asin(Mth.clamp(-look.y, -1.0, 1.0)));
        Vec3 vel = rotate(e.getDeltaMovement(), from, to);
        double out = vel.dot(nB);
        if (out < 0.1) vel = vel.add(nB.scale(0.1 - out));
        performTeleport(e, to.level, x, y, z, yaw, pitch, vel);
        return true;
    }

    // ── угол после перехода через портал IP ───────────────────────────────

    /**
     * Повернуть сущность, прошедшую через портал IP (скорость ядро уже повернуло):
     * снаряд смотрит вдоль новой скорости, остальные — повёрнутым порталом взглядом.
     * Клиентам — сразу угол и скорость (MysticPortalRotationPacket).
     */
    static void rotateAfterPortal(Entity entity, Portal portal) {
        float yaw, pitch;
        Vec3 vel = entity.getDeltaMovement();
        if (entity instanceof Projectile && vel.lengthSqr() > 1.0E-6) {
            // соглашение снарядов ванили (Projectile#updateRotation): yRot = atan2(x, z)
            double h = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
            yaw = (float) Math.toDegrees(Math.atan2(vel.x, vel.z));
            pitch = (float) Math.toDegrees(Math.atan2(vel.y, h));
        } else {
            Vec3 look = portal.transformLocalVecNonScale(Vec3.directionFromRotation(entity.getXRot(), entity.getYRot()));
            yaw = (float) Math.toDegrees(Math.atan2(-look.x, look.z));
            pitch = (float) Math.toDegrees(Math.asin(Mth.clamp(-look.y, -1.0, 1.0)));
        }
        applyRotation(entity, yaw, pitch);
        PacketDistributor.sendToPlayersTrackingEntity(entity,
                new MysticPortalRotationPacket(entity.getId(), yaw, pitch, vel.x, vel.y, vel.z));
    }

    /** Угол без интерполяции: текущий и прошлый тик, у живых — и голова с телом. */
    public static void applyRotation(Entity entity, float yaw, float pitch) {
        entity.setYRot(yaw);
        entity.setXRot(pitch);
        entity.yRotO = yaw;
        entity.xRotO = pitch;
        if (entity instanceof net.minecraft.world.entity.LivingEntity living) {
            living.setYHeadRot(yaw);
            living.yHeadRotO = yaw;
            living.yBodyRot = yaw;
            living.yBodyRotO = yaw;
        }
    }

    /** Как PortalTeleportEngine#performTeleport у пушки Рика. */
    private static void performTeleport(Entity entity, ServerLevel targetLevel, double x, double y, double z,
                                        float yaw, float pitch, Vec3 velocity) {
        if (entity.level() == targetLevel) {
            if (entity instanceof ServerPlayer player) {
                player.connection.teleport(x, y, z, yaw, pitch);
                player.setDeltaMovement(velocity);
                player.connection.send(new ClientboundSetEntityMotionPacket(player.getId(), velocity));
                player.hurtMarked = true;
                player.hasImpulse = true;
            } else {
                entity.teleportTo(x, y, z);
                entity.setYRot(yaw);
                entity.setXRot(pitch);
                entity.setYHeadRot(yaw);
                entity.setDeltaMovement(velocity);
                if (entity instanceof Projectile projectile) alignProjectile(projectile, velocity);
                entity.hurtMarked = true;
                entity.hasImpulse = true;
            }
            return;
        }
        DimensionTransition transition = new DimensionTransition(targetLevel, new Vec3(x, y, z), velocity,
                yaw, pitch, DimensionTransition.DO_NOTHING);
        if (entity instanceof ServerPlayer player) {
            player.changeDimension(transition);
            player.setDeltaMovement(velocity);
            player.connection.send(new ClientboundSetEntityMotionPacket(player.getId(), velocity));
            player.hurtMarked = true;
            player.hasImpulse = true;
        } else {
            Entity transferred = entity.changeDimension(transition);
            if (transferred != null) {
                transferred.setDeltaMovement(velocity);
                transferred.resetFallDistance();
                if (transferred instanceof Projectile projectile) alignProjectile(projectile, velocity);
            }
        }
    }

    private static void alignProjectile(Projectile projectile, Vec3 velocity) {
        if (velocity.length() <= 0.001) return;
        double hSpeed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
        float newYaw = (float) (Math.atan2(velocity.x, velocity.z) * (180.0 / Math.PI));
        float newPitch = (float) (Math.atan2(velocity.y, hSpeed) * (180.0 / Math.PI));
        projectile.setYRot(newYaw);
        projectile.setXRot(newPitch);
        projectile.yRotO = newYaw;
        projectile.xRotO = newPitch;
    }

    // ── настройки и жизнь игрока ────────────────────────────────────────────

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            PacketDistributor.sendToPlayer(player, new MysticPortalPackets.Settings(MysticPortalSettings.of(player)));
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        CompoundTag from = event.getOriginal().getPersistentData();
        if (from.contains(MysticPortalSettings.NBT)) {
            event.getEntity().getPersistentData().put(MysticPortalSettings.NBT, from.getCompound(MysticPortalSettings.NBT).copy());
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        HELD.remove(event.getEntity().getUUID());
        closeAll(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        BY_ID.clear();
        BY_OWNER.clear();
        KNOWN.clear();
        HELD.clear();
        CROSS_COOLDOWNS.clear();
    }
}
