package com.invfix.mysticportal;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;

/**
 * Рамка одного портала Mystic Portal: его геометрия, состояние и твёрдая
 * изнанка.
 *
 * Сам вид «на ту сторону» и переход — сущность ядра IP ({@link MysticPortalEntity}),
 * она есть только у связанного портала в том же измерении. Рамка есть всегда:
 *  - позиция — центр квадрата на плоскости портала;
 *  - нормаль — куда смотрит лицо портала, «верх» — ось высоты квадрата;
 *  - хитбокс — тонкая плита сразу за плоскостью: изнанка твёрдая (обычное
 *    столкновение с сущностью, как у лодки). Со стороны лица её отсекает
 *    столкновение ядра IP — всё, что лежит за плоскостью портала;
 *  - состояние для клиента: ободок, тёмная изнанка и тёмное лицо у портала без
 *    вида рисует эффект (client.MysticPortalFx).
 *
 * Не сохраняется по смыслу: после перезагрузки мира рамка без записи в
 * {@link MysticPortalHandler} сама исчезает.
 */
public class MysticPortalFrame extends Entity {

    /** Портал без пары: лицо тёмное. */
    public static final int STATE_UNLINKED = 0;
    /** Пара в том же измерении: вид и переход — ядро IP. */
    public static final int STATE_VIEW = 1;
    /** Пара в другом измерении: только переход, лицо тёмное. */
    public static final int STATE_CROSS = 2;

    /** Толщина твёрдой изнанки. */
    static final double BACK_THICKNESS = 0.08;

    private static final EntityDataAccessor<Integer> DATA_NORMAL =
            SynchedEntityData.defineId(MysticPortalFrame.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_UP =
            SynchedEntityData.defineId(MysticPortalFrame.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_SIZE =
            SynchedEntityData.defineId(MysticPortalFrame.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_STATE =
            SynchedEntityData.defineId(MysticPortalFrame.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_CLOSING =
            SynchedEntityData.defineId(MysticPortalFrame.class, EntityDataSerializers.BOOLEAN);

    /**
     * Клиент: игровое время появления рамки и начала схлопывания (-1 — не схлопывается).
     * Раскрытость считается от времени, а не тиком сущности: EntityCulling не тикает
     * сущности, которые не рисуются, а рамка сама ничего не рисует.
     */
    private long clientBorn = -1, clientClosingAt = -1;
    /** Хитбокс и ключ, по которому он посчитан (позиция и данные рамки). */
    private AABB boxCache;
    private double boxX = Double.NaN, boxY, boxZ;
    private int boxKey = -1;

    public MysticPortalFrame(EntityType<? extends MysticPortalFrame> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_NORMAL, Direction.UP.ordinal());
        builder.define(DATA_UP, Direction.NORTH.ordinal());
        builder.define(DATA_SIZE, 2);
        builder.define(DATA_STATE, STATE_UNLINKED);
        builder.define(DATA_CLOSING, false);
    }

    // ── геометрия ───────────────────────────────────────────────────────────

    void setup(Vec3 center, Direction normal, Direction up, int size) {
        this.entityData.set(DATA_NORMAL, normal.ordinal());
        this.entityData.set(DATA_UP, up.ordinal());
        this.entityData.set(DATA_SIZE, size);
        this.setPos(center.x, center.y, center.z);
        this.setBoundingBox(this.makeBoundingBox());
    }

    public Direction normal() {
        return dir(this.entityData.get(DATA_NORMAL), Direction.UP);
    }

    public Direction up() {
        return dir(this.entityData.get(DATA_UP), Direction.NORTH);
    }

    public int size() {
        return this.entityData.get(DATA_SIZE);
    }

    public int state() {
        return this.entityData.get(DATA_STATE);
    }

    void setState(int state) {
        this.entityData.set(DATA_STATE, state);
    }

    public boolean closing() {
        return this.entityData.get(DATA_CLOSING);
    }

    void setClosing() {
        this.entityData.set(DATA_CLOSING, true);
    }

    private static Direction dir(int ordinal, Direction fallback) {
        Direction[] all = Direction.values();
        return ordinal >= 0 && ordinal < all.length ? all[ordinal] : fallback;
    }

    public static Vec3 vec(Direction d) {
        return new Vec3(d.getStepX(), d.getStepY(), d.getStepZ());
    }

    /** Ось ширины: w × h = n, как у порталов IP. */
    public static Vec3 axisW(Direction normal, Direction up) {
        return vec(up).cross(vec(normal));
    }

    public Vec3 axisW() {
        return axisW(normal(), up());
    }

    @Override
    public void onSyncedDataUpdated(@NotNull EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (DATA_CLOSING.equals(key) && this.level().isClientSide() && closing() && clientClosingAt < 0) {
            clientClosingAt = this.level().getGameTime();
        }
    }

    /**
     * Хитбокс — всегда плита изнанки. Как у Portal ядра IP: переопределён сам
     * getBoundingBox, а не только makeBoundingBox, — иначе ваниль местами ставит
     * коробку по габариту типа (куб 1×1×1).
     */
    @Override
    public @NotNull AABB getBoundingBox() {
        double x = this.getX(), y = this.getY(), z = this.getZ();
        int key = this.entityData.get(DATA_NORMAL) | (this.entityData.get(DATA_UP) << 4) | (this.entityData.get(DATA_SIZE) << 8);
        if (boxCache == null || key != boxKey || x != boxX || y != boxY || z != boxZ) {
            boxKey = key;
            boxX = x;
            boxY = y;
            boxZ = z;
            boxCache = makeBoundingBox();
        }
        return boxCache;
    }

    /** Плита изнанки: квадрат портала, толщиной BACK_THICKNESS, целиком за плоскостью. */
    @Override
    protected @NotNull AABB makeBoundingBox() {
        Vec3 c = this.position();
        Vec3 n = vec(normal());
        Vec3 w = axisW();
        Vec3 h = vec(up());
        double half = size() * 0.5;
        Vec3 ext = abs(w).scale(half).add(abs(h).scale(half));
        Vec3 back0 = c.subtract(n.scale(0.002));
        Vec3 back1 = c.subtract(n.scale(BACK_THICKNESS));
        AABB a = new AABB(back0.subtract(ext), back0.add(ext));
        AABB b = new AABB(back1.subtract(ext), back1.add(ext));
        return a.minmax(b);
    }

    private static Vec3 abs(Vec3 v) {
        return new Vec3(Math.abs(v.x), Math.abs(v.y), Math.abs(v.z));
    }

    // ── клиент: раскрытие ───────────────────────────────────────────────────

    /** Клиент: рамка появилась в мире — отсюда отсчёт раскрытия. */
    public void clientJoined() {
        if (clientBorn < 0) clientBorn = this.level().getGameTime();
    }

    public float openness(float partial) {
        long now = this.level().getGameTime();
        if (clientBorn < 0) clientBorn = now;
        float anim = MysticPortalHandler.ANIM_TICKS;
        float grown = Math.min(1.0F, (now - clientBorn + partial) / anim);
        if (!closing()) return Math.max(0.0F, grown);
        if (clientClosingAt < 0) clientClosingAt = now;
        float shrunk = 1.0F - (now - clientClosingAt + partial) / anim;
        return Math.max(0.0F, Math.min(grown, shrunk));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) return;
        // рамка, о которой обработчик не знает (мир перезагружен), исчезает
        if (!MysticPortalHandler.isKnownFrame(this)) this.discard();
    }

    // ── поведение ───────────────────────────────────────────────────────────

    @Override public boolean canBeCollidedWith() { return !this.isRemoved(); }
    @Override public boolean isPushable() { return false; }
    @Override public boolean isPickable() { return false; }
    @Override public boolean hurt(@NotNull DamageSource source, float amount) { return false; }
    @Override public boolean fireImmune() { return true; }
    @Override public void move(@NotNull net.minecraft.world.entity.MoverType type, @NotNull Vec3 movement) {}

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 256.0 * 256.0;
    }

    @Override
    protected void readAdditionalSaveData(@NotNull CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(@NotNull CompoundTag tag) {}
}
