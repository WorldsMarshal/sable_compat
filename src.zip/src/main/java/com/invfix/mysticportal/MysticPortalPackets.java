package com.invfix.mysticportal;

import com.invfix.mysticportal.client.MysticPortalClient;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Пакеты Mystic Portal. */
public final class MysticPortalPackets {

    private MysticPortalPackets() {}

    /** Клиент → Сервер: выбрать Mystic Portal как текущую способность (для назначения в слот). */
    public record Assign(int x, int y, int z) implements CustomPacketPayload {

        public static final Type<Assign> TYPE =
                new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "mystic_portal_assign"));

        public static final StreamCodec<FriendlyByteBuf, Assign> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> { buf.writeInt(m.x()); buf.writeInt(m.y()); buf.writeInt(m.z()); },
                buf -> new Assign(buf.readInt(), buf.readInt(), buf.readInt()));

        @Override public Type<Assign> type() { return TYPE; }

        public static void handleServer(Assign pkt, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (!(ctx.player() instanceof ServerPlayer player) || !MysticPortalHandler.eligible(player)) return;
                try {
                    InvincibleIncModVariables.PlayerVariables vars =
                            player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                    vars.AbilitySet = MysticPortalHandler.ABILITY;
                    vars.abilityDescription = MysticPortalHandler.ABILITY + " | LVL:" + MysticPortalHandler.LVL_REQUIRED
                            + " | Shift + клавиша — настройка";
                    vars.markSyncDirty();
                } catch (Exception ignored) {}
            });
        }
    }

    /** Настройки в обе стороны: клиент → сервер — сохранить из меню; сервер → клиент — сохранённые (при входе). */
    public record Settings(MysticPortalSettings settings) implements CustomPacketPayload {

        public static final Type<Settings> TYPE =
                new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "mystic_portal_settings"));

        public static final StreamCodec<RegistryFriendlyByteBuf, Settings> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> MysticPortalSettings.STREAM_CODEC.encode(buf, m.settings()),
                buf -> new Settings(MysticPortalSettings.STREAM_CODEC.decode(buf)));

        @Override public Type<Settings> type() { return TYPE; }

        public static void handleServer(Settings p, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (ctx.player() instanceof ServerPlayer player) p.settings().sanitized().save(player);
            });
        }

        @OnlyIn(Dist.CLIENT)
        public static void handleClient(Settings p, IPayloadContext ctx) {
            ctx.enqueueWork(() -> MysticPortalClient.setSettings(p.settings().sanitized()));
        }
    }

    /** Клиент → Сервер: закрыть все свои порталы. */
    public record CloseAll() implements CustomPacketPayload {

        public static final Type<CloseAll> TYPE =
                new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "mystic_portal_close_all"));

        public static final StreamCodec<FriendlyByteBuf, CloseAll> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> {},
                buf -> new CloseAll());

        @Override public Type<CloseAll> type() { return TYPE; }

        public static void handleServer(CloseAll p, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (ctx.player() instanceof ServerPlayer player) MysticPortalHandler.closeAll(player.getUUID());
            });
        }
    }
}
