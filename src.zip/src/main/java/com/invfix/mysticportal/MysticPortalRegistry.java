package com.invfix.mysticportal;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Сущности Mystic Portal. Рамка — здесь; портал ядра IP (MysticPortalEntity)
 * регистрируется вместе с типами IP (IPModMain#registerEntityTypes), как
 * sable_compat:mystic_portal.
 */
public final class MysticPortalRegistry {

    private MysticPortalRegistry() {}

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, "sable_compat");

    /** Габарит — стартовый, настоящий хитбокс задаёт рамка (makeBoundingBox). */
    public static final DeferredHolder<EntityType<?>, EntityType<MysticPortalFrame>> FRAME =
            ENTITIES.register("mystic_portal_frame", () -> EntityType.Builder
                    .<MysticPortalFrame>of(MysticPortalFrame::new, MobCategory.MISC)
                    .sized(1.0F, 1.0F)
                    .fireImmune()
                    .noSummon()
                    .clientTrackingRange(16)
                    .updateInterval(20)
                    .build("mystic_portal_frame"));

    public static void register(IEventBus modEventBus) {
        ENTITIES.register(modEventBus);
    }
}
