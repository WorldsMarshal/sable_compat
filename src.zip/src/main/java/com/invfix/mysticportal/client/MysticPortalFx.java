package com.invfix.mysticportal.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import com.invfix.mysticportal.MysticPortalFrame;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Порталы Mystic Portal на графике Fx (mystic_portal.fsh): квадратная рамка из
 * жёлтых искр, тёмная изнанка, тёмное лицо у портала без вида. Раскрытие и
 * схлопывание — рамка растёт из точки и стягивается в точку.
 *
 * Один эффект на клиент, живёт, пока в мире есть рамки. Порталы — до
 * {@link #PER_PASS} за проход, ближние первыми; в проходе — от дальнего к
 * ближнему, чтобы тёмные заливки ложились правильно.
 */
@OnlyIn(Dist.CLIENT)
public final class MysticPortalFx extends FxEffect {

    private static final int PER_PASS = 4;
    private static final int MAX_DRAWN = 16;
    private static final double MAX_DISTANCE = 256.0;
    private static final int LINGER = 20;

    private static MysticPortalFx instance;
    private int idle;

    private MysticPortalFx() {}

    static void ensure() {
        if (instance == null || instance.finished()) {
            instance = new MysticPortalFx();
            FxManager.add(instance);
        }
        instance.idle = 0;
    }

    @Override
    protected void onTick(Minecraft minecraft, ClientLevel level, int age) {
        if (MysticPortalClient.FRAMES.isEmpty()) idle++;
        else idle = 0;
    }

    @Override
    protected int duration() {
        return Integer.MAX_VALUE;
    }

    @Override
    public boolean finished() {
        return idle > LINGER;
    }

    @Override
    protected void onRemoved() {
        if (instance == this) instance = null;
    }

    @Override
    public Vec3 focus() {
        return FxManager.camera();
    }

    @Override
    public double range() {
        return Double.MAX_VALUE;
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        if (MysticPortalClient.FRAMES.isEmpty()) return;
        Vec3 cam = frame.camera();
        float partial = frame.partial();
        List<MysticPortalFrame> drawn = new ArrayList<>();
        for (MysticPortalFrame f : MysticPortalClient.FRAMES) {
            if (f.isRemoved() || f.openness(partial) <= 0.001F) continue;
            if (f.position().distanceTo(cam) > MAX_DISTANCE) continue;
            drawn.add(f);
        }
        if (drawn.isEmpty()) return;
        drawn.sort(Comparator.comparingDouble(f -> f.position().distanceToSqr(cam)));
        if (drawn.size() > MAX_DRAWN) drawn = new ArrayList<>(drawn.subList(0, MAX_DRAWN));
        float time = (age + partial) / 20.0F;

        for (int start = 0; start < drawn.size(); start += PER_PASS) {
            List<MysticPortalFrame> batch = new ArrayList<>(drawn.subList(start, Math.min(drawn.size(), start + PER_PASS)));
            batch.sort(Comparator.comparingDouble((MysticPortalFrame f) -> f.position().distanceToSqr(cam)).reversed());
            float[] pts = new float[16 * 4];
            for (int i = 0; i < batch.size(); i++) {
                MysticPortalFrame f = batch.get(i);
                Vec3 c = frame.rel(f.position());
                Vec3 n = MysticPortalFrame.vec(f.normal());
                Vec3 w = f.axisW();
                int o = i * 16;
                put(pts, o, c, f.size());
                put(pts, o + 4, n, smooth(f.openness(partial)));
                put(pts, o + 8, w, f.state());
                pts[o + 12] = (f.getId() * 0.618034F) % 1.0F;
                pts[o + 13] = f.closing() ? 1.0F : 0.0F;
            }
            int count = batch.size();
            out.add(new FxPass("mystic_portal", u -> {
                u.f4("P0", count, time, 0.0F, 0.0F);
                u.vec4s("Pts", pts);
            }));
        }
    }

    private static void put(float[] a, int o, Vec3 v, float w) {
        a[o] = (float) v.x;
        a[o + 1] = (float) v.y;
        a[o + 2] = (float) v.z;
        a[o + 3] = w;
    }

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        // искры светятся: bloom, когда портал рядом
        Vec3 cam = frame.camera();
        for (MysticPortalFrame f : MysticPortalClient.FRAMES) {
            if (f.isRemoved()) continue;
            double d = f.position().distanceTo(cam);
            if (d < 48.0) {
                float k = (float) (1.0 - d / 48.0) * f.openness(frame.partial());
                screen.bloom = Math.max(screen.bloom, 0.6F * k);
                screen.bloomRadius = Math.max(screen.bloomRadius, 1.0F);
            }
        }
    }
}
