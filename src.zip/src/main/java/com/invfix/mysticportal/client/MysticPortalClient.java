package com.invfix.mysticportal.client;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.mysticportal.MysticPortalFrame;
import com.invfix.mysticportal.MysticPortalHandler;
import com.invfix.mysticportal.MysticPortalPackets;
import com.invfix.mysticportal.MysticPortalRegistry;
import com.invfix.mysticportal.MysticPortalSettings;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.vertex.PoseStack;
import net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Клиент Mystic Portal: настройки (сохранённые на сервере приходят при входе),
 * меню по Shift + клавиша слота, где стоит способность (сервер на нажатие с
 * Shift портал не открывает), и список рамок в мире для эффекта ободка.
 */
@OnlyIn(Dist.CLIENT)
public final class MysticPortalClient {

    private static MysticPortalSettings settings = MysticPortalSettings.DEFAULT;
    private static boolean wasDown;
    /** Рамки текущего клиентского мира — их рисует {@link MysticPortalFx}. */
    static final List<MysticPortalFrame> FRAMES = new ArrayList<>();

    private MysticPortalClient() {}

    public static void init(IEventBus modEventBus) {
        modEventBus.addListener(MysticPortalClient::onRegisterRenderers);
        NeoForge.EVENT_BUS.addListener((EntityJoinLevelEvent e) -> {
            if (e.getLevel().isClientSide() && !e.isCanceled() && e.getEntity() instanceof MysticPortalFrame f) {
                if (!FRAMES.contains(f)) FRAMES.add(f);
                MysticPortalFx.ensure();
            }
        });
        NeoForge.EVENT_BUS.addListener((EntityLeaveLevelEvent e) -> {
            if (e.getLevel().isClientSide() && e.getEntity() instanceof MysticPortalFrame f) FRAMES.remove(f);
        });
    }

    private static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(MysticPortalRegistry.FRAME.get(), FrameRenderer::new);
    }

    public static MysticPortalSettings settings() {
        return settings;
    }

    public static void setSettings(MysticPortalSettings s) {
        settings = s;
    }

    static void save(MysticPortalSettings s) {
        settings = s.sanitized();
        PacketDistributor.sendToServer(new MysticPortalPackets.Settings(settings), new CustomPacketPayload[0]);
    }

    static void closeAll() {
        PacketDistributor.sendToServer(new MysticPortalPackets.CloseAll(), new CustomPacketPayload[0]);
    }

    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
    public static final class GameBus {

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) {
                wasDown = false;
                FRAMES.clear();
                return;
            }
            FRAMES.removeIf(f -> f.isRemoved() || f.level() != mc.level);
            if (!FRAMES.isEmpty()) MysticPortalFx.ensure();
            boolean down = mc.screen == null && slotKeyDown(mc);
            if (down && !wasDown && rawDown(mc, mc.options.keyShift)) {
                mc.setScreen(new MysticPortalScreen(settings));
            }
            wasDown = down;
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            settings = MysticPortalSettings.DEFAULT;
            wasDown = false;
            FRAMES.clear();
        }
    }

    /** Зажата ли клавиша слота, в котором стоит Mystic Portal (текущий ряд). */
    private static boolean slotKeyDown(Minecraft mc) {
        try {
            InvincibleIncModVariables.PlayerVariables v = mc.player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (!AltrumiteRace.isAltrumite(v.Race)) return false;
            boolean row1 = v.AbilityRow == 1.0;
            String[] slots = {
                    row1 ? v.AbilitySlot1 : v.AbilitySlot1_row2,
                    row1 ? v.AbilitySlot2 : v.AbilitySlot2_row2,
                    row1 ? v.AbilitySlot3 : v.AbilitySlot3_row2,
                    row1 ? v.AbilitySlot4 : v.AbilitySlot4_row2,
                    row1 ? v.AbilitySlot5 : v.AbilitySlot5_row2};
            KeyMapping[] keys = {
                    InvincibleIncModKeyMappings.ABILITY_1, InvincibleIncModKeyMappings.ABILITY_2,
                    InvincibleIncModKeyMappings.ABILITY_3, InvincibleIncModKeyMappings.ABILITY_4,
                    InvincibleIncModKeyMappings.ABILITY_5};
            for (int i = 0; i < 5; i++) {
                if (MysticPortalHandler.ABILITY.equals(slots[i]) && rawDown(mc, keys[i])) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    /** Физическое состояние клавиши, мимо модификаторов (как у Space Fold). */
    private static boolean rawDown(Minecraft mc, KeyMapping km) {
        if (km == null) return false;
        InputConstants.Key key = km.getKey();
        if (key == null || key.getValue() == InputConstants.UNKNOWN.getValue()) return false;
        long window = mc.getWindow().getWindow();
        return switch (key.getType()) {
            case KEYSYM -> InputConstants.isKeyDown(window, key.getValue());
            case MOUSE -> GLFW.glfwGetMouseButton(window, key.getValue()) == GLFW.GLFW_PRESS;
            default -> km.isDown();
        };
    }

    /** Рамка сама ничего не рисует: ободок и тёмные стороны — эффект {@link MysticPortalFx}. */
    static final class FrameRenderer extends EntityRenderer<MysticPortalFrame> {

        FrameRenderer(EntityRendererProvider.Context context) {
            super(context);
        }

        @Override
        public boolean shouldRender(@NotNull MysticPortalFrame entity, @NotNull Frustum frustum,
                                    double x, double y, double z) {
            return false;
        }

        @Override
        public void render(@NotNull MysticPortalFrame entity, float yaw, float partialTick, @NotNull PoseStack poseStack,
                           @NotNull MultiBufferSource buffer, int light) {}

        @Override
        public @NotNull ResourceLocation getTextureLocation(@NotNull MysticPortalFrame entity) {
            return InventoryMenu.BLOCK_ATLAS;
        }
    }
}
