package com.invfix.mysticportal.client;

import com.invfix.mysticportal.MysticPortalSettings;
import com.invfix.rick.portalgun.PortalMode;
import com.invfix.rick.portalgun.PortalPoint;
import com.invfix.rick.portalgun.client.GadgetButton;
import com.invfix.rick.portalgun.client.GadgetGuiUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.List;

/**
 * Меню Mystic Portal (Shift + клавиша способности). Устроено как панель
 * портальной пушки Рика (PortalGunScreen): пять точек и редактор выбранной,
 * режим, лимит проходов, «закрыть все» — плюс размер рамки, дальность и
 * плоскость выхода режима «Точка».
 */
@OnlyIn(Dist.CLIENT)
public class MysticPortalScreen extends Screen {

    private static final int PANEL_W = 340;
    private static final int PANEL_H = 280;
    private static final int PAD = 12;
    private static final int ROW_H = 20;
    private static final int LIST_W = 130;

    private static final int TEXT_MUTED = 0xFF8A909C;
    private static final int TEXT_GOLD = 0xFFFFC23A;
    private static final int TEXT_CYAN = 0xFF36D7E8;
    private static final int TEXT_AMBER = 0xFFFFB326;


    private final List<PortalPoint> points = new ArrayList<>();
    private EditBox labelBox, xBox, yBox, zBox, dimBox, rangeBox;
    private GadgetButton passesButton, sizeButton, planeButton, entryButton;
    private int rangeRowY, rangeLabelX;

    private int selected;
    private int passLimit;
    private int size;
    private int range;
    private int plane;
    private int entry;
    private PortalMode mode;
    /** Режим «Срез пространства» (идёт в меню после режимов PortalMode). */
    private boolean slice;
    private int left, top;

    public MysticPortalScreen(MysticPortalSettings s) {
        super(Component.literal("Mystic Portal"));
        this.points.addAll(s.points());
        this.selected = s.selected();
        this.passLimit = s.passLimit();
        this.size = s.size();
        this.range = s.range();
        this.plane = s.plane();
        this.entry = s.entry();
        this.mode = s.portalMode();
        this.slice = s.slice();
    }

    @Override
    protected void init() {
        this.left = (this.width - PANEL_W) / 2;
        this.top = (this.height - PANEL_H) / 2;

        int listX = left + PAD;
        int listTop = top + 84;
        for (int i = 0; i < MysticPortalSettings.MAX_POINTS; i++) {
            final int index = i;
            PortalPoint p = points.get(i);
            String name = p.isSet() ? p.display() : "— пусто —";
            addRenderableWidget(GadgetButton.gadget(Component.literal(trim((i + 1) + ". " + name, LIST_W - 20)),
                            b -> { commit(); selected = index; rebuild(); })
                    .bounds(listX, listTop + i * ROW_H, LIST_W, 18)
                    .style(index == selected ? GadgetButton.Style.PRIMARY : GadgetButton.Style.NORMAL)
                    .build());
        }

        int editX = listX + LIST_W + 10;
        int editW = left + PANEL_W - PAD - editX;
        int y = listTop;
        labelBox = box(editX, y, editW, points.get(selected).label(), "Подпись");
        y += ROW_H;

        int third = (editW - 8) / 3;
        BlockPos pos = points.get(selected).pos();
        xBox = box(editX, y, third, Integer.toString(pos.getX()), "X");
        yBox = box(editX + third + 4, y, third, Integer.toString(pos.getY()), "Y");
        zBox = box(editX + (third + 4) * 2, y, third, Integer.toString(pos.getZ()), "Z");
        y += ROW_H;

        dimBox = box(editX, y, editW - 24, points.get(selected).dimension().toString(), "Измерение");
        addRenderableWidget(GadgetButton.gadget(Component.literal("↻"), b -> cycleDimension())
                .bounds(editX + editW - 20, y, 20, 18).build());
        y += ROW_H + 2;

        int halfW = (editW - 4) / 2;
        addRenderableWidget(GadgetButton.gadget(Component.literal("Здесь"), b -> fillFromPlayer())
                .bounds(editX, y, halfW, 18).build());
        addRenderableWidget(GadgetButton.gadget(Component.literal("Очистить"),
                        b -> { points.set(selected, PortalPoint.EMPTY); rebuild(); })
                .bounds(editX + halfW + 4, y, halfW, 18).style(GadgetButton.Style.DANGER).build());
        y += ROW_H + 2;

        // Дальность: блок ближе — портал на его грани, иначе в воздухе на этом расстоянии.
        int rangeW = 44;
        rangeRowY = y;
        rangeLabelX = editX;
        rangeBox = new EditBox(this.font, editX + editW - rangeW, y, rangeW, 18, Component.literal("Дальность"));
        rangeBox.setMaxLength(2);
        rangeBox.setFilter(s -> s.isEmpty() || s.chars().allMatch(Character::isDigit));
        rangeBox.setValue(Integer.toString(range));
        rangeBox.setResponder(s -> range = clampRange(parse(s, range)));
        addRenderableWidget(rangeBox);

        // плоскости входа и выхода (ЛКМ — дальше, ПКМ — назад)
        int halfRow = (PANEL_W - PAD * 2 - 4) / 2;
        int row0 = top + PANEL_H - PAD - 18 - 44;
        entryButton = addRenderableWidget(GadgetButton.gadget(
                        Component.literal("Вход: " + MysticPortalSettings.entryName(entry)),
                        b -> { commit(); entry = Math.floorMod(entry + 1, MysticPortalSettings.ENTRIES); rebuild(); })
                .bounds(left + PAD, row0, halfRow, 18).build());
        planeButton = addRenderableWidget(GadgetButton.gadget(
                        Component.literal("Выход: " + MysticPortalSettings.planeName(plane)),
                        b -> { commit(); plane = MysticPortalSettings.stepPlane(plane, 1); rebuild(); })
                .bounds(left + PAD + halfRow + 4, row0, halfRow, 18).build());

        int quarter = (PANEL_W - PAD * 2 - 8) / 3;
        int row1 = top + PANEL_H - PAD - 18 - 22;
        int bx = left + PAD;
        addRenderableWidget(GadgetButton.gadget(
                        Component.literal("Режим: ").append(modeName()),
                        b -> { commit(); nextMode(); rebuild(); })
                .bounds(bx, row1, quarter, 18).build());
        bx += quarter + 4;
        // ЛКМ — больше, ПКМ — меньше (по кругу в обе стороны).
        passesButton = addRenderableWidget(GadgetButton.gadget(
                        Component.literal("Проходы: " + (passLimit == 0 ? "∞" : Integer.toString(passLimit))),
                        b -> { commit(); passLimit = Math.floorMod(passLimit + 1, MysticPortalSettings.MAX_PASSES + 1); rebuild(); })
                .bounds(bx, row1, quarter, 18).build());
        bx += quarter + 4;
        sizeButton = addRenderableWidget(GadgetButton.gadget(
                        Component.literal("Размер: " + MysticPortalSettings.sizeLabel(size)),
                        b -> { commit(); stepSize(1); rebuild(); })
                .bounds(bx, row1, quarter, 18).build());

        int row2 = top + PANEL_H - PAD - 18;
        int half = (PANEL_W - PAD * 2 - 4) / 2;
        addRenderableWidget(GadgetButton.gadget(Component.literal("Закрыть все порталы"),
                        b -> MysticPortalClient.closeAll())
                .bounds(left + PAD, row2, half, 18).style(GadgetButton.Style.DANGER).build());
        addRenderableWidget(GadgetButton.gadget(Component.literal("Применить"),
                        b -> { commit(); apply(); onClose(); })
                .bounds(left + PAD + half + 4, row2, half, 18).style(GadgetButton.Style.PRIMARY).build());
    }

    private void stepSize(int delta) {
        size = MysticPortalSettings.stepSize(size, delta);
    }

    /** Режимы по кругу: режимы PortalMode, затем «Срез пространства». */
    private void nextMode() {
        if (slice) {
            slice = false;
            mode = PortalMode.values()[0];
        } else if (mode.ordinal() == PortalMode.values().length - 1) {
            slice = true;
        } else {
            mode = mode.next();
        }
    }

    private Component modeName() {
        return slice ? Component.literal("Срез пространства") : Component.translatable(mode.translationKey());
    }

    private static int clampRange(int value) {
        return Math.max(MysticPortalSettings.MIN_RANGE, Math.min(value, MysticPortalSettings.MAX_RANGE));
    }

    /** ПКМ по проходам и размеру уменьшает их; остальное — как обычно. */
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 1 && passesButton != null && passesButton.isMouseOver(mouseX, mouseY)) {
            commit();
            passLimit = Math.floorMod(passLimit - 1, MysticPortalSettings.MAX_PASSES + 1);
            rebuild();
            return true;
        }
        if (button == 1 && planeButton != null && planeButton.isMouseOver(mouseX, mouseY)) {
            commit();
            plane = MysticPortalSettings.stepPlane(plane, -1);
            rebuild();
            return true;
        }
        if (button == 1 && entryButton != null && entryButton.isMouseOver(mouseX, mouseY)) {
            commit();
            entry = Math.floorMod(entry - 1, MysticPortalSettings.ENTRIES);
            rebuild();
            return true;
        }
        if (button == 1 && sizeButton != null && sizeButton.isMouseOver(mouseX, mouseY)) {
            commit();
            stepSize(-1);
            rebuild();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    /** При смене размера окна введённое не теряется. */
    @Override
    public void resize(Minecraft minecraft, int width, int height) {
        commit();
        super.resize(minecraft, width, height);
    }

    private EditBox box(int x, int y, int w, String value, String hint) {
        EditBox b = new EditBox(this.font, x, y, w, 18, Component.literal(hint));
        b.setMaxLength(64);
        b.setValue(value);
        b.setHint(Component.literal(hint).withStyle(ChatFormatting.DARK_GRAY));
        addRenderableWidget(b);
        return b;
    }

    /** Переносит введённое в модель. Зовётся перед любой сменой состояния. */
    private void commit() {
        if (labelBox == null) return;
        PortalPoint old = points.get(selected);
        int x = parse(xBox.getValue(), old.pos().getX());
        int y = parse(yBox.getValue(), old.pos().getY());
        int z = parse(zBox.getValue(), old.pos().getZ());
        ResourceLocation dim = ResourceLocation.tryParse(dimBox.getValue().trim());
        if (dim == null) dim = old.dimension();
        points.set(selected, new PortalPoint(labelBox.getValue(), new BlockPos(x, y, z), dim));
        if (rangeBox != null) range = clampRange(parse(rangeBox.getValue(), range));
    }

    private static int parse(String raw, int fallback) {
        try {
            return Integer.parseInt(raw.trim());
        } catch (NumberFormatException bad) {
            return fallback;
        }
    }

    private void fillFromPlayer() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        BlockPos pos = mc.player.blockPosition();
        xBox.setValue(Integer.toString(pos.getX()));
        yBox.setValue(Integer.toString(pos.getY()));
        zBox.setValue(Integer.toString(pos.getZ()));
        dimBox.setValue(mc.player.level().dimension().location().toString());
    }

    /** Листает измерения, известные текущему подключению. */
    private void cycleDimension() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.connection == null) return;
        List<ResourceLocation> known = new ArrayList<>();
        for (ResourceKey<Level> key : mc.player.connection.levels()) known.add(key.location());
        if (known.isEmpty()) return;
        known.sort(ResourceLocation::compareTo);
        ResourceLocation current = ResourceLocation.tryParse(dimBox.getValue().trim());
        int index = current == null ? -1 : known.indexOf(current);
        dimBox.setValue(known.get((index + 1) % known.size()).toString());
    }

    private void rebuild() {
        this.clearWidgets();
        this.init();
    }

    private void apply() {
        List<PortalPoint> clean = new ArrayList<>(MysticPortalSettings.MAX_POINTS);
        for (PortalPoint p : points) {
            clean.add(new PortalPoint(PortalPoint.sanitize(p.label()), p.pos(), p.dimension()));
        }
        MysticPortalClient.save(new MysticPortalSettings(slice ? MysticPortalSettings.MODE_SLICE : mode.id(),
                passLimit, size, clampRange(range), plane,
                List.copyOf(clean), selected, entry));
    }

    private String trim(String text, int width) {
        return this.font.width(text) <= width ? text : this.font.plainSubstrByWidth(text, width - 6) + "…";
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g, mouseX, mouseY, partialTick);

        GadgetGuiUtils.renderChassis(g, left, top, PANEL_W, PANEL_H);
        GadgetGuiUtils.renderHeader(g, left + 4, top + 4, PANEL_W - 8, 30);
        g.fill(left + 8, top + 6, left + 34, top + 32, 0xFF121417);
        g.renderOutline(left + 8, top + 6, 26, 26, 0xFF353942);
        g.blit(ResourceLocation.parse("sable_compat:textures/screens/ab_mystic_portal.png"),
                left + 11, top + 9, 0.0F, 0.0F, 20, 20, 20, 20);
        g.drawString(this.font, "Mystic Portal", left + 40, top + 9, TEXT_GOLD, false);
        g.drawString(this.font, "Магический портал · Shift + клавиша", left + 40, top + 21, TEXT_MUTED, false);

        int screenX = left + PAD;
        int screenY = top + 38;
        int screenW = PANEL_W - PAD * 2;
        GadgetGuiUtils.renderTerminalScreen(g, screenX, screenY, screenW, 40);

        g.drawString(this.font, "Режим", screenX + 6, screenY + 5, TEXT_MUTED, false);
        g.drawString(this.font, modeName().getString(), screenX + 52, screenY + 5, TEXT_CYAN, false);
        String geometry = "рамка " + MysticPortalSettings.sizeLabel(size) + " · дальность " + range;
        g.drawString(this.font, geometry, screenX + screenW - this.font.width(geometry) - 8, screenY + 5, TEXT_MUTED, false);

        g.drawString(this.font, "Проходы", screenX + 6, screenY + 17, TEXT_MUTED, false);
        g.drawString(this.font, passLimit == 0 ? "без лимита" : Integer.toString(passLimit), screenX + 52, screenY + 17,
                TEXT_CYAN, false);

        g.drawString(this.font, "Цель", screenX + 6, screenY + 29, TEXT_MUTED, false);
        String target;
        int targetColor;
        if (slice) {
            target = "сквозь стену: вход на поверхности, выход за ней (до "
                    + MysticPortalSettings.SLICE_DEPTH + " бл.)";
            targetColor = TEXT_AMBER;
        } else if (mode == PortalMode.POINT) {
            PortalPoint p = points.get(selected);
            target = p.isSet() ? p.display() + " (" + p.dimension().getPath() + ") · выход: " + MysticPortalSettings.planeName(plane)
                    : "точка не задана";
            targetColor = p.isSet() ? TEXT_AMBER : TEXT_MUTED;
        } else {
            target = "куда смотришь";
            targetColor = TEXT_GOLD;
        }
        g.drawString(this.font, trim(target, screenW - 60), screenX + 52, screenY + 29, targetColor, false);
        GadgetGuiUtils.renderLed(g, screenX + screenW - 12, screenY + 30, 0xFFFFB000);

        g.drawString(this.font, "Точки", left + PAD, top + 84 - 11, TEXT_MUTED, false);
        g.drawString(this.font, "Дальность (1–60)", rangeLabelX, rangeRowY + 5, TEXT_CYAN, false);

        // Не super.render: он повторно рисует фон поверх корпуса — только виджеты.
        for (net.minecraft.client.gui.components.Renderable renderable : this.renderables) {
            renderable.render(g, mouseX, mouseY, partialTick);
        }
    }

    /** Размытый фон ванили не нужен — у панели свой корпус. */
    @Override
    protected void renderBlurredBackground(float partialTick) {
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
