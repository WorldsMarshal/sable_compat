package com.invfix.mysticportal.client;

import com.invfix.mysticportal.MysticPortalFrame;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

/**
 * Ободок Mystic Portal внутри прохода портала (портал в портале): вместо полной
 * графики с искрами — статичная жёлто-оранжевая обводка рамки, обычной геометрией
 * в мир прохода. Почти ничего не стоит: ни снимков экрана, ни полноэкранных шейдеров.
 * Трафарет ядра IP ограничивает её окном портала, глубина мира прохода прячет за стенами.
 */
@OnlyIn(Dist.CLIENT)
public final class MysticPortalOutline {

    /** Толщина яркой линии и мягкого ореола вокруг неё, блоков. */
    private static final float CORE = 0.09F;
    private static final float GLOW = 0.32F;
    private static final double MAX_DISTANCE = 256.0;

    private MysticPortalOutline() {}

    /**
     * Конец LevelRenderer#renderLevel в проходе портала. view — матрица вида прохода
     * (позиции относительно камеры), проекция прохода уже стоит в RenderSystem.
     */
    public static void render(Matrix4f view, Vec3 camera, float partial,
                              @Nullable Vec3 clipPos, @Nullable Vec3 clipNormal) {
        if (MysticPortalClient.FRAMES.isEmpty()) return;
        Tesselator tesselator = Tesselator.getInstance();
        BufferBuilder buffer = tesselator.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        boolean any = false;
        for (MysticPortalFrame f : MysticPortalClient.FRAMES) {
            if (f.isRemoved()) continue;
            float open = f.openness(partial);
            if (open <= 0.001F) continue;
            Vec3 c = f.position();
            if (c.distanceTo(camera) > MAX_DISTANCE) continue;
            // по ту сторону плоскости отсечения прохода мира нет
            if (clipPos != null && clipNormal != null
                    && c.subtract(clipPos).dot(clipNormal.normalize()) < 0.02) continue;
            Vec3 n = MysticPortalFrame.vec(f.normal());
            Vec3 w = MysticPortalFrame.axisW(f.normal(), f.up());
            Vec3 h = MysticPortalFrame.vec(f.up());
            // чуть перед лицом, чтобы не спорить по глубине со стеной под рамкой
            Vec3 rel = c.subtract(camera).add(n.scale(0.012));
            double hw = f.width() * 0.5 * open, hh = f.height() * 0.5 * open;
            rim(buffer, view, rel, w, h, hw, hh, GLOW, 1.0F, 0.42F, 0.04F, 0.7F);
            // смешивание сложением: ядро дважды — вдвое ярче
            rim(buffer, view, rel, w, h, hw, hh, CORE, 1.0F, 0.80F, 0.30F, 1.0F);
            rim(buffer, view, rel, w, h, hw, hh, CORE, 1.0F, 0.80F, 0.30F, 1.0F);
            any = true;
        }
        MeshData mesh = buffer.build();
        if (!any || mesh == null) {
            if (mesh != null) mesh.close();
            return;
        }
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        BufferUploader.drawWithShader(mesh);
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    /** Рамка — четыре полосы толщиной t по краю прямоугольника (половины hw × hh) в плоскости w-h. */
    private static void rim(BufferBuilder b, Matrix4f view, Vec3 c, Vec3 w, Vec3 h, double hw, double hh, float t,
                            float r, float g, float bl, float a) {
        double ow = hw + t * 0.5, oh = hh + t * 0.5, iw = hw - t * 0.5, ih = hh - t * 0.5;
        // верх и низ — во всю ширину, бока — между ними
        quad(b, view, c, w, h, -ow, ih, ow, oh, r, g, bl, a);
        quad(b, view, c, w, h, -ow, -oh, ow, -ih, r, g, bl, a);
        quad(b, view, c, w, h, -ow, -ih, -iw, ih, r, g, bl, a);
        quad(b, view, c, w, h, iw, -ih, ow, ih, r, g, bl, a);
    }

    private static void quad(BufferBuilder b, Matrix4f view, Vec3 c, Vec3 w, Vec3 h,
                             double x0, double y0, double x1, double y1, float r, float g, float bl, float a) {
        vertex(b, view, c, w, h, x0, y0, r, g, bl, a);
        vertex(b, view, c, w, h, x1, y0, r, g, bl, a);
        vertex(b, view, c, w, h, x1, y1, r, g, bl, a);
        vertex(b, view, c, w, h, x0, y1, r, g, bl, a);
    }

    private static void vertex(BufferBuilder b, Matrix4f view, Vec3 c, Vec3 w, Vec3 h, double x, double y,
                               float r, float g, float bl, float a) {
        Vec3 p = c.add(w.scale(x)).add(h.scale(y));
        b.addVertex(view, (float) p.x, (float) p.y, (float) p.z).setColor(r, g, bl, a);
    }
}
