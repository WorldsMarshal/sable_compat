package com.invfix.mysticportal;

import com.invfix.rick.portalgun.PortalMode;
import com.invfix.rick.portalgun.PortalPoint;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * Настройки Mystic Portal (меню на Shift + клавиша способности). На сервере —
 * в persistentData игрока, переживают смерть; клиенту приходят при входе.
 *
 *  - mode — режим связывания, те же пять, что у портальной пушки Рика;
 *  - passLimit — проходов на портал до закрытия, 0 — без лимита;
 *  - mode — также «Срез пространства» ({@link #MODE_SLICE}): пара сквозь стену, вход на поверхности,
 *    выход на её обратной стороне (не дальше {@link #SLICE_DEPTH} блоков);
 *  - size — сторона квадратной рамки, блоков; {@link #SIZE_TALL} — рамка 1×2 (1 в ширину, 2 в высоту);
 *  - range — дальность: блок ближе — портал на его грани, иначе в воздухе на этом расстоянии;
 *  - plane — плоскость выходного портала режима «Точка»: авто, горизонт лицом вверх / вниз, верт. X / Z
 *    (сторона — сама), стоячая лицом точно на восток / запад / юг / север;
 *  - entry — плоскость входного портала: авто (грань блока или угол взгляда), горизонт лицом
 *    вверх / вниз, стоячий лицом ко мне / от меня;
 *  - points / selected — пять точек и выбранная (режим «Точка»).
 */
public record MysticPortalSettings(String mode, int passLimit, int size, int range, int plane,
                                   List<PortalPoint> points, int selected, int entry) {

    public static final int MAX_POINTS = 5;
    public static final int MAX_PASSES = 16;
    public static final int MIN_SIZE = 1;
    public static final int MAX_SIZE = 5;
    /** Размер «1×2»: 1 блок в ширину, 2 в высоту. */
    public static final int SIZE_TALL = 0;
    /** Порядок размеров в меню. */
    private static final int[] SIZE_ORDER = {1, SIZE_TALL, 2, 3, 4, 5};
    /** Режим «Срез пространства» (своя строка: общие режимы пушки Рика — PortalMode). */
    public static final String MODE_SLICE = "slice";
    /** Насколько глубоко за поверхностью ищется обратная сторона стены, блоков. */
    public static final int SLICE_DEPTH = 60;
    public static final int MIN_RANGE = 1;
    public static final int MAX_RANGE = 60;

    /** Плоскость выхода режима «Точка». */
    public static final int PLANE_AUTO = 0;
    /** Горизонтальная, лицом вверх (раньше «горизонт.» — сохранённая 1 читается так). */
    public static final int PLANE_UP = 1;
    /** Вертикальная, вдоль оси X (смотрит на север/юг). */
    public static final int PLANE_VERTICAL_X = 2;
    /** Вертикальная, вдоль оси Z (смотрит на запад/восток). */
    public static final int PLANE_VERTICAL_Z = 3;
    /** Горизонтальная, лицом вниз. */
    public static final int PLANE_DOWN = 4;
    /** Стоячая, лицом точно на восток (+X): выходишь, идя на восток. */
    public static final int PLANE_EAST = 5;
    /** Стоячая, лицом на запад (−X). */
    public static final int PLANE_WEST = 6;
    /** Стоячая, лицом на юг (+Z). */
    public static final int PLANE_SOUTH = 7;
    /** Стоячая, лицом на север (−Z). */
    public static final int PLANE_NORTH = 8;
    public static final int PLANES = 9;
    /** Порядок плоскостей выхода в меню. */
    private static final int[] PLANE_ORDER = {PLANE_AUTO, PLANE_UP, PLANE_DOWN, PLANE_VERTICAL_X, PLANE_VERTICAL_Z,
            PLANE_EAST, PLANE_WEST, PLANE_SOUTH, PLANE_NORTH};

    /** Плоскость входа: авто — по грани блока или углу взгляда. */
    public static final int ENTRY_AUTO = 0;
    /** Горизонтальная, лицом вверх. */
    public static final int ENTRY_UP = 1;
    /** Горизонтальная, лицом вниз. */
    public static final int ENTRY_DOWN = 2;
    /** Стоячая, лицом ко мне. */
    public static final int ENTRY_TOWARD = 3;
    /** Стоячая, лицом от меня. */
    public static final int ENTRY_AWAY = 4;
    public static final int ENTRIES = 5;

    public static final MysticPortalSettings DEFAULT =
            new MysticPortalSettings(PortalMode.FIFO.id(), 0, 2, 30, PLANE_AUTO, List.of(), 0, ENTRY_AUTO).sanitized();

    static final String NBT = "invfix_mystic_portal";

    public static final Codec<MysticPortalSettings> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            Codec.STRING.optionalFieldOf("mode", PortalMode.FIFO.id()).forGetter(MysticPortalSettings::mode),
            Codec.INT.optionalFieldOf("pass_limit", 0).forGetter(MysticPortalSettings::passLimit),
            Codec.INT.optionalFieldOf("size", 2).forGetter(MysticPortalSettings::size),
            Codec.INT.optionalFieldOf("range", 30).forGetter(MysticPortalSettings::range),
            Codec.INT.optionalFieldOf("plane", PLANE_AUTO).forGetter(MysticPortalSettings::plane),
            PortalPoint.CODEC.listOf().optionalFieldOf("points", List.of()).forGetter(MysticPortalSettings::points),
            Codec.INT.optionalFieldOf("selected", 0).forGetter(MysticPortalSettings::selected),
            Codec.INT.optionalFieldOf("entry", ENTRY_AUTO).forGetter(MysticPortalSettings::entry)
    ).apply(inst, MysticPortalSettings::new));

    public static final StreamCodec<RegistryFriendlyByteBuf, MysticPortalSettings> STREAM_CODEC = StreamCodec.of(
            (buf, s) -> {
                buf.writeUtf(s.mode());
                buf.writeVarInt(s.passLimit());
                buf.writeVarInt(s.size());
                buf.writeVarInt(s.range());
                buf.writeVarInt(s.plane());
                PortalPoint.STREAM_CODEC.apply(ByteBufCodecs.list(MAX_POINTS)).encode(buf, s.points());
                buf.writeVarInt(s.selected());
                buf.writeVarInt(s.entry());
            },
            buf -> new MysticPortalSettings(buf.readUtf(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(),
                    buf.readVarInt(), PortalPoint.STREAM_CODEC.apply(ByteBufCodecs.list(MAX_POINTS)).decode(buf),
                    buf.readVarInt(), buf.readVarInt()).sanitized());

    /** Все поля в границах, точек ровно MAX_POINTS. */
    public MysticPortalSettings sanitized() {
        List<PortalPoint> list = new ArrayList<>(MAX_POINTS);
        for (int i = 0; i < MAX_POINTS; i++) {
            list.add(points != null && i < points.size() ? points.get(i) : PortalPoint.EMPTY);
        }
        return new MysticPortalSettings(
                MODE_SLICE.equals(mode) ? MODE_SLICE : PortalMode.byId(mode).id(),
                Math.max(0, Math.min(passLimit, MAX_PASSES)),
                Math.max(SIZE_TALL, Math.min(size, MAX_SIZE)),
                Math.max(MIN_RANGE, Math.min(range, MAX_RANGE)),
                Math.floorMod(plane, PLANES),
                List.copyOf(list),
                Math.max(0, Math.min(selected, MAX_POINTS - 1)),
                Math.floorMod(entry, ENTRIES));
    }

    /** Режим связывания; у «Среза» его нет (там всегда одна пара) — FIFO для порядка. */
    public PortalMode portalMode() {
        return PortalMode.byId(mode);
    }

    public boolean slice() {
        return MODE_SLICE.equals(mode);
    }

    /** Ширина рамки, блоков. */
    public static int width(int size) {
        return size == SIZE_TALL ? 1 : size;
    }

    /** Высота рамки, блоков. */
    public static int height(int size) {
        return size == SIZE_TALL ? 2 : size;
    }

    public int width() {
        return width(size);
    }

    public int height() {
        return height(size);
    }

    public static String sizeLabel(int size) {
        return width(size) + "×" + height(size);
    }

    /** Следующий (delta = 1) или предыдущий (delta = -1) размер по кругу, в порядке меню. */
    public static int stepSize(int size, int delta) {
        int at = 0;
        for (int i = 0; i < SIZE_ORDER.length; i++) if (SIZE_ORDER[i] == size) at = i;
        return SIZE_ORDER[Math.floorMod(at + delta, SIZE_ORDER.length)];
    }

    /** Следующая (delta = 1) или предыдущая плоскость выхода, в порядке меню. */
    public static int stepPlane(int plane, int delta) {
        int at = 0;
        for (int i = 0; i < PLANE_ORDER.length; i++) if (PLANE_ORDER[i] == plane) at = i;
        return PLANE_ORDER[Math.floorMod(at + delta, PLANE_ORDER.length)];
    }

    public static String planeName(int plane) {
        return switch (plane) {
            case PLANE_UP -> "Горизонт ↑";
            case PLANE_DOWN -> "Горизонт ↓";
            case PLANE_VERTICAL_X -> "Верт. X";
            case PLANE_VERTICAL_Z -> "Верт. Z";
            case PLANE_EAST -> "Восток X+";
            case PLANE_WEST -> "Запад X−";
            case PLANE_SOUTH -> "Юг Z+";
            case PLANE_NORTH -> "Север Z−";
            default -> "Авто";
        };
    }

    public static String entryName(int entry) {
        return switch (entry) {
            case ENTRY_UP -> "Горизонт ↑";
            case ENTRY_DOWN -> "Горизонт ↓";
            case ENTRY_TOWARD -> "Ко мне";
            case ENTRY_AWAY -> "От меня";
            default -> "Авто";
        };
    }

    public PortalPoint point() {
        return selected >= 0 && selected < points.size() ? points.get(selected) : PortalPoint.EMPTY;
    }

    public static MysticPortalSettings of(Player player) {
        CompoundTag data = player.getPersistentData();
        if (!data.contains(NBT)) return DEFAULT;
        return CODEC.parse(NbtOps.INSTANCE, data.getCompound(NBT)).result().orElse(DEFAULT).sanitized();
    }

    void save(Player player) {
        Tag tag = CODEC.encodeStart(NbtOps.INSTANCE, sanitized()).result().orElse(null);
        if (tag != null) player.getPersistentData().put(NBT, tag);
    }
}
