package com.invfix.mysticportal;

import com.invfix.rick.portalgun.PortalMode;
import com.invfix.rick.portalgun.PortalPoint;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * Настройки Mystic Portal (меню на Shift + клавиша способности). На сервере —
 * в persistentData игрока, переживают смерть; клиенту приходят при входе.
 *
 *  - mode — режим связывания, те же пять, что у портальной пушки Рика;
 *  - passLimit — проходов на портал до закрытия, 0 — без лимита;
 *  - size — сторона квадратной рамки, блоков;
 *  - range — дальность: блок ближе — портал на его грани, иначе в воздухе на этом расстоянии;
 *  - plane — плоскость выходного портала режима «Точка»;
 *  - points / selected — пять точек и выбранная (режим «Точка»).
 */
public record MysticPortalSettings(String mode, int passLimit, int size, int range, int plane,
                                   List<PortalPoint> points, int selected) {

    public static final int MAX_POINTS = 5;
    public static final int MAX_PASSES = 16;
    public static final int MIN_SIZE = 1;
    public static final int MAX_SIZE = 5;
    public static final int MIN_RANGE = 1;
    public static final int MAX_RANGE = 60;

    /** Плоскость выхода режима «Точка». */
    public static final int PLANE_AUTO = 0;
    public static final int PLANE_HORIZONTAL = 1;
    /** Вертикальная, вдоль оси X (смотрит на север/юг). */
    public static final int PLANE_VERTICAL_X = 2;
    /** Вертикальная, вдоль оси Z (смотрит на запад/восток). */
    public static final int PLANE_VERTICAL_Z = 3;
    public static final int PLANES = 4;

    public static final MysticPortalSettings DEFAULT =
            new MysticPortalSettings(PortalMode.FIFO.id(), 0, 2, 30, PLANE_AUTO, List.of(), 0).sanitized();

    static final String NBT = "invfix_mystic_portal";

    public static final Codec<MysticPortalSettings> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            Codec.STRING.optionalFieldOf("mode", PortalMode.FIFO.id()).forGetter(MysticPortalSettings::mode),
            Codec.INT.optionalFieldOf("pass_limit", 0).forGetter(MysticPortalSettings::passLimit),
            Codec.INT.optionalFieldOf("size", 2).forGetter(MysticPortalSettings::size),
            Codec.INT.optionalFieldOf("range", 30).forGetter(MysticPortalSettings::range),
            Codec.INT.optionalFieldOf("plane", PLANE_AUTO).forGetter(MysticPortalSettings::plane),
            PortalPoint.CODEC.listOf().optionalFieldOf("points", List.of()).forGetter(MysticPortalSettings::points),
            Codec.INT.optionalFieldOf("selected", 0).forGetter(MysticPortalSettings::selected)
    ).apply(inst, MysticPortalSettings::new));

    public static final StreamCodec<RegistryFriendlyByteBuf, MysticPortalSettings> STREAM_CODEC = StreamCodec.of(
            (buf, s) -> {
                buf.writeUtf(s.mode());
                buf.writeVarInt(s.passLimit());
                buf.writeVarInt(s.size());
                buf.writeVarInt(s.range());
                buf.writeVarInt(s.plane());
                PortalPoint.STREAM_CODEC.apply(ByteBufCodecs.list(MAX_POINTS)).encode(buf, s.points());
                buf.writeVarInt(s.selected());
            },
            buf -> new MysticPortalSettings(buf.readUtf(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(),
                    buf.readVarInt(), PortalPoint.STREAM_CODEC.apply(ByteBufCodecs.list(MAX_POINTS)).decode(buf),
                    buf.readVarInt()).sanitized());

    /** Все поля в границах, точек ровно MAX_POINTS. */
    public MysticPortalSettings sanitized() {
        List<PortalPoint> list = new ArrayList<>(MAX_POINTS);
        for (int i = 0; i < MAX_POINTS; i++) {
            list.add(points != null && i < points.size() ? points.get(i) : PortalPoint.EMPTY);
        }
        return new MysticPortalSettings(
                PortalMode.byId(mode).id(),
                Math.max(0, Math.min(passLimit, MAX_PASSES)),
                Math.max(MIN_SIZE, Math.min(size, MAX_SIZE)),
                Math.max(MIN_RANGE, Math.min(range, MAX_RANGE)),
                Math.floorMod(plane, PLANES),
                List.copyOf(list),
                Math.max(0, Math.min(selected, MAX_POINTS - 1)));
    }

    public PortalMode portalMode() {
        return PortalMode.byId(mode);
    }

    public PortalPoint point() {
        return selected >= 0 && selected < points.size() ? points.get(selected) : PortalPoint.EMPTY;
    }

    public static MysticPortalSettings of(Player player) {
        CompoundTag data = player.getPersistentData();
        if (!data.contains(NBT)) return DEFAULT;
        return CODEC.parse(NbtOps.INSTANCE, data.getCompound(NBT)).result().orElse(DEFAULT).sanitized();
    }

    void save(Player player) {
        Tag tag = CODEC.encodeStart(NbtOps.INSTANCE, sanitized()).result().orElse(null);
        if (tag != null) player.getPersistentData().put(NBT, tag);
    }
}
