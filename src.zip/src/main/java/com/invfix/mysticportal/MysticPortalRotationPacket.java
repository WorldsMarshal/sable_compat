package com.invfix.mysticportal;

import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Сервер → клиент: угол и скорость сущности сразу после перехода через Mystic
 * Portal. Ядро IP клиенту шлёт только новую позицию (RemoteCallables#updateEntityPos);
 * без этого снаряд у клиента летит со старым углом и старой скоростью до
 * следующего пакета движения. Ставится без интерполяции (и прошлый тик тоже).
 */
public record MysticPortalRotationPacket(int entityId, float yRot, float xRot, double vx, double vy, double vz)
        implements CustomPacketPayload {

    public static final Type<MysticPortalRotationPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "mystic_portal_rotation"));

    public static final StreamCodec<FriendlyByteBuf, MysticPortalRotationPacket> STREAM_CODEC = StreamCodec.of(
            (buf, m) -> {
                buf.writeVarInt(m.entityId());
                buf.writeFloat(m.yRot());
                buf.writeFloat(m.xRot());
                buf.writeDouble(m.vx());
                buf.writeDouble(m.vy());
                buf.writeDouble(m.vz());
            },
            buf -> new MysticPortalRotationPacket(buf.readVarInt(), buf.readFloat(), buf.readFloat(),
                    buf.readDouble(), buf.readDouble(), buf.readDouble()));

    @Override public Type<MysticPortalRotationPacket> type() { return TYPE; }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(MysticPortalRotationPacket p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) return;
            Entity e = mc.level.getEntity(p.entityId());
            if (e == null || e == mc.player) return;
            MysticPortalHandler.applyRotation(e, p.yRot(), p.xRot());
            e.setDeltaMovement(new Vec3(p.vx(), p.vy(), p.vz()));
        });
    }
}
