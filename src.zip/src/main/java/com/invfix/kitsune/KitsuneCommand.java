package com.invfix.kitsune;

import com.invfix.util.DebugUtils;
import com.mojang.brigadier.Command;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.procedures.ClearAbilitiesProcedure;
import net.mcreator.invincibleinc.procedures.ClearPassiveProcedure;
import net.mcreator.invincibleinc.procedures.FullResetProcedure;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * /wtf kitsune — делает расой Kitsune того, кто вызвал. Цели нет: только себя.
 * Доступна только владельцу расы ({@link DebugUtils#KITSUNE_OWNER}) и только с
 * правами оператора; остальным команда не видна.
 *
 * Как /altrumite: ставит расу, чистит способности и пассивки, полный сброс
 * прогресса (FullReset заново бросает родословную — DebugUtils оставляет
 * владельцу Kitsune и Rick).
 */
@EventBusSubscriber(modid = "sable_compat")
public final class KitsuneCommand {

    private KitsuneCommand() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("wtf")
                        .requires(KitsuneCommand::allowed)
                        .then(Commands.literal("kitsune")
                                .requires(KitsuneCommand::allowed)
                                .executes(ctx -> {
                                    if (!(ctx.getSource().getEntity() instanceof ServerPlayer player)) return 0;
                                    apply(player);
                                    ctx.getSource().sendSuccess(
                                            () -> Component.literal("§eРаса установлена: Kitsune"), false);
                                    return Command.SINGLE_SUCCESS;
                                })));
    }

    private static boolean allowed(CommandSourceStack source) {
        return source.hasPermission(2)
                && source.getEntity() instanceof ServerPlayer player
                && DebugUtils.KITSUNE_OWNER.equals(player.getGameProfile().getName());
    }

    public static void apply(ServerPlayer player) {
        InvincibleIncModVariables.PlayerVariables vars =
                player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        vars.Race = KitsuneRace.RACE;
        vars.Power = KitsuneRace.POWER;
        vars.racePower = KitsuneRace.POWER;
        vars.RaceStatMultiplier = KitsuneRace.RACE_STAT_MULTIPLIER;
        vars.markSyncDirty();

        try { ClearAbilitiesProcedure.execute(player); } catch (Exception ignored) {}
        try { ClearPassiveProcedure.execute(player); } catch (Exception ignored) {}
        try { FullResetProcedure.execute(player.level(), player); } catch (Exception ignored) {}
    }
}
