package com.invfix.kitsune;

import com.invfix.altrumite.AltrumiteRace;

/**
 * Раса Kitsune — dev-раса. В рандомайзер рас не входит: выдаётся только через
 * DebugUtils (HoustonWTF) и командой /wtf kitsune.
 *
 * Расовые показатели те же, что у Alien(Metroman): резисты, капы уровня, КПД
 * щита, множитель статов, сила, полёт, пассивки, способности Metroman. Отличия:
 *  - прокачка в {@link #XP_FACTOR} раза быстрее Metroman (бой и тренировки);
 *  - только у Kitsune — dev-способности (Heat Disruption, Dismantle, Energy
 *    Blast, The Whole Sentry Power, Space Fold, Mystic Portal, Prism Ward,
 *    Six Eyes, Shapeshifter и Morph Ability). Новые способности добавляются сюда же.
 */
public final class KitsuneRace {
    private KitsuneRace() {}

    /** Строка расы (§e — жёлтый). */
    public static final String RACE  = "§e§lKitsune";
    /** Строка Power-набора. */
    public static final String POWER = "§e§lKitsune";

    /** Коэффициент статов — как у Metroman. */
    public static final double RACE_STAT_MULTIPLIER = AltrumiteRace.RACE_STAT_MULTIPLIER;

    /** Во сколько раз Kitsune качается быстрее Metroman. */
    public static final double XP_FACTOR = 3.0;

    public static boolean isKitsune(String race) {
        return RACE.equals(race);
    }
}
