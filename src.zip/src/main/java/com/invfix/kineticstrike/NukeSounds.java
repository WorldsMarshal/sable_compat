package com.invfix.kineticstrike;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Звук ядерного взрыва Kinetic Strike. .ogg-файл лежит в
 *   assets/sable_compat/sounds/nuclear_boom.ogg
 * и описан в assets/sable_compat/sounds.json (ключ "nuclear_boom").
 *
 * ВАЖНО: в конструкторе InvincibleFix нужно вызвать:
 *     NukeSounds.SOUNDS.register(modEventBus);
 */
public final class NukeSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, "sable_compat");

    public static final DeferredHolder<SoundEvent, SoundEvent> NUCLEAR_BOOM = SOUNDS.register(
            "nuclear_boom",
            () -> SoundEvent.createVariableRangeEvent(
                    ResourceLocation.fromNamespaceAndPath("sable_compat", "nuclear_boom")));

    private NukeSounds() {}
}