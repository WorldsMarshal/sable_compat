package com.invfix.kineticstrike;

import com.invfix.kineticstrike.client.KineticStrikeClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Сервер → Клиент: игрок X начал/закончил Kinetic Strike рывок (для конуса нагрева ×3). */
public record KineticStrikeStatePacket(int entityId, boolean active) implements CustomPacketPayload {

    public static final Type<KineticStrikeStatePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "ks_state"));

    public static final StreamCodec<FriendlyByteBuf, KineticStrikeStatePacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, m) -> { buf.writeVarInt(m.entityId()); buf.writeBoolean(m.active()); },
                    buf -> new KineticStrikeStatePacket(buf.readVarInt(), buf.readBoolean()));

    @Override public Type<KineticStrikeStatePacket> type() { return TYPE; }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(KineticStrikeStatePacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> KineticStrikeClient.setDashing(pkt.entityId(), pkt.active()));
    }
}