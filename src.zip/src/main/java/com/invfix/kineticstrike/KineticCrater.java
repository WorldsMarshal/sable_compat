package com.invfix.kineticstrike;

import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ThreadedLevelLightEngine;
import net.minecraft.server.level.TicketType;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.PalettedContainer;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;

/**
 * Кратер Kinetic Strike — разрушение Gungnir из The Shooting Star 1.2.0
 * (star/Gungnir.java: floor, fissure, scorched, rim; star/Carving.java: flatten,
 * cut, relight), без иглы-шпиля Gungnir.
 *
 * Не лучи: у каждой колонки x,z считается высота дна, и всё выше него
 * вырезается прямо в секциях чанка — секция целиком над дном просто
 * заменяется пустой; потом пересвет и свежий пакет чанка игрокам. Поэтому в
 * сотни раз быстрее BMNW-лучей и чанки обновляются сразу.
 *
 * Форма (масштаб {@link #scale} = радиус / 400, как у Gungnir с радиусом 400):
 *  - вся зона до неровного края (три синусоиды по углу) срезана и вдавлена на
 *    DRIVEN к центру, у края — подъём-вал шириной RAMP;
 *  - в середине чаша CRATER_R глубиной CRATER_DEPTH;
 *  - 14 извилистых трещин-лучей от чаши почти до края, глубиной FISSURE_DEPTH;
 *  - дно выжжено: в центре магма, обсидиан, чернокамень; в чаше — чернокамень,
 *    базальт, магма, обсидиан, глубинный булыжник; дальше — каменистая
 *    земля, гравий, туф; в трещинах — магма и чернокамень.
 *
 * Идёт фронтом от центра — по той же кривой, что ударная волна Gungnir
 * ({@link #front}: до края за 36 тиков). Колонки чанков — не больше
 * {@link #CHUNKS_PER_TICK} за тик. Непрогруженные чанки не грузятся
 * синхронно: на время работы ставится тикет на всю зону, а такие чанки
 * режутся, как только догрузятся.
 *
 * Отличие от Gungnir: бедрок не трогается (Carving снёс бы и потолок Незера).
 */
final class KineticCrater {

    // Gungnir при scale = 1
    static final double BASE_RADIUS = 400.0;
    private static final double CRATER_R = 88.0;
    private static final double CRATER_DEPTH = 108.0;
    private static final double DRIVEN = 20.0;
    private static final int FISSURES = 14;
    private static final double FISSURE_DEPTH = 7.0;
    private static final double RAMP = 36.0;
    /** Фронт доходит до края за столько тиков (Gungnir.SWEEP). */
    static final double SWEEP = 36.0;

    private static final int CHUNKS_PER_TICK = 36;
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final TicketType<ChunkPos> TICKET =
            TicketType.create("sable_compat:kinetic_crater", Comparator.comparingLong(ChunkPos::toLong));

    final ServerLevel level;
    private final Vec3 target;
    private final long seed;
    final int ground;
    private final double scale;
    private final double radius;
    private final double craterR;
    private final double craterDepth;
    private final double driven;
    private final double fissureDepth;
    private final double ramp;
    private final double[] rimPhase = new double[3];

    private final List<ChunkPos> chunks = new ArrayList<>();
    private final List<Double> reach = new ArrayList<>();
    private final List<Integer> waiting = new ArrayList<>();
    private int next;
    private int age;
    private final ChunkPos ticketAt;
    private final int ticketRadius;
    private boolean ticketHeld;

    /**
     * @param radius радиус зоны (Gungnir — 400), блоков
     * @param ground высота земли в точке удара (y верхнего блока)
     */
    KineticCrater(ServerLevel level, Vec3 target, double radius, int ground, long seed) {
        this.level = level;
        this.target = target;
        this.seed = seed;
        this.ground = ground;
        this.scale = radius / BASE_RADIUS;
        this.radius = radius;
        this.craterR = CRATER_R * scale;
        this.craterDepth = CRATER_DEPTH * scale;
        this.driven = DRIVEN * scale;
        this.fissureDepth = FISSURE_DEPTH * Math.max(scale, 0.5);
        this.ramp = RAMP * scale;
        for (int i = 0; i < rimPhase.length; i++) {
            rimPhase[i] = Math.floorMod(seed >> (i * 11), 6283L) / 1000.0;
        }

        // колонки чанков зоны (край с запасом +12, как у Gungnir), от центра наружу
        double zone = radius + 12.0;
        int c0x = SectionPos.blockToSectionCoord(target.x - zone);
        int c1x = SectionPos.blockToSectionCoord(target.x + zone);
        int c0z = SectionPos.blockToSectionCoord(target.z - zone);
        int c1z = SectionPos.blockToSectionCoord(target.z + zone);
        List<double[]> found = new ArrayList<>();
        for (int x = c0x; x <= c1x; x++) {
            for (int z = c0z; z <= c1z; z++) {
                double nx = Math.max(x * 16.0, Math.min(target.x, x * 16.0 + 16.0)) - target.x;
                double nz = Math.max(z * 16.0, Math.min(target.z, z * 16.0 + 16.0)) - target.z;
                double near = Math.sqrt(nx * nx + nz * nz);
                if (near <= zone) found.add(new double[]{x, z, near});
            }
        }
        found.sort(Comparator.comparingDouble(a -> a[2]));
        for (double[] f : found) {
            chunks.add(new ChunkPos((int) f[0], (int) f[1]));
            reach.add(f[2]);
        }

        this.ticketAt = new ChunkPos(BlockPos.containing(target));
        this.ticketRadius = (int) Math.ceil((zone + 16.0) / 16.0);
        level.getChunkSource().addRegionTicket(TICKET, ticketAt, ticketRadius, ticketAt);
        this.ticketHeld = true;
    }

    /** Где фронт через t тиков после удара (Gungnir.front: до края за SWEEP тиков). */
    static double front(double t, double radius) {
        return t <= 0.0 ? 0.0 : radius * Math.pow(t / SWEEP, 0.6);
    }

    boolean done() {
        return next >= chunks.size() && waiting.isEmpty();
    }

    /** Тик: режет колонки, до которых дошёл фронт. */
    void tick() {
        double front = Math.min(front(++age, radius), radius + 12.0);
        int budget = CHUNKS_PER_TICK;
        Iterator<Integer> it = waiting.iterator();
        while (it.hasNext() && budget > 0) {
            ChunkPos pos = chunks.get(it.next());
            LevelChunk chunk = level.getChunkSource().getChunkNow(pos.x, pos.z);
            if (chunk != null) {
                cut(chunk);
                it.remove();
                budget--;
            }
        }
        for (; budget > 0 && next < chunks.size() && reach.get(next) <= front; next++) {
            ChunkPos pos = chunks.get(next);
            LevelChunk chunk = level.getChunkSource().getChunkNow(pos.x, pos.z);
            if (chunk == null) {
                waiting.add(next);
            } else {
                cut(chunk);
                budget--;
            }
        }
        // ждём недогруженные не дольше 30 с — дальше бросаем, чтобы тикет не висел вечно
        if (done() || age > 600) release();
    }

    boolean finished() {
        return !ticketHeld;
    }

    void release() {
        if (ticketHeld) {
            ticketHeld = false;
            waiting.clear();
            next = chunks.size();
            level.getChunkSource().removeRegionTicket(TICKET, ticketAt, ticketRadius, ticketAt);
        }
    }

    // ── форма (Gungnir) ────────────────────────────────────────────────────

    private double rim(double angle) {
        return radius + scale * (6.0 * Math.sin(3.0 * angle + rimPhase[0]) + 4.0 * Math.sin(7.0 * angle + rimPhase[1])
                + 2.4 * Math.sin(13.0 * angle + rimPhase[2]));
    }

    /** Высота дна колонки; Integer.MIN_VALUE — колонка вне кратера. */
    private int floor(int x, int z) {
        double dx = x + 0.5 - target.x;
        double dz = z + 0.5 - target.z;
        double d = Math.sqrt(dx * dx + dz * dz);
        double edge = rim(Math.atan2(dz, dx));
        if (d > edge) return Integer.MIN_VALUE;
        double y = ground;
        double inner = Math.max(edge - ramp, craterR + 1.0);
        double k = Math.min(d / inner, 1.0);
        y -= driven * (1.0 - Math.pow(k, 1.6));
        y -= fissure(dx, dz, d) * fissureDepth;
        if (d < craterR) {
            double r = d / craterR;
            y -= craterDepth * (1.0 - r * r) * (1.0 - r * r * 0.35);
        }
        double rise = d - (edge - ramp);
        if (rise > 0.0) y += rise * rise / ramp * 1.1;
        return Math.max(Mth.floor(y), level.getMinBuildHeight() + 2);
    }

    private double fissure(double dx, double dz, double d) {
        if (d < craterR * 0.8 || d > radius * 0.92) return 0.0;
        double a = Math.atan2(dz, dx);
        double best = 0.0;
        for (int i = 0; i < FISSURES; i++) {
            double ai = (double) i / FISSURES * Math.PI * 2.0 + rimPhase[i % rimPhase.length] * 0.3;
            double wander = Math.sin(d / scale * 0.03 + i * 1.7) * 0.05 + Math.sin(d / scale * 0.011 + i) * 0.04;
            double off = Math.abs(Math.IEEEremainder(a - ai - wander, Math.PI * 2.0)) * d;
            double w = 3.2 * Math.max(scale, 0.5) * (1.0 - d / radius * 0.7);
            if (off < w) best = Math.max(best, 1.0 - off / w);
        }
        return best;
    }

    /** Чем выжжено дно (null — оставить как есть). */
    private BlockState scorched(int x, int z, BlockState was) {
        if (!was.getFluidState().isEmpty() || was.is(Blocks.BEDROCK)) return null;
        double d = Math.hypot(x + 0.5 - target.x, z + 0.5 - target.z);
        double f = fissure(x + 0.5 - target.x, z + 0.5 - target.z, d);
        if (f > 0.35) {
            return f > 0.7 ? Blocks.MAGMA_BLOCK.defaultBlockState()
                    : hash(x * 3, z * 5) < 0.5 ? Blocks.BLACKSTONE.defaultBlockState() : Blocks.MAGMA_BLOCK.defaultBlockState();
        }
        double roll = hash(x, z);
        double jitter = (hash(z * 7 + 3, x * 13 - 5) - 0.5) * 24.0 * scale;
        double r = (d + jitter) * (200.0 / radius);
        if (r < 10.0) {
            return roll < 0.5 ? Blocks.MAGMA_BLOCK.defaultBlockState()
                    : roll < 0.8 ? Blocks.OBSIDIAN.defaultBlockState() : Blocks.BLACKSTONE.defaultBlockState();
        } else if (r < craterR * 200.0 / radius) {
            return roll < 0.34 ? Blocks.BLACKSTONE.defaultBlockState()
                    : roll < 0.58 ? Blocks.BASALT.defaultBlockState()
                    : roll < 0.7 ? Blocks.MAGMA_BLOCK.defaultBlockState()
                    : roll < 0.8 ? Blocks.OBSIDIAN.defaultBlockState() : Blocks.COBBLED_DEEPSLATE.defaultBlockState();
        } else if (r < 100.0) {
            return roll < 0.3 ? Blocks.COARSE_DIRT.defaultBlockState()
                    : roll < 0.45 ? Blocks.BLACKSTONE.defaultBlockState()
                    : roll < 0.65 ? Blocks.GRAVEL.defaultBlockState()
                    : roll < 0.73 ? Blocks.BASALT.defaultBlockState()
                    : roll < 0.86 ? Blocks.TUFF.defaultBlockState()
                    : roll < 0.88 ? Blocks.MAGMA_BLOCK.defaultBlockState() : Blocks.COBBLED_DEEPSLATE.defaultBlockState();
        } else if (r < 170.0) {
            return roll < 0.35 ? Blocks.COARSE_DIRT.defaultBlockState()
                    : roll < 0.5 ? Blocks.GRAVEL.defaultBlockState()
                    : roll < 0.7 ? Blocks.DIRT.defaultBlockState() : null;
        } else {
            return roll < 0.4 ? Blocks.COARSE_DIRT.defaultBlockState() : null;
        }
    }

    private double hash(int x, int z) {
        long h = seed ^ (long) x * -7046029254386353131L ^ (long) z * -4417276706812531889L;
        h = (h ^ h >>> 31) * -4658895280553007687L;
        h ^= h >>> 29;
        return (double) (h >>> 11) / 9.007199254740992E15;
    }

    // ── вырезание (Carving.cut) ────────────────────────────────────────────

    private void cut(LevelChunk chunk) {
        ChunkPos pos = chunk.getPos();
        int[] floor = new int[256];
        int count = 0;
        int highest = Integer.MIN_VALUE;
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int f = floor(pos.getMinBlockX() + lx, pos.getMinBlockZ() + lz);
                floor[lx * 16 + lz] = f;
                if (f != Integer.MIN_VALUE) {
                    count++;
                    highest = Math.max(highest, f);
                }
            }
        }
        if (count == 0) return;

        ThreadedLevelLightEngine light = level.getChunkSource().getLightEngine();
        LevelChunkSection[] sections = chunk.getSections();
        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection section = sections[i];
            if (section.hasOnlyAir()) continue;
            int base = SectionPos.sectionToBlockCoord(level.getSectionYFromSectionIndex(i));
            if (count == 256 && base > highest && !section.maybeHas(s -> s.is(Blocks.BEDROCK))) {
                // вся секция над дном — заменить пустой
                sections[i] = new LevelChunkSection(
                        new PalettedContainer<>(Block.BLOCK_STATE_REGISTRY, AIR, PalettedContainer.Strategy.SECTION_STATES),
                        section.getBiomes());
            } else {
                boolean changed = false;
                for (int lx = 0; lx < 16; lx++) {
                    for (int lz = 0; lz < 16; lz++) {
                        int f = floor[lx * 16 + lz];
                        if (f == Integer.MIN_VALUE || f >= base + 15) continue;
                        for (int ly = Math.max(0, f - base + 1); ly < 16; ly++) {
                            BlockState was = section.getBlockState(lx, ly, lz);
                            if (was.isAir() || was.is(Blocks.BEDROCK)) continue;
                            section.setBlockState(lx, ly, lz, AIR, false);
                            changed = true;
                        }
                    }
                }
                if (!changed) continue;
            }
            light.updateSectionStatus(SectionPos.of(pos, level.getSectionYFromSectionIndex(i)), sections[i].hasOnlyAir());
        }

        // дно — выжженное
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int f = floor[lx * 16 + lz];
                if (f == Integer.MIN_VALUE || f < level.getMinBuildHeight() || f > level.getMaxBuildHeight() - 1) continue;
                LevelChunkSection section = sections[chunk.getSectionIndex(f)];
                if (section.hasOnlyAir()) continue;
                BlockState was = section.getBlockState(lx, f & 15, lz);
                BlockState now = was.isAir() ? null : scorched(pos.getMinBlockX() + lx, pos.getMinBlockZ() + lz, was);
                if (now != null && now != was) section.setBlockState(lx, f & 15, lz, now, false);
            }
        }

        for (BlockPos at : new ArrayList<>(chunk.getBlockEntitiesPos())) {
            int f = floor(at.getX(), at.getZ());
            if (f != Integer.MIN_VALUE && at.getY() > f && !chunk.getBlockState(at).is(Blocks.BEDROCK)) {
                chunk.removeBlockEntity(at);
            }
        }
        relight(chunk);
    }

    /** Как Carving.relight: карты высот, свет, свежий чанк игрокам. */
    private void relight(LevelChunk chunk) {
        ChunkPos pos = chunk.getPos();
        ThreadedLevelLightEngine light = level.getChunkSource().getLightEngine();
        Heightmap.primeHeightmaps(chunk, EnumSet.allOf(Heightmap.Types.class));
        chunk.initializeLightSources();
        light.propagateLightSources(pos);
        chunk.setUnsaved(true);
        ClientboundLevelChunkWithLightPacket packet =
                new ClientboundLevelChunkWithLightPacket(chunk, light, (BitSet) null, (BitSet) null);
        for (ServerPlayer player : level.getChunkSource().chunkMap.getPlayers(pos, false)) {
            player.connection.send(packet);
        }
    }

    /** Высота земли под точкой удара: если удар в воздухе — поверхность под ним (не ниже 48 блоков). */
    static int groundAt(ServerLevel level, Vec3 at) {
        int y = Mth.floor(at.y) - 1;
        int surface = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(at.x), Mth.floor(at.z)) - 1;
        if (surface < y && y - surface <= 48) y = surface;
        return y;
    }
}
