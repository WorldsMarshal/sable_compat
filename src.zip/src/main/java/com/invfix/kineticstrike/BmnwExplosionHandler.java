package com.invfix.kineticstrike;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.*;

/**
 * Точный порт лучевого ядерного взрыва из BMNW (PlagiarizedExplosionHandlerBatched,
 * он же Hbm-style NTM nuke), без NBT-персистентности (взрыв транзиентный).
 *
 * Алгоритм:
 *  1) генерируем gspNumMax = 7.85 * strength² лучей, равномерно по сфере (golden-spiral);
 *  2) каждый луч марширует наружу до length, вычитая сопротивление блоков
 *     (res -= resistance^(7.5-fac)); собираем затронутые чанки и «кончик» луча;
 *  3) по-чанково перемаршируем лучи и сносим блоки в AIR.
 *
 * Фаза сбора (cacheChunksTick) батчами по speed*10 лучей/тик, фаза разрушения
 * (destructionTick) по времени (msBudget). Чанки вне прогрузки пропускаются
 * (в отличие от оригинала, который force-загружает — иначе фриз на радиусе 512).
 */
public class BmnwExplosionHandler {

    private final Map<ChunkPos, List<Vector3f>> perChunk = new HashMap<>();
    private final List<ChunkPos> orderedChunks = new ArrayList<>();
    private final int posX, posY, posZ;
    public final ServerLevel level;
    private final float strength;
    private final int length;
    private final int speed;
    private final int gspNumMax;
    private int gspNum;
    private double gspX, gspY;
    public boolean collectionComplete = false;

    public BmnwExplosionHandler(ServerLevel level, int x, int y, int z, float strength, int speed, int length) {
        this.level = level;
        this.posX = x; this.posY = y; this.posZ = z;
        this.strength = strength;
        this.speed = speed;
        this.length = length;
        this.gspNumMax = (int) (7.853981633974483 * Math.pow(strength, 2.0));
        this.gspNum = 1;
        this.gspX = Math.PI;
        this.gspY = 0.0;
    }

    private void generateGspUp() {
        if (this.gspNum < this.gspNumMax) {
            int k = this.gspNum + 1;
            double hk = -1.0 + 2.0 * ((double) k - 1.0) / ((double) this.gspNumMax - 1.0);
            this.gspX = Math.acos(hk);
            double lon = this.gspY + 3.6 / Math.sqrt(this.gspNumMax) / Math.sqrt(1.0 - hk * hk);
            this.gspY = lon % 6.283185307179586;
        } else {
            this.gspX = 0.0;
            this.gspY = 0.0;
        }
        ++this.gspNum;
    }

    private Vec3 spherical2cartesian() {
        double dx = Math.sin(this.gspX) * Math.cos(this.gspY);
        double dz = Math.sin(this.gspX) * Math.sin(this.gspY);
        double dy = Math.cos(this.gspX);
        return new Vec3(dx, dy, dz);
    }

    public static float getResistance(Block block) {
        return block == Blocks.OBSIDIAN
                ? Blocks.STONE.getExplosionResistance() * 3.0F
                : block.getExplosionResistance();
    }

    public void collectTip(int count) {
        BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();
        int processed = 0;
        do {
            if (this.gspNumMax < this.gspNum) {
                this.orderedChunks.addAll(this.perChunk.keySet());
                this.orderedChunks.sort(this::compareChunks);
                this.collectionComplete = true;
                return;
            }
            Vec3 vec = spherical2cartesian();
            float res = this.strength;
            Vector3f lastPos = null;
            HashSet<ChunkPos> chunkCoords = new HashSet<>();

            for (int i = 0; (float) i < this.strength && i <= this.length; ++i) {
                float x0 = (float) (this.posX + vec.x * i);
                float y0 = (float) (this.posY + vec.y * i);
                float z0 = (float) (this.posZ + vec.z * i);
                int iX = Mth.floor(x0), iY = Mth.floor(y0), iZ = Mth.floor(z0);

                if (!this.level.isLoaded(mutable.set(iX, iY, iZ))) break; // вне прогрузки — стоп

                double fac = (100.0 - (double) i / (double) this.length * 100.0) * 0.07;
                Block block = this.level.getBlockState(mutable).getBlock();
                if (!(block instanceof LiquidBlock)) {
                    res -= (float) Math.pow(getResistance(block), 7.5 - fac);
                }
                if (res > 0.0F && block != Blocks.AIR) {
                    lastPos = new Vector3f(x0, y0, z0);
                    chunkCoords.add(new ChunkPos(iX >> 4, iZ >> 4));
                }
                if (res <= 0.0F || i + 1 >= this.length || (float) i == this.strength - 1.0F) break;
            }

            if (lastPos != null) {
                for (ChunkPos pos : chunkCoords) {
                    this.perChunk.computeIfAbsent(pos, k -> new ArrayList<>()).add(lastPos);
                }
            }
            this.generateGspUp();
            ++processed;
        } while (processed < count);
    }

    public void processChunk() {
        if (this.perChunk.isEmpty() || this.orderedChunks.isEmpty()) return;
        BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();
        ChunkPos pos = this.orderedChunks.get(0);
        List<Vector3f> list = this.perChunk.get(pos);
        int chunkX = pos.x, chunkZ = pos.z;

        if (list != null && this.level.hasChunk(chunkX, chunkZ)) {
            HashSet<BlockPos> toRem = new HashSet<>();
            int enter = Math.max(0,
                    Math.min(Math.abs(this.posX - (chunkX << 4)), Math.abs(this.posZ - (chunkZ << 4))) - 16);

            for (Vector3f vec3f : list) {
                Vec3 vec = new Vec3(vec3f.x - this.posX, vec3f.y - this.posY, vec3f.z - this.posZ);
                double len = vec.length();
                if (len < 1e-6) continue;
                double pX = vec.x / len, pY = vec.y / len, pZ = vec.z / len;
                boolean inChunk = false;
                for (int i = enter; (double) i < len; ++i) {
                    int x = Mth.floor(this.posX + pX * i);
                    int y = Mth.floor(this.posY + pY * i);
                    int z = Mth.floor(this.posZ + pZ * i);
                    if (x >> 4 == chunkX && z >> 4 == chunkZ) {
                        inChunk = true;
                        if (!this.level.getBlockState(mutable.set(x, y, z)).isAir()) {
                            toRem.add(mutable.immutable());
                        }
                    } else if (inChunk) {
                        break;
                    }
                }
            }
            for (BlockPos bp : toRem) {
                this.level.setBlock(bp, Blocks.AIR.defaultBlockState(), 50);
            }
        }
        this.perChunk.remove(pos);
        this.orderedChunks.remove(0);
    }

    public void cacheChunksTick() {
        if (!this.collectionComplete) this.collectTip(this.speed * 10);
    }

    public void destructionTick(int msBudget) {
        if (this.collectionComplete) {
            long start = System.currentTimeMillis();
            while (!this.perChunk.isEmpty() && System.currentTimeMillis() < start + msBudget) {
                this.processChunk();
            }
        }
    }

    public boolean isComplete() {
        return this.collectionComplete && this.perChunk.isEmpty();
    }

    private int compareChunks(ChunkPos o1, ChunkPos o2) {
        int x = this.posX >> 4, z = this.posZ >> 4;
        int d1 = Math.abs(x - o1.x) + Math.abs(z - o1.z);
        int d2 = Math.abs(x - o2.x) + Math.abs(z - o2.z);
        return d1 - d2;
    }
}