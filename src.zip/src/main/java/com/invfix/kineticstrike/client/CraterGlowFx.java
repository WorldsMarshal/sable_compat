package com.invfix.kineticstrike.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxPass;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.List;

/**
 * Остаточный жар кратера Kinetic Strike (crater_glow.fsh) — как у Gungnir в
 * The Shooting Star 1.2.0 (GungnirFx#worldPass: heat, haze): дно вокруг центра
 * расплавлено, чаша раскалена добела внизу и остывает вверх по стенкам, воздух
 * над кратером дрожит.
 *
 * Таймлайн, тиков от удара (как у Gungnir от IMPACT): жар
 * e^(−t/700), разгорается за 3 тика; марево — с 2-го по 20-й тик, гаснет с
 * 500-го по 800-й; всё уходит к 900-му (45 с).
 */
@OnlyIn(Dist.CLIENT)
public final class CraterGlowFx extends FxEffect {

    private static final int DURATION = 900;

    private final ClientLevel level;
    private final Vec3 center;
    private final float radius;
    private final float seed;

    private CraterGlowFx(ClientLevel level, Vec3 center, float radius, float seed) {
        this.level = level;
        this.center = center;
        this.radius = radius;
        this.seed = seed;
    }

    /** x, z — центр удара, ground — высота земли (y верхнего блока), radius — радиус зоны кратера. */
    public static void start(double x, int ground, double z, float radius, float seed) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        com.invfix.fx.FxManager.add(new CraterGlowFx(level, new Vec3(x, ground + 1.0, z), radius, seed));
    }

    @Override
    protected int duration() {
        return DURATION;
    }

    @Override
    public boolean finished() {
        return super.finished() || Minecraft.getInstance().level != level;
    }

    @Override
    public Vec3 focus() {
        return center;
    }

    @Override
    public double range() {
        return 2048.0;
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        float t = ticks(frame);
        float heat = (float) Math.exp(-t / 700.0) * smooth(t / 3.0F) * (1.0F - smooth((t - 820.0F) / 80.0F));
        float haze = window(t, 2.0F, 20.0F, 500.0F, 800.0F);
        if (heat <= 0.001F && haze <= 0.001F) return;
        Vec3 c = frame.rel(center);
        float seconds = t / 20.0F;
        float r = radius;
        float k = radius / 400.0F;
        float sd = seed;
        out.add(new FxPass("crater_glow", u -> {
            u.v3("Target", c);
            u.f4("P0", seconds, sd, r, heat);
            u.f4("P1", k, haze, 0.0F, 0.0F);
        }));
    }
}
