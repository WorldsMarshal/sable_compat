package com.invfix.kineticstrike.client;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Клиентское состояние: какие игроки сейчас в Kinetic Strike рывке (для конуса ×3). */
@OnlyIn(Dist.CLIENT)
public final class KineticStrikeClient {

    private static final Set<Integer> DASHING = ConcurrentHashMap.newKeySet();

    private KineticStrikeClient() {}

    public static void setDashing(int entityId, boolean active) {
        if (active) DASHING.add(entityId);
        else DASHING.remove(entityId);
    }

    public static boolean isDashing(int entityId) {
        return DASHING.contains(entityId);
    }
}