package com.invfix.kineticstrike.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.List;

/**
 * Белый термоядерный взрыв Kinetic Strike — весь визуал удара. Прежние
 * частицы BMNW (вспышка flash.png, гриб, кольца дыма, огненное кольцо по
 * земле, мигание неба) убраны полностью.
 *
 * Сделан тем же способом, что удар The Shooting Star (StarFx): мировой проход
 * nuke.fsh плюс параметры композита по таймлайну.
 *
 * Таймлайн, секунды от детонации:
 *  0.00–0.30  белые импакт-кадры, 6 кадров по 0.05 с, рисунок чередования как
 *             у удара Shooting Star (A A B A B B). На это время мир погружён в
 *             темноту и освещён только шаром, жёстко; небо — белое. Из этого
 *             композит режет силуэты (режимы 36/37, белые, без растра);
 *  0.30       вспышка во весь экран, гаснет за ~0.5 с; кадр с шаром
 *             запоминается — из него «выжженный» послеобраз до ~3 с;
 *  0.00–0.30  шар раздувается почти мгновенно (70 % радиуса за 0.15 с);
 *  0.00–1.50  бело-голубой; дальше остывает: белый → жёлтый → оранжевый →
 *             красный, по нему поднимается копоть;
 *  6.00–9.00  гаснет: рвётся на тлеющие клочья по своим ячейкам;
 *  0.00–3.00  ударный фронт по земле — вместе с фронтом кратера (KineticCrater:
 *             до края кратера за 1.8 с, дальше слабеет за ним); тряска — когда
 *             фронт доходит до камеры.
 *
 * Шар — от радиуса кратера (size = 90/252 радиуса), так что у обеих версий
 * удара (обычной — 378 блоков, и в режиме Sentry — 567) взрыв ровно под свой кратер.
 *
 * Внешний вид проверен на стенде: тот же конвейер (проход → bloom → композит)
 * в WebGL2 над синтетической сценой, на 150, 380 и 1200 блоках.
 */
@OnlyIn(Dist.CLIENT)
public final class NukeFx extends FxEffect {

    /** Длительность, тиков. */
    private static final int DURATION = 200;
    /**
     * Размер, под который подобраны константы ниже (45 — гриб Tsar Bomba, с
     * которым эффект настраивался на стенде). Всё пространственное — шар,
     * подъём, ударный фронт, дальность «вблизи» — масштабируется от него.
     */
    private static final float BASE_SIZE = 45.0F;
    private static final float SHOCK_SECONDS = 3.0F;
    /** При BASE_SIZE: ближе этого всё на полную силу, дальше слабеет, но не ниже 20 %. */
    private static final double NEAR_RANGE = 1500.0;

    private final Vec3 center;
    private final float size;
    /** Радиус кратера: по нему идёт ударный фронт. */
    private final float crater;
    private final float seed;
    private final ClientLevel level;
    private boolean shockReachedCamera;

    private NukeFx(ClientLevel level, Vec3 center, float size, float crater) {
        this.level = level;
        this.center = center;
        this.size = size;
        this.crater = crater;
        this.seed = (float) ((Mth.getSeed((int) center.x, (int) center.y, (int) center.z) & 0xFFFFL) / 65535.0);
    }

    /** size и crater — из PacketMushroomCloud. */
    public static void start(double x, double y, double z, float size, float crater) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        FxManager.add(new NukeFx(level, new Vec3(x, y, z), size, crater));
    }

    @Override
    protected int duration() {
        return DURATION;
    }

    @Override
    public boolean finished() {
        return super.finished() || Minecraft.getInstance().level != level;
    }

    @Override
    public Vec3 focus() {
        return center;
    }

    /** Видно издалека — как и слышно (soundDistance Tsar Bomba). */
    @Override
    public double range() {
        return 4096.0;
    }

    // ── таймлайн ───────────────────────────────────────────────────────────

    private float maxRadius() {
        return size * 1.6F;
    }

    /** Раздувается почти мгновенно: 70 % радиуса за 0.15 с — к импакт-кадрам шар уже большой. */
    private float radius(float s) {
        return maxRadius() * (1.0F - (float) Math.exp(-s / 0.12F));
    }

    /** Температура шара: >1.25 бело-голубой, 1 белый, 0.5 оранжевый. */
    private static float heat(float s) {
        if (s < 1.5F) return 1.45F;
        return 1.45F * (float) Math.exp(-(s - 1.5F) / 3.0F);
    }

    /** Конец импакт-кадров: 6 кадров по 0.05 с. */
    private static final float IMPACT_END = 0.3F;

    /** Шар поднимается: горячий воздух. */
    private Vec3 fireball(float s) {
        return center.add(0.0, size * 0.25F * Math.min(s, 8.0F), 0.0);
    }

    private float scale() {
        return size / BASE_SIZE;
    }

    /** Фронт кратера Gungnir: радиус · (t / 36 тиков)^0.6. */
    private float shockFront(float s) {
        return s <= 0.0F ? 0.0F : crater * (float) Math.pow(s * 20.0F / 36.0F, 0.6);
    }

    @Override
    protected void onTick(Minecraft minecraft, ClientLevel level, int age) {
        // Тряска в момент, когда фронт доходит до камеры.
        float s = age / 20.0F;
        if (!shockReachedCamera && s <= SHOCK_SECONDS) {
            double d = FxManager.camera().distanceTo(center);
            if (shockFront(s) >= d) {
                shockReachedCamera = true;
                FxManager.shake(center, 0.75F, 2500.0);
            }
        }
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        float s = ticks(frame) / 20.0F;
        float opacity = 1.0F - smooth((s - 6.0F) / 3.0F);
        if (opacity <= 0.001F) return;

        float r = radius(s);
        float heat = heat(s);
        // Пока держатся импакт-кадры, мир погружён в темноту и освещён только
        // шаром, жёстко, без рассеянного света: грани к взрыву белые, прочее
        // чёрное — из этого импакт-кадры режут силуэты. Потом свет мягчеет.
        float impactPhase = window(s, 0.0F, 0.01F, IMPACT_END - 0.03F, IMPACT_END + 0.03F);
        float dim = impactPhase * 0.85F;
        float light = Math.max(window(s, 0.0F, 0.01F, 0.5F, 2.8F), 0.25F * smooth(heat / 1.45F)) * opacity;
        float air = (0.35F + 0.65F * window(s, 0.0F, 0.02F, 0.6F, 4.0F)) * opacity;
        float shock = s < SHOCK_SECONDS ? (1.0F - s / SHOCK_SECONDS) : 0.0F;
        float shell = window(s, 0.05F, 0.15F, 0.8F, 2.2F);
        Vec3 c = frame.rel(fireball(s));
        float groundY = (float) (center.y - frame.camera().y);
        float front = shockFront(s);
        float seedF = seed;
        out.add(new FxPass("nuke", u -> {
            u.v3("Target", c);
            u.f4("P0", r, s, seedF, heat);
            u.f4("P1", opacity, light, front, shock);
            u.f4("P2", air, groundY, Math.max(front * 0.6F, r * 1.05F), shell);
            u.f4("P3", dim, impactPhase, 0.0F, 0.0F);
        }));
    }

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        float s = ticks(frame) / 20.0F;
        float near = (float) Mth.clamp(1.0 - frame.camera().distanceTo(center) / (NEAR_RANGE * scale()), 0.2, 1.0);

        // Белые импакт-кадры, наши режимы композита: 36 — мир чёрными контурами
        // на белом, взрыв чёрным диском; 37 — наоборот. Рисунок чередования —
        // как у удара Shooting Star (A A B A B B). Сила почти не зависит от
        // расстояния: кадр должен читаться и издалека.
        float impact = (float) Mth.clamp(1.0 - frame.camera().distanceTo(center) / 4096.0, 0.5, 1.0);
        impactSequence(screen, s, fireball(s), impact, 0.05F, 36, 36, 37, 36, 37, 37);

        // Вспышка во весь экран сразу за импакт-кадрами и её быстрый спад;
        // выше 1 композит заливает кадр белым целиком.
        if (s >= IMPACT_END) {
            float flash = 1.4F * (float) Math.exp(-(s - IMPACT_END) / 0.22F);
            screen.addFlash(0xFFFFFF, flash * near);
        }

        // Ослепление: кадр с шаром запоминается сразу после импакт-кадров и
        // выжжен в глазах ещё несколько секунд.
        if (s >= IMPACT_END && s < IMPACT_END + 0.15F) screen.capture = 1.0F;
        screen.afterimage = Math.max(screen.afterimage,
                window(s, IMPACT_END, IMPACT_END + 0.02F, 0.5F, 3.0F) * 0.55F * near);

        float hold = window(s, IMPACT_END - 0.02F, IMPACT_END + 0.02F, 1.5F, 5.0F);
        screen.bloom = Math.max(screen.bloom, 1.1F * hold);
        screen.bloomRadius = Math.max(screen.bloomRadius, 1.0F + 1.3F * hold);
        screen.shake = Math.max(screen.shake, window(s, 0.0F, 0.05F, 1.5F, 4.0F) * 0.8F * near);
        screen.aberration = Math.max(screen.aberration, window(s, 0.0F, 0.05F, 0.8F, 3.0F) * near);
        screen.zoomBlur = Math.max(screen.zoomBlur, window(s, 0.0F, 0.03F, 0.35F, 1.4F) * 0.55F * near);
        screen.desaturate = Math.max(screen.desaturate, window(s, 0.3F, 0.5F, 1.5F, 5.0F) * 0.5F * near);
    }
}
