package com.invfix.kineticstrike;

import net.mcreator.invincibleinc.init.InvincibleIncModMobEffects;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.network.PlayPlayerAnimationMessage;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Kinetic Strike — Part 1: рывок (dash) на огромной скорости к цели.
 *
 * Условия активации:
 *  - раса Viltrumite/Altrumite, способность в слоте, LVL >= 80;
 *  - игрок в режиме боя (эффект COMBAT_MODE);
 *  - цель — блок в прогруженном чанке ИЛИ хитбокс прогруженной сущности.
 *
 * При активации: огромный импульс к цели, анимация быстрого полёта,
 * флаг нагрева (конус ×3 на клиенте), кольца ударной волны (photon fx + ×10 ванильное).
 * При достижении цели игрока ПРИНУДИТЕЛЬНО останавливаем (импульс сам не погасит,
 * особенно при цели-сущности без коллизии блока).
 */
@EventBusSubscriber(modid = "sable_compat")
public final class KineticStrikeHandler {

    public static final String ABILITY = "§e§lKinetic Strike";
    public static final int    LVL_REQUIRED = 180;

    private static final Set<String> ELIGIBLE = Set.of("§4§lViltrumite", "§1§lAlien(Metroman)");

    private static final double MAX_RANGE     = 512.0;
    private static final double DASH_SPEED    = 30.0;  // блоков/тик (≈600 бл/сек)
    private static final int    MAX_DASH_TICKS = 80;
    private static final double ARRIVE_DIST   = 1.5;
    private static final float  RING_SCALE    = 30.0f; // кольца ×10×3
    private static final long   COOLDOWN_TICKS = 1100;   // 5 секунд КД

    private static final String NBT_DASH = "invfix_kineticDash";

    private record Dash(Vec3 target, int targetEntityId, int ticks) {}
    private static final Map<UUID, Dash> DASHES = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_USE = new ConcurrentHashMap<>();

    private KineticStrikeHandler() {}

    public static boolean isEligible(String race) { return race != null && ELIGIBLE.contains(race); }

    public static boolean isDashing(Entity e) {
        return e.getPersistentData().getBoolean(NBT_DASH);
    }

    // ── Активация ──────────────────────────────────────────────────────────────
    public static void activate(ServerPlayer player) {
        try {
            if (!player.hasEffect(InvincibleIncModMobEffects.COMBAT_MODE)) return;

            InvincibleIncModVariables.PlayerVariables v =
                    player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (!isEligible(v.Race)) return;
            if (v.Lvl < LVL_REQUIRED) return;
            if (DASHES.containsKey(player.getUUID())) return;

            ServerLevel level = (ServerLevel) player.level();

            // Кулдаун 5 секунд
            long now = level.getGameTime();
            Long last = LAST_USE.get(player.getUUID());
            if (last != null && now - last < COOLDOWN_TICKS) return;
            Vec3 eye  = player.getEyePosition();
            Vec3 look = player.getLookAngle();
            if (look.lengthSqr() < 1e-6) return;
            look = look.normalize();

            // Блок в пределах прогрузки
            double blockDist = maxLoadedDistance(level, eye, look, MAX_RANGE);
            if (blockDist <= 1.0) return; // некуда (небо/непрогруз)
            Vec3 blockEnd = eye.add(look.scale(blockDist));
            BlockHitResult bh = level.clip(new ClipContext(
                    eye, blockEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            double targetDist = (bh.getType() != HitResult.Type.MISS)
                    ? eye.distanceTo(bh.getLocation()) : blockDist;
            Vec3 targetPos = (bh.getType() != HitResult.Type.MISS) ? bh.getLocation() : blockEnd;
            int targetEntityId = -1;

            // Ближайшая сущность на луче ближе блока
            AABB box = new AABB(eye, eye.add(look.scale(targetDist))).inflate(1.0);
            double bestSq = targetDist * targetDist;
            for (Entity e : level.getEntities(player, box,
                    ent -> ent instanceof LivingEntity le && le.isAlive() && ent != player)) {
                AABB eb = e.getBoundingBox().inflate(0.3);
                var clip = eb.clip(eye, eye.add(look.scale(targetDist)));
                if (clip.isPresent()) {
                    double dSq = eye.distanceToSqr(clip.get());
                    if (dSq < bestSq) {
                        bestSq = dSq;
                        targetEntityId = e.getId();
                        targetPos = e.position().add(0, e.getBbHeight() * 0.5, 0);
                    }
                }
            }

            boolean valid = (bh.getType() != HitResult.Type.MISS) || targetEntityId != -1;
            if (!valid) return;
            // цель должна быть в прогруженном чанке
            if (!level.isLoaded(net.minecraft.core.BlockPos.containing(targetPos))) return;

            // Старт рывка (движение — принудительным телепортом в onLevelTick)
            setFlightAnimation(level, player);
            spawnStartRings(level, player, look);
            player.getPersistentData().putBoolean(NBT_DASH, true);
            syncDashState(player, true);

            LAST_USE.put(player.getUUID(), now);
            DASHES.put(player.getUUID(), new Dash(targetPos, targetEntityId, 0));
        } catch (Exception ignored) {}
    }

    // ── Тик рывка ──────────────────────────────────────────────────────────────
    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (DASHES.isEmpty()) return;

        for (ServerPlayer player : level.players()) {
            Dash dash = DASHES.get(player.getUUID());
            if (dash == null) continue;
            try {
                updateDash(level, player, dash);
            } catch (Exception e) {
                stopDash(player, false);
            }
        }
    }

    private static void updateDash(ServerLevel level, ServerPlayer player, Dash dash) {
        int ticks = dash.ticks() + 1;

        // движущаяся цель-сущность
        Vec3 target = dash.target();
        if (dash.targetEntityId() != -1) {
            Entity te = level.getEntity(dash.targetEntityId());
            if (te != null && te.isAlive()) {
                target = te.position().add(0, te.getBbHeight() * 0.5, 0);
            }
        }

        Vec3 feet   = player.position();
        Vec3 selfMid = feet.add(0, player.getBbHeight() * 0.5, 0);
        Vec3 toTarget = target.subtract(selfMid);
        double dist = toTarget.length();

        if (dist <= ARRIVE_DIST) {
            stopDash(player, true);   // достигли цели — детонация
            return;
        }
        if (ticks >= MAX_DASH_TICKS) {
            stopDash(player, false);  // таймаут — без детонации
            return;
        }

        Vec3 dir = toTarget.scale(1.0 / dist);
        double step = Math.min(DASH_SPEED, dist);
        Vec3 nextMid = selfMid.add(dir.scale(step));

        // Коллизия: луч по центру игрока от текущей к следующей точке
        BlockHitResult hit = level.clip(new ClipContext(
                selfMid, nextMid, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        boolean arrived = false;
        if (hit.getType() != HitResult.Type.MISS) {
            // останавливаемся чуть перед блоком
            nextMid = hit.getLocation().subtract(dir.scale(0.6));
            arrived = true;
        }

        Vec3 nextFeet = nextMid.subtract(0, player.getBbHeight() * 0.5, 0);

        // Принудительное перемещение телепортом + скорость по шагу.
        // Клиент предсказывает движение со скоростью dir*step, а следующий телепорт
        // попадает ровно туда же → camera движется плавно, без рывков.
        player.connection.teleport(nextFeet.x, nextFeet.y, nextFeet.z,
                player.getYRot(), player.getXRot());
        player.setDeltaMovement(dir.scale(step));
        player.hurtMarked = true;
        player.fallDistance = 0;
        player.resetFallDistance();

        if (arrived) {
            stopDash(player, true);   // врезались в блок — детонация
            return;
        }
        DASHES.put(player.getUUID(), new Dash(dash.target(), dash.targetEntityId(), ticks));
    }

    /** Принудительная остановка. impact=true → детонация ядерного удара. */
    public static void stopDash(ServerPlayer player, boolean impact) {
        DASHES.remove(player.getUUID());
        if (impact && player.level() instanceof ServerLevel sl) {
            // Урон ядерного удара масштабируется от статы силы игрока (currentStr).
            // Если нужна базовая сила вместо текущей — замени currentStr на trueStr.
            double strength = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES).currentStr;
            KineticNuke.detonate(sl, player.position().add(0, player.getBbHeight() * 0.5, 0),
                    strength, player);
        }
        player.setDeltaMovement(0, 0, 0);
        player.hurtMarked = true;
        player.fallDistance = 0;
        player.getPersistentData().putBoolean(NBT_DASH, false);
        syncDashState(player, false);
        endFlightAnimation((ServerLevel) player.level(), player);
    }

    // ── Вспомогательное ─────────────────────────────────────────────────────────

    private static void setFlightAnimation(ServerLevel level, ServerPlayer player) {
        CompoundTag data = player.getPersistentData();
        data.putString("PlayerCurrentAnimation", "invincible_inc:standard_flight");
        data.putBoolean("OverrideCurrentAnimation", true);
        data.putBoolean("FirstPersonAnimation", true);
        PacketDistributor.sendToPlayersInDimension(level,
                new PlayPlayerAnimationMessage(player.getId(), "invincible_inc:standard_flight", true, true),
                new CustomPacketPayload[0]);
    }

    private static void endFlightAnimation(ServerLevel level, ServerPlayer player) {
        CompoundTag data = player.getPersistentData();
        data.remove("PlayerCurrentAnimation");
        data.putBoolean("OverrideCurrentAnimation", false);
        data.putBoolean("FirstPersonAnimation", false);
        PacketDistributor.sendToPlayersInDimension(level,
                new PlayPlayerAnimationMessage(player.getId(), "", false, false),
                new CustomPacketPayload[0]);
    }

    /** Кольца ударной волны: оригинальный photon fx + ванильное кольцо ×10. */
    private static void spawnStartRings(ServerLevel level, ServerPlayer player, Vec3 look) {
        // 3 кольца ударной волны по сужению, ориентированы ПО ВЕКТОРУ взгляда.
        Vec3 c = player.position().add(0, player.getBbHeight() * 0.5, 0);
        Vec3 upRef = Math.abs(look.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 right = look.cross(upRef).normalize();
        Vec3 up = right.cross(look).normalize();

        double[] radii = { RING_SCALE, RING_SCALE * 0.65, RING_SCALE * 0.35 }; // сужение
        double[] forward = { 0.0, 2.5, 4.5 };                                  // вперёд по вектору
        int points = 56;
        for (int ring = 0; ring < radii.length; ring++) {
            Vec3 center = c.add(look.scale(forward[ring]));
            double radius = radii[ring];
            for (int i = 0; i < points; i++) {
                double ang = (Math.PI * 2 * i) / points;
                Vec3 off = right.scale(Math.cos(ang) * radius).add(up.scale(Math.sin(ang) * radius));
                Vec3 p = center.add(off);
                Vec3 outward = off.normalize().scale(0.5);
                level.sendParticles(ParticleTypes.CLOUD, p.x, p.y, p.z, 0,
                        outward.x, outward.y, outward.z, 1.0);
                if (i % 3 == 0) {
                    level.sendParticles(ParticleTypes.EXPLOSION, p.x, p.y, p.z, 1, 0, 0, 0, 0);
                }
            }
        }
    }

    /** Клиентам — состояние рывка (для конуса нагрева ×3). */
    private static void syncDashState(ServerPlayer player, boolean active) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player,
                new KineticStrikeStatePacket(player.getId(), active), new CustomPacketPayload[0]);
    }

    // дистанция вдоль луча в пределах прогруженных чанков
    private static double maxLoadedDistance(ServerLevel level, Vec3 origin, Vec3 dir, double max) {
        double step = 16.0, d = step, reached = 0;
        while (d <= max) {
            if (!level.isLoaded(net.minecraft.core.BlockPos.containing(origin.add(dir.scale(d))))) break;
            reached = d; d += step;
        }
        return reached;
    }
}