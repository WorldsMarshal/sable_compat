package com.invfix.kineticstrike;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Ядерный удар Kinetic Strike.
 *
 * Разрушение — кратер Gungnir из The Shooting Star ({@link KineticCrater}):
 * зона радиусом {@link #CRATER_RADIUS} срезана и вдавлена, в центре чаша,
 * трещины-лучи, дно выжжено магмой, чернокамнем, обсидианом и т.д. Режется
 * прямо в секциях чанков за ~2 с (прежние BMNW-лучи разрешались минутами).
 *
 * Плюс волна урона/отброса/огня по сущностям и звук. Визуал на клиенте —
 * шейдерный взрыв NukeFx под размер кратера и остаточный жар дна CraterGlowFx.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class KineticNuke {

    /** Радиус зоны кратера, блоков (как радиус прежнего BMNW-взрыва). */
    static final double CRATER_RADIUS = 252.0;
    /**
     * Обычный удар — на уровне прежней версии The Whole Sentry Power: кратер
     * ×{@link com.invfix.sentry.SentryHandler#DESTRUCTION_MULT} (378 блоков),
     * урон ×{@link com.invfix.sentry.SentryHandler#DAMAGE_MULT}. В режиме Sentry
     * сверху ещё раз те же множители (кратер ×1.5 → 567, урон ×2 — общим бафом
     * Sentry на весь урон игрока).
     */
    static final double BASE_RADIUS_MULT = com.invfix.sentry.SentryHandler.DESTRUCTION_MULT;
    static final double BASE_DAMAGE_MULT = com.invfix.sentry.SentryHandler.DAMAGE_MULT;

    // ── Урон от статы силы (currentStr), затухание по дистанции ────────────────
    // Множитель к силе игрока по дистанции от точки чёткого попадания:
    //   10 бл → ×8,   40 бл → ×2,   350 бл → ×1.2,   дальше 350 бл → урона нет.
    // Между опорными точками — линейная интерполяция.
    private static final double DMG_NEAR_DIST = 10.0,  DMG_NEAR_MULT = 8.0;
    private static final double DMG_MID_DIST  = 40.0,  DMG_MID_MULT  = 2.0;
    private static final double DMG_FAR_DIST  = 350.0, DMG_FAR_MULT  = 1.2;
    private static final double ENTITY_DAMAGE_RADIUS = DMG_FAR_DIST; // максимум поражения сущностей
    private static final int   ENTITY_FIRE_TICKS  = 200;

    // Масштаб шейдерного взрыва (NukeFx): шар 1.6·size блоков в радиусе — от
    // радиуса кратера (при 252 блоках — 90, как было), ударный фронт идёт вместе
    // с фронтом кратера.
    private static final float VISUAL_PER_RADIUS = 90.0f / 252.0f;
    private static final int   SOUND_DISTANCE = 4096;    // TsarBombaNukeType.getSoundDistance()

    private static final List<KineticCrater> ACTIVE = new ArrayList<>();

    private KineticNuke() {}

    // ── Детонация ──────────────────────────────────────────────────────────────
    // strength — стата силы игрока (currentStr). attacker — кто нанёс удар (для зачёта килла).
    public static void detonate(ServerLevel level, Vec3 center, double strength,
                                net.minecraft.world.entity.player.Player attacker) {
        // Кратер (Gungnir). The Whole Sentry Power: разрушения ещё ×1.5 — кратер и взрыв больше
        double sentryMult = attacker != null ? com.invfix.sentry.SentryHandler.destruction(attacker) : 1.0;
        double radius = CRATER_RADIUS * BASE_RADIUS_MULT * sentryMult;
        int ground = KineticCrater.groundAt(level, center);
        long seed = level.random.nextLong();
        ACTIVE.add(new KineticCrater(level, center, radius, ground, seed));

        // Волна на сущности: урон = сила × множитель(дистанция) + отброс + поджог.
        Vec3 c = center;
        // щит Prism Ward: кто за ним (от точки удара) — без урона, отброса и огня
        com.invfix.prismward.WardOcclusion wards = com.invfix.prismward.WardOcclusion.of(level, c, ENTITY_DAMAGE_RADIUS);
        for (Entity e : level.getEntities(attacker,
                new AABB(c, c).inflate(ENTITY_DAMAGE_RADIUS),
                en -> en instanceof LivingEntity le && le.isAlive())) {
            double dist = e.position().distanceTo(c);
            double mult = strengthMultiplier(dist);
            if (mult <= 0.0) continue; // вне радиуса поражения (>350 бл)
            Vec3 ec = e.getBoundingBox().getCenter();
            if (wards.blocked(ec.x, ec.y, ec.z)) continue;

            float damage = (float) (strength * mult * BASE_DAMAGE_MULT);
            e.hurt(level.damageSources().explosion(attacker, attacker), damage);
            e.igniteForSeconds(ENTITY_FIRE_TICKS / 20);

            double knock = 1.0 - Math.min(1.0, dist / ENTITY_DAMAGE_RADIUS); // затухание отброса
            Vec3 push = e.position().subtract(c);
            if (push.lengthSqr() < 1e-4) push = new Vec3(0, 1, 0);
            push = push.normalize().scale(4.0 * knock).add(0, 0.6, 0);
            e.setDeltaMovement(e.getDeltaMovement().add(push));
            e.hurtMarked = true;
        }

        // Шейдерный взрыв + звук, всем игрокам в измерении.
        PacketDistributor.sendToPlayersInDimension(level,
                new PacketMushroomCloud(c.x, c.y, c.z, (float) (VISUAL_PER_RADIUS * radius), SOUND_DISTANCE,
                        (float) radius, ground, (float) ((seed & 0xFFFFL) / 65535.0)),
                new CustomPacketPayload[0]);
    }

    // Множитель к силе по дистанции: 10→×8, 40→×2, 350→×1.2, дальше 0.
    private static double strengthMultiplier(double d) {
        if (d <= DMG_NEAR_DIST) return DMG_NEAR_MULT;
        if (d <= DMG_MID_DIST)
            return lerp(DMG_NEAR_MULT, DMG_MID_MULT, (d - DMG_NEAR_DIST) / (DMG_MID_DIST - DMG_NEAR_DIST));
        if (d <= DMG_FAR_DIST)
            return lerp(DMG_MID_MULT, DMG_FAR_MULT, (d - DMG_MID_DIST) / (DMG_FAR_DIST - DMG_MID_DIST));
        return 0.0;
    }

    private static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    // ── Тик активных кратеров ──────────────────────────────────────────────────
    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (ACTIVE.isEmpty()) return;

        Iterator<KineticCrater> it = ACTIVE.iterator();
        while (it.hasNext()) {
            KineticCrater crater = it.next();
            if (crater.level != level) continue;
            try {
                crater.tick();
            } catch (Exception e) {
                crater.release();
            }
            if (crater.finished()) it.remove();
        }
    }
}