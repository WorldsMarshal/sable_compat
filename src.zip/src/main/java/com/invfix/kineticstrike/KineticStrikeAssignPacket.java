package com.invfix.kineticstrike;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Клиент → Сервер: выбрать Kinetic Strike как текущую способность (для назначения в слот). */
public record KineticStrikeAssignPacket(int x, int y, int z) implements CustomPacketPayload {

    public static final Type<KineticStrikeAssignPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "ks_assign"));

    public static final StreamCodec<FriendlyByteBuf, KineticStrikeAssignPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, m) -> { buf.writeInt(m.x()); buf.writeInt(m.y()); buf.writeInt(m.z()); },
                    buf -> new KineticStrikeAssignPacket(buf.readInt(), buf.readInt(), buf.readInt()));

    @Override public Type<KineticStrikeAssignPacket> type() { return TYPE; }

    public static void handleServer(KineticStrikeAssignPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer player)) return;
            try {
                InvincibleIncModVariables.PlayerVariables vars =
                        player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                if (!KineticStrikeHandler.isEligible(vars.Race)) return;
                if (vars.Lvl < KineticStrikeHandler.LVL_REQUIRED) return;
                vars.AbilitySet = KineticStrikeHandler.ABILITY;
                vars.abilityDescription = KineticStrikeHandler.ABILITY + " | LVL:80 | Рывок-таран";
                vars.markSyncDirty();
            } catch (Exception ignored) {}
        });
    }
}