package com.invfix.kineticstrike;

import com.invfix.kineticstrike.client.NukeFx;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Сервер → Клиент: детонация Kinetic Strike.
 *
 * Имя и id пакета (ks_mushroom_cloud) остались от BMNW-гриба, чтобы не трогать
 * регистрацию; гриба, дыма и прочих частиц больше нет. На клиенте — шейдерный
 * взрыв NukeFx и звук с затуханием по дистанции (как BMNW PacketSendNuclearSound).
 *
 * size — масштаб взрыва для NukeFx; crater — радиус зоны кратера, ground — высота
 * земли в точке удара, seed — для рисунка остаточного жара (CraterGlowFx).
 */
public record PacketMushroomCloud(double x, double y, double z, float size, int soundDistance,
                                  float crater, int ground, float seed)
        implements CustomPacketPayload {

    public static final Type<PacketMushroomCloud> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "ks_mushroom_cloud"));

    public static final StreamCodec<FriendlyByteBuf, PacketMushroomCloud> STREAM_CODEC =
            StreamCodec.of(
                    (buf, m) -> {
                        buf.writeDouble(m.x());
                        buf.writeDouble(m.y());
                        buf.writeDouble(m.z());
                        buf.writeFloat(m.size());
                        buf.writeVarInt(m.soundDistance());
                        buf.writeFloat(m.crater());
                        buf.writeVarInt(m.ground());
                        buf.writeFloat(m.seed());
                    },
                    buf -> new PacketMushroomCloud(
                            buf.readDouble(), buf.readDouble(), buf.readDouble(),
                            buf.readFloat(), buf.readVarInt(), buf.readFloat(), buf.readVarInt(), buf.readFloat()));

    @Override
    public Type<PacketMushroomCloud> type() {
        return TYPE;
    }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(PacketMushroomCloud packet, IPayloadContext context) {
        context.enqueueWork(() -> {
            NukeFx.start(packet.x, packet.y, packet.z, packet.size, packet.crater);
            com.invfix.kineticstrike.client.CraterGlowFx.start(packet.x, packet.ground, packet.z, packet.crater, packet.seed);

            if (packet.soundDistance > 0) {
                double playerDist = Math.sqrt(context.player().distanceToSqr(packet.x, packet.y, packet.z));
                if (playerDist <= packet.soundDistance) {
                    double inv = packet.soundDistance - playerDist;
                    double volume = Math.min(1.0, inv * 2.0 / packet.soundDistance);
                    double pitch = inv / packet.soundDistance;
                    context.player().playSound(NukeSounds.NUCLEAR_BOOM.get(), (float) volume, (float) pitch);
                }
            }
        });
    }
}
