package com.invfix.fourd;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.ArrayList;
import java.util.List;

/** Пакеты 4D Offset. */
public final class FourDPackets {

    private FourDPackets() {}

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath("sable_compat", path);
    }

    /** Сервер → игроки рядом и сам: игрок entityId смещён в 4D (on) или вернулся. */
    public record State(int entityId, boolean on) implements CustomPacketPayload {
        public static final Type<State> TYPE = new Type<>(id("four_d_state"));
        public static final StreamCodec<FriendlyByteBuf, State> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> {
                    buf.writeVarInt(m.entityId());
                    buf.writeBoolean(m.on());
                },
                buf -> new State(buf.readVarInt(), buf.readBoolean()));

        @Override public Type<State> type() { return TYPE; }
    }

    /** Один контейнер вокруг: где и что в нём (до {@link FourDHandler#SHOWN_ITEMS} стопок). */
    public record Box(BlockPos pos, List<ItemStack> items) {}

    /** Сервер → игрок в 4D: контейнеры вокруг и их содержимое (для зрения и рук сквозь стены). */
    public record Contents(List<Box> boxes) implements CustomPacketPayload {
        public static final Type<Contents> TYPE = new Type<>(id("four_d_contents"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Contents> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> {
                    buf.writeVarInt(m.boxes().size());
                    for (Box b : m.boxes()) {
                        buf.writeBlockPos(b.pos());
                        buf.writeVarInt(b.items().size());
                        for (ItemStack s : b.items()) ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, s);
                    }
                },
                buf -> {
                    int n = Math.min(buf.readVarInt(), 1024);
                    List<Box> boxes = new ArrayList<>(n);
                    for (int i = 0; i < n; i++) {
                        BlockPos pos = buf.readBlockPos();
                        int k = Math.min(buf.readVarInt(), 64);
                        List<ItemStack> items = new ArrayList<>(k);
                        for (int j = 0; j < k; j++) items.add(ItemStack.OPTIONAL_STREAM_CODEC.decode(buf));
                        boxes.add(new Box(pos, items));
                    }
                    return new Contents(boxes);
                });

        @Override public Type<Contents> type() { return TYPE; }
    }

    /** Клиент → сервер: открыть контейнер pos сквозь стены. */
    public record Open(BlockPos pos) implements CustomPacketPayload {
        public static final Type<Open> TYPE = new Type<>(id("four_d_open"));
        public static final StreamCodec<FriendlyByteBuf, Open> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> buf.writeBlockPos(m.pos()), buf -> new Open(buf.readBlockPos()));

        @Override public Type<Open> type() { return TYPE; }

        public static void handleServer(Open pkt, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (ctx.player() instanceof ServerPlayer player) FourDHandler.open(player, pkt.pos());
            });
        }
    }

    /** Клиент → сервер: залезть в карманы сущности entityId. */
    public record Pockets(int entityId) implements CustomPacketPayload {
        public static final Type<Pockets> TYPE = new Type<>(id("four_d_pockets"));
        public static final StreamCodec<FriendlyByteBuf, Pockets> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> buf.writeVarInt(m.entityId()), buf -> new Pockets(buf.readVarInt()));

        @Override public Type<Pockets> type() { return TYPE; }

        public static void handleServer(Pockets pkt, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (ctx.player() instanceof ServerPlayer player) FourDHandler.pockets(player, pkt.entityId());
            });
        }
    }

    /** Клиент → сервер: назначить способность в слот. */
    public record Assign() implements CustomPacketPayload {
        public static final Type<Assign> TYPE = new Type<>(id("four_d_assign"));
        public static final StreamCodec<FriendlyByteBuf, Assign> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> {}, buf -> new Assign());

        @Override public Type<Assign> type() { return TYPE; }

        public static void handleServer(Assign pkt, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (!(ctx.player() instanceof ServerPlayer player) || !FourD.eligible(player)) return;
                try {
                    InvincibleIncModVariables.PlayerVariables vars =
                            player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                    vars.AbilitySet = FourD.ABILITY;
                    vars.abilityDescription = FourD.ABILITY + " | LVL:" + FourD.LVL_REQUIRED
                            + " | Сместиться по 4-й координате / вернуться";
                    vars.markSyncDirty();
                } catch (Exception ignored) {}
            });
        }
    }
}
