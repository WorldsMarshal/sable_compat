package com.invfix.fourd.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.List;

/**
 * Вид из 4D (four_d.fsh): трёхмерный мир — как полупрозрачный срез: выцветший, холодно-фиолетовый,
 * чуть «раздвоенный» вдоль плывущего направления, его формы прочерчены светящимися рёбрами; поверх —
 * то, что стены прячут (FourDVision): каркас, контейнеры с содержимым, существа — с призрачным ореолом.
 * Идёт первым проходом, как Thermal Sense: остальные эффекты ложатся поверх.
 */
@OnlyIn(Dist.CLIENT)
public final class FourDVisionFx extends FxEffect {

    private static final int LINGER = 2;
    private static final float FADE_IN = 8.0F;
    private static FourDVisionFx instance;

    private final ClientLevel level;
    private int idle;

    private FourDVisionFx(ClientLevel level) {
        this.level = level;
    }

    static void keepAlive(ClientLevel level) {
        if (instance == null || instance.finished() || instance.level != level) {
            instance = new FourDVisionFx(level);
            FxManager.add(instance);
        }
        instance.idle = 0;
    }

    @Override
    protected void onTick(Minecraft minecraft, ClientLevel level, int age) {
        idle++;
    }

    @Override
    protected int duration() {
        return Integer.MAX_VALUE;
    }

    @Override
    public boolean finished() {
        return idle > LINGER || Minecraft.getInstance().level != level || !FourDClient.self();
    }

    @Override
    protected void onRemoved() {
        if (instance == this) instance = null;
    }

    @Override
    public Vec3 focus() {
        return FxManager.camera();
    }

    @Override
    public double range() {
        return Double.MAX_VALUE;
    }

    @Override
    public boolean first() {
        return true;
    }

    private float strength(FxFrame frame) {
        return smooth(ticks(frame) / FADE_IN);
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        float k = strength(frame);
        if (k <= 0.001F) return;
        float time = ticks(frame) / 20.0F;
        int tex = FourDVision.texture();
        float has = tex != 0 ? 1.0F : 0.0F;
        Vec3 cam = frame.camera();
        // узор привязан к миру: положение камеры по модулю — float не теряет точность
        float ox = (float) (cam.x % 512.0), oy = (float) (cam.y % 512.0), oz = (float) (cam.z % 512.0);
        out.add(new FxPass("four_d", u -> {
            u.glTexture("Overlay", tex);
            u.f4("P0", k, time, has, 0.0F);
            u.f3("Origin", ox, oy, oz);
        }));
    }

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        float k = strength(frame);
        if (k <= 0.001F) return;
        screen.addVignette(0x14062A, 0.4F * k);
        screen.bloom = Math.max(screen.bloom, 0.35F * k);
        screen.aberration = Math.max(screen.aberration, 0.12F * k);
    }
}
