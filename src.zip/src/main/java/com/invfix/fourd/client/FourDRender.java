package com.invfix.fourd.client;

import com.invfix.fourd.FourD;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLivingEvent;
import net.neoforged.neoforge.client.event.RenderNameTagEvent;
import net.neoforged.neoforge.common.util.TriState;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;

/**
 * Смещённый в 4D — для мира (и для себя от третьего лица) только 3D-срез: RenderLivingEvent.Pre
 * отменяется, тот же рендерер рисует модель заново — в буфер, оставляющий слой среза (FourDSlice).
 * Имени над ним нет, тени тоже (FlatShadowMixin).
 *
 * Срез меняется только от движения: у каждого смещённого своя фаза — сдвиг по четвёртой оси, она
 * копится каждый тик от пройденного пути ({@link #PER_BLOCK} на блок, по вертикали тоже) и поворотов
 * головы и тела ({@link #PER_DEGREE} на градус). Стоит неподвижно — срез замер.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class FourDRender {

    /** Фаза за блок пути и за градус поворота. */
    static final float PER_BLOCK = 0.9F;
    static final float PER_DEGREE = 0.012F;

    private static boolean rendering;

    /** Фаза и движение каждого смещённого (по id). */
    private static final class Track {
        float phase, prevPhase, speed;
        double x, y, z;
        float yaw, head;
    }

    private static final Map<Integer, Track> TRACKS = new HashMap<>();

    private FourDRender() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRenderPre(RenderLivingEvent.Pre<?, ?> event) {
        if (rendering || event.isCanceled()) return;
        LivingEntity entity = event.getEntity();
        Minecraft mc = Minecraft.getInstance();
        if (!FourD.in(entity) || mc.level == null) return;
        event.setCanceled(true);
        float partial = event.getPartialTick();
        PoseStack pose = event.getPoseStack();
        // поза сейчас — сдвиг к ногам относительно камеры: центр тела — над ними
        Vector3f feet = pose.last().pose().getTranslation(new Vector3f());
        Track t = TRACKS.get(entity.getId());
        float phase = t != null ? Mth.lerp(partial, t.prevPhase, t.phase) : 0.0F;
        float speed = t != null ? t.speed : 0.0F;
        FourDSlice slice = new FourDSlice(feet.x, feet.y + entity.getBbHeight() * 0.5F, feet.z, phase, speed,
                (entity.getUUID().hashCode() & 1023) / 1023.0F);
        EntityRenderer<? super LivingEntity> renderer = mc.getEntityRenderDispatcher().getRenderer(entity);
        rendering = true;
        try {
            renderer.render(entity, entity.getYRot(), partial, pose, slice.wrap(event.getMultiBufferSource()), event.getPackedLight());
        } finally {
            rendering = false;
        }
    }

    /** Фаза копится от движения: путь и повороты за тик. */
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.isPaused()) {
            if (mc.level == null) TRACKS.clear();
            return;
        }
        TRACKS.keySet().retainAll(FourD.clientIds());
        for (int id : FourD.clientIds()) {
            Entity e = mc.level.getEntity(id);
            if (!(e instanceof LivingEntity living)) continue;
            Track t = TRACKS.get(id);
            if (t == null) {
                t = new Track();
                t.x = e.getX();
                t.y = e.getY();
                t.z = e.getZ();
                t.yaw = living.yBodyRot;
                t.head = living.getYHeadRot();
                TRACKS.put(id, t);
            }
            double dx = e.getX() - t.x, dy = e.getY() - t.y, dz = e.getZ() - t.z;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            // телепорт — не шаг
            if (dist > 8.0) dist = 0.0;
            float turn = Math.abs(Mth.wrapDegrees(living.yBodyRot - t.yaw)) + Math.abs(Mth.wrapDegrees(living.getYHeadRot() - t.head));
            t.prevPhase = t.phase;
            t.phase += (float) dist * PER_BLOCK + turn * PER_DEGREE;
            t.speed = Mth.lerp(0.3F, t.speed, (float) dist);
            t.x = e.getX();
            t.y = e.getY();
            t.z = e.getZ();
            t.yaw = living.yBodyRot;
            t.head = living.getYHeadRot();
        }
    }

    @SubscribeEvent
    public static void onNameTag(RenderNameTagEvent event) {
        if (FourD.in(event.getEntity())) event.setCanRender(TriState.FALSE);
    }
}
