package com.invfix.fourd.client;

import com.invfix.fourd.FourD;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLivingEvent;
import net.neoforged.neoforge.client.event.RenderNameTagEvent;
import net.neoforged.neoforge.common.util.TriState;
import org.joml.Vector3f;

/**
 * Смещённый в 4D — для мира (и для себя от третьего лица) только 3D-срез: RenderLivingEvent.Pre
 * отменяется, тот же рендерер рисует модель заново — в буфер, оставляющий слой среза (FourDSlice).
 * Имени над ним нет, тени тоже (FlatShadowMixin).
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class FourDRender {

    private static boolean rendering;

    private FourDRender() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRenderPre(RenderLivingEvent.Pre<?, ?> event) {
        if (rendering || event.isCanceled()) return;
        LivingEntity entity = event.getEntity();
        Minecraft mc = Minecraft.getInstance();
        if (!FourD.in(entity) || mc.level == null) return;
        event.setCanceled(true);
        float partial = event.getPartialTick();
        PoseStack pose = event.getPoseStack();
        // поза сейчас — сдвиг к ногам относительно камеры: центр тела — над ними
        Vector3f feet = pose.last().pose().getTranslation(new Vector3f());
        float time = (mc.level.getGameTime() % 24000L + partial) / 20.0F;
        FourDSlice slice = new FourDSlice(feet.x, feet.y + entity.getBbHeight() * 0.5F, feet.z, time,
                (entity.getUUID().hashCode() & 1023) / 1023.0F);
        EntityRenderer<? super LivingEntity> renderer = mc.getEntityRenderDispatcher().getRenderer(entity);
        rendering = true;
        try {
            renderer.render(entity, entity.getYRot(), partial, pose, slice.wrap(event.getMultiBufferSource()), event.getPackedLight());
        } finally {
            rendering = false;
        }
    }

    @SubscribeEvent
    public static void onNameTag(RenderNameTagEvent event) {
        if (FourD.in(event.getEntity())) event.setCanRender(TriState.FALSE);
    }
}
