package com.invfix.fourd.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxScreen;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/**
 * Шаг по четвёртой координате — для себя, на {@link #LENGTH} с: бело-фиолетовая вспышка, три кадра
 * спектральных режимов композита (35 — изометрический каркас тессеракта, 33 — призма), зум-размытие,
 * аберрация и тряска. Туда и обратно — одинаково, обратно — каркас в конце.
 */
@OnlyIn(Dist.CLIENT)
final class FourDShiftFx extends FxEffect {

    private static final float LENGTH = 0.5F;
    private static final float FRAME = 1.0F / 15.0F;
    private static final int[] IN = {35, 33, 35};
    private static final int[] OUT = {33, 35, 33};

    private final boolean in;

    FourDShiftFx(boolean in) {
        this.in = in;
    }

    @Override
    protected int duration() {
        return (int) Math.ceil(LENGTH * 20.0F) + 1;
    }

    @Override
    public Vec3 focus() {
        return FxManager.camera();
    }

    @Override
    public double range() {
        return Double.MAX_VALUE;
    }

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        float t = ticks(frame) / 20.0F;
        if (t >= LENGTH) return;
        if (t < 0.04F) screen.addFlash(0xE8D8FF, 2.2F);
        Vec3 ahead = frame.camera().add(FxManager.cameraForward().scale(4.0));
        impactSequence(screen, t - 0.03F, ahead, 0.85F, FRAME, in ? IN : OUT);
        screen.addFlash(0x8A4CFF, (float) Math.exp(-t * 9.0) * 0.9F);
        screen.zoomBlur = Math.max(screen.zoomBlur, window(t, 0.0F, 0.03F, 0.12F, 0.3F) * 0.8F);
        screen.aberration = Math.max(screen.aberration, window(t, 0.0F, 0.03F, 0.2F, LENGTH) * 1.4F);
        screen.shake = Math.max(screen.shake, window(t, 0.0F, 0.02F, 0.1F, 0.3F) * 0.35F);
        screen.desaturate = Math.max(screen.desaturate, Mth.clamp(1.0F - t / LENGTH, 0.0F, 1.0F) * 0.5F);
    }
}
