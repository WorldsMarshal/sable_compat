package com.invfix.fourd.client;

import com.invfix.fourd.FourD;
import com.invfix.fourd.FourDPackets;
import com.invfix.fx.FxManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 4D Offset на клиенте.
 *
 * Движение своего игрока в 4D ({@link #move}, из LocalPlayer#move): горизонталь — как есть, сквозь стены;
 * по вертикали — гравитация, и встаёт на верх любого блока, через который проходит вниз (пол, крыша,
 * слой породы); зажат Пробел — поднимается, Shift — опускается сквозь перекрытия ({@link #VERTICAL} блока
 * за тик). В полёте (творческий) — как обычно.
 *
 * Прицел ({@link #pick}, после GameRenderer#pick): стены не мешают — существо в пределах удара, иначе
 * контейнер (из присланных сервером) в {@link FourD#CONTAINER_RANGE} блоках; блоки не выбираются (ломать и
 * ставить из 4D нечем). ПКМ по существу — его карманы, по контейнеру — открыть; ЛКМ по существу — удар.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class FourDClient {

    /** Подъём и спуск сквозь перекрытия, блоков за тик. */
    static final double VERTICAL = 0.3;
    /** Вспышка смещения — после комикс-панели щелчка, тиков. */
    private static final int SHIFT_AFTER_COMIC = 11;

    /** Контейнеры вокруг и их содержимое (сервер, раз в полсекунды). */
    static final Map<BlockPos, List<ItemStack>> BOXES = new HashMap<>();

    private static ClientLevel lastLevel;

    private FourDClient() {}

    public static void onState(FourDPackets.State pkt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        boolean was = FourD.inClient(pkt.entityId());
        FourD.setClient(pkt.entityId(), pkt.on());
        Entity e = mc.level.getEntity(pkt.entityId());
        if (e != null) e.refreshDimensions();
        if (mc.player != null && pkt.entityId() == mc.player.getId()) {
            mc.player.noPhysics = pkt.on() || mc.player.isSpectator();
            if (!pkt.on()) BOXES.clear();
            // туда — после комикс-панели щелчка (она идёт с этого же мгновения, FlatComicFx)
            if (was != pkt.on()) FxManager.add(new FourDShiftFx(pkt.on(), pkt.on() ? SHIFT_AFTER_COMIC : 0));
            if (pkt.on()) FourDVisionFx.keepAlive(mc.level);
        }
    }

    public static void onContents(FourDPackets.Contents pkt) {
        BOXES.clear();
        for (FourDPackets.Box b : pkt.boxes()) BOXES.put(b.pos(), b.items());
    }

    /** Свой игрок смещён в 4D. */
    static boolean self() {
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null && FourD.in(mc.player);
    }

    // ── движение ─────────────────────────────────────────────────────────────

    /** true — шаг сделан здесь (LocalPlayer#move отменяется). */
    public static boolean move(LocalPlayer p, MoverType type, Vec3 d) {
        if (type != MoverType.SELF || !FourD.in(p) || p.getAbilities().flying || p.isPassenger()) return false;
        boolean up = p.input != null && p.input.jumping;
        boolean down = p.input != null && p.input.shiftKeyDown;
        Vec3 v = p.getDeltaMovement();
        double x0 = p.getX(), y0 = p.getY(), z0 = p.getZ();
        double x1 = x0 + d.x, z1 = z0 + d.z;
        double y1;
        boolean ground = false;
        if (up != down) {
            y1 = y0 + (up ? VERTICAL : -VERTICAL);
            p.setDeltaMovement(v.x, 0.0, v.z);
        } else if (d.y <= 0.0) {
            y1 = y0 + d.y;
            double top = floorBetween(p, x1, z1, y1, y0);
            if (!Double.isNaN(top)) {
                y1 = top;
                ground = true;
                p.setDeltaMovement(v.x, 0.0, v.z);
                p.resetFallDistance();
            }
        } else {
            y1 = y0 + d.y;
        }
        p.setPos(x1, y1, z1);
        p.horizontalCollision = false;
        p.verticalCollision = ground;
        p.verticalCollisionBelow = ground;
        p.minorHorizontalCollision = false;
        p.setOnGroundWithMovement(ground, new Vec3(x1 - x0, y1 - y0, z1 - z0));
        return true;
    }

    /**
     * Самый высокий верх блока под ногами (по всей ширине хитбокса) между from (ниже) и to (выше) —
     * через него шаг вниз прошёл; NaN — не было.
     */
    private static double floorBetween(LocalPlayer p, double x, double z, double from, double to) {
        ClientLevel level = (ClientLevel) p.level();
        double hw = p.getBbWidth() / 2.0 - 1.0E-3;
        int x0 = Mth.floor(x - hw), x1 = Mth.floor(x + hw);
        int z0 = Mth.floor(z - hw), z1 = Mth.floor(z + hw);
        int yLow = Mth.floor(from - 1.0E-7) - 1, yHigh = Mth.floor(to);
        double best = Double.NaN;
        CollisionContext ctx = CollisionContext.of(p);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int bx = x0; bx <= x1; bx++) {
            for (int bz = z0; bz <= z1; bz++) {
                for (int by = yHigh; by >= yLow; by--) {
                    pos.set(bx, by, bz);
                    BlockState state = level.getBlockState(pos);
                    if (state.isAir()) continue;
                    VoxelShape shape = state.getCollisionShape(level, pos, ctx);
                    if (shape.isEmpty()) continue;
                    // верх части формы, что под хитбоксом по горизонтали
                    AABB foot = new AABB(x - hw - bx, -1.0E3, z - hw - bz, x + hw - bx, 1.0E3, z + hw - bz);
                    double top = Double.NaN;
                    for (AABB a : shape.toAabbs()) {
                        if (!a.intersects(foot)) continue;
                        if (Double.isNaN(top) || a.maxY > top) top = a.maxY;
                    }
                    if (Double.isNaN(top)) continue;
                    double t = by + top;
                    if (t >= from - 1.0E-7 && t <= to + 1.0E-7 && (Double.isNaN(best) || t > best)) best = t;
                }
            }
        }
        return best;
    }

    // ── прицел ───────────────────────────────────────────────────────────────

    /** После обычного прицела: в 4D — свой, сквозь стены. */
    public static void pick(Minecraft mc, float partial) {
        LocalPlayer player = mc.player;
        Entity cam = mc.getCameraEntity();
        if (player == null || cam != player || mc.level == null || !FourD.in(player)) return;
        Vec3 eye = cam.getEyePosition(partial);
        Vec3 look = cam.getViewVector(partial);
        double er = player.entityInteractionRange();
        Vec3 end = eye.add(look.scale(er));
        AABB box = cam.getBoundingBox().expandTowards(look.scale(er)).inflate(1.0);
        EntityHitResult eh = ProjectileUtil.getEntityHitResult(cam, eye, end, box,
                e -> !e.isSpectator() && e.isPickable(), er * er);
        double ed = eh != null ? eh.getLocation().distanceTo(eye) : Double.MAX_VALUE;

        BlockHitResult bh = null;
        double bd = FourD.CONTAINER_RANGE;
        Vec3 far = eye.add(look.scale(FourD.CONTAINER_RANGE));
        List<AABB> unit = List.of(new AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0));
        for (BlockPos pos : BOXES.keySet()) {
            if (mc.level.getBlockEntity(pos) == null) continue;
            BlockHitResult hit = AABB.clip(unit, eye, far, pos);
            if (hit == null) continue;
            double d = hit.getLocation().distanceTo(eye);
            if (d < bd) {
                bd = d;
                bh = hit;
            }
        }
        HitResult result;
        if (eh != null && ed <= bd) result = eh;
        else if (bh != null) result = bh;
        else result = BlockHitResult.miss(end, Direction.getNearest(look.x, look.y, look.z), BlockPos.containing(end));
        mc.hitResult = result;
        mc.crosshairPickEntity = result instanceof EntityHitResult e ? e.getEntity() : null;
    }

    @SubscribeEvent
    public static void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        Minecraft mc = Minecraft.getInstance();
        if (!self()) return;
        HitResult hit = mc.hitResult;
        if (event.isUseItem()) {
            if (hit instanceof EntityHitResult eh) {
                PacketDistributor.sendToServer(new FourDPackets.Pockets(eh.getEntity().getId()));
                event.setCanceled(true);
            } else if (hit instanceof BlockHitResult bh && bh.getType() == HitResult.Type.BLOCK) {
                PacketDistributor.sendToServer(new FourDPackets.Open(bh.getBlockPos()));
                event.setCanceled(true);
            }
        } else if (event.isAttack() && hit != null && hit.getType() == HitResult.Type.BLOCK) {
            // ломать из 4D нечем
            event.setSwingHand(false);
            event.setCanceled(true);
        }
    }

    // ── жизнь ────────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != lastLevel) {
            lastLevel = mc.level;
            FourD.clearClient();
            BOXES.clear();
        }
        if (mc.level != null && self()) FourDVisionFx.keepAlive(mc.level);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        FourD.clearClient();
        BOXES.clear();
        lastLevel = null;
    }
}
