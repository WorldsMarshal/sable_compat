package com.invfix.fourd.client;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Зрение из 4D: то, что из 3D скрыто стенами, — в свою текстуру, без мира (four_d.fsh кладёт её поверх
 * полупрозрачного мира):
 *  - каркас граней блоков вокруг ({@link #RADIUS} блоков) — только рёбра, где поверхность ломается
 *    (контуры пещер, комнат, рельефа), без сетки по ровным плоскостям; ярче вблизи;
 *  - контейнеры (присланные сервером) — их модели, а над каждым по кругу плывёт то, что в нём лежит;
 *  - существа в {@link #ENTITY_RANGE} блоках — моделями, как их рисует игра.
 * Всё освещено полностью: в толще камня темно, а смотреть надо.
 *
 * Как UnlimitedVoidEntities: AFTER_WEATHER, свой буфер вершин, запись глубины включается на время
 * рисования, потом — как было, и привязанный буфер кадра с областью вывода — тоже.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class FourDVision {

    static final int RADIUS = 10;
    static final double ENTITY_RANGE = 48.0;
    /** Перестроить каркас: сместилась на блок или прошло столько тиков. */
    private static final int REBUILD_TICKS = 20;

    private static final org.slf4j.Logger LOGGER = com.mojang.logging.LogUtils.getLogger();
    private static boolean errorLogged;

    private static TextureTarget target;
    private static boolean valid;
    private static ByteBufferBuilder bytes;
    private static MultiBufferSource.BufferSource buffers;

    /** Каркас: по 6 чисел на ребро (начало, конец), относительно builtAt. */
    private static float[] edges = new float[0];
    private static int edgeCount;
    private static BlockPos builtAt;
    private static long builtTick = Long.MIN_VALUE;
    private static ClientLevel builtLevel;

    private FourDVision() {}

    /** Текстура этого кадра; 0 — не рисовалась. */
    static int texture() {
        return valid && target != null ? target.getColorTextureId() : 0;
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_WEATHER) return;
        if (com.invfix.portal.client.PortalPassCompat.inPortalPass()) return;
        valid = false;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || !FourDClient.self()) return;
        Camera camera = event.getCamera();
        RenderTarget main = mc.getMainRenderTarget();
        float fogStart = RenderSystem.getShaderFogStart();
        float fogEnd = RenderSystem.getShaderFogEnd();
        EntityRenderDispatcher dispatcher = mc.getEntityRenderDispatcher();
        boolean depthWrite = org.lwjgl.opengl.GL11.glGetBoolean(org.lwjgl.opengl.GL11.GL_DEPTH_WRITEMASK);
        int prevFbo = org.lwjgl.opengl.GL11.glGetInteger(org.lwjgl.opengl.GL30.GL_FRAMEBUFFER_BINDING);
        int[] viewport = new int[4];
        org.lwjgl.opengl.GL11.glGetIntegerv(org.lwjgl.opengl.GL11.GL_VIEWPORT, viewport);
        try {
            RenderSystem.depthMask(true);
            if (target == null) {
                target = new TextureTarget(main.width, main.height, true, Minecraft.ON_OSX);
            } else if (target.width != main.width || target.height != main.height) {
                target.resize(main.width, main.height, Minecraft.ON_OSX);
            }
            target.setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
            target.clear(Minecraft.ON_OSX);
            target.bindWrite(true);
            if (buffers == null) {
                bytes = new ByteBufferBuilder(1 << 18);
                buffers = MultiBufferSource.immediate(bytes);
            }
            RenderSystem.setShaderFogStart(Float.MAX_VALUE);
            RenderSystem.setShaderFogEnd(Float.MAX_VALUE);
            dispatcher.setRenderShadow(false);
            float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
            draw(mc, level, camera, partial, event.getPoseStack(), dispatcher);
            valid = true;
        } catch (Throwable e) {
            valid = false;
            if (!errorLogged) {
                errorLogged = true;
                LOGGER.error("[4D Offset] не удалось нарисовать зрение", e);
            }
            try {
                if (bytes != null) bytes.close();
            } catch (Throwable ignoredToo) {}
            bytes = null;
            buffers = null;
        } finally {
            dispatcher.setRenderShadow(true);
            RenderSystem.depthMask(depthWrite);
            RenderSystem.setShaderFogStart(fogStart);
            RenderSystem.setShaderFogEnd(fogEnd);
            com.mojang.blaze3d.platform.GlStateManager._glBindFramebuffer(org.lwjgl.opengl.GL30.GL_FRAMEBUFFER, prevFbo);
            com.mojang.blaze3d.platform.GlStateManager._viewport(viewport[0], viewport[1], viewport[2], viewport[3]);
        }
    }

    private static void draw(Minecraft mc, ClientLevel level, Camera camera, float partial, PoseStack pose,
                             EntityRenderDispatcher dispatcher) {
        Vec3 cam = camera.getPosition();
        float time = (level.getGameTime() % 24000L + partial) / 20.0F;
        int light = LightTexture.FULL_BRIGHT;

        // ── каркас ──
        rebuildIfNeeded(mc, level);
        if (edgeCount > 0) {
            VertexConsumer lines = buffers.getBuffer(RenderType.lines());
            PoseStack.Pose last = pose.last();
            double r = RADIUS;
            // рёбра — относительно блока, где строились (float не теряет точность вдали от нуля мира)
            double bx = builtAt.getX() - cam.x, by = builtAt.getY() - cam.y, bz = builtAt.getZ() - cam.z;
            for (int i = 0; i < edgeCount; i++) {
                int o = i * 6;
                float x0 = (float) (edges[o] + bx), y0 = (float) (edges[o + 1] + by), z0 = (float) (edges[o + 2] + bz);
                float x1 = (float) (edges[o + 3] + bx), y1 = (float) (edges[o + 4] + by), z1 = (float) (edges[o + 5] + bz);
                float mx = (x0 + x1) * 0.5F, my = (y0 + y1) * 0.5F, mz = (z0 + z1) * 0.5F;
                double d = Math.sqrt(mx * mx + my * my + mz * mz);
                float k = (float) Mth.clamp(1.0 - d / r, 0.0, 1.0);
                if (k <= 0.0F) continue;
                // вблизи — бирюзово-белые, дальше — фиолетовые, бегущая по высоте волна
                float wave = 0.5F + 0.5F * Mth.sin((float) ((edges[o + 1] + builtAt.getY() % 64) * 0.9 - time * 2.2));
                float cr = Mth.lerp(k, 0.55F, 0.75F), cg = Mth.lerp(k, 0.3F, 0.95F), cb = 1.0F;
                float a = k * (0.45F + 0.35F * wave);
                float nx = x1 - x0, ny = y1 - y0, nz = z1 - z0;
                lines.addVertex(last, x0, y0, z0).setColor(cr, cg, cb, a).setNormal(last, nx, ny, nz);
                lines.addVertex(last, x1, y1, z1).setColor(cr, cg, cb, a).setNormal(last, nx, ny, nz);
            }
        }

        // ── контейнеры и их содержимое ──
        for (Map.Entry<BlockPos, List<ItemStack>> box : FourDClient.BOXES.entrySet()) {
            BlockPos pos = box.getKey();
            BlockEntity be = level.getBlockEntity(pos);
            if (be == null) continue;
            BlockState state = level.getBlockState(pos);
            pose.pushPose();
            pose.translate(pos.getX() - cam.x, pos.getY() - cam.y, pos.getZ() - cam.z);
            try {
                if (state.getRenderShape() == RenderShape.MODEL) {
                    mc.getBlockRenderer().renderSingleBlock(state, pose, buffers, light, OverlayTexture.NO_OVERLAY);
                } else {
                    renderBlockEntity(mc, be, partial, pose, light);
                }
            } catch (Throwable ex) {
                logOnce(ex);
            }
            List<ItemStack> items = box.getValue();
            int n = items.size();
            for (int i = 0; i < n; i++) {
                float ang = time * 0.9F + i * Mth.TWO_PI / n + (pos.hashCode() & 15);
                float rad = n == 1 ? 0.0F : 0.32F + 0.03F * n;
                pose.pushPose();
                pose.translate(0.5 + Mth.cos(ang) * rad, 1.25 + 0.06 * Mth.sin(time * 2.0F + i), 0.5 + Mth.sin(ang) * rad);
                pose.mulPose(Axis.YP.rotation(-ang + time));
                pose.scale(0.42F, 0.42F, 0.42F);
                try {
                    mc.getItemRenderer().renderStatic(items.get(i), ItemDisplayContext.FIXED, light, OverlayTexture.NO_OVERLAY,
                            pose, buffers, level, i);
                } catch (Throwable ex) {
                    logOnce(ex);
                }
                pose.popPose();
            }
            pose.popPose();
        }

        // ── существа ──
        Entity self = mc.getCameraEntity();
        boolean showSelf = camera.isDetached() || !mc.options.getCameraType().isFirstPerson();
        List<Entity> found = level.getEntities((Entity) null, new AABB(cam, cam).inflate(ENTITY_RANGE),
                e -> e.distanceToSqr(cam) < ENTITY_RANGE * ENTITY_RANGE);
        found.sort((a, b) -> Double.compare(b.distanceToSqr(cam), a.distanceToSqr(cam)));
        for (Entity e : found) {
            if ((e == self && !showSelf) || e.isRemoved() || e.isInvisibleTo(mc.player)) continue;
            double x = Mth.lerp(partial, e.xOld, e.getX()) - cam.x;
            double y = Mth.lerp(partial, e.yOld, e.getY()) - cam.y;
            double z = Mth.lerp(partial, e.zOld, e.getZ()) - cam.z;
            float yaw = Mth.lerp(partial, e.yRotO, e.getYRot());
            try {
                dispatcher.render(e, x, y, z, yaw, partial, pose, buffers, light);
            } catch (Throwable ex) {
                logOnce(ex);
            }
        }
        buffers.endBatch();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void renderBlockEntity(Minecraft mc, BlockEntity be, float partial, PoseStack pose, int light) {
        BlockEntityRenderer renderer = mc.getBlockEntityRenderDispatcher().getRenderer(be);
        if (renderer != null) renderer.render(be, partial, pose, buffers, light, OverlayTexture.NO_OVERLAY);
    }

    private static void logOnce(Throwable ex) {
        if (!errorLogged) {
            errorLogged = true;
            LOGGER.error("[4D Offset] не удалось нарисовать часть зрения", ex);
        }
    }

    // ── каркас граней ────────────────────────────────────────────────────────

    private static void rebuildIfNeeded(Minecraft mc, ClientLevel level) {
        BlockPos at = mc.player.blockPosition();
        long now = level.getGameTime();
        if (level == builtLevel && at.equals(builtAt) && now - builtTick < REBUILD_TICKS && now >= builtTick) return;
        builtLevel = level;
        builtAt = at;
        builtTick = now;
        build(level, at);
    }

    /**
     * Рёбра поверхности блоков вокруг: у каждой открытой грани полного блока — те её края, за которыми
     * поверхность не продолжается той же плоскостью (выступ, угол, обрыв). Повторы — по ключу ребра.
     */
    private static void build(ClientLevel level, BlockPos c) {
        int r = RADIUS + 1;
        int size = 2 * r + 1;
        boolean[] solid = new boolean[size * size * size];
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -r; dx <= r; dx++)
            for (int dy = -r; dy <= r; dy++)
                for (int dz = -r; dz <= r; dz++) {
                    m.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    BlockState s = level.getBlockState(m);
                    solid[((dx + r) * size + (dy + r)) * size + (dz + r)] = !s.isAir() && s.isCollisionShapeFullBlock(level, m);
                }
        Set<Long> seen = new HashSet<>();
        float[] out = new float[6 * 4096];
        int count = 0;
        int lim = RADIUS;
        for (int dx = -lim; dx <= lim; dx++)
            for (int dy = -lim; dy <= lim; dy++)
                for (int dz = -lim; dz <= lim; dz++) {
                    if (dx * dx + dy * dy + dz * dz > lim * lim) continue;
                    if (!solid(solid, size, r, dx, dy, dz)) continue;
                    for (Direction n : Direction.values()) {
                        if (solid(solid, size, r, dx + n.getStepX(), dy + n.getStepY(), dz + n.getStepZ())) continue;
                        for (Direction d : Direction.values()) {
                            if (d.getAxis() == n.getAxis()) continue;
                            boolean cont = solid(solid, size, r, dx + d.getStepX(), dy + d.getStepY(), dz + d.getStepZ())
                                    && !solid(solid, size, r, dx + d.getStepX() + n.getStepX(), dy + d.getStepY() + n.getStepY(),
                                    dz + d.getStepZ() + n.getStepZ());
                            if (cont) continue;
                            // ребро: на стороне n и стороне d, вдоль третьей оси
                            int[] p = {dx, dy, dz};
                            int an = n.getAxis().ordinal(), ad = d.getAxis().ordinal(), aa = 3 - an - ad;
                            if (n.getAxisDirection() == Direction.AxisDirection.POSITIVE) p[an]++;
                            if (d.getAxisDirection() == Direction.AxisDirection.POSITIVE) p[ad]++;
                            long key = (((long) (p[0] + 64) * 128 + (p[1] + 64)) * 128 + (p[2] + 64)) * 4 + aa;
                            if (!seen.add(key)) continue;
                            if (count * 6 + 6 > out.length) out = java.util.Arrays.copyOf(out, out.length * 2);
                            int o = count * 6;
                            out[o] = p[0];
                            out[o + 1] = p[1];
                            out[o + 2] = p[2];
                            p[aa]++;
                            out[o + 3] = p[0];
                            out[o + 4] = p[1];
                            out[o + 5] = p[2];
                            count++;
                        }
                    }
                }
        edges = out;
        edgeCount = count;
    }

    private static boolean solid(boolean[] solid, int size, int r, int dx, int dy, int dz) {
        if (dx < -r || dx > r || dy < -r || dy > r || dz < -r || dz > r) return false;
        return solid[((dx + r) * size + (dy + r)) * size + (dz + r)];
    }
}
