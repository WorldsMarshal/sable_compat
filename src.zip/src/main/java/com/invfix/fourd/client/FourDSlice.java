package com.invfix.fourd.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/**
 * Трёхмерный срез четырёхмерного тела: модель смещённого в 4D, как её видит мир, — только та её часть,
 * что лежит в слое A (между двумя параллельными плоскостями), за вычетом слоя B («дыры» другого
 * направления — он рвёт срез на куски).
 *
 * Слои задаёт фаза — сколько тело «сдвинулось по четвёртой оси»: она копится от движения (пройденный
 * путь, повороты; FourDRender), на месте срез замирает. С фазой ходят оси слоёв, середина A уходит за
 * пределы тела (тогда модель пропадает целиком), толщина A сжимается, «дыра» B то раскрывается, то
 * исчезает; срез пульсирует размером. На скорости слой ещё тоньше.
 *
 * Каждая грань модели обрезается по плоскостям точно (Сазерленд — Ходжмен), края среза подсвечены
 * фиолетовым. Вершины — в пространстве позы рендера (относительно камеры); центр тела в нём задаётся
 * снаружи.
 */
@OnlyIn(Dist.CLIENT)
final class FourDSlice {

    /** Ширина подсвеченной кромки у плоскостей среза, блоки. */
    private static final float RIM = 0.1F;
    private static final int MAX = 12;

    private final float cx, cy, cz;
    /** Слой A (видимый) и B (дыра): оси, середины, полутолщины. */
    private final float ax, ay, az, midA, halfA;
    private final float bx, by, bz, midB, halfB;
    private final float scale;

    /**
     * @param cx центр тела (пространство позы)
     * @param phase сдвиг по четвёртой оси (копится от движения)
     * @param speed скорость, блоков за тик
     * @param seed своя фаза у каждого, 0..1
     */
    FourDSlice(float cx, float cy, float cz, float phase, float speed, float seed) {
        this.cx = cx;
        this.cy = cy;
        this.cz = cz;
        float t = phase + seed * 17.0F;
        // ось A ходит по сфере
        float a = 0.6F + 0.55F * Mth.sin(t * 0.43F);
        float b = t * 0.61F;
        this.ax = Mth.sin(a) * Mth.cos(b);
        this.ay = Mth.cos(a);
        this.az = Mth.sin(a) * Mth.sin(b);
        // середина A — далеко за тело: временами срез пустой
        this.midA = 1.05F * Mth.sin(t * 0.79F) + 0.45F * Mth.sin(t * 1.93F + 0.7F);
        float thin = 1.0F - 0.45F * Mth.clamp(speed / 0.3F, 0.0F, 1.0F);
        this.halfA = (0.5F + 0.35F * Mth.sin(t * 0.57F + 1.3F)) * thin;
        // ось B — своя, примерно поперёк A
        float c = 1.2F + 0.6F * Mth.sin(t * 0.37F + 2.0F);
        float d = -t * 0.83F + 1.7F;
        this.bx = Mth.sin(c) * Mth.cos(d);
        this.by = Mth.cos(c);
        this.bz = Mth.sin(c) * Mth.sin(d);
        this.midB = 0.55F * Mth.sin(t * 1.11F + 0.4F);
        this.halfB = Math.max(0.0F, 0.32F * Mth.sin(t * 0.71F + 2.4F) + 0.06F);
        this.scale = 1.0F + 0.12F * Mth.sin(t * 1.7F);
    }

    MultiBufferSource wrap(MultiBufferSource source) {
        return type -> type.mode() == VertexFormat.Mode.QUADS ? new Consumer(source.getBuffer(type)) : source.getBuffer(type);
    }

    private final class Consumer implements VertexConsumer {

        private final VertexConsumer out;
        // до 4 вершин грани, после обрезки — до MAX
        private final float[] x = new float[4], y = new float[4], z = new float[4], u = new float[4], v = new float[4];
        private final int[] color = new int[4], overlay = new int[4], light = new int[4];
        private final float[] nx = new float[4], ny = new float[4], nz = new float[4];
        private int count;
        private final float[][] a = new float[MAX][7], b = new float[MAX][7], c = new float[MAX][7];

        Consumer(VertexConsumer out) {
            this.out = out;
        }

        private int cur() {
            return Math.max(0, count - 1);
        }

        @Override
        public VertexConsumer addVertex(float px, float py, float pz) {
            if (count >= 4) flush();
            x[count] = px;
            y[count] = py;
            z[count] = pz;
            color[count] = -1;
            overlay[count] = 0;
            light[count] = 0;
            u[count] = v[count] = 0.0F;
            nx[count] = 0.0F;
            ny[count] = 1.0F;
            nz[count] = 0.0F;
            count++;
            return this;
        }

        @Override
        public VertexConsumer setColor(int r, int g, int bl, int al) {
            color[cur()] = (al & 255) << 24 | (r & 255) << 16 | (g & 255) << 8 | (bl & 255);
            return this;
        }

        @Override
        public VertexConsumer setUv(float uu, float vv) {
            u[cur()] = uu;
            v[cur()] = vv;
            return this;
        }

        @Override
        public VertexConsumer setUv1(int p, int q) {
            overlay[cur()] = (p & 65535) | (q & 65535) << 16;
            return this;
        }

        @Override
        public VertexConsumer setUv2(int p, int q) {
            light[cur()] = (p & 65535) | (q & 65535) << 16;
            return this;
        }

        @Override
        public VertexConsumer setNormal(float x0, float y0, float z0) {
            int i = cur();
            nx[i] = x0;
            ny[i] = y0;
            nz[i] = z0;
            // нормаль — последняя у вершины: грань собрана
            if (count >= 4) flush();
            return this;
        }

        @Override
        public void addVertex(float px, float py, float pz, int c, float uu, float vv, int ov, int li,
                              float x0, float y0, float z0) {
            if (count >= 4) flush();
            x[count] = px;
            y[count] = py;
            z[count] = pz;
            color[count] = c;
            u[count] = uu;
            v[count] = vv;
            overlay[count] = ov;
            light[count] = li;
            nx[count] = x0;
            ny[count] = y0;
            nz[count] = z0;
            count++;
            if (count >= 4) flush();
        }

        private float alongA(float px, float py, float pz) {
            return (px - cx) * ax + (py - cy) * ay + (pz - cz) * az - midA;
        }

        private float alongB(float px, float py, float pz) {
            return (px - cx) * bx + (py - cy) * by + (pz - cz) * bz - midB;
        }

        private void flush() {
            int k = count;
            count = 0;
            if (k < 4) return;
            // x, y, z, u, v, вдоль A, вдоль B
            for (int i = 0; i < 4; i++) {
                float[] p = a[i];
                p[0] = x[i];
                p[1] = y[i];
                p[2] = z[i];
                p[3] = u[i];
                p[4] = v[i];
                p[5] = alongA(x[i], y[i], z[i]);
                p[6] = alongB(x[i], y[i], z[i]);
            }
            // слой A: -halfA ≤ A ≤ halfA
            int n = clip(a, 4, b, 5, 1.0F, halfA);
            if (n < 3) return;
            n = clip(b, n, a, 5, -1.0F, halfA);
            if (n < 3) return;
            if (halfB <= 0.0F) {
                fan(a, n);
                return;
            }
            // минус слой B: два куска — B ≤ -halfB и B ≥ halfB
            int m = clip(a, n, b, 6, 1.0F, -halfB);
            if (m >= 3) fan(b, m);
            m = clip(a, n, c, 6, -1.0F, -halfB);
            if (m >= 3) fan(c, m);
        }

        /** Веером по четвёркам (последняя вершина повторяется, если их нечётно). */
        private void fan(float[][] poly, int n) {
            for (int i = 1; i + 1 < n; i += 2) {
                emit(poly[0]);
                emit(poly[i]);
                emit(poly[i + 1]);
                emit(poly[Math.min(i + 2, n - 1)]);
            }
        }

        /** Оставить часть многоугольника, где side·p[axis] ≤ limit. */
        private int clip(float[][] in, int n, float[][] out, int axis, float side, float limit) {
            int m = 0;
            for (int i = 0; i < n; i++) {
                float[] p = in[i], q = in[(i + 1) % n];
                float dp = side * p[axis] - limit, dq = side * q[axis] - limit;
                boolean pin = dp <= 0.0F, qin = dq <= 0.0F;
                if (pin && m < MAX) System.arraycopy(p, 0, out[m++], 0, 7);
                if (pin != qin && m < MAX) {
                    float t = dp / (dp - dq);
                    float[] r = out[m++];
                    for (int j = 0; j < 7; j++) r[j] = p[j] + (q[j] - p[j]) * t;
                }
            }
            return m;
        }

        private void emit(float[] p) {
            // пульс размера — вокруг центра тела
            float px = cx + (p[0] - cx) * scale, py = cy + (p[1] - cy) * scale, pz = cz + (p[2] - cz) * scale;
            // у плоскостей среза — фиолетовая кромка
            float edge = Mth.clamp((Math.abs(p[5]) - (halfA - RIM)) / RIM, 0.0F, 1.0F);
            if (halfB > 0.0F) edge = Math.max(edge, Mth.clamp(1.0F - (Math.abs(p[6]) - halfB) / RIM, 0.0F, 1.0F));
            int c = color[0];
            int al = c >>> 24, r = c >> 16 & 255, g = c >> 8 & 255, bl = c & 255;
            r = (int) Mth.lerp(edge, r, 200);
            g = (int) Mth.lerp(edge, g, 120);
            bl = (int) Mth.lerp(edge, bl, 255);
            int li = edge > 0.5F ? 0xF000F0 : light[0];
            out.addVertex(px, py, pz, al << 24 | r << 16 | g << 8 | bl, p[3], p[4], overlay[0], li, nx[0], ny[0], nz[0]);
        }
    }
}
