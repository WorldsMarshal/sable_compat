package com.invfix.fourd.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/**
 * Трёхмерный срез четырёхмерного тела: модель смещённого в 4D, как её видит мир, — только та её часть,
 * что лежит в слое между двумя параллельными плоскостями. Слой (его ось, середина и толщина) всё время
 * плывёт — тело «дышит»: части то проступают, то уходят; весь срез ещё и пульсирует размером.
 *
 * Каждая грань модели обрезается по обеим плоскостям точно (Сазерленд — Ходжмен), края среза
 * подсвечены фиолетовым. Вершины — в пространстве позы рендера (относительно камеры); центр тела в нём
 * задаётся снаружи.
 */
@OnlyIn(Dist.CLIENT)
final class FourDSlice {

    /** Ширина подсвеченной кромки у плоскостей среза, блоки. */
    private static final float RIM = 0.12F;

    private final float cx, cy, cz;
    private final float ax, ay, az;
    private final float mid, half, scale;

    /**
     * @param cx центр тела (пространство позы)
     * @param time секунды — фаза «дыхания»
     * @param seed своя фаза у каждого
     */
    FourDSlice(float cx, float cy, float cz, float time, float seed) {
        this.cx = cx;
        this.cy = cy;
        this.cz = cz;
        float t = time + seed * 13.0F;
        // ось среза медленно ходит по сфере, чаще — около вертикали
        float a = 0.55F + 0.45F * Mth.sin(t * 0.37F);
        float b = t * 0.53F;
        this.ax = Mth.sin(a) * Mth.cos(b);
        this.ay = Mth.cos(a);
        this.az = Mth.sin(a) * Mth.sin(b);
        this.mid = 0.38F * Mth.sin(t * 1.21F) + 0.12F * Mth.sin(t * 2.9F);
        this.half = 0.62F + 0.3F * Mth.sin(t * 0.83F + 1.0F);
        this.scale = 1.0F + 0.07F * Mth.sin(t * 2.3F);
    }

    MultiBufferSource wrap(MultiBufferSource source) {
        return type -> type.mode() == VertexFormat.Mode.QUADS ? new Consumer(source.getBuffer(type)) : source.getBuffer(type);
    }

    private final class Consumer implements VertexConsumer {

        private final VertexConsumer out;
        // до 4 вершин грани, после обрезки — до 8
        private final float[] x = new float[4], y = new float[4], z = new float[4], u = new float[4], v = new float[4];
        private final int[] color = new int[4], overlay = new int[4], light = new int[4];
        private final float[] nx = new float[4], ny = new float[4], nz = new float[4];
        private int count;
        private final float[][] a = new float[8][7], b = new float[8][7];

        Consumer(VertexConsumer out) {
            this.out = out;
        }

        private int cur() {
            return Math.max(0, count - 1);
        }

        @Override
        public VertexConsumer addVertex(float px, float py, float pz) {
            if (count >= 4) flush();
            x[count] = px;
            y[count] = py;
            z[count] = pz;
            color[count] = -1;
            overlay[count] = 0;
            light[count] = 0;
            u[count] = v[count] = 0.0F;
            nx[count] = 0.0F;
            ny[count] = 1.0F;
            nz[count] = 0.0F;
            count++;
            return this;
        }

        @Override
        public VertexConsumer setColor(int r, int g, int bl, int al) {
            color[cur()] = (al & 255) << 24 | (r & 255) << 16 | (g & 255) << 8 | (bl & 255);
            return this;
        }

        @Override
        public VertexConsumer setUv(float uu, float vv) {
            u[cur()] = uu;
            v[cur()] = vv;
            return this;
        }

        @Override
        public VertexConsumer setUv1(int p, int q) {
            overlay[cur()] = (p & 65535) | (q & 65535) << 16;
            return this;
        }

        @Override
        public VertexConsumer setUv2(int p, int q) {
            light[cur()] = (p & 65535) | (q & 65535) << 16;
            return this;
        }

        @Override
        public VertexConsumer setNormal(float x0, float y0, float z0) {
            int i = cur();
            nx[i] = x0;
            ny[i] = y0;
            nz[i] = z0;
            // нормаль — последняя у вершины: грань собрана
            if (count >= 4) flush();
            return this;
        }

        @Override
        public void addVertex(float px, float py, float pz, int c, float uu, float vv, int ov, int li,
                              float x0, float y0, float z0) {
            if (count >= 4) flush();
            x[count] = px;
            y[count] = py;
            z[count] = pz;
            color[count] = c;
            u[count] = uu;
            v[count] = vv;
            overlay[count] = ov;
            light[count] = li;
            nx[count] = x0;
            ny[count] = y0;
            nz[count] = z0;
            count++;
            if (count >= 4) flush();
        }

        /** Расстояние точки (пространство позы) вдоль оси среза от его середины. */
        private float along(float px, float py, float pz) {
            return (px - cx) * ax + (py - cy) * ay + (pz - cz) * az - mid;
        }

        private void flush() {
            int k = count;
            count = 0;
            if (k < 4) return;
            // x, y, z, u, v, вдоль оси, вес первой вершины (для цвета) — в рабочий массив
            for (int i = 0; i < 4; i++) {
                float[] p = a[i];
                p[0] = x[i];
                p[1] = y[i];
                p[2] = z[i];
                p[3] = u[i];
                p[4] = v[i];
                p[5] = along(x[i], y[i], z[i]);
            }
            int n = clip(a, 4, b, 1.0F);
            if (n < 3) return;
            n = clip(b, n, a, -1.0F);
            if (n < 3) return;
            // веером по четвёркам (последняя вершина повторяется, если их нечётно)
            for (int i = 1; i + 1 < n; i += 2) {
                emit(a[0]);
                emit(a[i]);
                emit(a[i + 1]);
                emit(a[Math.min(i + 2, n - 1)]);
            }
        }

        /** Оставить часть многоугольника, где side·(along) ≤ half. */
        private int clip(float[][] in, int n, float[][] out, float side) {
            int m = 0;
            for (int i = 0; i < n; i++) {
                float[] p = in[i], q = in[(i + 1) % n];
                float dp = side * p[5] - half, dq = side * q[5] - half;
                boolean pin = dp <= 0.0F, qin = dq <= 0.0F;
                if (pin && m < 8) System.arraycopy(p, 0, out[m++], 0, 7);
                if (pin != qin && m < 8) {
                    float t = dp / (dp - dq);
                    float[] r = out[m++];
                    for (int j = 0; j < 7; j++) r[j] = p[j] + (q[j] - p[j]) * t;
                }
            }
            return m;
        }

        private void emit(float[] p) {
            // пульс размера — вокруг центра тела
            float px = cx + (p[0] - cx) * scale, py = cy + (p[1] - cy) * scale, pz = cz + (p[2] - cz) * scale;
            // у плоскостей среза — фиолетовая кромка
            float edge = Mth.clamp((Math.abs(p[5]) - (half - RIM)) / RIM, 0.0F, 1.0F);
            int c = color[0];
            int al = c >>> 24, r = c >> 16 & 255, g = c >> 8 & 255, bl = c & 255;
            r = (int) Mth.lerp(edge, r, 200);
            g = (int) Mth.lerp(edge, g, 120);
            bl = (int) Mth.lerp(edge, bl, 255);
            int li = edge > 0.5F ? 0xF000F0 : light[0];
            out.addVertex(px, py, pz, al << 24 | r << 16 | g << 8 | bl, p[3], p[4], overlay[0], li, nx[0], ny[0], nz[0]);
        }
    }
}
