package com.invfix.fourd;

import com.invfix.flat.Flat;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.Container;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.PlayerEnderChestContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.common.damagesource.DamageContainer;
import net.neoforged.neoforge.event.entity.living.LivingChangeTargetEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingShieldBlockEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 4D Offset на сервере.
 *
 * Клавиша по фронту нажатия: в 3D — щелчок пальцев (звук, вспышка, комикс-панель — FlatPackets.Snap) и
 * смещение в 4D на щелчке в звуке (Flat#CLICK_TICKS); в 4D — вернуться (без щелчка) в ближайшее свободное место
 * ({@link #exitSpot}: сначала стоя, потом ползком, в паре блоков вокруг; негде — сообщение, остаётся в 4D).
 *
 * В 4D:
 *  - без столкновений (noPhysics, FlatPlayerMixin) — ходит сквозь стены; двигается сама (client.FourDClient),
 *    сервер не кикает за «полёт» (FourDFloatAccessor);
 *  - урон — только тот, что идёт сквозь неуязвимость (/kill, пустота); мобы не берут в цель и бросают уже
 *    взятую; огня и удушья нет;
 *  - её удары (и всё, что идёт от неё) — изнутри: мимо брони, чар защиты и щита;
 *  - контейнеры — сквозь стены ({@link #open}, без крышек: FourDLidMixin), карманы существ ({@link #pockets});
 *  - раз в {@link #CONTENTS_TICKS} тиков — что лежит в контейнерах вокруг (для зрения на клиенте).
 */
@EventBusSubscriber(modid = "sable_compat")
public final class FourDHandler {

    static final int CONTENTS_TICKS = 10;
    /** Сколько стопок контейнера показывать над ним. */
    static final int SHOWN_ITEMS = 9;
    private static final int MAX_BOXES = 96;
    /** Выход: на сколько блоков вокруг искать место. */
    private static final int EXIT_RADIUS = 2;

    private static final Map<UUID, Boolean> KEY_DOWN = new HashMap<>();
    /** Щёлкнула, ждёт смещения: тик сервера, когда сместиться. */
    private static final Map<UUID, Long> PENDING = new HashMap<>();

    private FourDHandler() {}

    public static void handleKeyState(ServerPlayer player, boolean pressed) {
        boolean was = Boolean.TRUE.equals(KEY_DOWN.put(player.getUUID(), pressed));
        if (!pressed || was) return;
        try {
            if (FourD.SERVER.contains(player.getUUID())) exit(player);
            else if (!PENDING.containsKey(player.getUUID())) snap(player);
        } catch (Exception ignored) {}
    }

    // ── вход и выход ─────────────────────────────────────────────────────────

    private static boolean canEnter(ServerPlayer player) {
        if (!FourD.eligible(player) || player.isSpectator() || player.isSleeping()) return false;
        if (com.invfix.compat.LovsDowned.downed(player)) return false;
        if (Flat.flat(player)) {
            player.displayClientMessage(Component.literal("§7Из 2D в 4D не сместиться"), true);
            return false;
        }
        return true;
    }

    /** Щелчок: звук, вспышка у руки, комикс-панель; смещение — на щелчке в звуке. */
    private static void snap(ServerPlayer player) {
        if (!canEnter(player)) return;
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player,
                com.invfix.flat.FlatPackets.Snap.of(player, Flat.hand(player, 1.0F)));
        PENDING.put(player.getUUID(), (long) player.getServer().getTickCount() + Flat.CLICK_TICKS);
    }

    private static void enter(ServerPlayer player) {
        if (!canEnter(player)) return;
        player.stopRiding();
        // меню открытого по-обычному контейнера закрыть до входа: в 4D крышки не трогаются
        if (player.containerMenu != player.inventoryMenu) player.closeContainer();
        FourD.SERVER.add(player.getUUID());
        player.noPhysics = true;
        player.resetFallDistance();
        player.clearFire();
        forgetAsTarget(player);
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new FourDPackets.State(player.getId(), true));
        syncContents(player);
    }

    private static void exit(ServerPlayer player) {
        Exit spot = exitSpot(player);
        if (spot == null) {
            player.displayClientMessage(Component.literal("§7Здесь не выйти: вокруг нет места"), true);
            return;
        }
        clear(player);
        if (spot.pos().distanceToSqr(player.position()) > 1.0E-6) {
            player.connection.teleport(spot.pos().x, spot.pos().y, spot.pos().z, player.getYRot(), player.getXRot());
        }
        if (spot.crawl()) player.setPose(Pose.SWIMMING);
    }

    /** Снова 3D на месте (смерть, смена измерения, выход из игры — место ищет вызывающий). */
    private static void clear(ServerPlayer player) {
        if (!FourD.SERVER.contains(player.getUUID())) return;
        // закрыть контейнер ещё в 4D — крышка так и не открывалась, закрываться ей нечего
        if (player.containerMenu != player.inventoryMenu) player.closeContainer();
        FourD.SERVER.remove(player.getUUID());
        player.noPhysics = player.isSpectator();
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new FourDPackets.State(player.getId(), false));
    }

    record Exit(Vec3 pos, boolean crawl) {}

    /**
     * Ближайшее свободное место: сначала где помещается стоя, потом ползком, — в кубе
     * {@link #EXIT_RADIUS} блоков вокруг (сначала само место, потом центры блоков по удалению).
     */
    static Exit exitSpot(ServerPlayer player) {
        Level level = player.level();
        Vec3 at = player.position();
        AABB stand = player.getDimensions(Pose.STANDING).makeBoundingBox(Vec3.ZERO);
        AABB crawl = player.getDimensions(Pose.SWIMMING).makeBoundingBox(Vec3.ZERO);
        if (level.noCollision(player, stand.move(at))) return new Exit(at, false);
        List<Vec3> spots = new ArrayList<>();
        BlockPos base = player.blockPosition();
        int r = EXIT_RADIUS;
        for (int dx = -r; dx <= r; dx++)
            for (int dy = -r; dy <= r; dy++)
                for (int dz = -r; dz <= r; dz++)
                    spots.add(new Vec3(base.getX() + dx + 0.5, base.getY() + dy, base.getZ() + dz + 0.5));
        spots.sort((a, b) -> Double.compare(a.distanceToSqr(at), b.distanceToSqr(at)));
        for (Vec3 p : spots) if (level.noCollision(player, stand.move(p))) return new Exit(p, false);
        if (level.noCollision(player, crawl.move(at))) return new Exit(at, true);
        for (Vec3 p : spots) if (level.noCollision(player, crawl.move(p))) return new Exit(p, true);
        return null;
    }

    // ── контейнеры и карманы ─────────────────────────────────────────────────

    /** Открыть контейнер pos сквозь стены — без крышки и проверки «нечем открыть». */
    static void open(ServerPlayer player, BlockPos pos) {
        if (!FourD.in(player)) return;
        Level level = player.level();
        if (!level.isLoaded(pos)) return;
        double reach = FourD.CONTAINER_RANGE + 1.0;
        if (new AABB(pos).distanceToSqr(player.getEyePosition()) > reach * reach) return;
        BlockEntity be = level.getBlockEntity(pos);
        if (be == null) return;
        BlockState state = level.getBlockState(pos);
        if (be instanceof EnderChestBlockEntity) {
            PlayerEnderChestContainer ender = player.getEnderChestInventory();
            // без «открытого сундука»: его крышка не поднимется
            ender.setActiveChest(null);
            player.openMenu(new SimpleMenuProvider((id, inv, p) -> ChestMenu.threeRows(id, inv, ender),
                    Component.translatable("container.enderchest")));
            return;
        }
        MenuProvider provider = state.getMenuProvider(level, pos);
        if (provider != null) {
            player.openMenu(provider, pos);
            return;
        }
        // меню открывает сам блок (модовые хранилища) — его действием, как по клику
        if (isContainer(level, be)) {
            state.useWithoutItem(level, player, new BlockHitResult(Vec3.atCenterOf(pos), Direction.UP, pos, false));
        }
    }

    /** Залезть в карманы сущности entityId (в пределах удара). */
    static void pockets(ServerPlayer player, int entityId) {
        if (!FourD.in(player)) return;
        Entity e = player.level().getEntity(entityId);
        if (!(e instanceof LivingEntity target) || target == player || !target.isAlive()) return;
        if (!player.canInteractWithEntity(target, 1.5)) return;
        FourDPockets.open(player, target);
    }

    private static boolean isContainer(Level level, BlockEntity be) {
        return be instanceof Container || be instanceof EnderChestBlockEntity || handler(level, be) != null;
    }

    private static IItemHandler handler(Level level, BlockEntity be) {
        try {
            return level.getCapability(Capabilities.ItemHandler.BLOCK, be.getBlockPos(), be.getBlockState(), be, null);
        } catch (Exception e) {
            return null;
        }
    }

    /** Что лежит в контейнере (первые непустые стопки); null — не контейнер. */
    private static List<ItemStack> items(ServerPlayer player, Level level, BlockEntity be) {
        List<ItemStack> out = new ArrayList<>();
        Container c = be instanceof EnderChestBlockEntity ? player.getEnderChestInventory()
                : be instanceof Container cc ? cc : null;
        if (c != null) {
            for (int i = 0; i < c.getContainerSize() && out.size() < SHOWN_ITEMS; i++) {
                ItemStack s = c.getItem(i);
                if (!s.isEmpty()) out.add(s.copy());
            }
            return out;
        }
        IItemHandler h = handler(level, be);
        if (h == null) return null;
        for (int i = 0; i < h.getSlots() && out.size() < SHOWN_ITEMS; i++) {
            ItemStack s = h.getStackInSlot(i);
            if (!s.isEmpty()) out.add(s.copy());
        }
        return out;
    }

    /** Контейнеры в {@link FourD#CONTENTS_RANGE} блоках и их содержимое — игроку. */
    private static void syncContents(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        BlockPos c = player.blockPosition();
        int r = FourD.CONTENTS_RANGE;
        List<FourDPackets.Box> boxes = new ArrayList<>();
        outer:
        for (int cx = (c.getX() - r) >> 4; cx <= (c.getX() + r) >> 4; cx++) {
            for (int cz = (c.getZ() - r) >> 4; cz <= (c.getZ() + r) >> 4; cz++) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    BlockPos pos = be.getBlockPos();
                    if (pos.distSqr(c) > (double) r * r || be.isRemoved()) continue;
                    List<ItemStack> items = items(player, level, be);
                    if (items == null) continue;
                    boxes.add(new FourDPackets.Box(pos.immutable(), items));
                    if (boxes.size() >= MAX_BOXES) break outer;
                }
            }
        }
        PacketDistributor.sendToPlayer(player, new FourDPackets.Contents(boxes));
    }

    // ── урон, мобы ───────────────────────────────────────────────────────────

    /** В 4D её не достать: только то, что идёт сквозь неуязвимость (/kill, пустота). */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !FourD.SERVER.contains(player.getUUID())) return;
        if (!event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) event.setCanceled(true);
    }

    /** Удар из 4D — изнутри: броня и чары защиты цели не гасят его. */
    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onHitFromInside(LivingIncomingDamageEvent event) {
        if (!fromInside(event.getSource().getEntity(), event.getEntity())) return;
        event.addReductionModifier(DamageContainer.Reduction.ARMOR, (container, reduction) -> 0.0F);
        event.addReductionModifier(DamageContainer.Reduction.ENCHANTMENTS, (container, reduction) -> 0.0F);
    }

    /** ...и щит тоже: он снаружи. */
    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onShield(LivingShieldBlockEvent event) {
        if (fromInside(event.getDamageSource().getEntity(), event.getEntity())) event.setBlocked(false);
    }

    private static boolean fromInside(Entity attacker, LivingEntity target) {
        return attacker instanceof ServerPlayer p && p != target && FourD.SERVER.contains(p.getUUID());
    }

    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent event) {
        if (event.getNewAboutToBeSetTarget() instanceof ServerPlayer player && FourD.SERVER.contains(player.getUUID())) {
            event.setNewAboutToBeSetTarget(null);
        }
    }

    /** Мобы рядом бросают игрока как цель. */
    private static void forgetAsTarget(ServerPlayer player) {
        AABB box = player.getBoundingBox().inflate(64.0);
        for (Mob mob : player.serverLevel().getEntitiesOfClass(Mob.class, box)) {
            if (mob.getTarget() == player) mob.setTarget(null);
            try {
                if (mob.getBrain().getMemory(MemoryModuleType.ATTACK_TARGET).filter(t -> t == player).isPresent()) {
                    mob.getBrain().eraseMemory(MemoryModuleType.ATTACK_TARGET);
                }
            } catch (IllegalStateException ignored) {
                // у моба нет такой памяти
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        Long due = PENDING.get(player.getUUID());
        if (due != null && player.getServer() != null && player.getServer().getTickCount() >= due) {
            PENDING.remove(player.getUUID());
            if (!FourD.SERVER.contains(player.getUUID())) enter(player);
        }
        if (!FourD.SERVER.contains(player.getUUID())) return;
        player.noPhysics = true;
        player.resetFallDistance();
        player.clearFire();
        player.setAirSupply(player.getMaxAirSupply());
        // ходит по поверхностям сквозь блоки и поднимается сквозь перекрытия — это не полёт
        if (player.connection instanceof com.invfix.mixin.fourd.FourDFloatAccessor a) a.invfix$setAboveGroundTickCount(0);
        if (player.tickCount % 20 == 0) forgetAsTarget(player);
        if (player.tickCount % CONTENTS_TICKS == 0) syncContents(player);
    }

    // ── жизнь ────────────────────────────────────────────────────────────────

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onDeath(LivingDeathEvent event) {
        if (event.isCanceled() || !(event.getEntity() instanceof ServerPlayer player)) return;
        PENDING.remove(player.getUUID());
        clear(player);
    }

    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (!(event.getTarget() instanceof ServerPlayer target) || !(event.getEntity() instanceof ServerPlayer viewer)) return;
        if (FourD.SERVER.contains(target.getUUID())) {
            PacketDistributor.sendToPlayer(viewer, new FourDPackets.State(target.getId(), true));
        }
    }

    /** Выход из игры — в 3D, в ближайшее свободное (не сохраниться в стене); негде — как есть. */
    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        KEY_DOWN.remove(player.getUUID());
        PENDING.remove(player.getUUID());
        if (!FourD.SERVER.contains(player.getUUID())) return;
        Exit spot = exitSpot(player);
        clear(player);
        if (spot != null) player.moveTo(spot.pos().x, spot.pos().y, spot.pos().z, player.getYRot(), player.getXRot());
    }

    @SubscribeEvent
    public static void onChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        PENDING.remove(player.getUUID());
        clear(player);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        FourD.SERVER.clear();
        KEY_DOWN.clear();
        PENDING.clear();
    }
}
