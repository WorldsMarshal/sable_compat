package com.invfix.fourd;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.npc.InventoryCarrier;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Карманы существа, открытые из 4D: обычное меню сундука поверх его вещей — берёшь и кладёшь прямо в них.
 *  - игрок (5 рядов): 3 ряда инвентаря, хотбар, затем голова, грудь, ноги, ступни, вторая рука;
 *  - моб (1 ряд): основная и вторая рука, голова, грудь, ноги, ступни; у носящих инвентарь (жители,
 *    пиглины, тихони) — ещё ряды с ним.
 * Лишние клетки — «пустые»: положенное туда при закрытии возвращается открывшей.
 * Меню живо, пока она в 4D, существо живо, в том же мире и рядом.
 */
final class FourDPockets implements Container {

    private interface Cell {
        ItemStack get();

        void set(ItemStack stack);
    }

    /** Пустая клетка: держит своё до закрытия. */
    private static final class Spare implements Cell {
        ItemStack stack = ItemStack.EMPTY;

        @Override public ItemStack get() { return stack; }

        @Override public void set(ItemStack s) { stack = s; }
    }

    private final LivingEntity target;
    private final List<Cell> cells;

    private FourDPockets(LivingEntity target, List<Cell> cells) {
        this.target = target;
        this.cells = cells;
    }

    static void open(ServerPlayer opener, LivingEntity target) {
        List<Cell> cells = new ArrayList<>();
        if (target instanceof Player p) {
            Inventory inv = p.getInventory();
            for (int i = 9; i < 36; i++) cells.add(slot(inv, i));
            for (int i = 0; i < 9; i++) cells.add(slot(inv, i));
            // голова, грудь, ноги, ступни (39..36), вторая рука (40)
            for (int i = 39; i >= 36; i--) cells.add(slot(inv, i));
            cells.add(slot(inv, 40));
        } else {
            for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND, EquipmentSlot.HEAD,
                    EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                cells.add(equipment(target, s));
            }
            pad(cells);
            if (target instanceof InventoryCarrier carrier) {
                SimpleContainer inv = carrier.getInventory();
                for (int i = 0; i < inv.getContainerSize() && cells.size() < 54; i++) cells.add(slot(inv, i));
            }
        }
        pad(cells);
        int rows = Math.max(1, Math.min(6, cells.size() / 9));
        while (cells.size() > rows * 9) cells.remove(cells.size() - 1);
        FourDPockets pockets = new FourDPockets(target, cells);
        MenuType<ChestMenu> type = switch (rows) {
            case 1 -> MenuType.GENERIC_9x1;
            case 2 -> MenuType.GENERIC_9x2;
            case 3 -> MenuType.GENERIC_9x3;
            case 4 -> MenuType.GENERIC_9x4;
            case 5 -> MenuType.GENERIC_9x5;
            default -> MenuType.GENERIC_9x6;
        };
        Component title = Component.literal("Карманы: ").append(target.getDisplayName());
        opener.openMenu(new SimpleMenuProvider((id, inv, p) -> new ChestMenu(type, id, inv, pockets, rows), title));
    }

    private static void pad(List<Cell> cells) {
        while (cells.size() % 9 != 0) cells.add(new Spare());
    }

    private static Cell slot(Container c, int i) {
        return new Cell() {
            @Override public ItemStack get() { return c.getItem(i); }

            @Override public void set(ItemStack s) { c.setItem(i, s); }
        };
    }

    private static Cell equipment(LivingEntity e, EquipmentSlot slot) {
        return new Cell() {
            @Override public ItemStack get() { return e.getItemBySlot(slot); }

            @Override
            public void set(ItemStack s) {
                e.setItemSlot(slot, s);
                // положенное мобу не пропадает при его смерти
                if (!s.isEmpty() && e instanceof Mob mob) mob.setGuaranteedDrop(slot);
            }
        };
    }

    @Override
    public int getContainerSize() {
        return cells.size();
    }

    @Override
    public boolean isEmpty() {
        for (Cell c : cells) if (!c.get().isEmpty()) return false;
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return slot >= 0 && slot < cells.size() ? cells.get(slot).get() : ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        if (slot < 0 || slot >= cells.size() || amount <= 0) return ItemStack.EMPTY;
        Cell c = cells.get(slot);
        ItemStack s = c.get();
        if (s.isEmpty()) return ItemStack.EMPTY;
        ItemStack taken = s.split(amount);
        c.set(s.isEmpty() ? ItemStack.EMPTY : s);
        setChanged();
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        if (slot < 0 || slot >= cells.size()) return ItemStack.EMPTY;
        Cell c = cells.get(slot);
        ItemStack s = c.get();
        c.set(ItemStack.EMPTY);
        return s;
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        if (slot < 0 || slot >= cells.size()) return;
        cells.get(slot).set(stack);
        setChanged();
    }

    @Override
    public void setChanged() {
        if (target instanceof Player p) p.getInventory().setChanged();
    }

    @Override
    public boolean stillValid(Player player) {
        return FourD.in(player) && target.isAlive() && !target.isRemoved() && target.level() == player.level()
                && player.canInteractWithEntity(target, 3.0);
    }

    /** Положенное в пустые клетки — обратно открывшей. */
    @Override
    public void stopOpen(Player player) {
        for (Cell c : cells) {
            if (c instanceof Spare spare && !spare.stack.isEmpty()) {
                player.getInventory().placeItemBackInInventory(spare.stack);
                spare.stack = ItemStack.EMPTY;
            }
        }
    }

    @Override
    public void clearContent() {
        // чужие вещи не стираются
    }
}
