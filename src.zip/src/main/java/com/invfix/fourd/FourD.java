package com.invfix.fourd;

import com.invfix.kitsune.KitsuneRace;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * 4D Offset (Kitsune, LVL {@link #LVL_REQUIRED}): шаг по четвёртой координате. Пока игрок смещён:
 *  - ходит сквозь стены (гравитация есть, стоит на поверхностях; Пробел / Shift — вверх / вниз сквозь
 *    перекрытия) — client.FourDClient;
 *  - для мира он — меняющийся 3D-срез (client.FourDRender): его не задеть, не взять в цель, сквозь него
 *    проходят снаряды и существа (FourDHandler, FourDLivingMixin);
 *  - бьёт изнутри — мимо брони, чар защиты и щита;
 *  - видит мир насквозь: существа, контейнеры с содержимым и каркас скрытых граней — поверх
 *    полупрозрачного мира (client.FourDVision, four_d.fsh);
 *  - открывает контейнеры сквозь стены, не открывая крышек, и лезет в карманы существ (FourDPockets).
 * Выход — в ближайшее свободное место.
 */
public final class FourD {

    public static final String ABILITY = "§5§l4D Offset";
    public static final int LVL_REQUIRED = 500;

    /** Дальность «рук» к контейнерам сквозь стены, блоки. */
    public static final double CONTAINER_RANGE = 8.0;
    /** Сколько блоков вокруг видно содержимое контейнеров (и до каких можно дотянуться). */
    public static final int CONTENTS_RANGE = 12;

    static final Set<UUID> SERVER = new HashSet<>();
    static final Set<Integer> CLIENT = new HashSet<>();

    private FourD() {}

    /** Сущность смещена в 4D (сервер — по UUID, клиент — по id). */
    public static boolean in(@Nullable Entity entity) {
        if (!(entity instanceof Player) || entity.level() == null) return false;
        return entity.level().isClientSide() ? CLIENT.contains(entity.getId()) : SERVER.contains(entity.getUUID());
    }

    public static void setClient(int entityId, boolean on) {
        if (on) CLIENT.add(entityId);
        else CLIENT.remove(entityId);
    }

    /** Клиент: id смещённых в 4D (только чтение). */
    public static Set<Integer> clientIds() {
        return java.util.Collections.unmodifiableSet(CLIENT);
    }

    public static boolean inClient(int entityId) {
        return CLIENT.contains(entityId);
    }

    public static void clearClient() {
        CLIENT.clear();
    }

    public static boolean eligible(@Nullable Entity entity) {
        if (!(entity instanceof Player player)) return false;
        try {
            InvincibleIncModVariables.PlayerVariables v = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            return KitsuneRace.isKitsune(v.Race) && v.Lvl >= LVL_REQUIRED;
        } catch (Exception e) {
            return false;
        }
    }
}
