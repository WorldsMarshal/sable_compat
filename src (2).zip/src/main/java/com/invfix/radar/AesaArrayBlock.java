package com.invfix.radar;

import com.happysg.radar.block.radar.plane.StationaryRadarBlock;
import com.happysg.radar.block.radar.plane.StationaryRadarBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * АФАР-панель. НАСЛЕДУЕТ StationaryRadarBlock — это принципиально: передатчик
 * радиолокационных данных (data_link) валидирует цель жёстким instanceof
 * (getFilterTarget: MonitorBlockEntity / RadarBearingBlock / StationaryRadarBlock),
 * и только сабкласс их стационарного радара опознаётся как RADAR_STATIONARY и
 * попадает в сеть NetworkData. Placement/FACING/onRemove-очистка сети — родительские;
 * своё — тонкая панель у задней грани и наш BE-тип.
 */
public class AesaArrayBlock extends StationaryRadarBlock {

    private static final VoxelShape NORTH = Block.box(0, 0, 10, 16, 16, 16);
    private static final VoxelShape SOUTH = Block.box(0, 0, 0, 16, 16, 6);
    private static final VoxelShape WEST = Block.box(10, 0, 0, 16, 16, 16);
    private static final VoxelShape EAST = Block.box(0, 0, 0, 6, 16, 16);

    public AesaArrayBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return switch (state.getValue(FACING)) {
            case SOUTH -> SOUTH;
            case WEST -> WEST;
            case EAST -> EAST;
            default -> NORTH;
        };
    }

    @Override
    public BlockEntityType<? extends StationaryRadarBlockEntity> getBlockEntityType() {
        return RadarIntegration.AESA_ARRAY_BE.get();
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        super.onPlace(state, level, pos, oldState, isMoving);
        if (!level.isClientSide && !state.is(oldState.getBlock())) {
            AesaStructure.rebuild(level, pos);
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        super.onRemove(state, level, pos, newState, isMoving); // чистка NetworkData у родителя
        if (!level.isClientSide && !state.is(newState.getBlock())) {
            AesaStructure.rebuildNeighbors(level, pos);
        }
    }
}
