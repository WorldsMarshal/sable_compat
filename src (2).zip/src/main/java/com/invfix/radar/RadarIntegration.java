package com.invfix.radar;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Регистрация АФАР. Класс ссылается на create_radar (compileOnly) — грузится и
 * регистрируется ТОЛЬКО при загруженном create_radar (гейт в InvincibleFix),
 * по тому же паттерну, что CyberwareItems/createcybernetics.
 */
public final class RadarIntegration {

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks("sable_compat");
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("sable_compat");
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(net.minecraft.core.registries.Registries.BLOCK_ENTITY_TYPE, "sable_compat");

    public static final DeferredBlock<AesaArrayBlock> AESA_ARRAY =
            BLOCKS.registerBlock("aesa_array",
                    p -> new AesaArrayBlock(p),
                    BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY)
                            .strength(4.0F, 8.0F).requiresCorrectToolForDrops()
                            .sound(SoundType.NETHERITE_BLOCK).noOcclusion());

    public static final DeferredItem<BlockItem> AESA_ARRAY_ITEM =
            ITEMS.register("aesa_array", () -> new BlockItem(AESA_ARRAY.get(), new Item.Properties()) {
                @Override
                public void appendHoverText(net.minecraft.world.item.ItemStack stack,
                        TooltipContext context,
                        java.util.List<net.minecraft.network.chat.Component> tooltip,
                        net.minecraft.world.item.TooltipFlag flag) {
                    tooltip.add(net.minecraft.network.chat.Component
                            .translatable("tooltip.sable_compat.aesa_array")
                            .withStyle(net.minecraft.ChatFormatting.GRAY));
                }
            });

    // BE сам знает свой тип в конструкторе (паттерн PowerInputBlockEntity) —
    // здесь обычный метод-референс, без самоссылки в инициализаторе поля.
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AesaArrayBlockEntity>> AESA_ARRAY_BE =
            BLOCK_ENTITIES.register("aesa_array",
                    () -> BlockEntityType.Builder.of(AesaArrayBlockEntity::new, AESA_ARRAY.get()).build(null));

    private RadarIntegration() {}

    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
        modEventBus.addListener(RadarIntegration::onRegisterCapabilities);
        modEventBus.addListener(RadarIntegration::onBuildCreativeTabs);
    }

    private static void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
        AesaArrayBlockEntity.registerCapabilities(event);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept((Item) AESA_ARRAY_ITEM.get());
        }
    }
}
