package com.invfix.radar;

import dan200.computercraft.api.lua.LuaFunction;
import dan200.computercraft.api.peripheral.IPeripheral;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;

/**
 * Решётка AESA как периферия ComputerCraft.
 *
 * Своя, а не одолженная. Create Radar раздаёт методы своих радаров
 * generic-источником, нацеленным на {@code StationaryRadarBlockEntity}, а наша
 * панель его наследует - по документации этого должно хватать. На практике
 * капабилити периферии у панели пустое: проводной модем, приставленный к ней,
 * устройство находит, а обход саблевела - нет, и в инвентаре шины сорока пяти
 * панелей просто не существует. Разбираться, почему чужой generic-источник не
 * доезжает до чужого наследника, дороже, чем объявить периферию самим.
 *
 * Отвечает вся решётка целиком, а не отдельная панель: методы блок-сущности уже
 * делегируют тому, кто ведёт развёртку, поэтому провод или модем можно вешать
 * на любую панель кластера.
 */
public class AesaPeripheral implements IPeripheral {

    private final AesaArrayBlockEntity owner;

    public AesaPeripheral(AesaArrayBlockEntity owner) {
        this.owner = owner;
    }

    /**
     * Имя типа выбрано под уже написанные программы.
     *
     * Всё, что ищет радар, ищет {@code plane_radar} - так называется блок Create
     * Radar, и так же ComputerCraft называл бы generic-периферию по нему. Наш
     * блок зовётся иначе, и если бы тип шёл от него, каждую программу пришлось
     * бы править. Методы здесь те же самые, так что и имя пусть будет то же.
     */
    @Override
    public String getType() {
        return "plane_radar";
    }

    @Override
    public boolean equals(@Nullable IPeripheral other) {
        return other instanceof AesaPeripheral p && p.owner == this.owner;
    }

    @Override
    public Object getTarget() {
        return owner;
    }


    /**
     * Контакты решётки, в том же виде, что отдают радары Create Radar.
     *
     * Из снимка. Коллекция сканера живёт в серверном потоке и переписывается
     * каждый тик; читать её из потока компьютера значит получать то пустоту, то
     * половину списка, и разницу снаружи не отличить от пустого неба.
     */
    @LuaFunction
    public final List<Map<String, Object>> getTracks() {
        return owner.snapshot().tracks();
    }

    /** Точка отсчёта развёртки, уже в мировых координатах. */
    @LuaFunction
    public final Map<String, Object> getPosition() {
        AesaArrayBlockEntity.Snapshot s = owner.snapshot();
        Map<String, Object> m = new HashMap<>();
        m.put("x", s.worldX());
        m.put("y", s.worldY());
        m.put("z", s.worldZ());
        return m;
    }

    /** Дальность решётки, растёт с числом панелей. */
    @LuaFunction
    public final double getRange() {
        return owner.snapshot().range();
    }

    /** Работает ли решётка. Ложь чаще всего означает нехватку питания. */
    @LuaFunction
    public final boolean isRunning() {
        return owner.snapshot().running();
    }

    /** Сколько панелей в кластере. */
    @LuaFunction
    public final int getPanelCount() {
        return owner.snapshot().panels();
    }

    /** Есть ли питание у кластера. */
    @LuaFunction
    public final boolean isPowered() {
        return owner.snapshot().powered();
    }

    /** Запас FE по всему кластеру. */
    @LuaFunction
    public final int getEnergy() {
        return owner.snapshot().clusterEnergy();
    }

    /**
     * Каждая панель кластера: смещение от ВЕДУЩЕЙ панели и её запас FE.
     *
     * Для разбора случаев, когда решётка молчит: суммарные числа не отличают
     * "энергии нет" от "мастер считает не по тем панелям".
     */
    @LuaFunction
    public final List<Map<String, Object>> getPanels() {
        AesaArrayBlockEntity.Snapshot s = owner.snapshot();
        List<Map<String, Object>> out = new ArrayList<>();
        for (int i = 0; i < s.panelOffsets().size(); i++) {
            int[] o = s.panelOffsets().get(i);
            Map<String, Object> m = new HashMap<>();
            m.put("dx", o[0]);
            m.put("dy", o[1]);
            m.put("dz", o[2]);
            m.put("energy", s.panelEnergies().get(i));
            out.add(m);
        }
        return out;
    }

    /** Ведёт ли эта панель развёртку за кластер. */
    @LuaFunction
    public final boolean isMaster() {
        return owner.snapshot().master();
    }
}