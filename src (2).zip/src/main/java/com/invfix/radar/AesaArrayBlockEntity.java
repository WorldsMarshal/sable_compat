package com.invfix.radar;

import com.happysg.radar.block.radar.behavior.RadarScanningBlockBehavior;
import com.happysg.radar.block.radar.plane.StationaryRadarBlockEntity;
import com.happysg.radar.block.radar.track.RadarTrack;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.energy.EnergyStorage;

import java.util.Collection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.world.phys.Vec3;
import com.happysg.radar.compat.Mods;
import com.happysg.radar.compat.vs2.PhysicsHandler;
import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.companion.math.BoundingBox3d;
import dev.ryanhcode.sable.companion.math.BoundingBox3dc;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import java.util.List;

/**
 * АФАР (AESA) — мультиблочная фазированная решётка.
 *
 * Все смежные панели С ОДИНАКОВЫМ FACING (flood fill по 6 направлениям, см.
 * {@link AesaStructure}) — одна структура. Мастер — панель с минимальным BlockPos:
 * только её сканер работает, остальные — пассивные модули (их behavior заглушен).
 * Адаптер powergrid и передатчик радиолокационных данных можно вешать на ЛЮБУЮ
 * панель: энергия сифонится мастером из буферов всех модулей, а IRadar-методы
 * модулей делегируют мастеру, так что монитор, слинкованный на любой блок,
 * видит треки всей решётки.
 *
 * Дальность: {@value #BASE_RANGE} на одиночную панель, +{@value #RANGE_BONUS_PCT}%
 * от базы за каждый дополнительный блок (N панелей: 1200 * (1 + 0.05*(N-1))).
 * Потребление структуры — {@value #FE_PER_TICK} FE/т (в пределах одного адаптера).
 *
 * Никаких периодических пересборок: структура пересчитывается ТОЛЬКО на
 * установке/снятии панели (события блока), членство хранится в NBT.
 */
public class AesaArrayBlockEntity extends StationaryRadarBlockEntity {

    public static final int BASE_RANGE = 1200;
    public static final int RANGE_BONUS_PCT = 5;
    public static final int FOV = 150;

    /**
     * Вертикальный захват решётки.
     *
     * У радара Create Radar он равен двадцати блокам, и это не конфиг, а число,
     * зашитое в конструкторе поведения сканирования. Для решётки, которая стоит
     * как треть корабля и бьёт на километры, двадцать блоков по высоте - это
     * прибор, не видящий даже собственную мачту, поэтому множитель.
     *
     * Потолок нужен ровно затем, чтобы это осталось радаром, а не датчиком
     * присутствия: на дистанции в два километра вертикаль в километр означает
     * "видит вообще всё", и никакой геометрии в наведении больше нет.
     */
    /**
     * Что видит поток компьютера. Собирается здесь, читается там.
     *
     * Периферия ComputerCraft работает в своём потоке, а {@code getBlockEntity}
     * и {@code getBlockState} принадлежат серверному: оттуда они возвращают
     * пустоту, и это не падение, а тихие нули. Именно так решётка с полным
     * буфером рапортовала о нулевом банке - поле объекта читалось верно, а
     * обход соседей через уровень нет.
     *
     * Поэтому наружу отдаётся снимок, собранный в тике, и опубликованный через
     * volatile ссылку на неизменяемую структуру.
     */
    public record Snapshot(boolean running, boolean powered, boolean master,
                           int panels, int clusterEnergy, int panelEnergy,
                           int lastAvailable, float range,
                           double worldX, double worldY, double worldZ,
                           List<Map<String, Object>> tracks,
                           List<int[]> panelOffsets, List<Integer> panelEnergies) {}

    private static final Snapshot EMPTY_SNAPSHOT =
            new Snapshot(false, false, false, 1, 0, 0, 0, 0, 0, 0, 0,
                    List.of(), List.of(), List.of());

    /**
     * Часть снимка, общая для всего кластера. Собирает её ТОЛЬКО ведущая
     * панель.
     *
     * Так было не всегда, и это стоило мира. Раньше {@code buildSnapshot()}
     * вызывался каждый тик КАЖДОЙ панелью, а внутри него — обход всех панелей
     * кластера через {@code getBlockEntity}, полное копирование списка треков
     * (на трек три HashMap и Map.copyOf) и пространственный запрос Sable по
     * кубу в несколько километров. Стоимость выходила P·(P + 5·T) в тик, где
     * P — панелей в решётке, T — контактов: сорок панелей и триста контактов
     * это шестьдесят тысяч карт в тик на одну решётку. Пока корабль стоял
     * выгруженным, это никого не трогало; стоило удержать чанки и подойти к
     * месту, где контактов сотни, — сервер ложился.
     *
     * Теперь это одна честная сборка в тик на решётку плюс P раз по O(1).
     * Данные и их свежесть не меняются ни на йоту: сборка идёт каждый тик, как
     * и раньше, просто не сорок пять раз подряд с одинаковым результатом.
     */
    public record Shared(boolean running, boolean powered, int panels, int clusterEnergy,
                         int lastAvailable, float range,
                         double worldX, double worldY, double worldZ,
                         List<Map<String, Object>> tracks,
                         List<int[]> panelOffsets, List<Integer> panelEnergies) {}

    private volatile Shared shared;

    private volatile Snapshot snapshot = EMPTY_SNAPSHOT;

    /**
     * Ближе этого саблевел считается своим и целью не становится.
     *
     * Радар видит и сам авианосец, и подсаблевелы на нём - лифты, поворотные
     * платформы. Вреда от них нет, но пересчитывать их каждый тик и держать в
     * списке целей незачем.
     */
    private static final double OWN_HULL_RADIUS = 70.0;

    private static final int VANILLA_Y_RANGE = 20;
    private static final int Y_RANGE_MULTIPLIER = 18;
    private static final int Y_RANGE_CAP = 680;

    private static int aesaYRange() {
        return Math.min(Y_RANGE_CAP, VANILLA_Y_RANGE * Y_RANGE_MULTIPLIER);
    }
    public static final int FE_PER_TICK = 200;
    public static final int CAPACITY = 100_000;
    /**
     * Сколько панель берёт за тик.
     *
     * Было двадцать тысяч - в сто раз больше, чем кластер тратит. Пустая решётка
     * при запуске выгребала генератор досуха быстрее, чем тот успевал выйти на
     * режим, и генератору powergrid, подключённому напрямую, не хватало
     * собственной мощности на возбуждение: всё уходило в буфер. Тысяча заполняет
     * буфер за сотню тиков и оставляет источнику запас на раскрутку.
     */
    public static final int MAX_RECEIVE = 1_000;

    private final Buffer energy = new Buffer(CAPACITY, MAX_RECEIVE);
    private RadarScanningBlockBehavior aesaScanner;
    private boolean powered;
    /** Проверка ссылки на мастера делается один раз за жизнь сущности. */
    private transient boolean checkedStructure;

    /** Мастер структуры (null/self = мастер — я). Персистится. */
    /** Размер структуры (у всех членов одинаковый). Персистится. */
    private int structureSize = 1;
    /** Кэш членов — только у мастера, лениво, сбрасывается при пересборке. */
    private List<BlockPos> memberCache;

    public AesaArrayBlockEntity(BlockPos pos, BlockState state) {
        super(RadarIntegration.AESA_ARRAY_BE.get(), pos, state);
    }

    // ------------------------------------------------------------------ структура

    /**
     * Ведёт ли эта панель развёртку за весь кластер.
     *
     * Мастер больше не запоминается: он вычисляется из состава кластера прямо
     * сейчас, как панель с наименьшей позицией. Раньше ссылка лежала в NBT и
     * пересобиралась только при установке или снятии панели, поэтому любое
     * событие, переносящее блоки вместе с их NBT - аварийная остановка,
     * копирование саблевела, наша же починка сущностей, - оставляло ссылку
     * указывать в пустоту. Мастера не оказывалось ни одного, и решётка молчала
     * при полном питании.
     *
     * Теперь искать «тот самый первый блок» не нужно вообще: кластер сам решает,
     * кто считает, и решение не переживает перестройку, потому что нигде не
     * сохраняется.
     */
    public boolean isMaster() {
        BlockPos m = clusterMaster();
        return m == null || m.equals(worldPosition);
    }

    /**
     * Панель кластера с наименьшей позицией.
     *
     * Кэшируется до ближайшего изменения состава: обход соседей на каждый тик
     * каждой панели - это ровно та цена, которую платить не хочется.
     */
    private @javax.annotation.Nullable BlockPos clusterMaster() {
        List<BlockPos> all = members();
        if (all == null || all.isEmpty()) return null;
        BlockPos best = all.get(0);
        for (BlockPos p : all) {
            if (p.compareTo(best) < 0) best = p;
        }
        return best;
    }

    /**
     * Пересобрать структуру, если сохранённая ссылка на мастера протухла.
     *
     * {@code AesaStructure.rebuild} зовётся только при установке и снятии
     * панели, а ссылка на мастера и размер приезжали из NBT. Значит после любого
     * события, которое переносит блоки вместе с их NBT, но не вызывает
     * {@code onPlace} — аварийная остановка мира, копирование саблевела, наша же
     * починка блок-сущностей, — ссылка может указывать туда, где панели больше
     * нет. Тогда {@code isMaster} ложен у всех сразу, мастера нет ни одного, и
     * решётка молчит при исправном питании и правильной проводке.
     *
     * Проверка дешёвая: смотрим, жив ли тот, на кого мы ссылаемся, и только если
     * нет — запускаем обход. Пересборка идемпотентна, поэтому если её вызовут
     * все панели структуры разом, результат от этого не изменится.
     */
    /**
     * Забыть состав кластера и пересобрать его при следующем обращении.
     *
     * После того как мастер стал вычисляемым, ломаться тут больше нечему -
     * достаточно сбросить кэш. Метод остался, потому что им пользуется
     * {@code /sublevel refresh}: перерождённые панели должны заново
     * осмотреться, а не верить кэшу от прежней жизни.
     */
    public void validateStructure() {
        if (level == null || level.isClientSide) return;
        memberCache = null;
        int size = clusterSize();
        if (size != structureSize) {
            structureSize = size;
            notifyUpdate();
        } else {
            setChanged();
        }
    }

    /** Для диагностики: сколько панелей в кластере прямо сейчас. */
    public int structureSize() {
        return clusterSize();
    }

    /** Для диагностики: получает ли структура свои FE. */
    public boolean isPowered() {
        // Заполняет это поле только ведущая панель, потому что только она
        // списывает энергию. Без делегирования любая другая панель кластера
        // отвечала бы "питания нет" независимо от того, что происходит на
        // самом деле - и отвечала, пока это не поймали.
        AesaArrayBlockEntity m = master();
        return m == this ? powered : m.isPowered();
    }

    /**
     * Суммарный запас кластера, а не одной панели.
     *
     * Энергия приходит в ту панель, к которой подведён провод, а тратится за
     * всех, поэтому запас отдельно взятой панели ничего не говорит: у одной
     * может быть полный буфер, у сорока четырёх нули, и решётка при этом
     * работает.
     */
    /** Позиции панелей кластера, как их видит эта панель. */
    public List<BlockPos> clusterPanels() {
        List<BlockPos> all = members();
        return all == null ? List.of(worldPosition) : List.copyOf(all);
    }

    /** Запас конкретной панели, если она вообще панель. */
    public int energyAt(BlockPos pos) {
        if (level == null) return -1;
        return level.getBlockEntity(pos) instanceof AesaArrayBlockEntity m
                ? m.energy.getEnergyStored() : -1;
    }

    /** Что видело списание в последний раз: доступная энергия и число панелей. */
    public int lastAvailable() {
        AesaArrayBlockEntity m = master();
        return m == this ? lastAvailable : m.lastAvailable();
    }

    public int lastMemberCount() {
        AesaArrayBlockEntity m = master();
        return m == this ? lastMemberCount : m.lastMemberCount();
    }

    public int clusterEnergy() {
        List<BlockPos> all = members();
        if (all == null || level == null) return energy.getEnergyStored();
        int sum = 0;
        for (BlockPos p : all) {
            if (level.getBlockEntity(p) instanceof AesaArrayBlockEntity m) {
                sum += m.energy.getEnergyStored();
            }
        }
        return sum;
    }

    /** Для диагностики: сколько FE лежит в буфере этой панели. */
    public int storedEnergy() {
        return energy.getEnergyStored();
    }

    /** Для диагностики: на кого эта панель ссылается как на мастера. */
    public @javax.annotation.Nullable BlockPos masterPosition() {
        return clusterMaster();
    }

    /** Вызывается AesaStructure при пересборке. */
    void setStructure(BlockPos master, int size) {
        // master приходит от AesaStructure, но здесь он не нужен: кто ведёт
        // развёртку, панель выясняет сама по составу кластера. Сохраняем его
        // только чтобы старые сейвы читались без сюрпризов.
        this.structureSize = Math.max(1, size);
        this.memberCache = null;
        setChanged();
        if (level != null && !level.isClientSide) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    private AesaArrayBlockEntity master() {
        if (level == null) return this;
        BlockPos m = clusterMaster();
        if (m == null || m.equals(worldPosition)) return this;
        BlockEntity be = level.getBlockEntity(m);
        return be instanceof AesaArrayBlockEntity aesa ? aesa : this;
    }

    private List<BlockPos> members() {
        if (memberCache == null && level != null) {
            memberCache = AesaStructure.collect(level, worldPosition);
        }
        return memberCache;
    }

    float structureRange() {
        return (float) (BASE_RANGE * (1.0 + RANGE_BONUS_PCT / 100.0 * (clusterSize() - 1)));
    }

    /** Размер кластера по факту, с откатом на сохранённый, если обход не удался. */
    private int clusterSize() {
        List<BlockPos> all = members();
        return all == null || all.isEmpty() ? Math.max(1, structureSize) : all.size();
    }

    /**
     * Собрать всё, что периферия может спросить. Только из тика и только у
     * ведущей панели: см. {@link Shared} о том, во что обходился обратный
     * порядок.
     *
     * Здесь и только здесь позволено ходить по уровню: обход соседей,
     * {@code getBlockEntity}, чтение чужих буферов. Из потока компьютера всё
     * это возвращает пустоту, а не ошибку, и отличить такую пустоту от честного
     * нуля снаружи невозможно.
     *
     * Смещения панелей считаются от ведущей — раньше каждая панель считала их
     * от себя. Список диагностический, и единая точка отсчёта в нём удобнее.
     */
    private Shared buildShared() {
        List<BlockPos> all = members();
        if (all == null) all = List.of(worldPosition);

        List<int[]> offsets = new ArrayList<>(all.size());
        List<Integer> energies = new ArrayList<>(all.size());
        int total = 0;
        for (BlockPos p : all) {
            offsets.add(new int[]{ p.getX() - worldPosition.getX(),
                    p.getY() - worldPosition.getY(),
                    p.getZ() - worldPosition.getZ() });
            int e = level.getBlockEntity(p) instanceof AesaArrayBlockEntity m
                    ? m.energy.getEnergyStored() : -1;
            energies.add(e);
            if (e > 0) total += e;
        }

        // Позиция развёртки сразу в мировых координатах: панель на корабле
        // стоит в координатах плота, а треки приходят в мировых, и смешивать
        // их нельзя - расстояния выходят в миллионы блоков.
        BlockPos sweep = getWorldPos();
        Vec3 world;
        try {
            world = (Mods.SABLE.isLoaded() && PhysicsHandler.isBlockInPlotyard(level, sweep))
                    ? PhysicsHandler.getWorldPos(level, sweep).getCenter()
                    : sweep.getCenter();
        } catch (Throwable t) {
            world = sweep.getCenter();
        }

        // Треки копируются здесь же: коллекция сканера живёт в серверном
        // потоке и меняется каждый тик, читать её снаружи нельзя.
        List<Map<String, Object>> tracks = new ArrayList<>();
        for (RadarTrack track : getTracks()) {
            if (track == null) continue;
            Map<String, Object> t = new HashMap<>();
            t.put("id", track.getId());
            t.put("position", vecMap(track.getPosition()));
            t.put("velocity", vecMap(track.getVelocity()));
            t.put("scannedTime", track.getScannedTime());
            t.put("category", String.valueOf(track.getTrackCategory()));
            t.put("entityType", track.getEntityType());
            tracks.add(Map.copyOf(t));
        }

        addPlayers(tracks, world);
        addSubLevels(tracks, world);

        return new Shared(
                powered && aesaScanner != null,
                powered,
                all.size(),
                total,
                lastAvailable,
                structureRange(),
                world.x, world.y, world.z,
                List.copyOf(tracks),
                List.copyOf(offsets),
                List.copyOf(energies));
    }

    /**
     * Дописать игроков, которых обычный скан увидеть не может.
     *
     * Create Radar собирает цели через {@code level.getEntities}, а это работает
     * только по загруженным чанкам: в одиночной игре местность за прогрузкой не
     * существует, и решётка на два километра оказывается бесполезной ровно там,
     * где она нужна. Никакой настройкой это не обходится - сущностей там просто
     * нет.
     *
     * Игроки - исключение: сервер держит их список всегда, независимо от
     * чанков. Поэтому они добавляются отдельным проходом, по дальности решётки.
     * Всё остальное - корабли, снаряды, мобы - по-прежнему видно только в
     * загруженном, и это честное ограничение игры, а не наше.
     *
     * Дубли исключаются по идентификатору: того, кто стоит рядом, обычный скан
     * уже нашёл.
     */
    private void addPlayers(List<Map<String, Object>> tracks, Vec3 world) {
        if (level == null || level.isClientSide) return;

        java.util.Set<String> known = new java.util.HashSet<>();
        for (Map<String, Object> t : tracks) {
            Object id = t.get("id");
            if (id != null) known.add(String.valueOf(id));
        }

        double reach = structureRange();
        double reachSq = reach * reach;
        for (net.minecraft.world.entity.player.Player p : level.players()) {
            if (p.isSpectator()) continue;
            String id = p.getStringUUID();
            if (known.contains(id)) continue;

            Vec3 pos = p.position();
            if (pos.distanceToSqr(world) > reachSq) continue;

            Map<String, Object> t = new HashMap<>();
            t.put("id", id);
            t.put("position", vecMap(pos));
            t.put("velocity", vecMap(p.getDeltaMovement()));
            t.put("scannedTime", level.getGameTime());
            t.put("category", "PLAYER");
            t.put("entityType", p.getGameProfile().getName());
            tracks.add(Map.copyOf(t));
        }
    }

    /**
     * Дописать саблевелы, которых обычный скан увидеть не может.
     *
     * По той же причине, что и игроков: {@code level.getEntities} работает по
     * загруженным чанкам, а корабль за прогрузкой в них не попадает. Но Sable
     * держит список своих саблевелов сам и отвечает на запрос по мировым
     * габаритам независимо от того, прогружен ли там кто-то.
     *
     * Свой корпус и всё, что к нему прижато, отбрасывается по расстоянию: на
     * авианосце подсаблевелов вроде лифтов хватает, и считать их целями каждый
     * тик незачем.
     */
    private void addSubLevels(List<Map<String, Object>> tracks, Vec3 world) {
        if (level == null || level.isClientSide) return;

        java.util.Set<String> known = new java.util.HashSet<>();
        for (Map<String, Object> t : tracks) {
            Object id = t.get("id");
            if (id != null) known.add(String.valueOf(id));
        }

        double reach = structureRange();
        try {
            BoundingBox3d bounds = new BoundingBox3d(
                    world.x - reach, world.y - reach, world.z - reach,
                    world.x + reach, world.y + reach, world.z + reach);
            for (Object o : Sable.HELPER.getAllIntersecting(level, bounds)) {
                if (!(o instanceof ServerSubLevel sub)) continue;

                Vector3dc p = sub.logicalPose().position();
                Vec3 pos = new Vec3(p.x(), p.y(), p.z());
                double d = pos.distanceTo(world);
                if (d > reach || d < OWN_HULL_RADIUS) continue;

                String id = sub.getUniqueId().toString();
                if (!known.add(id)) continue;

                Vector3d v = sub.latestLinearVelocity;
                Map<String, Object> t = new HashMap<>();
                t.put("id", id);
                t.put("position", vecMap(pos));
                t.put("velocity", vecMap(v == null ? Vec3.ZERO : new Vec3(v.x, v.y, v.z)));
                t.put("scannedTime", level.getGameTime());
                t.put("category", "SABLE");
                t.put("entityType", "sublevel");
                // Габариты корабля в мире. position - это начало координат плота,
                // а не середина корабля: где оно окажется на корпусе, зависит от
                // того, как плот выделяли при сборке, и вполне может висеть за
                // бортом. Стрелять туда бессмысленно, поэтому вместе с точкой
                // отдаются границы, и наводка может целиться в центр корабля.
                //
                // Коробка мировая и осевая: она охватывает повёрнутый корабль
                // целиком, поэтому при крене она больше самого корабля, а её
                // центр немного гуляет относительно корпуса. Для наводки это
                // всё равно куда ближе к истине, чем угол плота.
                BoundingBox3dc bb = sub.boundingBox();
                if (bb != null) {
                    Map<String, Object> mn = new HashMap<>();
                    mn.put("x", bb.minX()); mn.put("y", bb.minY()); mn.put("z", bb.minZ());
                    Map<String, Object> mx = new HashMap<>();
                    mx.put("x", bb.maxX()); mx.put("y", bb.maxY()); mx.put("z", bb.maxZ());
                    t.put("boundsMin", Map.copyOf(mn));
                    t.put("boundsMax", Map.copyOf(mx));
                    t.put("center", vecMap(new Vec3(
                            (bb.minX() + bb.maxX()) * 0.5,
                            (bb.minY() + bb.maxY()) * 0.5,
                            (bb.minZ() + bb.maxZ()) * 0.5)));
                    t.put("size", vecMap(new Vec3(
                            bb.maxX() - bb.minX(),
                            bb.maxY() - bb.minY(),
                            bb.maxZ() - bb.minZ())));
                }
                tracks.add(Map.copyOf(t));
            }
        } catch (Throwable ignored) {
            // Sable отсутствует или перестраивается: обычный скан всё равно работает
        }
    }

    private static Map<String, Object> vecMap(Vec3 v) {
        Map<String, Object> m = new HashMap<>();
        m.put("x", v == null ? 0.0 : v.x);
        m.put("y", v == null ? 0.0 : v.y);
        m.put("z", v == null ? 0.0 : v.z);
        return Map.copyOf(m);
    }

    /** Последний снимок. Всё, что периферия имеет право читать. */
    public Snapshot snapshot() {
        return snapshot;
    }

    // ------------------------------------------------------------------ жизненный цикл

    @Override
    public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
        super.addBehaviours(behaviours);
        for (BlockEntityBehaviour b : behaviours) {
            if (b instanceof RadarScanningBlockBehavior scanner) {
                aesaScanner = scanner;
            }
        }
        if (aesaScanner != null) {
            aesaScanner.setFov(FOV);
            aesaScanner.setYRange(aesaYRange());
            aesaScanner.setTrackExpiration(1);
            aesaScanner.setRunning(false);
        }
    }

    @Override
    public void tick() {
        // Первый серверный тик после загрузки: убедиться, что мастер существует.
        if (!checkedStructure && level != null && !level.isClientSide) {
            checkedStructure = true;
            validateStructure();
        }

        boolean master = isMaster();

        if (master && level != null && !level.isClientSide) {
            boolean was = powered;
            powered = drainStructure(FE_PER_TICK);
            if (powered != was) {
                // Клиент узнаёт о состоянии только из синхронизации, а сама она
                // не случается: тик её не запускает, а Powered пишется в пакет
                // молча. Пока решётка не переставлена руками, монитор так и
                // показывает то, что приехало при загрузке чанка, то есть
                // offline. Поэтому смену состояния надо разослать явно.
                notifyUpdate();
            }
        }

        super.tick(); // behaviours + родитель форсит running=true и угол по FACING/кораблю

        if (level == null || level.isClientSide || aesaScanner == null) return;

        // Тяжёлую часть собирает только ведущая панель — но КАЖДЫЙ тик, как и
        // раньше. Прореживать её нельзя: треки сканера обновляются раз в пять
        // тиков, но игроков и саблевелы мы дописываем сами, по живым позициям,
        // и программам наведения нужна именно потиковая свежесть.
        //
        // Остальные панели берут готовое: списки неизменяемые, копировать их
        // незачем, своими остаются только запас этой панели и признак ведущей.
        if (master) shared = buildShared();
        Shared sh = master ? shared : master().shared;
        snapshot = sh == null ? EMPTY_SNAPSHOT : new Snapshot(
                sh.running(), sh.powered(), master,
                sh.panels(), sh.clusterEnergy(), energy.getEnergyStored(),
                sh.lastAvailable(), sh.range(),
                sh.worldX(), sh.worldY(), sh.worldZ(),
                sh.tracks(), sh.panelOffsets(), sh.panelEnergies());

        if (!master) {
            aesaScanner.setRunning(false); // модуль не сканирует — работает мастер
            return;
        }
        aesaScanner.setRange(structureRange());
        // Вертикаль переустанавливается каждый тик не от избытка усердия:
        // поведение сохраняет yRange в NBT и читает обратно при загрузке, так
        // что у панели, поставленной до этой правки, наша величина была бы
        // затёрта прочитанной двадцаткой - и осталась бы такой навсегда.
        aesaScanner.setYRange(aesaYRange());
        if (!powered) {
            aesaScanner.setRunning(false);
        }
    }

    /** Суммарный забор энергии из буферов всех панелей структуры (мастер — первым). */
    /**
     * Сколько энергии видело последнее списание, и по скольким панелям.
     *
     * Только для отчёта. Отказ питания снаружи выглядит одинаково, чем бы он ни
     * был вызван - пустыми буферами, несобранным кластером или тем, что мы
     * смотрим не на ту решётку, - а числа различают эти случаи сразу.
     */
    private int lastAvailable;
    private int lastMemberCount;

    private boolean drainStructure(int amount) {
        int available = energy.getEnergyStored();
        List<BlockPos> all = members();
        lastMemberCount = all == null ? -1 : all.size();
        if (available < amount && all != null) {
            for (BlockPos p : all) {
                if (p.equals(worldPosition)) continue;
                if (level.getBlockEntity(p) instanceof AesaArrayBlockEntity m) {
                    available += m.energy.getEnergyStored();
                    if (available >= amount) break;
                }
            }
        }
        lastAvailable = available;
        if (available < amount) return false;

        int left = amount - Math.min(energy.getEnergyStored(), amount);
        energy.take(Math.min(energy.getEnergyStored(), amount));
        if (left > 0 && all != null) {
            for (BlockPos p : all) {
                if (left <= 0) break;
                if (p.equals(worldPosition)) continue;
                if (level.getBlockEntity(p) instanceof AesaArrayBlockEntity m) {
                    int take = Math.min(m.energy.getEnergyStored(), left);
                    if (take > 0) {
                        m.energy.take(take);
                        m.setChanged();
                        left -= take;
                    }
                }
            }
        }
        setChanged();
        return left <= 0;
    }

    // ------------------------------------------------------------------ IRadar: делегация мастеру

    @Override
    public Collection<RadarTrack> getTracks() {
        AesaArrayBlockEntity m = master();
        return m == this ? aesaScanner.getRadarTracks() : m.getTracks();
    }

    @Override
    public float getRange() {
        return structureRange();
    }

    @Override
    public boolean isRunning() {
        AesaArrayBlockEntity m = master();
        return m == this ? powered : m.isRunning();
    }

    @Override
    public BlockPos getWorldPos() {
        // Центр развёртки на мониторе — мастер, чтобы у всей решётки был один ноль.
        BlockPos m = clusterMaster();
        return m == null ? worldPosition : m;
    }

    // ------------------------------------------------------------------ энергия

    /**
     * FE-буфер отдаётся любому соседу, кроме другой панели решётки.
     *
     * Раньше здесь стоял白 список: коннектор powergrid, наш высоковольтный
     * коннектор либо пустая грань. Из-за него панель была невидима для всего
     * остального - кабелей Mekanism, проводов Create-аддонов, чего угодно, что
     * просто отдаёт FE в грань. Ограничивать источник питания незачем: FE есть
     * FE, откуда бы он ни пришёл.
     *
     * Единственное исключение - соседняя панель того же типа. Расход и так
     * собирается со всех буферов кластера через {@code drainStructure}, а
     * взаимная выдача заставила бы панели переливать энергию друг в друга по
     * кругу, тратя на это ход за ходом и ничего не меняя по сути.
     */
    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, RadarIntegration.AESA_ARRAY_BE.get(),
                (be, side) -> {
                    Level lvl = be.getLevel();
                    if (lvl == null) return null;
                    if (side != null
                            && lvl.getBlockEntity(be.getBlockPos().relative(side)) instanceof AesaArrayBlockEntity) {
                        return null;
                    }
                    return be.energy;
                });

        registerPeripheral(event);
    }

    /**
     * Отдать решётку ComputerCraft своей периферией.
     *
     * Create Radar раздаёт методы своих радаров generic-источником, нацеленным
     * на {@code StationaryRadarBlockEntity}, а мы его наследуем - по документации
     * этого достаточно. На практике капабилити периферии у панели оставалось
     * пустым: обход саблевела сорока пяти панелей не находил, хотя проводной
     * модем, приставленный вплотную, устройство видел. Выяснять, почему чужой
     * generic-источник не доезжает до чужого наследника, дороже, чем объявить
     * периферию самим - тем более что методы всё равно наши, из блок-сущности.
     *
     * Регистрация условная: без ComputerCraft класс периферии просто не
     * загрузится, и трогать его нельзя.
     */
    private static void registerPeripheral(RegisterCapabilitiesEvent event) {
        if (!net.neoforged.fml.ModList.get().isLoaded("computercraft")) return;
        event.registerBlockEntity(
                dan200.computercraft.api.peripheral.PeripheralCapability.get(),
                RadarIntegration.AESA_ARRAY_BE.get(),
                (be, side) -> new AesaPeripheral(be));
    }

    // ------------------------------------------------------------------ NBT

    @Override
    protected void write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(tag, registries, clientPacket);
        tag.putInt("Energy", energy.getEnergyStored());
        tag.putBoolean("Powered", powered);
        tag.putInt("StructureSize", structureSize);
    }

    @Override
    protected void read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(tag, registries, clientPacket);
        energy.set(tag.getInt("Energy"));
        powered = tag.getBoolean("Powered");
        structureSize = Math.max(1, tag.getInt("StructureSize"));
        // MasterPos из старых сейвов намеренно не читается: кто ведёт развёртку,
        // кластер решает сам, а сохранённая ссылка ровно этим и ломалась.
    }

    static final class Buffer extends EnergyStorage {
        Buffer(int capacity, int maxReceive) { super(capacity, maxReceive, 0, 0); }
        void take(int amount) { this.energy = Math.max(0, this.energy - amount); }
        void set(int value) { this.energy = Math.max(0, Math.min(this.capacity, value)); }
    }
}