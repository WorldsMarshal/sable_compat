package com.invfix.radar;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Сборка мультиблочной АФАР: flood fill по 6 направлениям среди панелей aesa_array
 * с ОДИНАКОВЫМ FACING (панели, смотрящие в разные стороны, — разные решётки).
 * Мастер — минимальный BlockPos (детерминированно у всех членов).
 *
 * Вызывается ТОЛЬКО из событий блока (установка/снятие) — никакого тикового
 * сканирования; результат раздаётся членам и персистится в их NBT.
 */
final class AesaStructure {

    /** Предохранитель от патологических построек. */
    private static final int MAX_SIZE = 256;

    private AesaStructure() {}

    /** Пересобрать структуру, содержащую seed (seed должен быть панелью). */
    static void rebuild(Level level, BlockPos seed) {
        List<BlockPos> members = collect(level, seed);
        if (members == null || members.isEmpty()) return;
        BlockPos master = members.get(0);
        for (BlockPos p : members) {
            if (p.compareTo(master) < 0) master = p;
        }
        for (BlockPos p : members) {
            if (level.getBlockEntity(p) instanceof AesaArrayBlockEntity be) {
                be.setStructure(master, members.size());
            }
        }
    }

    /** После снятия панели: соседние панели могли распасться на несколько структур. */
    static void rebuildNeighbors(Level level, BlockPos removed) {
        Set<BlockPos> done = new HashSet<>();
        for (Direction d : Direction.values()) {
            BlockPos n = removed.relative(d);
            if (done.contains(n)) continue;
            if (level.getBlockState(n).getBlock() instanceof AesaArrayBlock) {
                List<BlockPos> members = collect(level, n);
                if (members != null) done.addAll(members);
                rebuild(level, n);
            }
        }
    }

    /** Flood fill; null если seed — не панель. */
    static List<BlockPos> collect(Level level, BlockPos seed) {
        BlockState seedState = level.getBlockState(seed);
        if (!(seedState.getBlock() instanceof AesaArrayBlock)) return null;
        Direction facing = seedState.getValue(HorizontalDirectionalBlock.FACING);

        List<BlockPos> out = new ArrayList<>();
        Set<BlockPos> seen = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        queue.add(seed.immutable());
        seen.add(seed.immutable());

        while (!queue.isEmpty() && out.size() < MAX_SIZE) {
            BlockPos p = queue.poll();
            out.add(p);
            for (Direction d : Direction.values()) {
                BlockPos n = p.relative(d);
                if (seen.contains(n)) continue;
                BlockState s = level.getBlockState(n);
                if (s.getBlock() instanceof AesaArrayBlock
                        && s.getValue(HorizontalDirectionalBlock.FACING) == facing) {
                    seen.add(n.immutable());
                    queue.add(n.immutable());
                }
            }
        }
        return out;
    }
}
