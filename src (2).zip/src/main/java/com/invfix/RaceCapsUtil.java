package com.invfix;

import com.invfix.humanlike.HumanLikeRaces;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;

/**
 * Утилиты для проверки капов рас.
 * Вынесены из mixin пакета — Mixin загрузчик запрещает
 * ссылаться на обычные классы внутри com.invfix.mixin.*
 */
public class RaceCapsUtil {

    public static double getLevelCap(String race) {
        if (race == null) return -1;
        return switch (race) {
            case "§1§lAlien(Metroman)"          -> 3000000;
            case "§4§lViltrumite"         -> 50000;
            case "§4§lBeast"              -> 92000000;
            case "§f§lHuman"              -> 1;
            case HumanLikeRaces.BORN_FOR_V,
                 HumanLikeRaces.PREDISPOSITION -> 1;
            case "§6§lUnopan"             -> 8750;
            case "§f§lHuman-Viltrumite"   -> 5580;
            case "§1§lThraxan-Viltrumite" -> 1820;
            default                       -> 10000;
        };
    }

    public static double getLvlMaxForUI(String race) {
        if (race == null) return 200;
        return switch (race) {
            case "§f§lHuman"              -> 1;
            case HumanLikeRaces.BORN_FOR_V,
                 HumanLikeRaces.PREDISPOSITION -> 1;
            case "§6§lUnopan"             -> 750;
            case "§f§lHuman-Viltrumite"   -> 580;
            case "§1§lThraxan-Viltrumite" -> 220;
            default                       -> 10000;
        };
    }

    public static boolean isAtCap(Entity entity) {
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            double cap = getLevelCap(vars.Race);
            return cap > 0 && vars.Lvl >= cap;
        } catch (Exception e) {
            return false;
        }
    }
}