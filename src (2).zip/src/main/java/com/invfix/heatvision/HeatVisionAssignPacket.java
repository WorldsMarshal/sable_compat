package com.invfix.heatvision;

import com.invfix.altrumite.AltrumiteRace;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Клиент → Сервер: выбрать одну из двух лучевых способностей в AbilitySet.
 * mode 1 = Heat Vision (LVL 30), mode 2 = Neutron Beam (LVL 50).
 */
public record HeatVisionAssignPacket(int x, int y, int z, int mode) implements CustomPacketPayload {

    public static final Type<HeatVisionAssignPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "hv_assign"));

    public static final StreamCodec<FriendlyByteBuf, HeatVisionAssignPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, msg) -> {
                        buf.writeInt(msg.x()); buf.writeInt(msg.y()); buf.writeInt(msg.z());
                        buf.writeVarInt(msg.mode());
                    },
                    buf -> new HeatVisionAssignPacket(
                            buf.readInt(), buf.readInt(), buf.readInt(), buf.readVarInt())
            );

    @Override
    public Type<HeatVisionAssignPacket> type() { return TYPE; }

    public static void handleServer(HeatVisionAssignPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer player)) return;
            try {
                InvincibleIncModVariables.PlayerVariables vars =
                        player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                if (!AltrumiteRace.isAltrumite(vars.Race)) return;

                String ability;
                double lvlNeeded;
                if (pkt.mode() == HeatVisionHandler.MODE_BLUE) {
                    ability = HeatVisionHandler.ABILITY_BLUE;
                    lvlNeeded = HeatVisionHandler.LVL_BLUE;
                } else {
                    ability = HeatVisionHandler.ABILITY_RED;
                    lvlNeeded = HeatVisionHandler.LVL_RED;
                }

                if (vars.Lvl < lvlNeeded) return; // уровень не достигнут

                vars.AbilitySet = ability;
                vars.abilityDescription = ability + " | LVL:" + (int) lvlNeeded + " | ";
                vars.markSyncDirty();
            } catch (Exception ignored) {}
        });
    }
}