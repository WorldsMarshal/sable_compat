package com.invfix.heatvision;

import com.invfix.grab.GrabSyncPacket;
import com.invfix.kineticstrike.KineticStrikeAssignPacket;
import com.invfix.kineticstrike.KineticStrikeStatePacket;
import com.invfix.kineticstrike.PacketMushroomCloud;
import com.invfix.network.ClientPacketHandlers;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Регистрация всех сетевых пакетов мода (Heat Vision + Kinetic Strike + Grab + ThreatMode + Time Stop).
 *
 * ВАЖНО: все методы handleClient у пакетов помечены @OnlyIn(Dist.CLIENT) и
 * вырезаются на сервере. Поэтому клиентские приёмники здесь НЕ ссылаются на
 * Packet::handleClient напрямую, а идут через ClientPacketHandlers (CLIENT-only
 * класс) и только если FMLEnvironment.dist == Dist.CLIENT. На сервере приёмник —
 * no-op: эти пакеты сервер только отправляет, принимать ему нечего.
 */
@EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD)
public class HeatVisionRegistration {

    private static final boolean CLIENT = FMLEnvironment.dist == Dist.CLIENT;

    @SubscribeEvent
    public static void onRegisterPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("sable_compat");

        // ── Heat Vision ──
        // Bidirectional: серверную половину обрабатываем всегда, клиентскую — только на клиенте.
        registrar.playBidirectional(
                HeatVisionHitPosSyncPacket.TYPE,
                HeatVisionHitPosSyncPacket.STREAM_CODEC,
                (pkt, ctx) -> {
                    if (CLIENT) {
                        ClientPacketHandlers.heatVisionHitPos(pkt, ctx);
                    } else {
                        HeatVisionHitPosSyncPacket.handleServer(pkt, ctx);
                    }
                });
        registrar.playToServer(
                HeatVisionAssignPacket.TYPE,
                HeatVisionAssignPacket.STREAM_CODEC,
                HeatVisionAssignPacket::handleServer);

        // Зарядка Хоумлендера: клиент шлёт состояние Alt, сервер шлёт свечение наблюдателям.
        registrar.playToServer(
                HeatVisionChargePacket.TYPE,
                HeatVisionChargePacket.STREAM_CODEC,
                HeatVisionChargePacket::handleServer);
        registrar.playToClient(
                HeatVisionGlowSyncPacket.TYPE,
                HeatVisionGlowSyncPacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.heatVisionGlow(pkt, ctx); });

        // ── Kinetic Strike ──
        registrar.playToServer(
                KineticStrikeAssignPacket.TYPE,
                KineticStrikeAssignPacket.STREAM_CODEC,
                KineticStrikeAssignPacket::handleServer);
        registrar.playToClient(
                KineticStrikeStatePacket.TYPE,
                KineticStrikeStatePacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.kineticStrikeState(pkt, ctx); });

        // ── Kinetic Strike: шейдерный взрыв и звук ──
        registrar.playToClient(
                PacketMushroomCloud.TYPE,
                PacketMushroomCloud.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.mushroomCloud(pkt, ctx); });

        // ── Удары способностей при Attackpwr > 500: импакт-кадры и ударная волна ──
        registrar.playToClient(
                com.invfix.combo.ComboImpactPacket.TYPE,
                com.invfix.combo.ComboImpactPacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.comboImpact(pkt, ctx); });

        // ── Heat Disruption (Metroman, LVL 500) ──
        registrar.playToServer(
                com.invfix.heatdisruption.HeatDisruptionAssignPacket.TYPE,
                com.invfix.heatdisruption.HeatDisruptionAssignPacket.STREAM_CODEC,
                com.invfix.heatdisruption.HeatDisruptionAssignPacket::handleServer);
        registrar.playToClient(
                com.invfix.heatdisruption.HeatDisruptionPacket.TYPE,
                com.invfix.heatdisruption.HeatDisruptionPacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.heatDisruption(pkt, ctx); });

        // ── Dismantle (Metroman, LVL 100) ──
        registrar.playToServer(
                com.invfix.dismantle.DismantleAssignPacket.TYPE,
                com.invfix.dismantle.DismantleAssignPacket.STREAM_CODEC,
                com.invfix.dismantle.DismantleAssignPacket::handleServer);
        registrar.playBidirectional(
                com.invfix.dismantle.DismantleSettingsPacket.TYPE,
                com.invfix.dismantle.DismantleSettingsPacket.STREAM_CODEC,
                (pkt, ctx) -> {
                    if (ctx.player() instanceof net.minecraft.server.level.ServerPlayer) {
                        com.invfix.dismantle.DismantleSettingsPacket.handleServer(pkt, ctx);
                    } else if (CLIENT) {
                        ClientPacketHandlers.dismantleSettings(pkt, ctx);
                    }
                });
        registrar.playToClient(
                com.invfix.dismantle.DismantlePacket.TYPE,
                com.invfix.dismantle.DismantlePacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.dismantle(pkt, ctx); });

        // ── Energy Blast (Metroman, LVL 200) ──
        registrar.playToServer(
                com.invfix.energyblast.EnergyBlastPackets.Assign.TYPE,
                com.invfix.energyblast.EnergyBlastPackets.Assign.STREAM_CODEC,
                com.invfix.energyblast.EnergyBlastPackets.Assign::handleServer);
        registrar.playToClient(
                com.invfix.energyblast.EnergyBlastPackets.Charge.TYPE,
                com.invfix.energyblast.EnergyBlastPackets.Charge.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.energyBlastCharge(pkt, ctx); });
        registrar.playToClient(
                com.invfix.energyblast.EnergyBlastPackets.Shot.TYPE,
                com.invfix.energyblast.EnergyBlastPackets.Shot.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.energyBlastShot(pkt, ctx); });
        registrar.playToClient(
                com.invfix.energyblast.EnergyBlastPackets.Blast.TYPE,
                com.invfix.energyblast.EnergyBlastPackets.Blast.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.energyBlastBlast(pkt, ctx); });

        // ── The Whole Sentry Power (Metroman, LVL 750) ──
        registrar.playToServer(
                com.invfix.sentry.SentryAssignPacket.TYPE,
                com.invfix.sentry.SentryAssignPacket.STREAM_CODEC,
                com.invfix.sentry.SentryAssignPacket::handleServer);
        registrar.playToClient(
                com.invfix.sentry.SentryPacket.TYPE,
                com.invfix.sentry.SentryPacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.sentry(pkt, ctx); });

        // ── Space Fold (Metroman, LVL 1000) ──
        registrar.playToServer(
                com.invfix.spacefold.SpaceFoldAssignPacket.TYPE,
                com.invfix.spacefold.SpaceFoldAssignPacket.STREAM_CODEC,
                com.invfix.spacefold.SpaceFoldAssignPacket::handleServer);
        registrar.playBidirectional(
                com.invfix.spacefold.SpaceFoldSettingsPacket.TYPE,
                com.invfix.spacefold.SpaceFoldSettingsPacket.STREAM_CODEC,
                (pkt, ctx) -> {
                    if (ctx.player() instanceof net.minecraft.server.level.ServerPlayer) {
                        com.invfix.spacefold.SpaceFoldSettingsPacket.handleServer(pkt, ctx);
                    } else if (CLIENT) {
                        ClientPacketHandlers.spaceFoldSettings(pkt, ctx);
                    }
                });
        registrar.playToClient(
                com.invfix.spacefold.SpaceFoldPacket.TYPE,
                com.invfix.spacefold.SpaceFoldPacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.spaceFold(pkt, ctx); });

        // ── Thermal Sense (Metroman) ──
        registrar.playToServer(
                com.invfix.thermal.ThermalAssignPacket.TYPE,
                com.invfix.thermal.ThermalAssignPacket.STREAM_CODEC,
                com.invfix.thermal.ThermalAssignPacket::handleServer);
        registrar.playToClient(
                com.invfix.thermal.ThermalPacket.TYPE,
                com.invfix.thermal.ThermalPacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.thermal(pkt, ctx); });

        // ── Grab & Throw (автономный порт The Boys) ──
        registrar.playToClient(
                GrabSyncPacket.TYPE,
                GrabSyncPacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.grab(pkt, ctx); });

        // ── Time Stop ──
        registrar.playToServer(
                com.invfix.timestop.TimeStopAssignPacket.TYPE,
                com.invfix.timestop.TimeStopAssignPacket.STREAM_CODEC,
                com.invfix.timestop.TimeStopAssignPacket::handleServer);
        registrar.playToClient(
                com.invfix.timestop.TimeStopSyncPacket.TYPE,
                com.invfix.timestop.TimeStopSyncPacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.timeStopSync(pkt, ctx); });
        registrar.playToClient(
                com.invfix.timestop.TimeStopFreezePosPacket.TYPE,
                com.invfix.timestop.TimeStopFreezePosPacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.timeStopFreezePos(pkt, ctx); });
        // Мгновенная остановка: цель от клиента, гашение интерполяции у зрителей.
        registrar.playToServer(
                com.invfix.timestop.blink.TimeStopBlinkPacket.TYPE,
                com.invfix.timestop.blink.TimeStopBlinkPacket.STREAM_CODEC,
                com.invfix.timestop.blink.TimeStopBlinkPacket::handleServer);
        registrar.playToClient(
                com.invfix.timestop.blink.TimeStopNoLerpPacket.TYPE,
                com.invfix.timestop.blink.TimeStopNoLerpPacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.timeStopNoLerp(pkt, ctx); });
        // Щит: попадание — купол и искры у всех в радиусе.
        registrar.playToClient(
                com.invfix.rick.shield.ShieldEffectPacket.TYPE,
                com.invfix.rick.shield.ShieldEffectPacket.STREAM_CODEC,
                (pkt, ctx) -> { if (CLIENT) ClientPacketHandlers.shieldEffect(pkt, ctx); });

        // ── Threatening/Playful Mode: клиент шлёт состояние клавиши удержания ──
        registrar.playToServer(
                com.invfix.threatmode.ThreatModePacket.TYPE,
                com.invfix.threatmode.ThreatModePacket.STREAM_CODEC,
                com.invfix.threatmode.ThreatModePacket::handleServer);
    }
}