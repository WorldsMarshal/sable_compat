package com.invfix.heatvision;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Регистрация звуков лучей. Отдельные звуки для теплового (red) и нейтронного (blue).
 *
 * ВАЖНО: чтобы звуки заработали, в главном классе мода InvincibleFix
 * в конструкторе нужно вызвать:  HeatVisionSounds.SOUNDS.register(modEventBus);
 *
 * Сами .ogg файлы кладутся в:
 *   src/main/resources/assets/sable_compat/sounds/<имя>.ogg
 * и описываются в:
 *   src/main/resources/assets/sable_compat/sounds.json
 *
 * Если .ogg отсутствует — игра не крашится, просто не проигрывает звук (лог-варнинг).
 */
public final class HeatVisionSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, "sable_compat");

    // Тепловое зрение (красный)
    public static final DeferredHolder<SoundEvent, SoundEvent> HEAT_VISION_START = reg("heat_vision_start");
    public static final DeferredHolder<SoundEvent, SoundEvent> HEAT_VISION_LOOP  = reg("heat_vision_loop");
    public static final DeferredHolder<SoundEvent, SoundEvent> HEAT_VISION_END   = reg("heat_vision_end");

    // Нейтронный луч (синий)
    public static final DeferredHolder<SoundEvent, SoundEvent> NEUTRON_START = reg("neutron_start");
    public static final DeferredHolder<SoundEvent, SoundEvent> NEUTRON_LOOP  = reg("neutron_loop");
    public static final DeferredHolder<SoundEvent, SoundEvent> NEUTRON_END   = reg("neutron_end");

    private static DeferredHolder<SoundEvent, SoundEvent> reg(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(
                        ResourceLocation.fromNamespaceAndPath("sable_compat", name)));
    }

    private HeatVisionSounds() {}
}