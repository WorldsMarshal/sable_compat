package com.invfix.heatvision;

import com.invfix.heatvision.client.HeatVisionClientHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Сервер → клиенты-наблюдатели: игрок {@code entityId} сейчас «заряжает» луч
 * (режим mode). Клиент рисует ему свечение глаз без самого луча.
 */
public record HeatVisionGlowSyncPacket(int entityId, int mode) implements CustomPacketPayload {

    public static final Type<HeatVisionGlowSyncPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "hv_glow_sync"));

    public static final StreamCodec<FriendlyByteBuf, HeatVisionGlowSyncPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, msg) -> {
                        buf.writeVarInt(msg.entityId());
                        buf.writeVarInt(msg.mode());
                    },
                    buf -> new HeatVisionGlowSyncPacket(buf.readVarInt(), buf.readVarInt())
            );

    @Override
    public Type<HeatVisionGlowSyncPacket> type() { return TYPE; }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(HeatVisionGlowSyncPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
            if (mc.level == null) return;
            // Себе свечение зарядки выставляем локально (без round-trip) — пропускаем.
            if (mc.player != null && mc.player.getId() == pkt.entityId()) return;
            HeatVisionClientHandler.setRemoteCharge(pkt.entityId(), pkt.mode());
        });
    }
}