package com.invfix.heatvision;

import com.invfix.heatvision.client.HeatVisionClientHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Синхронизирует позицию попадания луча + режим (1 красный / 2 синий).
 */
public record HeatVisionHitPosSyncPacket(int entityId, double x, double y, double z, int mode)
        implements CustomPacketPayload {

    public static final Type<HeatVisionHitPosSyncPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "hv_hit_pos_sync"));

    public static final StreamCodec<FriendlyByteBuf, HeatVisionHitPosSyncPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, msg) -> {
                        buf.writeVarInt(msg.entityId());
                        buf.writeDouble(msg.x());
                        buf.writeDouble(msg.y());
                        buf.writeDouble(msg.z());
                        buf.writeVarInt(msg.mode());
                    },
                    buf -> new HeatVisionHitPosSyncPacket(
                            buf.readVarInt(), buf.readDouble(), buf.readDouble(), buf.readDouble(), buf.readVarInt())
            );

    @Override
    public Type<HeatVisionHitPosSyncPacket> type() { return TYPE; }

    public static void handleServer(HeatVisionHitPosSyncPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
                HeatVisionHandler.updateClientHitPos(sp, new Vec3(pkt.x(), pkt.y(), pkt.z()));
            }
        });
    }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(HeatVisionHitPosSyncPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
            if (mc.level == null) return;
            if (mc.player == null || mc.player.getId() != pkt.entityId()) {
                HeatVisionClientHandler.setRemoteHitPos(pkt.entityId(), new Vec3(pkt.x(), pkt.y(), pkt.z()), pkt.mode());
            }
        });
    }
}