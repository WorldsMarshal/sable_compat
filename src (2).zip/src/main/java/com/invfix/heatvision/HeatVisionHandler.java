package com.invfix.heatvision;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Серверная логика двух лучевых способностей Altrumite.
 *
 * MODE 1 — Heat Vision (§c красный, LVL 30): поджигает мобов/поверхности.
 * MODE 2 — Neutron Beam (§9 синий, LVL 50): урон +25%, ломает блоки взрывами.
 *
 * Авто-деактивация: клиент шлёт позицию прицеливания каждый тик пока луч активен.
 * Если сервер не получает апдейтов HEARTBEAT_TIMEOUT тиков — выключаем луч.
 * Это страховка на случай если KeyHeldFalseProcedure не сработал — иначе
 * эффекты (огонь/взрыв) продолжали бы спавниться после отпускания клавиши.
 */
public final class HeatVisionHandler {

    public static final String ABILITY_RED  = "§c§lHeat Vision";
    public static final String ABILITY_BLUE = "§9§lNeutron Beam";

    public static final int LVL_RED  = 30;
    public static final int LVL_BLUE = 50;

    public static final int MODE_NONE = 0;
    public static final int MODE_RED  = 1;
    public static final int MODE_BLUE = 2;

    private static final String NBT_ACTIVE = "invfix_hvActive";
    private static final String NBT_MODE   = "invfix_hvMode";

    private static final int   DAMAGE_INTERVAL = 1;     // урон каждый тик (в 5x чаще)
    private static final int   EFFECT_INTERVAL = 1;     // огонь/взрыв каждый тик (в 5x чаще урона)
    private static final int   FIRE_SECONDS    = 2;
    private static final int   CLIENT_HIT_TTL  = 4;
    private static final int   VISUAL_INTERVAL = 2;
    private static final int   HEARTBEAT_TIMEOUT = 3; // тиков без апдейта от клиента → выключаем
    private static final float MAX_DISTANCE    = 500.0f;
    private static final float HIT_RADIUS      = 0.5f;
    private static final float NEUTRON_DAMAGE_MULT = 1.5f;
    private static final float NEUTRON_EXPLOSION_RADIUS = 2.2f;
    private static final double NEUTRON_BORE_RADIUS      = 3.0;  // нейтронный луч сносит любой блок (кроме бедрока)
    private static final double NEUTRON_CLEANUP_RADIUS  = 6.0;  // радиус удаления выпавших предметов

    private static final Map<UUID, Integer>   ACTIVE_TICKS   = new ConcurrentHashMap<>();
    private static final Map<UUID, SyncedHit> CLIENT_HIT_POS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long>      HEARTBEAT      = new ConcurrentHashMap<>();

    // ── Зарядка Хоумлендера (зажат Alt) ────────────────────────────────────────
    /** Игрок → gameTime последнего «Alt зажат» (TTL в тиках). */
    private static final Map<UUID, Long>    ALT_HELD      = new ConcurrentHashMap<>();
    /** Игрок → режим заряжаемого луча (для цвета свечения). */
    private static final Map<UUID, Integer> CHARGE_MODE   = new ConcurrentHashMap<>();
    /** Игрок → gameTime последнего тика зарядки (TTL). */
    private static final Map<UUID, Long>    CHARGE_TICK   = new ConcurrentHashMap<>();
    private static final int ALT_TTL              = 4;
    private static final int CHARGE_TTL           = 4;
    private static final int CHARGE_GLOW_INTERVAL = 2;

    private HeatVisionHandler() {}

    // ── Активация / деактивация ────────────────────────────────────────────────

    public static void activate(ServerPlayer player, int mode) {
        player.getPersistentData().putBoolean(NBT_ACTIVE, true);
        player.getPersistentData().putInt(NBT_MODE, mode);
        // Стартовый heartbeat — даём клиенту время начать слать позицию
        HEARTBEAT.put(player.getUUID(), player.level().getGameTime());
    }

    public static void deactivate(Entity entity) {
        entity.getPersistentData().putBoolean(NBT_ACTIVE, false);
        entity.getPersistentData().putInt(NBT_MODE, MODE_NONE);
        if (entity instanceof ServerPlayer sp) {
            ACTIVE_TICKS.remove(sp.getUUID());
            CLIENT_HIT_POS.remove(sp.getUUID());
            HEARTBEAT.remove(sp.getUUID());
        }
    }

    public static boolean isActive(Entity entity) {
        return entity.getPersistentData().getBoolean(NBT_ACTIVE);
    }

    // ── Зарядка ────────────────────────────────────────────────────────────────

    /** Клиент сообщает состояние Left Alt. */
    public static void setAltHeld(ServerPlayer player, boolean held) {
        if (held) ALT_HELD.put(player.getUUID(), player.level().getGameTime());
        else ALT_HELD.remove(player.getUUID());
    }

    /** Зажат ли сейчас Alt (свежий флаг от клиента). */
    public static boolean isChargeHeld(Entity entity) {
        Long t = ALT_HELD.get(entity.getUUID());
        return t != null && entity.level().getGameTime() - t <= ALT_TTL;
    }

    /**
     * Перевод в состояние зарядки: реального лазера нет (если был активен —
     * гасим), только запоминаем режим и время для рассылки свечения.
     */
    public static void markCharging(ServerPlayer player, int mode) {
        if (isActive(player)) deactivate(player);
        CHARGE_MODE.put(player.getUUID(), mode);
        CHARGE_TICK.put(player.getUUID(), player.level().getGameTime());
    }

    public static int getMode(Entity entity) {
        return entity.getPersistentData().getInt(NBT_MODE);
    }

    // ── Серверный тик ─────────────────────────────────────────────────────────

    public static void serverTick(ServerLevel level) {
        for (ServerPlayer player : level.players()) {
            try {
                if (!isActive(player)) {
                    ACTIVE_TICKS.remove(player.getUUID());
                    CLIENT_HIT_POS.remove(player.getUUID());
                    HEARTBEAT.remove(player.getUUID());
                    continue;
                }

                int ticks = ACTIVE_TICKS.getOrDefault(player.getUUID(), 0) + 1;
                ACTIVE_TICKS.put(player.getUUID(), ticks);

                // Авто-выключение по heartbeat (после небольшого грейса)
                if (ticks > HEARTBEAT_TIMEOUT) {
                    long last = HEARTBEAT.getOrDefault(player.getUUID(), 0L);
                    if (level.getGameTime() - last > HEARTBEAT_TIMEOUT) {
                        deactivate(player);
                        continue;
                    }
                }

                if (ticks == 1 || player.tickCount % VISUAL_INTERVAL == 0) {
                    syncVisualBeam(player);
                }
                boolean doDamage  = player.tickCount % DAMAGE_INTERVAL == 0;
                boolean doEffects = player.tickCount % EFFECT_INTERVAL == 0;
                if (doDamage || doEffects) {
                    processBeam(player, doDamage, doEffects);
                }
            } catch (Exception ignored) {}
        }

        // Рассылка свечения зарядки наблюдателям + чистка протухших.
        long now = level.getGameTime();
        for (ServerPlayer player : level.players()) {
            Long ct = CHARGE_TICK.get(player.getUUID());
            if (ct == null) continue;
            if (now - ct > CHARGE_TTL) {
                CHARGE_TICK.remove(player.getUUID());
                CHARGE_MODE.remove(player.getUUID());
                continue;
            }
            if (player.tickCount % CHARGE_GLOW_INTERVAL == 0) {
                int mode = CHARGE_MODE.getOrDefault(player.getUUID(), MODE_RED);
                HeatVisionGlowSyncPacket pkt = new HeatVisionGlowSyncPacket(player.getId(), mode);
                PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, pkt, new CustomPacketPayload[0]);
            }
        }
    }

    /** Вызывается при получении позиции от клиента — обновляет heartbeat. */
    public static void updateClientHitPos(ServerPlayer player, Vec3 hitPos) {
        if (player == null || hitPos == null) return;
        long now = player.level().getGameTime();
        CLIENT_HIT_POS.put(player.getUUID(), new SyncedHit(hitPos, now + CLIENT_HIT_TTL));
        HEARTBEAT.put(player.getUUID(), now);
    }

    private static void syncVisualBeam(ServerPlayer player) {
        Vec3 eye  = HeatVisionGeometry.getDynamicEyeBase(player, 1.0f);
        Vec3 look = player.getLookAngle();
        Vec3 end  = resolveBeamEnd(player, eye, look);
        int mode  = getMode(player);
        HeatVisionHitPosSyncPacket pkt =
                new HeatVisionHitPosSyncPacket(player.getId(), end.x, end.y, end.z, mode);
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, pkt, new CustomPacketPayload[0]);
    }

    // ── Урон ──────────────────────────────────────────────────────────────────

    /**
     * Единый серверный рейкаст луча. Находит первую преграду — блок ИЛИ хитбокс
     * живого существа (что ближе). Луч упирается в эту точку.
     *
     * Урон наносится сразу (без задержки «роста» луча).
     * Нейтронный взрыв происходит на endpoint (на хитбоксе существа, если оно перекрывает).
     * Термальный огонь спавнится только если луч упёрся в БЛОК (не за существом).
     */
    private static void processBeam(ServerPlayer player, boolean doDamage, boolean doEffects) {
        int mode = getMode(player);
        Vec3 eye  = HeatVisionGeometry.getDynamicEyeBase(player, 1.0f);
        Vec3 look = player.getLookAngle();
        if (look.lengthSqr() < 1e-6) return;
        Vec3 dir = look.normalize();

        // Блок в пределах прогруженных чанков
        BlockHitResult blockHit = clipLoaded(player, eye, look);
        double blockDist;
        Vec3 blockEnd;
        boolean blockSolid = blockHit != null
                && blockHit.getType() != net.minecraft.world.phys.HitResult.Type.MISS;
        if (blockSolid) {
            blockEnd = blockHit.getLocation();
            blockDist = eye.distanceTo(blockEnd);
        } else {
            blockDist = maxLoadedDistance(player, eye, dir, MAX_DISTANCE);
            blockEnd = eye.add(dir.scale(blockDist));
        }

        // Ближайшая живая сущность на луче в пределах blockDist
        AABB box = HeatVisionGeometry.createBeamSearchBox(eye, blockEnd, HIT_RADIUS);
        LivingEntity firstEntity = null;
        double firstDist = blockDist;
        Vec3 firstHit = blockEnd;
        for (Entity e : player.level().getEntities(player, box,
                ent -> ent instanceof LivingEntity le && le.isAlive() && ent != player)) {
            Vec3 hit = HeatVisionGeometry.clipInflatedBox(eye, blockEnd, e.getBoundingBox(), HIT_RADIUS);
            if (hit != null) {
                double d = eye.distanceTo(hit);
                if (d < firstDist) {
                    firstDist = d;
                    firstEntity = (LivingEntity) e;
                    firstHit = hit;
                }
            }
        }

        boolean entityBlocking = firstEntity != null;
        Vec3 endpoint = entityBlocking ? firstHit : blockEnd;

        // Урон — мгновенно по первой перекрывающей сущности (луч упирается в неё)
        if (doDamage && firstEntity != null) {
            double damage = calcDamage(player);
            if (mode == MODE_RED) {
                damage *= 0.3f;
            } else if (mode == MODE_BLUE) {
                damage *= NEUTRON_DAMAGE_MULT;
            }
            firstEntity.invulnerableTime = 0;
            firstEntity.hurtTime = 0;
// Используем косвенный магический урон.
// Теперь ни один мод не посмеет прибавить сюда модификаторы ближнего боя!
            firstEntity.hurt(player.damageSources().indirectMagic(player, player), (float) damage);
            firstEntity.igniteForSeconds(FIRE_SECONDS);
        }

        // Поджигаем предметы на луче до endpoint
        if (doDamage) {
            AABB itemBox = HeatVisionGeometry.createBeamSearchBox(eye, endpoint, HIT_RADIUS);
            for (ItemEntity item : player.level().getEntitiesOfClass(ItemEntity.class, itemBox,
                    it -> !it.isRemoved() && !it.getItem().isEmpty() && !it.fireImmune())) {
                Vec3 hit = HeatVisionGeometry.clipInflatedBox(eye, endpoint, item.getBoundingBox(), HIT_RADIUS);
                if (hit != null) {
                    item.setRemainingFireTicks(40);
                    item.discard();
                }
            }
        }

        // Эффекты
        if (doEffects) {
            if (mode == MODE_RED) {
                // Огонь только если луч упёрся в блок (не за существом)
                if (!entityBlocking && blockSolid) {
                    igniteSurfaceAt(player, blockHit);
                }
            } else if (mode == MODE_BLUE) {
                // Взрыв на endpoint (хитбокс существа, если перекрывает, иначе блок)
                explodeAt(player, endpoint);
            }
        }
    }

    private static void igniteSurfaceAt(ServerPlayer player, BlockHitResult hit) {
        BlockPos firePos = hit.getBlockPos().relative(hit.getDirection());
        if (player.level().isEmptyBlock(firePos)) {
            player.level().setBlockAndUpdate(firePos,
                    net.minecraft.world.level.block.Blocks.FIRE.defaultBlockState());
        }
    }

    private static void explodeAt(ServerPlayer player, Vec3 loc) {
        // Если луч закончился в жидкости (прошёл сквозь неё, твёрдого блока не встретил) —
        // никакого эффекта: нейтронный луч просто прошивает воду/лаву.
        if (player.level().getBlockState(BlockPos.containing(loc)).getBlock()
                instanceof net.minecraft.world.level.block.LiquidBlock) {
            return;
        }

        // The Whole Sentry Power: разрушения ×1.5
        double mult = com.invfix.sentry.SentryHandler.destruction(player);
        player.level().explode(player, loc.x, loc.y, loc.z,
                (float) (NEUTRON_EXPLOSION_RADIUS * mult), Level.ExplosionInteraction.BLOCK);

        // Нейтронный луч сносит ЛЮБОЙ блок (кроме бедрока). Обычный взрыв ограничен
        // сопротивлением блоков, поэтому сферу вокруг точки попадания вычищаем вручную.
        boreBlocks(player.level(), loc, NEUTRON_BORE_RADIUS * mult);

        // Взрыв оставляет блоки/дроп — убираем все выпавшие предметы в радиусе 6,
        // чтобы на точке попадания ничего не оставалось (только нейтронный луч).
        AABB cleanup = new AABB(
                loc.x - NEUTRON_CLEANUP_RADIUS, loc.y - NEUTRON_CLEANUP_RADIUS, loc.z - NEUTRON_CLEANUP_RADIUS,
                loc.x + NEUTRON_CLEANUP_RADIUS, loc.y + NEUTRON_CLEANUP_RADIUS, loc.z + NEUTRON_CLEANUP_RADIUS);
        for (ItemEntity drop : player.level().getEntitiesOfClass(ItemEntity.class, cleanup)) {
            drop.discard();
        }
    }

    /**
     * Вычищает сферу блоков вокруг точки попадания нейтронного луча.
     * Сносит любой блок, КРОМЕ бедрока. Жидкости (вода/лава) не трогаются —
     * луч их «прошивает» без эффекта. Воздух пропускается.
     */
    private static void boreBlocks(Level level, Vec3 loc, double radius) {
        int r = (int) Math.ceil(radius);
        double rSq = radius * radius;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int cx = (int) Math.floor(loc.x), cy = (int) Math.floor(loc.y), cz = (int) Math.floor(loc.z);
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (dx * dx + dy * dy + dz * dz > rSq) continue;
                    pos.set(cx + dx, cy + dy, cz + dz);
                    var state = level.getBlockState(pos);
                    if (state.isAir()) continue;                                    // нечего сносить
                    if (state.is(net.minecraft.world.level.block.Blocks.BEDROCK)) continue; // бедрок неуязвим
                    if (state.getBlock() instanceof net.minecraft.world.level.block.LiquidBlock) continue; // жидкости прошиваем
                    level.setBlock(pos, net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
    }

    private static double calcDamage(ServerPlayer player) {
        try {
            InvincibleIncModVariables.PlayerVariables v =
                    player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            double base = v.currentStr * v.statMultiplier * 0.01;
            return Math.max(0.5, Math.min(base, 500.0));
        } catch (Exception e) {
            return 1.0;
        }
    }

    private static Vec3 resolveBeamEnd(ServerPlayer player, Vec3 origin, Vec3 look) {
        Vec3 fallback = clipToBlock(player, origin, look);
        SyncedHit synced = CLIENT_HIT_POS.get(player.getUUID());
        if (synced == null) return fallback;
        if (player.level().getGameTime() > synced.expireTime()) {
            CLIENT_HIT_POS.remove(player.getUUID());
            return fallback;
        }
        Vec3 toSynced = synced.hitPos().subtract(origin);
        double dist = toSynced.length();
        if (dist < 0.05 || dist > 501.0) return fallback;
        Vec3 normLook = look.lengthSqr() > 1e-6 ? look.normalize() : Vec3.ZERO;
        Vec3 syncDir  = toSynced.scale(1.0 / dist);
        if (normLook != Vec3.ZERO && syncDir.dot(normLook) < 0.7) return fallback;

        // Клампим к прогруженной дистанции — чтобы урон/поиск сущностей не уходили
        // в непрогруженные чанки и не раздували AABB.
        double maxLoaded = maxLoadedDistance(player, origin, syncDir, MAX_DISTANCE);
        if (dist > maxLoaded && maxLoaded > 0.0) {
            return origin.add(syncDir.scale(maxLoaded));
        }
        return synced.hitPos();
    }

    /**
     * Максимальная дистанция вдоль луча, на которой чанки уже ПРОГРУЖЕНЫ.
     * Идём шагами по чанку; первый непрогруженный чанк обрывает луч.
     * Это не даёт level.clip() синхронно генерировать линию чанков (фриз на горизонте/небе).
     */
    private static double maxLoadedDistance(ServerPlayer player, Vec3 origin, Vec3 dir, double maxDist) {
        double step = 16.0;
        double d = step;
        double reached = 0.0;
        while (d <= maxDist) {
            Vec3 p = origin.add(dir.scale(d));
            if (!player.level().isLoaded(BlockPos.containing(p))) break;
            reached = d;
            d += step;
        }
        return reached;
    }

    /** clip только в пределах прогруженных чанков. */
    private static BlockHitResult clipLoaded(ServerPlayer player, Vec3 origin, Vec3 look) {
        Vec3 dir = look.lengthSqr() > 1e-6 ? look.normalize() : look;
        double maxLoaded = maxLoadedDistance(player, origin, dir, MAX_DISTANCE);
        if (maxLoaded <= 0.0) return null; // даже ближний чанк не загружен — некуда стрелять
        Vec3 end = origin.add(dir.scale(maxLoaded));
        return player.level().clip(
                new ClipContext(origin, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
    }

    private static Vec3 clipToBlock(ServerPlayer player, Vec3 origin, Vec3 look) {
        Vec3 dir = look.lengthSqr() > 1e-6 ? look.normalize() : look;
        double maxLoaded = maxLoadedDistance(player, origin, dir, MAX_DISTANCE);
        Vec3 end = origin.add(dir.scale(maxLoaded));
        if (maxLoaded <= 0.0) return end;
        BlockHitResult hit = player.level().clip(
                new ClipContext(origin, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        return hit.getType() != net.minecraft.world.phys.HitResult.Type.MISS
                ? hit.getLocation() : end;
    }

    private record SyncedHit(Vec3 hitPos, long expireTime) {}
}