package com.invfix.heatvision.client;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.heatvision.HeatVisionChargePacket;
import com.invfix.heatvision.HeatVisionGeometry;
import com.invfix.heatvision.HeatVisionHandler;
import com.invfix.heatvision.HeatVisionHitPosSyncPacket;
import com.invfix.heatvision.HeatVisionSounds;
import net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.PacketDistributor;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@OnlyIn(Dist.CLIENT)
public final class HeatVisionClientHandler {

    private static final Map<Integer, Float>   BEAM_VALUES = new ConcurrentHashMap<>();
    private static final Map<Integer, Float>   PREV_VALUES = new ConcurrentHashMap<>();
    private static final Map<Integer, Vec3>    HIT_POS     = new ConcurrentHashMap<>();
    private static final Map<Integer, Integer> MODES       = new ConcurrentHashMap<>();
    private static final Map<Integer, Integer> NETWORK_TTL = new ConcurrentHashMap<>();
    private static final Map<Integer, HeatVisionLoopSound> SOUNDS = new ConcurrentHashMap<>();
    private static final Set<Integer> PREV_ACTIVE = ConcurrentHashMap.newKeySet();

    // Зарядка (свечение без луча): id → режим / TTL.
    private static final Map<Integer, Integer> CHARGE_MODE = new ConcurrentHashMap<>();
    private static final Map<Integer, Integer> CHARGE_TTL  = new ConcurrentHashMap<>();
    private static final int CHARGE_TTL_TICKS = 4;

    public static final float MAX_DISTANCE   = 500.0f;
    private static final float EXTEND_SPEED  = 0.15f;
    private static final float RETRACT_SPEED = 0.25f;
    private static final int   NETWORK_TTL_TICKS = 6;

    private static boolean clientHeld = false;
    private static int     clientMode = HeatVisionHandler.MODE_NONE;

    public static boolean isHeatVisionActive(Player player) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && player.getId() == mc.player.getId()) return clientHeld;
        return hasFreshNetworkHit(player.getId());
    }

    public static boolean hasVisibleBeam(int id) { return BEAM_VALUES.getOrDefault(id, 0f) > 0f; }

    public static float getBeamValue(int id, float partial) {
        float cur  = BEAM_VALUES.getOrDefault(id, 0f);
        float prev = PREV_VALUES.getOrDefault(id, 0f);
        return prev + (cur - prev) * partial;
    }

    public static Vec3 getHitPosition(int id) { return HIT_POS.get(id); }

    /** Режим луча сущности (1 красный / 2 синий). */
    public static int getMode(int id) { return MODES.getOrDefault(id, HeatVisionHandler.MODE_RED); }

    // ── Зарядка (свечение без луча) ─────────────────────────────────────────────

    public static boolean isCharging(int id) { return CHARGE_TTL.getOrDefault(id, 0) > 0; }

    public static int getChargeMode(int id) { return CHARGE_MODE.getOrDefault(id, HeatVisionHandler.MODE_RED); }

    /** Свечение зарядки наблюдаемого игрока (из серверного пакета). */
    public static void setRemoteCharge(int id, int mode) {
        CHARGE_MODE.put(id, mode);
        CHARGE_TTL.put(id, CHARGE_TTL_TICKS);
    }

    private static void tickChargeTTL() {
        CHARGE_TTL.replaceAll((id, ttl) -> ttl - 1);
        CHARGE_TTL.entrySet().removeIf(e -> {
            if (e.getValue() <= 0) { CHARGE_MODE.remove(e.getKey()); return true; }
            return false;
        });
    }

    public static void setRemoteHitPos(int id, Vec3 hitPos, int mode) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) {
            var tracked = mc.level.getEntity(id);
            if (tracked instanceof LivingEntity le && (!le.isAlive() || le.isRemoved())) {
                NETWORK_TTL.remove(id); HIT_POS.remove(id); MODES.remove(id);
                return;
            }
        }
        HIT_POS.put(id, hitPos);
        MODES.put(id, mode);
        NETWORK_TTL.put(id, NETWORK_TTL_TICKS);
    }

    public static void clientTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;

        updateClientHeld(mc);
        tickNetworkTTL();
        tickChargeTTL();

        Set<Integer> currentActive = ConcurrentHashMap.newKeySet();
        for (AbstractClientPlayer player : mc.level.players()) {
            int id = player.getId();
            boolean active = isHeatVisionActive(player) || hasFreshNetworkHit(id);
            processEntity(player, id, active, mc, currentActive);
        }
        cleanupDead(mc);

        for (int id : PREV_ACTIVE) {
            if (!currentActive.contains(id)) {
                var ent = mc.level.getEntity(id);
                if (ent instanceof LivingEntity le) {
                    int m = getMode(id);
                    SoundEvent end = (m == HeatVisionHandler.MODE_BLUE)
                            ? HeatVisionSounds.NEUTRON_END.get()
                            : HeatVisionSounds.HEAT_VISION_END.get();
                    mc.level.playLocalSound(le.getX(), le.getY(), le.getZ(),
                            end, SoundSource.PLAYERS, 0.6f, 1.0f, false);
                }
                stopSound(id);
            }
        }
        PREV_ACTIVE.clear();
        PREV_ACTIVE.addAll(currentActive);

        // лучи рисует новая графика (HeatVisionFx), пока хоть один виден
        if (!BEAM_VALUES.isEmpty()) HeatVisionFx.keepAlive(mc.level);
    }

    private static void updateClientHeld(Minecraft mc) {
        if (mc.player == null) { clientHeld = false; clientMode = HeatVisionHandler.MODE_NONE; return; }
        try {
            InvincibleIncModVariables.PlayerVariables v =
                    mc.player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (!AltrumiteRace.isAltrumite(v.Race)) {
                clientHeld = false; clientMode = HeatVisionHandler.MODE_NONE; return;
            }
            int mode = heldMode(v);
            clientMode = mode;
            boolean abilityDown = mode != HeatVisionHandler.MODE_NONE;
            boolean altDown     = isLeftAltDown(mc);
            boolean charging    = abilityDown && altDown;

            // Реальный луч качаем только когда Alt НЕ зажат (иначе это зарядка).
            clientHeld = abilityDown && !altDown;

            if (abilityDown) {
                MODES.put(mc.player.getId(), mode);
                // Сообщаем серверу состояние Alt — он решает «зарядка/выстрел».
                PacketDistributor.sendToServer(new HeatVisionChargePacket(altDown), new CustomPacketPayload[0]);
            }
            if (charging) {
                // Своё свечение зарядки выставляем локально (для вида от 3-го лица).
                int selfId = mc.player.getId();
                CHARGE_MODE.put(selfId, mode);
                CHARGE_TTL.put(selfId, CHARGE_TTL_TICKS);
            }
        } catch (Exception e) {
            clientHeld = false; clientMode = HeatVisionHandler.MODE_NONE;
        }
    }

    private static boolean isLeftAltDown(Minecraft mc) {
        // Бинд Threatening/Playful Mode (по умолчанию Left Alt, можно переназначить
        // в настройках управления). Удержание = «зарядка» Heat Vision (только свечение).
        return com.invfix.threatmode.ThreatModeClientEvents.isHeld();
    }

    /** Определяет какой режим зажат: проверяет слоты на оба названия. */
    private static int heldMode(InvincibleIncModVariables.PlayerVariables v) {
        boolean row1 = v.AbilityRow == 1.0;
        String s1 = row1 ? v.AbilitySlot1 : v.AbilitySlot1_row2;
        String s2 = row1 ? v.AbilitySlot2 : v.AbilitySlot2_row2;
        String s3 = row1 ? v.AbilitySlot3 : v.AbilitySlot3_row2;
        String s4 = row1 ? v.AbilitySlot4 : v.AbilitySlot4_row2;
        String s5 = row1 ? v.AbilitySlot5 : v.AbilitySlot5_row2;

        var km = InvincibleIncModKeyMappings.class;
        if (down(0) && match(s1)) return modeOf(s1);
        if (down(1) && match(s2)) return modeOf(s2);
        if (down(2) && match(s3)) return modeOf(s3);
        if (down(3) && match(s4)) return modeOf(s4);
        if (down(4) && match(s5)) return modeOf(s5);
        return HeatVisionHandler.MODE_NONE;
    }

    private static boolean down(int idx) {
        KeyMapping km = switch (idx) {
            case 0 -> InvincibleIncModKeyMappings.ABILITY_1;
            case 1 -> InvincibleIncModKeyMappings.ABILITY_2;
            case 2 -> InvincibleIncModKeyMappings.ABILITY_3;
            case 3 -> InvincibleIncModKeyMappings.ABILITY_4;
            case 4 -> InvincibleIncModKeyMappings.ABILITY_5;
            default -> null;
        };
        return km != null && rawDown(km);
    }

    /**
     * Физическое состояние клавиши способности — в обход модификатор-гейтинга NeoForge.
     *
     * У бинда с {@code KeyModifier.NONE} метод {@code KeyMapping.isDown()} возвращает
     * false, пока зажат любой модификатор (Alt). Из-за этого при порядке
     * «зажал Alt → жму способность» нажатие не детектилось (нет свечения зарядки), а на
     * отпускании Alt был большой лаг, пока NeoForge не перерегистрирует состояние бинда.
     * Здесь читаем GLFW напрямую каждый тик: Alt больше не мешает, порядок нажатия не
     * важен, на отпускании Alt луч стартует мгновенно.
     *
     * В меню/чате ({@code mc.screen != null}) ведём себя как обычный isDown — не реагируем.
     */
    private static boolean rawDown(KeyMapping km) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen != null) return false;
        InputConstants.Key key = km.getKey();
        if (key == null || key.getValue() == InputConstants.UNKNOWN.getValue()) return false;
        long window = mc.getWindow().getWindow();
        return switch (key.getType()) {
            case KEYSYM -> InputConstants.isKeyDown(window, key.getValue());
            case MOUSE  -> GLFW.glfwGetMouseButton(window, key.getValue()) == GLFW.GLFW_PRESS;
            default     -> km.isDown();
        };
    }

    private static boolean match(String slot) {
        return HeatVisionHandler.ABILITY_RED.equals(slot) || HeatVisionHandler.ABILITY_BLUE.equals(slot);
    }

    private static int modeOf(String slot) {
        if (HeatVisionHandler.ABILITY_BLUE.equals(slot)) return HeatVisionHandler.MODE_BLUE;
        return HeatVisionHandler.MODE_RED;
    }

    private static void processEntity(LivingEntity entity, int id, boolean active,
                                      Minecraft mc, Set<Integer> currentActive) {
        float prev = BEAM_VALUES.getOrDefault(id, 0f);
        PREV_VALUES.put(id, prev);

        if (active) {
            float val = Math.min(prev + EXTEND_SPEED, 1f);
            if (prev <= 0f) {
                int m = getMode(id);
                SoundEvent start = (m == HeatVisionHandler.MODE_BLUE)
                        ? HeatVisionSounds.NEUTRON_START.get()
                        : HeatVisionSounds.HEAT_VISION_START.get();
                mc.level.playLocalSound(entity.getX(), entity.getY(), entity.getZ(),
                        start, SoundSource.PLAYERS, 0.7f, 1.0f, false);
                startSound(id, entity, m);
            }
            currentActive.add(id);

            boolean local = mc.player != null && mc.player.getId() == id;
            if (local) {
                updateRaycast(entity);
                Vec3 hitPos = HIT_POS.get(id);
                if (hitPos != null) {
                    PacketDistributor.sendToServer(
                            new HeatVisionHitPosSyncPacket(id, hitPos.x, hitPos.y, hitPos.z, clientMode),
                            new CustomPacketPayload[0]);
                }
            } else if (!hasFreshNetworkHit(id)) {
                updateRaycast(entity);
            }
            BEAM_VALUES.put(id, val);
        } else {
            float val = Math.max(prev - RETRACT_SPEED, 0f);
            if (val <= 0f) {
                BEAM_VALUES.remove(id); PREV_VALUES.remove(id); HIT_POS.remove(id); MODES.remove(id);
            } else {
                BEAM_VALUES.put(id, val);
            }
        }
    }

    private static void updateRaycast(LivingEntity entity) {
        Vec3 eye  = HeatVisionGeometry.getDynamicEyeBase(entity, 1.0f);
        Vec3 look = entity.getLookAngle();
        HeatVisionGeometry.TraceResult trace =
                HeatVisionGeometry.traceBeam(entity, eye, look, MAX_DISTANCE, 0.35, e -> true);
        HIT_POS.put(entity.getId(), trace.hitPos());
    }

    private static void tickNetworkTTL() {
        NETWORK_TTL.replaceAll((id, ttl) -> ttl - 1);

        NETWORK_TTL.entrySet().removeIf(e -> {
            if (e.getValue() <= 0) {
                HIT_POS.remove(e.getKey());
                MODES.remove(e.getKey());
                return true;
            }
            return false;
        });
    }

    private static void cleanupDead(Minecraft mc) {
        BEAM_VALUES.keySet().removeIf(id -> {
            var e = mc.level.getEntity(id);
            if (e instanceof LivingEntity le && le.isAlive() && !le.isRemoved()) return false;
            PREV_VALUES.remove(id); HIT_POS.remove(id); MODES.remove(id); NETWORK_TTL.remove(id);
            stopSound(id);
            return true;
        });
    }

    private static boolean hasFreshNetworkHit(int id) {
        return NETWORK_TTL.getOrDefault(id, 0) > 0 && HIT_POS.containsKey(id);
    }

    private static void startSound(int id, LivingEntity entity, int mode) {
        if (!SOUNDS.containsKey(id)) {
            SoundEvent loop = (mode == HeatVisionHandler.MODE_BLUE)
                    ? HeatVisionSounds.NEUTRON_LOOP.get()
                    : HeatVisionSounds.HEAT_VISION_LOOP.get();
            HeatVisionLoopSound s = new HeatVisionLoopSound(entity, loop);
            SOUNDS.put(id, s);
            Minecraft.getInstance().getSoundManager().play(s);
        }
    }

    private static void stopSound(int id) {
        HeatVisionLoopSound s = SOUNDS.remove(id);
        if (s != null) s.markStopped();
    }

    public static void clearAll() {
        BEAM_VALUES.clear(); PREV_VALUES.clear(); HIT_POS.clear(); MODES.clear();
        NETWORK_TTL.clear(); PREV_ACTIVE.clear();
        CHARGE_MODE.clear(); CHARGE_TTL.clear();
        SOUNDS.values().forEach(HeatVisionLoopSound::markStopped);
        SOUNDS.clear();
        clientHeld = false; clientMode = HeatVisionHandler.MODE_NONE;
    }
}