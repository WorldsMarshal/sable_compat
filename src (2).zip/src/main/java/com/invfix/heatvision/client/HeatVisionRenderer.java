package com.invfix.heatvision.client;

import com.invfix.heatvision.HeatVisionHandler;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import static com.invfix.heatvision.HeatVisionGeometry.*;

/**
 * Рендер лучей. Цвет зависит от режима:
 *  MODE_RED  — белое ядро + оранжево-красное свечение (Heat Vision).
 *  MODE_BLUE — бело-голубое ядро + глубоко-синее свечение (Neutron Beam).
 */
@OnlyIn(Dist.CLIENT)
public final class HeatVisionRenderer {

    private record Palette(float cR,float cG,float cB,float cA, float gR,float gG,float gB,float gA) {}

    private static final Palette RED  = new Palette(1.0f,0.95f,0.85f,0.95f,  1.0f,0.25f,0.05f,0.55f);
    private static final Palette BLUE = new Palette(0.85f,0.95f,1.0f,0.95f,  0.1f,0.4f,1.0f,0.6f);

    private static final float BEAM_WIDTH = 0.04375f;
    private static final int   BLOOM_LAYERS = 3;

    // ======================================================================
    //  Свечение глаз (flash.png). Меняй эти переменные под нужный результат.
    // ======================================================================
    /** Вкл/выкл свечение глаз целиком. */
    public static boolean GLOW_ENABLED      = true;
    /** Вынос свечения вперёд от глаз вдоль направления взгляда/луча, в блоках. */
    public static float   GLOW_FORWARD      = 0.23f;
    /** Общий множитель размера поверх размера-от-дистанции. */
    public static float   GLOW_SIZE_MULT    = 1.0f;
    /** Общий множитель яркости (альфы) свечения. */
    public static float   GLOW_BRIGHTNESS   = 1.15f;
    /** Подмешивание белого в центр (0 — чистый цвет луча, 1 — белый). */
    public static float   GLOW_WHITEN       = 0.35f;
    /** Амплитуда пульсации размера (0 — без пульсации). */
    public static float   GLOW_PULSE_AMP    = 0f;
    /** Скорость пульсации размера. */
    public static float   GLOW_PULSE_SPEED  = 0.35f;
    /**
     * Скрывать flash, когда модель головы перекрывает точку спавна для наблюдателя
     * (глаза смотрят от камеры). Порог по dot(направление взгляда, на камеру):
     *  -1 — не скрывать никогда, 0 — показывать пока лицо в сторону камеры (по умолч.),
     *   1 — только когда смотрит строго в камеру. Подними чуть выше 0, чтобы профиль
     *   тоже скрывался, опусти ниже 0 — чтобы flash дольше оставался виден сбоку.
     */
    public static float   GLOW_FACE_THRESHOLD = 0.0f;

    // --- Размер flash для стороннего наблюдателя в зависимости от дистанции ---
    //  Три опорные точки, между ними плавная интерполяция, дальше — по нарастающей.
    public static float GLOW_DIST_NEAR = 5f;   public static float GLOW_SIZE_NEAR = 0.45f;
    public static float GLOW_DIST_MID  = 15f;  public static float GLOW_SIZE_MID  = 2.5f;
    public static float GLOW_DIST_FAR  = 50f;  public static float GLOW_SIZE_FAR  = 5.0f;
    /** Потолок размера, чтобы на больших дистанциях не раздувало до бесконечности. */
    public static float GLOW_SIZE_MAX  = 6.0f;

    /** Текстура свечения — та же flash.png, что и у частиц. */
    private static final ResourceLocation FLASH =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/particle/flash_eyes.png");

    /** Размер билборда (диаметр в блоках) по дистанции до наблюдателя. */
    private static float sizeForDistance(double d) {
        if (d <= GLOW_DIST_NEAR) return GLOW_SIZE_NEAR;
        if (d <= GLOW_DIST_MID)
            return Mth.lerp((float)((d - GLOW_DIST_NEAR) / (GLOW_DIST_MID - GLOW_DIST_NEAR)),
                    GLOW_SIZE_NEAR, GLOW_SIZE_MID);
        if (d <= GLOW_DIST_FAR)
            return Mth.lerp((float)((d - GLOW_DIST_MID) / (GLOW_DIST_FAR - GLOW_DIST_MID)),
                    GLOW_SIZE_MID, GLOW_SIZE_FAR);
        float slope = (GLOW_SIZE_FAR - GLOW_SIZE_MID) / (GLOW_DIST_FAR - GLOW_DIST_MID);
        return Math.min(GLOW_SIZE_FAR + slope * (float)(d - GLOW_DIST_FAR), GLOW_SIZE_MAX);
    }

    private HeatVisionRenderer() {}

    /**
     * Внешний источник свечения глаз. Позволяет другим способностям (например,
     * Heat Vision из The Boys) переиспользовать наше свечение глаз, не таща
     * зависимости этих модов в ядро рендера. Источник возвращает true, пока у
     * игрока должна гореть «glow» — независимо от того, идёт ли луч.
     */
    @FunctionalInterface
    public interface GlowSource {
        boolean isGlowing(AbstractClientPlayer player);
    }

    private static final List<GlowSource> GLOW_SOURCES = new CopyOnWriteArrayList<>();

    public static void addGlowSource(GlowSource source) {
        if (source != null) GLOW_SOURCES.add(source);
    }

    private static boolean extraGlowing(AbstractClientPlayer player) {
        for (GlowSource s : GLOW_SOURCES) {
            try { if (s.isGlowing(player)) return true; } catch (Exception ignored) {}
        }
        return false;
    }

    /**
     * Виден ли flash наблюдателю, или его перекрывает модель головы перса.
     * Геометрическая аппроксимация без рейкаста по мешу: точка спавна на лице,
     * значит она видна, только когда камера в полупространстве, куда направлен
     * взгляд. dot(look, наПравлениеНаКамеру) > порога — видно.
     */
    private static boolean glowVisible(Vec3 spawn, Vec3 lookDir, Vec3 camPos) {
        if (lookDir.lengthSqr() < 1e-6) return true;
        Vec3 toCam = camPos.subtract(spawn);
        if (toCam.lengthSqr() < 1e-6) return true;
        return lookDir.normalize().dot(toCam.normalize()) > GLOW_FACE_THRESHOLD;
    }

    private static Palette paletteForMode(int mode) {
        return mode == HeatVisionHandler.MODE_BLUE ? BLUE : RED;
    }

    private static Palette paletteFor(int id) {
        return paletteForMode(HeatVisionClientHandler.getMode(id));
    }

    public static void renderFirstPerson(PoseStack ps, float partial) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        if (!mc.options.getCameraType().isFirstPerson()) return;

        AbstractClientPlayer player = mc.player;
        int id = player.getId();
        if (!HeatVisionClientHandler.hasVisibleBeam(id)) return;
        float beamVal = HeatVisionClientHandler.getBeamValue(id, partial);
        if (beamVal <= 0f) return;
        Vec3 hitPos = HeatVisionClientHandler.getHitPosition(id);
        if (hitPos == null) return;

        Vec3 camPos = mc.gameRenderer.getMainCamera().getPosition();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        float headYaw = Mth.lerp(partial, player.yHeadRotO, player.yHeadRot);
        Vec3 eyeBase  = getDynamicEyeBase(player, partial);
        Vec3 beamDir  = hitPos.subtract(eyeBase).normalize();
        double fullDist = eyeBase.distanceTo(hitPos);
        float beamLen = (float)(fullDist * beamVal);
        double yawRad = Math.toRadians(headYaw);
        Vec3 right    = new Vec3(Math.cos(yawRad), 0, Math.sin(yawRad));
        double side   = getDynamicEyeSideOffset(player);
        Palette p = paletteFor(id);

        renderBeam(ps, buf, camPos, eyeBase.add(right.scale(side)),
                eyeBase.add(right.scale(side)).add(beamDir.scale(beamLen)), player.tickCount, partial, p);
        renderBeam(ps, buf, camPos, eyeBase.add(right.scale(-side)),
                eyeBase.add(right.scale(-side)).add(beamDir.scale(beamLen)), player.tickCount, partial, p);
        buf.endBatch(RenderType.lightning());
    }

    public static void renderAll(PoseStack ps, float partial) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        Vec3 camPos = mc.gameRenderer.getMainCamera().getPosition();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();

        for (AbstractClientPlayer player : mc.level.players()) {
            if (player == mc.player && mc.options.getCameraType().isFirstPerson()) continue;
            int id = player.getId();
            if (!HeatVisionClientHandler.hasVisibleBeam(id)) continue;
            float beamVal = HeatVisionClientHandler.getBeamValue(id, partial);
            if (beamVal <= 0f) continue;
            Vec3 hitPos = HeatVisionClientHandler.getHitPosition(id);
            if (hitPos == null) continue;

            float headYaw = Mth.lerp(partial, player.yHeadRotO, player.yHeadRot);
            Vec3 eyeBase  = getDynamicEyeBase(player, partial);
            Vec3 beamDir  = hitPos.subtract(eyeBase).normalize();
            double fullDist = eyeBase.distanceTo(hitPos);
            float beamLen = (float)(fullDist * beamVal);
            double yawRad = Math.toRadians(headYaw);
            Vec3 right    = new Vec3(Math.cos(yawRad), 0, Math.sin(yawRad));
            double side   = getDynamicEyeSideOffset(player);
            Palette p = paletteFor(id);

            Vec3 eyeR = eyeBase.add(right.scale(side));
            Vec3 eyeL = eyeBase.add(right.scale(-side));
            renderBeam(ps, buf, camPos, eyeR, eyeR.add(beamDir.scale(beamLen)), player.tickCount, partial, p);
            renderBeam(ps, buf, camPos, eyeL, eyeL.add(beamDir.scale(beamLen)), player.tickCount, partial, p);
        }
        buf.endBatch(RenderType.lightning());
    }

    /** Одна светящаяся точка глаза: где, цвет (уже с подмешанным белым), яркость 0..1. */
    public record EyeGlow(Vec3 pos, float r, float g, float b, float intensity) {}

    /**
     * Все светящиеся сейчас глаза — те же, что рисуются билбордами ниже (луч,
     * зарядка на Alt, внешние источники), с теми же правилами видимости. Новая
     * графика (EyeGlowFx) рисует по ним две концентрированные точки света
     * вместо flash_eyes.png. Свои глаза от первого лица не светятся.
     */
    public static void collectEyeGlows(float partial, Vec3 camPos, java.util.function.Consumer<EyeGlow> out) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || !GLOW_ENABLED) return;
        for (AbstractClientPlayer player : mc.level.players()) {
            if (player == mc.player && mc.options.getCameraType().isFirstPerson()) continue;
            int id = player.getId();
            boolean firing   = HeatVisionClientHandler.hasVisibleBeam(id);
            boolean charging = HeatVisionClientHandler.isCharging(id);
            boolean extra    = !firing && !charging && !GLOW_SOURCES.isEmpty() && extraGlowing(player);
            if (!firing && !charging && !extra) continue;

            float headYaw = Mth.lerp(partial, player.yHeadRotO, player.yHeadRot);
            Vec3 eyeBase  = getDynamicEyeBase(player, partial);
            double yawRad = Math.toRadians(headYaw);
            Vec3 right    = new Vec3(Math.cos(yawRad), 0, Math.sin(yawRad));
            double side   = getDynamicEyeSideOffset(player);
            Vec3 eyeR = eyeBase.add(right.scale(side));
            Vec3 eyeL = eyeBase.add(right.scale(-side));

            Palette p;
            Vec3 dir;
            float intensity;
            if (firing) {
                Vec3 hitPos = HeatVisionClientHandler.getHitPosition(id);
                if (hitPos == null) continue;
                dir = hitPos.subtract(eyeBase).normalize();
                p = paletteFor(id);
                intensity = HeatVisionClientHandler.getBeamValue(id, partial);
            } else {
                Vec3 look = player.getViewVector(partial);
                dir = look.lengthSqr() > 1e-6 ? look.normalize() : right;
                p = !charging && com.invfix.heatdisruption.client.HeatDisruptionClient.eyesBlue(id)
                        ? BLUE : paletteForMode(HeatVisionClientHandler.getChargeMode(id));
                intensity = 1.0f;
            }
            float r = Mth.lerp(GLOW_WHITEN, p.gR(), 1.0f);
            float g = Mth.lerp(GLOW_WHITEN, p.gG(), 1.0f);
            float b = Mth.lerp(GLOW_WHITEN, p.gB(), 1.0f);
            Vec3 fwd = dir.scale(GLOW_FORWARD);
            Vec3 sR = eyeR.add(fwd), sL = eyeL.add(fwd);
            float alpha = Mth.clamp(GLOW_BRIGHTNESS * intensity, 0f, 1f);
            if (glowVisible(sR, dir, camPos)) out.accept(new EyeGlow(sR, r, g, b, alpha));
            if (glowVisible(sL, dir, camPos)) out.accept(new EyeGlow(sL, r, g, b, alpha));
        }
    }

    /**
     * Свечение глаз для всех видимых игроков. Рисуется ОТДЕЛЬНОЙ стадией
     * (после облаков), поэтому вынесено из renderAll. Свои глаза в FP пропускаем.
     * Если работает новая графика (eye_glow.fsh), глаза рисует EyeGlowFx, а здесь
     * ничего не делается.
     */
    public static void renderEyeGlowsAll(PoseStack ps, float partial) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        if (com.invfix.fx.FxManager.shaderUsable("eye_glow")) return;
        Camera cam = mc.gameRenderer.getMainCamera();
        Vec3 camPos = cam.getPosition();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();

        for (AbstractClientPlayer player : mc.level.players()) {
            if (player == mc.player && mc.options.getCameraType().isFirstPerson()) continue;
            int id = player.getId();

            boolean firing   = HeatVisionClientHandler.hasVisibleBeam(id);
            boolean charging = HeatVisionClientHandler.isCharging(id);
            boolean extra    = !firing && !charging
                    && !GLOW_SOURCES.isEmpty() && extraGlowing(player);
            if (!firing && !charging && !extra) continue;

            float headYaw = Mth.lerp(partial, player.yHeadRotO, player.yHeadRot);
            Vec3 eyeBase  = getDynamicEyeBase(player, partial);
            double yawRad = Math.toRadians(headYaw);
            Vec3 right    = new Vec3(Math.cos(yawRad), 0, Math.sin(yawRad));
            double side   = getDynamicEyeSideOffset(player);
            Vec3 eyeR = eyeBase.add(right.scale(side));
            Vec3 eyeL = eyeBase.add(right.scale(-side));
            float glowT = player.tickCount + partial;

            if (firing) {
                Vec3 hitPos = HeatVisionClientHandler.getHitPosition(id);
                if (hitPos == null) continue;
                float beamVal = HeatVisionClientHandler.getBeamValue(id, partial);
                Vec3 beamDir  = hitPos.subtract(eyeBase).normalize();
                Palette p = paletteFor(id);

                Vec3 fwd = beamDir.scale(GLOW_FORWARD);
                Vec3 sR = eyeR.add(fwd), sL = eyeL.add(fwd);
                if (glowVisible(sR, beamDir, camPos)) renderEyeGlow(ps, buf, cam, camPos, sR, p, beamVal, glowT);
                if (glowVisible(sL, beamDir, camPos)) renderEyeGlow(ps, buf, cam, camPos, sL, p, beamVal, glowT);
            } else {
                Palette p = !charging && com.invfix.heatdisruption.client.HeatDisruptionClient.eyesBlue(id)
                        ? BLUE : paletteForMode(HeatVisionClientHandler.getChargeMode(id));
                Vec3 look = player.getViewVector(partial);
                Vec3 dir  = look.lengthSqr() > 1e-6 ? look.normalize() : right;
                Vec3 fwd  = dir.scale(GLOW_FORWARD);
                Vec3 sR = eyeR.add(fwd), sL = eyeL.add(fwd);
                if (glowVisible(sR, dir, camPos)) renderEyeGlow(ps, buf, cam, camPos, sR, p, 1.0f, glowT);
                if (glowVisible(sL, dir, camPos)) renderEyeGlow(ps, buf, cam, camPos, sL, p, 1.0f, glowT);
            }
        }
        buf.endBatch(HeatVisionGlowRenderType.glow(FLASH));
    }

    /**
     * Билборд-свечение глаза: камеро-ориентированный квад с текстурой flash.png,
     * аддитивно подсвеченный цветом луча. Размер — от дистанции до наблюдателя
     * (плавно), яркость — из intensity (0..1: разгон луча или зарядка).
     */
    private static void renderEyeGlow(PoseStack ps, MultiBufferSource.BufferSource buf,
                                      Camera cam, Vec3 camPos, Vec3 eyeWorld,
                                      Palette pal, float intensity, float ticks) {
        if (!GLOW_ENABLED) return;

        double dist = camPos.distanceTo(eyeWorld);
        float pulse = 1f + GLOW_PULSE_AMP * Mth.sin(ticks * GLOW_PULSE_SPEED);
        float half  = sizeForDistance(dist) * GLOW_SIZE_MULT * pulse * 0.5f;
        if (half <= 0f) return;

        float alpha = Mth.clamp(GLOW_BRIGHTNESS * intensity, 0f, 1f);
        if (alpha <= 0f) return;

        // Цвет берём из свечения палитры луча, подмешивая белый в центр.
        float r = Mth.lerp(GLOW_WHITEN, pal.gR(), 1.0f);
        float g = Mth.lerp(GLOW_WHITEN, pal.gG(), 1.0f);
        float b = Mth.lerp(GLOW_WHITEN, pal.gB(), 1.0f);

        Vector3f left = cam.getLeftVector();
        Vector3f up   = cam.getUpVector();
        float lx = left.x() * half, ly = left.y() * half, lz = left.z() * half;
        float ux = up.x()   * half, uy = up.y()   * half, uz = up.z()   * half;

        ps.pushPose();
        ps.translate(eyeWorld.x - camPos.x, eyeWorld.y - camPos.y, eyeWorld.z - camPos.z);
        Matrix4f m = ps.last().pose();
        VertexConsumer vc = buf.getBuffer(HeatVisionGlowRenderType.glow(FLASH));

        vc.addVertex(m,  lx + ux,  ly + uy,  lz + uz).setUv(0f, 0f).setColor(r, g, b, alpha);
        vc.addVertex(m,  lx - ux,  ly - uy,  lz - uz).setUv(0f, 1f).setColor(r, g, b, alpha);
        vc.addVertex(m, -lx - ux, -ly - uy, -lz - uz).setUv(1f, 1f).setColor(r, g, b, alpha);
        vc.addVertex(m, -lx + ux, -ly + uy, -lz + uz).setUv(1f, 0f).setColor(r, g, b, alpha);

        ps.popPose();
    }

    private static void renderBeam(PoseStack ps, MultiBufferSource.BufferSource buf,
                                   Vec3 camPos, Vec3 start, Vec3 end, int ticks, float partial, Palette pal) {
        float len = (float) start.distanceTo(end);
        if (len < 0.01f) return;
        Vec3 rel = start.subtract(camPos);
        ps.pushPose();
        ps.translate(rel.x, rel.y, rel.z);
        Vec3 dir = end.subtract(start).normalize();
        ps.mulPose(Axis.YP.rotationDegrees((float) Math.toDegrees(Math.atan2(dir.x, dir.z))));
        ps.mulPose(Axis.XP.rotationDegrees((float) Math.toDegrees(Math.asin(-dir.y))));
        ps.mulPose(Axis.XP.rotationDegrees(90f));
        ps.mulPose(Axis.YP.rotationDegrees(((float) ticks + partial) % 360f));
        VertexConsumer vc = buf.getBuffer(RenderType.lightning());
        float h = BEAM_WIDTH / 2f;
        AABB core = new AABB(-h, 0, -h, h, len, h);
        box(ps, vc, core, pal.cR(), pal.cG(), pal.cB(), pal.cA());
        for (int i = 1; i <= BLOOM_LAYERS; i++) {
            float ex = i * 0.5f * 0.0625f;
            box(ps, vc, core.inflate(ex, 0, ex), pal.gR(), pal.gG(), pal.gB(), pal.gA() / i);
        }
        ps.popPose();
    }

    private static void box(PoseStack ps, VertexConsumer vc, AABB b,
                            float r, float g, float bl, float a) {
        Matrix4f m = ps.last().pose();
        int light = 15728640;
        float x0=(float)b.minX,y0=(float)b.minY,z0=(float)b.minZ,x1=(float)b.maxX,y1=(float)b.maxY,z1=(float)b.maxZ;
        vc.addVertex(m,x0,y1,z0).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x0,y1,z1).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x1,y1,z1).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x1,y1,z0).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x0,y0,z0).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x1,y0,z0).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x1,y0,z1).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x0,y0,z1).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x0,y0,z0).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x0,y1,z0).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x1,y1,z0).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x1,y0,z0).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x0,y0,z1).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x1,y0,z1).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x1,y1,z1).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x0,y1,z1).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x1,y0,z0).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x1,y1,z0).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x1,y1,z1).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x1,y0,z1).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x0,y0,z0).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x0,y0,z1).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x0,y1,z1).setColor(r,g,bl,a).setLight(light);
        vc.addVertex(m,x0,y1,z0).setColor(r,g,bl,a).setLight(light);
    }
}