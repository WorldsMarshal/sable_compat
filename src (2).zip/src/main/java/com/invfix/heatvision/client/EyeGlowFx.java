package com.invfix.heatvision.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.List;

/**
 * Свечение глаз новой графикой (eye_glow.fsh) вместо билборда flash_eyes.png:
 * на каждый светящийся глаз — маленькая очень концентрированная точка света
 * (белое ядро в пару пикселей, тугой ореол цвета луча, короткий горизонтальный
 * блик), размером в пикселях почти не зависящая от расстояния, поэтому видно её
 * примерно оттуда же, откуда был виден билборд. Какие глаза светятся и где —
 * HeatVisionRenderer.collectEyeGlows (луч, зарядка на Alt, Heat Disruption,
 * The Boys). Если шейдер не собрался, остаются билборды.
 */
@OnlyIn(Dist.CLIENT)
public final class EyeGlowFx extends FxEffect {

    /** Глаз за проход (Pts: 0–7 места, 8–15 цвета). */
    private static final int PER_PASS = 8;
    private static final int LINGER = 10;

    private static EyeGlowFx instance;

    private final ClientLevel level;
    private int idle;

    private EyeGlowFx(ClientLevel level) {
        this.level = level;
    }

    /** Каждый тик клиента: если хоть один глаз светится — эффект в работе. */
    public static void tick(ClientLevel level) {
        Minecraft mc = Minecraft.getInstance();
        boolean[] any = {false};
        HeatVisionRenderer.collectEyeGlows(1.0F, mc.gameRenderer.getMainCamera().getPosition(), e -> any[0] = true);
        if (!any[0]) return;
        if (instance == null || instance.finished() || instance.level != level) {
            instance = new EyeGlowFx(level);
            FxManager.add(instance);
        }
        instance.idle = 0;
    }

    @Override
    protected void onTick(Minecraft minecraft, ClientLevel level, int age) {
        idle++;
    }

    @Override
    protected int duration() {
        return Integer.MAX_VALUE;
    }

    @Override
    public boolean finished() {
        return idle > LINGER || Minecraft.getInstance().level != level;
    }

    @Override
    protected void onRemoved() {
        if (instance == this) instance = null;
    }

    @Override
    public Vec3 focus() {
        return FxManager.camera();
    }

    @Override
    public double range() {
        return Double.MAX_VALUE;
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        List<HeatVisionRenderer.EyeGlow> eyes = new ArrayList<>();
        HeatVisionRenderer.collectEyeGlows(frame.partial(), frame.camera(), eyes::add);
        float time = (age + frame.partial()) / 20.0F;
        for (int from = 0; from < eyes.size(); from += PER_PASS) {
            int count = Math.min(PER_PASS, eyes.size() - from);
            float[] pts = new float[16 * 4];
            for (int i = 0; i < count; i++) {
                HeatVisionRenderer.EyeGlow e = eyes.get(from + i);
                Vec3 rel = frame.rel(e.pos());
                pts[i * 4] = (float) rel.x;
                pts[i * 4 + 1] = (float) rel.y;
                pts[i * 4 + 2] = (float) rel.z;
                pts[i * 4 + 3] = e.intensity();
                pts[(PER_PASS + i) * 4] = e.r();
                pts[(PER_PASS + i) * 4 + 1] = e.g();
                pts[(PER_PASS + i) * 4 + 2] = e.b();
            }
            float n = count;
            out.add(new FxPass("eye_glow", u -> {
                u.f4("P0", n, time, 0.0F, 0.0F);
                u.vec4s("Pts", pts);
            }));
        }
    }
}
