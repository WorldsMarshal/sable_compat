package com.invfix.heatvision.client;

import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class HeatVisionLoopSound extends AbstractTickableSoundInstance {

    private final LivingEntity entity;
    private boolean shouldStop = false;

    public HeatVisionLoopSound(LivingEntity entity, SoundEvent loopSound) {
        super(loopSound,
                entity instanceof Player ? SoundSource.PLAYERS : SoundSource.HOSTILE,
                SoundInstance.createUnseededRandom());
        this.entity = entity;
        this.looping = true;
        this.delay = 0;
        this.volume = 0.7f;
        this.pitch = 1.0f;
        this.x = entity.getX();
        this.y = entity.getY();
        this.z = entity.getZ();
    }

    @Override
    public void tick() {
        if (shouldStop || !entity.isAlive() || entity.isRemoved()) {
            stop();
            return;
        }
        boolean active = entity instanceof Player p
                ? HeatVisionClientHandler.isHeatVisionActive(p)
                : HeatVisionClientHandler.hasVisibleBeam(entity.getId());
        if (!active) {
            stop();
        } else {
            this.x = entity.getX();
            this.y = entity.getY();
            this.z = entity.getZ();
        }
    }

    public void markStopped() { this.shouldStop = true; }
}