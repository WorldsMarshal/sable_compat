package com.invfix.heatvision.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import com.invfix.heatvision.HeatVisionGeometry;
import com.invfix.heatvision.HeatVisionHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.List;

/**
 * Лучи Heat Vision и Neutron Beam через новую графику (heat_vision.fsh): по
 * проходу на каждого стреляющего игрока — два луча из глаз, точка попадания со
 * свечением, светом на мир и маревом. Состояние лучей — то же, что и раньше
 * (HeatVisionClientHandler: видимость, разгон, точка попадания, режим);
 * свечение глаз (билборды HeatVisionRenderer) не тронуто.
 *
 * Эффект один на клиент: живёт, пока хоть у кого-то виден луч, и ещё секунду
 * после. Если шейдер не собрался, HeatVisionClientEvents рисует старые лучи.
 */
@OnlyIn(Dist.CLIENT)
public final class HeatVisionFx extends FxEffect {

    /** Сколько тиков эффект ждёт без лучей, прежде чем уйти. */
    private static final int LINGER = 20;

    private static HeatVisionFx instance;

    private final ClientLevel level;
    private int idle;

    private HeatVisionFx(ClientLevel level) {
        this.level = level;
    }

    /** Вызывается каждый тик клиента, пока у кого-то виден луч: эффект должен быть в работе. */
    public static void keepAlive(ClientLevel level) {
        if (instance == null || instance.finished() || instance.level != level) {
            instance = new HeatVisionFx(level);
            FxManager.add(instance);
        }
        instance.idle = 0;
    }

    @Override
    protected void onTick(Minecraft minecraft, ClientLevel level, int age) {
        idle++;
    }

    @Override
    protected int duration() {
        return Integer.MAX_VALUE;
    }

    @Override
    public boolean finished() {
        return idle > LINGER || Minecraft.getInstance().level != level;
    }

    @Override
    protected void onRemoved() {
        if (instance == this) instance = null;
    }

    @Override
    public Vec3 focus() {
        return FxManager.camera();
    }

    @Override
    public double range() {
        return Double.MAX_VALUE;
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        Minecraft mc = frame.minecraft();
        if (mc.level == null) return;
        float partial = frame.partial();
        float time = (age + partial) / 20.0F;
        for (AbstractClientPlayer player : mc.level.players()) {
            int id = player.getId();
            if (!HeatVisionClientHandler.hasVisibleBeam(id)) continue;
            float beamVal = HeatVisionClientHandler.getBeamValue(id, partial);
            Vec3 hit = HeatVisionClientHandler.getHitPosition(id);
            if (beamVal <= 0.0F || hit == null) continue;
            if (hit.distanceTo(frame.camera()) > 600.0 && player.position().distanceTo(frame.camera()) > 600.0) continue;

            float headYaw = Mth.lerp(partial, player.yHeadRotO, player.yHeadRot);
            Vec3 eyeBase = HeatVisionGeometry.getDynamicEyeBase(player, partial);
            double yawRad = Math.toRadians(headYaw);
            Vec3 right = new Vec3(Math.cos(yawRad), 0, Math.sin(yawRad));
            double side = HeatVisionGeometry.getDynamicEyeSideOffset(player);
            Vec3 eyeR = eyeBase.add(right.scale(side));
            Vec3 eyeL = eyeBase.add(right.scale(-side));
            // как у прежних лучей: оба идут параллельно, от глаз к точке попадания
            Vec3 dir = hit.subtract(eyeBase);
            double full = dir.length();
            if (full < 1.0E-3) continue;
            dir = dir.scale(1.0 / full);
            float length = (float) (full * beamVal);
            boolean own = player == mc.player && mc.options.getCameraType().isFirstPerson();
            float mode = HeatVisionClientHandler.getMode(id) == HeatVisionHandler.MODE_BLUE ? 2.0F : 1.0F;
            // точка попадания горит, только когда луч до неё дотянулся
            float landed = Mth.clamp((beamVal - 0.85F) / 0.15F, 0.0F, 1.0F);
            float seed = (float) ((id * 0.61803398875) % 1.0);

            Vec3 a = frame.rel(eyeR);
            Vec3 b = frame.rel(eyeL);
            Vec3 d = dir;
            Vec3 h = frame.rel(eyeBase.add(dir.scale(length)));
            float ownF = own ? 1.0F : 0.0F;
            Vec3 cam = frame.camera();
            float ox = (float) (cam.x - 2048.0 * Math.floor(cam.x / 2048.0));
            float oy = (float) (cam.y - 2048.0 * Math.floor(cam.y / 2048.0));
            float oz = (float) (cam.z - 2048.0 * Math.floor(cam.z / 2048.0));
            out.add(new FxPass("heat_vision", u -> {
                u.v3("Target", a);
                u.v3("Caster", b);
                u.v3("Facing", d);
                u.f3("Origin", ox, oy, oz);
                u.f4("P0", length, mode, time, ownF);
                u.f4("P1", (float) h.x, (float) h.y, (float) h.z, landed);
                u.f4("P2", seed, 0.0F, 0.0F, 0.0F);
            }));
            // The Whole Sentry Power: белые разряды там, где луч бьёт
            if (landed > 0.0F && com.invfix.sentry.client.SentryClient.isActive(id)) {
                float k = landed;
                out.add(new FxPass("sentry", u -> {
                    u.v3("Target", h);
                    u.f3("Origin", ox, oy, oz);
                    u.f4("P0", mode > 1.5F ? 3.5F : 2.2F, 0.0F, time, seed);
                    u.f4("P1", k * 0.85F, 0.0F, 0.55F, 1.0F);
                }));
            }
        }
    }

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        Minecraft mc = frame.minecraft();
        if (mc.level == null) return;
        // немного свечения, пока рядом бьёт луч
        for (AbstractClientPlayer player : mc.level.players()) {
            int id = player.getId();
            if (!HeatVisionClientHandler.hasVisibleBeam(id)) continue;
            Vec3 hit = HeatVisionClientHandler.getHitPosition(id);
            if (hit == null) continue;
            float near = proximity(frame, hit, 96.0);
            near = Math.max(near, proximity(frame, player.position(), 64.0));
            screen.bloom = Math.max(screen.bloom, 0.55F * near);
            screen.bloomRadius = Math.max(screen.bloomRadius, 1.1F);
        }
    }
}
