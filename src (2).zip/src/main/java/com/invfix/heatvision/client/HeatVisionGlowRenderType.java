package com.invfix.heatvision.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/**
 * Аддитивный текстурный RenderType для билборда-свечения глаз Heat Vision.
 *
 * Наследуемся от {@link RenderType} только чтобы достучаться до protected-шардов
 * ({@code ADDITIVE_TRANSPARENCY}, {@code NO_CULL} и т.д.) — это стандартный приём.
 * Глубина читается ({@code LEQUAL}), но НЕ пишется ({@code COLOR_WRITE}), без
 * лайтмапа (эмиссивно), аддитивное смешивание поверх сцены.
 */
@OnlyIn(Dist.CLIENT)
public final class HeatVisionGlowRenderType extends RenderType {

    private static RenderType INSTANCE;

    private HeatVisionGlowRenderType(String name, VertexFormat format, VertexFormat.Mode mode,
                                     int bufferSize, boolean affectsCrumbling, boolean sortOnUpload,
                                     Runnable setupState, Runnable clearState) {
        super(name, format, mode, bufferSize, affectsCrumbling, sortOnUpload, setupState, clearState);
    }

    public static RenderType glow(ResourceLocation texture) {
        if (INSTANCE == null) {
            INSTANCE = create(
                    "invfix_heatvision_glow",
                    DefaultVertexFormat.POSITION_TEX_COLOR,
                    VertexFormat.Mode.QUADS,
                    256,
                    false,
                    true,
                    RenderType.CompositeState.builder()
                            .setShaderState(new RenderStateShard.ShaderStateShard(GameRenderer::getPositionTexColorShader))
                            .setTextureState(new RenderStateShard.TextureStateShard(texture, false, false))
                            .setTransparencyState(ADDITIVE_TRANSPARENCY)
                            .setCullState(NO_CULL)
                            .setLightmapState(NO_LIGHTMAP)
                            .setWriteMaskState(COLOR_WRITE)
                            .setDepthTestState(LEQUAL_DEPTH_TEST)
                            .createCompositeState(false)
            );
        }
        return INSTANCE;
    }
}