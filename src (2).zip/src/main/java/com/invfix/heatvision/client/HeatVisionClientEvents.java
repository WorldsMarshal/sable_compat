package com.invfix.heatvision.client;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public class HeatVisionClientEvents {

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        HeatVisionClientHandler.clientTick();
        net.minecraft.client.multiplayer.ClientLevel level = net.minecraft.client.Minecraft.getInstance().level;
        if (level != null) EyeGlowFx.tick(level);
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        RenderLevelStageEvent.Stage stage = event.getStage();
        // Лучи — после полупрозрачных блоков (как раньше).
        if (stage == RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) {
            // лучи — новой графикой (HeatVisionFx, heat_vision.fsh); старые коробки — только
            // если шейдер не собрался
            if (com.invfix.fx.FxManager.shaderUsable("heat_vision")) return;
            float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
            HeatVisionRenderer.renderFirstPerson(event.getPoseStack(), partial);
            HeatVisionRenderer.renderAll(event.getPoseStack(), partial);
        }
        // Свечение глаз — ПОСЛЕ облаков (они рендерятся до AFTER_WEATHER),
        // иначе flash тускнеет за облачным слоем даже будучи перед ним.
        else if (stage == RenderLevelStageEvent.Stage.AFTER_WEATHER) {
            float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
            HeatVisionRenderer.renderEyeGlowsAll(event.getPoseStack(), partial);
        }
    }
}