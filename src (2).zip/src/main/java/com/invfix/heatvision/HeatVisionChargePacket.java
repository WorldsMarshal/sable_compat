package com.invfix.heatvision;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Клиент → сервер: текущее состояние зажатого Left Alt у игрока, пока активна
 * клавиша луча. Сервер по нему решает: зажат Alt → «зарядка» (только свечение,
 * без лазера); отпущен → реальный лазер. Шлётся каждый тик, пока ability нажат.
 */
public record HeatVisionChargePacket(boolean altHeld) implements CustomPacketPayload {

    public static final Type<HeatVisionChargePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "hv_charge"));

    public static final StreamCodec<FriendlyByteBuf, HeatVisionChargePacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, msg) -> buf.writeBoolean(msg.altHeld()),
                    buf -> new HeatVisionChargePacket(buf.readBoolean())
            );

    @Override
    public Type<HeatVisionChargePacket> type() { return TYPE; }

    public static void handleServer(HeatVisionChargePacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
                HeatVisionHandler.setAltHeld(sp, pkt.altHeld());
            }
        });
    }
}