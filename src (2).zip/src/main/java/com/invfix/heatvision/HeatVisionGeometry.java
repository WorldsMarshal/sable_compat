package com.invfix.heatvision;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Iterator;
import java.util.Optional;
import java.util.function.Predicate;

/** Геометрия луча. Портировано из LaserEyeGeometry (The Boys). */
public final class HeatVisionGeometry {

    private HeatVisionGeometry() {}

    public static Vec3 getDynamicEyeBase(LivingEntity entity, float partialTick) {
        Vec3 eye = entity.getEyePosition(partialTick);
        double eyeRel = eye.y - entity.getY();
        double min = entity.getBbHeight() * 0.35;
        double max = entity.getBbHeight() * 0.90;
        if (eyeRel < min) eye = eye.add(0, min - eyeRel, 0);
        else if (eyeRel > max) eye = eye.add(0, max - eyeRel, 0);

        Vec3 look = entity.getViewVector(partialTick);
        if (look.lengthSqr() < 1e-6) look = entity.getLookAngle();
        if (look.lengthSqr() > 1e-6) {
            double fwd = Mth.clamp(entity.getBbWidth() * 0.06, 0.015, 0.04);
            eye = eye.add(look.normalize().scale(fwd));
        }
        return eye;
    }

    public static double getDynamicEyeSideOffset(LivingEntity entity) {
        return Mth.clamp(entity.getBbWidth() * 0.12, 0.05, 0.1);
    }

    public static TraceResult traceBeam(LivingEntity shooter, Vec3 origin, Vec3 direction,
                                        double maxDist, double hitInflation,
                                        Predicate<LivingEntity> filter) {
        if (direction.lengthSqr() < 1e-6 || maxDist <= 0) return new TraceResult(origin, 0, null);

        Vec3 dir = direction.normalize();
        Vec3 maxEnd = origin.add(dir.scale(maxDist));
        BlockHitResult blockHit = shooter.level().clip(
                new ClipContext(origin, maxEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, shooter));

        double closestDist = maxDist;
        Vec3 closestHit = maxEnd;
        if (blockHit.getType() != net.minecraft.world.phys.HitResult.Type.MISS) {
            closestHit = blockHit.getLocation();
            closestDist = origin.distanceTo(closestHit);
        }

        AABB searchBox = createBeamSearchBox(origin, origin.add(dir.scale(closestDist)), hitInflation);
        LivingEntity closestEntity = null;
        double closestDistSq = closestDist * closestDist;

        for (LivingEntity target : shooter.level().getEntitiesOfClass(LivingEntity.class, searchBox,
                e -> e != shooter && e.isAlive() && filter.test(e))) {
            Vec3 hit = clipInflatedBox(origin, origin.add(dir.scale(closestDist)), target.getBoundingBox(), hitInflation);
            if (hit != null) {
                double dSq = origin.distanceToSqr(hit);
                if (dSq < closestDistSq) {
                    closestDistSq = dSq;
                    closestDist = Math.sqrt(dSq);
                    closestHit = hit;
                    closestEntity = target;
                }
            }
        }
        return new TraceResult(closestHit, closestDist, closestEntity);
    }

    public static Vec3 clipInflatedBox(Vec3 start, Vec3 end, AABB box, double inflation) {
        AABB inflated = box.inflate(inflation);
        Optional<Vec3> clip = inflated.clip(start, end);
        if (clip.isPresent()) return clip.get();
        return inflated.contains(start) ? start : null;
    }

    public static AABB createBeamSearchBox(Vec3 s, Vec3 e, double inflation) {
        return new AABB(
                Math.min(s.x, e.x) - inflation, Math.min(s.y, e.y) - inflation, Math.min(s.z, e.z) - inflation,
                Math.max(s.x, e.x) + inflation, Math.max(s.y, e.y) + inflation, Math.max(s.z, e.z) + inflation);
    }

    public record TraceResult(Vec3 hitPos, double distance, LivingEntity entity) {}
}