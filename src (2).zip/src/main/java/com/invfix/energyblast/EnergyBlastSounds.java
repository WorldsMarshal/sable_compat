package com.invfix.energyblast;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Звуки Energy Blast — файлы The Shooting Star как есть
 * (assets/sable_compat/sounds/energy_blast/):
 *  charge ← stars_hum   (ровный гул, 6 с — шар растёт в руке до 5 с);
 *  fire   ← star_fire   (выстрел);
 *  blast  ← stars_land  (взрыв; маленький — выше и тише, полный заряд — ниже и громче).
 */
public final class EnergyBlastSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, "sable_compat");

    public static final DeferredHolder<SoundEvent, SoundEvent> CHARGE = register("energy_blast_charge");
    public static final DeferredHolder<SoundEvent, SoundEvent> FIRE = register("energy_blast_fire");
    public static final DeferredHolder<SoundEvent, SoundEvent> BLAST = register("energy_blast_blast");

    private static DeferredHolder<SoundEvent, SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath("sable_compat", name)));
    }

    private EnergyBlastSounds() {}
}
