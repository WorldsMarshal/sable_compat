package com.invfix.energyblast;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.kineticstrike.BmnwExplosionHandler;
import net.mcreator.invincibleinc.init.InvincibleIncModGameRules;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Energy Blast (в оригинале Ki Blast) — способность Metroman (Alien(Metroman)), LVL 200.
 *
 * Держишь клавишу — в вытянутой руке (поза как у Grab &amp; Throw) растёт шар
 * энергии, до {@link #MAX_CHARGE_TICKS} (5 с). Отпускаешь — шар летит по прицелу
 * очень быстро ({@link #SPEED} блоков за тик) и взрывается в первом блоке или
 * сущности на пути (или в конце {@link #RANGE} блоков).
 *
 * Сила — от заряда k = 0..1 (быстрое нажатие — 0):
 *  - урон всем в радиусе взрыва, один раз: от 0.35 до 1.0 Attackpwr;
 *  - радиус взрыва и кратера: от {@link #MIN_RADIUS} до {@link #MAX_RADIUS} блоков.
 *
 * Кратер — тем же лучевым алгоритмом BMNW, что у Kinetic Strike
 * (BmnwExplosionHandler), только меньше и кучнее: сила лучей ×3 к радиусу (у
 * Kinetic Strike ×2), так что почти каждый луч доходит до края и кратер
 * выходит плотным и круглым. Бедрок лучи не пробивают. Снос — по геймрулу
 * invincibleBlockDestruction, как у остальных разрушений.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class EnergyBlastHandler {

    public static final String ABILITY = "§b§lEnergy Blast";
    public static final int LVL_REQUIRED = 200;

    public static final int MAX_CHARGE_TICKS = 100;
    public static final float SPEED = 12.0F;
    public static final double RANGE = 320.0;
    public static final double MIN_RADIUS = 7.0;
    public static final double MAX_RADIUS = 35.0;
    private static final double MIN_DAMAGE = 0.35, MAX_DAMAGE = 1.0;
    /** Сила лучей BMNW на блок радиуса (у Kinetic Strike 2): больше — кучнее кратер. */
    private static final float RAY_STRENGTH = 3.0F;
    private static final int RAY_SPEED = 500;
    private static final int DESTRUCT_MS = 6;
    /** Радиус шара в полёте при полном заряде, блоков (сервер — для попадания по сущностям). */
    private static final double BALL_RADIUS = 0.6;
    private static final double SEND_RANGE = 640.0;

    private static final ResourceKey<DamageType> DAMAGE = ResourceKey.create(Registries.DAMAGE_TYPE,
            ResourceLocation.parse("sable_compat:energy_blast"));

    /** Кто заряжает: игрок → gameTime начала. */
    private static final Map<UUID, Long> CHARGING = new ConcurrentHashMap<>();
    private static final List<Shot> SHOTS = new ArrayList<>();
    private static final List<BmnwExplosionHandler> CRATERS = new ArrayList<>();
    private static int nextShotId = 1;

    private static final class Shot {
        final int id;
        final ServerLevel level;
        final UUID caster;
        final Vec3 dir;
        final float charge;
        Vec3 pos;
        double travelled;

        Shot(int id, ServerLevel level, UUID caster, Vec3 pos, Vec3 dir, float charge) {
            this.id = id;
            this.level = level;
            this.caster = caster;
            this.pos = pos;
            this.dir = dir;
            this.charge = charge;
        }
    }

    private EnergyBlastHandler() {}

    public static boolean isEligible(String race) {
        return AltrumiteRace.isAltrumite(race);
    }

    public static double radius(double charge) {
        return Mth.lerp(charge, MIN_RADIUS, MAX_RADIUS);
    }

    // ── клавиша: из AbilityCallProcedureMixin каждый тик, и зажата, и нет ───

    public static void handleKeyState(ServerPlayer player, boolean held) {
        UUID id = player.getUUID();
        Long started = CHARGING.get(id);
        if (held) {
            if (started != null) return;
            try {
                InvincibleIncModVariables.PlayerVariables v = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                if (!isEligible(v.Race) || v.Lvl < LVL_REQUIRED) return;
            } catch (Exception e) {
                return;
            }
            CHARGING.put(id, player.level().getGameTime());
            PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new EnergyBlastPackets.Charge(player.getId(), true));
        } else if (started != null) {
            CHARGING.remove(id);
            long ticks = player.level().getGameTime() - started;
            fire(player, (float) Mth.clamp(ticks / (double) MAX_CHARGE_TICKS, 0.0, 1.0));
        }
    }

    /** Откуда вылетает шар: перед правой рукой, вытянутой вперёд. */
    public static Vec3 handPosition(Entity e, Vec3 look) {
        double yaw = Math.toRadians(e.getYRot());
        Vec3 right = new Vec3(-Math.cos(yaw), 0.0, -Math.sin(yaw));
        Vec3 shoulder = e.position().add(0.0, e.getBbHeight() * 0.764, 0.0).add(right.scale(0.3125));
        return shoulder.add(look.scale(0.95));
    }

    private static void fire(ServerPlayer player, float charge) {
        ServerLevel level = (ServerLevel) player.level();
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new EnergyBlastPackets.Charge(player.getId(), false));
        if (!player.isAlive()) return;
        Vec3 look = player.getLookAngle();
        if (look.lengthSqr() < 1.0E-6) return;
        // летит из руки туда, куда смотрит прицел
        Vec3 eye = player.getEyePosition();
        Vec3 aim = eye.add(look.scale(RANGE));
        BlockHitResult bh = level.clip(new ClipContext(eye, aim, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        if (bh.getType() != HitResult.Type.MISS) aim = bh.getLocation();
        Vec3 from = handPosition(player, look.normalize());
        Vec3 dir = aim.subtract(from);
        dir = dir.lengthSqr() < 1.0E-6 ? look.normalize() : dir.normalize();

        Shot shot = new Shot(nextShotId++, level, player.getUUID(), from, dir, charge);
        SHOTS.add(shot);
        level.playSound(null, from.x, from.y, from.z, EnergyBlastSounds.FIRE.get(), SoundSource.PLAYERS,
                2.0F + 2.0F * charge, 1.1F - 0.2F * charge);
        PacketDistributor.sendToPlayersNear(level, null, from.x, from.y, from.z, SEND_RANGE,
                new EnergyBlastPackets.Shot(shot.id, player.getId(), from.x, from.y, from.z,
                        (float) dir.x, (float) dir.y, (float) dir.z, charge, SPEED));
    }

    // ── полёт и взрывы ─────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        Iterator<Shot> it = SHOTS.iterator();
        while (it.hasNext()) {
            Shot shot = it.next();
            if (shot.level != level) continue;
            try {
                if (fly(shot)) it.remove();
            } catch (Exception e) {
                it.remove();
            }
        }
        Iterator<BmnwExplosionHandler> ci = CRATERS.iterator();
        while (ci.hasNext()) {
            BmnwExplosionHandler h = ci.next();
            if (h.level != level) continue;
            try {
                h.cacheChunksTick();
                h.destructionTick(DESTRUCT_MS);
            } catch (Exception ignored) {}
            if (h.isComplete()) ci.remove();
        }
    }

    /** Один тик полёта; true — шар взорвался. */
    private static boolean fly(Shot shot) {
        ServerLevel level = shot.level;
        Vec3 from = shot.pos;
        Vec3 to = from.add(shot.dir.scale(SPEED));
        ServerPlayer caster = level.getServer().getPlayerList().getPlayer(shot.caster);
        if (!level.isLoaded(BlockPos.containing(to))) {
            detonate(shot, from, caster);
            return true;
        }
        BlockHitResult bh = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE,
                caster));
        Vec3 end = bh.getType() != HitResult.Type.MISS ? bh.getLocation() : to;
        double best = from.distanceTo(end);
        Vec3 hit = bh.getType() != HitResult.Type.MISS ? end : null;
        double inflate = BALL_RADIUS * (0.4 + 0.6 * shot.charge);
        for (Entity e : level.getEntities(caster, new AABB(from, end).inflate(inflate + 1.0),
                en -> en instanceof LivingEntity le && le.isAlive())) {
            var clip = e.getBoundingBox().inflate(inflate).clip(from, end);
            if (clip.isPresent() && from.distanceTo(clip.get()) < best) {
                best = from.distanceTo(clip.get());
                hit = clip.get();
            }
        }
        if (hit != null) {
            detonate(shot, hit, caster);
            return true;
        }
        shot.pos = to;
        shot.travelled += SPEED;
        if (shot.travelled >= RANGE) {
            detonate(shot, to, caster);
            return true;
        }
        return false;
    }

    private static void detonate(Shot shot, Vec3 at, ServerPlayer caster) {
        ServerLevel level = shot.level;
        // The Whole Sentry Power: разрушения ×1.5 — радиус взрыва и кратера
        float scale = caster != null ? (float) com.invfix.sentry.SentryHandler.destruction(caster) : 1.0F;
        double r = radius(shot.charge) * scale;

        // урон — всем в радиусе, один раз
        if (caster != null) {
            double ap = 0.0;
            try {
                ap = caster.getData(InvincibleIncModVariables.PLAYER_VARIABLES).attackPower;
            } catch (Exception ignored) {}
            float damage = (float) (ap * Mth.lerp(shot.charge, MIN_DAMAGE, MAX_DAMAGE));
            DamageSource source = new DamageSource(level.holderOrThrow(DAMAGE), caster);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(r + 2.0),
                    t -> t != caster && t.isAlive())) {
                double d = e.getBoundingBox().getCenter().distanceTo(at) - e.getBbWidth() * 0.5;
                if (d > r) continue;
                if (damage > 0.0F) {
                    e.invulnerableTime = 0;
                    e.hurtTime = 0;
                    e.hurt(source, damage);
                }
                // отброс от центра, слабее к краю
                Vec3 push = e.position().subtract(at);
                if (push.lengthSqr() < 1.0E-4) push = new Vec3(0.0, 1.0, 0.0);
                double knock = (1.0 - Math.min(1.0, Math.max(d, 0.0) / r)) * (1.0 + 2.0 * shot.charge);
                e.setDeltaMovement(e.getDeltaMovement().add(push.normalize().scale(knock).add(0.0, 0.4 * knock, 0.0)));
                e.hurtMarked = true;
            }
        }

        // кратер
        if (level.getGameRules().getBoolean(InvincibleIncModGameRules.INVINCIBLE_BLOCK_DESTRUCTION)) {
            int length = (int) Math.round(r);
            CRATERS.add(new BmnwExplosionHandler(level, Mth.floor(at.x), Mth.floor(at.y), Mth.floor(at.z),
                    length * RAY_STRENGTH, RAY_SPEED, length));
        }

        level.playSound(null, at.x, at.y, at.z, EnergyBlastSounds.BLAST.get(), SoundSource.PLAYERS,
                4.0F + 12.0F * shot.charge, 1.15F - 0.3F * shot.charge);
        PacketDistributor.sendToPlayersNear(level, null, at.x, at.y, at.z, SEND_RANGE,
                new EnergyBlastPackets.Blast(shot.id, at.x, at.y, at.z, shot.charge, scale));
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        CHARGING.remove(event.getEntity().getUUID());
    }
}
