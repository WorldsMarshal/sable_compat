package com.invfix.energyblast;

import com.invfix.energyblast.client.EnergyBlastClient;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Пакеты Energy Blast. */
public final class EnergyBlastPackets {

    private EnergyBlastPackets() {}

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath("sable_compat", path);
    }

    /** Сервер → клиенты: игрок начал (charging = true) или закончил заряжать шар. */
    public record Charge(int playerId, boolean charging) implements CustomPacketPayload {
        public static final Type<Charge> TYPE = new Type<>(id("energy_blast_charge"));
        public static final StreamCodec<FriendlyByteBuf, Charge> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> { buf.writeVarInt(m.playerId()); buf.writeBoolean(m.charging()); },
                buf -> new Charge(buf.readVarInt(), buf.readBoolean()));
        @Override public Type<Charge> type() { return TYPE; }

        @OnlyIn(Dist.CLIENT)
        public static void handleClient(Charge p, IPayloadContext ctx) {
            ctx.enqueueWork(() -> EnergyBlastClient.setCharging(p.playerId, p.charging));
        }
    }

    /** Сервер → клиенты: шар выпущен. Откуда, куда, заряд 0..1, скорость (блоков/тик). */
    public record Shot(int shotId, int playerId, double x, double y, double z, float dx, float dy, float dz,
                       float charge, float speed) implements CustomPacketPayload {
        public static final Type<Shot> TYPE = new Type<>(id("energy_blast_shot"));
        public static final StreamCodec<FriendlyByteBuf, Shot> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> {
                    buf.writeVarInt(m.shotId()); buf.writeVarInt(m.playerId());
                    buf.writeDouble(m.x()); buf.writeDouble(m.y()); buf.writeDouble(m.z());
                    buf.writeFloat(m.dx()); buf.writeFloat(m.dy()); buf.writeFloat(m.dz());
                    buf.writeFloat(m.charge()); buf.writeFloat(m.speed());
                },
                buf -> new Shot(buf.readVarInt(), buf.readVarInt(), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                        buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat()));
        @Override public Type<Shot> type() { return TYPE; }

        @OnlyIn(Dist.CLIENT)
        public static void handleClient(Shot p, IPayloadContext ctx) {
            ctx.enqueueWork(() -> EnergyBlastClient.shot(p.shotId, p.playerId, p.x, p.y, p.z, p.dx, p.dy, p.dz,
                    p.charge, p.speed));
        }
    }

    /** Сервер → клиенты: шар взорвался. Где и с каким зарядом. */
    public record Blast(int shotId, double x, double y, double z, float charge, float scale) implements CustomPacketPayload {
        public static final Type<Blast> TYPE = new Type<>(id("energy_blast_blast"));
        public static final StreamCodec<FriendlyByteBuf, Blast> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> {
                    buf.writeVarInt(m.shotId());
                    buf.writeDouble(m.x()); buf.writeDouble(m.y()); buf.writeDouble(m.z());
                    buf.writeFloat(m.charge());
                    buf.writeFloat(m.scale());
                },
                buf -> new Blast(buf.readVarInt(), buf.readDouble(), buf.readDouble(), buf.readDouble(), buf.readFloat(),
                        buf.readFloat()));
        @Override public Type<Blast> type() { return TYPE; }

        @OnlyIn(Dist.CLIENT)
        public static void handleClient(Blast p, IPayloadContext ctx) {
            ctx.enqueueWork(() -> EnergyBlastClient.blast(p.shotId, p.x, p.y, p.z, p.charge, p.scale));
        }
    }

    /** Клиент → Сервер: выбрать Energy Blast как текущую способность (для назначения в слот). */
    public record Assign(int x, int y, int z) implements CustomPacketPayload {
        public static final Type<Assign> TYPE = new Type<>(id("energy_blast_assign"));
        public static final StreamCodec<FriendlyByteBuf, Assign> STREAM_CODEC = StreamCodec.of(
                (buf, m) -> { buf.writeInt(m.x()); buf.writeInt(m.y()); buf.writeInt(m.z()); },
                buf -> new Assign(buf.readInt(), buf.readInt(), buf.readInt()));
        @Override public Type<Assign> type() { return TYPE; }

        public static void handleServer(Assign pkt, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                if (!(ctx.player() instanceof ServerPlayer player)) return;
                try {
                    InvincibleIncModVariables.PlayerVariables vars =
                            player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                    if (!EnergyBlastHandler.isEligible(vars.Race)) return;
                    if (vars.Lvl < EnergyBlastHandler.LVL_REQUIRED) return;
                    vars.AbilitySet = EnergyBlastHandler.ABILITY;
                    vars.abilityDescription = EnergyBlastHandler.ABILITY + " | LVL:" + EnergyBlastHandler.LVL_REQUIRED
                            + " | Энергошар (держать — заряд)";
                    vars.markSyncDirty();
                } catch (Exception ignored) {}
            });
        }
    }
}
