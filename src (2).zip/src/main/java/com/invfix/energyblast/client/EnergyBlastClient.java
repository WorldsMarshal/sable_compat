package com.invfix.energyblast.client;

import com.invfix.energyblast.EnergyBlastHandler;
import com.invfix.energyblast.EnergyBlastSounds;
import com.invfix.fx.FxManager;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import org.joml.Vector3f;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Клиент Energy Blast: кто заряжает шар (рука вперёд, как у Grab &amp; Throw —
 * GrabArmMixin; гул заряда), летящие шары (летят здесь сами, той же скоростью,
 * что на сервере, до пакета о взрыве) и взрывы (EnergyBlastFx). Шары рисует
 * EnergyBallFx.
 */
@OnlyIn(Dist.CLIENT)
public final class EnergyBlastClient {

    /** Сколько тиков рука ещё вытянута после броска. */
    private static final int ARM_AFTER = 6;

    /** Кто заряжает: id игрока → тик клиента начала. */
    static final Map<Integer, Long> CHARGING = new ConcurrentHashMap<>();
    private static final Map<Integer, Integer> ARM = new ConcurrentHashMap<>();
    private static final Map<Integer, ChargeSound> SOUNDS = new ConcurrentHashMap<>();
    static final Map<Integer, Flight> SHOTS = new ConcurrentHashMap<>();
    private static long clientTicks;

    static final class Flight {
        final int casterId;
        final Vec3 dir;
        final float charge;
        final float speed;
        Vec3 pos;
        Vec3 prev;
        double travelled;

        Flight(int casterId, Vec3 pos, Vec3 dir, float charge, float speed) {
            this.casterId = casterId;
            this.pos = pos;
            this.prev = pos;
            this.dir = dir;
            this.charge = charge;
            this.speed = speed;
        }
    }

    private EnergyBlastClient() {}

    public static void setCharging(int playerId, boolean charging) {
        Minecraft mc = Minecraft.getInstance();
        if (charging) {
            CHARGING.put(playerId, clientTicks);
            ChargeSound old = SOUNDS.remove(playerId);
            if (old != null) old.end();
            if (mc.level != null && mc.level.getEntity(playerId) instanceof LivingEntity le) {
                ChargeSound s = new ChargeSound(le);
                SOUNDS.put(playerId, s);
                mc.getSoundManager().play(s);
            }
            if (mc.level != null) EnergyBallFx.keepAlive(mc.level);
        } else {
            CHARGING.remove(playerId);
            ARM.put(playerId, ARM_AFTER);
            ChargeSound s = SOUNDS.remove(playerId);
            if (s != null) s.end();
        }
    }

    public static void shot(int shotId, int playerId, double x, double y, double z, float dx, float dy, float dz,
                            float charge, float speed) {
        Minecraft mc = Minecraft.getInstance();
        CHARGING.remove(playerId);
        ARM.put(playerId, ARM_AFTER);
        Vec3 dir = new Vec3(dx, dy, dz).normalize();
        SHOTS.put(shotId, new Flight(playerId, new Vec3(x, y, z), dir, charge, speed));
        if (mc.level != null) EnergyBallFx.keepAlive(mc.level);
    }

    public static void blast(int shotId, double x, double y, double z, float charge, float scale) {
        Flight f = SHOTS.remove(shotId);
        EnergyBlastFx.start(x, y, z, charge, scale);
        // The Whole Sentry Power: белые разряды в точке взрыва
        if (f != null) {
            com.invfix.sentry.client.SentryClient.arcsIfSentry(f.casterId, new Vec3(x, y, z),
                    (float) (EnergyBlastHandler.radius(charge) * scale * 0.8));
        }
    }

    /** Рука вытянута вперёд (заряд или только что бросил) — для GrabArmMixin. */
    public static boolean armForward(int playerId) {
        return CHARGING.containsKey(playerId) || ARM.containsKey(playerId);
    }

    /** Заряд 0..1 у заряжающего. */
    static float charge(int playerId, float partial) {
        Long start = CHARGING.get(playerId);
        if (start == null) return 0.0F;
        return Math.min(1.0F, (clientTicks - start + partial) / EnergyBlastHandler.MAX_CHARGE_TICKS);
    }

    /** Радиус шара по заряду, блоков. */
    static float ballRadius(float charge) {
        return 0.12F + 0.45F * charge;
    }

    /**
     * Где шар в руке: перед правой рукой, вытянутой по взгляду; своя камера от
     * первого лица — внизу справа кадра, где рука.
     */
    static Vec3 ballInHand(LivingEntity e, float partial, float radius, boolean ownFirstPerson) {
        if (ownFirstPerson) {
            Camera cam = Minecraft.getInstance().gameRenderer.getMainCamera();
            Vector3f f = cam.getLookVector(), up = cam.getUpVector(), left = cam.getLeftVector();
            Vec3 c = cam.getPosition();
            double fwd = 1.1 + radius;
            return c.add(f.x() * fwd, f.y() * fwd, f.z() * fwd)
                    .add(-left.x() * 0.34, -left.y() * 0.34, -left.z() * 0.34)
                    .add(up.x() * -0.3, up.y() * -0.3, up.z() * -0.3);
        }
        Vec3 look = e.getViewVector(partial);
        double yaw = Math.toRadians(e.getViewYRot(partial));
        Vec3 right = new Vec3(-Math.cos(yaw), 0.0, -Math.sin(yaw));
        Vec3 shoulder = e.getPosition(partial).add(0.0, e.getBbHeight() * 0.764, 0.0).add(right.scale(0.3125));
        return shoulder.add(look.scale(0.72 + radius));
    }

    private static void reset() {
        CHARGING.clear();
        ARM.clear();
        SHOTS.clear();
        SOUNDS.values().forEach(ChargeSound::end);
        SOUNDS.clear();
    }

    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
    public static final class GameBus {

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            ClientLevel level = mc.level;
            if (level == null) {
                reset();
                return;
            }
            if (mc.isPaused()) return;
            clientTicks++;
            ARM.replaceAll((id, t) -> t - 1);
            ARM.values().removeIf(t -> t <= 0);
            CHARGING.keySet().removeIf(id -> !(level.getEntity(id) instanceof LivingEntity le) || !le.isAlive());
            Iterator<Map.Entry<Integer, Flight>> it = SHOTS.entrySet().iterator();
            while (it.hasNext()) {
                Flight f = it.next().getValue();
                f.prev = f.pos;
                f.pos = f.pos.add(f.dir.scale(f.speed));
                f.travelled += f.speed;
                // пакет о взрыве мог потеряться/не дойти — дальше дальности шар не летит
                if (f.travelled > EnergyBlastHandler.RANGE + f.speed * 3) it.remove();
            }
            if (!CHARGING.isEmpty() || !SHOTS.isEmpty()) EnergyBallFx.keepAlive(level);
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            reset();
        }
    }

    /** Гул заряда: идёт за заряжающим, стихает за 4 тика, когда заряд кончился. */
    private static final class ChargeSound extends AbstractTickableSoundInstance {
        private final Entity entity;
        private int fading = -1;

        ChargeSound(Entity entity) {
            super(EnergyBlastSounds.CHARGE.get(), SoundSource.PLAYERS, SoundInstance.createUnseededRandom());
            this.entity = entity;
            this.volume = 1.5F;
            this.pitch = 1.0F;
            this.looping = false;
            this.x = entity.getX();
            this.y = entity.getY() + 1.2;
            this.z = entity.getZ();
        }

        void end() {
            if (fading < 0) fading = 4;
        }

        @Override
        public void tick() {
            if (entity.isRemoved()) {
                stop();
                return;
            }
            this.x = entity.getX();
            this.y = entity.getY() + 1.2;
            this.z = entity.getZ();
            if (fading >= 0) {
                if (fading == 0) {
                    stop();
                    return;
                }
                this.volume = 1.5F * fading / 4.0F;
                fading--;
            }
        }
    }

    static void keepFx(ClientLevel level) {
        EnergyBallFx.keepAlive(level);
    }

    static Vec3 camera() {
        return FxManager.camera();
    }
}
