package com.invfix.energyblast.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.List;
import java.util.Map;

/**
 * Шары Energy Blast (energy_ball.fsh): в руке, пока заряжаются (растут с
 * зарядом), и в полёте — со шлейфом света. Один эффект на клиент, живёт, пока
 * есть кого рисовать.
 */
@OnlyIn(Dist.CLIENT)
public final class EnergyBallFx extends FxEffect {

    private static final int LINGER = 4;
    private static EnergyBallFx instance;

    private final ClientLevel level;
    private int idle;

    private EnergyBallFx(ClientLevel level) {
        this.level = level;
    }

    static void keepAlive(ClientLevel level) {
        if (instance == null || instance.finished() || instance.level != level) {
            instance = new EnergyBallFx(level);
            FxManager.add(instance);
        }
        instance.idle = 0;
    }

    @Override
    protected void onTick(Minecraft minecraft, ClientLevel level, int age) {
        idle++;
    }

    @Override
    protected int duration() {
        return Integer.MAX_VALUE;
    }

    @Override
    public boolean finished() {
        return idle > LINGER || Minecraft.getInstance().level != level;
    }

    @Override
    protected void onRemoved() {
        if (instance == this) instance = null;
    }

    @Override
    public Vec3 focus() {
        return FxManager.camera();
    }

    @Override
    public double range() {
        return Double.MAX_VALUE;
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        Minecraft mc = frame.minecraft();
        if (mc.level == null) return;
        float partial = frame.partial();
        float time = (age + partial) / 20.0F;

        // в руке
        for (Integer id : EnergyBlastClient.CHARGING.keySet()) {
            if (!(mc.level.getEntity(id) instanceof LivingEntity e)) continue;
            float k = EnergyBlastClient.charge(id, partial);
            boolean ownFp = e == mc.player && mc.options.getCameraType().isFirstPerson();
            float r = EnergyBlastClient.ballRadius(k) * (ownFp ? 0.45F : 1.0F);
            Vec3 c = EnergyBlastClient.ballInHand(e, partial, r, ownFp);
            add(out, frame, c, e.getViewVector(partial), r, time, id * 0.618F % 1.0F, 0.0F, k, ownFp, 0.6F + 0.4F * k);
        }
        // в полёте
        for (Map.Entry<Integer, EnergyBlastClient.Flight> entry : EnergyBlastClient.SHOTS.entrySet()) {
            EnergyBlastClient.Flight f = entry.getValue();
            Vec3 c = f.prev.lerp(f.pos, partial);
            float r = EnergyBlastClient.ballRadius(f.charge);
            float trail = (float) Math.min(f.travelled + f.speed * partial, 4.0 + 18.0 * f.charge);
            add(out, frame, c, f.dir, r, time, entry.getKey() * 0.618F % 1.0F, trail, f.charge, false, 1.0F);
        }
    }

    private static void add(List<FxPass> out, FxFrame frame, Vec3 world, Vec3 dir, float r, float time, float seed,
                            float trail, float charge, boolean own, float light) {
        if (world.distanceTo(frame.camera()) > 512.0) return;
        Vec3 c = frame.rel(world);
        Vec3 cam = frame.camera();
        float ox = (float) (cam.x - 2048.0 * Math.floor(cam.x / 2048.0));
        float oy = (float) (cam.y - 2048.0 * Math.floor(cam.y / 2048.0));
        float oz = (float) (cam.z - 2048.0 * Math.floor(cam.z / 2048.0));
        float ownF = own ? 1.0F : 0.0F;
        out.add(new FxPass("energy_ball", u -> {
            u.v3("Target", c);
            u.v3("Facing", dir);
            u.f3("Origin", ox, oy, oz);
            u.f4("P0", r, time, seed, trail);
            u.f4("P1", charge, ownF, light, 0.0F);
        }));
    }

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        Minecraft mc = frame.minecraft();
        if (mc.player == null) return;
        // свой шар в руке: свечение и лёгкая дрожь кадра к полному заряду
        float k = EnergyBlastClient.charge(mc.player.getId(), frame.partial());
        if (EnergyBlastClient.CHARGING.containsKey(mc.player.getId())) {
            screen.bloom = Math.max(screen.bloom, 0.4F + 0.5F * k);
            screen.bloomRadius = Math.max(screen.bloomRadius, 1.1F);
            screen.shake = Math.max(screen.shake, k * k * 0.12F);
        }
    }
}
