package com.invfix.energyblast.client;

import com.invfix.energyblast.EnergyBlastHandler;
import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.List;

/**
 * Взрыв Energy Blast — тот же взрыв, что у Kinetic Strike (nuke.fsh, NukeFx), в
 * палитре чистой энергии (бело-голубой, остывает в глубокий синий, без копоти),
 * меньше и короче; всё — от заряда k:
 *  - шар: до ~0.55 радиуса кратера (k = 1: ~19 блоков, k = 0: ~4);
 *  - весь таймлайн сжат: k = 1 — ~4 с, k = 0 — ~1.8 с (у Kinetic Strike 10 с);
 *  - белые импакт-кадры (как у Kinetic Strike): от 2 кадров (k = 0) до 6 (k = 1);
 *  - вспышка, послеобраз, тряска, ударный фронт по земле — слабее при малом заряде.
 */
@OnlyIn(Dist.CLIENT)
public final class EnergyBlastFx extends FxEffect {

    /** Константы таймлайна NukeFx — сюда в «секундах NukeFx», реальное время = их × timeScale. */
    private static final float BASE_SIZE = 45.0F;
    private static final float SHOCK_SPEED = 220.0F;
    private static final float SHOCK_SECONDS = 3.0F;

    private final ClientLevel level;
    private final Vec3 center;
    private final float charge;
    private final float size;
    private final float timeScale;
    private final float seed;
    private final int frames;
    private boolean shockReachedCamera;

    private EnergyBlastFx(ClientLevel level, Vec3 center, float charge, float scale) {
        this.level = level;
        this.center = center;
        this.charge = charge;
        double r = EnergyBlastHandler.radius(charge) * scale;
        this.size = (float) (r * 0.55 / 1.6);
        this.timeScale = 0.18F + 0.27F * charge;
        this.frames = 2 + Math.round(4.0F * charge);
        this.seed = (float) ((Mth.getSeed((int) center.x, (int) center.y, (int) center.z) & 0xFFFFL) / 65535.0);
    }

    public static void start(double x, double y, double z, float charge, float scale) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        FxManager.add(new EnergyBlastFx(level, new Vec3(x, y, z), charge, scale));
    }

    @Override
    protected int duration() {
        return (int) Math.ceil(9.0F * timeScale * 20.0F) + 2;
    }

    @Override
    public boolean finished() {
        return super.finished() || Minecraft.getInstance().level != level;
    }

    @Override
    public Vec3 focus() {
        return center;
    }

    @Override
    public double range() {
        return 900.0;
    }

    // ── таймлайн NukeFx в сжатом времени ──────────────────────────────────

    private float maxRadius() {
        return size * 1.6F;
    }

    private float radius(float s) {
        return maxRadius() * (1.0F - (float) Math.exp(-s / 0.12F));
    }

    private static float heat(float s) {
        if (s < 1.5F) return 1.45F;
        return 1.45F * (float) Math.exp(-(s - 1.5F) / 3.0F);
    }

    private float scale() {
        return size / BASE_SIZE;
    }

    private Vec3 ball(float s) {
        return center.add(0.0, size * 0.12F * Math.min(s, 8.0F), 0.0);
    }

    private float shockFront(float s) {
        return s * SHOCK_SPEED * scale();
    }

    /** «Секунды NukeFx» из реального времени. */
    private float nuke(float realSeconds) {
        return realSeconds / timeScale;
    }

    @Override
    protected void onTick(Minecraft minecraft, ClientLevel level, int age) {
        float s = nuke(age / 20.0F);
        if (!shockReachedCamera && s <= SHOCK_SECONDS) {
            double d = FxManager.camera().distanceTo(center);
            if (shockFront(s) >= d) {
                shockReachedCamera = true;
                FxManager.shake(center, 0.3F + 0.45F * charge, 600.0);
            }
        }
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        float real = ticks(frame) / 20.0F;
        float s = nuke(real);
        float opacity = 1.0F - smooth((s - 6.0F) / 3.0F);
        if (opacity <= 0.001F) return;
        float impactEnd = frames * 0.05F;
        float r = radius(s);
        float heat = heat(s);
        float impactPhase = window(real, 0.0F, 0.01F, impactEnd - 0.03F, impactEnd + 0.03F);
        float dim = impactPhase * 0.85F;
        float light = Math.max(window(s, 0.0F, 0.01F, 0.5F, 2.8F), 0.25F * smooth(heat / 1.45F)) * opacity;
        float air = (0.35F + 0.65F * window(s, 0.0F, 0.02F, 0.6F, 4.0F)) * opacity;
        float shock = s < SHOCK_SECONDS ? (1.0F - s / SHOCK_SECONDS) : 0.0F;
        float shell = window(s, 0.05F, 0.15F, 0.8F, 2.2F);
        Vec3 c = frame.rel(ball(s));
        float groundY = (float) (center.y - frame.camera().y);
        float front = shockFront(s);
        float seedF = seed;
        out.add(new FxPass("nuke", u -> {
            u.v3("Target", c);
            u.f4("P0", r, s, seedF, heat);
            u.f4("P1", opacity, light, front, shock);
            u.f4("P2", air, groundY, Math.max(front * 0.6F, r * 1.05F), shell);
            u.f4("P3", dim, impactPhase, 1.0F, 0.0F);
        }));
    }

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        float real = ticks(frame) / 20.0F;
        float s = nuke(real);
        double dist = frame.camera().distanceTo(center);
        float near = (float) Mth.clamp(1.0 - dist / (1500.0 * scale() + 60.0), 0.2, 1.0);
        float impactEnd = frames * 0.05F;

        // белые импакт-кадры, как у Kinetic Strike: 36 — мир чёрными контурами на белом, 37 — наоборот
        if (dist < 220.0 + 300.0 * charge) {
            int[] pattern = {36, 36, 37, 36, 37, 37};
            int[] modes = new int[frames];
            for (int i = 0; i < frames; i++) modes[i] = pattern[(6 - frames + i) % 6];
            impactSequence(screen, real, ball(s), 1.0F, 0.05F, modes);
        }
        if (real >= impactEnd) {
            float flash = (0.8F + 0.6F * charge) * (float) Math.exp(-(real - impactEnd) / (0.12F + 0.1F * charge));
            screen.addFlash(0xE8F2FF, flash * near);
        }
        if (charge > 0.5F) {
            if (real >= impactEnd && real < impactEnd + 0.1F) screen.capture = 1.0F;
            screen.afterimage = Math.max(screen.afterimage,
                    window(real, impactEnd, impactEnd + 0.02F, 0.3F, 1.2F + 0.8F * charge) * 0.45F * near);
        }
        float hold = window(s, 0.0F, 0.04F, 1.5F, 5.0F);
        screen.bloom = Math.max(screen.bloom, (0.7F + 0.4F * charge) * hold);
        screen.bloomRadius = Math.max(screen.bloomRadius, 1.0F + 1.2F * hold);
        screen.shake = Math.max(screen.shake, window(s, 0.0F, 0.05F, 1.5F, 4.0F) * (0.3F + 0.5F * charge) * near);
        screen.aberration = Math.max(screen.aberration, window(s, 0.0F, 0.05F, 0.8F, 3.0F) * (0.4F + 0.6F * charge) * near);
        screen.zoomBlur = Math.max(screen.zoomBlur, window(s, 0.0F, 0.03F, 0.35F, 1.4F) * (0.25F + 0.3F * charge) * near);
    }
}
