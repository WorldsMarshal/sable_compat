package com.invfix.thing;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Registration for the thingamajig computer.
 *
 * The block entity type has to exist before the block that builds it, and the
 * block has to exist before the type can name it - the usual circle. It is
 * broken the same way the rest of this mod does it: the block takes a supplier
 * of the type rather than the type itself, so neither is resolved until the
 * registry is frozen.
 */
public final class ThingRegistry {

    public static final String MODID = "sable_compat";
    public static final ResourceLocation BE_ID =
            ResourceLocation.fromNamespaceAndPath(MODID, "thing_computer");

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MODID);

    // The two fields need each other, and Java forbids naming a later field by
    // its simple name from an earlier initializer - the illegal forward
    // reference rule. A lambda body does not escape it: the rule is about the
    // textual position of the name, not about when the code runs. Qualifying
    // with the class name makes it a qualified name instead of a simple one,
    // which the rule does not cover, and changes nothing at runtime: both
    // lambdas are still only invoked while the registries are being filled,
    // long after the static initializer has assigned both fields.
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ThingComputerBlockEntity>> THING_COMPUTER_BE =
            BLOCK_ENTITIES.register("thing_computer",
                    () -> BlockEntityType.Builder.of(ThingComputerBlockEntity::new,
                            ThingRegistry.THING_COMPUTER.get()).build(null));

    public static final DeferredBlock<ThingComputerBlock> THING_COMPUTER =
            BLOCKS.registerBlock("thing_computer",
                    p -> new ThingComputerBlock(p, ThingRegistry.THING_COMPUTER_BE, BE_ID),
                    // the same feel as a computer: breakable by hand-tool speed,
                    // not blast resistant enough to be cover
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.METAL)
                            .strength(2.0F)
                            .sound(SoundType.METAL));

    public static final DeferredItem<?> THING_COMPUTER_ITEM =
            ITEMS.registerSimpleBlockItem("thing_computer", THING_COMPUTER);

    private ThingRegistry() {}

    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
        modEventBus.addListener(ThingRegistry::onBuildCreativeTabs);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
            event.accept(THING_COMPUTER_ITEM);
        }
    }
}
