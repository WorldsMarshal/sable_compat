package com.invfix.thing;

import dan200.computercraft.shared.computer.blocks.ComputerBlock;
import dan200.computercraft.shared.platform.RegistryEntry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import java.util.function.Supplier;

/**
 * The block. Deliberately thin.
 *
 * ComputerBlock already carries the facing and screen-state properties, the
 * placement rule, the ticker wiring, redstone, the break and pick behaviour and
 * the interaction that opens the terminal. Subclassing it means all of that -
 * including the blinking animation, which is driven by the STATE property the
 * base class maintains - is inherited rather than reimplemented, and stays
 * correct when CC changes it.
 *
 * The only thing this class supplies is which block entity to build.
 */
public class ThingComputerBlock extends ComputerBlock {

    public ThingComputerBlock(BlockBehaviour.Properties settings,
                              Supplier<? extends BlockEntityType<?>> type,
                              ResourceLocation id) {
        super(settings, entry(type, id));
    }

    /**
     * CC addresses the block entity type through its own RegistryEntry rather
     * than a plain supplier, because the block codec needs the id as well as
     * the value. A DeferredHolder gives both, so this just adapts it.
     */
    private static RegistryEntry<BlockEntityType<?>> entry(
            Supplier<? extends BlockEntityType<?>> type, ResourceLocation id) {
        return new RegistryEntry<>() {
            @Override
            public ResourceLocation id() {
                return id;
            }

            @Override
            public BlockEntityType<?> get() {
                return type.get();
            }
        };
    }

    // NOTE ON THE CODEC.
    //
    // ComputerBlock's MapCodec rebuilds a plain ComputerBlock. That codec is
    // only used where blocks are serialised by value - it is not on the path
    // for placing, ticking or saving a block in the world, which all go
    // through the registry. Leaving it inherited is therefore harmless here,
    // and overriding it would mean duplicating BlockCodecs internals for no
    // behaviour change.
}
