package com.invfix.thing;

import com.invfix.simulated.IAnalogTransmissionControl;
import com.simibubi.create.infrastructure.config.AllConfigs;
import dan200.computercraft.api.lua.LuaException;
import dan200.computercraft.api.lua.LuaFunction;
import dan200.computercraft.shared.peripheral.modem.ModemState;
import dan200.computercraft.shared.peripheral.modem.wired.WiredModemLocalPeripheral;
import dan200.computercraft.shared.peripheral.modem.wired.WiredModemPeripheral;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;

/**
 * The bus, as the computer sees it.
 *
 * This is a wired modem in every respect that matters to a program - it carries
 * the peripheral_hub type, so peripheral.getNames, peripheral.wrap and
 * callRemote work exactly as they do on a cable network, and every peripheral
 * on the vehicle appears under the same kind of name a modem would give it.
 * What it does not have is a cable: the block entity keeps the node's peripheral
 * map in step with the sub-level directly.
 *
 * The local peripheral - the block a real modem sits against - is deliberately
 * empty. This modem is inside the computer's own case, so there is no adjacent
 * block for it to publish, and the computer's own faces are still handled by the
 * computer in the ordinary way.
 *
 * On top of the modem contract it answers questions about the vehicle as a
 * whole, which no arrangement of cables could: a wired network knows about
 * blocks, not about the body they add up to.
 */
/**
 * Про отсутствие mainThread у методов ниже.
 *
 * Помечать их им было бы правильнее по учебнику: они читают блок-сущности и
 * состояние саблевела, а это владения серверного потока. Но в этой сборке
 * задачи главного потока для компьютера на саблевеле не доносят результат:
 * замер показал четыре метода из четырёх с mainThread, возвращающих ноль
 * значений за один тик, и три из трёх без него, отвечающих нормально. Задача
 * при этом исполняется - время round trip как раз тиковое, - теряется именно
 * результат.
 *
 * Копать в связку Sable и очереди задач CC мы не стали: дешевле не зависеть от
 * неё. Методы читают то, что шина уже собрала в своём тике, а запись состоит из
 * одного присваивания в блок-сущность, так что цена отказа от очереди здесь
 * невелика.
 */
public class SubLevelBusPeripheral extends WiredModemPeripheral {

    private static final org.slf4j.Logger LOG = com.mojang.logging.LogUtils.getLogger();

    private final ThingComputerBlockEntity owner;

    public SubLevelBusPeripheral(ThingComputerBlockEntity owner, SubLevelBusElement element) {
        super(new ModemState(), element, new WiredModemLocalPeripheral(direction -> null), owner);
        this.owner = owner;
        element.setModem(this);
    }

    @Override
    public String getType() {
        return "sublevel_bus";
    }

    @Override
    public Vec3 getPosition() {
        return Vec3.atCenterOf(owner.getBlockPos());
    }

    // ---- what a cable could never tell you ----

    /**
     * The vehicle as a whole: mass, centre of mass, pose, motion.
     *
     * This is the part a wired network structurally cannot provide.
     */
    @LuaFunction
    public final Map<String, Object> getVehicle() {
        // Снимок, собранный в серверном тике. Никакого чтения физики отсюда:
        // периферия работает в потоке компьютера, а поза саблевела, трекер
        // массы и карты чанков принадлежат серверному. Лезть в них через поток
        // - гонка, которая один раз уже выбросила игрока за километр.
        return owner.vehicleSnapshot();
    }

    /** Every block entity on the vehicle, with its local position and id. */
    @LuaFunction
    public final List<Map<String, Object>> listBlocks() {
        // Из того же снимка, что и listAvailable. Живой обход чанков отсюда
        // недопустим по той же причине, что и чтение физики.
        List<Map<String, Object>> out = new ArrayList<>();
        BlockPos origin = owner.getBlockPos();
        for (ThingComputerBlockEntity.Device device : owner.devices()) {
            Map<String, Object> m = new HashMap<>();
            BlockPos p = device.pos();
            m.put("x", p.getX());
            m.put("y", p.getY());
            m.put("z", p.getZ());
            m.put("dx", p.getX() - origin.getX());
            m.put("dy", p.getY() - origin.getY());
            m.put("dz", p.getZ() - origin.getZ());
            m.put("type", device.type());
            out.add(m);
        }
        return out;
    }

    // ---- claiming ----

    /**
     * Everything the bus can see, claimed or not.
     *
     * Offsets are given relative to the computer, never as absolute
     * coordinates. Absolute is worthless here twice over: the world position of
     * anything on a vehicle is stale the moment it moves, and the plot position
     * is an eight-digit number nobody can hold in their head. The offset from
     * the computer is a small triple that stays true however the ship flies, so
     * "the thruster three blocks aft" remains findable.
     *
     * Even so, this is the weaker way to pick a device. Running a DriveByWire
     * cable to the one you meant is unambiguous, needs no claiming at all and
     * works the same on a ship as on a missile.
     */
    /**
     * Всё, что шина видит.
     *
     * Обёрнуто в перехват намеренно: причина падения уезжает в лог сервера
     * полным стеком, а Lua получает честную ошибку с текстом вместо пустоты.
     */
    @LuaFunction
    public final List<Map<String, Object>> listAvailable() throws LuaException {
        List<Map<String, Object>> out = new ArrayList<>();
        BlockPos origin = owner.getBlockPos();
        List<ThingComputerBlockEntity.Device> devices;
        try {
            devices = owner.devices();
        } catch (Throwable t) {
            LOG.error("[sable_compat] listAvailable failed", t);
            throw new LuaException("bus scan failed: " + t);
        }
        for (ThingComputerBlockEntity.Device device : devices) {
            Map<String, Object> m = new HashMap<>();
            m.put("name", device.name());
            m.put("type", device.type());
            m.put("dx", device.pos().getX() - origin.getX());
            m.put("dy", device.pos().getY() - origin.getY());
            m.put("dz", device.pos().getZ() - origin.getZ());
            m.put("distance", Math.sqrt(device.pos().distSqr(origin)));
            m.put("cable", device.cable());
            m.put("claimed", device.cable() || owner.isClaimed(device.name()));
            out.add(m);
        }
        return out;
    }

    /**
     * Take a device under computer control.
     *
     * Nothing is under computer control until this is called. That is deliberate:
     * a mount or a thruster stops answering its crew the moment a computer
     * attaches to it, so switching a computer on must not quietly seize a whole
     * battleship. Claims survive a save.
     */
    @LuaFunction
    public final boolean claim(String name) {
        return owner.claim(name);
    }

    /** Hand a device back. Whoever was operating it by hand gets it back at once. */
    @LuaFunction
    public final boolean release(String name) {
        return owner.release(name);
    }

    /**
     * Take the first free device of a type and say which one it was.
     *
     * The short form for a missile with one thruster, where naming it would be
     * ceremony.
     */
    @LuaFunction
    public final Object claimFirst(String type) {
        String name = owner.claimFirst(type);
        return name == null ? false : name;
    }

    /** Take every device of a type. Returns how many were newly taken. */
    @LuaFunction
    public final int claimType(String type) {
        return owner.claimType(type);
    }

    /** Take whatever sits at this offset from the computer, and name it. */
    @LuaFunction
    public final Object claimAt(int dx, int dy, int dz) {
        String name = owner.claimAt(new BlockPos(dx, dy, dz));
        return name == null ? false : name;
    }

    /** Take everything on the vehicle. Returns how many were newly taken. */
    @LuaFunction
    public final int claimAll() {
        return owner.claimAll();
    }

    /** Hand everything back. Returns how many were released. */
    @LuaFunction
    public final int releaseAll() {
        return owner.releaseAll();
    }

    /** Names of everything currently under computer control. */
    @LuaFunction
    public final List<String> listClaimed() {
        List<String> out = new ArrayList<>();
        for (ThingComputerBlockEntity.Device device : owner.devices()) {
            if (device.cable() || owner.isClaimed(device.name())) out.add(device.name());
        }
        return out;
    }

    /**
     * Простая правда о положении, без физики.
     *
     * Нужна потому, что всё интересное про корпус считает физический движок, а
     * он временами не готов ответить. Позиция блока известна всегда, и для
     * удержания высоты этого уже достаточно.
     *
     * Имя не {@code getPosition}: такой метод уже есть выше, унаследованный от
     * модема и возвращающий {@code Vec3}. Два метода с одинаковым стиранием и
     * разными типами возврата Java не разрешает.
     */
    @LuaFunction
    public final Map<String, Object> getBlockPosition() {
        Map<String, Object> m = new HashMap<>();
        BlockPos p = owner.getBlockPos();
        m.put("x", p.getX());
        m.put("y", p.getY());
        m.put("z", p.getZ());
        m.put("onSubLevel", owner.subLevel() != null);
        return m;
    }

    /**
     * Держать чанки саблевела загруженными.
     *
     * Выгрузка чанка глушит не только компьютер и радар, но и реактор, а
     * перезапускать его в полёте нечем. Удержание идёт через бюджетный менеджер
     * Ritchie's - тот же, что у снарядов, - и он не генерирует местность: если
     * чанка нет на диске, запрос снимается. Ванильный форс-лоад так не умеет и
     * однажды уже положил мир, попав на саблевел.
     *
     * Настройка сохраняется: смысл её в работе без присмотра.
     */
    @LuaFunction
    public final void setKeepLoaded(boolean value) {
        owner.enqueue(() -> owner.setKeepLoaded(value));
    }

    @LuaFunction
    public final boolean isKeepLoaded() {
        return owner.isKeepLoaded();
    }

    // ---- прямое управление устройствами саблевела ----

    /**
     * Найти блок-сущность устройства по его имени в списке шины.
     *
     * Шина знает позицию каждого устройства, поэтому добраться до самого блока
     * можно и не спрашивая ComputerCraft. Это важнее, чем кажется: периферию на
     * блок отдаёт кто-то один, и если её занял чужой мод, наши методы до
     * устройства не доходят вовсе. Через шину они доходят всегда, потому что
     * шина наша от начала до конца.
     */
    private @Nullable BlockEntity deviceEntity(String name) {
        Level level = owner.getLevel();
        if (level == null) return null;
        for (ThingComputerBlockEntity.Device device : owner.devices()) {
            if (device.name().equals(name)) return level.getBlockEntity(device.pos());
        }
        return null;
    }

    /**
     * Задать обороты ведомой стороне умной передачи по имени устройства.
     *
     * Обход того, что периферию блока занимает Simulated: мы обращаемся не к
     * периферии, а к самой блок-сущности через свой интерфейс управления.
     * Поведение то же самое - отношение считается от фактической скорости
     * входа, а посторонний редстоун передача, пока управляет компьютер, не
     * слушает.
     */
    @LuaFunction
    public final boolean setDriveSpeed(String name, double rpm) throws LuaException {
        BlockEntity be = deviceEntity(name);
        if (be == null) throw new LuaException("no such device: " + name);
        if (!(be instanceof IAnalogTransmissionControl control)) {
            throw new LuaException(name + " is not a smart transmission");
        }
        // Само присваивание переносится в серверный тик: менять чужую
        // блок-сущность из потока компьютера так же опасно, как и читать её
        // оттуда, а пересборка кинетической сети внутри - тем более.
        owner.enqueue(() -> control.invfix$setTargetSpeed((float) rpm));
        return true;
    }

    /** Вернуть передачу под редстоун. */
    @LuaFunction
    public final boolean clearDriveSpeed(String name) throws LuaException {
        BlockEntity be = deviceEntity(name);
        if (be == null) throw new LuaException("no such device: " + name);
        if (!(be instanceof IAnalogTransmissionControl control)) {
            throw new LuaException(name + " is not a smart transmission");
        }
        owner.enqueue(() -> control.invfix$setTargetSpeed(null));
        return true;
    }

    /** Что сейчас с передачей: задание, обе стороны, кто ведомый. */
    @LuaFunction
    public final Map<String, Object> getDrive(String name) throws LuaException {
        BlockEntity be = deviceEntity(name);
        if (be == null) throw new LuaException("no such device: " + name);
        if (!(be instanceof IAnalogTransmissionControl control)) {
            throw new LuaException(name + " is not a smart transmission");
        }
        Map<String, Object> m = new HashMap<>();
        Float target = control.invfix$targetSpeed();
        m.put("target", target == null ? Boolean.FALSE : target);
        m.put("computerControlled", target != null);
        m.put("shaft", control.invfix$shaftSpeed());
        m.put("cog", control.invfix$cogSpeed());
        m.put("drivenSide", control.invfix$shaftDriven() ? "shaft" : "cog");
        m.put("driven", control.invfix$shaftDriven()
                ? control.invfix$shaftSpeed() : control.invfix$cogSpeed());
        m.put("input", control.invfix$shaftDriven()
                ? control.invfix$cogSpeed() : control.invfix$shaftSpeed());
        m.put("maxSpeed", AllConfigs.server().kinetics.maxRotationSpeed.get());
        return m;
    }

    @LuaFunction
    public final boolean isOnSubLevel() {
        return owner.subLevel() != null;
    }
}