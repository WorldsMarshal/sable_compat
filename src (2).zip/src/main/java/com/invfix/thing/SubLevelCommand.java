package com.invfix.thing;

import com.mojang.brigadier.Command;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * Команды осмотра и починки саблевела, на котором стоит игрок.
 *
 *   /sublevel status   — сводка по типам блок-сущностей и подозрительным
 *   /sublevel list     — поимённо, только подозрительные, с координатами
 *   /sublevel refresh  — переродить все блок-сущности саблевела
 *
 * Точка отсчёта — позиция вызывающего, поэтому стоять надо на самом корабле.
 * Только для оператора: {@code refresh} трогает весь корабль разом, и на чужом
 * судне это выглядело бы неотличимо от диверсии.
 */
@EventBusSubscriber(modid = "sable_compat")
public class SubLevelCommand {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("sublevel")
                        .requires(s -> s.hasPermission(2))
                        .then(Commands.literal("status").executes(ctx -> status(ctx.getSource())))
                        .then(Commands.literal("list").executes(ctx -> list(ctx.getSource())))
                        .then(Commands.literal("refresh").executes(ctx -> refresh(ctx.getSource())))
        );
    }

    /**
     * Найти корабль под вызывающим.
     *
     * Позиция берётся мировая, и это важно: игрок ходит по перенесённой оболочке
     * столкновений в обычном мире, а блоки корабля лежат в плоте за миллионы
     * блоков отсюда. Поиск идёт по мировым габаритам саблевела, а не по
     * координатам под ногами.
     */
    private static @Nullable ServerSubLevel resolve(CommandSourceStack source) {
        ServerSubLevel sub = SubLevelDoctor.subLevelAt(source.getLevel(), source.getPosition());
        if (sub == null) {
            source.sendFailure(Component.literal(
                    "Саблевела рядом нет. Встань на корабль или ближе к нему."));
        }
        return sub;
    }

    private static int status(CommandSourceStack source) {
        ServerSubLevel sub = resolve(source);
        if (sub == null) return 0;

        List<SubLevelDoctor.Finding> findings = SubLevelDoctor.diagnose(sub);
        Map<String, int[]> summary = SubLevelDoctor.summarise(findings);

        int found = 0;
        for (SubLevelDoctor.Finding f : findings) if (f.suspect()) found++;
        // Лямбда сообщения захватывает переменную, а счётчик менялся в цикле,
        // поэтому итог перекладывается в отдельную неизменяемую копию.
        final int suspect = found;

        source.sendSuccess(() -> Component.literal("Саблевел: " + findings.size()
                + " блок-сущностей, из них подозрительных " + suspect)
                .withStyle(suspect == 0 ? ChatFormatting.GREEN : ChatFormatting.YELLOW), false);

        summary.entrySet().stream()
                .sorted((a, b) -> Integer.compare(b.getValue()[0], a.getValue()[0]))
                .limit(20)
                .forEach(e -> source.sendSuccess(() -> Component.literal(
                        String.format("  %-46s %4d  подозр. %d",
                                e.getKey(), e.getValue()[0], e.getValue()[1])), false));
        return findings.size();
    }

    private static int list(CommandSourceStack source) {
        ServerSubLevel sub = resolve(source);
        if (sub == null) return 0;

        int shown = 0;
        for (SubLevelDoctor.Finding f : SubLevelDoctor.diagnose(sub)) {
            if (!f.suspect()) continue;
            if (shown++ >= 40) {
                source.sendSuccess(() -> Component.literal("  ... остальные не показаны"), false);
                break;
            }
            source.sendSuccess(() -> Component.literal(String.format("  %d %d %d  %s — %s",
                    f.pos().getX(), f.pos().getY(), f.pos().getZ(), f.type(), f.state()))
                    .withStyle(ChatFormatting.YELLOW), false);
        }
        if (shown == 0) {
            source.sendSuccess(() -> Component.literal("Подозрительных нет.")
                    .withStyle(ChatFormatting.GREEN), false);
        }
        return shown;
    }

    private static int refresh(CommandSourceStack source) {
        ServerSubLevel sub = resolve(source);
        if (sub == null) return 0;

        int total = SubLevelDoctor.refresh(source.getLevel(), sub);
        source.sendSuccess(() -> Component.literal("Перерождаю блок-сущности: " + total
                + " штук, порциями по тикам. Подожди несколько секунд.")
                .withStyle(ChatFormatting.AQUA), true);
        return total == 0 ? 0 : Command.SINGLE_SUCCESS;
    }
}
