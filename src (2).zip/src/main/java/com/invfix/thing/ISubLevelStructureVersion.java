package com.invfix.thing;

/**
 * A counter on Sable's LevelPlot that moves whenever the vehicle's structure
 * does.
 *
 * The bus needs to know when the set of blocks on a sub-level changes. Asking
 * that question by looking is possible but costs a walk over every block entity
 * on the vehicle, every tick, forever - and the answer is almost always "no
 * change". Sable already routes every block placed or broken inside a plot
 * through LevelPlot.onBlockChange, so the cheaper and more exact arrangement is
 * to have that call bump a number here and let the bus compare two longs.
 *
 * Implemented on LevelPlot by PlotStructureVersionMixin. Code that reads it
 * should check the instanceof rather than cast blindly, so that a build without
 * the mixin applied degrades to the periodic backstop instead of crashing.
 */
public interface ISubLevelStructureVersion {

    /** Monotonic; only equality between two readings is meaningful. */
    long invfix$structureVersion();

    /** Force readers to treat the structure as changed. */
    void invfix$bumpStructureVersion();
}
