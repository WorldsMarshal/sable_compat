package com.invfix.thing;

import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.companion.math.BoundingBox3d;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.sublevel.SubLevel;
import dev.ryanhcode.sable.sublevel.plot.PlotChunkHolder;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3dc;

/**
 * Осмотр и починка саблевела, пережившего аварийную остановку.
 *
 * Когда игра виснет на столкновении и мир не успевает сохраниться, чанки плота
 * возвращаются с диска в состоянии, которого никогда не было целиком: блоки на
 * месте, а всё, что живёт не в блоке, а в связях между блоками, потеряно.
 * Кинетические сети, провода энергосети, привязки радара к своей опоре — всё
 * это строится в {@code initialize} блок-сущности при загрузке чанка, и если
 * сущность вернулась с обрывками старых ссылок, она больше не соберётся сама:
 * с её точки зрения она уже инициализирована.
 *
 * Отсюда лечение: заставить сущность родиться заново. Её NBT снимается, сама
 * она сносится, ставится обратно из того же состояния блока и получает свой NBT
 * назад. Для мира это выглядит как «блок переставили», для Create — как новый
 * блок в сети, а всё, что было в инвентаре и настройках, остаётся на месте,
 * потому что переезжает вместе с NBT.
 *
 * Именно поэтому способ годится для блоков, которые не выпадают в выживании:
 * ломать их не нужно, они и не ломаются.
 */
public final class SubLevelDoctor {

    /**
     * Сколько блок-сущностей чинить за тик.
     *
     * Тридцать тысяч блоков разом — это зависшая игра во второй раз за вечер.
     * Порция подобрана так, чтобы авианосец лечился секунд за десять, а сервер
     * этого не заметил.
     */
    private static final int PER_TICK = 64;

    private SubLevelDoctor() {}

    // ---- осмотр ----

    /** Что удалось понять про одну блок-сущность. */
    public record Finding(BlockPos pos, String type, String state, boolean suspect) {}

    /**
     * Пройтись по саблевелу и рассказать, кто как себя чувствует.
     *
     * Универсального признака «блок жив» не существует, поэтому проверяется то,
     * что можно проверить честно: снята ли сущность с учёта, есть ли у
     * кинетики источник вращения и не перегружена ли она. Остальное выводится
     * как есть, без выводов — список типов и количеств сам по себе показывает,
     * если чего-то не хватает.
     */
    public static List<Finding> diagnose(ServerSubLevel sub) {
        List<Finding> out = new ArrayList<>();
        for (BlockEntity be : blockEntities(sub)) {
            String type = key(be);
            StringBuilder note = new StringBuilder();
            boolean suspect = false;

            if (be.isRemoved()) {
                note.append("снята с учёта");
                suspect = true;
            }
            if (be instanceof com.invfix.radar.AesaArrayBlockEntity aesa) {
                // Отдельно, потому что «молчит при исправной проводке» — это про
                // AESA, и без этих трёх чисел причину не отличить: нет мастера,
                // нет питания или просто маленькая решётка.
                if (note.length() > 0) note.append(", ");
                if (aesa.isMaster()) {
                    note.append("мастер, панелей ").append(aesa.structureSize());
                    if (!aesa.isPowered()) {
                        note.append(", БЕЗ ПИТАНИЯ");
                        suspect = true;
                    }
                    note.append(", ").append(aesa.storedEnergy()).append(" FE");
                } else {
                    // Кластер сам выбирает, кто ведёт развёртку, поэтому «модуль»
                    // здесь не диагноз, а просто роль: считает соседняя панель.
                    note.append("модуль кластера из ").append(aesa.structureSize());
                }
            }
            if (be instanceof KineticBlockEntity kinetic) {
                if (note.length() > 0) note.append(", ");
                note.append(String.format("%.1f об/мин", kinetic.getSpeed()));
                if (!kinetic.hasSource() && kinetic.getGeneratedSpeed() == 0.0F) {
                    note.append(", без источника");
                    suspect = true;
                }
                if (kinetic.isOverStressed()) {
                    note.append(", перегрузка");
                    suspect = true;
                }
            }
            out.add(new Finding(be.getBlockPos(), type,
                    note.length() == 0 ? "норма" : note.toString(), suspect));
        }
        return out;
    }

    /** Сводка по типам: сколько всего и сколько подозрительных. */
    public static Map<String, int[]> summarise(List<Finding> findings) {
        Map<String, int[]> out = new LinkedHashMap<>();
        for (Finding f : findings) {
            int[] counts = out.computeIfAbsent(f.type(), k -> new int[2]);
            counts[0]++;
            if (f.suspect()) counts[1]++;
        }
        return out;
    }

    // ---- починка ----

    /**
     * Переродить все блок-сущности саблевела, порциями по тикам.
     *
     * Возвращает сколько штук взято в работу; сама работа растянется на
     * несколько тиков.
     */
    public static int refresh(ServerLevel level, ServerSubLevel sub) {
        REBUILD.clear();
        Deque<BlockPos> queue = new ArrayDeque<>();
        for (BlockEntity be : blockEntities(sub)) queue.add(be.getBlockPos().immutable());
        int total = queue.size();
        if (total == 0) return 0;
        step(level, queue);
        return total;
    }

    private static void step(ServerLevel level, Deque<BlockPos> queue) {
        int done = 0;
        while (done < PER_TICK && !queue.isEmpty()) {
            reborn(level, queue.poll());
            done++;
        }
        if (!queue.isEmpty()) {
            level.getServer().execute(() -> step(level, queue));
        } else {
            // Перерождение возвращает панелям тот же NBT, включая ссылку на
            // мастера. Если она была протухшей, она такой и осталась, поэтому
            // структуры дособираются отдельно, уже после того как все панели на
            // месте.
            level.getServer().execute(() -> rebuildArrays(level));
        }
    }

    private static void rebuildArrays(ServerLevel level) {
        for (BlockPos pos : REBUILD) {
            if (level.getBlockEntity(pos) instanceof com.invfix.radar.AesaArrayBlockEntity aesa) {
                aesa.validateStructure();
            }
        }
        REBUILD.clear();
    }

    /** Позиции панелей AESA, встреченных при перерождении. */
    private static final List<BlockPos> REBUILD = new ArrayList<>();

    /**
     * Снести сущность и поставить её обратно с тем же содержимым.
     *
     * Порядок важен. NBT снимается до удаления, иначе сохранять будет нечего.
     * {@code removeBlockEntity} заставляет чанк забыть про старую; следующее
     * обращение к позиции создаёт новую через сам блок, и вот она уже пройдёт
     * {@code initialize} с чистого листа. NBT возвращается сразу, чтобы
     * инвентарь, фильтры и настройки не потерялись, а обновление соседей
     * достраивает связи, которые собираются не изнутри блока, а снаружи.
     */
    private static void reborn(ServerLevel level, BlockPos pos) {
        BlockEntity old = level.getBlockEntity(pos);
        if (old == null) return;

        BlockState state = level.getBlockState(pos);
        if (old instanceof com.invfix.radar.AesaArrayBlockEntity) REBUILD.add(pos);
        HolderLookup.Provider registries = level.registryAccess();
        CompoundTag data;
        try {
            data = old.saveWithoutMetadata(registries);
        } catch (Throwable t) {
            return;   // сущность настолько плоха, что не сохраняется - не трогаем
        }

        try {
            LevelChunk chunk = level.getChunkAt(pos);
            chunk.removeBlockEntity(pos);

            BlockEntity fresh = ((net.minecraft.world.level.block.EntityBlock) state.getBlock())
                    .newBlockEntity(pos, state);
            if (fresh == null) return;
            fresh.loadWithComponents(data, registries);
            chunk.addAndRegisterBlockEntity(fresh);
            fresh.setChanged();

            level.sendBlockUpdated(pos, state, state, Block.UPDATE_ALL);
            level.updateNeighborsAt(pos, state.getBlock());
        } catch (Throwable ignored) {
            // один упрямый блок не должен останавливать лечение всего корабля
        }
    }

    // ---- обход саблевела ----

    /**
     * Все блок-сущности саблевела, в котором стоит точка отсчёта.
     *
     * Чанки берутся у самого плота, а не гаданием радиусом вокруг: корабль на
     * тридцать тысяч блоков в любой квадрат не влезет.
     */
    private static List<BlockEntity> blockEntities(ServerSubLevel sub) {
        List<BlockEntity> out = new ArrayList<>();
        if (sub == null) return out;
        try {
            for (PlotChunkHolder holder : sub.getPlot().getLoadedChunks()) {
                LevelChunk chunk = holder.getChunk();
                if (chunk != null) out.addAll(chunk.getBlockEntities().values());
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    /** Насколько далеко от игрока искать корабль, если он не внутри плота. */
    private static final double SEARCH_RADIUS = 12.0;

    /**
     * Найти саблевел, на котором стоит точка мировых координат.
     *
     * Двумя способами, и второй — основной. Игрок, идущий по палубе, физически
     * находится в обычном мире: под ним лежит перенесённая оболочка столкновений,
     * а сами блоки корабля живут в плоте за миллионы блоков отсюда. Поэтому
     * прямой {@code getContaining} от его позиции честно отвечает, что плота
     * здесь нет, и это не ошибка Sable.
     *
     * Правильный вопрос звучит иначе: какой саблевел своими мировыми габаритами
     * накрывает эту точку. На него отвечает {@code getAllIntersecting}, которому
     * даётся небольшой куб вокруг игрока. Прямая проверка оставлена первой на
     * случай, если игрока всё же занесло внутрь самого плота — телепортом или
     * отладкой.
     */
    public static @Nullable ServerSubLevel subLevelAt(ServerLevel level, Vec3 worldPos) {
        try {
            SubLevel inside = Sable.HELPER.getContaining(level, BlockPos.containing(worldPos));
            if (inside instanceof ServerSubLevel ssl) return ssl;
        } catch (Throwable ignored) {
        }

        try {
            BoundingBox3d box = new BoundingBox3d(
                    worldPos.x - SEARCH_RADIUS, worldPos.y - SEARCH_RADIUS, worldPos.z - SEARCH_RADIUS,
                    worldPos.x + SEARCH_RADIUS, worldPos.y + SEARCH_RADIUS, worldPos.z + SEARCH_RADIUS);
            ServerSubLevel best = null;
            double bestDist = Double.MAX_VALUE;
            for (Object o : Sable.HELPER.getAllIntersecting(level, box)) {
                if (!(o instanceof ServerSubLevel sub)) continue;
                Vector3dc p = sub.logicalPose().position();
                double dx = p.x() - worldPos.x, dy = p.y() - worldPos.y, dz = p.z() - worldPos.z;
                double d = dx * dx + dy * dy + dz * dz;
                if (d < bestDist) {
                    bestDist = d;
                    best = sub;
                }
            }
            return best;
        } catch (Throwable t) {
            return null;
        }
    }

    private static String key(BlockEntity be) {
        var id = net.minecraft.core.registries.BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(be.getType());
        return id == null ? be.getClass().getSimpleName() : id.toString();
    }
}
