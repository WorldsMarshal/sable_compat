package com.invfix.thing;

import dan200.computercraft.api.peripheral.IPeripheral;
import dan200.computercraft.api.network.wired.WiredNode;
import dan200.computercraft.api.peripheral.PeripheralCapability;
import dan200.computercraft.core.computer.ComputerSide;
import dan200.computercraft.shared.computer.blocks.ComputerBlockEntity;
import dan200.computercraft.shared.computer.core.ComputerFamily;
import dan200.computercraft.shared.computer.core.ServerComputer;
import dan200.computercraft.shared.peripheral.modem.ModemState;
import com.invfix.dbw.ICableLinked;
import com.invfix.dbw.WireLinks;
import dev.ryanhcode.sable.api.physics.handle.RigidBodyHandle;
import dev.ryanhcode.sable.api.physics.mass.MassData;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaterniondc;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.sublevel.SubLevel;
import dev.ryanhcode.sable.sublevel.plot.PlotChunkHolder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerLevel;
import dev.ryanhcode.sable.api.sublevel.ServerSubLevelContainer;
import dev.ryanhcode.sable.api.sublevel.SubLevelContainer;
import dev.ryanhcode.sable.api.sublevel.ticket.SubLevelLoadingTicketType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;

/**
 * The thingamajig computer.
 *
 * An advanced computer in every respect - same terminal, same filesystem, same
 * animation and interaction - with two things added that only make sense on a
 * vehicle:
 *
 *   * a sub-level bus on its BACK side, which attaches every peripheral in the
 *     sub-level by name with no cable at all;
 *   * a wireless modem built into the case, so a missile does not have to carry
 *     a separate modem block and pay for it in centre-of-mass offset.
 *
 * Off a sub-level both extras go quiet and it behaves exactly like the advanced
 * computer it is built from. Nothing about the base class is replaced - it is
 * subclassed - so CC's own behaviour, including anything added in a future
 * version, comes along unchanged.
 */
public class ThingComputerBlockEntity extends ComputerBlockEntity implements ICableLinked {

    private static final org.slf4j.Logger LOG = com.mojang.logging.LogUtils.getLogger();

    /** The side the bus owns. Nothing external may claim it. */
    public static final ComputerSide BUS_SIDE = ComputerSide.BACK;
    /** The side the built-in modem owns. Likewise reserved. */
    public static final ComputerSide MODEM_SIDE = ComputerSide.TOP;

    private static final String NBT_NAMES = "SubLevelBusNames";
    private static final String NBT_CLAIMED = "SubLevelBusClaimed";
    private static final String NBT_KEEP_LOADED = "SubLevelKeepLoaded";
    /**
     * Backstop only. The bus normally rescans the same tick the vehicle changes;
     * this exists for the one case a fingerprint cannot see - a block that keeps
     * its block entity but stops or starts publishing a peripheral.
     */
    private static final int RESCAN_BACKSTOP = 20;

    private final ModemState modemState = new ModemState();
    private @Nullable ThingModemPeripheral modem;

    private @Nullable SubLevelBusElement busElement;
    private @Nullable SubLevelBusPeripheral bus;

    private long cacheTick = Long.MIN_VALUE;
    private List<BlockEntity> cachedBlocks = Collections.emptyList();
    private int backstopCooldown = 0;
    private long lastStructureVersion = Long.MIN_VALUE;
    private @Nullable ServerSubLevel lastSubLevel;

    /**
     * Names handed out to peripherals, keyed by where the peripheral lives.
     *
     * A program that wrapped "vector_thruster_2" should still be talking to the
     * same thruster after a neighbouring block is broken, so an assignment is
     * made once per position and kept - including across a save, which is why it
     * goes into NBT. Recomputing indices per scan would renumber the whole
     * vehicle every time anything changed.
     */
    private final Map<BlockPos, String> names = new HashMap<>();
    private final Set<String> usedNames = new HashSet<>();

    /**
     * Everything the bus can see, whether or not it is being used.
     *
     * Rebuilt on rescan. Nothing here reaches a computer by itself - see
     * published() for what actually goes onto the network.
     */
    private final Map<String, Device> inventory = new LinkedHashMap<>();

    /**
     * The devices the program has actually asked for.
     *
     * This set is the whole point of the redesign. A wired modem hijacks a
     * cannon mount or a thruster the moment it attaches, so a bus that published
     * the entire vehicle would take a battleship's every mount away from its crew
     * the instant the computer was switched on. Claiming is therefore explicit
     * and persistent: the computer starts inert and takes only what it is told
     * to take.
     */
    private final Set<String> claimed = new HashSet<>();

    /** Wired nodes we have tied ourselves to over a DriveByWire cable. */
    private final Set<WiredNode> linked = new HashSet<>();

    /**
     * Держать чанки саблевела загруженными.
     *
     * Выгрузка чанка останавливает не только компьютер и радар, но и реактор:
     * после возвращения всё это приходится перезапускать руками, а на корабле в
     * полёте перезапускать нечем. Флаг переживает сохранение, потому что смысл
     * его именно в том, чтобы работать без присмотра.
     */
    private boolean keepLoaded;

    /**
     * Что видит компьютерный поток. Строится здесь, читается там.
     *
     * Периферия ComputerCraft работает в своём потоке, а поза саблевела, трекер
     * массы и карты блок-сущностей чанков принадлежат серверному. Читать их
     * оттуда напрямую - гонка с физическим потоком, и стоит она дорого: в
     * лучшем случае мусорные числа, в худшем перезагрузка саблевела и игрок,
     * выброшенный хитбоксом за километр. Проверено на практике.
     *
     * Поэтому наружу отдаётся не живое состояние, а снимок: он собирается один
     * раз за тик здесь, на серверном потоке, и публикуется через volatile
     * ссылку на неизменяемые структуры. Читатель либо видит прошлый снимок,
     * либо новый, и никогда - наполовину переписанный.
     */
    private volatile Map<String, Object> vehicleSnapshot = Map.of();
    private volatile List<Device> deviceSnapshot = List.of();

    /**
     * Команды от компьютера, исполняемые в тике.
     *
     * Запись в чужую блок-сущность из потока компьютера так же небезопасна, как
     * и чтение. Очередь переносит её в серверный поток, а неограниченный рост
     * не грозит: команд приходит единицы, и каждый тик очередь опустошается.
     */
    private final java.util.Queue<Runnable> pending = new java.util.concurrent.ConcurrentLinkedQueue<>();

    /**
     * Takes only position and state, because BlockEntityType.Builder.of wants a
     * BlockEntitySupplier, whose signature is exactly (BlockPos, BlockState).
     * The parent needs the type as well, so it is pulled from the registry
     * here - by the time an entity is actually built the holder is filled, and
     * the builder itself never calls this, it only stores the reference.
     * This is the same shape the rest of the mod's block entities use.
     */
    public ThingComputerBlockEntity(BlockPos pos, BlockState state) {
        super(ThingRegistry.THING_COMPUTER_BE.get(), pos, state, ComputerFamily.ADVANCED);
    }

    /**
     * Both extra sides are reserved. Without this the base class would overwrite
     * them every time a neighbouring block changed.
     */
    @Override
    protected boolean isPeripheralBlockedOnSide(ComputerSide localSide) {
        return localSide == BUS_SIDE || localSide == MODEM_SIDE
                || super.isPeripheralBlockedOnSide(localSide);
    }

    @Override
    public void serverTick() {
        super.serverTick();
        if (level == null || level.isClientSide) return;

        ServerComputer computer = getServerComputer();
        if (computer == null) return;

        if (busElement == null) {
            busElement = new SubLevelBusElement(this);
            bus = new SubLevelBusPeripheral(this, busElement);
        }
        if (modem == null) modem = new ThingModemPeripheral(this, modemState);

        // Ставится только при изменении.
        //
        // Каждый setPeripheral берёт в серверном потоке замок окружения
        // компьютера и замок таблицы периферий, а поток компьютера берёт те же
        // замки в обратном порядке, ожидая задачу главного потока. На каждом
        // тике это рано или поздно кончается взаимной блокировкой: серверный
        // ждёт компьютерный, компьютерный - серверный, и мир встаёт целиком.
        // Проверка через getPeripheral замков не берёт.
        if (computer.getPeripheral(BUS_SIDE) != bus) computer.setPeripheral(BUS_SIDE, bus);
        if (computer.getPeripheral(MODEM_SIDE) != modem) computer.setPeripheral(MODEM_SIDE, modem);

        // Rediscovery is driven by the vehicle changing shape, not by a clock.
        // Sable already routes every block placed or broken inside a plot
        // through LevelPlot.onBlockChange, and the mixin turns that into a
        // counter, so the steady-state cost of this check is comparing two
        // longs - the block-entity walk happens only on the tick something
        // actually moved. A stage separating or a thruster being blown off is
        // therefore reflected on the very next tick, not up to a second later.
        //
        // None of this sits in the path of a peripheral call. Once a peripheral
        // is on the network the computer holds the object itself and calls
        // straight into it, so there is no added latency between the computer
        // and any device on the vehicle, at any tick rate.
        ServerSubLevel sub = subLevel();
        long version = structureVersion(sub);
        if (version != lastStructureVersion || sub != lastSubLevel || --backstopCooldown <= 0) {
            lastStructureVersion = version;
            lastSubLevel = sub;
            backstopCooldown = RESCAN_BACKSTOP;
            rebuildInventory();
            relinkCables();
            publish();
        }

        // Команды компьютера исполняются здесь, а не там, откуда пришли.
        Runnable job;
        while ((job = pending.poll()) != null) {
            try {
                job.run();
            } catch (Throwable t) {
                LOG.error("[sable_compat] queued command failed", t);
            }
        }

        updateHoldTicket(sub);

        // Снимок для компьютерного потока. Раз в тик, на сервере, целиком.
        vehicleSnapshot = buildVehicleSnapshot(sub);
        deviceSnapshot = List.copyOf(inventory.values());

        if (modemState.pollChanged()) setChanged();
    }

    /**
     * Собрать всё, что компьютеру может понадобиться знать о корпусе.
     *
     * Вызывается только из тика. Каждое поле в своём перехвате: физика имеет
     * право быть не готовой, и одна неготовая величина не должна лишать
     * программу остальных. Позиция кладётся всегда - без неё снимок бесполезен
     * для полёта.
     */
    private Map<String, Object> buildVehicleSnapshot(@Nullable ServerSubLevel sub) {
        Map<String, Object> m = new HashMap<>();
        BlockPos here = getBlockPos();
        m.put("onSubLevel", sub != null);
        m.put("localx", here.getX());
        m.put("localy", here.getY());
        m.put("localz", here.getZ());

        if (sub == null) {
            m.put("x", here.getX() + 0.5);
            m.put("y", here.getY() + 0.5);
            m.put("z", here.getZ() + 0.5);
            m.put("vx", 0.0);
            m.put("vy", 0.0);
            m.put("vz", 0.0);
            return Map.copyOf(m);
        }

        try {
            Vec3 world = sub.logicalPose().transformPosition(
                    new Vec3(here.getX() + 0.5, here.getY() + 0.5, here.getZ() + 0.5));
            m.put("x", world.x);
            m.put("y", world.y);
            m.put("z", world.z);
        } catch (Throwable t) {
            m.put("x", here.getX() + 0.5);
            m.put("y", here.getY() + 0.5);
            m.put("z", here.getZ() + 0.5);
        }

        try {
            Quaterniondc q = sub.logicalPose().orientation();
            m.put("qx", q.x());
            m.put("qy", q.y());
            m.put("qz", q.z());
            m.put("qw", q.w());
        } catch (Throwable ignored) {
        }

        try {
            MassData mass = sub.getMassTracker();
            if (mass != null) {
                m.put("mass", (double) mass.getMass());
                m.put("valid", !mass.isInvalid());
                Vector3dc com = mass.getCenterOfMass();
                if (com != null) {
                    m.put("comx", com.x());
                    m.put("comy", com.y());
                    m.put("comz", com.z());
                }
            }
        } catch (Throwable ignored) {
        }

        try {
            RigidBodyHandle body = RigidBodyHandle.of(sub);
            if (body != null) {
                Vector3d lin = body.getLinearVelocity(new Vector3d());
                Vector3d ang = body.getAngularVelocity(new Vector3d());
                m.put("vx", lin.x);
                m.put("vy", lin.y);
                m.put("vz", lin.z);
                m.put("wx", ang.x);
                m.put("wy", ang.y);
                m.put("wz", ang.z);
            }
        } catch (Throwable ignored) {
        }
        if (!m.containsKey("vy")) {
            m.put("vx", 0.0);
            m.put("vy", 0.0);
            m.put("vz", 0.0);
        }

        try {
            m.put("uuid", sub.getUniqueId().toString());
        } catch (Throwable ignored) {
        }
        m.put("blocks", cachedBlocks.size());
        return Map.copyOf(m);
    }

    /**
     * Билет на удержание саблевела, выданный от нашего имени.
     *
     * Sable держит свои саблевелы сам и умеет удерживать их принудительно -
     * ровно этим занимается его команда forceload. Механизм билетный: билет
     * выдаётся на конкретный саблевел, помечается типом и ключом владельца и
     * сохраняется в собственный файл Sable. Пока билет есть, саблевел
     * загружен; убрали билет - отпустили.
     *
     * Это единственно правильный путь. Ванильный форс-лоад по координатам
     * плота однажды уже положил мир, а чужой менеджер чанков из библиотеки
     * снарядов ничего не знает про плоты и спорил бы с Sable за одни и те же
     * чанки. Здесь спорить не с кем: хозяин один и мы просим его, а не лезем
     * мимо.
     *
     * Ключ билета - позиция компьютера, поэтому два компьютера на одном
     * корабле не мешают друг другу и каждый снимает только свой билет.
     */
    private static final SubLevelLoadingTicketType KEEP_LOADED_TICKET =
            SubLevelLoadingTicketType.create(
                    ResourceLocation.fromNamespaceAndPath("sable_compat", "computer_hold"),
                    BlockPos.CODEC);

    private boolean ticketIssued;

    private void updateHoldTicket(@Nullable ServerSubLevel sub) {
        if (!(level instanceof ServerLevel server)) return;
        boolean want = keepLoaded && sub != null;
        if (want == ticketIssued) return;

        try {
            ServerSubLevelContainer container =
                    (ServerSubLevelContainer) SubLevelContainer.getContainer(server);
            if (container == null) return;

            if (want) {
                container.addForceLoadTicket(sub, KEEP_LOADED_TICKET, getBlockPos());
            } else if (lastHeld != null) {
                container.removeForceLoadTicket(lastHeld, KEEP_LOADED_TICKET, getBlockPos());
            }
            ticketIssued = want;
            lastHeld = want ? sub : null;
        } catch (Throwable t) {
            LOG.error("[sable_compat] keepLoaded ticket failed", t);
        }
    }

    /** Саблевел, на который выдан билет: снимать надо именно с него. */
    private @Nullable ServerSubLevel lastHeld;

    public boolean isKeepLoaded() {
        return keepLoaded;
    }

    public void setKeepLoaded(boolean value) {
        if (keepLoaded == value) return;
        keepLoaded = value;
        setChanged();
        // Билет выдаётся или снимается в ближайшем тике, где есть саблевел.
        LOG.info("[sable_compat] keepLoaded {} at {}", value, getBlockPos());
    }

    /** Поставить команду в очередь на исполнение в серверном тике. */
    public void enqueue(Runnable job) {
        pending.add(job);
    }

    /** Снимок состояния корпуса, каким его увидит компьютер. */
    public Map<String, Object> vehicleSnapshot() {
        return vehicleSnapshot;
    }

    @Override
    public void setRemoved() {
        super.setRemoved();
        if (busElement != null) {
            for (WiredNode node : linked) busElement.getNode().disconnectFrom(node);
            linked.clear();
            busElement.getNode().remove();
        }
        if (bus != null) bus.removed();
        if (modem != null) modem.removed();
    }

    // ---- the bus contents ----

    /**
     * How many times this vehicle's structure has changed.
     *
     * The instanceof is not defensive noise: the mixin that supplies the counter
     * is gated on Sable being present, and a build where it did not apply should
     * fall back to the periodic backstop rather than throw. Returning a constant
     * in that case makes the comparison in the tick always come out equal, which
     * is exactly the fallback wanted.
     */
    private long structureVersion(@Nullable ServerSubLevel sub) {
        if (sub == null) return 0L;
        try {
            return sub.getPlot() instanceof ISubLevelStructureVersion v
                    ? v.invfix$structureVersion() : 0L;
        } catch (Throwable t) {
            return 0L;
        }
    }

    /** Force the bus to rebuild on the next tick. */
    public void markBusDirty() {
        lastStructureVersion = Long.MIN_VALUE;
    }

    /**
     * One thing the bus can see.
     *
     * The position is the part that makes the list usable. Names follow CC's
     * convention - type plus an index - and "vector_thruster_1" tells a player
     * nothing about which of the eight thrusters on the hull it is. Carrying the
     * coordinates alongside turns the list from a riddle into a map.
     */
    public record Device(String name, IPeripheral peripheral, BlockPos pos, String type,
                         boolean cable) {}

    /**
     * Take stock of the vehicle and of anything on the end of a cable.
     *
     * Names follow CC's convention, so a program written against a wired modem
     * needs no changes. Cable-attached devices are listed the same way but are
     * marked, because they do not need claiming: running a wire to something is
     * already the player saying which device they meant.
     */
    private void rebuildInventory() {
        inventory.clear();
        if (level == null) return;

        if (subLevel() != null) {
            for (BlockEntity be : sublevelBlockEntities()) {
                if (be == this) continue;
                add(be.getBlockPos(), peripheralAt(be.getBlockPos(), be), false);
            }
        }

        for (BlockPos wired : WireLinks.neighbours(level, getBlockPos())) {
            if (wired.equals(getBlockPos())) continue;
            if (inventory.values().stream().anyMatch(d -> d.pos().equals(wired))) {
                // already seen on the bus: promote it, a cable is an explicit choice
                String name = names.get(wired);
                Device existing = name == null ? null : inventory.get(name);
                if (existing != null) {
                    inventory.put(name, new Device(name, existing.peripheral(), wired,
                            existing.type(), true));
                }
                continue;
            }
            if (level.getBlockEntity(wired) instanceof ICableLinked) continue;
            add(wired, peripheralAt(wired, level.getBlockEntity(wired)), true);
        }
    }

    private void add(BlockPos pos, @Nullable IPeripheral peripheral, boolean cable) {
        if (peripheral == null) return;
        String name = nameFor(pos, peripheral.getType());
        inventory.put(name, new Device(name, peripheral, pos.immutable(),
                peripheral.getType(), cable));
    }

    private @Nullable IPeripheral peripheralAt(BlockPos pos, @Nullable BlockEntity be) {
        if (level == null) return null;
        for (Direction d : Direction.values()) {
            IPeripheral p = level.getCapability(PeripheralCapability.get(), pos, null, be, d);
            if (p != null) return p;
        }
        return null;
    }

    /**
     * What actually goes onto the wired network.
     *
     * Claimed bus devices plus everything on a cable. CC works out what appeared
     * and what went from the map alone and raises the peripheral and
     * peripheral_detach events itself, so releasing a thruster hands it straight
     * back to whoever was flying it manually.
     */
    private void publish() {
        if (busElement == null) return;
        Map<String, IPeripheral> out = new HashMap<>();
        for (Device device : inventory.values()) {
            if (device.cable() || claimed.contains(device.name())) {
                out.put(device.name(), device.peripheral());
            }
        }
        busElement.getNode().updatePeripherals(out);
    }

    /**
     * Tie our wired node to the node of any of our computers on the far end of a
     * cable.
     *
     * This is what lets two computers on the same hull share a network without a
     * single modem or length of networking cable: CC's own wired network does all
     * the work once the nodes are joined, so rednet, peripheral sharing and
     * modem messages all come along. Only our computers can do this - an ordinary
     * advanced computer has no wired element to join.
     */
    private void relinkCables() {
        if (busElement == null || level == null) return;
        Set<WiredNode> wanted = new HashSet<>();
        for (BlockPos pos : WireLinks.neighbours(level, getBlockPos())) {
            if (!(level.getBlockEntity(pos) instanceof ICableLinked other) || other == this) continue;
            WiredNode node = other.invfix$cableNode();
            if (node != null && node != busElement.getNode()) wanted.add(node);
        }
        for (WiredNode node : new HashSet<>(linked)) {
            if (!wanted.contains(node)) {
                busElement.getNode().disconnectFrom(node);
                linked.remove(node);
            }
        }
        for (WiredNode node : wanted) {
            if (linked.add(node)) busElement.getNode().connectTo(node);
        }
    }

    // ---- claiming, as the bus peripheral exposes it ----

    @Override
    public @Nullable WiredNode invfix$cableNode() {
        return busElement == null ? null : busElement.getNode();
    }

    /**
     * Всё, что шина видит.
     *
     * Отдаётся снимок прошлого тика, а не живая карта: она перестраивается в
     * тике, и обход её из потока компьютера рано или поздно поймал бы её на
     * середине перестройки.
     */
    public List<Device> devices() {
        return deviceSnapshot;
    }

    public boolean isClaimed(String name) {
        return claimed.contains(name);
    }

    public boolean claim(String name) {
        if (!inventory.containsKey(name) || !claimed.add(name)) return false;
        publish();
        setChanged();
        return true;
    }

    public boolean release(String name) {
        if (!claimed.remove(name)) return false;
        publish();
        setChanged();
        return true;
    }

    public int claimAll() {
        int taken = 0;
        for (Device device : inventory.values()) {
            if (!device.cable() && claimed.add(device.name())) taken++;
        }
        if (taken > 0) { publish(); setChanged(); }
        return taken;
    }

    public int releaseAll() {
        int freed = claimed.size();
        if (freed == 0) return 0;
        claimed.clear();
        publish();
        setChanged();
        return freed;
    }

    /** Claim every device of a type. The bulk case for a ship full of thrusters. */
    public int claimType(String type) {
        int taken = 0;
        for (Device device : inventory.values()) {
            if (device.type().equals(type) && claimed.add(device.name())) taken++;
        }
        if (taken > 0) { publish(); setChanged(); }
        return taken;
    }

    /** Claim the first unclaimed device of a type, and say which it was. */
    public @Nullable String claimFirst(String type) {
        for (Device device : inventory.values()) {
            if (device.type().equals(type) && !claimed.contains(device.name())) {
                claimed.add(device.name());
                publish();
                setChanged();
                return device.name();
            }
        }
        return null;
    }

    /**
     * Claim whatever sits at an offset from the computer.
     *
     * Relative, not absolute, and that is the only form worth offering. A
     * vehicle's absolute coordinates are either the world position, which is
     * stale the moment the ship moves, or the plot position, which is an
     * eight-digit number that means nothing to anyone. The offset from the
     * computer is small, readable and does not change when the ship does.
     */
    public @Nullable String claimAt(BlockPos offset) {
        BlockPos pos = getBlockPos().offset(offset);
        for (Device device : inventory.values()) {
            if (device.pos().equals(pos)) {
                if (claimed.add(device.name())) { publish(); setChanged(); }
                return device.name();
            }
        }
        return null;
    }

    private String nameFor(BlockPos pos, String type) {
        String existing = names.get(pos);
        if (existing != null) return existing;

        String base = type.toLowerCase(Locale.ROOT);
        int i = 0;
        String candidate = base + "_" + i;
        while (usedNames.contains(candidate)) candidate = base + "_" + (++i);

        names.put(pos.immutable(), candidate);
        usedNames.add(candidate);
        setChanged();
        return candidate;
    }

    // ---- persistence of the name assignments ----

    @Override
    public void saveAdditional(CompoundTag nbt, HolderLookup.Provider registries) {
        super.saveAdditional(nbt, registries);
        nbt.putBoolean(NBT_KEEP_LOADED, keepLoaded);
        if (!claimed.isEmpty()) {
            ListTag taken = new ListTag();
            for (String name : claimed) taken.add(StringTag.valueOf(name));
            nbt.put(NBT_CLAIMED, taken);
        }
        if (names.isEmpty()) return;
        ListTag list = new ListTag();
        for (Map.Entry<BlockPos, String> e : names.entrySet()) {
            CompoundTag entry = new CompoundTag();
            entry.putLong("p", e.getKey().asLong());
            entry.putString("n", e.getValue());
            list.add(entry);
        }
        nbt.put(NBT_NAMES, list);
    }

    @Override
    protected void loadServer(CompoundTag nbt, HolderLookup.Provider registries) {
        super.loadServer(nbt, registries);
        keepLoaded = nbt.getBoolean(NBT_KEEP_LOADED);
        names.clear();
        usedNames.clear();
        claimed.clear();
        ListTag taken = nbt.getList(NBT_CLAIMED, Tag.TAG_STRING);
        for (int i = 0; i < taken.size(); i++) claimed.add(taken.getString(i));

        ListTag list = nbt.getList(NBT_NAMES, Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            String name = entry.getString("n");
            if (name.isEmpty()) continue;
            names.put(BlockPos.of(entry.getLong("p")), name);
            usedNames.add(name);
        }
    }

    // ---- sub-level access ----

    public @Nullable ServerSubLevel subLevel() {
        if (level == null || level.isClientSide) return null;
        try {
            SubLevel s = Sable.HELPER.getContaining(this);
            return (s instanceof ServerSubLevel ssl) ? ssl : null;
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * Every block entity in the sub-level, cached for a tick.
     *
     * A sub-level occupies a small, known set of chunks, so this is a walk over
     * those chunks' block-entity maps rather than a search of the world. It is
     * cached because the bus, the Lua methods and anything else asking in the
     * same tick should not each pay for it.
     */
    public List<BlockEntity> sublevelBlockEntities() {
        if (level == null || level.isClientSide) return Collections.emptyList();
        long now = level.getGameTime();
        if (now == cacheTick) return cachedBlocks;

        List<BlockEntity> out = new ArrayList<>();
        ServerSubLevel sub = subLevel();
        if (sub != null) {
            for (LevelChunk chunk : subLevelChunks(sub)) {
                out.addAll(chunk.getBlockEntities().values());
            }
        }
        cacheTick = now;
        cachedBlocks = out;
        return out;
    }

    /**
     * The chunks the vehicle actually occupies.
     *
     * The plot knows its own loaded chunks, so this asks it rather than probing
     * a fixed box around the computer. That matters for anything long: a plot
     * grows as blocks are placed near its edge, and a guessed 3x3 would quietly
     * stop seeing the nose of a large missile once it outgrew 48 blocks.
     */
    private List<LevelChunk> subLevelChunks(ServerSubLevel sub) {
        List<LevelChunk> out = new ArrayList<>();
        if (level == null) return out;
        try {
            for (PlotChunkHolder holder : sub.getPlot().getLoadedChunks()) {
                LevelChunk c = holder.getChunk();
                if (c != null) out.add(c);
            }
        } catch (Throwable t) {
            // if the plot is mid-teardown, this tick simply sees nothing
            return List.of();
        }
        return out;
    }

    public ModemState modemState() {
        return modemState;
    }

    public @Nullable IPeripheral busPeripheral() {
        return bus;
    }
}