package com.invfix.thing;

import dan200.computercraft.api.peripheral.IPeripheral;
import dan200.computercraft.shared.peripheral.modem.ModemState;
import dan200.computercraft.shared.peripheral.modem.wireless.WirelessModemPeripheral;
import javax.annotation.Nullable;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * The modem built into the case.
 *
 * Advanced-tier, so it is interdimensional and effectively unlimited in range -
 * a missile two hundred thousand blocks downrange still answers. It extends
 * CC's own WirelessModemPeripheral rather than reimplementing one, which means
 * it joins the same packet network as every other modem and Sable's distance
 * compat applies to it unchanged.
 *
 * The position it reports is the computer's own block. On a sub-level that is a
 * plot coordinate, and Sable's WirelessNetworkMixin projects it out to the real
 * world before measuring range - the same treatment a placed modem gets.
 */
public class ThingModemPeripheral extends WirelessModemPeripheral {

    private final ThingComputerBlockEntity owner;

    public ThingModemPeripheral(ThingComputerBlockEntity owner, ModemState state) {
        super(state, true);   // advanced: interdimensional, unlimited range
        this.owner = owner;
    }

    @Override
    public @Nullable Level getLevel() {
        return owner.getLevel();
    }

    @Override
    public Vec3 getPosition() {
        return Vec3.atCenterOf(owner.getBlockPos());
    }

    // The base class already resolves the server's wireless network; there is
    // no reason to reach for it differently and every reason not to - this is
    // the same network every other modem is on, Sable's distance compat
    // included.
    // (WirelessModemPeripheral.getNetwork does exactly this.)

    @Override
    public boolean equals(@Nullable IPeripheral other) {
        return other instanceof ThingModemPeripheral m && m.owner == this.owner;
    }

    @Override
    public Object getTarget() {
        return owner;
    }
}
