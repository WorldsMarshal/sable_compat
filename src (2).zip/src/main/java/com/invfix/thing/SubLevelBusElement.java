package com.invfix.thing;

import dan200.computercraft.api.peripheral.IPeripheral;
import dan200.computercraft.shared.peripheral.modem.wired.WiredModemElement;
import javax.annotation.Nullable;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * The node this computer occupies on CC's wired network.
 *
 * A wired modem answers "what can this computer talk to" with cable, which on
 * a vehicle means mass in places the centre of mass would rather not have it.
 * On a sub-level the question already has an exact answer - everything in the
 * sub-level - and the game knows precisely what that is.
 *
 * So rather than reimplementing peripheral attachment, this is a real wired
 * node with no neighbours: the block entity feeds it the sub-level's
 * peripherals through WiredNode.updatePeripherals, and CC's own machinery does
 * the naming, the wrapping, the peripheral/peripheral_detach events, filesystem
 * mounts for disk drives and everything else a modem network provides. A lone
 * node broadcasts its own changes back to itself, so the map arrives here as a
 * networkChanged and is handed to the peripheral below.
 */
public class SubLevelBusElement extends WiredModemElement {

    private final ThingComputerBlockEntity owner;
    private @Nullable SubLevelBusPeripheral modem;

    public SubLevelBusElement(ThingComputerBlockEntity owner) {
        this.owner = owner;
    }

    void setModem(SubLevelBusPeripheral modem) {
        this.modem = modem;
    }

    @Override
    public Level getLevel() {
        return owner.getLevel();
    }

    @Override
    public Vec3 getPosition() {
        return Vec3.atCenterOf(owner.getBlockPos());
    }

    @Override
    protected void attachPeripheral(String name, IPeripheral peripheral) {
        if (modem != null) modem.attachPeripheral(name, peripheral);
    }

    @Override
    protected void detachPeripheral(String name) {
        if (modem != null) modem.detachPeripheral(name);
    }
}
