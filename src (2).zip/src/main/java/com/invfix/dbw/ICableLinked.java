package com.invfix.dbw;

import dan200.computercraft.api.network.wired.WiredNode;
import javax.annotation.Nullable;

/**
 * Что-то, что умеет присоединяться к чужой сети по кабелю DriveByWire.
 *
 * Реализуют двое: наш саблевел-компьютер, у которого узел проводной сети есть
 * изначально, и обычный компьютер ComputerCraft, которому узел добавляет миксин.
 * Благодаря общему интерфейсу им безразлично, кто на другом конце провода —
 * связываются любые два.
 */
public interface ICableLinked {

    /** Узел проводной сети, или null, если он ещё не создан. */
    @Nullable WiredNode invfix$cableNode();
}
