package com.invfix.dbw;

import dan200.computercraft.api.peripheral.PeripheralCapability;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

/**
 * Вешает периферию на хабы контроллеров DriveByWire.
 *
 * Хаб — обычный блок без блок-энтити, его сигналы хранит менеджер проводов по
 * координате. NeoForge позволяет регистрировать капабилити прямо на блок, и это
 * оказывается единственным вариантом: цеплять было бы не к чему, а лезть
 * миксином в чужой блок ради того, что и так доступно через публичный
 * {@code ControllerSignalStore}, незачем.
 *
 * Обычный проводной модем рядом с хабом теперь видит {@code controller_hub}, и
 * наша шина саблевела подхватывает его на постройке вообще без проводов.
 */
@EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD)
public final class DbwPeripheralRegistrar {

    private DbwPeripheralRegistrar() {}

    /**
     * Одна периферия на позицию.
     *
     * Провайдер капабилити зовётся на каждый запрос, а CC сравнивает периферии
     * между тиками, чтобы понять, не сменилось ли устройство. Раздавая новые
     * экземпляры, мы бы заставляли его переподключать хаб каждый тик — отсюда
     * кэш. Equals у периферии сравнивает позицию, так что это скорее экономия,
     * но она же держит поведение предсказуемым.
     */
    private static final Map<String, ControllerHubPeripheral> CACHE =
            Collections.synchronizedMap(new HashMap<>());

    /**
     * Блоки, чьи каналы провода мы отдаём компьютеру.
     *
     * Печатная машинка DriveByWire попала сюда не по родству, а по устройству:
     * её блок-сущность наследует Simulated'овскую, но зарегистрирована под своим
     * типом, поэтому периферию Simulated к ней никто не цепляет и компьютер её
     * не видит вовсе. При этом нажатия она честно пишет в каналы провода -
     * keyQ, keyE, keyF и так далее, пятнадцать на нажатие и ноль на отпускание.
     * Читать их тем же способом, что и каналы хаба контроллера, - самый прямой
     * путь к клавишам, и он не требует ни периферии от чужого мода, ни миксина.
     */
    private static final String[][] HUBS = {
            {"drivebywire", "controller_hub"},
            {"drivebywire", "tweaked_controller_hub"},
            {"drivebywiretypewriter", "typewriter_hub"},
    };

    @SubscribeEvent
    public static void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
        ModList mods = ModList.get();
        if (mods == null || !mods.isLoaded("computercraft")) return;

        for (String[] id : HUBS) {
            if (!mods.isLoaded(id[0])) continue;
            Block block = BuiltInRegistries.BLOCK.get(
                    ResourceLocation.fromNamespaceAndPath(id[0], id[1]));
            if (block == null || block == net.minecraft.world.level.block.Blocks.AIR) continue;
            event.registerBlock(PeripheralCapability.get(),
                    (level, pos, state, be, side) -> peripheral(level, pos), block);
        }
    }

    private static ControllerHubPeripheral peripheral(Level level, BlockPos pos) {
        String key = level.dimension().location() + "@" + pos.asLong();
        return CACHE.computeIfAbsent(key, k -> new ControllerHubPeripheral(level, pos));
    }
}