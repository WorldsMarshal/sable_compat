package com.invfix.dbw;

import edn.stratodonut.drivebywire.wire.WireNetworkManager;
import edn.stratodonut.drivebywire.wire.graph.WireNetworkNode;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.neoforged.fml.ModList;

/**
 * Читает, что подключено кабелем DriveByWire к данному блоку.
 *
 * Кабель у DBW направленный - у связи есть источник и приёмник, - но для нас
 * направление не значит ничего: игрок протянул провод от компьютера к трастеру
 * или от трастера к компьютеру, намерение одно и то же. Поэтому оба конца
 * смотрятся симметрично.
 *
 * Всё завёрнуто в проверку загруженного мода и в перехват ошибок: саблевел-
 * компьютер должен работать и без DBW, просто без этой возможности.
 */
public final class WireLinks {

    private WireLinks() {}

    private static Boolean available;

    public static boolean isAvailable() {
        Boolean cached = available;
        if (cached != null) return cached;
        ModList mods = ModList.get();
        boolean loaded = mods != null && mods.isLoaded("drivebywire");
        available = loaded;
        return loaded;
    }

    /**
     * Одна связь, увиденная с нашего конца.
     *
     * {@code face} — грань нашего блока, к которой игрок прицепил провод, и она
     * известна не всегда. У DBW приёмник связи хранит и позицию, и грань, а
     * источник — только позицию: начало провода вешается на блок целиком.
     * Поэтому если мы оказались источником, грани нет и её приходится выбирать
     * самим.
     */
    public record Link(BlockPos other, @Nullable Direction face) {}

    /**
     * Все связи кабеля, у которых один конец — эта позиция.
     *
     * Порядок сохраняется: список упорядочен, чтобы имена, которые компьютер
     * раздаёт подключённым устройствам, не прыгали между перезапусками.
     */
    public static List<Link> links(Level level, BlockPos pos) {
        List<Link> out = new ArrayList<>();
        if (!isAvailable() || level == null || level.isClientSide) return out;

        long me = pos.asLong();
        try {
            // getNetwork у DBW отдаёт сырой Map: дженерики в сигнатуре не
            // объявлены, поэтому тип восстанавливается здесь, а не выводится.
            @SuppressWarnings("unchecked")
            Map<Long, Map<String, Set<WireNetworkNode.WireNetworkSink>>> network =
                    (Map<Long, Map<String, Set<WireNetworkNode.WireNetworkSink>>>)
                            WireNetworkManager.get(level).getNetwork();
            for (Map.Entry<Long, Map<String, Set<WireNetworkNode.WireNetworkSink>>> entry : network.entrySet()) {
                long source = entry.getKey();
                for (Set<WireNetworkNode.WireNetworkSink> sinks : entry.getValue().values()) {
                    for (WireNetworkNode.WireNetworkSink sink : sinks) {
                        if (sink.position() == me) {
                            BlockPos other = BlockPos.of(source);
                            if (!other.equals(pos)) {
                                out.add(new Link(other, Direction.from3DDataValue(sink.direction())));
                            }
                        } else if (source == me) {
                            BlockPos other = BlockPos.of(sink.position());
                            if (!other.equals(pos)) out.add(new Link(other, null));
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
            // DBW переустанавливается или сеть перестраивается: считаем, что кабелей нет
        }
        return out;
    }

    /** Только позиции, для тех, кому грань безразлична. */
    public static Set<BlockPos> neighbours(Level level, BlockPos pos) {
        Set<BlockPos> out = new LinkedHashSet<>();
        for (Link link : links(level, pos)) out.add(link.other());
        return out;
    }
}
