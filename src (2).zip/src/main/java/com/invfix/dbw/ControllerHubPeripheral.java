package com.invfix.dbw;

import dan200.computercraft.api.lua.LuaException;
import dan200.computercraft.api.lua.LuaFunction;
import dan200.computercraft.api.peripheral.IPeripheral;
import edn.stratodonut.drivebywire.compat.ControllerSignalStore;
import edn.stratodonut.drivebywire.wire.MultiChannelWireSource;
import edn.stratodonut.drivebywire.wire.WireNetworkManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Хаб контроллера DriveByWire как периферия.
 *
 * Это аналог печатной машинки на стороне DBW: блок, за который садится игрок и
 * который гонит сигналы по каналам провода вместо редстоун-линка. Своего
 * блок-энтити у него нет — сигналы живут в {@code WireNetworkManager} по
 * позиции источника, — поэтому периферия вешается капабилити прямо на блок, без
 * BE и без миксина в чужой класс.
 *
 * Управление сырое и симметричное. {@code setSignal} пишет в канал ровно то же,
 * что пишет туда игрок с контроллером в руках, а {@code getSignals} читает, что
 * в каналах сейчас, кто бы их ни выставил. Отсюда и берётся ретрансляция в обе
 * стороны: компьютер может вести машину сам, может смотреть, как её ведёт
 * человек, и может подмешивать своё поверх ручного — приоритета нет ни у кого,
 * последняя запись побеждает, разруливать это программе.
 */
public class ControllerHubPeripheral implements IPeripheral {

    private final Level level;
    private final BlockPos pos;

    public ControllerHubPeripheral(Level level, BlockPos pos) {
        this.level = level;
        this.pos = pos.immutable();
    }

    @Override
    public String getType() {
        return "controller_hub";
    }

    @Override
    public boolean equals(@Nullable IPeripheral other) {
        return other instanceof ControllerHubPeripheral p
                && p.pos.equals(this.pos) && p.level == this.level;
    }

    @Override
    public Object getTarget() {
        return pos;
    }

    /** Каналы, которые этот хаб умеет вести. */
    @LuaFunction
    public final List<String> getChannels() {
        List<String> out = new ArrayList<>();
        BlockState state = level.getBlockState(pos);
        if (state.getBlock() instanceof MultiChannelWireSource source) {
            for (Object channel : source.wire$getChannels()) {
                out.add(String.valueOf(channel));
            }
        }
        return out;
    }

    /**
     * Что сейчас в каналах.
     *
     * Читает общее состояние источника, а не то, что писал компьютер, поэтому
     * нажатия живого игрока видны здесь так же, как свои собственные команды.
     */
    @LuaFunction
    public final Map<String, Object> getSignals() {
        Map<String, Object> out = new HashMap<>();
        Map<?, ?> signals = ControllerSignalStore.getSignals(level, pos);
        if (signals != null) {
            for (Map.Entry<?, ?> e : signals.entrySet()) {
                out.put(String.valueOf(e.getKey()), e.getValue());
            }
        }
        return out;
    }

    @LuaFunction
    public final int getSignal(String channel) {
        Object value = ControllerSignalStore.getSignals(level, pos).get(channel);
        return value instanceof Number n ? n.intValue() : 0;
    }

    /** Выставить канал. Диапазон тот же редстоуновский, 0..15. */
    @LuaFunction(mainThread = true)
    public final void setSignal(String channel, int value) throws LuaException {
        if (value < 0 || value > 15) throw new LuaException("signal must be 0..15");
        ControllerSignalStore.setSignal(level, pos, channel, value);
    }

    /** Погасить всё, что этот хаб вещает. */
    @LuaFunction(mainThread = true)
    public final void clearSignals() {
        ControllerSignalStore.clear(level, pos);
    }

    /**
     * Есть ли на канале хоть один потребитель.
     *
     * Полезно, чтобы программа не гоняла сигналы в никуда после того, как провод
     * перерезали.
     */
    @LuaFunction
    public final boolean isConnected(String channel) {
        return !ControllerSignalStore.getSignals(level, pos).isEmpty()
                || WireNetworkManager.get(level).getSourceSignals(pos).containsKey(channel);
    }
}
