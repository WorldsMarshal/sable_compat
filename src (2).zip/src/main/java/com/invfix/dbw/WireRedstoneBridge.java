package com.invfix.dbw;

import com.invfix.mixin.drivebywire.WireNetworkManagerAccessor;
import edn.stratodonut.drivebywire.wire.WireNetworkManager;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

/**
 * Делает кабель DriveByWire проводником обычного редстоуна.
 *
 * DBW почти всё для этого уже имел. Источником провода может быть любой блок —
 * для не-хаба клиент сам выбирает канал {@code world}, — а доставленный сигнал
 * складывается в узел, привязанный к грани блока-приёмника. Не работало две
 * вещи. Сигнал источника снимался ровно один раз, в момент создания связи, и
 * больше никогда: рычаг у начала кабеля можно было дёргать сколько угодно.
 * А доставленный сигнал видели только блоки, которые DBW пропатчил под себя, —
 * лампе, поршню и пыли он был не виден вовсе.
 *
 * Здесь закрыты обе половины: опрос источников каждый тик и подмешивание узла в
 * {@code Level.getSignal} миксином. Модель DBW при этом не трогается — мы
 * пользуемся её же публичным {@code trySetSignalAt} и её же узлами.
 *
 * Связь остаётся односторонней, и это следует из самой конструкции, а не из
 * отдельной проверки. Провод только вписывает сигнал в одну конкретную грань
 * приёмника и только слабым питанием; в обратную сторону по нему не идёт
 * ничего, потому что источник читается ванильным редстоуном, а не сетью.
 * Единственное место, где это могло сломаться, — обратная связь: после миксина
 * ванильный запрос сигнала уже включает вклад провода, и источник, стоящий рядом
 * со своим же приёмником, накрутил бы сам себя. Отсюда флаг {@code SAMPLING}:
 * пока снимается значение источника, провод из ответа исключён.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class WireRedstoneBridge {

    private WireRedstoneBridge() {}

    private static final String WORLD_CHANNEL = "world";

    /**
     * Мы сейчас читаем источник ванильными глазами.
     *
     * ThreadLocal, а не поле: серверный тик один, но {@code getSignal} зовут и с
     * других потоков, и глушить их вклад заодно было бы неверно.
     */
    private static final ThreadLocal<Boolean> SAMPLING = ThreadLocal.withInitial(() -> false);

    private static Boolean available;

    /**
     * Вклад провода в грань блока, или ноль. Зовётся из миксина на каждый запрос.
     *
     * Граней две, и обе нужны. Провод можно повесить на грань блока-источника,
     * смотрящую в сторону потребителя, а можно наоборот - на грань самого
     * потребителя, смотрящую назад к источнику. Первый случай я и учитывал,
     * второй пропускал, отчего редстоуновая пыль рядом с концом кабеля ничего не
     * получала.
     *
     * Формула взята дословно из {@code WireRedstoneCompat} самого DBW - там этот
     * же метод подменяет {@code Level.getSignal} через {@code @Redirect}, с той
     * же парой аргументов, и берёт максимум обеих граней.
     */
    public static int wireSignalAt(Level level, BlockPos pos, Direction direction) {
        if (SAMPLING.get()) return 0;
        if (!isAvailable()) return 0;
        if (level == null || level.isClientSide) return 0;
        try {
            WireNetworkManager manager = WireNetworkManager.get(level);
            int providerFace = manager.getSignalAt(pos, direction);
            int consumerFace = manager.getSignalAt(pos.relative(direction), direction.getOpposite());
            return Math.max(providerFace, consumerFace);
        } catch (Throwable t) {
            return 0;
        }
    }

    private static boolean isAvailable() {
        Boolean cached = available;
        if (cached != null) return cached;
        ModList mods = ModList.get();
        boolean loaded = mods != null && mods.isLoaded("drivebywire");
        available = loaded;
        return loaded;
    }

    /**
     * Снять редстоун со всех источников и разослать изменения.
     *
     * Опрос, а не событие соседа: DBW ограничивает домен 64 источниками, обход
     * такой карты стоит ничего, а ловить каждое изменение блока миксином значило
     * бы висеть на самом горячем пути в игре ради того же результата.
     */
    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (!isAvailable()) return;
        if (!(event.getLevel() instanceof ServerLevel level)) return;

        WireNetworkManager manager;
        Map<Long, Map<String, ?>> sinks;
        try {
            manager = WireNetworkManager.get(level);
            sinks = ((WireNetworkManagerAccessor) (Object) manager).invfix$sinks();
        } catch (Throwable t) {
            return;
        }
        if (sinks == null || sinks.isEmpty()) return;

        for (Map.Entry<Long, Map<String, ?>> entry : sinks.entrySet()) {
            Map<String, ?> perChannel = entry.getValue();
            if (perChannel == null || !perChannel.containsKey(WORLD_CHANNEL)) continue;

            BlockPos source = BlockPos.of(entry.getKey());
            if (!level.isLoaded(source)) continue;

            int now = sampleVanilla(level, source);
            Object stored = manager.getSourceSignals(source).get(WORLD_CHANNEL);
            int before = stored instanceof Number n ? n.intValue() : 0;
            if (now != before) {
                WireNetworkManager.trySetSignalAt(level, source, WORLD_CHANNEL, now);
            }
        }
    }

    /**
     * Редстоун у источника так, как его видела бы ванилла до нашего миксина.
     *
     * Без флага источник, у которого приёмник собственного кабеля стоит рядом,
     * прочитал бы свой же сигнал и защёлкнулся бы на пятнадцати навсегда.
     */
    private static int sampleVanilla(Level level, BlockPos source) {
        SAMPLING.set(true);
        try {
            return WireNetworkManager.computeWorldSignal(level, source);
        } catch (Throwable t) {
            return 0;
        } finally {
            SAMPLING.set(false);
        }
    }
}
