package com.invfix.dbw;

import dan200.computercraft.api.network.wired.WiredNode;
import dan200.computercraft.api.peripheral.IPeripheral;
import dan200.computercraft.api.peripheral.PeripheralCapability;
import dan200.computercraft.core.computer.ComputerSide;
import dan200.computercraft.shared.computer.core.ServerComputer;
import dan200.computercraft.shared.peripheral.modem.ModemState;
import dan200.computercraft.shared.peripheral.modem.wired.WiredModemElement;
import dan200.computercraft.shared.peripheral.modem.wired.WiredModemLocalPeripheral;
import dan200.computercraft.shared.peripheral.modem.wired.WiredModemPeripheral;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Кабель DriveByWire как проводная сеть ComputerCraft.
 *
 * Одна и та же машинерия нужна дважды: нашему саблевел-компьютеру она встроена
 * изначально, а обычному компьютеру ComputerCraft её добавляет миксин. Поэтому
 * она вынесена сюда целиком - узел, модем, набор соседей и правило, по которому
 * всё это пересобирается.
 *
 * Смысл в том, что провод, протянутый игроком, и есть заявление о намерении.
 * Ничего захватывать не нужно, ничего настраивать тоже: устройство на дальнем
 * конце появляется в сети компьютера само, а два компьютера, соединённые
 * проводом, оказываются в одной сети со всем, что из этого следует - rednet,
 * модемные сообщения, взаимный доступ к периферии.
 */
public class CableHub {

    /**
     * Грань по умолчанию.
     *
     * Используется только когда сторона неизвестна: у DBW приёмник связи хранит
     * грань, а источник — нет, начало провода вешается на блок целиком. Если
     * компьютер оказался источником, выбирать приходится нам, и задняя грань
     * взята потому, что на ней исторически и висит проводной модем.
     */
    public static final ComputerSide DEFAULT_SIDE = ComputerSide.BACK;

    private static final int REFRESH_INTERVAL = 20;

    private final BlockEntity owner;
    private final Function<Direction, ComputerSide> toLocalSide;
    private final Element element;
    private final WiredModemPeripheral modem;
    private final Set<WiredNode> linked = new HashSet<>();

    private int cooldown = 0;
    private @Nullable ComputerSide side;

    /**
     * @param toLocalSide перевод мировой грани в сторону компьютера; у блока
     *                    своя ориентация, и «восток» для мира и для компьютера —
     *                    разные вещи
     */
    public CableHub(BlockEntity owner, Function<Direction, ComputerSide> toLocalSide) {
        this.owner = owner;
        this.toLocalSide = toLocalSide;
        this.element = new Element(owner);
        this.modem = new Peripheral(element, owner);
        this.element.modem = this.modem;
    }

    public WiredNode node() {
        return element.getNode();
    }

    /** Сторона, занятая кабелем, или null, если провода нет. */
    public @Nullable ComputerSide side() {
        return side;
    }

    public boolean isActive() {
        return side != null;
    }

    /**
     * Пересобрать сеть и повесить модем, если есть за что.
     *
     * Пересчёт раз в секунду: провод не появляется каждый тик, а обход карты
     * связей DBW хоть и дёшев, но бесплатным не бывает. Сами вызовы периферии
     * это не задерживает - подключённое устройство компьютер держит объектом и
     * зовёт напрямую.
     */
    public void tick(@Nullable ServerComputer computer) {
        Level level = owner.getLevel();
        if (level == null || level.isClientSide || computer == null) return;

        // Грань переустанавливается только когда она действительно изменилась.
        //
        // Раньше здесь стоял безусловный setPeripheral каждый тик - я поставил
        // его, чтобы базовый класс не переписывал модем при изменении соседей.
        // Цена оказалась несоразмерной: каждый такой вызов берёт в серверном
        // потоке замок окружения компьютера и замок таблицы периферий, а поток
        // компьютера берёт те же замки в обратном порядке, когда ждёт задачу
        // главного потока. Рано или поздно они встречаются, и это уже не
        // просадка, а полная остановка: серверный поток ждёт поток компьютера,
        // поток компьютера ждёт серверный.
        //
        // Проверка через getPeripheral не берёт замков и стоит ничего. Если
        // базовый класс всё же снимет модем, следующий тик поставит его назад.
        if (--cooldown > 0) {
            if (side != null && computer.getPeripheral(side) != modem) {
                computer.setPeripheral(side, modem);
            }
            return;
        }
        cooldown = REFRESH_INTERVAL;

        List<WireLinks.Link> links = WireLinks.links(level, owner.getBlockPos());
        ComputerSide previous = side;
        side = links.isEmpty() ? null : chooseSide(links);

        if (previous != null && previous != side && computer.getPeripheral(previous) == modem) {
            computer.setPeripheral(previous, null);
        }

        if (side == null) {
            detachAll();
            return;
        }

        Set<BlockPos> wired = new LinkedHashSet<>();
        for (WireLinks.Link link : links) wired.add(link.other());

        // Тоже только при изменении: этот путь проходится раз в REFRESH_INTERVAL,
        // но замки те же самые.
        if (computer.getPeripheral(side) != modem) computer.setPeripheral(side, modem);
        node().updatePeripherals(collect(level, wired));
        relink(level, wired);
    }

    /**
     * На какой стороне показать модем.
     *
     * Там, куда игрок воткнул провод — как с проводным модемом, который вешается
     * на любую грань. Если проводов несколько, берётся первый с известной гранью
     * в порядке сторон света: сеть у всех всё равно общая, узел один, так что
     * выбор влияет только на то, под каким именем модем видно из Lua. Если грань
     * не известна ни у одного - компьютер везде оказался источником - остаётся
     * задняя.
     */
    private ComputerSide chooseSide(List<WireLinks.Link> links) {
        Direction best = null;
        for (WireLinks.Link link : links) {
            Direction face = link.face();
            if (face == null) continue;
            if (best == null || face.ordinal() < best.ordinal()) best = face;
        }
        return best == null ? DEFAULT_SIDE : toLocalSide.apply(best);
    }

    /**
     * Всё, до чего дотянулся провод.
     *
     * Имена в стиле CC - тип плюс индекс, - но индекс здесь считается заново на
     * каждой пересборке, а не запоминается: у кабеля на компьютере устройств
     * единицы, и порядок обхода стабилен, потому что набор соседей упорядочен.
     */
    private Map<String, IPeripheral> collect(Level level, Set<BlockPos> wired) {
        Map<String, IPeripheral> out = new LinkedHashMap<>();
        Map<String, Integer> counters = new HashMap<>();
        for (BlockPos pos : wired) {
            if (level.getBlockEntity(pos) instanceof ICableLinked) continue;  // это компьютер
            IPeripheral p = peripheralAt(level, pos);
            if (p == null) continue;
            int index = counters.merge(p.getType(), 1, Integer::sum) - 1;
            out.put(p.getType() + "_" + index, p);
        }
        return out;
    }

    private static @Nullable IPeripheral peripheralAt(Level level, BlockPos pos) {
        BlockEntity be = level.getBlockEntity(pos);
        for (Direction d : Direction.values()) {
            IPeripheral p = level.getCapability(PeripheralCapability.get(), pos, null, be, d);
            if (p != null) return p;
        }
        return null;
    }

    /** Связать узлы с компьютерами на другом конце провода. */
    private void relink(Level level, Set<BlockPos> wired) {
        Set<WiredNode> wanted = new HashSet<>();
        for (BlockPos pos : wired) {
            if (!(level.getBlockEntity(pos) instanceof ICableLinked other)) continue;
            WiredNode node = other.invfix$cableNode();
            if (node != null && node != node()) wanted.add(node);
        }
        for (WiredNode node : new HashSet<>(linked)) {
            if (!wanted.contains(node)) {
                node().disconnectFrom(node);
                linked.remove(node);
            }
        }
        for (WiredNode node : wanted) {
            if (linked.add(node)) node().connectTo(node);
        }
    }

    private void detachAll() {
        for (WiredNode node : linked) node().disconnectFrom(node);
        linked.clear();
        node().updatePeripherals(Map.of());
    }

    /** Снять всё при разрушении блока. */
    public void remove() {
        detachAll();
        node().remove();
        modem.removed();
    }

    // ---- внутренности ----

    private static final class Element extends WiredModemElement {

        private final BlockEntity owner;
        private @Nullable WiredModemPeripheral modem;

        Element(BlockEntity owner) {
            this.owner = owner;
        }

        @Override
        public Level getLevel() {
            return owner.getLevel();
        }

        @Override
        public Vec3 getPosition() {
            return Vec3.atCenterOf(owner.getBlockPos());
        }

        @Override
        protected void attachPeripheral(String name, IPeripheral peripheral) {
            if (modem != null) modem.attachPeripheral(name, peripheral);
        }

        @Override
        protected void detachPeripheral(String name) {
            if (modem != null) modem.detachPeripheral(name);
        }
    }

    private static final class Peripheral extends WiredModemPeripheral {

        private final BlockEntity owner;

        Peripheral(Element element, BlockEntity owner) {
            super(new ModemState(), element, new WiredModemLocalPeripheral(direction -> null), owner);
            this.owner = owner;
        }

        @Override
        public String getType() {
            return "wire_hub";
        }

        @Override
        public Vec3 getPosition() {
            return Vec3.atCenterOf(owner.getBlockPos());
        }
    }
}
