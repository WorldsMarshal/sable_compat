package com.invfix.theboys;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;

/**
 * Логика препарата V для расы Human. Вызывается из миксинов в The Boys
 * ({@code TheBoysHumanVMixins}). Сам класс НЕ ссылается на классы The Boys —
 * вся привязка к моду идёт через таргеты миксинов, поэтому без The Boys этот
 * код просто никогда не вызывается.
 *
 * Правила (только для §f§lHuman):
 *  Compound V (перманентный, «compound_v_syringe»):
 *    - 90%: 80 урона, шприц тратится, сил нет — игрок умирает;
 *    - 5%:  18 урона, сил нет, тошнота + отравление на 20 мин, шприц тратится;
 *    - 5%:  успех — отрабатывает стандартная выдача суперсилы The Boys.
 *    - Если игрок колет V, уже находясь под отравлением — гарантированная
 *      смерть, сил нет (100%).
 *  Temp V («compound_v_temp_syringe»):
 *    - работает всегда (стандартная механика The Boys);
 *    - по истечении накладывается Critical Poisoning на 20 мин (слепота/тошнота/
 *      отравление как дочерние эффекты, неснимаемо молоком);
 *    - пока висит Critical Poisoning — повторный Temp V вколоть нельзя.
 */
public final class HumanCompoundV {

    public static final String HUMAN_RACE = "\u00a7f\u00a7lHuman";

    private static final int TWENTY_MINUTES = 20 * 60 * 20; // 24000 тиков

    private static final float COMPOUND_V_LETHAL_DAMAGE = 80.0F;
    private static final float COMPOUND_V_SICK_DAMAGE   = 18.0F;

    private static final int CHANCE_DEATH   = 90; // [0, 90)
    private static final int CHANCE_SICK     = 95; // [90, 95)
    // [95, 100) — успех

    private HumanCompoundV() {}

    public static boolean isHuman(ServerPlayer player) {
        if (player == null) return false;
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            return HUMAN_RACE.equals(vars.Race);
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * @return true, если оригинальную инъекцию нужно ОТМЕНИТЬ (мы всё обработали
     *         сами). false — пропустить дальше стандартную механику The Boys.
     */
    public static boolean handleCompoundV(ServerPlayer target, ItemStack syringe) {
        // Под отравлением — 100% смерть, сил нет.
        if (target.hasEffect(MobEffects.POISON)) {
            killByV(target, syringe);
            target.sendSystemMessage(Component.literal(
                    "\u00a74Your body was too weak to take V now."));
            return true;
        }

        int roll = target.getRandom().nextInt(100);
        if (roll < CHANCE_DEATH) {
            killByV(target, syringe);
            target.sendSystemMessage(Component.literal(
                    "\u00a74The body rejected V. You're fucked."));
            return true;
        }
        if (roll < CHANCE_SICK) {
            consume(syringe);
            target.hurt(target.damageSources().magic(), COMPOUND_V_SICK_DAMAGE);
            target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, TWENTY_MINUTES, 0, false, true, true));
            target.addEffect(new MobEffectInstance(MobEffects.POISON, TWENTY_MINUTES, 0, false, true, true));
            target.sendSystemMessage(Component.literal(
                    "\u00a76The body rejected V. Blood is gushing from your ass."));
            return true;
        }
        // 5% — успех: даём отработать штатной выдаче суперсилы (не отменяем).
        return false;
    }

    /**
     * @return true, если инъекцию Temp V нужно ЗАБЛОКИРОВАТЬ (шприц не тратится).
     *         false — пропустить штатную механику Temp V.
     */
    public static boolean handleTempV(ServerPlayer target) {
        if (target.hasEffect(CompoundVRegistry.CRITICAL_POISONING)) {
            target.sendSystemMessage(Component.literal(
                    "\u00a74\n" + "You are not healthy enough to take Temp V."));
            return true;
        }
        return false;
    }

    /** Вызывается при распаде Temp V (любой путь истечения). */
    public static void onTempVExpired(ServerPlayer target) {
        if (!isHuman(target)) return;
        target.addEffect(new MobEffectInstance(
                CompoundVRegistry.CRITICAL_POISONING, TWENTY_MINUTES, 0, false, true, true));
        // Дочерние эффекты накидываются сразу, дальше их поддерживает сам эффект.
        target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, TWENTY_MINUTES, 0, false, true, true));
        target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, TWENTY_MINUTES, 0, false, true, true));
        target.addEffect(new MobEffectInstance(MobEffects.POISON, TWENTY_MINUTES, 0, false, true, true));
        target.sendSystemMessage(Component.literal(
                "\u00a74Temp V has disintegrated."));
    }

    private static void killByV(ServerPlayer target, ItemStack syringe) {
        consume(syringe);
        target.hurt(target.damageSources().magic(), COMPOUND_V_LETHAL_DAMAGE);
    }

    private static void consume(ItemStack syringe) {
        if (syringe != null && !syringe.isEmpty()) {
            syringe.shrink(1);
        }
    }
}