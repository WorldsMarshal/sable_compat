package com.invfix.theboys;

import com.invfix.humanlike.HumanLikeRaces;
import net.benniao.theboysmod.network.SkillSyncPacket;
import net.benniao.theboysmod.server.FleshStrengthHandler;
import net.benniao.theboysmod.skill.ModSkillAttachments;
import net.benniao.theboysmod.skill.ModSkills;
import net.benniao.theboysmod.skill.SkillData;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.attachment.AttachmentType;

/**
 * Перманентный Compound V для расы §a§lHuman(Born for V).
 *
 * В отличие от обычной выдачи The Boys (один случайный перм-скилл из
 * {@code permanentPool()}), эта раса при инъекции «compound_v_syringe»
 * получает фиксированный набор сил Хоумлендера, сразу на максимуме:
 *
 *   - Super Strength  (super_strength)  — уровень 5
 *   - Heat Vision     (laser_eye)       — уровень 5
 *   - Flesh Strength  (flesh_strength)  — уровень 5
 *   - Flight          (flight)          — без уровня
 *   - Super Vision    (super_vision)    — без уровня
 *
 * Класс НАПРЯМУЮ ссылается на классы The Boys, поэтому вызывается только из
 * миксина {@code TheBoysHumanVMixins}, который применяется лишь при наличии
 * мода (гейт в {@link com.invfix.compat.InvincibleIncMixinTransformer}).
 * Без The Boys этот класс никогда не загружается.
 */
public final class BornForVPowers {

    /** Уже под действием Temp V — перм. V не колется, отдаём ванильной логике. */
    public static final int RESULT_DEFER       = 0;
    /** Силы выданы/докачаны — шприц нужно потратить. */
    public static final int RESULT_GRANTED      = 1;
    /** Всё уже на максимуме — ничего не делаем, шприц НЕ тратим. */
    public static final int RESULT_ALREADY_MAXED = 2;

    private BornForVPowers() {}

    public static boolean isBornForV(ServerPlayer player) {
        if (player == null) return false;
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            return HumanLikeRaces.BORN_FOR_V.equals(vars.Race);
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Выдаёт/докачивает фиксированный набор Хоумлендера.
     *
     * @return один из RESULT_* — миксин по нему решает, тратить ли шприц
     *         и отменять ли штатную выдачу.
     */
    public static int grantHomelanderKit(ServerPlayer target) {
        SkillData data = (SkillData) target.getData(
                (AttachmentType) ModSkillAttachments.SKILL_DATA.get());

        // Активный Temp V — пусть штатная механика сама сообщит игроку.
        if (data.hasTemporarySkills()) {
            return RESULT_DEFER;
        }

        final String superStrength = ModSkills.SUPER_STRENGTH.getId().toString();
        final String laserEye      = ModSkills.LASER_EYE.getId().toString();
        final String fleshStrength = ModSkills.FLESH_STRENGTH.getId().toString();
        final String flight        = ModSkills.FLIGHT.getId().toString();
        final String superVision   = ModSkills.SUPER_VISION.getId().toString();

        boolean hadFleshStrength = data.hasSkill(fleshStrength);
        boolean changed = false;

        changed |= ensureSkill(data, superStrength);
        changed |= ensureSkill(data, laserEye);
        changed |= ensureSkill(data, fleshStrength);
        changed |= ensureSkill(data, flight);
        changed |= ensureSkill(data, superVision);

        // Уровневые силы всегда тянем на максимум.
        if (data.getSuperStrengthLevel() < 5) { data.setSuperStrengthLevel(5); changed = true; }
        if (data.getLaserEyeLevel()      < 5) { data.setLaserEyeLevel(5);      changed = true; }
        if (data.getFleshStrengthLevel() < 5) { data.setFleshStrengthLevel(5); changed = true; }

        if (!changed) {
            return RESULT_ALREADY_MAXED;
        }

        // При первой выдаче Flesh Strength заполняем щит здоровья (как штатная инъекция).
        boolean fillFleshStrength = !hadFleshStrength && data.hasSkill(fleshStrength);
        if (fillFleshStrength) {
            data.setShieldHp(data.getMaxShieldHp());
        }
        FleshStrengthHandler.refreshHealthModifier(target, data, fillFleshStrength);
        SkillSyncPacket.syncToClient(target);

        return RESULT_GRANTED;
    }

    private static boolean ensureSkill(SkillData data, String id) {
        if (data.hasSkill(id)) return false;
        data.addSkill(id);
        return true;
    }
}