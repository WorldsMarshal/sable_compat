package com.invfix.theboys;

import net.benniao.theboysmod.skill.ModSkillAttachments;
import net.benniao.theboysmod.skill.SkillData;
import net.benniao.theboysmod.skill.skills.FlightSkill;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.attachment.AttachmentType;

/**
 * Утилиты состояния скиллов The Boys.
 *
 * Класс напрямую ссылается на классы The Boys, поэтому вызывается только из
 * миксинов, применяемых под гейтом наличия мода
 * ({@link com.invfix.compat.InvincibleIncMixinTransformer}). Без The Boys не
 * загружается.
 */
public final class TheBoysSkillState {

    private TheBoysSkillState() {}

    /**
     * @return true, если у игрока есть хотя бы один ПЕРМАНЕНТНЫЙ скилл
     *         (временные скиллы Temp V не учитываются). Логика повторяет
     *         {@code InjectVPacket.hasAnyPermanentSkill}.
     */
    public static boolean hasPermanentSkill(ServerPlayer player) {
        if (player == null) return false;
        try {
            SkillData data = (SkillData) player.getData(
                    (AttachmentType) ModSkillAttachments.SKILL_DATA.get());
            for (Object skillId : data.getAllSkills()) {
                if (!data.isTemporarySkill((String) skillId)) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static final String FLIGHT_ID = FlightSkill.ID.toString();

    /** @return true, если у игрока есть навык полёта The Boys ({@code theboysmod:flight}). */
    public static boolean hasFlight(ServerPlayer player) {
        if (player == null) return false;
        try {
            SkillData data = (SkillData) player.getData(
                    (AttachmentType) ModSkillAttachments.SKILL_DATA.get());
            return data != null && data.hasSkill(FLIGHT_ID);
        } catch (Throwable ignored) {
        }
        return false;
    }
}