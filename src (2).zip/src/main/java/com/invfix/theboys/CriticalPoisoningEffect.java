package com.invfix.theboys;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;

/**
 * «Critical Poisoning» — фирменное отравление расы Human после распада Temp V.
 *
 * Особенности:
 *  - держится 20 минут; молоком и массовым {@code /effect clear <игрок>} НЕ
 *    снимается (блокируется в {@link CompoundVRegistry#onEffectRemove}). Снять
 *    можно только адресной командой {@code /effect clear <игрок>
 *    sable_compat:critical_poisoning} или дождавшись истечения;
 *  - поддерживает дочерние ванильные эффекты (слепота, тошнота, отравление):
 *    если игрок снимет их молоком — они вернутся, пока висит Critical Poisoning;
 *  - пока эффект активен, нельзя вколоть ещё один Temp V (проверка в
 *    {@code HumanCompoundV.handleTempV}).
 *
 * Дочерние эффекты привязаны к остатку родителя: пока Critical Poisoning жив,
 * они продлеваются до его срока и гаснут ровно вместе с ним. addEffect для них
 * вызывается только когда эффект отсутствует или короче родителя — без спама.
 */
public class CriticalPoisoningEffect extends MobEffect {

    public CriticalPoisoningEffect() {
        // Болотно-зелёный цвет частиц, ближе к ванильному яду.
        super(MobEffectCategory.HARMFUL, 0x3B5323);
    }

    @Override
    public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
        return true;
    }

    @Override
    public boolean applyEffectTick(LivingEntity entity, int amplifier) {
        if (!entity.level().isClientSide) {
            // Сколько ещё держится сам Critical Poisoning — к этому сроку
            // привязываем дочерние эффекты, чтобы они гасли ровно вместе с ним.
            MobEffectInstance self = entity.getEffect(CompoundVRegistry.CRITICAL_POISONING);
            int remaining = self != null ? self.getDuration() : 0;
            if (remaining > 0) {
                ensureChild(entity, MobEffects.BLINDNESS, remaining);
                ensureChild(entity, MobEffects.CONFUSION, remaining); // тошнота (Nausea)
                ensureChild(entity, MobEffects.POISON, remaining);
            }
        }
        return super.applyEffectTick(entity, amplifier);
    }

    /**
     * Докидывает дочерний эффект ТОЛЬКО если его нет. Эффект вешается на остаток
     * родителя и тикает с ним синхронно, поэтому простой проверки наличия хватает:
     * пока он висит — addEffect не вызывается (без засорения рантайма каждый тик).
     */
    private static void ensureChild(LivingEntity entity, net.minecraft.core.Holder<MobEffect> child, int duration) {
        if (entity.hasEffect(child)) {
            return;
        }
        entity.addEffect(new MobEffectInstance(child, duration, 0, false, true, true));
    }
}