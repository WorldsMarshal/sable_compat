package com.invfix.theboys;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffect;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.MobEffectEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Реестр кастомных эффектов, связанных с препаратом V (расса Human).
 * Регистрируется из главного класса мода {@code InvincibleFix}.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class CompoundVRegistry {

    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(Registries.MOB_EFFECT, "sable_compat");

    public static final DeferredHolder<MobEffect, CriticalPoisoningEffect> CRITICAL_POISONING =
            EFFECTS.register("critical_poisoning", CriticalPoisoningEffect::new);

    private CompoundVRegistry() {}

    public static void register(IEventBus modEventBus) {
        EFFECTS.register(modEventBus);
    }

    /**
     * Блокируем принудительное снятие Critical Poisoning (молоко, /effect clear
     * и т.п.). Естественное истечение по таймеру идёт через событие Expired и
     * этим обработчиком не затрагивается.
     */
    @SubscribeEvent
    public static void onEffectRemove(MobEffectEvent.Remove event) {
        var effect = event.getEffect();
        if (effect != null && effect.value() == CRITICAL_POISONING.value()) {
            event.setCanceled(true);
        }
    }
}