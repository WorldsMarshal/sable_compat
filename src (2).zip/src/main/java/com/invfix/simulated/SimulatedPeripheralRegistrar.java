package com.invfix.simulated;

import dan200.computercraft.api.ComputerCraftAPI;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;

/**
 * Подключает наши методы управления передачей к ComputerCraft.
 *
 * Через generic-источник, а не капабилити. Капабилити на блок одно, и его уже
 * занимает Simulated своим источником; наша периферия просто не подключалась, а
 * снаружи это выглядело как объект с правильным именем типа и половиной
 * пропавших методов. Generic-источники складываются, поэтому наши методы теперь
 * встают рядом с их собственными.
 */
@EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD)
public final class SimulatedPeripheralRegistrar {

    private SimulatedPeripheralRegistrar() {}

    @SubscribeEvent
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        ModList mods = ModList.get();
        if (mods == null || !mods.isLoaded("simulated") || !mods.isLoaded("computercraft")) return;
        event.enqueueWork(() ->
                ComputerCraftAPI.registerGenericSource(new AnalogTransmissionMethods()));
    }
}
