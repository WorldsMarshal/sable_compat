package com.invfix.simulated;

import dan200.computercraft.api.lua.LuaException;
import dan200.computercraft.api.lua.LuaFunction;
import dan200.computercraft.api.peripheral.GenericPeripheral;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.infrastructure.config.AllConfigs;
import dev.simulated_team.simulated.content.blocks.analog_transmission.AnalogTransmissionBlockEntity;

/**
 * Прямое задание оборотов умной передаче Simulated.
 *
 * Раньше это была отдельная периферия, повешенная капабилити на блок, и она не
 * работала ни разу: Simulated отдаёт для этого же блока свой generic-источник,
 * капабилити достаётся ему, а наша периферия остаётся неподключённой. Снаружи
 * это выглядело как пропавшие методы у объекта с правильным именем типа.
 *
 * Generic-источники, в отличие от капабилити, складываются: CC собирает методы
 * всех подходящих источников в одну периферию. Поэтому теперь наши методы
 * появляются рядом с их {@code setSignal} и {@code getRotationModifier}, ничего
 * не вытесняя.
 *
 * Зачем они, если {@code setSignal} уже есть. Их сигнал - это делитель на
 * шестнадцать ступеней, и что он сделает, зависит от того, какая сторона
 * ведущая: ту же ручку можно крутить и в замедление, и в ускорение. Здесь
 * задаются обороты ведомой стороны, а отношение считается само от фактической
 * скорости входа.
 *
 * Без {@code mainThread}: в этой сборке задачи главного потока для компьютера
 * на саблевеле не доносят результат, и помеченные им методы возвращают пустоту.
 * Запись здесь - одно присваивание в блок-сущность, так что обойтись без
 * очереди задач дешевле, чем зависеть от неё. И пока управляет компьютер, посторонний редстоун передача не
 * слушает - как маунт CBC или трастер, взятые под управление.
 */
public class AnalogTransmissionMethods implements GenericPeripheral {

    @Override
    public String id() {
        return "sable_compat:analog_transmission";
    }

    private static IAnalogTransmissionControl control(AnalogTransmissionBlockEntity be)
            throws LuaException {
        if (be instanceof IAnalogTransmissionControl c && !be.isRemoved()) return c;
        throw new LuaException("transmission is gone");
    }

    /**
     * Задать обороты ведомой стороне и забрать управление у редстоуна.
     *
     * Знак задаёт направление относительно ведущей стороны. Ноль останавливает
     * выход, не разрывая передачу - этим он отличается от сигнала 15, который
     * её просто отключает.
     */
    @LuaFunction
    public final void setSpeed(AnalogTransmissionBlockEntity be, double rpm) throws LuaException {
        control(be).invfix$setTargetSpeed((float) rpm);
    }

    /** Вернуть передачу под редстоун. */
    @LuaFunction
    public final void clearSpeed(AnalogTransmissionBlockEntity be) throws LuaException {
        control(be).invfix$setTargetSpeed(null);
    }

    /** Заданные обороты, или false, если управляет редстоун. */
    @LuaFunction
    public final Object getTargetSpeed(AnalogTransmissionBlockEntity be) throws LuaException {
        Float target = control(be).invfix$targetSpeed();
        return target == null ? Boolean.FALSE : target;
    }

    @LuaFunction
    public final boolean isComputerControlled(AnalogTransmissionBlockEntity be) throws LuaException {
        return control(be).invfix$targetSpeed() != null;
    }

    /** Обороты ведущей стороны — той, откуда пришло вращение. */
    @LuaFunction
    public final double getInputSpeed(AnalogTransmissionBlockEntity be) throws LuaException {
        IAnalogTransmissionControl c = control(be);
        return c.invfix$shaftDriven() ? c.invfix$cogSpeed() : c.invfix$shaftSpeed();
    }

    /** Обороты ведомой стороны — той, которой командует компьютер. */
    @LuaFunction
    public final double getDrivenSpeed(AnalogTransmissionBlockEntity be) throws LuaException {
        IAnalogTransmissionControl c = control(be);
        return c.invfix$shaftDriven() ? c.invfix$shaftSpeed() : c.invfix$cogSpeed();
    }

    /** Какая сторона сейчас ведомая: "shaft" или "cog". */
    @LuaFunction
    public final String getDrivenSide(AnalogTransmissionBlockEntity be) throws LuaException {
        return control(be).invfix$shaftDriven() ? "shaft" : "cog";
    }

    @LuaFunction
    public final double getShaftSpeed(AnalogTransmissionBlockEntity be) throws LuaException {
        return control(be).invfix$shaftSpeed();
    }

    @LuaFunction
    public final double getCogSpeed(AnalogTransmissionBlockEntity be) throws LuaException {
        return control(be).invfix$cogSpeed();
    }

    /** Потолок оборотов из конфига Create. Выше не выставится. */
    @LuaFunction
    public final int getMaxSpeed(AnalogTransmissionBlockEntity be) {
        return AllConfigs.server().kinetics.maxRotationSpeed.get();
    }

    /**
     * Не хватает ли мощности.
     *
     * Ровно то, обо что упирается разгон: обороты выставить можно любые до
     * потолка, но тянуть их должно ведущее вращение.
     */
    @LuaFunction
    public final boolean isUnderpowered(AnalogTransmissionBlockEntity be) {
        return be instanceof KineticBlockEntity kinetic && kinetic.isOverStressed();
    }
}