package com.invfix.simulated;

import javax.annotation.Nullable;

/**
 * Компьютерное управление умной передачей Simulated.
 *
 * Реализуется миксином на {@code AnalogTransmissionBlockEntity}; периферия
 * работает только через этот интерфейс и о самом классе передачи ничего не знает.
 */
public interface IAnalogTransmissionControl {

    /**
     * Заданные обороты ведомой стороны, или null, если передачей по-прежнему
     * управляет редстоун.
     */
    @Nullable Float invfix$targetSpeed();

    /** Передать управление компьютеру, или вернуть редстоуну, передав null. */
    void invfix$setTargetSpeed(@Nullable Float rpm);

    /** Обороты вала. */
    float invfix$shaftSpeed();

    /** Обороты шестерни. */
    float invfix$cogSpeed();

    /** Есть ли на валу источник вращения. Если нет — ведущая сторона шестерня. */
    boolean invfix$shaftDriven();
}
