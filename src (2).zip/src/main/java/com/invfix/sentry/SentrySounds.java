package com.invfix.sentry;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Звук включения The Whole Sentry Power — star_impact из The Shooting Star как есть. */
public final class SentrySounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, "sable_compat");

    public static final DeferredHolder<SoundEvent, SoundEvent> ACTIVATE = SOUNDS.register("sentry_activate",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("sable_compat", "sentry_activate")));

    private SentrySounds() {}
}
