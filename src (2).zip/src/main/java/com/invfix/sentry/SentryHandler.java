package com.invfix.sentry;

import com.invfix.altrumite.AltrumiteRace;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The Whole Sentry Power — режим Metroman (Alien(Metroman)), LVL 750.
 *
 * Тумблер: нажатие клавиши способности включает, следующее — выключает. Без
 * лимита по времени. При включении от игрока — ослепительная вспышка с ударной
 * волной; пока включён — белая аура и мелкие молнии по телу (клиент,
 * SentryClient / SentryFx).
 *
 * Бафы, пока режим включён:
 *  - весь урон игрока ×{@link #DAMAGE_MULT} — любые атаки и способности,
 *    родные Invincible тоже;
 *  - разрушения наших способностей ×{@link #DESTRUCTION_MULT} (Neutron Beam,
 *    Dismantle, Energy Blast, Kinetic Strike, кратеры ударов с Attackpwr > 500);
 *    Heat Disruption — кратно: радиус и длина ×2, луч толще, урон ещё ×2, и
 *    палитра бело-голубая, как у нейтронной звезды;
 *  - в визуал наших способностей добавляются белые молнии.
 *
 * Состояние не сохраняется: смерть, выход, смена измерения выключают режим и
 * всем рассылается «выключен» — ничего не остаётся висеть.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class SentryHandler {

    public static final String ABILITY = "§f§lThe Whole Sentry Power";
    public static final int LVL_REQUIRED = 750;
    public static final float DAMAGE_MULT = 2.0F;
    public static final double DESTRUCTION_MULT = 1.5;

    private static final Set<UUID> ACTIVE = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Boolean> KEY_DOWN = new ConcurrentHashMap<>();

    private SentryHandler() {}

    public static boolean isActive(Entity e) {
        return e instanceof Player && ACTIVE.contains(e.getUUID());
    }

    /** Множитель разрушений способности этого игрока (1 вне режима). */
    public static double destruction(Entity e) {
        return isActive(e) ? DESTRUCTION_MULT : 1.0;
    }

    // ── клавиша (AbilityCallProcedureMixin, каждый тик) ────────────────────

    public static void handleKeyState(ServerPlayer player, boolean pressed) {
        boolean was = Boolean.TRUE.equals(KEY_DOWN.put(player.getUUID(), pressed));
        if (!pressed || was) return;
        if (ACTIVE.contains(player.getUUID())) {
            set(player, false, false);
            return;
        }
        try {
            InvincibleIncModVariables.PlayerVariables v = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (!AltrumiteRace.isAltrumite(v.Race) || v.Lvl < LVL_REQUIRED) return;
        } catch (Exception e) {
            return;
        }
        set(player, true, true);
    }

    private static void set(ServerPlayer player, boolean on, boolean burst) {
        if (on) ACTIVE.add(player.getUUID());
        else ACTIVE.remove(player.getUUID());
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new SentryPacket(player.getId(), on, burst));
        if (on && burst && player.level() instanceof ServerLevel level) {
            Vec3 p = player.position();
            level.playSound(null, p.x, p.y + 1.0, p.z, SentrySounds.ACTIVATE.get(), SoundSource.PLAYERS, 8.0F, 1.0F);
        }
    }

    /** Выключить без вспышки и без звука (смерть, выход и т.п.). */
    private static void off(Player player) {
        KEY_DOWN.remove(player.getUUID());
        if (!ACTIVE.remove(player.getUUID())) return;
        if (player instanceof ServerPlayer sp) {
            PacketDistributor.sendToPlayersTrackingEntityAndSelf(sp, new SentryPacket(sp.getId(), false, false));
        }
    }

    // ── урон ×2 ────────────────────────────────────────────────────────────
    // LOW: после того как родной AttackDuraProcedure (NORMAL) выставил сырой урон,
    // до смягчения щитом (ViltrumiteImmunityHandler, LOWEST).
    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (event.getEntity().level().isClientSide()) return;
        Entity src = event.getSource().getEntity();
        if (src != null && src != event.getEntity() && isActive(src)) {
            event.setAmount(event.getAmount() * DAMAGE_MULT);
        }
    }

    // ── уборка ─────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof Player p && !p.level().isClientSide()) off(p);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        off(event.getEntity());
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        off(event.getEntity());
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        off(event.getEntity());
    }

    /** Кто только что увидел игрока в режиме — узнаёт о нём (без вспышки). */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getEntity() instanceof ServerPlayer viewer && isActive(event.getTarget())) {
            PacketDistributor.sendToPlayer(viewer, new SentryPacket(event.getTarget().getId(), true, false));
        }
    }
}
