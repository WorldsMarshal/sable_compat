package com.invfix.sentry;

import com.invfix.sentry.client.SentryClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Сервер → клиенты: игрок playerId в режиме Sentry (active) или нет; burst — вспышка включения. */
public record SentryPacket(int playerId, boolean active, boolean burst) implements CustomPacketPayload {

    public static final Type<SentryPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "sentry"));

    public static final StreamCodec<FriendlyByteBuf, SentryPacket> STREAM_CODEC = StreamCodec.of(
            (buf, m) -> { buf.writeVarInt(m.playerId()); buf.writeBoolean(m.active()); buf.writeBoolean(m.burst()); },
            buf -> new SentryPacket(buf.readVarInt(), buf.readBoolean(), buf.readBoolean()));

    @Override
    public Type<SentryPacket> type() {
        return TYPE;
    }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(SentryPacket p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> SentryClient.set(p.playerId, p.active, p.burst));
    }
}
