package com.invfix.sentry;

import com.invfix.altrumite.AltrumiteRace;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Клиент → Сервер: выбрать The Whole Sentry Power как текущую способность (для назначения в слот). */
public record SentryAssignPacket(int x, int y, int z) implements CustomPacketPayload {

    public static final Type<SentryAssignPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "sentry_assign"));

    public static final StreamCodec<FriendlyByteBuf, SentryAssignPacket> STREAM_CODEC = StreamCodec.of(
            (buf, m) -> { buf.writeInt(m.x()); buf.writeInt(m.y()); buf.writeInt(m.z()); },
            buf -> new SentryAssignPacket(buf.readInt(), buf.readInt(), buf.readInt()));

    @Override public Type<SentryAssignPacket> type() { return TYPE; }

    public static void handleServer(SentryAssignPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer player)) return;
            try {
                InvincibleIncModVariables.PlayerVariables vars =
                        player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                if (!AltrumiteRace.isAltrumite(vars.Race) || vars.Lvl < SentryHandler.LVL_REQUIRED) return;
                vars.AbilitySet = SentryHandler.ABILITY;
                vars.abilityDescription = SentryHandler.ABILITY + " | LVL:" + SentryHandler.LVL_REQUIRED
                        + " | Режим (тумблер)";
                vars.markSyncDirty();
            } catch (Exception ignored) {}
        });
    }
}
