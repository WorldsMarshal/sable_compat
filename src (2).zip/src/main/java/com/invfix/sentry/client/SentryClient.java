package com.invfix.sentry.client;

import com.invfix.fx.FxManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Клиент The Whole Sentry Power: кто сейчас в режиме (аура — SentryFx), вспышка
 * включения (SentryBurstFx) и белые молнии в местах, куда бьют наши способности
 * игрока в режиме ({@link #arcsIfSentry}).
 *
 * Аура гаснет за 0.4 с после выключения; игрок, которого больше нет в мире или
 * который умер, из списка убирается сам — ничего не остаётся висеть.
 */
@OnlyIn(Dist.CLIENT)
public final class SentryClient {

    /** Затухание ауры после выключения, тиков. */
    static final int FADE_OUT = 8;
    /** Разгорание ауры после включения, тиков. */
    static final int FADE_IN = 6;

    /** id → тик клиента включения. */
    static final Map<Integer, Long> ACTIVE = new ConcurrentHashMap<>();
    /** id → сколько тиков ещё гаснуть. */
    static final Map<Integer, Integer> FADING = new ConcurrentHashMap<>();
    static long ticks;

    private SentryClient() {}

    public static void set(int playerId, boolean active, boolean burst) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        if (active) {
            FADING.remove(playerId);
            ACTIVE.putIfAbsent(playerId, burst ? ticks : ticks - FADE_IN);
            if (burst && level.getEntity(playerId) instanceof LivingEntity le) {
                SentryBurstFx.activation(level, le);
            }
            SentryFx.keepAlive(level);
        } else if (ACTIVE.remove(playerId) != null) {
            FADING.put(playerId, FADE_OUT);
        }
    }

    public static boolean isActive(int playerId) {
        return ACTIVE.containsKey(playerId);
    }

    /** Наши способности: если ударил игрок в режиме — белые молнии в точке удара. */
    public static void arcsIfSentry(int casterId, Vec3 at, float radius) {
        if (!isActive(casterId)) return;
        ClientLevel level = Minecraft.getInstance().level;
        if (level != null) SentryBurstFx.arcs(level, at, radius, 20);
    }

    /** Сила ауры 0..1 с учётом разгорания и затухания. */
    static float strength(int id, float partial) {
        Long on = ACTIVE.get(id);
        if (on != null) return Math.min(1.0F, (ticks - on + partial) / FADE_IN);
        Integer left = FADING.get(id);
        return left == null ? 0.0F : Math.max(0.0F, (left - partial) / FADE_OUT);
    }

    private static void reset() {
        ACTIVE.clear();
        FADING.clear();
    }

    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
    public static final class GameBus {

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            ClientLevel level = mc.level;
            if (level == null) {
                reset();
                return;
            }
            if (mc.isPaused()) return;
            ticks++;
            // кого нет в мире или кто умер — аура гаснет сразу, без хвостов
            ACTIVE.keySet().removeIf(id -> {
                Entity e = level.getEntity(id);
                return !(e instanceof LivingEntity le) || !le.isAlive() || le.isRemoved();
            });
            FADING.replaceAll((id, t) -> t - 1);
            FADING.entrySet().removeIf(e -> e.getValue() <= 0 || !(level.getEntity(e.getKey()) instanceof LivingEntity));
            if (!ACTIVE.isEmpty() || !FADING.isEmpty()) SentryFx.keepAlive(level);
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            reset();
        }
    }

    static Vec3 camera() {
        return FxManager.camera();
    }
}
