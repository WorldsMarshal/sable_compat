package com.invfix.sentry.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Аура режима Sentry (sentry.fsh, mode 0) на всех игроках в режиме. Один эффект на клиент. */
@OnlyIn(Dist.CLIENT)
public final class SentryFx extends FxEffect {

    private static final int LINGER = 4;
    private static SentryFx instance;

    private final ClientLevel level;
    private int idle;

    private SentryFx(ClientLevel level) {
        this.level = level;
    }

    static void keepAlive(ClientLevel level) {
        if (instance == null || instance.finished() || instance.level != level) {
            instance = new SentryFx(level);
            FxManager.add(instance);
        }
        instance.idle = 0;
    }

    @Override
    protected void onTick(Minecraft minecraft, ClientLevel level, int age) {
        idle++;
    }

    @Override
    protected int duration() {
        return Integer.MAX_VALUE;
    }

    @Override
    public boolean finished() {
        return idle > LINGER || Minecraft.getInstance().level != level;
    }

    @Override
    protected void onRemoved() {
        if (instance == this) instance = null;
    }

    @Override
    public Vec3 focus() {
        return FxManager.camera();
    }

    @Override
    public double range() {
        return Double.MAX_VALUE;
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        Minecraft mc = frame.minecraft();
        if (mc.level == null) return;
        float partial = frame.partial();
        float time = (age + partial) / 20.0F;
        Set<Integer> ids = new HashSet<>(SentryClient.ACTIVE.keySet());
        ids.addAll(SentryClient.FADING.keySet());
        for (int id : ids) {
            Entity e = mc.level.getEntity(id);
            if (!(e instanceof LivingEntity le) || !le.isAlive()) continue;
            float k = SentryClient.strength(id, partial);
            if (k <= 0.001F) continue;
            Vec3 feet = e.getPosition(partial);
            if (feet.distanceTo(frame.camera()) > 256.0) continue;
            boolean own = e == mc.player && mc.options.getCameraType().isFirstPerson();
            Vec3 f = frame.rel(feet);
            float h = e.getBbHeight();
            float w = e.getBbWidth();
            float seed = (id * 0.61803398875F) % 1.0F;
            float ownF = own ? 1.0F : 0.0F;
            Vec3 cam = frame.camera();
            float ox = (float) (cam.x - 2048.0 * Math.floor(cam.x / 2048.0));
            float oy = (float) (cam.y - 2048.0 * Math.floor(cam.y / 2048.0));
            float oz = (float) (cam.z - 2048.0 * Math.floor(cam.z / 2048.0));
            out.add(new FxPass("sentry", u -> {
                u.v3("Target", f);
                u.f3("Origin", ox, oy, oz);
                u.f4("P0", h, w, time, seed);
                u.f4("P1", k, ownF, 0.7F, 0.0F);
            }));
        }
    }

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        Minecraft mc = frame.minecraft();
        if (mc.player == null) return;
        float k = SentryClient.strength(mc.player.getId(), frame.partial());
        if (k <= 0.001F) return;
        // сам в режиме: мир чуть светлее и мягко светится
        screen.bloom = Math.max(screen.bloom, 0.45F * k);
        screen.bloomRadius = Math.max(screen.bloomRadius, 1.2F);
    }
}
