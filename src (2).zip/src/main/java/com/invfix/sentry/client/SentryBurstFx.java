package com.invfix.sentry.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.List;

/**
 * Вспышки режима Sentry:
 *  - включение: ослепительная бело-голубая вспышка от игрока — светящийся шар
 *    ионизированного воздуха и ударная волна (shockwave.fsh, кольца, сфера,
 *    волна пыли), молнии во все стороны (sentry.fsh, mode 1), белые импакт-кадры
 *    в 64 блоках, вспышка экрана, тряска;
 *  - молнии в точке удара наших способностей игрока в режиме — только mode 1.
 */
@OnlyIn(Dist.CLIENT)
public final class SentryBurstFx extends FxEffect {

    private static final double FRAMES_RANGE = 64.0;

    private final ClientLevel level;
    private final Vec3 center;
    private final float radius;
    private final int life;
    private final boolean activation;
    private final boolean frames;
    private final float seed;

    private SentryBurstFx(ClientLevel level, Vec3 center, float radius, int life, boolean activation, boolean frames) {
        this.level = level;
        this.center = center;
        this.radius = radius;
        this.life = life;
        this.activation = activation;
        this.frames = frames;
        this.seed = (float) ((Mth.getSeed((int) center.x, (int) center.y, (int) center.z) & 0xFFFFL) / 65535.0);
    }

    static void activation(ClientLevel level, LivingEntity e) {
        Vec3 c = e.position().add(0.0, e.getBbHeight() * 0.55, 0.0);
        boolean frames = FxManager.camera().distanceTo(c) <= FRAMES_RANGE;
        FxManager.add(new SentryBurstFx(level, c, 5.0F, 40, true, frames));
        FxManager.shake(c, 0.6F, 96.0);
    }

    static void arcs(ClientLevel level, Vec3 at, float radius, int life) {
        FxManager.add(new SentryBurstFx(level, at, Math.max(1.5F, radius), life, false, false));
    }

    @Override
    protected int duration() {
        return life;
    }

    @Override
    public boolean finished() {
        return super.finished() || Minecraft.getInstance().level != level;
    }

    @Override
    public Vec3 focus() {
        return center;
    }

    @Override
    public double range() {
        return 400.0;
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        float t = ticks(frame);
        float s = t / 20.0F;
        float k = 1.0F - smooth((t - life * 0.5F) / (life * 0.5F));
        if (k <= 0.001F) return;
        Vec3 c = frame.rel(center);
        Vec3 cam = frame.camera();
        float ox = (float) (cam.x - 2048.0 * Math.floor(cam.x / 2048.0));
        float oy = (float) (cam.y - 2048.0 * Math.floor(cam.y / 2048.0));
        float oz = (float) (cam.z - 2048.0 * Math.floor(cam.z / 2048.0));
        float sd = seed;
        float r = radius;

        if (activation) {
            // ослепительный шар света и ударная волна — тот же shockwave.fsh, что у тяжёлых ударов
            float ring = 2.0F + 22.0F * (1.0F - (float) Math.exp(-s / 0.25F));
            float shell = 3.0F + s * 60.0F;
            float ground = 2.0F + 34.0F * (1.0F - (float) Math.exp(-s / 0.45F));
            float band = 2.0F + s * 3.5F;
            float flash = 2.5F * (float) Math.exp(-s / 0.1F);
            float kw = 1.0F - smooth((s - 0.7F) / 1.0F);
            float glowR = 1.0F + 3.5F * (1.0F - (float) Math.exp(-s / 0.06F));
            float glowI = 3.5F * (1.0F - smooth((s - 0.15F) / 0.5F)) + 0.6F * (float) Math.exp(-s / 0.08F);
            float front = 1.5F + 14.0F * (1.0F - (float) Math.exp(-s / 0.22F));
            float travel = 0.0F;
            out.add(new FxPass("shockwave", u -> {
                u.v3("Target", c);
                u.v3("Facing", new Vec3(0.0, 1.0, 0.0));
                u.f3("Origin", ox, oy, oz);
                u.f4("P0", s, 2.0F, sd, kw);
                u.f4("P1", ring, shell, ground, flash);
                u.f4("P2", 0.0F, 0.6F + s, band, travel);
                u.f4("P3", glowR, glowI, front, 0.0F);
            }));
        }
        float time = t / 20.0F;
        out.add(new FxPass("sentry", u -> {
            u.v3("Target", c);
            u.f3("Origin", ox, oy, oz);
            u.f4("P0", r, 0.0F, time, sd);
            u.f4("P1", k, 0.0F, 1.0F, 1.0F);
        }));
    }

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        if (!activation) return;
        float s = ticks(frame) / 20.0F;
        float near = (float) Mth.clamp(1.0 - frame.camera().distanceTo(center) / 160.0, 0.2, 1.0);
        if (frames) impactSequence(screen, s, center, 1.0F, 0.05F, 36, 37, 36, 37);
        if (s >= 0.2F) screen.addFlash(0xF2F7FF, 1.6F * (float) Math.exp(-(s - 0.2F) / 0.2F) * near);
        float hold = window(s, 0.0F, 0.03F, 0.6F, 1.8F);
        screen.bloom = Math.max(screen.bloom, 1.2F * hold);
        screen.bloomRadius = Math.max(screen.bloomRadius, 1.0F + 1.2F * hold);
        screen.aberration = Math.max(screen.aberration, window(s, 0.0F, 0.03F, 0.3F, 1.0F) * 0.8F * near);
        screen.zoomBlur = Math.max(screen.zoomBlur, window(s, 0.0F, 0.03F, 0.25F, 0.9F) * 0.45F * near);
    }
}
