package com.invfix.ammo;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.ArrayList;
import java.util.List;

/**
 * Промежуточные предметы для крафта боеприпасов Point Blank через системы
 * Create / Create Big Cannons (этап «ребаланс PointBlank»).
 *
 * Регистрируются под неймспейсом {@code sable_compat}, поэтому ассеты лежат в
 * {@code assets/sable_compat/...}. Предметы существуют всегда, но используются
 * только в рецептах, включающихся по условию create + createbigcannons +
 * pointblank.
 *
 * Текстуры намеренно общие на тир: одна гильза/сердечник на калибр-группу, а
 * все «incomplete_*» одного тира ссылаются на одну текстуру. Перечень общих
 * текстур см. в моделях {@code assets/sable_compat/models/item}.
 *
 * Подключается из {@link com.invfix.InvincibleFix} через {@link #register(IEventBus)}.
 */
public final class AmmoForgeItems {

    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems("sable_compat");

    private static final List<DeferredItem<Item>> TAB_ENTRIES = new ArrayList<>();

    private static DeferredItem<Item> simple(String name) {
        DeferredItem<Item> item = ITEMS.registerSimpleItem(name, new Item.Properties());
        TAB_ENTRIES.add(item);
        return item;
    }

    // ===== Общие компоненты =====
    public static final DeferredItem<Item> PRIMER = simple("primer");
    public static final DeferredItem<Item> BULLET_CORE = simple("bullet_core");
    public static final DeferredItem<Item> AP_CORE = simple("ap_core");

    // ===== Гильзы / корпуса =====
    public static final DeferredItem<Item> PISTOL_CASING = simple("pistol_casing");
    public static final DeferredItem<Item> RIFLE_CASING = simple("rifle_casing");
    public static final DeferredItem<Item> HEAVY_CASING = simple("heavy_casing");
    public static final DeferredItem<Item> SHOTGUN_HULL = simple("shotgun_hull");
    public static final DeferredItem<Item> GRENADE_SHELL = simple("grenade_shell");

    // ===== Спец-компоненты =====
    public static final DeferredItem<Item> SHOT_LOAD = simple("shot_load");
    public static final DeferredItem<Item> LASER_CELL = simple("laser_cell");
    public static final DeferredItem<Item> ROCKET_MOTOR = simple("rocket_motor");
    public static final DeferredItem<Item> HE_WARHEAD = simple("he_warhead");
    public static final DeferredItem<Item> HEAT_WARHEAD = simple("heat_warhead");
    public static final DeferredItem<Item> GUIDANCE_UNIT = simple("guidance_unit");

    // ===== «Незавершённые» (transitional для sequenced_assembly) =====
    // Пистолетный тир (текстура incomplete_pistol_round)
    public static final DeferredItem<Item> INCOMPLETE_9MM = simple("incomplete_9mm");
    public static final DeferredItem<Item> INCOMPLETE_357 = simple("incomplete_357");
    public static final DeferredItem<Item> INCOMPLETE_45ACP = simple("incomplete_45acp");
    public static final DeferredItem<Item> INCOMPLETE_50AE = simple("incomplete_50ae");
    public static final DeferredItem<Item> INCOMPLETE_57 = simple("incomplete_57");
    public static final DeferredItem<Item> INCOMPLETE_46 = simple("incomplete_46");
    // Винтовочные тиры (текстура incomplete_rifle_round)
    public static final DeferredItem<Item> INCOMPLETE_556 = simple("incomplete_556");
    public static final DeferredItem<Item> INCOMPLETE_545 = simple("incomplete_545");
    public static final DeferredItem<Item> INCOMPLETE_68 = simple("incomplete_68");
    public static final DeferredItem<Item> INCOMPLETE_762 = simple("incomplete_762");
    public static final DeferredItem<Item> INCOMPLETE_762X51 = simple("incomplete_762x51");
    public static final DeferredItem<Item> INCOMPLETE_338LAPUA = simple("incomplete_338lapua");
    // Тяжёлый (incomplete_heavy_round)
    public static final DeferredItem<Item> INCOMPLETE_50BMG = simple("incomplete_50bmg");
    // Дробовик / энергия
    public static final DeferredItem<Item> INCOMPLETE_12GAUGE = simple("incomplete_12gauge");
    public static final DeferredItem<Item> INCOMPLETE_LASERCHARGE = simple("incomplete_lasercharge");
    // Снаряды
    public static final DeferredItem<Item> INCOMPLETE_GRENADE20MM = simple("incomplete_grenade20mm");
    public static final DeferredItem<Item> INCOMPLETE_GRENADE40MM = simple("incomplete_grenade40mm");
    public static final DeferredItem<Item> INCOMPLETE_AT4 = simple("incomplete_at4");
    public static final DeferredItem<Item> INCOMPLETE_SMAW = simple("incomplete_smaw");
    public static final DeferredItem<Item> INCOMPLETE_JAVELIN = simple("incomplete_javelin");

    private AmmoForgeItems() {}

    public static void register(IEventBus modEventBus) {
        ITEMS.register(modEventBus);
        modEventBus.addListener(AmmoForgeItems::onBuildCreativeTabs);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            for (DeferredItem<Item> item : TAB_ENTRIES) {
                event.accept(item);
            }
        }
    }
}
