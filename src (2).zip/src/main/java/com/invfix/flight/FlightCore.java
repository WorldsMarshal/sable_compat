package com.invfix.flight;

import dan200.computercraft.api.lua.LuaException;
import dev.propulsionteam.propulsionsimulated.PropulsionConfig;
import dev.propulsionteam.propulsionsimulated.content.thruster.AbstractThrusterBlockEntity;
import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.api.physics.handle.RigidBodyHandle;
import dev.ryanhcode.sable.api.physics.mass.MassData;
import dev.ryanhcode.sable.physics.config.dimension_physics.DimensionPhysicsData;
import dev.ryanhcode.sable.api.sublevel.SubLevelContainer;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.sublevel.SubLevel;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3dc;
import org.joml.Quaterniond;
import org.joml.Vector3d;
import org.joml.Vector3dc;

/**
 * Everything a flight computer needs, attached to any Create Propulsion
 * thruster.
 *
 * The logic lives here as plain statics; the @LuaFunction wrappers are added to
 * Create Propulsion's own peripheral class by mixin.
 *
 * That indirection is forced. CC resolves a block's peripheral capability FIRST
 * and only falls back to generic sources when there is none
 * (PlatformHelperImpl: "if (result != null) return result;"), so generic methods
 * are invisible on a block that already publishes a peripheral - which these
 * thrusters do. Registering a competing capability would instead REPLACE
 * setVector and setThrust. Adding methods to their peripheral class keeps
 * everything and depends on no registration order.
 *
 * WHY THIS EXISTS. The previous guidance loop had to discover the sign of each
 * control axis at runtime by watching the rate diverge and flipping when it
 * grew - an adaptive hack that costs a second of wrong-way torque every time it
 * guesses. It had to, because nothing told it where the thrusters were, which
 * way they pushed, or where the centre of mass was. All of that is right here
 * in Sable's MassData and the thruster's own geometry, and with it the control
 * allocation can be computed once, exactly, instead of being groped for.
 *
 * FRAMES. "local" is sub-level block coordinates - the frame the vehicle was
 * built in, and the frame thruster positions and axes live in. "world" is the
 * parent level. logicalPose() converts. Angular velocity is reported in both
 * because the physics pipeline works in radians per second while everything
 * else here is per tick.
 */
public final class FlightCore {

    private FlightCore() {}

    // ---- plumbing ----

    private static ServerSubLevel sub(AbstractThrusterBlockEntity be) throws LuaException {
        SubLevel s;
        try {
            s = Sable.HELPER.getContaining(be);
        } catch (Throwable t) {
            throw new LuaException("sable not available");
        }
        if (!(s instanceof ServerSubLevel ssl)) {
            throw new LuaException("this thruster is not on a sub-level");
        }
        return ssl;
    }

    private static Object container(ServerSubLevel s) throws LuaException {
        Object c = SubLevelContainer.getContainer(s.getLevel());
        if (c == null) throw new LuaException("no sub-level container in this dimension");
        return c;
    }

    private static RigidBodyHandle body(ServerSubLevel s) throws LuaException {
        RigidBodyHandle h = RigidBodyHandle.of(s);
        if (h == null) throw new LuaException("no physics body for this sub-level");
        return h;
    }

    private static void put3(Map<String, Object> m, String p, Vector3dc v) {
        m.put(p + "x", v.x());
        m.put(p + "y", v.y());
        m.put(p + "z", v.z());
    }

    private static void put3(Map<String, Object> m, String p, Vec3 v) {
        m.put(p + "x", v.x);
        m.put(p + "y", v.y);
        m.put(p + "z", v.z);
    }

    /**
     * Nozzle application point, sub-level local - the exact point the impulse
     * acts on, copied from ThrusterForceProvider.createSample rather than
     * guessed. The offset is a config value (0.45 by default); I had 0.5.
     */
    private static Vector3d mountLocal(AbstractThrusterBlockEntity be) {
        Vector3d dir = new Vector3d(be.getThrustDirectionLocal()).normalize();
        double off = PropulsionConfig.NOZZLE_OFFSET_FROM_CENTER.get();
        return new Vector3d(be.getBlockPos().getX() + 0.5,
                be.getBlockPos().getY() + 0.5,
                be.getBlockPos().getZ() + 0.5).fma(off, dir);
    }

    /** Internal thrust units per kilonewton - the physics conversion factor. */
    private static double unitsPerKn() {
        return PropulsionConfig.THRUST_UNITS_PER_KN.get();
    }

    // ---- state ----

    /**
     * Mass properties and attitude. Everything the allocation maths needs and
     * the old loop had to infer: real mass, real centre of mass, real
     * orientation as a quaternion (no gimbal-lock games with Euler angles).
     */
    public static Map<String, Object> getBody(AbstractThrusterBlockEntity be) throws LuaException {
        ServerSubLevel s = sub(be);
        MassData mass = s.getMassTracker();
        Map<String, Object> m = new HashMap<>();

        m.put("mass", mass.getMass());
        m.put("valid", !mass.isInvalid());
        Vector3dc com = mass.getCenterOfMass();
        if (com != null) put3(m, "com", com);   // LOCAL frame

        Vec3 p = s.logicalPose().transformPosition(new Vec3(0, 0, 0));
        // the world position of the centre of mass is what actually flies
        if (com != null) {
            Vec3 comWorld = s.logicalPose().transformPosition(new Vec3(com.x(), com.y(), com.z()));
            put3(m, "world", comWorld);
        } else {
            put3(m, "world", p);
        }

        Quaterniond q = new Quaterniond(s.logicalPose().orientation());
        m.put("qx", q.x); m.put("qy", q.y); m.put("qz", q.z); m.put("qw", q.w);
        // Euler for readability only - drive control off the quaternion or the
        // basis vectors below, both of which stay well behaved straight up.
        Vector3d up   = new Vector3d(0, 1, 0); q.transform(up);
        Vector3d fwd  = new Vector3d(0, 0, 1); q.transform(fwd);
        put3(m, "up", up);
        put3(m, "fwd", fwd);
        m.put("tilt", Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, up.y)))));

        m.put("uuid", s.getUniqueId().toString());
        return m;
    }

    /**
     * Body attitude and motion in ONE call.
     *
     * Every peripheral call is a round trip parked until the next server tick,
     * and the flight loop needs both of these every iteration. Measured on a
     * real flight, four round trips per iteration turned a 20 Hz control loop
     * into 3 Hz - slow enough that gains tuned for 20 Hz went unstable. Merging
     * two calls into one is a direct rate increase.
     */
    public static Map<String, Object> getState(AbstractThrusterBlockEntity be) throws LuaException {
        Map<String, Object> m = getBody(be);
        m.putAll(getMotion(be));
        return m;
    }

    /** Linear and angular velocity of the body. Sable works per second. */
    public static Map<String, Object> getMotion(AbstractThrusterBlockEntity be) throws LuaException {
        RigidBodyHandle h = body(sub(be));
        Vector3d lin = h.getLinearVelocity(new Vector3d());
        Vector3d ang = h.getAngularVelocity(new Vector3d());
        Map<String, Object> m = new HashMap<>();
        put3(m, "v", lin);                                   // blocks/second
        m.put("speed", lin.length());
        put3(m, "w", ang);                                   // radians/second
        m.put("vtx", lin.x * 0.05); m.put("vty", lin.y * 0.05); m.put("vtz", lin.z * 0.05);
        m.put("wdegx", Math.toDegrees(ang.x));
        m.put("wdegy", Math.toDegrees(ang.y));
        m.put("wdegz", Math.toDegrees(ang.z));
        m.put("spin", Math.toDegrees(ang.length()));
        return m;
    }

    /**
     * This thruster's geometry and, more usefully, its authority: what one unit
     * of its impulse actually does to the body.
     *
     * "linear" is the acceleration along the thrust axis. "angular" is the
     * angular acceleration it produces about the centre of mass, with the axis
     * it produces it about. Build the allocation matrix out of these instead of
     * flipping signs until the vehicle stops tumbling.
     */
    public static Map<String, Object> getMount(AbstractThrusterBlockEntity be) throws LuaException {
        ServerSubLevel s = sub(be);
        MassData mass = s.getMassTracker();
        Vector3d pt  = mountLocal(be);
        Vector3d dir = new Vector3d(be.getThrustDirectionLocal()).normalize();

        Map<String, Object> m = new HashMap<>();
        put3(m, "p", pt);        // local application point
        put3(m, "d", dir);       // local thrust axis

        Quaterniond q = new Quaterniond(s.logicalPose().orientation());
        Vector3d dirW = q.transform(new Vector3d(dir));
        put3(m, "wd", dirW);     // same axis in world
        Vec3 ptW = s.logicalPose().transformPosition(new Vec3(pt.x, pt.y, pt.z));
        put3(m, "wp", ptW);

        Vector3dc com = mass.getCenterOfMass();
        if (com != null && !mass.isInvalid()) {
            Vector3d r = new Vector3d(pt).sub(com);          // lever arm, local
            put3(m, "r", r);
            m.put("arm", r.length());
            m.put("linear", mass.getInverseMass());          // accel per unit impulse
            Matrix3dc invI = mass.getInverseInertiaTensor();
            Vector3d torque = new Vector3d(r).cross(dir);    // per unit impulse
            Vector3d alpha = invI.transform(new Vector3d(torque));
            put3(m, "alpha", alpha);                         // rad/s per unit impulse
            m.put("angular", alpha.length());
            // total effective inverse mass along this axis at this point -
            // Sable's own figure, useful as a sanity check on the two above
            m.put("normal", mass.getInverseNormalMass(pt, dir));
        }

        m.put("thrust", (double) be.getCurrentThrust());
        m.put("throttle", (double) be.getThrottle());
        m.put("active", be.isActive());

        // WHAT THIS ENGINE IS DOING RIGHT NOW, exactly as the physics tick
        // computes it:
        //     impulse = direction * thrust * dt / unitsPerKn
        // so no calibration flight is needed to learn the thrust scale - the
        // engine reports its own thrust and the conversion is a config value.
        double dt = 1.0 / 20.0;
        double imp = be.getCurrentThrust() * dt / unitsPerKn();
        m.put("impulse", imp);
        m.put("unitsPerKn", unitsPerKn());
        if (com != null && !mass.isInvalid()) {
            Vector3d r = new Vector3d(pt).sub(com);
            Vector3d torque = new Vector3d(r).cross(dir).mul(imp);
            Vector3d dw = mass.getInverseInertiaTensor().transform(new Vector3d(torque));
            put3(m, "dw", dw);                       // rad/s gained this tick
            m.put("dv", mass.getInverseMass() * imp); // b/s gained this tick
        }
        return m;
    }

    /**
     * The exact change in angular velocity this thruster will impose THIS
     * physics tick, in the sub-level frame.
     *
     * Everything in it is read, nothing assumed: the direction is the nozzle's
     * real current axis (the mod tweens it exponentially at 0.2 per tick and
     * snaps within 0.001, which no external model reproduces), the thrust is
     * what the engine reports, the application point is the configured nozzle
     * offset, and the inertia is Sable's own tensor.
     *
     * Accumulating this per tick is the only honest way to predict a burst:
     * sampling from Lua at 4-5 Hz misses three ticks out of four, and the
     * nozzle is moving through all of them.
     */
    public static double[] perTickDw(AbstractThrusterBlockEntity be) {
        try {
            SubLevel sl = Sable.HELPER.getContaining(be);
            if (!(sl instanceof ServerSubLevel s)) return null;
            MassData mass = s.getMassTracker();
            Vector3dc com = mass.getCenterOfMass();
            if (com == null || mass.isInvalid()) return null;
            float thrust = be.getCurrentThrust();
            if (thrust <= 0.0F) return new double[] { 0, 0, 0 };

            Vector3d dir = new Vector3d(be.getThrustDirectionLocal()).normalize();
            Vector3d pt = mountLocal(be);
            Vector3d r = new Vector3d(pt).sub(com);
            // the physics system substeps, but the impulse per substep is
            // thrust*substepDt/unitsPerKn and the substeps sum to one tick
            Vector3d imp = new Vector3d(dir).mul(thrust * (1.0 / 20.0) / unitsPerKn());
            Vector3d torque = new Vector3d(r).cross(imp);
            Vector3d dw = mass.getInverseInertiaTensor().transform(new Vector3d(torque));
            return new double[] { dw.x, dw.y, dw.z };
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * The environment, read rather than measured: gravity for this dimension at
     * this point, and the mass it acts on.
     *
     * Sable publishes gravity through DimensionPhysicsData, so the vertical
     * acceleration probe that cost several test flights was never necessary.
     */
    public static Map<String, Object> getEnv(AbstractThrusterBlockEntity be) throws LuaException {
        ServerSubLevel s = sub(be);
        MassData mass = s.getMassTracker();
        Vector3dc com = mass.getCenterOfMass();
        Vec3 world = com == null
                ? s.logicalPose().transformPosition(new Vec3(0, 0, 0))
                : s.logicalPose().transformPosition(new Vec3(com.x(), com.y(), com.z()));

        Vector3d gvec = DimensionPhysicsData.getGravity(s.getLevel(),
                new Vector3d(world.x, world.y, world.z), new Vector3d());
        Map<String, Object> m = new HashMap<>();
        put3(m, "g", gvec);                      // blocks per second squared
        m.put("gmag", gvec.length());
        m.put("mass", mass.getMass());
        m.put("weight", mass.getMass() * gvec.length());
        return m;
    }

    /** Gimbal and throttle in one call, for the same reason as getState. */
    public static void setControl(AbstractThrusterBlockEntity be,
                                  double vx, double vy, double throttle) {
        if (be instanceof dev.propulsionteam.propulsionsimulated.content.thruster
                .vector_thruster.VectorThrusterBlockEntity v) {
            v.setVectorCoordinates(
                    (float) Math.max(-1.0, Math.min(1.0, vx)),
                    (float) Math.max(-1.0, Math.min(1.0, vy)));
        } else if (be instanceof dev.propulsionteam.propulsionsimulated.content.thruster
                .liquid_vector_thruster.LiquidVectorThrusterBlockEntity l) {
            l.setVectorCoordinates(
                    (float) Math.max(-1.0, Math.min(1.0, vx)),
                    (float) Math.max(-1.0, Math.min(1.0, vy)));
        }
        // same conversion the mod's own setThrustNormalized performs
        double t = Math.max(0.0, Math.min(1.0, throttle));
        int rs = (int) Math.floor(t * 15.0 + 1.0E-6);
        be.setDigitalInput(rs / 15.0F);
    }

    /** Straight-down clip from the body, world frame: height above terrain. */
    public static Map<String, Object> getGround(AbstractThrusterBlockEntity be) throws LuaException {
        ServerSubLevel s = sub(be);
        Level level = s.getLevel();
        MassData mass = s.getMassTracker();
        Vector3dc com = mass.getCenterOfMass();
        Vec3 from = com == null
                ? s.logicalPose().transformPosition(new Vec3(0, 0, 0))
                : s.logicalPose().transformPosition(new Vec3(com.x(), com.y(), com.z()));
        Vec3 to = new Vec3(from.x, level.getMinBuildHeight(), from.z);

        // the cast is required: ClipContext has both an Entity and a
        // CollisionContext overload, and a bare null matches neither uniquely
        BlockHitResult hit = level.clip(new ClipContext(
                from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, (Entity) null));

        Map<String, Object> m = new HashMap<>();
        put3(m, "from", from);
        if (hit.getType() == HitResult.Type.MISS) {
            m.put("hit", false);
            m.put("agl", from.y - level.getMinBuildHeight());
        } else {
            m.put("hit", true);
            m.put("agl", from.y - hit.getLocation().y);
            m.put("groundY", hit.getLocation().y);
            m.put("block", level.getBlockState(hit.getBlockPos()).getBlock()
                    .getDescriptionId());
        }
        return m;
    }

    // ---- loading ----

    /**
     * Keep this sub-level (and the world chunks under it) loaded while the
     * flight is running.
     *
     * The ticket is persisted by Sable, so it survives a server restart - which
     * means a program that sets it must clear it. Anything that arms a missile
     * should release the ticket on impact or abort, otherwise every test flight
     * leaves a chunk-loaded corpse in the world forever.
     */
    public static boolean setLoaded(AbstractThrusterBlockEntity be, boolean load) throws LuaException {
        if (SableTickets.unavailable()) throw new LuaException(SableTickets.why());
        ServerSubLevel s = sub(be);
        try {
            return SableTickets.set(container(s), s, load);
        } catch (LuaException e) {
            throw e;
        } catch (Exception e) {
            throw new LuaException("force-load failed: " + e);
        }
    }

    public static boolean isLoaded(AbstractThrusterBlockEntity be) throws LuaException {
        ServerSubLevel s = sub(be);
        return SableTickets.isLoaded(container(s), s);
    }

    /** Whether this Sable build exposes force-loading, and why not if it does not. */
    public static Map<String, Object> getLoadSupport(AbstractThrusterBlockEntity be) {
        Map<String, Object> m = new HashMap<>();
        m.put("supported", !SableTickets.unavailable());
        m.put("reason", SableTickets.why());
        return m;
    }

    // ---- frame conversion, so Lua never has to reimplement quaternions ----

    public static Map<String, Object> toWorld(AbstractThrusterBlockEntity be,
                                              double x, double y, double z,
                                              boolean asDirection) throws LuaException {
        ServerSubLevel s = sub(be);
        Map<String, Object> m = new HashMap<>();
        if (asDirection) {
            Vector3d v = new Quaterniond(s.logicalPose().orientation())
                    .transform(new Vector3d(x, y, z));
            put3(m, "", v);
        } else {
            put3(m, "", s.logicalPose().transformPosition(new Vec3(x, y, z)));
        }
        return m;
    }

    public static Map<String, Object> toLocal(AbstractThrusterBlockEntity be,
                                              double x, double y, double z,
                                              boolean asDirection) throws LuaException {
        ServerSubLevel s = sub(be);
        Map<String, Object> m = new HashMap<>();
        if (asDirection) {
            Vector3d v = new Vector3d(x, y, z);
            new Quaterniond(s.logicalPose().orientation()).transformInverse(v);
            put3(m, "", v);
        } else {
            put3(m, "", s.logicalPose().transformPositionInverse(new Vec3(x, y, z)));
        }
        return m;
    }
}