package com.invfix.flight;

import java.lang.reflect.Method;
import java.util.Collection;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Unit;

/**
 * Sable's sub-level force-load tickets, reached by reflection.
 *
 * Not because reflection is nice, but because this API is not in every build of
 * Sable. Binding to it directly makes the whole addon fail to compile against an
 * older jar, and worse, fail to LOAD against one at runtime - the class would
 * link the moment a thruster is touched. Reflected, a Sable without the ticket
 * system just reports that force-loading is unavailable, and everything else on
 * the flight computer keeps working.
 *
 * If unavailable() comes back true and the server still has /sable forceload,
 * the compile dependency and the runtime jar are different versions.
 */
final class SableTickets {

    private SableTickets() {}

    private static final String TYPE_CLASS =
            "dev.ryanhcode.sable.api.sublevel.ticket.SubLevelLoadingTicketType";

    private static boolean probed = false;
    private static Object ticketType = null;
    private static Method add = null;
    private static Method remove = null;
    private static Method collect = null;
    private static String failure = "not probed";

    private static synchronized void probe() {
        if (probed) return;
        probed = true;
        try {
            Class<?> typeCls = Class.forName(TYPE_CLASS);
            Method create = typeCls.getMethod("create", ResourceLocation.class,
                    com.mojang.serialization.Codec.class);
            ticketType = create.invoke(null,
                    ResourceLocation.fromNamespaceAndPath("sable_compat", "in_flight"),
                    Unit.CODEC);

            Class<?> containerCls = Class.forName(
                    "dev.ryanhcode.sable.api.sublevel.ServerSubLevelContainer");
            for (Method m : containerCls.getMethods()) {
                if (m.getParameterCount() == 3) {
                    if ("addForceLoadTicket".equals(m.getName())) add = m;
                    if ("removeForceLoadTicket".equals(m.getName())) remove = m;
                }
                if (m.getParameterCount() == 0
                        && "collectForceLoadedSubLevels".equals(m.getName())) collect = m;
            }
            if (add == null || remove == null) {
                failure = "this Sable build has no addForceLoadTicket";
                ticketType = null;
            } else {
                failure = null;
            }
        } catch (ClassNotFoundException e) {
            failure = "this Sable build has no sub-level ticket API";
        } catch (Throwable t) {
            failure = "sable ticket API rejected: " + t;
        }
    }

    static boolean unavailable() {
        probe();
        return failure != null;
    }

    static String why() {
        probe();
        return failure == null ? "ok" : failure;
    }

    static boolean set(Object container, Object subLevel, boolean load) throws Exception {
        probe();
        if (failure != null) return false;
        Method m = load ? add : remove;
        Object r = m.invoke(container, subLevel, ticketType, Unit.INSTANCE);
        return r instanceof Boolean b && b;
    }

    static boolean isLoaded(Object container, Object subLevel) {
        probe();
        if (collect == null) return false;
        try {
            Object r = collect.invoke(container);
            return r instanceof Collection<?> c && c.contains(subLevel);
        } catch (Throwable t) {
            return false;
        }
    }
}