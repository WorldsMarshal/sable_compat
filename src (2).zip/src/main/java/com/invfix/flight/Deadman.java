package com.invfix.flight;

/**
 * Implemented on every thruster block entity by ThrusterDeadmanMixin.
 *
 * The peripheral needs a typed way to reach the countdown, and the countdown
 * has to live on the block entity rather than the peripheral: a peripheral only
 * exists while something is talking to it, and the whole point is to survive
 * the moment nothing is.
 */
public interface Deadman {
    void invfix$armDeadman(int ticks);
    int invfix$deadmanLeft();

    /**
     * Sum of the per-tick angular-velocity changes this thruster has imposed
     * since the last reset, sub-level frame. Accumulated inside the block
     * entity's own tick, so it misses nothing.
     */
    double[] invfix$dwAccum();

    void invfix$resetDw();
}