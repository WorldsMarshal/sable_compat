package com.invfix.compat.jei;

import com.invfix.InvincibleFix;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.runtime.IIngredientManager;
import mezz.jei.api.runtime.IJeiRuntime;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

/**
 * JEI-плагин совместимости.
 *
 * Прячет из меню JEI вообще все предметы мода invincible_inc (у них нет крафтов,
 * и в списке ингредиентов JEI они только мусорят). ИСКЛЮЧЕНИЕ — предметы,
 * добавленные нами (sable_compat), которые зарегистрированы в namespace
 * invincible_inc ради единого id-пути: у них есть крафт/назначение, поэтому
 * они должны остаться видимыми. Их пути перечислены в {@link #KEEP_VISIBLE}.
 *
 * Предметы остаются зарегистрированными и доступными в креативном меню — мы не
 * удаляем их из реестра, а лишь убираем из рантайм-списка JEI через
 * removeIngredientsAtRuntime.
 *
 * Класс инстанцируется исключительно самим JEI (по аннотации @JeiPlugin), поэтому
 * при отсутствии JEI он не подгружается и никакого гейта не требует. JEI — это
 * compileOnly-зависимость.
 */
@JeiPlugin
public class InvincibleJeiPlugin implements IModPlugin {

    /** Неймспейс мода, чьи предметы скрываем из JEI. */
    private static final String HIDDEN_NAMESPACE = "invincible_inc";

    /**
     * Пути предметов в namespace invincible_inc, которые НЕ скрываем
     * (это наши добавления, а не оригинальные вещи мода).
     */
    private static final Set<String> KEEP_VISIBLE = Set.of(
            "scourge_virus",
            "viltrumite_fossil"
    );

    @Override
    public ResourceLocation getPluginUid() {
        return ResourceLocation.fromNamespaceAndPath(InvincibleFix.MOD_ID, "jei_hide");
    }

    @Override
    @SuppressWarnings("unchecked")
    public void onRuntimeAvailable(IJeiRuntime jeiRuntime) {
        IIngredientManager manager = jeiRuntime.getIngredientManager();

        Collection<ItemStack> allStacks = manager.getAllItemStacks();
        List<ItemStack> toHide = new ArrayList<>();
        for (ItemStack stack : allStacks) {
            ResourceLocation id = BuiltInRegistries.ITEM.getKey(stack.getItem());
            if (id != null
                    && HIDDEN_NAMESPACE.equals(id.getNamespace())
                    && !KEEP_VISIBLE.contains(id.getPath())) {
                toHide.add(stack);
            }
        }

        if (!toHide.isEmpty()) {
            manager.removeIngredientsAtRuntime(VanillaTypes.ITEM_STACK, toHide);
        }
    }
}