package com.invfix.compat;

import net.neoforged.fml.loading.LoadingModList;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.MultiANewArrayInsnNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Set;

public class InvincibleIncMixinTransformer implements IMixinConfigPlugin {

    private static final Logger INVFIX_LOG = LoggerFactory.getLogger("invfix/dist-strip");
    private static final String INVFIX_NET_PREFIX = "net/benniao/theboysmod/network/";
    private static final String INVFIX_CLIENT_PREFIX = "net/minecraft/client/";

    @Override public void onLoad(String mixinPackage) {}
    @Override public String getRefMapperConfig() { return null; }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        // ── Ветка timestop: миксины в чужие моды ставим только при их наличии.
        // Ванильные (TsServerLevelMixin/TsServerPlayerMixin/TsEntityMixin/
        // TsNeighborUpdaterMixin и клиентские) идут всегда.
        if (mixinClassName != null && mixinClassName.contains("timestop.TsComputerCraftMixin")) {
            return invfix_modLoaded("computercraft");
        }
        if (mixinClassName != null && mixinClassName.contains("timestop.TsCreateTrainMixin")) {
            return invfix_modLoaded("create");
        }
        if (mixinClassName != null && mixinClassName.contains("timestop.TsAeronauticsTickMixin")) {
            return invfix_modLoaded("aeronautics");
        }
        if (mixinClassName != null && mixinClassName.contains("timestop.TsSimulatedTickMixin")) {
            return invfix_modLoaded("simulated");
        }
        // Подавление родной «остановки времени» спидстера — только если
        // invincible_inc загружен (мы правим его процедуру).
        if (mixinClassName != null && mixinClassName.contains("timestop.TsNativeTimeStopMixin")) {
            return invfix_modLoaded("invincible_inc");
        }

        // Дедупликация регистрации звуковых записей Create (CBC Military Supplement
        // и другие аддоны попадают в AllSoundEvents.ALL дважды) — только если create загружен.
        if (mixinClassName != null && mixinClassName.contains("CreateSoundEntryDuplicateMixin")) {
            return invfix_modLoaded("create");
        }
        // Ограничитель энтальпии по домену таблиц — только если formicapi загружен.
        if (mixinClassName != null && mixinClassName.contains("FormicEnthalpyClampMixin")) {
            return invfix_modLoaded("formicapi");
        }
        // Предохранитель паровых потоков Crowns — только если crowns загружен.
        if (mixinClassName != null && mixinClassName.contains("CrownsSteamFlowCapMixin")) {
            return invfix_modLoaded("crowns");
        }
        // Миксин совместимости с Neat применяем только если Neat загружен
        if (mixinClassName != null && mixinClassName.contains("NeatNoPlayerPlatesMixin")) {
            return invfix_modLoaded("neat");
        }
        // Миксин скрытия слоёв модели в анимациях от первого лица — только если
        // загружен оригинальный invincible_inc (его персистентные флаги мы читаем).
        if (mixinClassName != null && mixinClassName.contains("LivingEntityRendererLayersMixin")) {
            return invfix_modLoaded("invincible_inc");
        }
        // Клавиши Invincible Inc по умолчанию не назначены — только если он загружен.
        if (mixinClassName != null && mixinClassName.contains("InvincibleIncKeysUnboundMixin")) {
            return invfix_modLoaded("invincible_inc");
        }
        // Фикс accessor'а Synaxis (битое поле sceneID) — только если Synaxis загружен.
        if (mixinClassName != null && mixinClassName.contains("SynaxisConstraintIdFixMixin")) {
            return invfix_modLoaded("synaxis");
        }
        // Все миксины, зависящие от The Boys, применяем только если мод загружен
        if (mixinClassName != null
                && (mixinClassName.contains("VoughtDeathHandlerMixin")
                || mixinClassName.contains("TranslucentBucketFixMixin")
                || mixinClassName.contains("TheBoysEventMixins")
                || mixinClassName.contains("TheBoysHumanVMixins")
                || mixinClassName.contains("TheBoysBornForVMixins")
                || mixinClassName.contains("StarterPhoneHandlerMixin")
                || mixinClassName.contains("LaserEyePlayfulMixin")
                || mixinClassName.contains("LaserEyePlayfulClientMixin")
                || mixinClassName.contains("SyringeRaceGateMixin")
                || mixinClassName.contains("SyringeAttackRaceGateMixin")
                || mixinClassName.contains("InjectVRaceGateMixin")
                || mixinClassName.contains("TheBoysNetworkServerFixMixin")
                || mixinClassName.contains("MzhanShopCatalogMixin"))) {
            return invfix_theBoysLoaded();
        }
        if (mixinClassName != null && mixinClassName.contains("ColdSweatTempRegistryMixin")) {
            return invfix_modLoaded("cold_sweat");
        }
        // Незамерзающие океаны (фикс замерзания воды Cold Sweat) — только если мод загружен.
        if (mixinClassName != null && mixinClassName.contains("ColdSweatOceanFreezeMixin")) {
            return invfix_modLoaded("cold_sweat");
        }
        // Фикс совместимости с PointBlank — только если мод загружен.
        if (mixinClassName != null && mixinClassName.contains("PointBlankHurtMarkerMixin")) {
            return invfix_modLoaded("pointblank");
        }
        // Ребаланс PointBlank: отключение дропа gunmetal — только если мод загружен.
        // Пак оружия и FE-питание бластера — только при загруженном PointBlank.
        if (mixinClassName != null && (mixinClassName.contains("PointBlankExtensionPackMixin")
                || mixinClassName.contains("PointBlankGunInventoryTickMixin")
                || mixinClassName.contains("PointBlankGunClientStateInvoker")
                || mixinClassName.contains("PointBlankBlasterAmmoSyncMixin"))) {
            return invfix_modLoaded("pointblank");
        }
        if (mixinClassName != null && mixinClassName.contains("GunmetalDropSuppressMixin")) {
            return invfix_modLoaded("pointblank");
        }
        // Рендер бионических протезов — только если загружен createcybernetics.
        if (mixinClassName != null && mixinClassName.contains("BionicSkinMixin")) {
            return invfix_modLoaded("createcybernetics");
        }
        // Синхронизация SonarPingManager (гонка потоков, AIOOBE при воспроизведении
        // звука) — только если загружен createcybernetics.
        if (mixinClassName != null && mixinClassName.contains("CyberneticsSonarThreadSafetyMixin")) {
            return invfix_modLoaded("createcybernetics");
        }
        // Power Grid: чтение синхронизации электросети в пределах своей записи — только если мод загружен.
        // Скины посетителей MineColonies затапливали Util.backgroundExecutor().
        if (mixinClassName != null && mixinClassName.contains("MinecoloniesVisitorSkinMixin")) {
            return invfix_modLoaded("minecolonies");
        }
        // Гонка в RenderTypeShardRegistry у Veil (идёт внутри Sable) — только если Veil загружен.
        if (mixinClassName != null && mixinClassName.contains("VeilShardRegistrySyncMixin")) {
            return invfix_modLoaded("veil");
        }
        if (mixinClassName != null && mixinClassName.contains("PowergridStateSyncBoundsMixin")) {
            return invfix_modLoaded("powergrid");
        }
        // Фикс краша PerformanceWatchdog (AIOOBE при итерации сущностей) — только если SpawnControl загружен.
        if (mixinClassName != null && mixinClassName.contains("SpawnControlWatchdogMixin")) {
            return invfix_modLoaded("spawncontrol");
        }
        if (mixinClassName != null
                && (mixinClassName.contains("FormicEnthalpyClampMixin")
                || mixinClassName.contains("FormicGasStateCodecFixMixin"))) {
            return invfix_modLoaded("formicapi");
        }
        // Убирает импланты из лута Create Cybernetics.
        if (mixinClassName != null
                && (mixinClassName.contains("AddItemModifierMixin")
                || mixinClassName.contains("CyberwareMobDropMixin"))) {
            return invfix_modLoaded("createcybernetics");
        }
        // Прямое задание оборотов умной передаче Simulated.
        if (mixinClassName != null && mixinClassName.contains("AnalogTransmissionControlMixin")) {
            return invfix_modLoaded("simulated") && invfix_modLoaded("create");
        }
        // Кабельный порт на обычных компьютерах CC — нужны оба мода.
        if (mixinClassName != null && mixinClassName.contains("ComputerCableMixin")) {
            return invfix_modLoaded("drivebywire") && invfix_modLoaded("computercraft");
        }
        // Мост между ванильным редстоуном и кабелем DriveByWire.
        if (mixinClassName != null
                && (mixinClassName.contains("LevelWireSignalMixin")
                || mixinClassName.contains("WireNetworkManagerAccessor"))) {
            return invfix_modLoaded("drivebywire");
        }
        // Управление печатной машинкой Simulated с компьютера — только если
        // Simulated и CC загружены: миксин трогает их классы напрямую.
        if (mixinClassName != null
                && (mixinClassName.contains("LinkedTypewriter")
                || mixinClassName.contains("SimPeripheralAccessor"))) {
            return invfix_modLoaded("simulated") && invfix_modLoaded("computercraft");
        }
        // Счётчик изменений структуры плота для шины саблевел-компьютера —
        // только если Sable загружен.
        if (mixinClassName != null && mixinClassName.contains("PlotStructureVersionMixin")) {
            return invfix_modLoaded("sable");
        }
        return true;
    }

    /**
     * Проверка наличия мода по modId на РАННЕЙ фазе (prepare миксинов).
     * ModList.get() здесь ещё null — используем LoadingModList.
     */
    private static boolean invfix_modLoaded(String modId) {
        try {
            return LoadingModList.get() != null
                    && LoadingModList.get().getModFileById(modId) != null;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Проверка наличия The Boys на РАННЕЙ фазе (prepare миксинов).
     * ModList.get() здесь ещё null — используем LoadingModList.
     */
    private static boolean invfix_theBoysLoaded() {
        return invfix_modLoaded("theboysmod");
    }

    @Override public void acceptTargets(Set<String> a, Set<String> b) {}
    @Override public List<String> getMixins() { return null; }
    @Override public void preApply(String t, ClassNode c, String m, IMixinInfo i) {}
    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
        if (targetClassName == null || targetClass == null) {
            return;
        }
        String internal = targetClassName.replace('.', '/');
        if (!internal.startsWith(INVFIX_NET_PREFIX)) {
            return;
        }
        if (targetClass.methods == null) {
            return;
        }
        for (MethodNode method : targetClass.methods) {
            if (method == null || method.name == null) {
                continue;
            }
            if ("<init>".equals(method.name) || "<clinit>".equals(method.name)) {
                continue;
            }
            if ((method.access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_NATIVE)) != 0) {
                continue;
            }
            if (method.instructions == null || method.instructions.size() == 0) {
                continue;
            }
            if (!invfix_referencesClient(method)) {
                continue;
            }
            invfix_neutralize(method);
            INVFIX_LOG.info("Stripped client-only body from {}.{}{} for dedicated server",
                    internal, method.name, method.desc);
        }
    }

    private static boolean invfix_referencesClient(MethodNode method) {
        for (AbstractInsnNode insn = method.instructions.getFirst(); insn != null; insn = insn.getNext()) {
            if (insn instanceof MethodInsnNode) {
                MethodInsnNode mi = (MethodInsnNode) insn;
                if (invfix_isClient(mi.owner) || invfix_descHasClient(mi.desc)) {
                    return true;
                }
            } else if (insn instanceof FieldInsnNode) {
                FieldInsnNode fi = (FieldInsnNode) insn;
                if (invfix_isClient(fi.owner) || invfix_descHasClient(fi.desc)) {
                    return true;
                }
            } else if (insn instanceof TypeInsnNode) {
                if (invfix_isClient(((TypeInsnNode) insn).desc)) {
                    return true;
                }
            } else if (insn instanceof MultiANewArrayInsnNode) {
                if (invfix_descHasClient(((MultiANewArrayInsnNode) insn).desc)) {
                    return true;
                }
            } else if (insn instanceof InvokeDynamicInsnNode) {
                InvokeDynamicInsnNode idn = (InvokeDynamicInsnNode) insn;
                if (invfix_descHasClient(idn.desc)) {
                    return true;
                }
                if (idn.bsmArgs != null) {
                    for (Object arg : idn.bsmArgs) {
                        if (arg instanceof Type && invfix_descHasClient(((Type) arg).getDescriptor())) {
                            return true;
                        }
                        if (arg instanceof Handle) {
                            Handle h = (Handle) arg;
                            if (invfix_isClient(h.getOwner()) || invfix_descHasClient(h.getDesc())) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    private static boolean invfix_isClient(String internalName) {
        return internalName != null && internalName.startsWith(INVFIX_CLIENT_PREFIX);
    }

    private static boolean invfix_descHasClient(String desc) {
        return desc != null && desc.contains("L" + INVFIX_CLIENT_PREFIX);
    }

    private static void invfix_neutralize(MethodNode method) {
        method.instructions.clear();
        if (method.tryCatchBlocks != null) {
            method.tryCatchBlocks.clear();
        }
        if (method.localVariables != null) {
            method.localVariables.clear();
        }
        if (method.visibleLocalVariableAnnotations != null) {
            method.visibleLocalVariableAnnotations.clear();
        }
        if (method.invisibleLocalVariableAnnotations != null) {
            method.invisibleLocalVariableAnnotations.clear();
        }

        Type returnType = Type.getReturnType(method.desc);
        int stack;
        switch (returnType.getSort()) {
            case Type.VOID:
                method.instructions.add(new InsnNode(Opcodes.RETURN));
                stack = 0;
                break;
            case Type.BOOLEAN:
            case Type.CHAR:
            case Type.BYTE:
            case Type.SHORT:
            case Type.INT:
                method.instructions.add(new InsnNode(Opcodes.ICONST_0));
                method.instructions.add(new InsnNode(Opcodes.IRETURN));
                stack = 1;
                break;
            case Type.FLOAT:
                method.instructions.add(new InsnNode(Opcodes.FCONST_0));
                method.instructions.add(new InsnNode(Opcodes.FRETURN));
                stack = 1;
                break;
            case Type.LONG:
                method.instructions.add(new InsnNode(Opcodes.LCONST_0));
                method.instructions.add(new InsnNode(Opcodes.LRETURN));
                stack = 2;
                break;
            case Type.DOUBLE:
                method.instructions.add(new InsnNode(Opcodes.DCONST_0));
                method.instructions.add(new InsnNode(Opcodes.DRETURN));
                stack = 2;
                break;
            default:
                method.instructions.add(new InsnNode(Opcodes.ACONST_NULL));
                method.instructions.add(new InsnNode(Opcodes.ARETURN));
                stack = 1;
                break;
        }
        method.maxStack = stack;
    }
}