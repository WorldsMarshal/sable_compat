package com.invfix.compat.pointblank;

import com.mojang.logging.LogUtils;
import net.neoforged.fml.loading.FMLPaths;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

/**
 * Пак оружия sable_compat для Point Blank.
 *
 * Point Blank берёт оружие только из паков расширений в {@code <игра>/pointblank/}
 * (ExtensionRegistry.discoverExtensions -> scanExtensions). Пак лежит внутри нашего
 * jar готовым zip-архивом; перед тем как Point Blank начнёт искать паки,
 * {@code PointBlankExtensionPackMixin} вызывает {@link #install()}, и архив
 * кладётся (или обновляется) в эту папку. Дальше Point Blank грузит его
 * штатно, как любой другой пак.
 */
public final class SableWeaponsPack {

    private SableWeaponsPack() {}

    private static final Logger LOGGER = LogUtils.getLogger();

    /** Где лежит в нашем jar. Не в assets/, чтобы не попасть в ресурсы игры. */
    private static final String RESOURCE = "/sable_compat_pointblank/sable_compat_weapons.zip";
    /** Имя файла в папке паков Point Blank. */
    public static final String FILE_NAME = "sable_compat_weapons.zip";

    private static boolean installed;

    public static synchronized void install() {
        if (installed) return;
        installed = true;
        try (InputStream in = SableWeaponsPack.class.getResourceAsStream(RESOURCE)) {
            if (in == null) {
                LOGGER.error("[sable_compat] В jar нет пака оружия {}", RESOURCE);
                return;
            }
            byte[] bytes = in.readAllBytes();
            Path dir = FMLPaths.GAMEDIR.get().resolve("pointblank");
            Files.createDirectories(dir);
            Path target = dir.resolve(FILE_NAME);
            if (Files.exists(target) && Arrays.equals(Files.readAllBytes(target), bytes)) return;
            Path tmp = dir.resolve(FILE_NAME + ".tmp");
            Files.write(tmp, bytes);
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            LOGGER.info("[sable_compat] Пак оружия Point Blank записан: {}", target);
        } catch (IOException e) {
            LOGGER.error("[sable_compat] Не удалось записать пак оружия Point Blank", e);
        }
    }
}
