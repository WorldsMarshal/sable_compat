package com.invfix.compat.pointblank;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

/** Строка заряда в подсказке бластера. */
@OnlyIn(Dist.CLIENT)
public final class FlaxanBlasterClient {

    private FlaxanBlasterClient() {}

    public static void init() {
        if (!ModList.get().isLoaded("pointblank")) return;
        NeoForge.EVENT_BUS.addListener(FlaxanBlasterClient::onTooltip);
    }

    private static void onTooltip(ItemTooltipEvent event) {
        if (!FlaxanBlasterEnergy.isBlaster(event.getItemStack())) return;
        int fe = FlaxanBlasterEnergy.energy(event.getItemStack());
        event.getToolTip().add(1, Component.translatable("tooltip.sable_compat.flaxan_blaster.energy",
                String.format("%,d", fe).replace(',', ' '),
                String.format("%,d", FlaxanBlasterEnergy.CAPACITY).replace(',', ' '),
                String.format("%,d", FlaxanBlasterEnergy.FE_PER_SHOT).replace(',', ' '))
                .withStyle(ChatFormatting.RED));
    }
}
