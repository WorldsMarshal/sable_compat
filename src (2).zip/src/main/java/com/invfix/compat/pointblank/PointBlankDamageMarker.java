package com.invfix.compat.pointblank;

/**
 * Маркер «сейчас выполняется нанесение урона из PointBlank».
 *
 * PointBlank наносит урон от выстрелов через DamageSource типа PLAYER_ATTACK
 * (см. HurtingItem#hurtEntity), из-за чего этот урон попадает под систему
 * ближнего боя invfix и ошибочно получает силовой стат-бонус атаки.
 *
 * Маркер ставится миксином ровно вокруг вызова Entity#hurt внутри
 * HurtingItem#hurtEntity и снимается сразу после. Событие урона
 * (LivingIncomingDamageEvent → AttackDuraProcedure) срабатывает синхронно
 * внутри hurt() на том же потоке, поэтому AttackDuraProcedureMixin видит
 * активный маркер именно для выстрела и ни для чего другого.
 *
 * Класс НЕ зависит от PointBlank и грузится всегда: при отсутствии мода
 * маркер просто никогда не активируется, а isActive() возвращает false.
 */
public final class PointBlankDamageMarker {

    private static final ThreadLocal<Integer> DEPTH = ThreadLocal.withInitial(() -> 0);

    private PointBlankDamageMarker() {}

    public static void begin() {
        DEPTH.set(DEPTH.get() + 1);
    }

    public static void end() {
        int d = DEPTH.get() - 1;
        if (d <= 0) {
            DEPTH.remove();
        } else {
            DEPTH.set(d);
        }
    }

    public static boolean isActive() {
        return DEPTH.get() > 0;
    }
}