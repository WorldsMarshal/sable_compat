package com.invfix.compat.pointblank;

import com.mojang.serialization.Codec;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.RegisterEvent;

/**
 * Питание бластера от FE.
 *
 * Point Blank считает патроны в своём компоненте предмета {@code pointblank:custom_tag}
 * (ключ {@code "ammo"}, общий пул — GunItem.getAmmo/setAmmo/decrementAmmo), клиент
 * периодически сверяет с ним своё состояние (GunClientState.syncAmmo). Бластер
 * патронов не принимает (compatibleAmmo пуст), поэтому перезарядка обычным путём
 * ничего не даёт, а заряд — это и есть число выстрелов:
 *
 * <pre>энергия = патроны × 50 000 FE + остаток</pre>
 *
 * Остаток (меньше одного выстрела) и заряд, влитый в ещё не «инициализированную»
 * Point Blank пушку (у которой нет mid/lid и которую первый inventoryTick обнулит),
 * лежат в нашем компоненте {@code sable_compat:blaster_pending_fe}. Как только пушка
 * инициализирована, накопленное превращается в патроны (при приёме энергии и в
 * inventoryTick — миксин PointBlankGunInventoryTickMixin).
 *
 * Заряжается всем, что работает с Capabilities.EnergyStorage.ITEM: слот куба Рика,
 * зарядка Рика в инвентаре, зарядники Mekanism и т.п. Отдавать энергию не умеет.
 */
public final class FlaxanBlasterEnergy {

    private FlaxanBlasterEnergy() {}

    public static final ResourceLocation ITEM_ID = ResourceLocation.fromNamespaceAndPath("pointblank", "flaxan_blaster");
    /**
     * Прежний id (бластер сначала назывался Траксанским). Оставлен алиасом реестра
     * предметов: стеки, сохранённые под старым именем, грузятся как новый предмет.
     */
    public static final ResourceLocation LEGACY_ITEM_ID = ResourceLocation.fromNamespaceAndPath("pointblank", "thraxan_blaster");
    public static final int FE_PER_SHOT = 50_000;
    public static final int MAX_SHOTS = 100;                    // = maxAmmoCapacity в items/flaxan_blaster.json
    public static final int CAPACITY = FE_PER_SHOT * MAX_SHOTS; // 5 000 000 FE
    public static final int MAX_RECEIVE = 250_000;              // полный заряд за 20 тиков

    private static final ResourceLocation PB_TAG = ResourceLocation.fromNamespaceAndPath("pointblank", "custom_tag");
    private static final ResourceLocation PB_TS = ResourceLocation.fromNamespaceAndPath("pointblank", "ts");

    public static final DeferredRegister<DataComponentType<?>> COMPONENTS =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, "sable_compat");

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> PENDING_FE =
            COMPONENTS.register("blaster_pending_fe", () -> DataComponentType.<Integer>builder()
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT)
                    .build());

    public static void register(IEventBus modEventBus) {
        if (!ModList.get().isLoaded("pointblank")) return;
        COMPONENTS.register(modEventBus);
        modEventBus.addListener(FlaxanBlasterEnergy::onRegisterCapabilities);
        modEventBus.addListener(FlaxanBlasterEnergy::onRegister);
    }

    /**
     * Алиас старого id. Так же делает Create (RemapHelper): addAlias в RegisterEvent,
     * до снимка реестров; NeoForge (BaseMappedRegistry.resolve) подставляет новое имя
     * при любом поиске по старому, если старого предмета в реестре нет, и передаёт
     * алиасы клиенту в снимке реестра.
     */
    private static void onRegister(RegisterEvent event) {
        if (event.getRegistryKey().equals(Registries.ITEM)) {
            event.getRegistry().addAlias(LEGACY_ITEM_ID, ITEM_ID);
        }
    }

    private static void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
        Item item = blasterItem();
        if (item == null) return;
        event.registerItem(Capabilities.EnergyStorage.ITEM, (stack, ctx) -> new Storage(stack), item);
    }

    public static Item blasterItem() {
        return BuiltInRegistries.ITEM.getOptional(ITEM_ID).orElse(null);
    }

    public static boolean isBlaster(ItemStack stack) {
        return !stack.isEmpty() && ITEM_ID.equals(BuiltInRegistries.ITEM.getKey(stack.getItem()));
    }

    // ================= доступ к данным Point Blank =================

    @SuppressWarnings("unchecked")
    private static DataComponentType<CompoundTag> tagType() {
        return (DataComponentType<CompoundTag>) BuiltInRegistries.DATA_COMPONENT_TYPE.get(PB_TAG);
    }

    @SuppressWarnings("unchecked")
    private static DataComponentType<Long> tsType() {
        return (DataComponentType<Long>) BuiltInRegistries.DATA_COMPONENT_TYPE.get(PB_TS);
    }

    /** Пушку уже инициализировал Point Blank (GunItem.ensureItemStack: mid/lid заданы). */
    private static boolean initialized(ItemStack stack) {
        DataComponentType<CompoundTag> type = tagType();
        CompoundTag tag = type == null ? null : stack.get(type);
        return tag != null && (tag.getLong("mid") != 0L || tag.getLong("lid") != 0L);
    }

    public static int shots(ItemStack stack) {
        DataComponentType<CompoundTag> type = tagType();
        CompoundTag tag = type == null ? null : stack.get(type);
        return tag == null || !initialized(stack) ? 0 : Math.max(0, Math.min(tag.getInt("ammo"), MAX_SHOTS));
    }

    /**
     * Запись патронов. Тег копируется: стек при синхронизации контейнера сравнивается
     * по компонентам, и правка того же объекта на месте клиенту не ушла бы. Отметка
     * времени — как в MiscUtil.setTag у самого Point Blank.
     */
    private static void setShots(ItemStack stack, int shots) {
        DataComponentType<CompoundTag> type = tagType();
        if (type == null) return;
        CompoundTag old = stack.get(type);
        CompoundTag tag = old == null ? new CompoundTag() : old.copy();
        tag.putInt("ammo", shots);
        stack.set(type, tag);
        DataComponentType<Long> ts = tsType();
        if (ts != null) stack.set(ts, System.currentTimeMillis());
    }

    public static int pending(ItemStack stack) {
        Integer v = stack.get(PENDING_FE.get());
        return v == null ? 0 : Math.max(0, v);
    }

    private static void setPending(ItemStack stack, int value) {
        if (value <= 0) stack.remove(PENDING_FE.get());
        else stack.set(PENDING_FE.get(), value);
    }

    public static int energy(ItemStack stack) {
        return Math.min(CAPACITY, shots(stack) * FE_PER_SHOT + pending(stack));
    }

    /**
     * Встроенный прицел — выбранный «прицел» пушки.
     *
     * PIP Point Blank рисует только для выбранного прицела: PipItemLayer берёт
     * PipFeature.getSelected(стек) = фича предмета из Attachments.getSelectedAttachment
     * (стек, SCOPE), а это путь из тега {@code sa.scope} ({@code "/"} — сама пушка).
     * Путь выставляет Attachments.selectNextAttachment, но он сразу выходит, если у
     * пушки нет совместимых обвесов (getCompatibleAttachments().isEmpty()) — у
     * бластера их нет, тег пуст, и линза не рисовалась. Пишем ровно то, что Point
     * Blank записал бы сам для пушки со своей фичей Aiming (как у встроенных прицелов
     * cp2077 osprey/hercules); ensureValidAttachmentSelected такой выбор принимает.
     */
    public static void ensureBuiltInScopeSelected(ItemStack stack) {
        DataComponentType<CompoundTag> type = tagType();
        if (type == null || !initialized(stack)) return;
        CompoundTag old = stack.get(type);
        if (old == null || "/".equals(old.getCompound("sa").getString("scope"))) return;
        CompoundTag tag = old.copy();
        CompoundTag sa = tag.getCompound("sa");
        sa.putString("scope", "/");
        tag.put("sa", sa);
        stack.set(type, tag);
        DataComponentType<Long> ts = tsType();
        if (ts != null) stack.set(ts, System.currentTimeMillis());
    }

    /** Накопленный остаток — в патроны, если пушка уже инициализирована. */
    public static void fold(ItemStack stack) {
        int pend = pending(stack);
        if (pend < FE_PER_SHOT || !initialized(stack)) return;
        int shots = shots(stack);
        int add = Math.min(MAX_SHOTS - shots, pend / FE_PER_SHOT);
        if (add <= 0) return;
        setShots(stack, shots + add);
        setPending(stack, pend - add * FE_PER_SHOT);
    }

    /** Ёмкость предмета: принимает, не отдаёт. */
    public static final class Storage implements IEnergyStorage {
        private final ItemStack stack;

        public Storage(ItemStack stack) { this.stack = stack; }

        @Override
        public int receiveEnergy(int max, boolean simulate) {
            if (max <= 0) return 0;
            int accepted = Math.min(Math.min(max, MAX_RECEIVE), CAPACITY - energy(stack));
            if (accepted <= 0) return 0;
            if (!simulate) {
                setPending(stack, pending(stack) + accepted);
                fold(stack);
            }
            return accepted;
        }

        @Override public int extractEnergy(int max, boolean simulate) { return 0; }
        @Override public int getEnergyStored() { return energy(stack); }
        @Override public int getMaxEnergyStored() { return CAPACITY; }
        @Override public boolean canExtract() { return false; }
        @Override public boolean canReceive() { return true; }
    }
}
