package com.invfix.compat;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.yggdrasil.ProfileResult;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.slf4j.Logger;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Загрузка скинов «особых» посетителей MineColonies вне общего пула Minecraft.
 *
 * Оригинал (VisitorDataView.getCustomTexture, MineColonies 1.21) вызывается каждый
 * кадр, пока посетитель в поле зрения, и КАЖДЫЙ кадр, пока профиль не получен,
 * кладёт новый запрос fetchProfile в Util.backgroundExecutor(). Если сервер
 * сессий отвечает медленно или не отвечает (authlib ely у TLauncher), запросы
 * копятся, все потоки Worker-Main висят на чтении из сокета, и встаёт всё, что
 * живёт на этом пуле — в том числе обфускация чанков AntiXray (без неё
 * соединение придерживает ВСЕ пакеты клиенту) и работа с чанками сервера.
 *
 * Здесь: один запрос на UUID за раз, на собственном единственном фоновом потоке;
 * неудача запоминается и повторяется не раньше чем через 10 минут.
 */
@OnlyIn(Dist.CLIENT)
public final class MinecoloniesSkinFetcher {

    private MinecoloniesSkinFetcher() {}

    private static final Logger LOGGER = LogUtils.getLogger();
    private static final long RETRY_AFTER_FAILURE_MS = 10L * 60L * 1000L;

    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "invfix-minecolonies-skin-fetch");
        t.setDaemon(true);
        t.setPriority(Thread.MIN_PRIORITY);
        return t;
    });

    /** Состояние по UUID: в работе, получен профиль или неудача (с моментом). */
    private record Entry(boolean inFlight, GameProfile profile, long failedAt) {}

    private static final Map<UUID, Entry> CACHE = new ConcurrentHashMap<>();

    /**
     * Профиль, если уже получен; иначе null и (не чаще раза на UUID) фоновая загрузка.
     * Зовётся из потока отрисовки.
     */
    public static GameProfile getOrRequest(UUID id) {
        if (id == null) return null;
        Entry e = CACHE.get(id);
        if (e != null) {
            if (e.profile() != null) return e.profile();
            if (e.inFlight()) return null;
            if (System.currentTimeMillis() - e.failedAt() < RETRY_AFTER_FAILURE_MS) return null;
        }
        Entry pending = new Entry(true, null, 0L);
        boolean claimed = e == null ? CACHE.putIfAbsent(id, pending) == null : CACHE.replace(id, e, pending);
        if (!claimed) return null;

        EXECUTOR.execute(() -> {
            GameProfile got = null;
            try {
                ProfileResult result = Minecraft.getInstance().getMinecraftSessionService().fetchProfile(id, true);
                if (result != null) got = result.profile();
            } catch (Throwable t) {
                LOGGER.debug("MineColonies visitor skin fetch failed for {}: {}", id, t.toString());
            }
            CACHE.put(id, got != null ? new Entry(false, got, 0L) : new Entry(false, null, System.currentTimeMillis()));
        });
        return null;
    }
}
