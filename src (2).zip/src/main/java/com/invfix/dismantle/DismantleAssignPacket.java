package com.invfix.dismantle;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Клиент → Сервер: выбрать Dismantle как текущую способность (для назначения в слот). */
public record DismantleAssignPacket(int x, int y, int z) implements CustomPacketPayload {

    public static final Type<DismantleAssignPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "dismantle_assign"));

    public static final StreamCodec<FriendlyByteBuf, DismantleAssignPacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, m) -> { buf.writeInt(m.x()); buf.writeInt(m.y()); buf.writeInt(m.z()); },
                    buf -> new DismantleAssignPacket(buf.readInt(), buf.readInt(), buf.readInt()));

    @Override public Type<DismantleAssignPacket> type() { return TYPE; }

    public static void handleServer(DismantleAssignPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer player)) return;
            try {
                InvincibleIncModVariables.PlayerVariables vars =
                        player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                if (!DismantleHandler.isEligible(vars.Race)) return;
                if (vars.Lvl < DismantleHandler.LVL_REQUIRED) return;
                vars.AbilitySet = DismantleHandler.ABILITY;
                vars.abilityDescription = DismantleHandler.ABILITY + " | LVL:" + DismantleHandler.LVL_REQUIRED
                        + " | Разрез (Shift — настройка)";
                vars.markSyncDirty();
            } catch (Exception ignored) {}
        });
    }
}
