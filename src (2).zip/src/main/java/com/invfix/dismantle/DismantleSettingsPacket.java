package com.invfix.dismantle;

import com.invfix.dismantle.client.DismantleClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Настройки Dismantle в обе стороны: клиент → сервер — сохранить из меню;
 * сервер → клиент — что сохранено (при входе в мир).
 */
public record DismantleSettingsPacket(double length, double depth, double angle) implements CustomPacketPayload {

    public static final Type<DismantleSettingsPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "dismantle_settings"));

    public static final StreamCodec<FriendlyByteBuf, DismantleSettingsPacket> STREAM_CODEC = StreamCodec.of(
            (buf, m) -> {
                buf.writeDouble(m.length());
                buf.writeDouble(m.depth());
                buf.writeDouble(m.angle());
            },
            buf -> new DismantleSettingsPacket(buf.readDouble(), buf.readDouble(), buf.readDouble()));

    @Override
    public Type<DismantleSettingsPacket> type() {
        return TYPE;
    }

    public static void handleServer(DismantleSettingsPacket p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer player) {
                new DismantleSettings(p.length, p.depth, p.angle).save(player);
            }
        });
    }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(DismantleSettingsPacket p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> DismantleClient.setSettings(new DismantleSettings(p.length, p.depth, p.angle)));
    }
}
