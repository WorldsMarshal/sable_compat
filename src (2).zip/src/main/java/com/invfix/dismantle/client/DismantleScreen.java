package com.invfix.dismantle.client;

import com.invfix.dismantle.DismantleSettings;
import com.mojang.math.Axis;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

/**
 * Меню настройки Dismantle (Shift + клавиша способности).
 *
 *  - Длина разреза, блоков (5–25, по умолчанию 20) — поле ввода;
 *  - Глубина разреза, блоков (1–10) — поле ввода;
 *  - Угол — круг с самим разрезом: его тянут мышью, и он лежит так, как ляжет в
 *    мире (0° — горизонтально, плюс — против часовой стрелки на экране); колесо
 *    мыши — по 1°, с Shift — шаг 15°. Длина разреза в круге — от настройки длины.
 *
 * Сохранить — Enter или кнопка; Esc / «Отмена» — выйти без изменений.
 */
@OnlyIn(Dist.CLIENT)
public final class DismantleScreen extends Screen {

    private static final int W = 330, H = 236;
    private static final int DIAL_R = 76;
    private static final int PANEL = 0xF0141416, FRAME = 0xFF3C3C42, ACCENT = 0xFFE8E8E8, MUTED = 0xFF9A9AA2;
    private static final int DIAL_BG = 0xFF676767, DIAL_RING = 0xFF2A2A2E, TICK = 0xFF4A4A4E;

    private double angle;
    private EditBox lengthBox;
    private EditBox depthBox;
    private boolean dragging;
    private String error = "";

    private int left, top, cx, cy;

    public DismantleScreen(DismantleSettings current) {
        super(Component.literal("Dismantle"));
        this.angle = current.angle();
        this.initial = current;
    }

    private final DismantleSettings initial;

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        cx = left + 18 + DIAL_R;
        cy = top + 34 + DIAL_R;
        int fx = left + 196;

        lengthBox = new EditBox(font, fx, top + 52, 110, 18, Component.literal("Длина"));
        lengthBox.setMaxLength(5);
        lengthBox.setFilter(s -> s.matches("\\d{0,2}([.,]\\d?)?"));
        lengthBox.setValue(format(initial.length()));
        addRenderableWidget(lengthBox);

        depthBox = new EditBox(font, fx, top + 98, 110, 18, Component.literal("Глубина"));
        depthBox.setMaxLength(5);
        depthBox.setFilter(s -> s.matches("\\d{0,2}([.,]\\d?)?"));
        depthBox.setValue(format(initial.depth()));
        addRenderableWidget(depthBox);

        addRenderableWidget(Button.builder(Component.literal("Сохранить"), b -> saveAndClose())
                .bounds(fx, top + H - 52, 110, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Отмена"), b -> onClose())
                .bounds(fx, top + H - 30, 110, 18).build());
        setInitialFocus(lengthBox);
    }

    private static String format(double v) {
        return v == Math.rint(v) ? String.valueOf((int) v) : String.format(Locale.ROOT, "%.1f", v);
    }

    private static double parse(String s, double fallback) {
        try {
            return s.isBlank() ? fallback : Double.parseDouble(s.replace(',', '.'));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private double lengthNow() {
        return Mth.clamp(parse(lengthBox.getValue(), initial.length()),
                DismantleSettings.MIN_LENGTH, DismantleSettings.MAX_LENGTH);
    }

    private void saveAndClose() {
        double len = parse(lengthBox.getValue(), initial.length());
        double dep = parse(depthBox.getValue(), initial.depth());
        DismantleClient.save(new DismantleSettings(len, dep, angle));
        onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ── угол мышью ─────────────────────────────────────────────────────────

    private boolean overDial(double mx, double my) {
        return Mth.square(mx - cx) + Mth.square(my - cy) <= Mth.square(DIAL_R + 8);
    }

    private void aimAt(double mx, double my) {
        double a = Math.toDegrees(Math.atan2(cy - my, mx - cx));
        // разрез — линия: 30° и 210° — одно и то же
        if (a > 90.0) a -= 180.0;
        if (a <= -90.0) a += 180.0;
        if (hasShiftDown()) a = Math.round(a / 15.0) * 15.0;
        angle = Math.round(a);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && overDial(mx, my)) {
            dragging = true;
            aimAt(mx, my);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            aimAt(mx, my);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (overDial(mx, my) && scrollY != 0.0) {
            double step = hasShiftDown() ? 15.0 : 1.0;
            double a = angle + Math.signum(scrollY) * step;
            if (a > 90.0) a -= 180.0;
            if (a <= -90.0) a += 180.0;
            angle = a;
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            saveAndClose();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    // ── рисование ──────────────────────────────────────────────────────────

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float partial) {
        super.renderBackground(g, mx, my, partial);
        g.fill(left - 1, top - 1, left + W + 1, top + H + 1, FRAME);
        g.fill(left, top, left + W, top + H, PANEL);
        g.fill(left, top, left + W, top + 22, 0xF0202024);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        super.render(g, mx, my, partial);
        int fx = left + 196;
        g.drawString(font, "DISMANTLE  ·  настройка разреза", left + 10, top + 7, ACCENT, false);

        g.drawString(font, "Длина разреза, блоков", fx, top + 40, ACCENT, false);
        g.drawString(font, "от 5 до 25", fx + 112 - font.width("от 5 до 25") - 2, top + 74, MUTED, false);
        g.drawString(font, "Глубина разреза, блоков", fx, top + 86, ACCENT, false);
        g.drawString(font, "от 1 до 10", fx + 112 - font.width("от 1 до 10") - 2, top + 120, MUTED, false);
        g.drawString(font, "Толщина: " + com.invfix.dismantle.DismantleHandler.THICKNESS + " блока", fx, top + 136, MUTED, false);

        drawDial(g, mx, my);

        g.drawCenteredString(font, String.format(Locale.ROOT, "Угол: %+d°", (int) Math.round(angle)),
                cx, cy + DIAL_R + 8, ACCENT);
        g.drawCenteredString(font, "тяни мышью · колесо ±1° · Shift — 15°", cx, cy + DIAL_R + 20, MUTED);
    }

    private void drawDial(GuiGraphics g, int mx, int my) {
        int r = DIAL_R;
        // серый круг — как на референсе
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.round(Math.sqrt(r * r - dy * dy));
            g.fill(cx - half, cy + dy, cx + half, cy + dy + 1, DIAL_BG);
        }
        // обод и деления каждые 15°
        for (int i = 0; i < 360; i++) {
            double a = Math.toRadians(i);
            int x = (int) Math.round(cx + Math.cos(a) * (r + 1));
            int y = (int) Math.round(cy - Math.sin(a) * (r + 1));
            g.fill(x, y, x + 1, y + 1, DIAL_RING);
        }
        for (int deg = 0; deg < 360; deg += 15) {
            double a = Math.toRadians(deg);
            int len = deg % 90 == 0 ? 8 : deg % 45 == 0 ? 6 : 3;
            for (int k = 0; k < len; k++) {
                int x = (int) Math.round(cx + Math.cos(a) * (r - 2 - k));
                int y = (int) Math.round(cy - Math.sin(a) * (r - 2 - k));
                g.fill(x, y, x + 1, y + 1, TICK);
            }
        }

        // сам разрез: чёрная линза с белой окантовкой, иглами к концам
        double lengthPx = (r - 6) * 2.0 * (lengthNow() / DismantleSettings.MAX_LENGTH);
        float half = (float) (lengthPx * 0.5);
        float thick = Math.max(2.2F, half * 0.055F);
        var pose = g.pose();
        pose.pushPose();
        pose.translate(cx, cy, 0.0F);
        pose.mulPose(Axis.ZP.rotationDegrees((float) -angle));
        int steps = 4; // четверть пикселя — край ровный и под углом
        pose.scale(1.0F / steps, 1.0F / steps, 1.0F);
        int n = (int) (half * steps);
        for (int i = -n; i < n; i++) {
            float a = (i + 0.5F) / (half * steps);
            float tw = Math.max(0.0F, 1.0F - a * a);
            float tb = Math.max(0.0F, 1.0F - (a / 0.84F) * (a / 0.84F));
            float blackHalf = thick * (float) Math.pow(tb, 0.75);
            float whiteHalf = Math.max(blackHalf + Math.max(1.0F, thick * 0.3F), thick * 0.35F * (float) Math.pow(tw, 1.5));
            int w = Math.round(whiteHalf * steps);
            int b = Math.round(blackHalf * steps);
            // мягкое белое свечение
            int glow = Math.round((whiteHalf + 2.5F) * steps);
            g.fill(i, -glow, i + 1, glow, 0x30FFFFFF);
            if (w > 0) g.fill(i, -w, i + 1, w, 0xFFF4F4F4);
            if (b > 0) g.fill(i, -b, i + 1, b, 0xFF060606);
        }
        pose.popPose();

        // ручка на конце разреза
        double ar = Math.toRadians(angle);
        int hx = (int) Math.round(cx + Math.cos(ar) * (r - 4));
        int hy = (int) Math.round(cy - Math.sin(ar) * (r - 4));
        boolean hot = dragging || overDial(mx, my);
        g.fill(hx - 3, hy - 3, hx + 4, hy + 4, hot ? 0xFFFFFFFF : 0xFFBDBDBD);
        g.fill(hx - 2, hy - 2, hx + 3, hy + 3, 0xFF141416);
    }
}
