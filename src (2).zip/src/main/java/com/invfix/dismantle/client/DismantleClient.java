package com.invfix.dismantle.client;

import com.invfix.altrumite.AltrumiteRace;
import com.invfix.dismantle.DismantleHandler;
import com.invfix.dismantle.DismantleSettings;
import com.invfix.dismantle.DismantleSettingsPacket;
import com.mojang.blaze3d.platform.InputConstants;
import net.mcreator.invincibleinc.init.InvincibleIncModKeyMappings;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

/**
 * Клиент Dismantle: настройки разреза (что сохранено на сервере — приходит при
 * входе) и меню настройки по Shift + клавиша слота, где стоит Dismantle (сервер
 * на нажатие с Shift не режет).
 */
@OnlyIn(Dist.CLIENT)
public final class DismantleClient {

    private static DismantleSettings settings = DismantleSettings.DEFAULT;
    private static boolean wasDown;

    private DismantleClient() {}

    public static DismantleSettings settings() {
        return settings;
    }

    public static void setSettings(DismantleSettings s) {
        settings = s;
    }

    /** Из меню: запомнить и отправить на сервер. */
    public static void save(DismantleSettings s) {
        settings = s;
        PacketDistributor.sendToServer(new DismantleSettingsPacket(s.length(), s.depth(), s.angle()),
                new CustomPacketPayload[0]);
    }

    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
    public static final class GameBus {

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) {
                wasDown = false;
                return;
            }
            boolean down = mc.screen == null && slotKeyDown(mc);
            if (down && !wasDown && rawDown(mc, mc.options.keyShift)) {
                mc.setScreen(new DismantleScreen(settings));
            }
            wasDown = down;
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            settings = DismantleSettings.DEFAULT;
            wasDown = false;
        }
    }

    /** Зажата ли клавиша слота, в котором стоит Dismantle (текущий ряд). */
    private static boolean slotKeyDown(Minecraft mc) {
        try {
            InvincibleIncModVariables.PlayerVariables v = mc.player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (!AltrumiteRace.isAltrumite(v.Race)) return false;
            boolean row1 = v.AbilityRow == 1.0;
            String[] slots = {
                    row1 ? v.AbilitySlot1 : v.AbilitySlot1_row2,
                    row1 ? v.AbilitySlot2 : v.AbilitySlot2_row2,
                    row1 ? v.AbilitySlot3 : v.AbilitySlot3_row2,
                    row1 ? v.AbilitySlot4 : v.AbilitySlot4_row2,
                    row1 ? v.AbilitySlot5 : v.AbilitySlot5_row2};
            KeyMapping[] keys = {
                    InvincibleIncModKeyMappings.ABILITY_1, InvincibleIncModKeyMappings.ABILITY_2,
                    InvincibleIncModKeyMappings.ABILITY_3, InvincibleIncModKeyMappings.ABILITY_4,
                    InvincibleIncModKeyMappings.ABILITY_5};
            for (int i = 0; i < 5; i++) {
                if (DismantleHandler.ABILITY.equals(slots[i]) && rawDown(mc, keys[i])) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    /** Физическое состояние клавиши, мимо модификаторов (как HeatVisionClientHandler.rawDown). */
    private static boolean rawDown(Minecraft mc, KeyMapping km) {
        if (km == null) return false;
        InputConstants.Key key = km.getKey();
        if (key == null || key.getValue() == InputConstants.UNKNOWN.getValue()) return false;
        long window = mc.getWindow().getWindow();
        return switch (key.getType()) {
            case KEYSYM -> InputConstants.isKeyDown(window, key.getValue());
            case MOUSE -> GLFW.glfwGetMouseButton(window, key.getValue()) == GLFW.GLFW_PRESS;
            default -> km.isDown();
        };
    }
}
