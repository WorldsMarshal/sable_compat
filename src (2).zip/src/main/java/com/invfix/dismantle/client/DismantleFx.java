package com.invfix.dismantle.client;

import com.invfix.dismantle.DismantleHandler;
import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/**
 * Dismantle на клиенте: импакт-кадры 0.35 с, чёрно-белые, и сам разрез —
 * чёрная линза с белой окантовкой (composite.fsh, drawCut) — только на эти
 * 0.35 с, вне кадров его нет. Разрез лежит там, где лёг в мире: середина,
 * направление и длина — из пакета (настройки стрелявшего), на экран
 * проецируется каждый кадр.
 *
 * Кадры и разрез видны, только пока разрез попадает в поле зрения (хоть часть
 * его на экране) или камера — сам игрок — стоит в зоне урона разреза. Иначе
 * не видно ни того, ни другого. Проверяется каждый кадр.
 */
@OnlyIn(Dist.CLIENT)
public final class DismantleFx extends FxEffect {

    /** Кадры: белая вспышка, потом 40 / 41 (светлое на чёрном / наоборот) — всего 0.35 с. */
    private static final float FLASH = 0.03F;
    private static final float[][] FRAMES = {{40, 0.08F}, {41, 0.08F}, {40, 0.08F}, {41, 0.08F}};
    private static final float TOTAL = 0.35F;
    /** Разрез начинается чуть перед точкой попадания (как на сервере), блоков. */
    private static final double FRONT = 0.5;

    private final ClientLevel level;
    private final Vec3 center;
    private final Vec3 u;
    private final Vec3 v;
    private final Vec3 f;
    private final float length;
    private final float depth;
    /** Толщина ×1.5, если стрелявший в режиме Sentry. */
    private final double thick;

    private DismantleFx(ClientLevel level, Vec3 center, Vec3 u, Vec3 v, Vec3 f, float length, float depth,
                        double thick) {
        this.thick = thick;
        this.level = level;
        this.center = center;
        this.u = u;
        this.v = v;
        this.f = f;
        this.length = length;
        this.depth = depth;
    }

    public static void start(int casterId, double x, double y, double z, float ux, float uy, float uz,
                             float vx, float vy, float vz, float fx, float fy, float fz, float length, float depth) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        Vec3 c = new Vec3(x, y, z);
        boolean sentry = com.invfix.sentry.client.SentryClient.isActive(casterId);
        FxManager.add(new DismantleFx(level, c, new Vec3(ux, uy, uz).normalize(), new Vec3(vx, vy, vz).normalize(),
                new Vec3(fx, fy, fz).normalize(), length, depth,
                sentry ? com.invfix.sentry.SentryHandler.DESTRUCTION_MULT : 1.0));
        // The Whole Sentry Power: белые разряды по разрезу
        com.invfix.sentry.client.SentryClient.arcsIfSentry(casterId, c, length * 0.5F);
    }

    @Override
    protected int duration() {
        return 9;
    }

    @Override
    public boolean finished() {
        return super.finished() || Minecraft.getInstance().level != level;
    }

    @Override
    public Vec3 focus() {
        return center;
    }

    @Override
    public double range() {
        return 400.0;
    }

    private boolean shook;

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        float s = ticks(frame) / 20.0F;
        if (s >= TOTAL) return;
        if (!onScreen() && !viewerInZone(frame)) return;

        if (!shook) {
            shook = true;
            FxManager.shake(center, 0.35F, 64.0);
        }
        if (s < FLASH) {
            screen.addFlash(0xFFFFFF, 1.3F);
        } else {
            float into = s - FLASH;
            for (float[] fr : FRAMES) {
                if (into < fr[1]) {
                    float[] uv = FxManager.uv(center);
                    screen.addImpact(1.0F, (int) fr[0], uv[0], uv[1]);
                    break;
                }
                into -= fr[1];
            }
        }

        // разрез — только пока идут кадры
        Vec3 a = center.add(u.scale(-length * 0.5));
        Vec3 b = center.add(u.scale(length * 0.5));
        float[] pa = FxManager.uvRaw(a);
        float[] pb = FxManager.uvRaw(b);
        if (pa[2] <= 0.05F && pb[2] <= 0.05F) return;
        if (pa[2] <= 0.05F) pa = FxManager.uvRaw(inFront(b, a));
        if (pb[2] <= 0.05F) pb = FxManager.uvRaw(inFront(a, b));
        // полуширина: доля длины, чуть больше, чем у разреза на картинке
        float[] mid = FxManager.uvRaw(center);
        float[] pw = FxManager.uvRaw(center.add(v.scale(length * 0.018 * thick)));
        float aspect = (float) frame.minecraft().getWindow().getWidth() / Math.max(1, frame.minecraft().getWindow().getHeight());
        float halfWidth = mid[2] > 0.05F && pw[2] > 0.05F
                ? (float) Math.hypot((pw[0] - mid[0]) * aspect, pw[1] - mid[1]) : 0.0F;
        screen.cutX0 = pa[0];
        screen.cutY0 = pa[1];
        screen.cutX1 = pb[0];
        screen.cutY1 = pb[1];
        screen.cutWidth = halfWidth;
        screen.cut = 1.0F;
    }

    /** Хоть часть разреза на экране (перед камерой и внутри кадра). */
    private boolean onScreen() {
        for (int i = 0; i <= 16; i++) {
            Vec3 p = center.add(u.scale(length * (i / 16.0 - 0.5)));
            float[] uv = FxManager.uvRaw(p);
            if (uv[2] > 0.05F && uv[0] >= 0.0F && uv[0] <= 1.0F && uv[1] >= 0.0F && uv[1] <= 1.0F) return true;
        }
        return false;
    }

    /** Камера (игрок) в зоне урона разреза — те же границы, что у урона на сервере. */
    private boolean viewerInZone(FxFrame frame) {
        Entity cam = frame.minecraft().getCameraEntity();
        if (cam == null) return false;
        Vec3 q = cam.getBoundingBox().getCenter().subtract(center);
        double margin = Math.max(cam.getBbWidth(), cam.getBbHeight()) * 0.5;
        double a = q.dot(u), b = q.dot(v), c = q.dot(f);
        double half = length * 0.5;
        if (Math.abs(a) > half + margin) return false;
        if (c < -FRONT - margin || c > depth + margin) return false;
        return Math.abs(b) <= DismantleHandler.halfThickness(Math.max(-half, Math.min(half, a)), length, thick) + margin;
    }

    /** Точка на отрезке от seen (перед камерой) к hidden (за ней), ещё перед камерой. */
    private static Vec3 inFront(Vec3 seen, Vec3 hidden) {
        Vec3 lo = seen, hi = hidden;
        for (int i = 0; i < 16; i++) {
            Vec3 m = lo.add(hi).scale(0.5);
            if (FxManager.uvRaw(m)[2] > 0.05F) lo = m;
            else hi = m;
        }
        return lo;
    }
}
