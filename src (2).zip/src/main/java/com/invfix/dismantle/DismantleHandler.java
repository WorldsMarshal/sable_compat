package com.invfix.dismantle;

import com.invfix.altrumite.AltrumiteRace;
import net.mcreator.invincibleinc.init.InvincibleIncModGameRules;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Dismantle (Сукуна) — способность Metroman (Alien(Metroman)), LVL 100.
 *
 * Нажатие — разрез в цель под прицелом: первая сущность или блок на луче
 * взгляда до {@link #RANGE} блоков (только прогруженные чанки). С Shift вместо
 * разреза открывается меню настройки (клиент, DismantleClient), и сервер не
 * режет.
 *
 * Разрез лежит в плоскости экрана стрелявшего на момент нажатия: линия длиной
 * {@link DismantleSettings#length} под углом {@link DismantleSettings#angle}
 * (0° — горизонтально, плюс — против часовой, как в меню), толщиной
 * {@link #THICKNESS} (в середине; к остриям сходится в ноль, как сам разрез на
 * картинке), и уходит вглубь по взгляду на {@link DismantleSettings#depth}
 * блоков от точки попадания. Сносится и весь клин между глазами стрелявшего и
 * разрезом — всё, через что разрез прошёл. Всё это исчезает (кроме бедрока; геймрул
 * invincibleBlockDestruction). Урон — один раз половина Attackpwr: цели и
 * всему живому в самом разрезе с его глубиной.
 *
 * Один разрез на нажатие: удержание клавиши не режет очередью.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class DismantleHandler {

    public static final String ABILITY = "§f§lDismantle";
    public static final int LVL_REQUIRED = 100;
    public static final double RANGE = 156.0;
    /** Толщина разреза в середине, блоков. */
    public static final double THICKNESS = 1.5;
    /** Разрез начинается чуть перед точкой попадания, блоков. */
    private static final double FRONT = 0.5;
    private static final double SEND_RANGE = 200.0;

    private static final ResourceKey<DamageType> DAMAGE = ResourceKey.create(Registries.DAMAGE_TYPE,
            ResourceLocation.parse("sable_compat:dismantle"));

    /** Последний тик, в который клавиша способности была зажата (для «одно нажатие — один разрез»). */
    private static final Map<UUID, Long> HELD = new ConcurrentHashMap<>();

    private DismantleHandler() {}

    public static boolean isEligible(String race) {
        return AltrumiteRace.isAltrumite(race);
    }

    // ── нажатие (из AbilityCallProcedureMixin, каждый тик, пока клавиша зажата) ──

    public static void onKeyHeld(ServerPlayer player) {
        long now = player.level().getGameTime();
        Long last = HELD.put(player.getUUID(), now);
        if (last != null && now - last <= 1) return; // всё ещё то же нажатие
        if (player.isShiftKeyDown()) return;         // Shift — меню настройки на клиенте
        try {
            InvincibleIncModVariables.PlayerVariables v = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if (!isEligible(v.Race) || v.Lvl < LVL_REQUIRED) return;
            cut(player, v.attackPower);
        } catch (Exception ignored) {}
    }

    private static void cut(ServerPlayer player, double attackPower) {
        ServerLevel level = (ServerLevel) player.level();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        if (look.lengthSqr() < 1.0E-6) return;
        Vec3 f = look.normalize();

        // цель: блок или сущность на луче, что ближе, в пределах прогруженного
        double reach = loadedReach(level, eye, f, RANGE);
        if (reach <= 0.0) return;
        Vec3 end = eye.add(f.scale(reach));
        BlockHitResult bh = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        boolean blockHit = bh.getType() != HitResult.Type.MISS;
        Vec3 target = blockHit ? bh.getLocation() : null;
        double best = blockHit ? eye.distanceTo(target) : reach;
        LivingEntity victim = null;
        for (Entity e : level.getEntities(player, new AABB(eye, eye.add(f.scale(best))).inflate(1.0),
                ent -> ent instanceof LivingEntity le && le.isAlive() && ent != player)) {
            var clip = e.getBoundingBox().inflate(0.3).clip(eye, eye.add(f.scale(best)));
            if (clip.isPresent()) {
                double d = eye.distanceTo(clip.get());
                if (d < best) {
                    best = d;
                    victim = (LivingEntity) e;
                    target = clip.get();
                }
            }
        }
        if (target == null) return; // ни блока, ни сущности в 156 блоках

        DismantleSettings s = DismantleSettings.of(player);
        // The Whole Sentry Power: разрушения ×1.5 — глубже и толще
        double thick = com.invfix.sentry.SentryHandler.destruction(player);
        if (thick != 1.0) s = new DismantleSettings(s.length(), s.depth() * thick, s.angle());
        // плоскость экрана на момент нажатия: вправо и вверх
        double yaw = Math.toRadians(player.getYRot());
        Vec3 right = new Vec3(-Math.cos(yaw), 0.0, -Math.sin(yaw));
        Vec3 up = right.cross(f).normalize();
        double ang = Math.toRadians(s.angle());
        Vec3 u = right.scale(Math.cos(ang)).add(up.scale(Math.sin(ang))).normalize();
        Vec3 v = f.cross(u).normalize();

        // урон — один раз
        float damage = (float) (attackPower * 0.5);
        if (damage > 0.0F) {
            DamageSource source = new DamageSource(level.holderOrThrow(DAMAGE), player);
            double half = s.length() * 0.5;
            AABB box = new AABB(target, target).inflate(half + THICKNESS * thick + s.depth() + 2.0);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, t -> t != player && t.isAlive())) {
                double m = Math.max(e.getBbWidth(), e.getBbHeight()) * 0.5;
                if (e != victim && !inside(e.getBoundingBox().getCenter(), target, f, u, v, s, thick, m)) continue;
                e.invulnerableTime = 0;
                e.hurtTime = 0;
                e.hurt(source, damage);
            }
        }

        // блоки
        if (level.getGameRules().getBoolean(InvincibleIncModGameRules.INVINCIBLE_BLOCK_DESTRUCTION)) {
            carve(level, eye, target, f, u, v, s, thick);
        }

        // звук и картинка
        level.playSound(null, target.x, target.y, target.z, DismantleSounds.DISMANTLE.get(), SoundSource.PLAYERS,
                10.0F, 0.95F + level.random.nextFloat() * 0.1F);
        PacketDistributor.sendToPlayersNear(level, null, target.x, target.y, target.z, SEND_RANGE,
                new DismantlePacket(player.getId(), target.x, target.y, target.z,
                        (float) u.x, (float) u.y, (float) u.z, (float) v.x, (float) v.y, (float) v.z,
                        (float) f.x, (float) f.y, (float) f.z, (float) s.length(), (float) s.depth()));
    }

    /** Полутолщина разреза в точке a по длине: в середине THICKNESS/2, к остриям — ноль. */
    public static double halfThickness(double a, double length) {
        return halfThickness(a, length, 1.0);
    }

    /** То же, толщина × scale (режим Sentry). */
    public static double halfThickness(double a, double length, double scale) {
        double k = 1.0 - Mth.square(2.0 * a / length);
        return k <= 0.0 ? 0.0 : THICKNESS * scale * 0.5 * Math.sqrt(k);
    }

    private static boolean inside(Vec3 p, Vec3 t, Vec3 f, Vec3 u, Vec3 v, DismantleSettings s, double thick,
                                  double margin) {
        Vec3 q = p.subtract(t);
        double a = q.dot(u), b = q.dot(v), c = q.dot(f);
        double half = s.length() * 0.5;
        if (Math.abs(a) > half + margin) return false;
        if (c < -FRONT - margin || c > s.depth() + margin) return false;
        return Math.abs(b) <= halfThickness(Mth.clamp(a, -half, half), s.length(), thick) + margin;
    }

    /** Столько блоков от глаз не трогается — разрез не режет землю под ногами и самого стрелявшего. */
    private static final double CLEAR = 2.0;
    /** Шаг выборки точек по объёму разреза (меньше блока — без дыр). */
    private static final double STEP = 0.4;

    /**
     * Снос: сам разрез и его глубина за точкой попадания — и весь клин от глаз
     * стрелявшего до разреза: на расстоянии c по взгляду клин шириной
     * c / (до цели) × длина, той же толщины (у самых глаз сходится в ноль), так
     * что режется всё, через что прошёл разрез. Точки выбираются по объёму
     * разреза с шагом {@link #STEP}, каждый блок — один раз.
     */
    private static void carve(ServerLevel level, Vec3 eye, Vec3 t, Vec3 f, Vec3 u, Vec3 v, DismantleSettings s,
                              double thick) {
        double toCut = t.subtract(eye).dot(f);
        double end = toCut + s.depth();
        double fullHalf = s.length() * 0.5;
        it.unimi.dsi.fastutil.longs.LongOpenHashSet done = new it.unimi.dsi.fastutil.longs.LongOpenHashSet();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (double c = CLEAR; c <= end + 1e-6; c += STEP) {
            double k = c < toCut - FRONT ? c / Math.max(toCut, 1e-3) : 1.0;   // доля ширины клина
            double half = fullHalf * k;
            double ramp = Math.min(1.0, (c - CLEAR) / 2.0 + 0.25);            // у глаз толщина сходится
            for (double a = -half; a <= half + 1e-6; a += STEP) {
                double hb = half < 0.05 ? 0.25 : Math.max(halfThickness(a, half * 2.0, thick) * ramp, 0.25);
                for (double b = -hb; b <= hb + 1e-6; b += STEP) {
                    double x = eye.x + f.x * c + u.x * a + v.x * b;
                    double y = eye.y + f.y * c + u.y * a + v.y * b;
                    double z = eye.z + f.z * c + u.z * a + v.z * b;
                    pos.set(Mth.floor(x), Mth.floor(y), Mth.floor(z));
                    if (!done.add(pos.asLong())) continue;
                    if (pos.getY() < level.getMinBuildHeight() || pos.getY() >= level.getMaxBuildHeight()) continue;
                    if (!level.isLoaded(pos)) continue;
                    BlockState state = level.getBlockState(pos);
                    if (state.isAir() || state.is(Blocks.BEDROCK)) continue;
                    level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
    }

    private static double loadedReach(ServerLevel level, Vec3 origin, Vec3 dir, double max) {
        double step = 8.0, reached = 0.0;
        for (double d = step; d <= max + 1e-6; d += step) {
            if (!level.isLoaded(BlockPos.containing(origin.add(dir.scale(d))))) break;
            reached = d;
        }
        if (reached > 0.0 && reached >= max - step) reached = max;
        return reached;
    }

    // ── настройки: сохраняются за игроком, переживают смерть, приходят клиенту при входе ──

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            DismantleSettings s = DismantleSettings.of(player);
            PacketDistributor.sendToPlayer(player, new DismantleSettingsPacket(s.length(), s.depth(), s.angle()));
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        CompoundTag from = event.getOriginal().getPersistentData();
        if (from.contains(DismantleSettings.NBT)) {
            event.getEntity().getPersistentData().put(DismantleSettings.NBT, from.getCompound(DismantleSettings.NBT).copy());
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        HELD.remove(event.getEntity().getUUID());
    }
}
