package com.invfix.dismantle;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Звук Dismantle — присланный dismantle-1.mp3 как есть, только сведён в моно (иначе Minecraft не ставит звук в мир). */
public final class DismantleSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, "sable_compat");

    public static final DeferredHolder<SoundEvent, SoundEvent> DISMANTLE = SOUNDS.register("dismantle",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("sable_compat", "dismantle")));

    private DismantleSounds() {}
}
