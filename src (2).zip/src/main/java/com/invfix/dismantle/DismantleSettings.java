package com.invfix.dismantle;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

/**
 * Настройки разреза Dismantle (меню на Shift + клавиша способности): длина
 * 5–25 блоков (по умолчанию 20), глубина 1–10 (по умолчанию 5), угол в градусах
 * (0 — горизонтально, плюс — против часовой стрелки на экране). На сервере
 * хранятся в persistentData игрока.
 */
public record DismantleSettings(double length, double depth, double angle) {

    public static final double MIN_LENGTH = 5.0, MAX_LENGTH = 25.0, DEFAULT_LENGTH = 20.0;
    public static final double MIN_DEPTH = 1.0, MAX_DEPTH = 10.0, DEFAULT_DEPTH = 5.0;
    static final String NBT = "invfix_dismantle";

    public static final DismantleSettings DEFAULT = new DismantleSettings(DEFAULT_LENGTH, DEFAULT_DEPTH, 0.0);

    public DismantleSettings {
        length = Mth.clamp(length, MIN_LENGTH, MAX_LENGTH);
        depth = Mth.clamp(depth, MIN_DEPTH, MAX_DEPTH);
        angle = Mth.wrapDegrees(angle);
    }

    static DismantleSettings of(Player player) {
        CompoundTag data = player.getPersistentData();
        if (!data.contains(NBT)) return DEFAULT;
        CompoundTag t = data.getCompound(NBT);
        return new DismantleSettings(t.getDouble("length"), t.getDouble("depth"), t.getDouble("angle"));
    }

    void save(Player player) {
        CompoundTag t = new CompoundTag();
        t.putDouble("length", length);
        t.putDouble("depth", depth);
        t.putDouble("angle", angle);
        player.getPersistentData().put(NBT, t);
    }
}
