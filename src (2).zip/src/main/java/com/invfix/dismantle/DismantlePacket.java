package com.invfix.dismantle;

import com.invfix.dismantle.client.DismantleFx;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Сервер → клиенты: разрез Dismantle. Середина разреза (x, y, z), направление
 * вдоль него u, поперёк v (оба в плоскости экрана стрелявшего), взгляд
 * стрелявшего f (по нему глубина), длина и глубина — для зоны урона.
 */
public record DismantlePacket(int casterId, double x, double y, double z, float ux, float uy, float uz,
                              float vx, float vy, float vz, float fx, float fy, float fz,
                              float length, float depth) implements CustomPacketPayload {

    public static final Type<DismantlePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "dismantle"));

    public static final StreamCodec<FriendlyByteBuf, DismantlePacket> STREAM_CODEC = StreamCodec.of(
            (buf, m) -> {
                buf.writeVarInt(m.casterId());
                buf.writeDouble(m.x());
                buf.writeDouble(m.y());
                buf.writeDouble(m.z());
                buf.writeFloat(m.ux());
                buf.writeFloat(m.uy());
                buf.writeFloat(m.uz());
                buf.writeFloat(m.vx());
                buf.writeFloat(m.vy());
                buf.writeFloat(m.vz());
                buf.writeFloat(m.fx());
                buf.writeFloat(m.fy());
                buf.writeFloat(m.fz());
                buf.writeFloat(m.length());
                buf.writeFloat(m.depth());
            },
            buf -> new DismantlePacket(buf.readVarInt(), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                    buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(),
                    buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat()));

    @Override
    public Type<DismantlePacket> type() {
        return TYPE;
    }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(DismantlePacket p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> DismantleFx.start(p.casterId, p.x, p.y, p.z, p.ux, p.uy, p.uz, p.vx, p.vy, p.vz,
                p.fx, p.fy, p.fz, p.length, p.depth));
    }
}
