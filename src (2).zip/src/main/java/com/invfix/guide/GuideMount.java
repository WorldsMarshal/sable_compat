package com.invfix.guide;

import dan200.computercraft.api.filesystem.FileOperationException;
import dan200.computercraft.api.filesystem.Mount;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SeekableByteChannel;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * Гайд как каталог файлов на компьютере.
 *
 * Читать с экрана удобно ровно один раз; дальше хочется грепать, копировать
 * куски в свою программу и держать открытым в соседнем окне. Поэтому те же
 * тексты монтируются в {@code /guide} только на чтение, и с ними работает всё
 * обычное — {@code edit}, {@code type}, {@code cp}, перенаправление вывода.
 *
 * Монтирование, а не запись файлов в корень: гайд не должен занимать место на
 * диске компьютера, переживать {@code delete} и расходиться по версиям между
 * старыми и новыми компьютерами.
 */
public class GuideMount implements Mount {

    private final Map<String, byte[]> files;

    public GuideMount() {
        files = GuideLibrary.topics().values().stream().collect(
                java.util.stream.Collectors.toMap(
                        topic -> topic.id() + ".md",
                        topic -> topic.text().getBytes(StandardCharsets.UTF_8),
                        (a, b) -> a,
                        java.util.LinkedHashMap::new));
    }

    private static String normalise(String path) {
        return path == null ? "" : path.replace('\\', '/').replaceAll("^/+", "");
    }

    @Override
    public boolean exists(String path) {
        String p = normalise(path);
        return p.isEmpty() || files.containsKey(p);
    }

    @Override
    public boolean isDirectory(String path) {
        return normalise(path).isEmpty();
    }

    @Override
    public void list(String path, List<String> contents) throws IOException {
        if (!isDirectory(path)) throw new FileOperationException(path, "Not a directory");
        contents.addAll(files.keySet());
    }

    @Override
    public long getSize(String path) throws IOException {
        byte[] data = files.get(normalise(path));
        if (data == null) {
            if (isDirectory(path)) return 0;
            throw new FileOperationException(path, "No such file");
        }
        return data.length;
    }

    @Override
    public SeekableByteChannel openForRead(String path) throws IOException {
        byte[] data = files.get(normalise(path));
        if (data == null) throw new FileOperationException(path, "No such file");
        return new ByteChannel(ByteBuffer.wrap(data));
    }

    /** Простейший канал только на чтение поверх массива в памяти. */
    private static final class ByteChannel implements SeekableByteChannel {

        private final ByteBuffer buffer;
        private boolean open = true;

        ByteChannel(ByteBuffer buffer) {
            this.buffer = buffer;
        }

        @Override
        public int read(ByteBuffer dst) {
            if (!buffer.hasRemaining()) return -1;
            int count = Math.min(dst.remaining(), buffer.remaining());
            ByteBuffer slice = buffer.slice();
            slice.limit(count);
            dst.put(slice);
            buffer.position(buffer.position() + count);
            return count;
        }

        @Override
        public int write(ByteBuffer src) throws IOException {
            throw new IOException("read-only");
        }

        @Override
        public long position() {
            return buffer.position();
        }

        @Override
        public SeekableByteChannel position(long newPosition) {
            buffer.position((int) newPosition);
            return this;
        }

        @Override
        public long size() {
            return buffer.limit();
        }

        @Override
        public SeekableByteChannel truncate(long size) throws IOException {
            throw new IOException("read-only");
        }

        @Override
        public boolean isOpen() {
            return open;
        }

        @Override
        public void close() {
            open = false;
        }
    }
}
