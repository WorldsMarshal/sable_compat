package com.invfix.guide;

import dan200.computercraft.api.ComputerCraftAPI;
import dan200.computercraft.api.lua.IComputerSystem;
import dan200.computercraft.api.lua.ILuaAPI;
import dan200.computercraft.api.lua.LuaException;
import dan200.computercraft.api.lua.LuaFunction;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;

/**
 * Таблица {@code guide} — документация на всё, что мод добавил.
 *
 * Мы с тобой знаем, как этим пользоваться, потому что мы это писали. Больше
 * никто не знает, и знать неоткуда: у периферии нет ни всплывающих подсказок, ни
 * страницы в JEI, а имена методов угадать нельзя. Поэтому гайд лежит внутри
 * самой игры, на любом компьютере, без интернета и без вики.
 *
 * Доступно двумя способами сразу. {@code guide.read(...)} возвращает текст
 * строкой — это для «глянуть прямо сейчас». И тот же текст смонтирован файлами в
 * {@code /guide}, чтобы его можно было листать, грепать и копировать куски в свою
 * программу.
 *
 * Искать можно тем, что есть на руках: идентификатором предмета
 * ({@code propulsion:vector_thruster}), коротким именем ({@code thruster}) или
 * типом периферии, каким его показывает {@code peripheral.getType}.
 */
public class GuideApi implements ILuaAPI {

    /** Куда монтируется каталог с текстами. */
    private static final String MOUNT_POINT = "guide";

    private final IComputerSystem system;
    private @Nullable String mounted;

    public GuideApi(IComputerSystem system) {
        this.system = system;
    }

    @Override
    public String[] getNames() {
        return new String[]{"guide"};
    }

    @Override
    public void startup() {
        try {
            mounted = system.mount(MOUNT_POINT, new GuideMount(), "sable_compat_guide");
        } catch (Throwable ignored) {
            // место занято или файловая система не готова: текстовый доступ остаётся
        }
    }

    @Override
    public void shutdown() {
        if (mounted != null) {
            try {
                system.unmount(mounted);
            } catch (Throwable ignored) {
                // компьютер уже разбирается: отмонтировать нечего
            }
            mounted = null;
        }
    }

    /**
     * Оглавление: что вообще есть.
     *
     * Начинать отсюда. Каждая запись несёт идентификатор темы, заголовок, строку
     * с сутью и список того, по чему её ещё можно найти.
     */
    @LuaFunction
    public final List<Map<String, Object>> topics() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (GuideLibrary.Topic topic : GuideLibrary.topics().values()) {
            Map<String, Object> m = new HashMap<>();
            m.put("id", topic.id());
            m.put("title", topic.title());
            m.put("summary", topic.summary());
            m.put("aliases", topic.aliases());
            m.put("file", "/" + MOUNT_POINT + "/" + topic.id() + ".md");
            out.add(m);
        }
        return out;
    }

    /**
     * Полный текст темы.
     *
     * Длинный: пропускать через {@code textutils.pagedPrint}, иначе улетит за
     * верх экрана.
     */
    @LuaFunction
    public final String read(String query) throws LuaException {
        GuideLibrary.Topic topic = GuideLibrary.find(query);
        if (topic == null) throw new LuaException("no such topic: " + query);
        return topic.text();
    }

    /** Заголовок и суть без полотна текста. */
    @LuaFunction
    public final Map<String, Object> about(String query) throws LuaException {
        GuideLibrary.Topic topic = GuideLibrary.find(query);
        if (topic == null) throw new LuaException("no such topic: " + query);
        Map<String, Object> m = new HashMap<>();
        m.put("id", topic.id());
        m.put("title", topic.title());
        m.put("summary", topic.summary());
        m.put("aliases", topic.aliases());
        m.put("file", "/" + MOUNT_POINT + "/" + topic.id() + ".md");
        return m;
    }

    /** Темы, в тексте которых встречается строка. Когда помнишь метод, но не блок. */
    @LuaFunction
    public final List<String> search(String query) {
        List<String> out = new ArrayList<>();
        for (GuideLibrary.Topic topic : GuideLibrary.search(query)) out.add(topic.id());
        return out;
    }

    /** Каталог, в который смонтированы те же тексты файлами. */
    @LuaFunction
    public final String path() {
        return "/" + MOUNT_POINT;
    }

    /** Вешает таблицу на каждый компьютер. */
    @EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD)
    public static final class Setup {

        private Setup() {}

        @SubscribeEvent
        public static void onCommonSetup(FMLCommonSetupEvent event) {
            ModList mods = ModList.get();
            if (mods == null || !mods.isLoaded("computercraft")) return;
            event.enqueueWork(() -> ComputerCraftAPI.registerAPIFactory(GuideApi::new));
        }
    }
}
