package com.invfix.guide;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.annotation.Nullable;

/**
 * Вся документация мода, загруженная из джарника один раз.
 *
 * Тексты лежат отдельными файлами рядом с индексом, а не константами в коде:
 * их правит человек, а не программа, и держать абзац про наведение ЗРК внутри
 * Java-строки — верный способ никогда его не обновить.
 *
 * Поиск идёт по трём вещам сразу: по идентификатору темы, по идентификаторам
 * предметов и блоков, к которым она относится, и по типу периферии, каким его
 * видит Lua. Поэтому {@code guide.read("propulsion:vector_thruster")},
 * {@code guide.read("vector_thruster")} и {@code guide.read("thrusters")}
 * приводят в одно и то же место — игрок ищет тем, что у него на руках, а не тем,
 * как мы назвали файл.
 */
public final class GuideLibrary {

    private GuideLibrary() {}

    private static final String ROOT = "/assets/sable_compat/guide/";

    /** Тема документации. */
    public record Topic(String id, String title, String summary, List<String> aliases, String text) {}

    private static @Nullable Map<String, Topic> topics;

    public static synchronized Map<String, Topic> topics() {
        if (topics == null) topics = load();
        return topics;
    }

    private static Map<String, Topic> load() {
        Map<String, Topic> out = new LinkedHashMap<>();
        JsonObject index;
        try (InputStream in = GuideLibrary.class.getResourceAsStream(ROOT + "index.json")) {
            if (in == null) return out;
            index = JsonParser.parseReader(
                    new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (Exception e) {
            return out;
        }

        JsonArray entries = index.getAsJsonArray("topics");
        if (entries == null) return out;
        for (JsonElement element : entries) {
            JsonObject entry = element.getAsJsonObject();
            String id = entry.get("id").getAsString();
            List<String> aliases = new ArrayList<>();
            JsonArray raw = entry.getAsJsonArray("aliases");
            if (raw != null) for (JsonElement a : raw) aliases.add(a.getAsString());
            out.put(id, new Topic(id,
                    entry.get("title").getAsString(),
                    entry.has("summary") ? entry.get("summary").getAsString() : "",
                    List.copyOf(aliases),
                    text(id)));
        }
        return Collections.unmodifiableMap(out);
    }

    private static String text(String id) {
        try (InputStream in = GuideLibrary.class.getResourceAsStream(ROOT + id + ".md")) {
            if (in == null) return "(текст темы не найден)";
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "(текст темы не читается)";
        }
    }

    /**
     * Найти тему по чему угодно, что игрок мог набрать.
     *
     * Точное совпадение идентификатора или псевдонима идёт первым; если его нет,
     * ищется вхождение подстроки, потому что человек, у которого в руке
     * "propulsion:vector_thruster", наберёт скорее "thruster", чем полный id.
     */
    public static @Nullable Topic find(String query) {
        if (query == null || query.isEmpty()) return null;
        String needle = query.toLowerCase(Locale.ROOT).trim();

        Topic exact = topics().get(needle);
        if (exact != null) return exact;

        for (Topic topic : topics().values()) {
            for (String alias : topic.aliases()) {
                if (alias.toLowerCase(Locale.ROOT).equals(needle)) return topic;
            }
        }
        for (Topic topic : topics().values()) {
            if (topic.id().contains(needle) || topic.title().toLowerCase(Locale.ROOT).contains(needle)) {
                return topic;
            }
            for (String alias : topic.aliases()) {
                if (alias.toLowerCase(Locale.ROOT).contains(needle)) return topic;
            }
        }
        return null;
    }

    /** Все темы, чей текст содержит строку. Для тех, кто помнит метод, но не блок. */
    public static List<Topic> search(String query) {
        List<Topic> out = new ArrayList<>();
        if (query == null || query.isEmpty()) return out;
        String needle = query.toLowerCase(Locale.ROOT).trim();
        for (Topic topic : topics().values()) {
            if (topic.text().toLowerCase(Locale.ROOT).contains(needle)) out.add(topic);
        }
        return out;
    }
}
