package com.invfix;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

/**
 * Скорость разрушения блоков ГОЛОЙ РУКОЙ масштабируется от силы (currentStr).
 *
 * Реализовано через штатное событие {@link PlayerEvent.BreakSpeed} вместо
 * миксина на Player#getDestroySpeed — событие не зависит от маппингов/refmap
 * и срабатывает каждый тик копания и на клиенте, и на сервере.
 *
 * Сила растёт с уровнем у всех рас, КРОМЕ людских (чистый Human и оба
 * Human(...)-варианта), поэтому у людей бонуса нет. Трогаем только скорость
 * (setNewSpeed) — механика выпадения блоков (нужный инструмент / лут) не
 * затрагивается, скорость и дроп в Minecraft независимы.
 *
 *   mult = min(1 + max(0, currentStr - BASE_STR) * STR_PER_MULT, MAX_MULT)
 *
 * NB: голой рукой блоки, требующие инструмент (камень, руда), всё равно
 * ломаются очень медленно из-за ванильного штрафа ×1/100 — это нормально,
 * проверяй на блоках, которые рука и так добывает (земля, дерево, листва...).
 */
@EventBusSubscriber(modid = "sable_compat")
public final class BareHandDigSpeedHandler {

    /** Сила, на которой бонуса ещё нет (база у всех = 1.0). */
    private static final double BASE_STR     = 1.0;
    /** Прибавка множителя за каждую единицу силы свыше базы. */
    private static final double STR_PER_MULT = 0.1;
    /** Жёсткий потолок множителя скорости. */
    private static final double MAX_MULT     = 70.0;

    private BareHandDigSpeedHandler() {}

    @SubscribeEvent
    public static void onBreakSpeed(PlayerEvent.BreakSpeed event) {
        Player player = event.getEntity();

        // только голая рука
        if (!player.getMainHandItem().isEmpty()) return;

        float base = event.getNewSpeed();
        if (base <= 0.0f) return;

        InvincibleIncModVariables.PlayerVariables vars =
                player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        if (vars == null || isHumanType(vars.Race)) return;

        double str  = Math.max(0.0, vars.currentStr - BASE_STR);
        double mult = Math.min(1.0 + str * STR_PER_MULT, MAX_MULT);

        if (mult > 1.0) {
            event.setNewSpeed((float) (base * mult));
        }
    }

    /**
     * Людская раса = чистый Human или Human(...)-вариант (Born for V /
     * Predisposition to V). Human-Viltrumite людским НЕ считается — у него
     * сила растёт, значит он получает бонус к копанию.
     */
    private static boolean isHumanType(String race) {
        if (race == null) return true;
        StringBuilder sb = new StringBuilder(race.length());
        for (int i = 0; i < race.length(); i++) {
            char c = race.charAt(i);
            if (c == '\u00a7' && i + 1 < race.length()) {
                i++; // пропускаем §-код
            } else {
                sb.append(c);
            }
        }
        String s = sb.toString();
        return s.equals("Human") || s.startsWith("Human(");
    }
}