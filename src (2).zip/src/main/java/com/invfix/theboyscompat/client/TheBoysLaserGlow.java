package com.invfix.theboyscompat.client;

import com.invfix.heatvision.client.HeatVisionRenderer;
import net.benniao.theboysmod.client.ClientSkillStateCache;
import net.benniao.theboysmod.skill.ModSkillAttachments;
import net.benniao.theboysmod.skill.SkillData;
import net.benniao.theboysmod.skill.skills.LaserEyeSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.neoforged.neoforge.attachment.AttachmentType;

/**
 * Источник свечения глаз для Heat Vision (лазерных глаз) мода The Boys.
 *
 * Возвращает true, пока игрок «канализирует» лазер (зажата кнопка способности),
 * НЕЗАВИСИМО от бинда Threatening/Playful Mode и от того, идёт ли сейчас луч.
 * Поэтому свечение глаз горит всегда, пока способность активна, а бинд лишь
 * гасит сам луч (LaserEyePlayfulMixin / LaserEyePlayfulClientMixin) — полное
 * зеркало нашего Heat Vision.
 *
 * Трогается только когда theboysmod загружен (см. {@link TheBoysLaserGlowInit}).
 */
public final class TheBoysLaserGlow implements HeatVisionRenderer.GlowSource {

    private static final String LASER_ID = LaserEyeSkill.ID.toString();

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public boolean isGlowing(AbstractClientPlayer player) {
        try {
            Minecraft mc = Minecraft.getInstance();
            // Локальный игрок — читаем его SkillData напрямую (мгновенно, без round-trip).
            if (mc.player != null && player.getId() == mc.player.getId()) {
                SkillData data = (SkillData) player.getData((AttachmentType) ModSkillAttachments.SKILL_DATA.get());
                return data != null && data.hasSkill(LASER_ID) && data.isSkillActive(LASER_ID);
            }
            // Прочие игроки — синхронизированное состояние с сервера.
            return ClientSkillStateCache.isSkillActive(player.getId(), LASER_ID);
        } catch (Exception e) {
            return false;
        }
    }
}
