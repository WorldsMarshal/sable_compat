package com.invfix.theboyscompat.client;

import com.invfix.heatvision.client.HeatVisionRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Подключает свечение глаз нашего Heat Vision к лазерным глазам The Boys —
 * только если theboysmod загружен. Ссылка на {@link TheBoysLaserGlow}
 * (с импортами The Boys) берётся исключительно внутри проверки, поэтому без
 * мода класс не загружается и ничего не падает.
 */
@EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class TheBoysLaserGlowInit {

    private TheBoysLaserGlowInit() {}

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        if (ModList.get().isLoaded("theboysmod")) {
            event.enqueueWork(() -> HeatVisionRenderer.addGlowSource(new TheBoysLaserGlow()));
        }
    }
}
