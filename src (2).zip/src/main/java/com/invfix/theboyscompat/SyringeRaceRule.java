package com.invfix.theboyscompat;

import com.invfix.humanlike.HumanLikeRaces;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.Set;

/**
 * Правило «V только для человеческой ДНК» (The Boys × расы Invincible Inc).
 *
 * Проверяется ДНК ПОЛУЧАТЕЛЯ инъекции: self-use → сам игрок, инъекция ударом →
 * цель удара. Разрешены чистый Human, Human(Born for V), Human(Predisposition to V)
 * и Human-Viltrumite. Остальные расы получить Compound V / Temp V не могут.
 *
 * Обычный класс (не миксин) — общий для SyringeRaceGateMixin, onAttackEntity и
 * injectTarget; ссылок на The Boys не содержит (тип шприца берётся по id предмета).
 */
public final class SyringeRaceRule {

    private SyringeRaceRule() {}

    private static final Set<String> HUMAN_RACES = Set.of(
            "\u00a7f\u00a7lHuman",
            "\u00a7lHuman",
            "Human",
            "\u00a7f\u00a7lHuman-Viltrumite",
            HumanLikeRaces.BORN_FOR_V,
            HumanLikeRaces.PREDISPOSITION);

    /** "Compound V" / "Temp V", или null если это не инъекционный V-шприц (например, удалитель). */
    public static String vLabel(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;
        String id = stack.getItemHolder().getRegisteredName();
        if ("theboysmod:compound_v_syringe".equals(id)) return "Compound V";
        if ("theboysmod:compound_v_temp_syringe".equals(id)) return "Temp V";
        return null;
    }

    public static boolean isHuman(Player recipient) {
        try {
            String race = recipient.getData(InvincibleIncModVariables.PLAYER_VARIABLES).Race;
            return race != null && HUMAN_RACES.contains(race);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Сообщение, которое нужно показать при отмене, если получателю нельзя V
     * (нечеловеческая ДНК и шприц — Compound/Temp V). Иначе null (инъекция разрешена).
     */
    public static String blockMessage(Player recipient, ItemStack stack) {
        String label = vLabel(stack);
        if (label == null) return null;
        if (recipient == null || isHuman(recipient)) return null;
        return label + " was created for human DNA.";
    }
}
