package com.invfix.theboyscompat;

import com.invfix.theboys.TheBoysSkillState;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;

/**
 * Фикс недочёта The Boys: игрок с навыком Flight ({@code theboysmod:flight}) не
 * должен получать урон от падения.
 *
 * В самом моде защита от падения есть только для крыльев
 * ({@code WingFlightServerHandler}), и она ЯВНО исключает навык flight
 * (hasLegacyFlight), поэтому летающие игроки с этим навыком урон от падения
 * получают. Гасим его так же, как мод гасит для крыльев: обнуляем fallDistance
 * и отменяем LivingFallEvent.
 *
 * Ссылки на The Boys изолированы в {@link TheBoysSkillState} и трогаются только
 * при наличии мода (проверка ModList), иначе обработчик — no-op.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class FlightFallHandler {

    private static Boolean loaded;

    private FlightFallHandler() {}

    private static boolean theBoys() {
        if (loaded == null) loaded = ModList.get().isLoaded("theboysmod");
        return loaded;
    }

    @SubscribeEvent
    public static void onLivingFall(LivingFallEvent event) {
        if (!theBoys()) return;
        if (event.getEntity() instanceof ServerPlayer player && TheBoysSkillState.hasFlight(player)) {
            player.fallDistance = 0.0F;
            event.setCanceled(true);
        }
    }
}
