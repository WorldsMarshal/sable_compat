package com.invfix.theboyscompat;

import net.minecraft.world.entity.Entity;

/**
 * Мягкий мост к состоянию препарата V (The Boys).
 *
 * Класс НЕ ссылается на классы The Boys ни статически, ни в импортах, поэтому
 * грузится всегда и безопасен без мода. Реальный провайдер (VBonusProvider)
 * подцепляется лениво через рефлексию и только если theboysmod загружен —
 * до этого и при отсутствии мода isCompoundVActive() возвращает false.
 *
 * Нужен, чтобы HumanCapsMixin (применяется ВСЕГДА) мог узнать про активный
 * Compound V, не таща за собой жёсткую зависимость от The Boys.
 */
public final class VBonusBridge {

    public interface Provider {
        boolean isCompoundVActive(Entity entity);
    }

    private static volatile Provider provider;
    private static volatile boolean initialized;

    private VBonusBridge() {}

    public static boolean isCompoundVActive(Entity entity) {
        Provider p = provider;
        if (p == null) {
            if (initialized) return false;
            p = tryInit();
            if (p == null) return false;
        }
        try {
            return p.isCompoundVActive(entity);
        } catch (Throwable t) {
            return false;
        }
    }

    private static synchronized Provider tryInit() {
        if (initialized) return provider;
        initialized = true;
        try {
            if (net.neoforged.fml.ModList.get() != null
                    && net.neoforged.fml.ModList.get().isLoaded("theboysmod")) {
                // Class.forName, чтобы VBonusBridge не имел статической ссылки на
                // VBonusProvider (который тянет классы The Boys).
                provider = (Provider) Class
                        .forName("com.invfix.theboyscompat.VBonusProvider")
                        .getDeclaredConstructor()
                        .newInstance();
            }
        } catch (Throwable ignored) {}
        return provider;
    }
}