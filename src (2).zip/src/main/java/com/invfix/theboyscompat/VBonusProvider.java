package com.invfix.theboyscompat;

import com.invfix.theboys.TheBoysSkillState;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

/**
 * Реальная реализация {@link VBonusBridge.Provider}. Ссылается на классы The Boys
 * (через {@link TheBoysSkillState}), поэтому грузится ТОЛЬКО когда theboysmod есть —
 * VBonusBridge создаёт её рефлексией под проверкой наличия мода.
 *
 * «Compound V активен» = у игрока есть хотя бы один перманентный скилл The Boys
 * (временные скиллы Temp V не считаются). Это покрывает и Predisposition (успешный
 * Compound V даёт перм-скилл), и Born for V (набор Хоумлендера — перм-скиллы).
 * При снятии V перм-скиллы пропадают → провайдер вернёт false → бонус снимется.
 */
public final class VBonusProvider implements VBonusBridge.Provider {

    @Override
    public boolean isCompoundVActive(Entity entity) {
        if (!(entity instanceof ServerPlayer sp)) return false;
        return TheBoysSkillState.hasPermanentSkill(sp);
    }
}