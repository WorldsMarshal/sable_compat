package com.invfix.network;

import com.invfix.grab.GrabSyncPacket;
import com.invfix.heatvision.HeatVisionGlowSyncPacket;
import com.invfix.heatvision.HeatVisionHitPosSyncPacket;
import com.invfix.kineticstrike.KineticStrikeStatePacket;
import com.invfix.kineticstrike.PacketMushroomCloud;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Единая клиентская обёртка для всех сетевых приёмников мода.
 *
 * Все методы handleClient у пакетов помечены @OnlyIn(Dist.CLIENT), поэтому на
 * физическом сервере их тела вырезаются RuntimeDistCleaner'ом. Если ссылаться на
 * них напрямую (Packet::handleClient) в регистраторе, который выполняется на ОБЕИХ
 * сторонах, на сервере получаем NoSuchMethodError.
 *
 * Весь этот класс помечен @OnlyIn(Dist.CLIENT), поэтому на сервере он не
 * загружается вообще, и ссылки на вырезанные методы изолированы здесь. Регистратор
 * вызывает эти методы только после проверки стороны (FMLEnvironment.dist), так что
 * серверная JVM до загрузки данного класса никогда не доходит.
 */
@OnlyIn(Dist.CLIENT)
public final class ClientPacketHandlers {

    private ClientPacketHandlers() {}

    public static void heatVisionGlow(HeatVisionGlowSyncPacket pkt, IPayloadContext ctx) {
        HeatVisionGlowSyncPacket.handleClient(pkt, ctx);
    }

    public static void heatVisionHitPos(HeatVisionHitPosSyncPacket pkt, IPayloadContext ctx) {
        HeatVisionHitPosSyncPacket.handleClient(pkt, ctx);
    }

    public static void kineticStrikeState(KineticStrikeStatePacket pkt, IPayloadContext ctx) {
        KineticStrikeStatePacket.handleClient(pkt, ctx);
    }

    public static void mushroomCloud(PacketMushroomCloud pkt, IPayloadContext ctx) {
        PacketMushroomCloud.handleClient(pkt, ctx);
    }

    public static void comboImpact(com.invfix.combo.ComboImpactPacket pkt, IPayloadContext ctx) {
        com.invfix.combo.ComboImpactPacket.handleClient(pkt, ctx);
    }

    public static void heatDisruption(com.invfix.heatdisruption.HeatDisruptionPacket pkt, IPayloadContext ctx) {
        com.invfix.heatdisruption.HeatDisruptionPacket.handleClient(pkt, ctx);
    }

    public static void dismantle(com.invfix.dismantle.DismantlePacket pkt, IPayloadContext ctx) {
        com.invfix.dismantle.DismantlePacket.handleClient(pkt, ctx);
    }

    public static void dismantleSettings(com.invfix.dismantle.DismantleSettingsPacket pkt, IPayloadContext ctx) {
        com.invfix.dismantle.DismantleSettingsPacket.handleClient(pkt, ctx);
    }

    public static void energyBlastCharge(com.invfix.energyblast.EnergyBlastPackets.Charge pkt, IPayloadContext ctx) {
        com.invfix.energyblast.EnergyBlastPackets.Charge.handleClient(pkt, ctx);
    }

    public static void energyBlastShot(com.invfix.energyblast.EnergyBlastPackets.Shot pkt, IPayloadContext ctx) {
        com.invfix.energyblast.EnergyBlastPackets.Shot.handleClient(pkt, ctx);
    }

    public static void energyBlastBlast(com.invfix.energyblast.EnergyBlastPackets.Blast pkt, IPayloadContext ctx) {
        com.invfix.energyblast.EnergyBlastPackets.Blast.handleClient(pkt, ctx);
    }

    public static void sentry(com.invfix.sentry.SentryPacket pkt, IPayloadContext ctx) {
        com.invfix.sentry.SentryPacket.handleClient(pkt, ctx);
    }

    public static void spaceFold(com.invfix.spacefold.SpaceFoldPacket pkt, IPayloadContext ctx) {
        com.invfix.spacefold.SpaceFoldPacket.handleClient(pkt, ctx);
    }

    public static void spaceFoldSettings(com.invfix.spacefold.SpaceFoldSettingsPacket pkt, IPayloadContext ctx) {
        com.invfix.spacefold.SpaceFoldSettingsPacket.handleClient(pkt, ctx);
    }

    public static void thermal(com.invfix.thermal.ThermalPacket pkt, IPayloadContext ctx) {
        com.invfix.thermal.ThermalPacket.handleClient(pkt, ctx);
    }

    public static void portalRecoil(com.invfix.rick.portalgun.PortalRecoilPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> com.invfix.rick.portalgun.client.PortalGunRecoilManager
                .triggerRecoilByOrdinal(pkt.entityId(), pkt.hand()));
    }

    public static void portalFlash(com.invfix.rick.portalgun.PortalFlashPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> com.invfix.rick.portalgun.client.PortalFadeOverlay.trigger(pkt.color()));
    }

    public static void shieldEffect(com.invfix.rick.shield.ShieldEffectPacket pkt, IPayloadContext ctx) {
        com.invfix.rick.shield.client.ShieldClientPackets.handle(pkt, ctx);
    }

    public static void timeStopNoLerp(com.invfix.timestop.blink.TimeStopNoLerpPacket pkt, IPayloadContext ctx) {
        com.invfix.timestop.blink.client.TimeStopBlinkClient.handleNoLerp(pkt, ctx);
    }

    public static void timeStopSync(com.invfix.timestop.TimeStopSyncPacket pkt, IPayloadContext ctx) {
        com.invfix.timestop.TimeStopSyncPacket.handleClient(pkt, ctx);
    }

    /**
     * Ставит замороженную сущность точно в присланную позицию и приравнивает к
     * ней прошлую (xo/yo/zo). Без этого рендер продолжал бы интерполировать её
     * от старой позиции к новой, и моб, замерзший на бегу, «дотягивал» бы шаг.
     */
    public static void timeStopFreezePos(com.invfix.timestop.TimeStopFreezePosPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            var mc = net.minecraft.client.Minecraft.getInstance();
            if (mc.level == null) return;
            net.minecraft.world.entity.Entity entity = mc.level.getEntity(pkt.entityId());
            if (entity == null) return;
            entity.setPos(pkt.x(), pkt.y(), pkt.z());
            // Только xo/yo/zo — ровно те поля, что трогает ROTP
            // (EntityDirectPosNoLerpPacket.Handler#handle). xOld/yOld/zOld не
            // трогаем: за пределами сверенного источника.
            entity.xo = pkt.x();
            entity.yo = pkt.y();
            entity.zo = pkt.z();
        });
    }

    public static void grab(GrabSyncPacket pkt, IPayloadContext ctx) {
        GrabSyncPacket.handleClient(pkt, ctx);
    }
}