package com.invfix.item;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.animal.Fox;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Пасхалки девятихвостого разработчика (HoustonWTF) и лис.
 *
 * Присед + ПКМ пустой рукой по взрослой лисе — «разведение»: рядом
 * появляется лисёнок того же окраса, с сердечками, звуком и опытом как при
 * ванильном размножении. Мать уходит в стандартный откат размножения
 * (6000 тиков), лисёнок — в стандартные -24000 тиков детства, так что
 * ферму быстрее ванильной пары лис на ягодах так не собрать — это рофл,
 * а не автоматизация.
 *
 * Страх лис перед разработчиком снят миксином
 * {@link com.invfix.mixin.FoxTrustDevMixin} через Fox#trusts.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class KitsuneFoxHandler {

    private static final String DEV_NICK = "HoustonWTF";

    private KitsuneFoxHandler() {}

    /** Единая проверка ника для всех лисьих пасхалок. */
    public static boolean isDev(Player player) {
        return DEV_NICK.equals(player.getGameProfile().getName());
    }

    @SubscribeEvent
    public static void onBreedFox(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof Fox fox)) return;

        Player player = event.getEntity();
        if (!isDev(player)) return;
        if (!player.isShiftKeyDown()) return;

        ItemStack held = player.getItemInHand(event.getHand());
        if (!held.isEmpty()) return;          // только пустой рукой
        if (fox.isBaby()) return;             // лисят не трогаем
        if (fox.getAge() != 0) return;        // мать не в откате размножения

        if (event.getLevel() instanceof ServerLevel level) {
            Fox kit = EntityType.FOX.create(level);
            if (kit == null) return;

            RandomSource random = level.getRandom();
            kit.setBaby(true);
            kit.setVariant(fox.getVariant());
            kit.moveTo(fox.getX(), fox.getY(), fox.getZ(),
                    random.nextFloat() * 360.0F, 0.0F);
            level.addFreshEntity(kit);

            // как ванильное размножение: сердечки, опыт, откат матери
            level.broadcastEntityEvent(fox, (byte) 18);
            level.addFreshEntity(new ExperienceOrb(level,
                    fox.getX(), fox.getY(), fox.getZ(),
                    random.nextInt(7) + 1));
            fox.setAge(6000);

            fox.playSound(SoundEvents.FOX_AMBIENT, 1.0F, 1.0F);
        }

        event.setCanceled(true);
        event.setCancellationResult(
                InteractionResult.sidedSuccess(event.getLevel().isClientSide));
    }
}
