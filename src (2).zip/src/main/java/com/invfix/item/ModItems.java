package com.invfix.item;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Реестр предметов, добавляемых модом sable_compat.
 *
 * Аккумулятор регистрируется ПОД НЕЙМСПЕЙСОМ The Boys → id будет
 * {@code theboysmod:accumulator}. NeoForge не требует, чтобы namespace
 * совпадал с modid: параметр createItems — это просто namespace для всех
 * регистрируемых объектов, а registerSimpleItem сам проставит ему
 * ResourceKey theboysmod:accumulator.
 *
 * Из-за этого ассеты предмета лежат под assets/theboysmod/... (их даёт наш
 * мод и Minecraft мёрджит их с ресурсами The Boys).
 *
 * Регистрируется из {@link com.invfix.InvincibleFix} через {@link #register(IEventBus)}.
 */
public final class ModItems {

    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems("theboysmod");

    /** Аккумулятор — крафтовый предмет (theboysmod:accumulator). */
    public static final DeferredItem<Item> ACCUMULATOR =
            ITEMS.registerSimpleItem("accumulator", new Item.Properties());

    private ModItems() {}

    public static void register(IEventBus modEventBus) {
        ITEMS.register(modEventBus);
        modEventBus.addListener(ModItems::onBuildCreativeTabs);
    }

    /** Кладём аккумулятор во вкладку «Ингредиенты». */
    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(ACCUMULATOR);
        }
    }
}