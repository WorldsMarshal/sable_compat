package com.invfix.item;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.Items;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Дойка разработчика: ПКМ пустым ведром по игроку с ником HoustonWTF —
 * ведро превращается в «Лисье молоко», со звуком дойки коровы.
 * Механика от разраба, работающая только с разрабом.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class FoxMilkingHandler {

    private static final String DEV_NICK = "HoustonWTF";

    private FoxMilkingHandler() {}

    /**
     * Самодойка: HoustonWTF, присед + ПКМ пустым ведром строго ПО ВОЗДУХУ
     * (рейтрейс в пределах руки не должен попасть ни в блок, ни в жидкость —
     * иначе присевший разраб не смог бы зачерпнуть воду ведром).
     */
    @SubscribeEvent
    public static void onSelfMilk(PlayerInteractEvent.RightClickItem event) {
        Player player = event.getEntity();
        if (!DEV_NICK.equals(player.getGameProfile().getName())) return;
        if (!player.isShiftKeyDown()) return;
        ItemStack held = event.getItemStack();
        if (!held.is(Items.BUCKET)) return;
        if (player.pick(4.5, 1.0F, true).getType() != net.minecraft.world.phys.HitResult.Type.MISS) return;

        player.playSound(SoundEvents.COW_MILK, 1.0F, 1.0F);
        if (!event.getLevel().isClientSide) {
            ItemStack milk = ItemUtils.createFilledResult(held, player,
                    new ItemStack(com.invfix.cyberware.CompositeItems.FOX_MILK.get()));
            player.setItemInHand(event.getHand(), milk);
        }
        event.setCanceled(true);
        event.setCancellationResult(net.minecraft.world.InteractionResult.sidedSuccess(event.getLevel().isClientSide));
    }

    @SubscribeEvent
    public static void onMilkTheDev(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof Player target)) return;
        if (!DEV_NICK.equals(target.getGameProfile().getName())) return;

        Player player = event.getEntity();
        InteractionHand hand = event.getHand();
        ItemStack held = player.getItemInHand(hand);
        if (!held.is(Items.BUCKET)) return;

        player.playSound(SoundEvents.COW_MILK, 1.0F, 1.0F);
        if (!event.getLevel().isClientSide) {
            ItemStack milk = ItemUtils.createFilledResult(held, player, new ItemStack(com.invfix.cyberware.CompositeItems.FOX_MILK.get()));
            player.setItemInHand(hand, milk);
        }
        event.setCanceled(true);
        event.setCancellationResult(net.minecraft.world.InteractionResult.sidedSuccess(event.getLevel().isClientSide));
    }
}
