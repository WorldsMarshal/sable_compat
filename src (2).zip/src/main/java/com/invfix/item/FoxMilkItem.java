package com.invfix.item;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

/**
 * «Лисье молоко» — рофл-предмет от разработчика.
 *
 * Пьётся всегда, как молоко, но НЕ снимает эффекты и НЕ восполняет голод —
 * вместо этого выпившему лично пишется сообщение в чат
 * (lang-ключ {@code message.not_yuri.fox_milk} — текст правится в
 * en_us.json / ru_ru.json). После питья возвращается пустое ведро.
 *
 * Добыча — {@link FoxMilkingHandler}: подоить игрока с ником HoustonWTF
 * пустым ведром, как корову.
 */
public class FoxMilkItem extends Item {

    private static final int DRINK_DURATION = 62; // как у ведра молока

    public FoxMilkItem(Properties properties) {
        super(properties);
    }

    /** Ник *источника* — ему приходит уведомление о выпившем. */
    private static final String SOURCE_NICK = "HoustonWTF";

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide && entity instanceof Player player) {
            // Лично в чат — не actionbar. Никаких эффектов, никакой еды.
            player.displayClientMessage(Component.translatable("message.not_yuri.fox_milk"), false);

            // Источник узнаёт, кто выпил (лично в чат), — если он онлайн и пил не он сам.
            if (!SOURCE_NICK.equals(player.getGameProfile().getName()) && level.getServer() != null) {
                var source = level.getServer().getPlayerList().getPlayerByName(SOURCE_NICK);
                if (source != null) {
                    source.displayClientMessage(Component.translatable(
                            "message.not_yuri.fox_milk_notify", player.getDisplayName()), false);
                }
            }
        }
        if (entity instanceof Player player && !player.getAbilities().instabuild) {
            return new ItemStack(Items.BUCKET);
        }
        return stack;
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return DRINK_DURATION;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.DRINK;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return ItemUtils.startUsingInstantly(level, player, hand);
    }

    @Override
    public net.minecraft.sounds.SoundEvent getDrinkingSound() {
        return SoundEvents.GENERIC_DRINK;
    }
}
