package com.invfix.fx;

/**
 * Параметры финального композита на этот кадр. Эффекты складываются максимумом:
 * каждый поднимает нужное, ничего не перезаписывая.
 *
 * Набор и смысл полей — как ScreenFx в The Shooting Star, без перемотки
 * кадров (tape/rewind). Добавлено поле {@link #capture}.
 */
public final class FxScreen {

    public float shake;
    public float aberration;
    public float desaturate;
    public float zoomBlur;
    public float flashR, flashG, flashB, flash;
    public float vignetteR, vignetteG, vignetteB, vignette;
    public float bloom;
    public float bloomRadius;
    public float impact;
    public float impactMode;
    public float impactX = 0.5F;
    public float impactY = 0.5F;
    /** Заморозить кадр: показывать удержанный снимок вместо мира. */
    public float freeze;
    /** «Выжженный» послеобраз удержанного снимка поверх мира. */
    public float afterimage;
    public float contrast;
    public float grain;
    public float keepHot;
    public float synthetic;
    /**
     * Снять кадр в удержание, НЕ замораживая картинку. В оригинале удержание
     * берётся только через freeze, а у нас ослепление вспышкой должно
     * запомнить огненный шар, пока мир продолжает идти.
     */
    public float capture;
    /**
     * Покадровость, кадров/с (stepFps оригинала): пока > 0, картинка обновляется
     * только с этой частотой — импакт-кадры «рисованные», 12 в секунду.
     */
    public float stepFps;
    /**
     * Разрез Dismantle поверх всего, импакт-кадров тоже: концы в экранных uv,
     * полуширина в середине (в долях высоты экрана), сила.
     */
    public float cutX0, cutY0, cutX1, cutY1, cutWidth, cut;

    public void reset() {
        shake = aberration = desaturate = zoomBlur = 0.0F;
        flashR = flashG = flashB = flash = 0.0F;
        vignetteR = vignetteG = vignetteB = vignette = 0.0F;
        bloom = bloomRadius = impact = impactMode = 0.0F;
        impactX = impactY = 0.5F;
        freeze = afterimage = contrast = grain = keepHot = synthetic = capture = stepFps = 0.0F;
        cutX0 = cutY0 = cutX1 = cutY1 = cutWidth = cut = 0.0F;
    }

    public boolean idle() {
        return shake < 1.0E-4F && aberration < 1.0E-4F && desaturate < 1.0E-4F && zoomBlur < 1.0E-4F
                && flash < 1.0E-4F && vignette < 1.0E-4F && impact < 1.0E-4F && freeze < 1.0E-4F
                && afterimage < 1.0E-4F && contrast < 1.0E-4F && grain < 1.0E-4F && bloom < 1.0E-4F
                && capture < 0.5F && stepFps < 0.5F && cut < 1.0E-4F;
    }

    public void addFlash(int rgb, float strength) {
        if (strength <= flash) return;
        flash = strength;
        flashR = (rgb >> 16 & 255) / 255.0F;
        flashG = (rgb >> 8 & 255) / 255.0F;
        flashB = (rgb & 255) / 255.0F;
    }

    public void addImpact(float strength, int mode, float x, float y) {
        if (strength <= impact) return;
        impact = strength;
        impactMode = mode;
        impactX = x;
        impactY = y;
    }

    public void addVignette(int rgb, float strength) {
        if (strength <= vignette) return;
        vignette = strength;
        vignetteR = (rgb >> 16 & 255) / 255.0F;
        vignetteG = (rgb >> 8 & 255) / 255.0F;
        vignetteB = (rgb & 255) / 255.0F;
    }
}
