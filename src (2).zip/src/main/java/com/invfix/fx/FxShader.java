package com.invfix.fx;

import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Программа одного полноэкранного прохода.
 *
 * Сборка как в The Shooting Star (client.render.ShaderProgram): вершинный шейдер
 * общий и без буфера — полноэкранный треугольник из gl_VertexID; фрагментный =
 * common.glsl + тело прохода, с развёрткой #include "файл" (GLSL сам их не
 * умеет) и директивами #line, чтобы номера строк в ошибках драйвера указывали
 * в исходный файл, а не в склейку.
 *
 * Ванильный ShaderInstance сюда не подходит: он требует json-описания, своих
 * вершинных форматов и обязательных uniform'ов, а нам нужен голый проход по
 * экрану с произвольным набором переменных.
 */
final class FxShader {

    static final String ROOT = "/assets/sable_compat/shaders/fx/";

    static final String VERTEX_SOURCE = """
            #version 150

            out vec2 texCoord;

            void main() {
                vec2 positions[3] = vec2[](vec2(-1.0, -1.0), vec2(3.0, -1.0), vec2(-1.0, 3.0));
                vec2 position = positions[gl_VertexID];
                gl_Position = vec4(position, 0.0, 1.0);
                texCoord = position * 0.5 + 0.5;
            }
            """;

    private static final int GL_VERTEX_SHADER = 0x8B31;
    private static final int GL_FRAGMENT_SHADER = 0x8B30;
    private static final int GL_COMPILE_STATUS = 0x8B81;
    private static final int GL_LINK_STATUS = 0x8B82;

    final int id;
    private final Map<String, Integer> locations = new HashMap<>();

    private FxShader(int id) {
        this.id = id;
    }

    /** Кэш расположений uniform'ов: glGetUniformLocation на каждый кадр — лишний вызов драйвера. */
    int location(String name) {
        return locations.computeIfAbsent(name, key -> GL20.glGetUniformLocation(id, key));
    }

    void close() {
        GL20.glDeleteProgram(id);
    }

    static String readSource(String name) throws IOException {
        String common = read("common.glsl");
        String body = read(name + ".fsh");
        return common + "\n#line 1 1\n" + includes(body);
    }

    private static String includes(String body) throws IOException {
        StringBuilder out = new StringBuilder();
        String[] lines = body.split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.startsWith("#include \"") && line.endsWith("\"") && line.length() > 11) {
                out.append(read(line.substring(10, line.length() - 1)))
                        .append("\n#line ").append(i + 2).append(" 1\n");
            } else {
                out.append(lines[i]).append('\n');
            }
        }
        return out.toString();
    }

    private static String read(String file) throws IOException {
        try (InputStream stream = FxShader.class.getResourceAsStream(ROOT + file)) {
            if (stream == null) throw new IOException("missing shader " + file);
            return new String(stream.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    static FxShader compile(String name, String fragmentSource) {
        int vertex = compileShader(GL_VERTEX_SHADER, VERTEX_SOURCE, name + ".vsh");
        int fragment;
        try {
            fragment = compileShader(GL_FRAGMENT_SHADER, fragmentSource, name + ".fsh");
        } catch (IllegalStateException e) {
            GL20.glDeleteShader(vertex);
            throw e;
        }
        int program = GL20.glCreateProgram();
        GL20.glAttachShader(program, vertex);
        GL20.glAttachShader(program, fragment);
        GL30.glBindFragDataLocation(program, 0, "fragColor");
        GL20.glLinkProgram(program);
        int linked = GL20.glGetProgrami(program, GL_LINK_STATUS);
        String log = GL20.glGetProgramInfoLog(program, 32768);
        GL20.glDetachShader(program, vertex);
        GL20.glDetachShader(program, fragment);
        GL20.glDeleteShader(vertex);
        GL20.glDeleteShader(fragment);
        if (linked == 0) {
            GL20.glDeleteProgram(program);
            throw new IllegalStateException(name + " link failed: " + log);
        }
        return new FxShader(program);
    }

    private static int compileShader(int type, String source, String label) {
        int shader = GL20.glCreateShader(type);
        GL20.glShaderSource(shader, source);
        GL20.glCompileShader(shader);
        if (GL20.glGetShaderi(shader, GL_COMPILE_STATUS) == 0) {
            String log = GL20.glGetShaderInfoLog(shader, 32768);
            GL20.glDeleteShader(shader);
            throw new IllegalStateException(label + " compile failed: " + log);
        }
        return shader;
    }
}
