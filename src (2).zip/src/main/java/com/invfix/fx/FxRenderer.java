package com.invfix.fx;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL33;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Пост-обработка эффектов — конвейер The Shooting Star (client.render.PostFxRenderer):
 *
 *  1. снимок главного буфера: цвет блитом, глубина шейдером depth_copy
 *     (блит глубины требует совпадения форматов, а на части драйверов его нет);
 *  2. проходы эффектов по очереди, через два попеременных буфера, в пониженном
 *     разрешении под бюджет пикселей;
 *  3. bloom: 5 уровней вниз (13 выборок, фильтр Хименеса) и обратно (tent 9);
 *  4. composite — обратно в главный буфер: экспозиция, bloom, тряска,
 *     аберрация, радиальное размытие, виньетка, вспышка, послеобраз,
 *     импакт-кадры; плюс возврат резкости мира, если проходы шли в пониженном
 *     разрешении.
 *
 * Бюджет. Каждый 8-й кадр с эффектами время GPU меряется glFinish'ами, и доля
 * разрешения подстраивается так, чтобы эффекты укладывались в 16 мс (не ниже
 * 25 %). Когда эффектов нет — возвращается к 100 % на 5 % за кадр.
 *
 * Состояние GL сохраняется целиком до работы и восстанавливается после:
 * ваниль, Sodium и прочие ничего не замечают.
 *
 * Отличия от оригинала: убраны перемотка (tape/rewind) и покадровость
 * (stepFps); добавлен FxScreen#capture — снимок в удержание без заморозки.
 */
public final class FxRenderer {

    private static final Logger LOGGER = LoggerFactory.getLogger("invfix/fx");

    // ── константы GL (числа сверены с декомпилом оригинала) ────────────────
    private static final int GL_TEXTURE0 = 0x84C0;
    private static final int GL_FRAMEBUFFER = 0x8D40;
    private static final int GL_READ_FRAMEBUFFER = 0x8CA8;
    private static final int GL_DRAW_FRAMEBUFFER = 0x8CA9;
    private static final int GL_COLOR_ATTACHMENT0 = 0x8CE0;
    private static final int GL_DEPTH_ATTACHMENT = 0x8D00;
    private static final int GL_DEPTH_STENCIL_ATTACHMENT = 0x821A;
    private static final int GL_FRAMEBUFFER_COMPLETE = 0x8CD5;
    private static final int GL_COLOR_BUFFER_BIT = 0x4000;
    private static final int GL_DEPTH_BUFFER_BIT = 0x0100;
    private static final int GL_NEAREST = 0x2600;
    private static final int GL_LINEAR = 0x2601;
    private static final int GL_TEXTURE_MIN_FILTER = 0x2801;
    private static final int GL_TEXTURE_MAG_FILTER = 0x2800;
    private static final int GL_TEXTURE_WRAP_S = 0x2802;
    private static final int GL_TEXTURE_WRAP_T = 0x2803;
    private static final int GL_CLAMP_TO_EDGE = 0x812F;
    private static final int GL_TEXTURE_COMPARE_MODE = 0x884C;
    private static final int GL_TEXTURE_INTERNAL_FORMAT = 0x1003;
    private static final int GL_RGBA = 0x1908;
    private static final int GL_RGBA8 = 0x8058;
    private static final int GL_RGBA16F = 0x881A;
    private static final int GL_UNSIGNED_BYTE = 0x1401;
    private static final int GL_FLOAT = 0x1406;
    private static final int GL_DEPTH_COMPONENT = 0x1902;
    private static final int GL_DEPTH_COMPONENT16 = 0x81A5;
    private static final int GL_DEPTH_COMPONENT24 = 0x81A6;
    private static final int GL_DEPTH_COMPONENT32 = 0x81A7;
    private static final int GL_DEPTH24_STENCIL8 = 0x88F0;
    private static final int GL_DEPTH_COMPONENT32F = 0x8CAC;
    private static final int GL_DEPTH32F_STENCIL8 = 0x8CAD;
    private static final int GL_DEPTH_STENCIL = 0x84F9;
    private static final int GL_UNSIGNED_INT_24_8 = 0x84FA;
    private static final int GL_FLOAT_32_UNSIGNED_INT_24_8_REV = 0x8DAD;
    private static final int GL_PIXEL_UNPACK_BUFFER = 0x88EC;
    private static final int GL_PIXEL_UNPACK_BUFFER_BINDING = 0x88EF;
    private static final int GL_DEPTH_TEST = 0x0B71;
    private static final int GL_BLEND = 0x0BE2;
    private static final int GL_CULL_FACE = 0x0B44;
    private static final int GL_SCISSOR_TEST = 0x0C11;
    private static final int GL_DEPTH_FUNC = 0x0B74;
    private static final int GL_ALWAYS = 0x0207;
    private static final int GL_TRIANGLES = 0x0004;

    private static final int BLOOM_LEVELS = 5;
    /** Бюджет пикселей проходов при 100 %: примерно 1920×1200. */
    private static final double PIXEL_BUDGET = 2_300_000.0;

    private final Map<String, FxShader> programs = new HashMap<>();
    private final Set<String> broken = new HashSet<>();
    private final int[] framebuffers = new int[2];
    private final int[] textures = new int[2];
    private final int[] bloomDownFbo = new int[BLOOM_LEVELS];
    private final int[] bloomDownTex = new int[BLOOM_LEVELS];
    private final int[] bloomUpFbo = new int[BLOOM_LEVELS];
    private final int[] bloomUpTex = new int[BLOOM_LEVELS];
    private final int[][] bloomSize = new int[BLOOM_LEVELS][2];
    private final FloatBuffer matrixBuffer = BufferUtils.createFloatBuffer(16);
    private final Binder binder = new Binder();

    private int mainFramebuffer;
    private int snapshotFramebuffer;
    private int snapshotColor;
    private int snapshotDepth;
    private int depthSampler;
    private int keptDepthFbo;
    private int keptDepth;
    private int keptWidth;
    private int keptHeight;
    private boolean depthKept;
    private int vao;
    private int width;
    private int height;
    private int fxWidth;
    private int fxHeight;
    private int sceneLowFbo;
    private int sceneLowTex;
    private int depthFormat;
    private int holdFbo;
    private int holdTex;
    private boolean holding;
    /** «Покадровость» импакт-кадров (stepFps, как в оригинале): готовый кадр держится и повторяется. */
    private int stepFbo;
    private int stepTex;
    private boolean stepHeld;
    private long stepAt;
    private float gameTime;
    private boolean diagnosed;
    private int warmVao;
    private final int[] warmFbo = new int[2];
    private final int[] warmTex = new int[2];
    private double dynamic = 1.0;
    private double lastStep = 1.0;
    private double gpuMs;
    private long gpuStart;
    private int gpuFrame;
    private int gpuSamples;
    private boolean timing;

    public void render(List<FxPass> passes, FxScreen screen, Matrix4f projection, Matrix4f view, float time) {
        Minecraft minecraft = Minecraft.getInstance();
        RenderTarget main = minecraft.getMainRenderTarget();
        int colorId = main.getColorTextureId();
        int depthId = main.getDepthTextureId();
        if (colorId <= 0 || depthId <= 0) return;

        RenderSystem.assertOnRenderThread();
        this.gameTime = time;
        GlState state = GlState.capture();
        try {
            long now = System.nanoTime();
            boolean stepping = screen.stepFps > 0.5F && stepHeld && width == main.width && height == main.height;
            if (stepping && now - stepAt < (long) (1.0E9 / screen.stepFps)) {
                // между шагами — повторить удержанный кадр, мир под ним идёт своим ходом
                GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, mainFramebuffer);
                GL30.glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, colorId, 0);
                GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, stepFbo);
                GL30.glBlitFramebuffer(0, 0, width, height, 0, 0, width, height, GL_COLOR_BUFFER_BIT, GL_NEAREST);
                return;
            }
            if (screen.stepFps <= 0.5F) pace(!passes.isEmpty());
            double step = Math.ceil(dynamic * 16.0) / 16.0;
            if (step != lastStep) {
                lastStep = step;
                LOGGER.debug("[fx] бюджет эффектов {}%", Math.round(step * 100.0));
            }
            double budget = PIXEL_BUDGET * step;
            double scale = Math.min(1.0, Math.sqrt(budget / Math.max(1.0, (double) main.width * main.height)));
            ensureTargets(main.width, main.height,
                    Math.max(2, (int) (main.width * scale)), Math.max(2, (int) (main.height * scale)),
                    colorId, depthId);
            boolean upscaled = fxWidth != width || fxHeight != height;
            snapshot(depthId);
            if (!diagnosed) {
                diagnosed = true;
                diagnose();
            }

            beginTimer(!passes.isEmpty());
            GL11.glViewport(0, 0, fxWidth, fxHeight);
            GL11.glDisable(GL_DEPTH_TEST);
            GL11.glDepthMask(false);
            GL11.glDisable(GL_BLEND);
            GL11.glDisable(GL_CULL_FACE);
            GL11.glDisable(GL_SCISSOR_TEST);
            GL11.glColorMask(true, true, true, true);
            for (int unit = 0; unit < 6; unit++) GL33.glBindSampler(unit, 0);
            GL30.glBindVertexArray(vao);

            Matrix4f inverseProjection = new Matrix4f(projection).invert();
            Matrix4f inverseView = new Matrix4f(view).invert();
            Matrix4f viewProjection = new Matrix4f(projection).mul(view);

            int input = snapshotColor;
            int ping = 0;
            boolean frozen = screen.freeze > 0.5F && holding;
            if (frozen) {
                input = holdTex;
                passes = List.of();
            }

            for (FxPass pass : passes) {
                FxShader program = program(pass.program());
                if (program == null) continue;
                GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, framebuffers[ping]);
                bind(program, input, inverseProjection, inverseView, viewProjection);
                pass.setup().accept(binder);
                GL11.glDrawArrays(GL_TRIANGLES, 0, 3);
                input = textures[ping];
                ping ^= 1;
            }

            // Удержание кадра: по freeze (как в оригинале) или по capture (без заморозки).
            if ((screen.freeze > 0.5F || screen.capture > 0.5F) && !holding) {
                boolean scene = input == snapshotColor;
                GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, scene ? snapshotFramebuffer : framebuffers[ping ^ 1]);
                GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, holdFbo);
                GL30.glBlitFramebuffer(0, 0, scene ? width : fxWidth, scene ? height : fxHeight,
                        0, 0, fxWidth, fxHeight, GL_COLOR_BUFFER_BIT, GL_LINEAR);
                holding = true;
            } else if (screen.freeze <= 0.5F && screen.capture <= 0.5F && screen.afterimage <= 0.001F) {
                holding = false;
            }

            int bloom = screen.bloom > 0.001F && !frozen
                    ? bloom(input, screen, inverseProjection, inverseView, viewProjection) : 0;

            if (upscaled) {
                GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, snapshotFramebuffer);
                GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, sceneLowFbo);
                GL30.glBlitFramebuffer(0, 0, width, height, 0, 0, fxWidth, fxHeight, GL_COLOR_BUFFER_BIT, GL_LINEAR);
            }

            FxShader composite = program("composite");
            GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, mainFramebuffer);
            GL11.glViewport(0, 0, width, height);
            if (composite != null) {
                bind(composite, input, inverseProjection, inverseView, viewProjection);
                bindAux(bloom);
                bindUnit(1, snapshotColor, "SceneSampler");
                bindUnit(3, sceneLowTex, "SceneLowSampler");
                bindUnit(4, bloom != 0 ? bloomDownTex[BLOOM_LEVELS - 1] : 0, "ExposureSampler");
                bindUnit(5, holdTex, "HoldSampler");
                binder.f1("AutoExposure", bloom != 0 ? 1.0F : 0.0F);
                binder.f1("Upscaled", upscaled && !frozen ? 1.0F - Math.min(1.0F, screen.synthetic) : 0.0F);
                binder.f4("Grade", screen.contrast, screen.grain,
                        holding && !frozen ? screen.afterimage : 0.0F, screen.keepHot);
                binder.f2("OutSize", width, height);
                binder.f1("Bloom", bloom != 0 ? screen.bloom : 0.0F);
                binder.f4("Impact", screen.impact, screen.impactMode, screen.impactX, screen.impactY);
                binder.f1("Shake", screen.shake);
                binder.f1("Aberration", screen.aberration);
                binder.f1("Desaturate", screen.desaturate);
                binder.f1("ZoomBlur", screen.zoomBlur);
                binder.f4("Flash", screen.flashR, screen.flashG, screen.flashB, screen.flash);
                binder.f4("Vignette", screen.vignetteR, screen.vignetteG, screen.vignetteB, screen.vignette);
                binder.f4("Cut", screen.cutX0, screen.cutY0, screen.cutX1, screen.cutY1);
                binder.f2("CutShape", screen.cutWidth, screen.cut);
                GL11.glDrawArrays(GL_TRIANGLES, 0, 3);
            } else if (input != snapshotColor) {
                GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, framebuffers[ping ^ 1]);
                GL30.glBlitFramebuffer(0, 0, fxWidth, fxHeight, 0, 0, width, height, GL_COLOR_BUFFER_BIT, GL_LINEAR);
            }
            endTimer();
            if (screen.stepFps > 0.5F) {
                GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, mainFramebuffer);
                GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, stepFbo);
                GL30.glBlitFramebuffer(0, 0, width, height, 0, 0, width, height, GL_COLOR_BUFFER_BIT, GL_NEAREST);
                stepHeld = true;
                stepAt = now;
            } else {
                stepHeld = false;
            }
        } catch (RuntimeException e) {
            LOGGER.error("[fx] сбой пост-обработки эффектов", e);
        } finally {
            state.restore();
        }
    }

    // ── бюджет ─────────────────────────────────────────────────────────────

    private void pace(boolean busy) {
        if (!busy) {
            dynamic = Math.min(1.0, dynamic * 1.05);
            return;
        }
        if (gpuMs > 0.0) {
            double want = Mth.clamp(dynamic * 16.0 / gpuMs, 0.25, 1.0);
            dynamic = Mth.clamp(want < dynamic ? want : dynamic + (want - dynamic) * 0.33, 0.25, 1.0);
            if (++gpuSamples % 6 == 0) {
                LOGGER.debug("[fx] GPU {} мс при бюджете {}%", Math.round(gpuMs * 10.0) / 10.0,
                        Math.round(dynamic * 100.0));
            }
            gpuMs = 0.0;
        }
    }

    private void beginTimer(boolean busy) {
        timing = busy && ++gpuFrame % 8 == 0;
        if (timing) {
            GL11.glFinish();
            gpuStart = System.nanoTime();
        }
    }

    private void endTimer() {
        if (timing) {
            GL11.glFinish();
            gpuMs = (System.nanoTime() - gpuStart) / 1_000_000.0;
            timing = false;
        }
    }

    // ── bloom ──────────────────────────────────────────────────────────────

    private int bloom(int source, FxScreen screen, Matrix4f inverseProjection, Matrix4f inverseView,
                      Matrix4f viewProjection) {
        FxShader down = program("bloom_down");
        FxShader up = program("bloom_up");
        if (down == null || up == null) return 0;

        int input = source;
        int inputW = fxWidth;
        int inputH = fxHeight;
        for (int i = 0; i < BLOOM_LEVELS; i++) {
            GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, bloomDownFbo[i]);
            GL11.glViewport(0, 0, bloomSize[i][0], bloomSize[i][1]);
            bind(down, input, inverseProjection, inverseView, viewProjection);
            bindAux(snapshotColor);
            binder.f2("TexelSize", 1.0F / inputW, 1.0F / inputH);
            binder.f1("Prefilter", i == 0 ? 1.0F : 0.0F);
            binder.f1("Synthetic", screen.synthetic);
            binder.f1("MaskAlpha", source != snapshotColor ? 1.0F : 0.0F);
            GL11.glDrawArrays(GL_TRIANGLES, 0, 3);
            input = bloomDownTex[i];
            inputW = bloomSize[i][0];
            inputH = bloomSize[i][1];
        }
        for (int i = BLOOM_LEVELS - 2; i >= 0; i--) {
            GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, bloomUpFbo[i]);
            GL11.glViewport(0, 0, bloomSize[i][0], bloomSize[i][1]);
            bind(up, input, inverseProjection, inverseView, viewProjection);
            bindAux(bloomDownTex[i]);
            binder.f2("TexelSize", 1.0F / inputW, 1.0F / inputH);
            binder.f1("Radius", Math.max(1.0F, screen.bloomRadius));
            GL11.glDrawArrays(GL_TRIANGLES, 0, 3);
            input = bloomUpTex[i];
            inputW = bloomSize[i][0];
            inputH = bloomSize[i][1];
        }
        return input;
    }

    private void bindUnit(int unit, int texture, String name) {
        GL13.glActiveTexture(GL_TEXTURE0 + unit);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture);
        GL13.glActiveTexture(GL_TEXTURE0);
        int location = binder.program.location(name);
        if (location >= 0) GL20.glUniform1i(location, unit);
    }

    private void bindAux(int texture) {
        bindUnit(2, texture, "AuxSampler");
    }

    // ── диагностика, прогрев, программы ────────────────────────────────────

    /** Один раз: совпадает ли копия глубины с оригиналом. Расхождение — эффекты в мире встанут не туда. */
    private void diagnose() {
        FloatBuffer px = BufferUtils.createFloatBuffer(4);
        GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, mainFramebuffer);
        GL11.glReadPixels(width / 2, height / 3, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, px);
        float mainD = px.get(0);
        GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, snapshotFramebuffer);
        px.clear();
        GL11.glReadPixels(width / 2, height / 3, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, px);
        float snapD = px.get(0);
        int glError = GL11.glGetError();
        LOGGER.info("[fx] диагностика: {}x{} fx {}x{} depthFormat=0x{} mainDepth={} snapshotDepth={} glError=0x{}",
                width, height, fxWidth, fxHeight, Integer.toHexString(depthFormat), mainD, snapD,
                Integer.toHexString(glError));
        if (Math.abs(mainD - snapD) > 0.001F) {
            LOGGER.warn("[fx] копия глубины расходится с оригиналом: {} против {}", mainD, snapD);
        }
    }

    /** Скомпилировать и один раз прогнать программу на крошечном буфере — чтобы первый взрыв не дёрнул кадр. */
    public boolean warm(String name) {
        GlState saved = GlState.capture();
        try {
            FxShader program = program(name);
            if (program == null) return false;
            if (warmVao == 0) {
                warmVao = GL30.glGenVertexArrays();
                for (int i = 0; i < 2; i++) {
                    warmFbo[i] = GL30.glGenFramebuffers();
                    warmTex[i] = GL11.glGenTextures();
                    if (i == 0) hdrTexture(warmTex[i], 1, 1);
                    else colorTexture(warmTex[i], 1, 1);
                    attachColor(warmFbo[i], warmTex[i]);
                }
            }
            GL11.glDisable(GL_DEPTH_TEST);
            GL11.glDepthMask(false);
            GL11.glDisable(GL_BLEND);
            GL11.glDisable(GL_CULL_FACE);
            GL11.glDisable(GL_SCISSOR_TEST);
            GL11.glColorMask(true, true, true, true);
            GL11.glViewport(0, 0, 1, 1);
            GL30.glBindVertexArray(warmVao);
            GL20.glUseProgram(program.id);
            for (int fbo : warmFbo) {
                GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, fbo);
                GL11.glDrawArrays(GL_TRIANGLES, 0, 3);
            }
            GL11.glFinish();
            return true;
        } catch (RuntimeException e) {
            LOGGER.error("[fx] прогрев {} не удался", name, e);
            return false;
        } finally {
            saved.restore();
        }
    }

    public void clearPrograms() {
        programs.values().forEach(FxShader::close);
        programs.clear();
        broken.clear();
    }

    /** Собирается ли программа (собирает при первом вызове; только из потока рендера). */
    public boolean usable(String name) {
        return program(name) != null;
    }

    /** Сломанный шейдер отключается один, остальные эффекты продолжают работать. */
    private FxShader program(String name) {
        FxShader program = programs.get(name);
        if (program != null || broken.contains(name)) return program;
        try {
            program = FxShader.compile(name, FxShader.readSource(name));
            programs.put(name, program);
            LOGGER.info("[fx] собран шейдер {}", name);
        } catch (Exception e) {
            broken.add(name);
            LOGGER.error("[fx] не удалось собрать шейдер {}: {}", name, e.getMessage());
        }
        return program;
    }

    private void bind(FxShader program, int colorTexture, Matrix4f inverseProjection, Matrix4f inverseView,
                      Matrix4f viewProjection) {
        GL20.glUseProgram(program.id);
        binder.program = program;
        binder.nextUnit = Binder.FIRST_TEXTURE_UNIT;
        GL13.glActiveTexture(GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, colorTexture);
        GL13.glActiveTexture(GL_TEXTURE0 + 1);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, snapshotDepth);
        GL13.glActiveTexture(GL_TEXTURE0);
        set1i(program.location("DiffuseSampler"), 0);
        set1i(program.location("DepthSampler"), 1);
        setMatrix(program.location("InvProj"), inverseProjection);
        setMatrix(program.location("InvView"), inverseView);
        setMatrix(program.location("ViewProj"), viewProjection);
        binder.f2("OutSize", fxWidth, fxHeight);
        binder.f1("GTime", gameTime);
    }

    // ── буферы ─────────────────────────────────────────────────────────────

    private void ensureTargets(int newWidth, int newHeight, int newFxWidth, int newFxHeight,
                               int mainColor, int mainDepth) {
        int unpack = GL11.glGetInteger(GL_PIXEL_UNPACK_BUFFER_BINDING);
        GL15.glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
        try {
            if (vao == 0) {
                vao = GL30.glGenVertexArrays();
                for (int i = 0; i < 2; i++) {
                    framebuffers[i] = GL30.glGenFramebuffers();
                    textures[i] = GL11.glGenTextures();
                }
                mainFramebuffer = GL30.glGenFramebuffers();
                snapshotFramebuffer = GL30.glGenFramebuffers();
                snapshotColor = GL11.glGenTextures();
                snapshotDepth = GL11.glGenTextures();
                depthSampler = GL33.glGenSamplers();
                GL33.glSamplerParameteri(depthSampler, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
                GL33.glSamplerParameteri(depthSampler, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
                GL33.glSamplerParameteri(depthSampler, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
                GL33.glSamplerParameteri(depthSampler, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
                GL33.glSamplerParameteri(depthSampler, GL_TEXTURE_COMPARE_MODE, 0);
                sceneLowFbo = GL30.glGenFramebuffers();
                sceneLowTex = GL11.glGenTextures();
                holdFbo = GL30.glGenFramebuffers();
                holdTex = GL11.glGenTextures();
                for (int i = 0; i < BLOOM_LEVELS; i++) {
                    bloomDownFbo[i] = GL30.glGenFramebuffers();
                    bloomDownTex[i] = GL11.glGenTextures();
                    bloomUpFbo[i] = GL30.glGenFramebuffers();
                    bloomUpTex[i] = GL11.glGenTextures();
                }
            }
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, mainDepth);
            int format = GL11.glGetTexLevelParameteri(GL11.GL_TEXTURE_2D, 0, GL_TEXTURE_INTERNAL_FORMAT);
            if (newWidth != width || newHeight != height || format != depthFormat
                    || newFxWidth != fxWidth || newFxHeight != fxHeight) {
                width = newWidth;
                height = newHeight;
                fxWidth = newFxWidth;
                fxHeight = newFxHeight;
                depthFormat = format;
                allocate();
            }
            GL30.glBindFramebuffer(GL_FRAMEBUFFER, mainFramebuffer);
            GL30.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, mainColor, 0);
            attachDepth(mainDepth, isDepthStencil(depthFormat));
            GL11.glDrawBuffer(GL_COLOR_ATTACHMENT0);
            GL11.glReadBuffer(GL_COLOR_ATTACHMENT0);
            check("main");
        } finally {
            GL15.glBindBuffer(GL_PIXEL_UNPACK_BUFFER, unpack);
        }
    }

    private void allocate() {
        for (int i = 0; i < 2; i++) {
            colorTexture(textures[i], fxWidth, fxHeight);
            GL30.glBindFramebuffer(GL_FRAMEBUFFER, framebuffers[i]);
            GL30.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, textures[i], 0);
            GL11.glDrawBuffer(GL_COLOR_ATTACHMENT0);
            check("ping-pong");
        }
        for (int i = 0; i < BLOOM_LEVELS; i++) {
            int w = Math.max(1, fxWidth >> (i + 1));
            int h = Math.max(1, fxHeight >> (i + 1));
            bloomSize[i][0] = w;
            bloomSize[i][1] = h;
            hdrTexture(bloomDownTex[i], w, h);
            attachColor(bloomDownFbo[i], bloomDownTex[i]);
            hdrTexture(bloomUpTex[i], w, h);
            attachColor(bloomUpFbo[i], bloomUpTex[i]);
        }
        colorTexture(sceneLowTex, fxWidth, fxHeight);
        attachColor(sceneLowFbo, sceneLowTex);
        colorTexture(holdTex, fxWidth, fxHeight);
        attachColor(holdFbo, holdTex);
        holding = false;
        if (stepFbo == 0) {
            stepFbo = GL30.glGenFramebuffers();
            stepTex = GL11.glGenTextures();
        }
        colorTexture(stepTex, width, height);
        attachColor(stepFbo, stepTex);
        stepHeld = false;
        colorTexture(snapshotColor, width, height);

        boolean stencil = isDepthStencil(depthFormat);
        int internal = switch (depthFormat) {
            case GL_DEPTH_COMPONENT16, GL_DEPTH_COMPONENT24, GL_DEPTH_COMPONENT32, GL_DEPTH24_STENCIL8,
                 GL_DEPTH_COMPONENT32F, GL_DEPTH32F_STENCIL8 -> depthFormat;
            default -> GL_DEPTH_COMPONENT32F;
        };
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, snapshotDepth);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, 0);
        if (stencil) {
            GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, internal, width, height, 0, GL_DEPTH_STENCIL,
                    internal == GL_DEPTH32F_STENCIL8 ? GL_FLOAT_32_UNSIGNED_INT_24_8_REV : GL_UNSIGNED_INT_24_8,
                    0L);
        } else {
            GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, internal, width, height, 0, GL_DEPTH_COMPONENT, GL_FLOAT, 0L);
        }
        GL30.glBindFramebuffer(GL_FRAMEBUFFER, snapshotFramebuffer);
        GL30.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, snapshotColor, 0);
        attachDepth(snapshotDepth, stencil);
        GL11.glDrawBuffer(GL_COLOR_ATTACHMENT0);
        check("snapshot");
    }

    private static void hdrTexture(int texture, int w, int h) {
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL_RGBA16F, w, h, 0, GL_RGBA, GL_FLOAT, 0L);
    }

    private static void colorTexture(int texture, int w, int h) {
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, 0L);
    }

    private static void attachColor(int fbo, int texture) {
        GL30.glBindFramebuffer(GL_FRAMEBUFFER, fbo);
        GL30.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, texture, 0);
        GL11.glDrawBuffer(GL_COLOR_ATTACHMENT0);
        check("color");
    }

    // ── снимок и глубина ───────────────────────────────────────────────────

    private void snapshot(int mainDepth) {
        GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, mainFramebuffer);
        GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, snapshotFramebuffer);
        GL30.glBlitFramebuffer(0, 0, width, height, 0, 0, width, height, GL_COLOR_BUFFER_BIT, GL_NEAREST);
        boolean kept = depthKept && keptWidth == width && keptHeight == height;
        copyDepth(kept ? keptDepth : mainDepth, width, height);
        depthKept = false;
    }

    public void forgetKeptDepth() {
        depthKept = false;
    }

    /**
     * При графике «Fabulous» ванильный PostChain прозрачности перед концом
     * renderLevel портит глубину главного буфера. Её копия снимается до него.
     */
    public void keepSceneDepth() {
        RenderTarget main = Minecraft.getInstance().getMainRenderTarget();
        int depthId = main.getDepthTextureId();
        if (depthId <= 0 || vao == 0 || program("depth_copy") == null) return;
        GlState state = GlState.capture();
        int unpack = GL11.glGetInteger(GL_PIXEL_UNPACK_BUFFER_BINDING);
        GL15.glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
        try {
            if (keptDepthFbo == 0) {
                keptDepthFbo = GL30.glGenFramebuffers();
                keptDepth = GL11.glGenTextures();
            }
            if (keptWidth != main.width || keptHeight != main.height) {
                keptWidth = main.width;
                keptHeight = main.height;
                GL11.glBindTexture(GL11.GL_TEXTURE_2D, keptDepth);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, 0);
                GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32F, keptWidth, keptHeight, 0,
                        GL_DEPTH_COMPONENT, GL_FLOAT, 0L);
                GL30.glBindFramebuffer(GL_FRAMEBUFFER, keptDepthFbo);
                GL30.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, keptDepth, 0);
                GL11.glDrawBuffer(0);
                GL11.glReadBuffer(0);
                check("kept depth");
            }
            GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, keptDepthFbo);
            copyDepth(depthId, keptWidth, keptHeight);
            depthKept = true;
        } catch (RuntimeException e) {
            LOGGER.error("[fx] не удалось сохранить глубину сцены", e);
        } finally {
            GL15.glBindBuffer(GL_PIXEL_UNPACK_BUFFER, unpack);
            state.restore();
        }
    }

    /** Глубина копируется шейдером по значению; блит — только запасной путь. */
    private void copyDepth(int mainDepth, int w, int h) {
        FxShader copy = program("depth_copy");
        if (copy == null) {
            GL30.glBlitFramebuffer(0, 0, w, h, 0, 0, w, h, GL_DEPTH_BUFFER_BIT, GL_NEAREST);
            return;
        }
        int depthFunc = GL11.glGetInteger(GL_DEPTH_FUNC);
        GL11.glViewport(0, 0, w, h);
        GL11.glColorMask(false, false, false, false);
        GL11.glDisable(GL_BLEND);
        GL11.glDisable(GL_CULL_FACE);
        GL11.glDisable(GL_SCISSOR_TEST);
        GL11.glEnable(GL_DEPTH_TEST);
        GL11.glDepthFunc(GL_ALWAYS);
        GL11.glDepthMask(true);
        GL20.glUseProgram(copy.id);
        GL13.glActiveTexture(GL_TEXTURE0 + 1);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, mainDepth);
        GL33.glBindSampler(1, depthSampler);
        GL13.glActiveTexture(GL_TEXTURE0);
        set1i(copy.location("DepthSampler"), 1);
        GL30.glBindVertexArray(vao);
        GL11.glDrawArrays(GL_TRIANGLES, 0, 3);
        GL33.glBindSampler(1, 0);
        GL11.glDepthFunc(depthFunc);
        GL11.glDisable(GL_DEPTH_TEST);
        GL11.glDepthMask(false);
        GL11.glColorMask(true, true, true, true);
    }

    private static boolean isDepthStencil(int format) {
        return format == GL_DEPTH24_STENCIL8 || format == GL_DEPTH32F_STENCIL8;
    }

    private static void attachDepth(int texture, boolean stencil) {
        if (stencil) {
            GL30.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, 0, 0);
            GL30.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL11.GL_TEXTURE_2D, texture, 0);
        } else {
            GL30.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL11.GL_TEXTURE_2D, 0, 0);
            GL30.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, texture, 0);
        }
    }

    private static void check(String label) {
        int status = GL30.glCheckFramebufferStatus(GL_FRAMEBUFFER);
        if (status != GL_FRAMEBUFFER_COMPLETE) {
            throw new IllegalStateException("Incomplete " + label + " framebuffer: " + status);
        }
    }

    private static void set1i(int location, int value) {
        if (location >= 0) GL20.glUniform1i(location, value);
    }

    private void setMatrix(int location, Matrix4f matrix) {
        if (location < 0) return;
        matrixBuffer.clear();
        matrix.get(matrixBuffer);
        GL20.glUniformMatrix4fv(location, false, matrixBuffer);
    }

    // ── uniform'ы ──────────────────────────────────────────────────────────

    private static final class Binder implements FxUniforms {
        /** Юниты 0–5 заняты сценой, глубиной, aux, scene-low, экспозицией и удержанием. */
        static final int FIRST_TEXTURE_UNIT = 6;

        FxShader program;
        int nextUnit;

        @Override
        public void glTexture(String sampler, int texture) {
            int location = program.location(sampler);
            if (location < 0 || nextUnit >= 16 || texture == 0) return;
            int unit = nextUnit++;
            GL13.glActiveTexture(GL_TEXTURE0 + unit);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture);
            GL33.glBindSampler(unit, 0);
            GL13.glActiveTexture(GL_TEXTURE0);
            GL20.glUniform1i(location, unit);
        }

        @Override
        public void f1(String name, float x) {
            int location = program.location(name);
            if (location >= 0) GL20.glUniform1f(location, x);
        }

        @Override
        public void f2(String name, float x, float y) {
            int location = program.location(name);
            if (location >= 0) GL20.glUniform2f(location, x, y);
        }

        @Override
        public void f3(String name, float x, float y, float z) {
            int location = program.location(name);
            if (location >= 0) GL20.glUniform3f(location, x, y, z);
        }

        @Override
        public void f4(String name, float x, float y, float z, float w) {
            int location = program.location(name);
            if (location >= 0) GL20.glUniform4f(location, x, y, z, w);
        }

        @Override
        public void vec4s(String name, float[] values) {
            int location = program.location(name + "[0]");
            if (location < 0) location = program.location(name);
            if (location >= 0) GL20.glUniform4fv(location, values);
        }
    }

    // ── состояние GL ───────────────────────────────────────────────────────

    private record GlState(int drawFbo, int readFbo, int program, int vao, int activeTexture,
                           int[] textures, int[] samplers, int[] viewport, boolean depthTest, boolean blend,
                           boolean cull, boolean scissor, boolean depthMask, boolean[] colorMask) {

        static final int UNITS = 16;
        private static final int GL_VIEWPORT = 0x0BA2;
        private static final int GL_ACTIVE_TEXTURE = 0x84E0;
        private static final int GL_TEXTURE_BINDING_2D = 0x8069;
        private static final int GL_SAMPLER_BINDING = 0x8919;
        private static final int GL_COLOR_WRITEMASK = 0x0C23;
        private static final int GL_DRAW_FRAMEBUFFER_BINDING = 0x8CA6;
        private static final int GL_READ_FRAMEBUFFER_BINDING = 0x8CAA;
        private static final int GL_CURRENT_PROGRAM = 0x8B8D;
        private static final int GL_VERTEX_ARRAY_BINDING = 0x85B5;
        private static final int GL_DEPTH_WRITEMASK = 0x0B72;

        static GlState capture() {
            IntBuffer viewport = BufferUtils.createIntBuffer(4);
            GL11.glGetIntegerv(GL_VIEWPORT, viewport);
            int active = GL11.glGetInteger(GL_ACTIVE_TEXTURE);
            int[] textures = new int[UNITS];
            int[] samplers = new int[UNITS];
            for (int unit = 0; unit < UNITS; unit++) {
                GL13.glActiveTexture(GL_TEXTURE0 + unit);
                textures[unit] = GL11.glGetInteger(GL_TEXTURE_BINDING_2D);
                samplers[unit] = GL11.glGetInteger(GL_SAMPLER_BINDING);
            }
            GL13.glActiveTexture(active);
            ByteBuffer mask = BufferUtils.createByteBuffer(16);
            GL11.glGetBooleanv(GL_COLOR_WRITEMASK, mask);
            return new GlState(GL11.glGetInteger(GL_DRAW_FRAMEBUFFER_BINDING),
                    GL11.glGetInteger(GL_READ_FRAMEBUFFER_BINDING),
                    GL11.glGetInteger(GL_CURRENT_PROGRAM),
                    GL11.glGetInteger(GL_VERTEX_ARRAY_BINDING),
                    active, textures, samplers,
                    new int[]{viewport.get(0), viewport.get(1), viewport.get(2), viewport.get(3)},
                    GL11.glIsEnabled(GL_DEPTH_TEST), GL11.glIsEnabled(GL_BLEND), GL11.glIsEnabled(GL_CULL_FACE),
                    GL11.glIsEnabled(GL_SCISSOR_TEST), GL11.glGetBoolean(GL_DEPTH_WRITEMASK),
                    new boolean[]{mask.get(0) != 0, mask.get(1) != 0, mask.get(2) != 0, mask.get(3) != 0});
        }

        void restore() {
            toggle(GL_DEPTH_TEST, depthTest);
            toggle(GL_BLEND, blend);
            toggle(GL_CULL_FACE, cull);
            toggle(GL_SCISSOR_TEST, scissor);
            GL11.glDepthMask(depthMask);
            GL11.glColorMask(colorMask[0], colorMask[1], colorMask[2], colorMask[3]);
            GL20.glUseProgram(program);
            GL30.glBindVertexArray(vao);
            for (int unit = 0; unit < UNITS; unit++) {
                GL13.glActiveTexture(GL_TEXTURE0 + unit);
                GL11.glBindTexture(GL11.GL_TEXTURE_2D, textures[unit]);
                GL33.glBindSampler(unit, samplers[unit]);
            }
            GL13.glActiveTexture(activeTexture);
            GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, drawFbo);
            GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, readFbo);
            GL11.glViewport(viewport[0], viewport[1], viewport[2], viewport[3]);
        }

        private static void toggle(int capability, boolean enabled) {
            if (enabled) GL11.glEnable(capability);
            else GL11.glDisable(capability);
        }
    }
}
