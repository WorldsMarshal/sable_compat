package com.invfix.fx;

import net.minecraft.client.Minecraft;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;

import java.util.List;

/**
 * Обвязка эффектов на клиенте: тик, сброс при выходе, перезагрузка шейдеров
 * вместе с ресурсами (F3+T) и прогрев.
 *
 * Прогрев — как ShaderWarmup в The Shooting Star: все программы собираются и
 * прогоняются заранее, по одной за тик, чтобы компиляция не легла на кадр
 * первого взрыва. Идёт с первого тика клиента (ещё на титульном экране) и
 * заново после каждой перезагрузки ресурсов.
 */
public final class FxClient {

    private FxClient() {}

    /** Все программы ветки. Новый эффект — новая строка здесь. */
    static final List<String> PROGRAMS = List.of("composite", "bloom_down", "bloom_up", "depth_copy", "nuke",
            "flight", "boom", "shockwave", "heat_disruption", "heat_vision", "eye_glow", "energy_ball", "sentry", "thermal", "crater_glow", "space_fold");

    private static int warmNext = 0;

    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
    public static final class GameBus {

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft minecraft = Minecraft.getInstance();
            if (warmNext < PROGRAMS.size()) {
                FxManager.warmShader(PROGRAMS.get(warmNext++));
            }
            if (!minecraft.isPaused()) FxManager.tick(minecraft);
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            FxManager.clear();
        }
    }

    @EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {

        @SubscribeEvent
        public static void onRegisterReloadListeners(RegisterClientReloadListenersEvent event) {
            event.registerReloadListener((ResourceManagerReloadListener) manager -> {
                FxManager.reloadShaders();
                warmNext = 0;
            });
        }
    }
}
