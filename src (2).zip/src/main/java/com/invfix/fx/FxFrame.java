package com.invfix.fx;

import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

/** Кадр, для которого эффект собирает проходы. Координаты в шейдер идут относительно камеры. */
public record FxFrame(Minecraft minecraft, float partial, Vec3 camera) {

    /** Мировая точка относительно камеры: float в шейдере не теряет точность вдали от нуля мира. */
    public Vec3 rel(Vec3 world) {
        return world.subtract(camera);
    }
}
