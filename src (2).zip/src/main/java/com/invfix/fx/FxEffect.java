package com.invfix.fx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Один живой эффект на клиенте. Как SpellFx в The Shooting Star: тикает со
 * своим возрастом, на каждом кадре отдаёт проходы и параметры композита.
 */
public abstract class FxEffect {

    protected int age;

    final void tick(Minecraft minecraft, ClientLevel level) {
        onTick(minecraft, level, age);
        age++;
    }

    protected void onTick(Minecraft minecraft, ClientLevel level, int age) {}

    /** Сколько тиков живёт эффект. */
    protected abstract int duration();

    public boolean finished() {
        return age > duration();
    }

    protected void onRemoved() {}

    /** Точка, по расстоянию до которой эффект отсекается. */
    public abstract Vec3 focus();

    /** Дальше этого от камеры эффект не рисуется вовсе. */
    public double range() {
        return 600.0;
    }

    /**
     * Проходы этого эффекта идут раньше всех остальных (перекраска всего мира —
     * Thermal Sense: остальные эффекты ложатся поверх неё в своих цветах).
     */
    public boolean first() {
        return false;
    }

    public void passes(FxFrame frame, List<FxPass> out) {}

    public void screen(FxFrame frame, FxScreen screen) {}

    /** Возраст в тиках с долей кадра. */
    protected float ticks(FxFrame frame) {
        return age + frame.partial();
    }

    // ── помощники из оригинала (SpellFx / StarFx) ──────────────────────────

    /** Плавный вход за [in0, in1] и выход за [out0, out1]. */
    protected static float window(float t, float in0, float in1, float out0, float out1) {
        return (float) (Mth.clamp((t - in0) / Math.max(in1 - in0, 0.001), 0.0, 1.0)
                * (1.0 - Mth.clamp((t - out0) / Math.max(out1 - out0, 0.001), 0.0, 1.0)));
    }

    protected static float smooth(float x) {
        x = Mth.clamp(x, 0.0F, 1.0F);
        return x * x * (3.0F - 2.0F * x);
    }

    /**
     * Последовательность импакт-кадров: каждый держится frameSeconds, режим —
     * по номеру кадра; режим < 0 — пропуск. Центр — проекция точки на экран.
     */
    protected static void impactSequence(FxScreen screen, float since, Vec3 focus, float strength,
                                         float frameSeconds, int... modes) {
        if (since < 0.0F || strength <= 0.0F) return;
        int step = (int) (since / frameSeconds);
        if (step < modes.length && modes[step] >= 0) {
            float[] uv = FxManager.uv(focus);
            screen.addImpact(strength, modes[step], uv[0], uv[1]);
        }
    }

    protected static float proximity(FxFrame frame, Vec3 at, double range) {
        return (float) Mth.clamp(1.0 - frame.camera().distanceTo(at) / range, 0.0, 1.0);
    }
}
