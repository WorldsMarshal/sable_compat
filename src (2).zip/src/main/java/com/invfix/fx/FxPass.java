package com.invfix.fx;

import java.util.function.Consumer;

/** Один проход эффекта: имя шейдера из shaders/fx и установка его переменных. */
public record FxPass(String program, Consumer<FxUniforms> setup) {}
