package com.invfix.fx;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Клиентский диспетчер эффектов — FxManager из The Shooting Star без
 * катсцен, подписей и HUD.
 *
 * Кадр: в начале LevelRenderer#renderLevel запоминаются матрицы вида и
 * проекции; перед ванильным PostChain прозрачности снимается глубина (только
 * при «Fabulous»); в конце renderLevel все эффекты отдают проходы и параметры,
 * и {@link FxRenderer} рисует их поверх готового мира. Всё ниже — только
 * рендер-поток клиента.
 */
public final class FxManager {

    private static final int MAX_ACTIVE = 24;
    private static final List<FxEffect> ACTIVE = new ArrayList<>();
    private static final FxRenderer RENDERER = new FxRenderer();
    private static final FxScreen SCREEN = new FxScreen();
    private static final Matrix4f CAPTURED_VIEW = new Matrix4f();
    private static final Matrix4f CAPTURED_PROJECTION = new Matrix4f();
    private static final Matrix4f LAST_VIEW_PROJECTION = new Matrix4f();
    private static Vec3 lastCamera = Vec3.ZERO;
    /** Накопленная «травма» тряски камеры, гаснет сама. */
    private static float trauma;
    /** Тряска картинки из эффектов прошлого кадра — подмешивается в камеру. */
    private static float rumble;

    private FxManager() {}

    public static void add(FxEffect fx) {
        while (ACTIVE.size() >= MAX_ACTIVE) {
            ACTIVE.remove(0).onRemoved();
        }
        ACTIVE.add(fx);
    }

    public static boolean active() {
        return !ACTIVE.isEmpty();
    }

    public static void tick(Minecraft minecraft) {
        ClientLevel level = minecraft.level;
        if (level == null) {
            clear();
            return;
        }
        Iterator<FxEffect> it = ACTIVE.iterator();
        while (it.hasNext()) {
            FxEffect fx = it.next();
            fx.tick(minecraft, level);
            if (fx.finished()) {
                it.remove();
                fx.onRemoved();
            }
        }
        trauma = Math.max(0.0F, trauma - 0.035F);
    }

    public static void clear() {
        for (FxEffect fx : List.copyOf(ACTIVE)) fx.onRemoved();
        ACTIVE.clear();
        trauma = 0.0F;
        rumble = 0.0F;
    }

    /** Толчок камеры от источника: слабеет с расстоянием до нуля на range. */
    public static void shake(Vec3 source, float amount, double range) {
        double distance = lastCamera.distanceTo(source);
        float falloff = (float) Mth.clamp(1.0 - distance / range, 0.0, 1.0);
        trauma = Math.min(1.0F, trauma + amount * falloff);
    }

    // ── кадр ───────────────────────────────────────────────────────────────

    public static void capture(Matrix4f view, Matrix4f projection) {
        CAPTURED_VIEW.set(view);
        CAPTURED_PROJECTION.set(projection);
        RENDERER.forgetKeptDepth();
    }

    public static void beforePostChain() {
        if (Minecraft.useShaderTransparency() && (!ACTIVE.isEmpty() || trauma > 0.0F)) {
            RENDERER.keepSceneDepth();
        }
    }

    public static void render(Camera camera, float partial) {
        Minecraft minecraft = Minecraft.getInstance();
        lastCamera = camera.getPosition();
        LAST_VIEW_PROJECTION.set(CAPTURED_PROJECTION).mul(CAPTURED_VIEW);
        if (ACTIVE.isEmpty() && trauma <= 0.0F) {
            rumble = 0.0F;
            return;
        }
        FxFrame frame = new FxFrame(minecraft, partial, lastCamera);
        List<FxPass> passes = new ArrayList<>();
        SCREEN.reset();
        for (int round = 0; round < 2; round++) {
            for (FxEffect fx : ACTIVE) {
                if (fx.first() != (round == 0)) continue;
                if (fx.focus().distanceTo(lastCamera) > fx.range()) continue;
                fx.passes(frame, passes);
                fx.screen(frame, SCREEN);
            }
        }
        rumble = SCREEN.shake;
        SCREEN.shake = Math.min(1.0F, SCREEN.shake * 0.4F + trauma * trauma * 0.35F);
        if (!passes.isEmpty() || !SCREEN.idle()) {
            float time = ((minecraft.level == null ? 0L : minecraft.level.getGameTime() % 24000L) + partial) / 20.0F;
            RENDERER.render(passes, SCREEN, CAPTURED_PROJECTION, CAPTURED_VIEW, time);
        }
    }

    /** Тряска камеры — из GameRenderer#bobHurt, как в оригинале. */
    public static void applyShake(PoseStack poseStack, float partial) {
        float amount = trauma * trauma + rumble * 0.25F;
        if (amount <= 1.0E-4F) return;
        float t = (System.nanoTime() % 100_000_000_000L) / 1.0E9F;
        float yaw = (float) (Math.sin(t * 37.0) * 0.6 + Math.sin(t * 61.0) * 0.4) * 2.6F * amount;
        float pitch = (float) (Math.sin(t * 43.0 + 1.3) * 0.6 + Math.sin(t * 71.0) * 0.4) * 2.2F * amount;
        float roll = (float) Math.sin(t * 29.0 + 0.7) * 3.0F * amount;
        poseStack.mulPose(Axis.ZP.rotationDegrees(roll));
        poseStack.mulPose(Axis.XP.rotationDegrees(pitch));
        poseStack.mulPose(Axis.YP.rotationDegrees(yaw));
    }

    /** Экранные uv мировой точки (0..1), для центра импакт-кадров. За камерой — центр экрана. */
    public static float[] uv(Vec3 world) {
        Vec3 rel = world.subtract(lastCamera);
        Vector4f clip = LAST_VIEW_PROJECTION.transform(new Vector4f((float) rel.x, (float) rel.y, (float) rel.z, 1.0F));
        if (clip.w <= 0.05F) return new float[]{0.5F, 0.5F};
        return new float[]{
                Mth.clamp(clip.x / clip.w * 0.5F + 0.5F, 0.0F, 1.0F),
                Mth.clamp(clip.y / clip.w * 0.5F + 0.5F, 0.0F, 1.0F)};
    }

    /**
     * Экранные uv мировой точки без зажима в 0..1 и глубина отсечения:
     * {x, y, w}; w <= 0 — точка за камерой.
     */
    public static float[] uvRaw(Vec3 world) {
        Vec3 rel = world.subtract(lastCamera);
        Vector4f clip = LAST_VIEW_PROJECTION.transform(new Vector4f((float) rel.x, (float) rel.y, (float) rel.z, 1.0F));
        if (clip.w <= 1.0E-4F) return new float[]{0.5F, 0.5F, clip.w};
        return new float[]{clip.x / clip.w * 0.5F + 0.5F, clip.y / clip.w * 0.5F + 0.5F, clip.w};
    }

    public static Vec3 camera() {
        return lastCamera;
    }

    /** Куда смотрит камера кадра, в мире: из захваченной матрицы вида (только поворот, мир относительно камеры). */
    public static Vec3 cameraForward() {
        Vector3f f = new Matrix4f(CAPTURED_VIEW).invert().transformDirection(new Vector3f(0.0F, 0.0F, -1.0F));
        return new Vec3(f.x, f.y, f.z);
    }

    /**
     * Работает ли шейдер name: собирается без ошибок. Для эффектов со старой
     * отрисовкой про запас (лучи Heat Vision). Только из потока рендера.
     */
    public static boolean shaderUsable(String name) {
        return RENDERER.usable(name);
    }

    public static boolean warmShader(String name) {
        return RENDERER.warm(name);
    }

    public static void reloadShaders() {
        RENDERER.clearPrograms();
    }
}
