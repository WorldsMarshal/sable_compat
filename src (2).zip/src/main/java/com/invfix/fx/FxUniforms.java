package com.invfix.fx;

import net.minecraft.world.phys.Vec3;

/** Установка uniform'ов текущего прохода. Отсутствующие в шейдере имена молча пропускаются. */
public interface FxUniforms {

    void f1(String name, float x);

    void f2(String name, float x, float y);

    void f3(String name, float x, float y, float z);

    void f4(String name, float x, float y, float z, float w);

    void vec4s(String name, float[] values);

    /** Привязать готовую GL-текстуру к сэмплеру (юниты с 6-го). */
    void glTexture(String sampler, int texture);

    default void v3(String name, Vec3 v) {
        f3(name, (float) v.x, (float) v.y, (float) v.z);
    }
}
