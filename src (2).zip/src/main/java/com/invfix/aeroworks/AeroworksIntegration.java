package com.invfix.aeroworks;

import com.simibubi.create.api.stress.BlockStressValues;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModList;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Интеграция с Aeroworks: тяжёлый гироскоп для сверхтяжёлых кораблей.
 *
 * Регистрация идёт нашим модом, а не их Registrate — так у блока остаётся наш
 * идентификатор и наши ассеты, а вся механика наследуется от их классов.
 *
 * Всё завязано на присутствие aeroworks и create: без них регистрация просто не
 * выполняется, а классы-наследники никогда не загружаются.
 */
public final class AeroworksIntegration {

    private static final String MODID = "sable_compat";

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MODID);

    public static final DeferredBlock<HeavyGyroscopeBlock> HEAVY_GYROSCOPE =
            BLOCKS.register("heavy_gyroscope", () -> new HeavyGyroscopeBlock(
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_LIGHT_GRAY)
                            .strength(4.0F, 8.0F)
                            .requiresCorrectToolForDrops()
                            .sound(SoundType.NETHERITE_BLOCK)
                            .noOcclusion()));

    public static final DeferredItem<BlockItem> HEAVY_GYROSCOPE_ITEM =
            ITEMS.register("heavy_gyroscope",
                    () -> new BlockItem(HEAVY_GYROSCOPE.get(), new Item.Properties()));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<HeavyGyroscopeBlockEntity>>
            HEAVY_GYROSCOPE_BE = BLOCK_ENTITIES.register("heavy_gyroscope",
                    () -> BlockEntityType.Builder.of(HeavyGyroscopeBlockEntity::new,
                            HEAVY_GYROSCOPE.get()).build(null));

    private AeroworksIntegration() {}

    public static boolean available() {
        return ModList.get().isLoaded("aeroworks") && ModList.get().isLoaded("create");
    }

    public static void register(IEventBus modEventBus) {
        if (!available()) return;
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
        modEventBus.addListener(AeroworksIntegration::onCommonSetup);
        modEventBus.addListener(AeroworksIntegration::onBuildCreativeTabs);
    }

    /**
     * Нагрузка регистрируется здесь, а не в свойствах блока: Create держит
     * импакты в собственном реестре BlockStressValues, и записывать туда можно
     * только после того, как блок уже существует.
     */
    private static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> BlockStressValues.IMPACTS.register(
                HEAVY_GYROSCOPE.get(), () -> HeavyGyroscopeBlockEntity.STRESS_IMPACT));
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(HEAVY_GYROSCOPE_ITEM);
        }
    }
}
