package com.invfix.aeroworks;

import com.mred231.aeroworks.content.gyroscope.GyroscopeBlock;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;

/**
 * Блок тяжёлого гироскопа. Вся геометрия, состояния и логика вала достаются от
 * Aeroworks — переопределены только тип и класс блок-энтити, чтобы IBE создавал
 * нашу сущность, а не их.
 */
public class HeavyGyroscopeBlock extends GyroscopeBlock {

    public HeavyGyroscopeBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    /**
     * Возвращаемые типы намеренно сырые.
     *
     * GyroscopeBlock реализует Create'овский IBE, параметризованный ИХ
     * блок-энтити. Объявить переопределение как Class<HeavyGyroscopeBlockEntity>
     * нельзя — это сужение чужого параметра типа, компилятор такое не пропустит.
     * Сырой тип совместим с любым вариантом объявления родителя.
     */
    @Override
    @SuppressWarnings({"rawtypes", "unchecked"})
    public Class getBlockEntityClass() {
        return HeavyGyroscopeBlockEntity.class;
    }

    @Override
    @SuppressWarnings({"rawtypes", "unchecked"})
    public BlockEntityType getBlockEntityType() {
        return AeroworksIntegration.HEAVY_GYROSCOPE_BE.get();
    }
}
