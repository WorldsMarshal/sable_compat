package com.invfix.aeroworks;

import com.mred231.aeroworks.content.gyroscope.GyroscopeBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Тяжёлый гироскоп: тот же механизм, другие числа.
 *
 * Наследуется от гироскопа Aeroworks намеренно. Их контроллер собирает флот
 * простым {@code actor instanceof GyroscopeBlockEntity}, поэтому наш подкласс
 * попадает в расчёт сам, без единой правки на их стороне.
 *
 * Отличий ровно два: нагрузка и авторитет. Нагрузка задаётся при регистрации
 * блока через BlockStressValues, авторитет — миксином в контроллер, потому что
 * там он берётся из глобального конфига и одинаков для всех гироскопов.
 */
public class HeavyGyroscopeBlockEntity extends GyroscopeBlockEntity {

    /**
     * Авторитет на единицу. У обычного гироскопа 5000, потолок конфига
     * 1 000 000 — сюда он не упирается, потому что значение живёт в коде, а не
     * в конфиге Aeroworks.
     */
    public static final double AUTHORITY_PER_UNIT = 4_000_000.0;

    /**
     * Нагрузка в SU на оборот. Полная тяга у гироскопа наступает на 256 RPM
     * (referenceRpm в их конфиге), значит 62.5 * 256 = 16 000 SU на входе —
     * ровно та цифра, которая нужна. У обычного гироскопа импакт 16, то есть
     * 4096 SU на тех же оборотах.
     */
    public static final double STRESS_IMPACT = 62.5;

    /**
     * Конструктор принимает только позицию и состояние, потому что
     * BlockEntityType.Builder.of ждёт именно BlockEntitySupplier с сигнатурой
     * (BlockPos, BlockState). Родительский класс требует ещё и тип, поэтому тип
     * подставляется здесь из реестра — к моменту создания сущности он уже есть.
     */
    public HeavyGyroscopeBlockEntity(BlockPos pos, BlockState state) {
        super(AeroworksIntegration.HEAVY_GYROSCOPE_BE.get(), pos, state);
    }
}
