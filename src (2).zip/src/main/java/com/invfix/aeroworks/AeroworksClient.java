package com.invfix.aeroworks;

import com.mred231.aeroworks.content.gyroscope.GyroscopeRenderer;
import com.mred231.aeroworks.content.gyroscope.GyroscopeVisual;
import dev.engine_room.flywheel.lib.visualization.SimpleBlockEntityVisualizer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/**
 * Клиентская часть тяжёлого гироскопа.
 *
 * Переиспользуются РОДНЫЕ рендерер и Flywheel-визуал Aeroworks — именно поэтому
 * модель получается абсолютно та же, вплоть до вращения маховика и подсветки
 * индикаторов. Своего кода отрисовки у нас нет вообще.
 */
@OnlyIn(Dist.CLIENT)
public final class AeroworksClient {

    private AeroworksClient() {}

    public static void init(IEventBus modEventBus) {
        if (!AeroworksIntegration.available()) return;
        modEventBus.addListener(AeroworksClient::onRegisterRenderers);
        modEventBus.addListener(AeroworksClient::onClientSetup);
    }

    private static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(
                AeroworksIntegration.HEAVY_GYROSCOPE_BE.get(), GyroscopeRenderer::new);
    }

    /**
     * Flywheel-визуал регистрируется отдельно от обычного рендерера: при
     * включённом бэкенде Flywheel рисует именно он, а BER остаётся запасным
     * путём. Без этой строки тяжёлый гироскоп у части игроков был бы невидим.
     */
    private static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> SimpleBlockEntityVisualizer
                .builder(AeroworksIntegration.HEAVY_GYROSCOPE_BE.get())
                .factory(GyroscopeVisual::new)
                .neverSkipVanillaRender()
                .apply());
    }
}
