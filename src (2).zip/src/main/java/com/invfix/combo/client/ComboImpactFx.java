package com.invfix.combo.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.List;

/**
 * Попадание ударной способности при Attackpwr > 500 (сервер — ComboImpact):
 * импакт-кадры и ударная волна, тем же путём, что взрыв Kinetic Strike и удары
 * The Shooting Star.
 *
 * Импакт-кадры — короткая белая вспышка и несколько плоских кадров без растра с
 * пульсирующим радиальным размытием: 0.18 с на > 500, 0.24 с на > 1500.
 * Чёрно-белые (режимы композита 40/41 вперемежку); у Headbutt три кадра —
 * бело-чёрный, красно-чёрный (самый короткий), чёрно-белый. Видит их сам
 * ударивший и все в 48 блоках от удара. Новый набор не начинается, пока идёт
 * текущий — общий на клиент замок.
 *
 * Ударная волна — shockwave.fsh: > 500 одно кольцо воздуха поперёк удара и
 * короткая волна пыли по земле; > 1500 три кольца, сфера скачка уплотнения,
 * широкая волна пыли с крошкой и сильная вспышка — всё в 1.2 раза шире, — и
 * вспышка ионизированного воздуха в точке удара: сине-белый светящийся шар с
 * раскалённым ядром, бегущий от него тонкий светящийся фронт ионизации и
 * короткие разряды; мир вокруг на миг подсвечен. Без огня и дыма. Только визуал.
 */
@OnlyIn(Dist.CLIENT)
public final class ComboImpactFx extends FxEffect {

    private static final double FRAMES_RANGE = 48.0;

    /**
     * Наборы кадров: {режим композита, длительность в секундах}. Перед каждым —
     * белая вспышка (FLASH_*). 40 — светлые формы белым на чёрном («бело-
     * чёрный»), 41 — наоборот («чёрно-белый»), 38 — красным на чёрном.
     * > 500 — 0.18 с всего, > 1500 — 0.24 с.
     */
    private static final float[][] BLACK_WHITE_1 = {{40, 0.055F}, {41, 0.055F}, {40, 0.05F}};
    private static final float[][] BLACK_WHITE_2 = {{40, 0.055F}, {41, 0.055F}, {40, 0.055F}, {41, 0.05F}};
    /** Headbutt: бело-чёрный, красно-чёрный (самый короткий), чёрно-белый. */
    private static final float[][] HEADBUTT_1 = {{40, 0.065F}, {38, 0.03F}, {41, 0.065F}};
    private static final float[][] HEADBUTT_2 = {{40, 0.085F}, {38, 0.045F}, {41, 0.085F}};
    private static final float FLASH_1 = 0.02F;
    private static final float FLASH_2 = 0.025F;

    /** Пока идёт набор кадров — новый не начинать (System.nanoTime конца). */
    private static long framesBusyUntil;

    private final ClientLevel level;
    private final Vec3 at;
    private final Vec3 dir;
    private final int tier;
    private final boolean red;
    private final boolean frames;
    private final float seed;

    private ComboImpactFx(ClientLevel level, Vec3 at, Vec3 dir, int tier, boolean red, boolean frames) {
        this.level = level;
        this.at = at;
        this.dir = dir;
        this.tier = tier;
        this.red = red;
        this.frames = frames;
        this.seed = (float) ((Mth.getSeed((int) at.x, (int) at.y, (int) at.z) & 0xFFFFL) / 65535.0);
    }

    public static void start(int attackerId, double x, double y, double z, float dx, float dy, float dz, int tier,
                             boolean headbutt) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        Vec3 at = new Vec3(x, y, z);
        Vec3 dir = new Vec3(dx, dy, dz);
        if (dir.lengthSqr() < 1.0E-6) dir = new Vec3(0.0, 0.0, 1.0);
        dir = dir.normalize();
        int t = tier >= 2 ? 2 : 1;

        Entity camera = mc.getCameraEntity();
        boolean own = camera != null && camera.getId() == attackerId;
        Vec3 eye = mc.gameRenderer.getMainCamera().getPosition();
        boolean frames = false;
        if (own || eye.distanceTo(at) <= FRAMES_RANGE) {
            long now = System.nanoTime();
            if (now >= framesBusyUntil) {
                frames = true;
                framesBusyUntil = now + (long) (sequenceSeconds(t, headbutt) * 1.0E9);
            }
        }
        FxManager.add(new ComboImpactFx(level, at, dir, t, headbutt, frames));
        FxManager.shake(at, t == 2 ? 0.55F : 0.22F, t == 2 ? 96.0 : 40.0);
        // The Whole Sentry Power: белые разряды в точке удара
        com.invfix.sentry.client.SentryClient.arcsIfSentry(attackerId, at, t == 2 ? 6.0F : 3.0F);
    }

    private static float[][] sequence(int tier, boolean headbutt) {
        if (headbutt) return tier == 2 ? HEADBUTT_2 : HEADBUTT_1;
        return tier == 2 ? BLACK_WHITE_2 : BLACK_WHITE_1;
    }

    private static float flashSeconds(int tier) {
        return tier == 2 ? FLASH_2 : FLASH_1;
    }

    private static float sequenceSeconds(int tier, boolean headbutt) {
        float total = flashSeconds(tier);
        for (float[] f : sequence(tier, headbutt)) total += f[1];
        return total;
    }

    @Override
    protected int duration() {
        return tier == 2 ? 36 : 18;
    }

    @Override
    public boolean finished() {
        return super.finished() || Minecraft.getInstance().level != level;
    }

    @Override
    public Vec3 focus() {
        return at;
    }

    @Override
    public double range() {
        return 160.0;
    }

    // ── ударная волна ──────────────────────────────────────────────────────

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        float s = ticks(frame) / 20.0F;
        boolean heavy = tier == 2;
        float ring;
        float thick;
        float shell;
        float ground;
        float band;
        float flash;
        float k;
        float travel;
        float glowR = 0.0F;
        float glowI = 0.0F;
        float front = 0.0F;
        float fil = 0.0F;
        if (heavy) {
            // ударная волна > 1500 — в 1.2 раза больше
            final float w = 1.2F;
            ring = w * (1.0F + 16.0F * (1.0F - (float) Math.exp(-s / 0.25F)));
            travel = w * 14.0F * (1.0F - (float) Math.exp(-s / 0.4F));
            thick = w * (0.4F + s * 0.8F);
            shell = w * (2.0F + s * 45.0F);
            ground = w * (1.0F + 28.0F * (1.0F - (float) Math.exp(-s / 0.45F)));
            band = w * (1.5F + s * 3.0F);
            flash = 2.0F * (float) Math.exp(-s / 0.07F);
            k = 1.0F - smooth((s - 0.7F) / 1.1F);
            // ионизированный воздух: шар свечения ~3.8 блока за 0.15 с; держится в полную силу,
            // пока идут импакт-кадры (до 0.24 с), и гаснет после них, к ~0.7 с; фронт ионизации
            // до ~12 блоков за ~0.6 с; разряды — три коротких и тусклых, гаснут к ~0.36 с
            glowR = w * (0.6F + 2.6F * (1.0F - (float) Math.exp(-s / 0.06F)));
            glowI = 2.4F * (1.0F - smooth((s - 0.25F) / 0.45F)) + 0.8F * (float) Math.exp(-s / 0.08F);
            front = w * (1.0F + 9.0F * (1.0F - (float) Math.exp(-s / 0.25F)));
            fil = 1.0F - smooth((s - 0.24F) / 0.12F);
        } else {
            ring = 0.6F + 6.0F * (1.0F - (float) Math.exp(-s / 0.22F));
            travel = 6.0F * (1.0F - (float) Math.exp(-s / 0.3F));
            thick = 0.25F + s * 0.6F;
            shell = 0.0F;
            ground = 0.5F + 9.0F * (1.0F - (float) Math.exp(-s / 0.3F));
            band = 1.0F + s * 1.5F;
            flash = 1.2F * (float) Math.exp(-s / 0.05F);
            k = 1.0F - smooth((s - 0.4F) / 0.5F);
        }
        if (k <= 0.001F && flash <= 0.001F && glowI <= 0.001F) return;
        Vec3 c = frame.rel(at);
        Vec3 cam = frame.camera();
        float ox = (float) (cam.x - 2048.0 * Math.floor(cam.x / 2048.0));
        float oy = (float) (cam.y - 2048.0 * Math.floor(cam.y / 2048.0));
        float oz = (float) (cam.z - 2048.0 * Math.floor(cam.z / 2048.0));
        float fTier = tier;
        float fRed = red ? 1.0F : 0.0F;
        float gR = glowR;
        float gI = glowI;
        float gFront = front;
        float gFil = fil;
        out.add(new FxPass("shockwave", u -> {
            u.v3("Target", c);
            u.v3("Facing", dir);
            u.f3("Origin", ox, oy, oz);
            u.f4("P0", s, fTier, seed, k);
            u.f4("P1", ring, shell, ground, flash);
            u.f4("P2", fRed, thick, band, travel);
            u.f4("P3", gR, gI, gFront, gFil);
        }));
    }

    // ── импакт-кадры и композит ────────────────────────────────────────────

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        float s = ticks(frame) / 20.0F;
        boolean heavy = tier == 2;
        float near = (float) Mth.clamp(1.0 - frame.camera().distanceTo(at) / range(), 0.0, 1.0);

        if (frames) {
            float flashTime = flashSeconds(tier);
            if (s < flashTime) {
                screen.addFlash(red ? 0xFFE0E0 : 0xFFFFFF, heavy ? 1.6F : 1.2F);
            } else {
                float into = s - flashTime;
                float[][] seq = sequence(tier, red);
                for (int i = 0; i < seq.length; i++) {
                    if (into < seq[i][1]) {
                        float[] uv = FxManager.uv(at);
                        screen.addImpact(1.0F, (int) seq[i][0], uv[0], uv[1]);
                        screen.zoomBlur = Math.max(screen.zoomBlur, (i % 2 == 0 ? 0.6F : 0.2F) * (heavy ? 1.0F : 0.7F));
                        if (heavy) screen.aberration = Math.max(screen.aberration, i % 2 == 0 ? 0.3F : 1.0F);
                        break;
                    }
                    into -= seq[i][1];
                }
            }
        }

        screen.bloom = Math.max(screen.bloom, (heavy ? 0.9F : 0.6F) * (float) Math.exp(-s / 0.3F) * near);
        screen.bloomRadius = Math.max(screen.bloomRadius, heavy ? 1.5F : 1.2F);
        // > 1500: светящийся воздух держит свечение чуть дольше вспышки
        if (heavy) screen.bloom = Math.max(screen.bloom, 0.8F * (1.0F - smooth((s - 0.25F) / 0.5F)) * near);
        if (heavy) {
            screen.aberration = Math.max(screen.aberration, window(s, 0.0F, 0.02F, 0.3F, 1.0F) * 0.6F * near);
        }
    }
}
