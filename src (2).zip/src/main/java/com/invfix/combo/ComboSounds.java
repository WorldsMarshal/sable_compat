package com.invfix.combo;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Звуки попаданий ударных способностей при Attackpwr > 500 (ComboImpact).
 * Нарезаны из saitama-serious-punch (присланного референса), шесть звуков,
 * выбранных на прослушке v6: обычные — первый удар записи (0.9 с, высота
 * 0 / +4 / −4 / +7 %), Headbutt — второй удар (0.9 с, 0 / −5 %). Тяжёлые
 * события (> 1500) играют те же файлы, только громче и слышны дальше.
 * Файлы — assets/sable_compat/sounds/combo/, варианты выбираются случайно
 * (sounds.json).
 */
public final class ComboSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, "sable_compat");

    public static final DeferredHolder<SoundEvent, SoundEvent> IMPACT = register("combo_impact");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMPACT_HEAVY = register("combo_impact_heavy");
    public static final DeferredHolder<SoundEvent, SoundEvent> HEADBUTT = register("combo_headbutt");
    public static final DeferredHolder<SoundEvent, SoundEvent> HEADBUTT_HEAVY = register("combo_headbutt_heavy");

    private static DeferredHolder<SoundEvent, SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath("sable_compat", name)));
    }

    private ComboSounds() {}
}
