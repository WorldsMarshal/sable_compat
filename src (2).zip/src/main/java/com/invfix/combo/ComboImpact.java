package com.invfix.combo;

import net.mcreator.invincibleinc.init.InvincibleIncModGameRules;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Развитие ударных способностей Fighting Style Standard (вкладка Combos) и Heavy
 * Punch — по стате Attackpwr (PlayerVariables.attackPower) атакующего игрока, не
 * по уровню: у разных рас на одном уровне разный урон.
 *
 *  Attackpwr ≤ 500   — всё как в Invincible.
 *  Attackpwr > 500   — на каждое попадание импакт-кадры (как в The Shooting
 *                      Star: вспышка и рисованные кадры по 1/12 с) и небольшая
 *                      ударная волна. Кадры чёрно-белые, у Headbutt — чёрно-
 *                      красные. Новый набор кадров не начинается, пока идёт
 *                      текущий (это решает клиент).
 *  Attackpwr > 1500  — серьёзная ударная волна, кратер в точке удара (когда
 *                      цель из него улетит — иначе она падает в яму и не
 *                      отлетает от следующего удара) и
 *                      переработанный, более широкий «туннель» брошенной цели
 *                      (BB_THROWN, см. BBThrownProcedureMixin). Ниже 1500
 *                      разрушение — родное Invincible.
 *
 * Попадание ловится на LivingDamageEvent.Post: урон реально прошёл (не съеден
 * неуязвимостью). Какая способность ударила — по стеку вызова: удары идут из
 * процедур Invincible, в том числе отложенных (queueServerWork) и из тиков
 * эффектов — их лямбды и анонимные классы лежат в тех же классах. Тип урона —
 * invincible_inc:attack_power (полётная ветка Heavy Punch — invincible_inc:powers).
 *
 * Звук попадания (ComboSounds) — на каждое попадание, один на удар.
 *
 * Только игроки: атакующий должен быть игроком. Ударные волны — только визуал.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class ComboImpact {

    /** «Более 500» / «более 1500» Attackpwr. */
    public static final double TIER1 = 500.0;
    public static final double TIER2 = 1500.0;

    /** Кому показывать удар: игроки в этом радиусе от точки удара. */
    private static final double SEND_RANGE = 128.0;
    /** Кратер — не чаще раза в столько тиков на атакующего (Barrage и Fury Kicks бьют каждый тик). */
    private static final int CRATER_COOLDOWN = 10;
    /** Сколько тиков после удара > 1500 туннель брошенной цели идёт по-новому (BB_THROWN — 30 тиков). */
    static final int THROW_WINDOW = 40;
    static final String TAG_THROW_TICK = "invfix_heavyThrowTick";
    static final String TAG_THROW_AP = "invfix_heavyThrowAP";
    /** Множитель разрушений бросившего (The Whole Sentry Power: ×1.5). */
    static final String TAG_THROW_MULT = "invfix_heavyThrowMult";

    private static final String PKG = "net.mcreator.invincibleinc.procedures.";
    /** Классы процедур, из которых бьют эти способности. */
    private static final Set<String> ABILITIES = Set.of(
            "HeavyAttackProcedure",              // Heavy Punch (ПКМ), земля и полёт
            "BarrageTicksProcedure",             // Barrage Punch, серия
            "BarrageEndProcedure",               // Barrage Punch, финальный
            "DoubleKicks1Procedure",             // Double Kick
            "OverheadAttackTicksProcedure",      // Overhead Attack
            "HammeringStrikeonTicksProcedure",   // Hammering Strike
            "FlippingKick1Procedure",            // Flipping Kick
            "FuryKicksDamageProcedure",          // Fury Kicks
            "Backkick1Procedure",                // Back Kick
            "TornadoKick1Procedure",             // Tornado Kick
            "Headbutt1Procedure");               // Headbutt
    private static final String HEADBUTT = "Headbutt1Procedure";

    private static final ResourceKey<DamageType> ATTACK_POWER = ResourceKey.create(Registries.DAMAGE_TYPE,
            ResourceLocation.parse("invincible_inc:attack_power"));
    private static final ResourceKey<DamageType> POWERS = ResourceKey.create(Registries.DAMAGE_TYPE,
            ResourceLocation.parse("invincible_inc:powers"));
    /** Тот же список неразрушаемого, что у Invincible (data/minecraft/tags/block/nondestroy.json). */
    static final TagKey<Block> NONDESTROY = BlockTags.create(ResourceLocation.parse("minecraft:nondestroy"));

    /** Кратер выкапывается, когда цель покинула его (её отбросило) или не позже этого срока, тиков. */
    private static final int CRATER_MAX_WAIT = 60;

    private record PendingCrater(ServerLevel level, Vec3 feet, double ap, LivingEntity victim, long tick, double mult) {}

    /** Ждущие кратеры, по одному на атакующего (новый заменяет старый). */
    private static final Map<UUID, PendingCrater> PENDING = new HashMap<>();

    private static final Map<UUID, Long> LAST_PACKET = new HashMap<>();
    private static final Map<UUID, Long> LAST_CRATER = new HashMap<>();

    private ComboImpact() {}

    @SubscribeEvent
    public static void onDamage(LivingDamageEvent.Post event) {
        LivingEntity victim = event.getEntity();
        if (!(victim.level() instanceof ServerLevel level)) return;
        DamageSource source = event.getSource();
        if (!(source.getEntity() instanceof ServerPlayer attacker)) return;
        if (!source.is(ATTACK_POWER) && !source.is(POWERS)) return;

        double ap;
        try {
            ap = attacker.getData(InvincibleIncModVariables.PLAYER_VARIABLES).attackPower;
        } catch (Exception e) {
            return;
        }
        if (!(ap > TIER1)) return;
        String ability = ability();
        if (ability == null) return;

        int tier = ap > TIER2 ? 2 : 1;
        boolean headbutt = HEADBUTT.equals(ability);
        long now = level.getGameTime();
        Vec3 at = victim.getBoundingBox().getCenter();
        UUID id = attacker.getUUID();

        // один удар на тик: несколько целей одного удара — один визуал
        Long last = LAST_PACKET.get(id);
        if (last == null || last != now) {
            LAST_PACKET.put(id, now);
            Vec3 dir = attacker.getLookAngle();
            PacketDistributor.sendToPlayersNear(level, null, at.x, at.y, at.z, SEND_RANGE,
                    new ComboImpactPacket(attacker.getId(), at.x, at.y, at.z,
                            (float) dir.x, (float) dir.y, (float) dir.z, (byte) tier, headbutt));
            // звук удара (ComboSounds): громкость задаёт и дальность — 2 ≈ 32 блока, 5 ≈ 80
            var sound = tier == 2
                    ? (headbutt ? ComboSounds.HEADBUTT_HEAVY : ComboSounds.IMPACT_HEAVY)
                    : (headbutt ? ComboSounds.HEADBUTT : ComboSounds.IMPACT);
            level.playSound(null, at.x, at.y, at.z, sound.get(), SoundSource.PLAYERS,
                    tier == 2 ? 5.0F : 2.0F, 0.9F + level.getRandom().nextFloat() * 0.2F);
        }

        if (tier == 2) {
            // брошенная этим ударом цель режет мир по-новому (BBThrownProcedureMixin)
            victim.getPersistentData().putLong(TAG_THROW_TICK, now);
            victim.getPersistentData().putDouble(TAG_THROW_AP, ap);
            victim.getPersistentData().putDouble(TAG_THROW_MULT, com.invfix.sentry.SentryHandler.destruction(attacker));
            Long crater = LAST_CRATER.get(id);
            if (crater == null || now - crater >= CRATER_COOLDOWN) {
                LAST_CRATER.put(id, now);
                // не сразу: кратер под ногами, вырытый в момент удара, роняет цель в яму, и отдача
                // следующего удара (финал Barrage, второй пинок Double Kick, Fury Kicks) упирается в
                // её стенку — цель не отлетает. Кратер ждёт, пока цель улетит из него.
                PENDING.put(id, new PendingCrater(level, victim.position(), ap, victim, now,
                        com.invfix.sentry.SentryHandler.destruction(attacker)));
            }
        }
    }

    /**
     * Выкопать ждущие кратеры. Цель держат на месте (серия Barrage, первый пинок
     * Double Kick) — ждём; отбросило за край будущего кратера, умерла или прошло
     * 3 с — копаем там, куда пришёлся удар.
     */
    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (PENDING.isEmpty() || !(event.getLevel() instanceof ServerLevel level)) return;
        long now = level.getGameTime();
        PENDING.values().removeIf(p -> {
            if (p.level() != level) return false;
            double rh = craterRadius(p.ap()) * p.mult();
            LivingEntity v = p.victim();
            boolean gone = v.isRemoved() || !v.isAlive() || v.level() != level
                    || v.position().distanceTo(p.feet()) > rh + 1.0;
            if (!gone && now - p.tick() < CRATER_MAX_WAIT) return false;
            crater(level, p.feet(), p.ap(), p.mult());
            return true;
        });
    }

    static double craterRadius(double ap) {
        return 3.5 + 4.5 * over(ap);
    }

    /** Какая из способностей сейчас наносит урон — по классам в стеке. null — не наша. */
    private static String ability() {
        return StackWalker.getInstance().walk(frames -> frames.limit(96)
                .map(StackWalker.StackFrame::getClassName)
                .filter(n -> n.startsWith(PKG))
                .map(n -> {
                    String s = n.substring(PKG.length());
                    int inner = s.indexOf('$');
                    return inner >= 0 ? s.substring(0, inner) : s;
                })
                .filter(ABILITIES::contains)
                .findFirst()
                .orElse(null));
    }

    /** 0 на 1500 Attackpwr, 1 на 3000 и выше — во сколько раз «сильнее порога». */
    static double over(double ap) {
        return Mth.clamp((ap - TIER2) / 1500.0, 0.0, 1.0);
    }

    // ── разрушение > 1500 ──────────────────────────────────────────────────

    /**
     * Кратер под точкой удара: приплюснутый эллипсоид с рваным краем, центр — у
     * ног цели, так что удар вбивает её в грунт. Радиус 3.5 на 1500 Attackpwr до
     * 8 на 3000+. Как у Invincible: уважает геймрул invincibleBlockDestruction и
     * тег minecraft:nondestroy, блоки исчезают без дропа.
     */
    static void crater(ServerLevel level, Vec3 feet, double ap, double mult) {
        if (!level.getGameRules().getBoolean(InvincibleIncModGameRules.INVINCIBLE_BLOCK_DESTRUCTION)) return;
        double t = over(ap);
        double rh = craterRadius(ap) * mult;
        double rv = rh * 0.6;
        BlockPos c = BlockPos.containing(feet);
        RandomSource random = level.getRandom();
        int removed = carve(level, c, rh, rv, random, 0.3);
        if (removed > 0) {
            level.sendParticles(ParticleTypes.EXPLOSION, c.getX() + 0.5, c.getY() + 0.5, c.getZ() + 0.5,
                    3, rh * 0.4, rv * 0.3, rh * 0.4, 0.0);
            level.sendParticles(ParticleTypes.CLOUD, c.getX() + 0.5, c.getY() + 0.5, c.getZ() + 0.5,
                    20 + (int) (rh * 4), rh * 0.5, rv * 0.4, rh * 0.5, 0.15);
            level.playSound(null, c, SoundEvents.GENERIC_EXPLODE.value(), SoundSource.PLAYERS,
                    2.0F + (float) t * 2.0F, 0.7F + level.getRandom().nextFloat() * 0.2F);
        }
    }

    /**
     * Убрать блоки в эллипсоиде (rh — по горизонтали, rv — по вертикали) с
     * рваным краем: внешние roughness доли радиуса берутся случайно.
     * Возвращает число убранных блоков.
     */
    static int carve(ServerLevel level, BlockPos c, double rh, double rv, RandomSource random, double roughness) {
        int ih = Mth.ceil(rh);
        int iv = Mth.ceil(rv);
        int removed = 0;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int dy = -iv; dy <= iv; dy++) {
            for (int dx = -ih; dx <= ih; dx++) {
                for (int dz = -ih; dz <= ih; dz++) {
                    double d = (dx * dx + dz * dz) / (rh * rh) + (dy * dy) / (rv * rv);
                    if (d > 1.0) continue;
                    if (d > 1.0 - roughness && random.nextFloat() < (d - (1.0 - roughness)) / roughness) continue;
                    pos.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    BlockState state = level.getBlockState(pos);
                    if (state.isAir() || state.is(NONDESTROY)) continue;
                    level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                    removed++;
                }
            }
        }
        return removed;
    }

    /**
     * Брошенная ударом > 1500 цель (вместо родного тика BB_THROWN): туннель шире
     * родного (эллипсоид 5×3) — 7.5×4.5 на 1500 Attackpwr до 9×5.4 на 3000+.
     * true — родной тик не нужен.
     */
    public static boolean heavyThrowTick(ServerLevel level, Entity entity, double x, double y, double z) {
        var data = entity.getPersistentData();
        if (!data.contains(TAG_THROW_TICK)) return false;
        long since = level.getGameTime() - data.getLong(TAG_THROW_TICK);
        if (since < 0 || since > THROW_WINDOW) return false;
        if (!level.getGameRules().getBoolean(InvincibleIncModGameRules.INVINCIBLE_BLOCK_DESTRUCTION)) return true;
        if (since < 2) return true;
        double t = over(data.getDouble(TAG_THROW_AP));
        double rh = (7.5 + 1.5 * t) * (data.contains(TAG_THROW_MULT) ? data.getDouble(TAG_THROW_MULT) : 1.0);
        double rv = rh * 0.6;
        BlockPos c = BlockPos.containing(x, y, z);
        int removed = carve(level, c, rh, rv, level.getRandom(), 0.25);
        if (removed > 0) {
            level.sendParticles(ParticleTypes.CLOUD, x, y + 0.5, z, 6, rh * 0.4, rv * 0.4, rh * 0.4, 0.1);
            level.sendParticles(ParticleTypes.EXPLOSION, x, y + 0.5, z, 1, rh * 0.3, rv * 0.3, rh * 0.3, 0.0);
            if (since % 4 == 0) {
                level.playSound(null, c, SoundEvents.GENERIC_EXPLODE.value(), SoundSource.NEUTRAL, 1.5F,
                        0.8F + level.getRandom().nextFloat() * 0.2F);
            }
            entity.hurt(new DamageSource(level.holderOrThrow(ATTACK_POWER)), 3.0F * Math.min(removed, 30));
        }
        return true;
    }
}
