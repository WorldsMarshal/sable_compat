package com.invfix.combo;

import com.invfix.combo.client.ComboImpactFx;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Сервер → клиент: попадание ударной способности при Attackpwr > 500 (ComboImpact).
 * tier 1 — > 500, tier 2 — > 1500; headbutt — чёрно-красные кадры и алая волна.
 */
public record ComboImpactPacket(int attackerId, double x, double y, double z, float dx, float dy, float dz,
                                byte tier, boolean headbutt) implements CustomPacketPayload {

    public static final Type<ComboImpactPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "combo_impact"));

    public static final StreamCodec<FriendlyByteBuf, ComboImpactPacket> STREAM_CODEC = StreamCodec.of(
            (buf, m) -> {
                buf.writeVarInt(m.attackerId());
                buf.writeDouble(m.x());
                buf.writeDouble(m.y());
                buf.writeDouble(m.z());
                buf.writeFloat(m.dx());
                buf.writeFloat(m.dy());
                buf.writeFloat(m.dz());
                buf.writeByte(m.tier());
                buf.writeBoolean(m.headbutt());
            },
            buf -> new ComboImpactPacket(buf.readVarInt(), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                    buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readByte(), buf.readBoolean()));

    @Override
    public Type<ComboImpactPacket> type() {
        return TYPE;
    }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(ComboImpactPacket p, IPayloadContext context) {
        context.enqueueWork(() -> ComboImpactFx.start(p.attackerId, p.x, p.y, p.z, p.dx, p.dy, p.dz, p.tier, p.headbutt));
    }
}
