package com.invfix.threatmode;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Клиент → сервер: новое состояние переключателя Playful/Threatening Mode.
 * Шлётся при каждом нажатии клавиши (toggle), не каждый тик.
 */
public record ThreatModePacket(boolean held) implements CustomPacketPayload {

    public static final Type<ThreatModePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "threat_mode"));

    public static final StreamCodec<FriendlyByteBuf, ThreatModePacket> STREAM_CODEC =
            StreamCodec.of(
                    (buf, msg) -> buf.writeBoolean(msg.held()),
                    buf -> new ThreatModePacket(buf.readBoolean())
            );

    @Override
    public Type<ThreatModePacket> type() { return TYPE; }

    public static void handleServer(ThreatModePacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
                ThreatModeState.set(sp.getUUID(), pkt.held());
                // Статус в action bar — там же, где Invincible пишет про Combat Mode.
                sp.displayClientMessage(
                        net.minecraft.network.chat.Component.translatable(pkt.held()
                                ? "message.sable_compat.threat_mode.on"
                                : "message.sable_compat.threat_mode.off"),
                        true);
            }
        });
    }
}
