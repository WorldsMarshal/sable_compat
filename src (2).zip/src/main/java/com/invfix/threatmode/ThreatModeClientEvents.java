package com.invfix.threatmode;

import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Клиентская логика Playful/Threatening Mode: ПЕРЕКЛЮЧЕНИЕ по нажатию
 * (не удержание). Каждое нажатие клавиши инвертирует режим и шлёт
 * {@link ThreatModePacket} серверу; сервер в ответ показывает статус в
 * action bar — там же, где Invincible пишет про Combat Mode.
 *
 * Локальный флаг {@link #isHeld()} использует и Heat Vision — пока режим
 * включён, глаза дают только «зарядку»-свечение, без луча.
 */
@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class ThreatModeClientEvents {

    private static boolean active = false;

    private ThreatModeClientEvents() {}

    /** Включён ли режим на клиенте (имя историческое, семантика — toggle). */
    public static boolean isHeld() { return active; }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            active = false;
            return;
        }
        while (ThreatModeKeyMappings.THREATENING_MODE.consumeClick()) {
            active = !active;
            if (mc.getConnection() != null) {
                PacketDistributor.sendToServer(
                        new ThreatModePacket(active), new CustomPacketPayload[0]);
            }
        }
    }
}
