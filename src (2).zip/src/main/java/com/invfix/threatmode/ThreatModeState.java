package com.invfix.threatmode;

import net.minecraft.world.entity.Entity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Серверное состояние ПЕРЕКЛЮЧАТЕЛЯ Playful/Threatening Mode
 * (клавиша по умолчанию — Left Alt, нажатие инвертирует режим).
 *
 * Пока режим включён: базовая атака ЛКМ игрока перестаёт учитывать его силовой
 * скейл (attackPower) — урон как у ваниль-игрока (бонусы предметов остаются);
 * тепловизор даёт только зарядку без луча; снаряды НЕ отскакивают от игрока,
 * а честно попадают — урон уходит в дюру-щит обычным конвейером Invincible
 * (см. DamagePhysicsHandler#onProjectileImpact).
 *
 * Клиент шлёт {@link ThreatModePacket} при каждом переключении; сервер хранит
 * флаг по UUID. Запись чистится при выходе игрока — после релога режим
 * выключен, чтобы не залипал между сессиями.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class ThreatModeState {

    private static final Set<UUID> HELD = ConcurrentHashMap.newKeySet();

    private ThreatModeState() {}

    public static void set(UUID id, boolean held) {
        if (id == null) return;
        if (held) HELD.add(id);
        else HELD.remove(id);
    }

    public static boolean isHeld(Entity entity) {
        return entity != null && HELD.contains(entity.getUUID());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        HELD.remove(event.getEntity().getUUID());
    }
}
