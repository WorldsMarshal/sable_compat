package com.invfix.threatmode;

import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;

/**
 * Клавиша Playful/Threatening Mode (переключение по нажатию). По умолчанию — Left Alt.
 *
 * Категория совпадает с биндами оригинального мода ("key.categories.invincible_inc"),
 * поэтому в меню управления она появляется в том же разделе, а не в новой вкладке,
 * и игрок может переназначить её как любую другую клавишу мода.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class ThreatModeKeyMappings {

    public static final KeyMapping THREATENING_MODE = new KeyMapping(
            "key.sable_compat.threatening_mode",
            GLFW.GLFW_KEY_LEFT_ALT,
            "key.categories.invincible_inc");

    private ThreatModeKeyMappings() {}

    @SubscribeEvent
    public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(THREATENING_MODE);
    }
}
