package com.invfix;

import java.util.UUID;

/**
 * Инжектируется в HandleBlockEntity через миксин.
 * Хранит множитель максимальной силы (maxForce) для каждого игрока,
 * держащего рукоятку.
 */
public interface IHandleStrengthHost {
    void invfix$putPlayerStrength(UUID player, double mult);
    void invfix$removePlayerStrength(UUID player);
    double invfix$getPlayerStrength(UUID player);
}
