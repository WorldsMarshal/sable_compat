package com.invfix.integration.ponder;

import com.invfix.cyberware.machines.MachineRegistry;
import com.invfix.cyberware.machines.crafter.PrecisionMachineBlockEntity;
import com.invfix.cyberware.machines.crafter.UltraPrecisionMachineBlockEntity;
import net.createmod.ponder.api.registration.PonderPlugin;
import net.createmod.ponder.api.registration.PonderSceneRegistrationHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;

/**
 * Ponder-плагин: вешает на блоки-контроллеры всех программируемых машин сцену
 * «как собрать обвязку». Открывается по клавише Ponder при наведении на блок
 * или из индекса Ponder по этому предмету.
 *
 * <p><b>Важно про {@code scene.title(id, fallback)}:</b> первый параметр — это
 * НЕ произвольный ключ локализации, а ПОЛНАЯ ПЕРЕЗАПИСЬ {@code scene.sceneId}
 * (см. {@code PonderSceneBuilder.title()}: {@code this.scene.sceneId =
 * ResourceLocation.fromNamespaceAndPath(namespace, sceneId)}). Именно поэтому
 * сюда идёт голый id сцены (совпадающий с путём схемы), а НЕ "id.header" —
 * лишний суффикс ломал все последующие ключи текста, дописывая его в sceneId
 * (отсюда была видна сырая строка "...precision_machine_build.header.text_1"
 * прямо в игре вместо переведённого текста).
 */
public class SablePonderPlugin implements PonderPlugin {

    @Override
    public String getModId() { return "sable_compat"; }

    @Override
    public void registerScenes(PonderSceneRegistrationHelper helper) {
        ResourceLocation precisionKey = BuiltInRegistries.BLOCK.getKey(MachineRegistry.PRECISION_MACHINE.get());
        ResourceLocation ultraKey = BuiltInRegistries.BLOCK.getKey(MachineRegistry.ULTRA_PRECISION_MACHINE.get());
        ResourceLocation hyperKey = BuiltInRegistries.BLOCK.getKey(MachineRegistry.HYPERBARIC_FURNACE.get());
        ResourceLocation lithoKey = BuiltInRegistries.BLOCK.getKey(
                com.invfix.cyberware.lithograph.LithographRegistry.LITHOGRAPH_CONTROLLER.get());

        // Литограф: короб Д8×Ш5×В5 (рёбра — iron_block, стены — industrial_plating_block,
        // без шлюзов — только контроллер + питание на короткой стене).
        helper.addStoryBoard(
                lithoKey,
                "lithograph_build",
                (scene, util) -> MachineBuildScenes.run(scene, util,
                        8, 5, 5,
                        4,
                        new int[0],
                        com.invfix.cyberware.lithograph.LithographRegistry.LITHOGRAPH_CONTROLLER.get(),
                        "lithograph_build",
                        "Lithograph - Assembly")
        );

        helper.addStoryBoard(
                precisionKey,
                "precision_machine_build",
                (scene, util) -> MachineBuildScenes.run(scene, util,
                        PrecisionMachineBlockEntity.LENGTH, 5, 5,
                        PrecisionMachineBlockEntity.LENGTH / 2,
                        new int[]{1, 3, 5},
                        MachineRegistry.PRECISION_MACHINE.get(),
                        "precision_machine_build",
                        "High-Precision Machine - Assembly")
        );

        helper.addStoryBoard(
                ultraKey,
                "ultra_precision_machine_build",
                (scene, util) -> MachineBuildScenes.run(scene, util,
                        UltraPrecisionMachineBlockEntity.LENGTH, 5, 5,
                        UltraPrecisionMachineBlockEntity.LENGTH / 2,
                        new int[]{3, 5, 7},
                        MachineRegistry.ULTRA_PRECISION_MACHINE.get(),
                        "ultra_precision_machine_build",
                        "Ultra-Precision Machine - Assembly")
        );

        // Гипербарическая печь: форма из реального чертежа (surpress.nbt),
        // 11x12x11, контроллер (2,1,5), питание (5,1,8), 3 шлюза на стене напротив.
        helper.addStoryBoard(
                hyperKey,
                "hyperbaric_furnace_build",
                (scene, util) -> IrregularMachineBuildScenes.run(scene, util,
                        11, 12, 11,
                        new BlockPos(2, 1, 5), MachineRegistry.HYPERBARIC_FURNACE.get(),
                        new BlockPos(5, 1, 8),
                        new BlockPos[]{ new BlockPos(8, 1, 3), new BlockPos(8, 1, 5), new BlockPos(8, 1, 7) },
                        "hyperbaric_furnace_build",
                        "Hyperbaric Furnace - Assembly")
        );
    }
}
