package com.invfix.integration.ponder;

import net.createmod.ponder.api.PonderPalette;
import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;
import net.createmod.ponder.api.scene.Selection;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/**
 * Сценарий «как собрать» для машин с НЕправильной формой, взятой из реального
 * Create-чертежа (химсинтезатор, гипербарическая печь) — в отличие от
 * прямоугольных коробов E2/E3 ({@link MachineBuildScenes}), тут просто
 * раскрываем всю сохранённую структуру целиком и подсвечиваем ключевые точки
 * по их АБСОЛЮТНЫМ координатам внутри схемы (см. {@code assets/sable_compat/
 * ponder/*_build.nbt}, извлечены из твоих исходных чертежей).
 */
final class IrregularMachineBuildScenes {

    private IrregularMachineBuildScenes() {}

    static void run(SceneBuilder scene, SceneBuildingUtil util,
                    int sizeX, int sizeY, int sizeZ,
                    BlockPos controllerPos, Block controllerBlock,
                    BlockPos powerPos, BlockPos[] portPositions,
                    String sceneId, String titleFallback) {

        scene.title(sceneId, titleFallback);
        // configureBasePlate НЕ вызываем — см. подробное объяснение в MachineBuildScenes:
        // явный size=0 ломал центрирование камеры (структура "улетала" за кадр). Без
        // вызова Ponder сам берёт basePlateSize = ширина структуры по X.
        scene.showBasePlate();
        scene.idle(5);

        Selection all = util.select().fromTo(0, 0, 0, sizeX - 1, sizeY - 1, sizeZ - 1);
        scene.world().showSection(all, Direction.UP);
        scene.idle(15);
        scene.overlay().showOutlineWithText(all, 60)
                .colored(PonderPalette.BLUE)
                .text("The full structure from the blueprint - casing shell with electronics packed inside");
        scene.idle(60);
        scene.addKeyframe();

        BlockState ctrlState = controllerBlock.defaultBlockState();
        if (ctrlState.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
            ctrlState = ctrlState.setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH);
        }
        scene.world().setBlock(controllerPos, ctrlState, true);
        scene.idle(5);
        scene.overlay().showOutlineWithText(util.select().position(controllerPos), 60)
                .colored(PonderPalette.GREEN)
                .text("The controller replaces the marked cell here, facing outward");
        scene.idle(60);
        scene.addKeyframe();

        scene.overlay().showOutlineWithText(util.select().position(powerPos), 60)
                .colored(PonderPalette.OUTPUT)
                .text("Power Input goes here - connect a Device Connector to it");
        scene.idle(60);
        scene.addKeyframe();

        for (int i = 0; i < portPositions.length; i++) {
            scene.overlay().showOutlineWithText(util.select().position(portPositions[i]), i == 0 ? 60 : 40)
                    .colored(PonderPalette.RED)
                    .text(i == 0
                            ? "Three Item or Fluid Ports total - any mix works, one is shown added here"
                            : "Another Port position");
            scene.idle(i == 0 ? 60 : 40);
        }

        scene.markAsFinished();
    }
}
