package com.invfix.integration.ponder;

import net.createmod.ponder.api.PonderPalette;
import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;
import net.createmod.ponder.api.scene.Selection;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/**
 * Общий сценарий «как собрать короб станка» для высокоточного (E2) и
 * сверхвысокоточного (E3) станков — отличаются только размерами и блоком-корпусом.
 *
 * <p>Оси схемы (см. {@code assets/sable_compat/ponder/*.nbt}): X — длина короба,
 * Y — высота, Z — глубина. Z=0 — стена контроллера (в самой схеме эта ячейка —
 * воздух, сцена ставит блок контроллера инструкцией, чтобы отдельно его
 * подсветить); Z=depth-1 — стена с тремя шлюзами; X=0 — короткая стена с
 * энергоприёмником.
 *
 * <p>Текст сцен регистрируется Ponder под ключи {@code <ns>.ponder.<sceneId>.text_N}
 * в порядке вызова {@code .text(...)} — см. соответствующие записи в lang-файлах
 * (порядок здесь: shell, controller, power, ports×3).
 */
final class MachineBuildScenes {

    private MachineBuildScenes() {}

    static void run(SceneBuilder scene, SceneBuildingUtil util,
                    int length, int width, int height, int controllerX, int[] portXs,
                    Block controllerBlock, String titleKey, String titleFallback) {

        int cy = height / 2;
        int lastZ = width - 1;

        scene.title(titleKey, titleFallback);
        // configureBasePlate НЕ вызываем: её 3-й параметр — это basePlateSize, который
        // напрямую входит в формулу центрирования сцены (translate(-size/2 - offset, ...)
        // в PonderScene). Явный вызов с size=0 ломал центрирование по X/Z и уводил
        // камеру/структуру за пределы кадра на высоких постройках (видно на гипербарической
        // печи). Без вызова Ponder сам берёт basePlateSize = ширина структуры по X — верно.
        scene.showBasePlate();
        scene.idle(5);

        // 1. Раскрыть весь короб обшивки + начинку электроники разом.
        Selection all = util.select().fromTo(0, 0, 0, length - 1, height - 1, width - 1);
        scene.world().showSection(all, Direction.UP);
        scene.idle(15);
        scene.overlay().showOutlineWithText(all, 60)
                .colored(PonderPalette.BLUE)
                .text("The casing is a sealed box: edges and walls are the machine's plating block");
        scene.idle(60);
        scene.addKeyframe();

        // 2. Поставить блок контроллера в отмеченную ячейку (в схеме — воздух).
        BlockPos ctrlPos = util.grid().at(controllerX, cy, 0);
        BlockState ctrlState = controllerBlock.defaultBlockState();
        if (ctrlState.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
            ctrlState = ctrlState.setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH);
        }
        scene.world().setBlock(ctrlPos, ctrlState, true);
        scene.idle(5);
        Selection ctrlSel = util.select().position(ctrlPos);
        scene.overlay().showOutlineWithText(ctrlSel, 60)
                .colored(PonderPalette.GREEN)
                .text("The controller goes in any non-edge cell of the long wall, facing outward");
        scene.idle(60);
        scene.addKeyframe();

        // 3. Подсветить энергоприёмник (короткая стена, X=0).
        Selection powerSel = util.select().position(0, cy, width / 2);
        scene.overlay().showOutlineWithText(powerSel, 60)
                .colored(PonderPalette.OUTPUT)
                .text("Power Input sits in the center of the short wall - connect a Device Connector to it");
        scene.idle(60);
        scene.addKeyframe();

        // 4. Подсветить три шлюза (стена напротив контроллера).
        for (int i = 0; i < portXs.length; i++) {
            Selection portSel = util.select().position(portXs[i], cy, lastZ);
            scene.overlay().showOutlineWithText(portSel, i == 0 ? 60 : 40)
                    .colored(PonderPalette.RED)
                    .text(i == 0
                            ? "Three Item or Fluid Ports go on the wall opposite the controller, one gap apart"
                            : "Any mix of Item and Fluid Ports works here");
            scene.idle(i == 0 ? 60 : 40);
        }

        scene.markAsFinished();
    }
}
