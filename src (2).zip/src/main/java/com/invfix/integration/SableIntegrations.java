package com.invfix.integration;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModList;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Клиентский бутстрап опциональных интеграций. JEI обнаруживает
 * {@link com.invfix.integration.jei.SableJeiPlugin} сам (аннотация
 * {@code @JeiPlugin} + сканирование модов) — регистрировать вручную не нужно.
 *
 * Ponder (эта версия — v1.0.82) НЕ сканирует моды на плагины сам: регистрация
 * только явным вызовом {@code PonderIndex.addPlugin(...)} со стороны мода.
 * Делаем это здесь на {@link FMLClientSetupEvent}, тем же событием, которым
 * сам Ponder инициализирует свои встроенные плагины — порядок между разными
 * модами на этом событии не важен, т.к. фактическая сборка сцен (reload)
 * происходит позже, на отдельном ресурс-релоаде.
 */
public final class SableIntegrations {

    private SableIntegrations() {}

    public static void initClient(IEventBus modEventBus) {
        modEventBus.addListener(SableIntegrations::onClientSetup);
    }

    private static void onClientSetup(FMLClientSetupEvent event) {
        if (ModList.get().isLoaded("ponder")) {
            registerPonder();
        }
    }

    // Вынесено в отдельный метод: класс с прямой ссылкой на net.createmod.ponder.*
    // не должен даже загружаться классом, если Ponder не установлен.
    private static void registerPonder() {
        net.createmod.ponder.foundation.PonderIndex.addPlugin(
                new com.invfix.integration.ponder.SablePonderPlugin());
    }
}
