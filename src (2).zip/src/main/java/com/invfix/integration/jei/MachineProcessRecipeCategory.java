package com.invfix.integration.jei;

import com.invfix.cyberware.machines.crafter.MachineProcessRecipe;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.AbstractRecipeCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.material.Fluid;

/**
 * Категория JEI для гипербарической печи
 * и гипербарической печи ({@code sable_compat:hyperbaric}): сетка 3×3 + опциональный
 * слот жидкости (только если рецепт её требует) + выход. Одна и та же категория
 * переиспользуется для обоих типов рецептов — отличаются только заголовком,
 * иконкой и катализатором (см. {@link SableJeiPlugin}).
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public class MachineProcessRecipeCategory extends AbstractRecipeCategory {

    private static final int GRID = 3;
    private static final int SLOT = 18;
    private static final int GRID_PX = GRID * SLOT;
    private static final int FLUID_Y = GRID_PX + 6;

    private final RecipeType type;
    private final IDrawable slotDrawable;
    private final IDrawable arrow;

    /**
     * @param jeiId "hyperbaric" — используется только как ключ JEI-категории
     *              (JEI-шный {@code RecipeType} — свой отдельный класс, не связан с нашим
     *              {@code net.minecraft.world.item.crafting.RecipeType}; сопоставление рецептов
     *              с реальным ванильным типом происходит в {@link SableJeiPlugin} напрямую
     *              через {@code RecipeManager}).
     */
    public MachineProcessRecipeCategory(IGuiHelper gui, String jeiId, Component title, IDrawable icon) {
        super(RecipeType.create("sable_compat", jeiId, MachineProcessRecipe.class),
                title, icon, GRID_PX + 20 + SLOT, GRID_PX + SLOT + 8);
        this.type = getRecipeType();
        this.slotDrawable = gui.getSlotDrawable();
        this.arrow = gui.getRecipeArrow();
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, Object recipeObj, IFocusGroup focuses) {
        MachineProcessRecipe recipe = (MachineProcessRecipe) recipeObj;
        int w = recipe.getWidth();
        int h = recipe.getHeight();
        int offX = (GRID - w) / 2;
        int offY = (GRID - h) / 2;

        var ingredients = recipe.getIngredients();
        for (int row = 0; row < h; row++) {
            for (int col = 0; col < w; col++) {
                Ingredient ing = (Ingredient) ingredients.get(row * w + col);
                int x = (offX + col) * SLOT;
                int y = (offY + row) * SLOT;
                builder.addSlot(RecipeIngredientRole.INPUT, x + 1, y + 1).addIngredients(ing);
            }
        }

        if (recipe.fluidId().isPresent() && recipe.fluidAmount() > 0) {
            Fluid fluid = BuiltInRegistries.FLUID.get(recipe.fluidId().get());
            builder.addSlot(RecipeIngredientRole.INPUT, 1, FLUID_Y + 1)
                    .addFluidStack(fluid, recipe.fluidAmount());
        }

        var access = Minecraft.getInstance().level != null ? Minecraft.getInstance().level.registryAccess() : null;
        ItemStack result = recipe.getResultItem(access);
        builder.addSlot(RecipeIngredientRole.OUTPUT, GRID_PX + 20 + 1, (GRID_PX - SLOT) / 2 + 1)
                .addItemStack(result);
    }

    @Override
    public void draw(Object recipeObj, IRecipeSlotsView recipeSlotsView, GuiGraphics guiGraphics,
                     double mouseX, double mouseY) {
        MachineProcessRecipe recipe = (MachineProcessRecipe) recipeObj;
        for (int row = 0; row < GRID; row++) {
            for (int col = 0; col < GRID; col++) {
                slotDrawable.draw(guiGraphics, col * SLOT, row * SLOT);
            }
        }
        if (recipe.fluidId().isPresent() && recipe.fluidAmount() > 0) {
            slotDrawable.draw(guiGraphics, 0, FLUID_Y);
        }
        arrow.draw(guiGraphics, GRID_PX + 1, (GRID_PX - arrow.getHeight()) / 2);
    }
}
