package com.invfix.integration.jei;

import com.invfix.cyberware.lithograph.LithographControllerBlockEntity;
import com.invfix.cyberware.lithograph.LithographRegistry;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.AbstractRecipeCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/**
 * Литограф крафтит {@code exposed_wafer} НЕ по датапак-рецепту — превращение
 * {@code coated_wafer -> exposed_wafer} зашито прямо в
 * {@link LithographControllerBlockEntity#resultFor(ItemStack)}, поэтому обычный
 * механизм JEI (сбор рецептов из {@code RecipeManager}) его не видит. Категория
 * показывает эту единственную зашитую пару вход/выход статически — без
 * настоящего {@code Recipe}-объекта, просто как готовую пару предметов.
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public class LithographRecipeCategory extends AbstractRecipeCategory {

    /** Заглушка вместо настоящего Recipe — категории JEI достаточно пары предметов. */
    public record Entry(ItemStack input, ItemStack output) {}

    public static final RecipeType TYPE =
            RecipeType.create("sable_compat", "lithograph", Entry.class);

    private static final int SLOT = 18;

    private final IDrawable slotDrawable;
    private final IDrawable arrow;

    public LithographRecipeCategory(IGuiHelper gui) {
        super(TYPE, Component.translatable("jei.sable_compat.category.lithograph"),
                gui.createDrawableItemStack(LithographRegistry.LITHOGRAPH_CONTROLLER_ITEM.get().getDefaultInstance()),
                SLOT + 24 + SLOT, SLOT + 14);
        this.slotDrawable = gui.getSlotDrawable();
        this.arrow = gui.getRecipeArrow();
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, Object recipeObj, IFocusGroup focuses) {
        Entry entry = (Entry) recipeObj;
        builder.addSlot(RecipeIngredientRole.INPUT, 1, 1).addItemStack(entry.input());
        builder.addSlot(RecipeIngredientRole.OUTPUT, SLOT + 24 + 1, 1).addItemStack(entry.output());
    }

    @Override
    public void draw(Object recipeObj, IRecipeSlotsView recipeSlotsView, GuiGraphics guiGraphics,
                     double mouseX, double mouseY) {
        slotDrawable.draw(guiGraphics, 0, 0);
        slotDrawable.draw(guiGraphics, SLOT + 24, 0);
        arrow.draw(guiGraphics, SLOT + 3, 0);

        String caption = (LithographControllerBlockEntity.MAX_PROGRESS / 20) + "s, "
                + LithographControllerBlockEntity.CONSUME_PER_TICK + " FE/t";
        guiGraphics.drawString(Minecraft.getInstance().font, caption, 0, SLOT + 2, 0x808080, false);
    }
}
