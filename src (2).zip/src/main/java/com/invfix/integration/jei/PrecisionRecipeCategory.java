package com.invfix.integration.jei;

import com.invfix.cyberware.machines.MachineRegistry;
import com.invfix.cyberware.machines.crafter.PrecisionRecipe;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.AbstractRecipeCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.crafting.Ingredient;

/**
 * Категория JEI для {@code sable_compat:precision} — рецептов, крафтящихся на
 * высокоточном (E2, tier 1) и сверхвысокоточном (E3, tier 2) станках. Сетка
 * фиксирована 5×5 (максимальный шаблон станка); рецепты меньшего размера
 * (1×1, 3×3 и т.п.) центрируются в ней — как JEI центрирует обычные шейпед-рецепты
 * верстака в своей 3×3 категории.
 *
 * <p>Эта версия JEI API (декомпил) не сохранила generics у {@code IRecipeCategory} —
 * класс написан как raw-тип, чтобы совпасть с фактическими сигнатурами байткода вне
 * зависимости от того, восстановлены они в реальной среде или нет.
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public class PrecisionRecipeCategory extends AbstractRecipeCategory {

    public static final RecipeType TYPE =
            RecipeType.create("sable_compat", "precision", PrecisionRecipe.class);

    private static final int GRID = 5;
    private static final int SLOT = 18;
    private static final int GRID_PX = GRID * SLOT;

    private final IDrawable slotDrawable;
    private final IDrawable arrow;

    public PrecisionRecipeCategory(IGuiHelper gui) {
        super(TYPE,
                Component.translatable("jei.sable_compat.category.precision"),
                gui.createDrawableItemStack(MachineRegistry.PRECISION_MACHINE_ITEM.get().getDefaultInstance()),
                GRID_PX + 20 + SLOT, GRID_PX + 12);
        this.slotDrawable = gui.getSlotDrawable();
        this.arrow = gui.getRecipeArrow();
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, Object recipeObj, IFocusGroup focuses) {
        PrecisionRecipe recipe = (PrecisionRecipe) recipeObj;
        int w = recipe.getWidth();
        int h = recipe.getHeight();
        int offX = (GRID - w) / 2;
        int offY = (GRID - h) / 2;

        var ingredients = recipe.getIngredients();
        for (int row = 0; row < h; row++) {
            for (int col = 0; col < w; col++) {
                Ingredient ing = (Ingredient) ingredients.get(row * w + col);
                int x = (offX + col) * SLOT;
                int y = (offY + row) * SLOT;
                builder.addSlot(RecipeIngredientRole.INPUT, x + 1, y + 1).addIngredients(ing);
            }
        }

        var access = Minecraft.getInstance().level != null ? Minecraft.getInstance().level.registryAccess() : null;
        builder.addSlot(RecipeIngredientRole.OUTPUT, GRID_PX + 20 + 1, (GRID_PX - SLOT) / 2 + 1)
                .addItemStack(recipe.getResultItem(access));
    }

    @Override
    public void draw(Object recipeObj, IRecipeSlotsView recipeSlotsView, GuiGraphics guiGraphics,
                     double mouseX, double mouseY) {
        PrecisionRecipe recipe = (PrecisionRecipe) recipeObj;
        for (int row = 0; row < GRID; row++) {
            for (int col = 0; col < GRID; col++) {
                slotDrawable.draw(guiGraphics, col * SLOT, row * SLOT);
            }
        }
        arrow.draw(guiGraphics, GRID_PX + 1, (GRID_PX - arrow.getHeight()) / 2);

        String tierLabel = "Tier " + recipe.tier();
        guiGraphics.drawString(Minecraft.getInstance().font, tierLabel, 0, GRID_PX + 1, 0xFFAA00, false);
    }
}
