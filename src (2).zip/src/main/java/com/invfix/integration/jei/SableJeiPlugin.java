package com.invfix.integration.jei;

import com.invfix.cyberware.CompositeItems;
import com.invfix.cyberware.machines.MachineRegistry;
import com.invfix.cyberware.machines.SableRecipes;
import com.invfix.cyberware.machines.crafter.MachineProcessRecipe;
import com.invfix.cyberware.machines.crafter.PrecisionRecipe;
import com.invfix.cyberware.lithograph.LithographRegistry;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.RecipeHolder;

import java.util.ArrayList;
import java.util.List;

/**
 * Плагин JEI. Категории рецептов машин:
 *  - {@code sable_compat:precision} — высокоточный (E2) и сверхвысокоточный (E3)
 *    станки, сетка 5×5 (тир виден бейджем);
 *  - {@code sable_compat:hyperbaric} — гипербарическая печь, сетка 3×3 + жидкость;
 *  - {@code sable_compat:lithograph} — единственное зашитое превращение литографа
 *    (coated_wafer -> exposed_wafer), у него нет датапак-рецепта вообще.
 *
 * Ванильные/мех.сборочные рецепты, которые станки ТАКЖЕ умеют крафтить (см.
 * {@code ProgrammableMachineBlockEntity.resolveRecipe}), уже показаны JEI как
 * обычный верстак/Create-мех.сборка — здесь не дублируются.
 */
@JeiPlugin
public class SableJeiPlugin implements IModPlugin {

    private static final ResourceLocation UID =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "jei_plugin");

    private MachineProcessRecipeCategory hyperbaricCategory;
    private LithographRecipeCategory lithographCategory;

    @Override
    public ResourceLocation getPluginUid() { return UID; }

    @Override
    public void registerCategories(IRecipeCategoryRegistration registration) {
        var gui = registration.getJeiHelpers().getGuiHelper();

        hyperbaricCategory = new MachineProcessRecipeCategory(gui, "hyperbaric",
                Component.translatable("jei.sable_compat.category.hyperbaric"),
                gui.createDrawableItemStack(MachineRegistry.HYPERBARIC_FURNACE_ITEM.get().getDefaultInstance()));

        lithographCategory = new LithographRecipeCategory(gui);

        registration.addRecipeCategories(
                new PrecisionRecipeCategory(gui),
                hyperbaricCategory,
                lithographCategory);
    }

    @Override
    public void registerRecipes(IRecipeRegistration registration) {
        var level = Minecraft.getInstance().level;

        List<PrecisionRecipe> precisionRecipes = new ArrayList<>();
        List<MachineProcessRecipe> hyperbaricRecipes = new ArrayList<>();

        if (level != null) {
            for (RecipeHolder<PrecisionRecipe> holder : level.getRecipeManager().getAllRecipesFor(SableRecipes.PRECISION_TYPE.get())) {
                precisionRecipes.add(holder.value());
            }
            for (RecipeHolder<MachineProcessRecipe> holder : level.getRecipeManager().getAllRecipesFor(SableRecipes.HYPERBARIC_TYPE.get())) {
                hyperbaricRecipes.add(holder.value());
            }
        }

        registration.addRecipes(PrecisionRecipeCategory.TYPE, precisionRecipes);
        registration.addRecipes(hyperbaricCategory.getRecipeType(), hyperbaricRecipes);

        // Литограф: нет датапак-рецепта, отдаём единственную зашитую пару вручную.
        registration.addRecipes(lithographCategory.getRecipeType(), List.of(
                new LithographRecipeCategory.Entry(
                        CompositeItems.COATED_WAFER.get().getDefaultInstance(),
                        CompositeItems.EXPOSED_WAFER.get().getDefaultInstance())
        ));
    }

    @Override
    public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
        registration.addRecipeCatalysts(PrecisionRecipeCategory.TYPE,
                MachineRegistry.PRECISION_MACHINE_ITEM.get(),
                MachineRegistry.ULTRA_PRECISION_MACHINE_ITEM.get());
        registration.addRecipeCatalysts(hyperbaricCategory.getRecipeType(),
                MachineRegistry.HYPERBARIC_FURNACE_ITEM.get());
        registration.addRecipeCatalysts(lithographCategory.getRecipeType(),
                LithographRegistry.LITHOGRAPH_CONTROLLER_ITEM.get());
    }
}
