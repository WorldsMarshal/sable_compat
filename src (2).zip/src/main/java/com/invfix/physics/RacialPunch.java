package com.invfix.physics;

import dev.ryanhcode.sable.api.sublevel.ServerSubLevelContainer;
import dev.ryanhcode.sable.api.sublevel.SubLevelContainer;
import dev.ryanhcode.sable.api.physics.PhysicsPipeline;
import dev.ryanhcode.sable.api.physics.handle.RigidBodyHandle;
import dev.ryanhcode.sable.api.physics.mass.MassData;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.server.level.ServerLevel;
import org.joml.Vector3d;
import org.joml.Vector3dc;

/**
 * Расовый «толчок» физических построек (sable sub-level'ов).
 *
 * Любая НЕ-людская раса в боевом режиме при клике по физической постройке
 * сообщает ей скорость, пропорциональную силе существа. Импульс считается
 * через обобщённую обратную массу самого sable — поэтому «сила» автоматически
 * масштабируется массой постройки (тяжёлой нужно больше импульса на ту же
 * скорость), а «скорость» жёстко ограничена потолком.
 *
 *   targetDelta = min(currentStr * STRENGTH_TO_SPEED, MAX_SPEED) * sideMult
 *   impulse     = targetDelta / inverseNormalMass        (=> Δv вдоль удара == targetDelta)
 *
 *   ЛКМ (обычный удар)  -> sideMult = LMB_MULT   (половина)
 *   Heavy Punch (ПКМ)   -> sideMult = HEAVY_MULT (полная)
 */
public final class RacialPunch {

    private RacialPunch() {}

    /** м/с на единицу currentStr. Линейный скейл до потолка. */
    public static final double STRENGTH_TO_SPEED = 1.0;
    /** Жёсткий потолок: максимум, который существо может сообщить постройке. */
    public static final double MAX_SPEED = 600.0;

    /** Множитель удара левой кнопкой (обычный) — половина силы. */
    public static final double LMB_MULT   = 0.5;
    /** Множитель Heavy Punch (ПКМ в Combat) — полная сила. */
    public static final double HEAVY_MULT = 1.0;

    /** Раса людская, если после снятия §-кодов имя начинается с "Human". */
    public static boolean isHuman(String race) {
        if (race == null) return true;
        StringBuilder sb = new StringBuilder(race.length());
        for (int i = 0; i < race.length(); i++) {
            char c = race.charAt(i);
            if (c == '\u00a7' && i + 1 < race.length()) {
                i++;                       // пропускаем §-код целиком
            } else {
                sb.append(c);
            }
        }
        return sb.toString().startsWith("Human");
    }

    /** true, если эта раса в этом состоянии должна получать расовый толчок. */
    public static boolean qualifies(InvincibleIncModVariables.PlayerVariables vars) {
        return vars != null && vars.battleMode && !isHuman(vars.Race);
    }

    /** Целевая Δv для удара (с учётом стороны и потолка). */
    public static double targetDelta(InvincibleIncModVariables.PlayerVariables vars, double sideMult) {
        double str = Math.max(0.0, vars.currentStr);
        double capped = Math.min(str * STRENGTH_TO_SPEED, MAX_SPEED);
        return capped * sideMult;
    }

    /**
     * Прикладывает расовый импульс к постройке в её ЛОКАЛЬНОЙ системе координат.
     *
     * @param target      sable sub-level, по которому бьём
     * @param localPos    точка удара в локальных координатах постройки
     * @param localDir    направление удара в локальных координатах (не обязан быть нормализован)
     * @param targetDelta желаемая Δv вдоль удара (уже с потолком и множителем стороны)
     */
    public static void applyLocal(ServerSubLevel target,
                                  Vector3dc localPos,
                                  Vector3dc localDir,
                                  double targetDelta) {
        if (target == null || targetDelta <= 0.0) return;

        ServerLevel level = target.getLevel();
        if (level == null) return;

        ServerSubLevelContainer container = SubLevelContainer.getContainer(level);
        if (container == null) return;
        PhysicsPipeline pipeline = container.physicsSystem().getPipeline();

        Vector3d dir = new Vector3d(localDir);
        double len = dir.length();
        if (len < 1.0e-9) return;
        dir.div(len);                              // нормализуем

        MassData mass = target.getMassTracker();
        double invMass = mass.getInverseNormalMass(localPos, dir);
        if (invMass <= 1.0e-12) return;            // закреплённая/бесконечно тяжёлая — не двигаем

        double impulseMag = targetDelta / invMass; // Δv = impulse * invMass = targetDelta
        pipeline.applyImpulse(target, localPos, dir.mul(impulseMag));
    }

    /**
     * Толкает постройку прямой выставкой линейной скорости через Rapier
     * (addLinearAndAngularVelocity) в МИРОВЫХ координатах: прибавляет delta
     * вдоль (dx,dy,dz), ограничивая итоговую |v| потолком MAX_SPEED.
     *
     * Не зависит от масс-математики и направления исходного импульса.
     *
     * @return true, если толчок реально применён; false — если handle недоступен
     *         (тогда вызывающий код может откатиться на applyLocal).
     */
    public static boolean pushWorld(ServerSubLevel target, double dx, double dy, double dz, double targetDelta) {
        if (target == null || targetDelta <= 0.0) return false;

        Vector3d dir = new Vector3d(dx, dy, dz);
        double len = dir.length();
        if (len < 1.0e-9) return false;
        dir.div(len);

        RigidBodyHandle handle = RigidBodyHandle.of(target);
        if (handle == null || !handle.isValid()) return false;

        Vector3d v = handle.getLinearVelocity(new Vector3d());   // текущая скорость (мир)
        Vector3d newV = new Vector3d(v).fma(targetDelta, dir);   // v + dir*delta
        double sp = newV.length();
        if (sp > MAX_SPEED) newV.mul(MAX_SPEED / sp);            // кап итоговой скорости

        Vector3d dv = newV.sub(v, new Vector3d());
        handle.addLinearAndAngularVelocity(dv, new Vector3d());  // мгновенно, с wake-up
        return true;
    }
}