package com.invfix;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.FinalizeSpawnEvent;

/**
 * Полностью отключает появление любых мобов/NPC из мода Invincible Inc.
 *
 * FinalizeSpawnEvent — общая точка для ВСЕХ путей спавна Mob-сущностей:
 * естественный спавн через biome_modifier, кастомный NPCspawningProcedure
 * (EntityType.spawn с MOB_SUMMONED) и спавн-яйца. Любой моб, чей тип
 * принадлежит namespace "invincible_inc", отменяется до попадания в мир.
 *
 * Снаряды способностей (atomic_blast, sonic_clap_arrow, red_rush_trail и т.п.)
 * НЕ являются Mob и через это событие не проходят — они продолжают работать.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class NpcSpawnDisableHandler {

    private static final String SOURCE_MOD = "invincible_inc";

    private NpcSpawnDisableHandler() {}

    @SubscribeEvent
    public static void onFinalizeSpawn(FinalizeSpawnEvent event) {
        EntityType<?> type = event.getEntity().getType();
        ResourceLocation id = BuiltInRegistries.ENTITY_TYPE.getKey(type);
        if (id != null && SOURCE_MOD.equals(id.getNamespace())) {
            event.setSpawnCancelled(true);
        }
    }
}