package com.invfix.coldsweat;

import com.invfix.humanlike.HumanLikeRaces;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

import java.util.Set;

/**
 * Совместимость с Cold Sweat: температурный резист по расе/уровню и по системе V (The Boys).
 *
 * Резист задаётся через атрибуты Cold Sweat (heat/cold resistance + heat/cold dampening),
 * БЕЗ эффектов — UI не засоряется иконками. Cold Sweat читает эти атрибуты каждый тик,
 * поэтому достаточно держать на игроке актуальный модификатор.
 *
 * Логика фактора резиста [0..1] (0 = ваниль, 1 = полный иммунитет):
 *
 *  • Раса (кроме чистых Human): растёт с уровнем. Lvl 1 → 0, Lvl 10+ → 1.0
 *    (на 10 уровне те же расы получают полный огненный иммунитет — здесь же полный темп-резист).
 *  • Чистые Human / Human(Predisposition to V) / Human(Born for V): расового резиста нет.
 *  • Temp V активен → 1.0, пока действует.
 *  • Compound V: Born for V → 1.0, любой другой игрок с V → 0.6.
 *
 * Итоговый фактор = максимум из расового и V-резиста (сильнейший перекрывает, без переполнения >1).
 *
 * Cold Sweat и The Boys лежат в compileOnly, поэтому прямые ссылки на их классы
 * изолированы в {@link ColdSweatTempResist} и {@link TheBoysVResist} и трогаются
 * только когда соответствующий мод загружен.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class ColdSweatTempCompat {

    private static Boolean coldSweatLoaded;
    private static Boolean theBoysLoaded;

    /** Чистые Human-расы — расовый темп-резист на них НЕ распространяется. */
    private static final Set<String> PURE_HUMAN = Set.of(
            "\u00a7f\u00a7lHuman",
            "\u00a7lHuman",
            "Human",
            HumanLikeRaces.BORN_FOR_V,
            HumanLikeRaces.PREDISPOSITION);

    private static final double FULL_RESIST_LEVEL = 10.0;

    /** Пересчёт раз в секунду (20 тиков) — задержки реакции на левел-ап/V незаметны. */
    private static final int UPDATE_INTERVAL = 20;

    private ColdSweatTempCompat() {}

    private static boolean coldSweat() {
        if (coldSweatLoaded == null) coldSweatLoaded = ModList.get().isLoaded("cold_sweat");
        return coldSweatLoaded;
    }

    private static boolean theBoys() {
        if (theBoysLoaded == null) theBoysLoaded = ModList.get().isLoaded("theboysmod");
        return theBoysLoaded;
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!coldSweat()) return;
        if (!(event.getEntity() instanceof ServerPlayer player)) return;

        // Фактор резиста меняется редко (левел-ап, смена расы, вкл/выкл V), а температура
        // в Cold Sweat ползёт медленно и урон тикает с большим интервалом — поэтому
        // пересчитываем раз в секунду, а не каждый тик. Смещение по id размазывает
        // нагрузку, чтобы игроки не пересчитывались все в один тик.
        if ((player.tickCount + player.getId()) % UPDATE_INTERVAL != 0) return;

        ColdSweatTempResist.apply(player, computeFactor(player));
    }

    private static double computeFactor(Player player) {
        String race = null;
        double level = 0.0;
        try {
            InvincibleIncModVariables.PlayerVariables v =
                    player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            race = v.Race;
            level = v.Lvl;
        } catch (Exception ignored) {}

        double factor = raceResist(race, level);
        if (theBoys()) {
            factor = Math.max(factor, TheBoysVResist.compute(player, race));
        }

        if (factor < 0.0) return 0.0;
        return Math.min(factor, 1.0);
    }

    /** Резист от уровня: Lvl ≤1 → 0, Lvl ≥10 → 1.0, между — линейно. Чистые Human → всегда 0. */
    private static double raceResist(String race, double level) {
        if (race == null || PURE_HUMAN.contains(race)) return 0.0;
        if (level <= 1.0) return 0.0;
        if (level >= FULL_RESIST_LEVEL) return 1.0;
        return (level - 1.0) / (FULL_RESIST_LEVEL - 1.0);
    }
}
