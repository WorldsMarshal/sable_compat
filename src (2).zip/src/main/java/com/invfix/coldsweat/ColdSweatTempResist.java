package com.invfix.coldsweat;

import com.momosoftworks.coldsweat.core.init.ModAttributes;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.player.Player;

/**
 * Применение температурного резиста через атрибуты Cold Sweat. Класс трогается
 * только когда cold_sweat загружен (см. {@link ColdSweatTempCompat}).
 *
 * Фактор [0..1] кладётся одинаково на четыре атрибута:
 *   • heat/cold resistance — режут урон от жары/холода (1.0 = урона нет, 0.6 = −60%);
 *   • heat/cold dampening  — замедляют сдвиг температуры тела (1.0 = тело не нагревается/
 *     не остывает вовсе, 0.6 = свинг на 60% медленнее).
 *
 * Cold Sweat читает базу атрибута вручную (NaN-база трактуется как 0), поэтому
 * ADD_VALUE-модификатор задаёт ровно нужное значение. Держим один транзиентный
 * модификатор на атрибут и обновляем только при изменении фактора.
 */
final class ColdSweatTempResist {

    private ColdSweatTempResist() {}

    private static final ResourceLocation HEAT_RES_ID =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "temp_heat_resist");
    private static final ResourceLocation COLD_RES_ID =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "temp_cold_resist");
    private static final ResourceLocation HEAT_DMP_ID =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "temp_heat_dampen");
    private static final ResourceLocation COLD_DMP_ID =
            ResourceLocation.fromNamespaceAndPath("sable_compat", "temp_cold_dampen");

    static void apply(Player player, double factor) {
        set(player, holder(ModAttributes.HEAT_RESISTANCE), HEAT_RES_ID, factor);
        set(player, holder(ModAttributes.COLD_RESISTANCE), COLD_RES_ID, factor);
        set(player, holder(ModAttributes.HEAT_DAMPENING),  HEAT_DMP_ID, factor);
        set(player, holder(ModAttributes.COLD_DAMPENING),  COLD_DMP_ID, factor);
    }

    @SuppressWarnings("unchecked")
    private static Holder<Attribute> holder(Object deferred) {
        return (Holder<Attribute>) deferred; // DeferredHolder<Attribute,…> реализует Holder<Attribute>
    }

    private static void set(Player player, Holder<Attribute> attr, ResourceLocation id, double amount) {
        AttributeInstance inst = player.getAttribute(attr);
        if (inst == null) return;

        AttributeModifier existing = inst.getModifier(id);
        if (amount <= 0.0) {
            if (existing != null) inst.removeModifier(id);
            return;
        }
        if (existing != null) {
            if (Math.abs(existing.amount() - amount) < 1.0e-4) return; // не изменилось
            inst.removeModifier(id);
        }
        inst.addTransientModifier(new AttributeModifier(id, amount, Operation.ADD_VALUE));
    }
}
