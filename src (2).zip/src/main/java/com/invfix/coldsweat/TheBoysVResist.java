package com.invfix.coldsweat;

import com.invfix.humanlike.HumanLikeRaces;
import net.benniao.theboysmod.skill.ModSkillAttachments;
import net.benniao.theboysmod.skill.SkillData;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.attachment.AttachmentType;

/**
 * Резист температуры по системе V мода The Boys. Класс трогается только когда
 * theboysmod загружен (см. {@link ColdSweatTempCompat}).
 *
 *  • Temp V активен (есть временные скиллы) → 1.0, пока действует.
 *  • Compound V (есть перманентный скилл): Born for V → 1.0, иначе → 0.6.
 *  • Нет V → 0.
 */
final class TheBoysVResist {

    private TheBoysVResist() {}

    @SuppressWarnings({"unchecked", "rawtypes"})
    static double compute(Player player, String race) {
        try {
            SkillData data = (SkillData) player.getData((AttachmentType) ModSkillAttachments.SKILL_DATA.get());
            if (data == null) return 0.0;

            // Temp V — временные способности с таймером.
            if (data.hasTemporarySkills()) return 1.0;

            // Compound V — перманентная способность (скилл вне временного набора).
            if (hasPermanentSkill(data)) {
                return HumanLikeRaces.BORN_FOR_V.equals(race) ? 1.0 : 0.6;
            }
        } catch (Exception ignored) {}
        return 0.0;
    }

    private static boolean hasPermanentSkill(SkillData data) {
        for (Object id : data.getAllSkills()) {
            if (!data.getTemporarySkills().contains(id)) return true;
        }
        return false;
    }
}
