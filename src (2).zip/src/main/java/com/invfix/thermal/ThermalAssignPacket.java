package com.invfix.thermal;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Клиент → Сервер: выбрать Thermal Sense как текущую способность (для назначения в слот). */
public record ThermalAssignPacket(int x, int y, int z) implements CustomPacketPayload {

    public static final Type<ThermalAssignPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "thermal_sense_assign"));

    public static final StreamCodec<FriendlyByteBuf, ThermalAssignPacket> STREAM_CODEC = StreamCodec.of(
            (buf, m) -> { buf.writeInt(m.x()); buf.writeInt(m.y()); buf.writeInt(m.z()); },
            buf -> new ThermalAssignPacket(buf.readInt(), buf.readInt(), buf.readInt()));

    @Override public Type<ThermalAssignPacket> type() { return TYPE; }

    public static void handleServer(ThermalAssignPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer player) || !ThermalHandler.eligible(player)) return;
            try {
                InvincibleIncModVariables.PlayerVariables vars =
                        player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                vars.AbilitySet = ThermalHandler.ABILITY;
                vars.abilityDescription = ThermalHandler.ABILITY + " | LVL:" + ThermalHandler.LVL_REQUIRED
                        + " | Режим восприятия (тумблер)";
                vars.markSyncDirty();
            } catch (Exception ignored) {}
        });
    }
}
