package com.invfix.thermal;

import com.invfix.altrumite.AltrumiteRace;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Thermal Sense — режим восприятия Metroman (Alien(Metroman)), LVL {@link #LVL_REQUIRED}.
 *
 * Тумблер: нажатие клавиши способности включает, следующее — выключает. Не
 * атака: сервер только помнит, у кого режим включён, и говорит об этом самому
 * игроку — всё остальное (холодный серо-синий мир, тепловые силуэты всего
 * живого сквозь стены, пылающие лава и огонь) рисуется у него на клиенте
 * (ThermalClient / ThermalFx). Другие игроки ничего не видят.
 *
 * Смерть и выход выключают режим.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class ThermalHandler {

    public static final String ABILITY = "§6§lThermal Sense";
    public static final int LVL_REQUIRED = 60;

    private static final Set<UUID> ACTIVE = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Boolean> KEY_DOWN = new ConcurrentHashMap<>();

    private ThermalHandler() {}

    public static boolean eligible(ServerPlayer player) {
        try {
            InvincibleIncModVariables.PlayerVariables v = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            return AltrumiteRace.isAltrumite(v.Race) && v.Lvl >= LVL_REQUIRED;
        } catch (Exception e) {
            return false;
        }
    }

    /** Клавиша (AbilityCallProcedureMixin, каждый тик): переключение по фронту нажатия. */
    public static void handleKeyState(ServerPlayer player, boolean pressed) {
        boolean was = Boolean.TRUE.equals(KEY_DOWN.put(player.getUUID(), pressed));
        if (!pressed || was) return;
        if (ACTIVE.contains(player.getUUID())) {
            set(player, false);
        } else if (eligible(player)) {
            set(player, true);
        }
    }

    private static void set(ServerPlayer player, boolean on) {
        if (on) ACTIVE.add(player.getUUID());
        else ACTIVE.remove(player.getUUID());
        PacketDistributor.sendToPlayer(player, new ThermalPacket(on));
    }

    private static void off(Player player) {
        KEY_DOWN.remove(player.getUUID());
        if (ACTIVE.remove(player.getUUID()) && player instanceof ServerPlayer sp && sp.connection != null) {
            PacketDistributor.sendToPlayer(sp, new ThermalPacket(false));
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof Player p && !p.level().isClientSide()) off(p);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        KEY_DOWN.remove(event.getEntity().getUUID());
        ACTIVE.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        off(event.getEntity());
    }
}
