package com.invfix.thermal.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.List;

/**
 * Раскалённые блоки вокруг камеры для Thermal Sense: лава (и текущая), огонь,
 * магма, горящие костры и печи, факелы и фонари. Ищутся по секциям чанков в
 * {@link #RADIUS} блоках — сначала дешёвая проверка палитры секции
 * (maybeHas), потом перебор только тех секций, где такое есть; понемногу за
 * тик, полный круг — около секунды. Из каждого блока берутся только грани,
 * открытые наружу (не к такому же горячему соседу), — у озера лавы рисуется
 * поверхность, а не толща.
 *
 * Список читает ThermalMask: блоки ложатся в маску силуэтов с пометкой «блок»
 * (B = 1), а шейдер показывает их только там, где они видны глазом, — сквозь
 * стены светится лишь живое.
 */
@OnlyIn(Dist.CLIENT)
final class ThermalHeatBlocks {

    /** Радиус поиска, блоков. */
    static final int RADIUS = 48;
    /** Больше граней не рисуется (ближние важнее). */
    private static final int MAX_BOXES = 6000;
    /** Сколько секций проверять за тик. */
    private static final int SECTIONS_PER_TICK = 160;

    /** Горячий блок: коробка в мире, накал 0..1 и какие грани открыты (биты по Direction.get3DDataValue). */
    record Box(AABB box, float heat, int faces) {}

    private static List<Box> ready = List.of();
    private static final List<Box> building = new ArrayList<>();
    private static ClientLevel scanLevel;
    private static int cx0, cz0, sectionMin, sectionCount;
    private static int cursor = -1;
    private static int total;

    private ThermalHeatBlocks() {}

    static List<Box> boxes() {
        return ready;
    }

    static void reset() {
        ready = List.of();
        building.clear();
        scanLevel = null;
        cursor = -1;
    }

    /** Накал горячего блока, 0 — не горячий. */
    static float heat(BlockState s) {
        if (s.getFluidState().is(FluidTags.LAVA)) return 1.0F;
        if (s.is(Blocks.FIRE) || s.is(Blocks.SOUL_FIRE)) return 1.0F;
        if (s.is(Blocks.LAVA_CAULDRON)) return 1.0F;
        if (s.is(Blocks.MAGMA_BLOCK)) return 0.84F;
        if (s.getBlock() instanceof CampfireBlock) {
            return s.hasProperty(BlockStateProperties.LIT) && s.getValue(BlockStateProperties.LIT) ? 0.95F : 0.0F;
        }
        if (s.getBlock() instanceof AbstractFurnaceBlock) {
            return s.hasProperty(BlockStateProperties.LIT) && s.getValue(BlockStateProperties.LIT) ? 0.72F : 0.0F;
        }
        if (s.is(Blocks.TORCH) || s.is(Blocks.WALL_TORCH) || s.is(Blocks.SOUL_TORCH) || s.is(Blocks.SOUL_WALL_TORCH)) {
            return 0.82F;
        }
        if (s.is(Blocks.LANTERN) || s.is(Blocks.SOUL_LANTERN)) return 0.76F;
        return 0.0F;
    }

    /** Понемногу за тик (ThermalClient), пока режим виден. */
    static void tick(Minecraft mc) {
        ClientLevel level = mc.level;
        if (level == null || mc.player == null) {
            reset();
            return;
        }
        if (level != scanLevel) {
            reset();
            scanLevel = level;
        }
        if (cursor < 0) {
            Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
            cx0 = (int) Math.floor(cam.x) >> 4;
            cz0 = (int) Math.floor(cam.z) >> 4;
            sectionMin = level.getMinSection();
            sectionCount = level.getSectionsCount();
            building.clear();
            cursor = 0;
        }
        int r = (RADIUS >> 4) + 1;
        int side = r * 2 + 1;
        total = side * side * sectionCount;
        int done = 0;
        while (cursor < total && done < SECTIONS_PER_TICK) {
            int i = cursor++;
            done++;
            int sy = i % sectionCount;
            int col = i / sectionCount;
            int cx = cx0 - r + col % side;
            int cz = cz0 - r + col / side;
            LevelChunk chunk = level.getChunkSource().getChunk(cx, cz, false);
            if (chunk == null) continue;
            LevelChunkSection[] sections = chunk.getSections();
            if (sy >= sections.length) continue;
            LevelChunkSection section = sections[sy];
            if (section == null || section.hasOnlyAir()) continue;
            if (!section.maybeHas(s -> heat(s) > 0.0F)) continue;
            scanSection(level, section, cx, sectionMin + sy, cz);
        }
        if (cursor >= total) {
            Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
            if (building.size() > MAX_BOXES) {
                building.sort((a, b) -> Double.compare(a.box.getCenter().distanceToSqr(cam),
                        b.box.getCenter().distanceToSqr(cam)));
            }
            ready = List.copyOf(building.size() > MAX_BOXES ? building.subList(0, MAX_BOXES) : building);
            building.clear();
            cursor = -1;
        }
    }

    private static void scanSection(ClientLevel level, LevelChunkSection section, int cx, int sy, int cz) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        BlockPos.MutableBlockPos nb = new BlockPos.MutableBlockPos();
        int bx = cx << 4, by = sy << 4, bz = cz << 4;
        for (int y = 0; y < 16; y++) {
            for (int z = 0; z < 16; z++) {
                for (int x = 0; x < 16; x++) {
                    BlockState s = section.getBlockState(x, y, z);
                    float h = heat(s);
                    if (h <= 0.0F) continue;
                    pos.set(bx + x, by + y, bz + z);
                    boolean fluid = s.getFluidState().is(FluidTags.LAVA);
                    int faces = 0;
                    for (Direction d : Direction.values()) {
                        nb.setWithOffset(pos, d);
                        BlockState n = level.getBlockState(nb);
                        // грань не видна к такому же горячему соседу (лава к лаве) и к сплошному блоку
                        boolean open = fluid ? !n.getFluidState().is(FluidTags.LAVA) && !n.isSolidRender(level, nb)
                                : !n.is(s.getBlock()) && !n.isSolidRender(level, nb);
                        if (open) faces |= 1 << d.get3DDataValue();
                    }
                    if (faces == 0) continue;
                    AABB box;
                    if (fluid || s.is(Blocks.FIRE) || s.is(Blocks.SOUL_FIRE) || s.is(Blocks.MAGMA_BLOCK)
                            || s.getBlock() instanceof AbstractFurnaceBlock) {
                        double top = fluid ? Math.max(0.15, s.getFluidState().getHeight(level, pos)) : 0.95;
                        box = new AABB(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1.0, pos.getY() + top, pos.getZ() + 1.0);
                    } else {
                        VoxelShape shape = s.getShape(level, pos);
                        if (shape.isEmpty()) continue;
                        box = shape.bounds().move(pos.getX(), pos.getY(), pos.getZ());
                        faces = 0x3F;
                    }
                    building.add(new Box(box, h, faces));
                }
            }
        }
    }
}
