package com.invfix.thermal.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Клиент Thermal Sense: включён ли режим у себя и как далеко зашла смена
 * картинки — волна от центра экрана за {@link #WIPE} тиков при включении и
 * обратно при выключении. Сам вид — ThermalFx (thermal.fsh) и ThermalMask
 * (силуэты сквозь стены).
 *
 * Выход с сервера, смерть (своё тело умерло) и пропавший мир выключают режим
 * сразу — ничего не остаётся.
 */
@OnlyIn(Dist.CLIENT)
public final class ThermalClient {

    /** Смена картинки, тиков. */
    static final int WIPE = 7;

    private static boolean on;
    /** 0..WIPE: насколько картинка уже тепловая. */
    private static int progress;
    private static int prevProgress;
    static long ticks;

    private ThermalClient() {}

    public static void set(boolean active) {
        on = active;
        ClientLevel level = Minecraft.getInstance().level;
        if (active && level != null) ThermalFx.keepAlive(level);
    }

    /** Режим виден (включён или ещё гаснет). */
    static boolean visible() {
        return on || progress > 0 || prevProgress > 0;
    }

    /** 0..1 — доля смены картинки на этом кадре. */
    static float strength(float partial) {
        return Mth.clamp(Mth.lerp(partial, prevProgress, progress) / WIPE, 0.0F, 1.0F);
    }

    static boolean on() {
        return on;
    }

    private static void reset() {
        on = false;
        progress = 0;
        prevProgress = 0;
        ThermalHeatBlocks.reset();
    }

    @EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
    public static final class GameBus {

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            ClientLevel level = mc.level;
            if (level == null || mc.player == null) {
                reset();
                return;
            }
            if (mc.isPaused()) return;
            ticks++;
            if (!mc.player.isAlive()) on = false;
            prevProgress = progress;
            progress = Mth.clamp(progress + (on ? 1 : -1), 0, WIPE);
            if (visible()) {
                ThermalFx.keepAlive(level);
                ThermalHeatBlocks.tick(mc);
            } else {
                ThermalHeatBlocks.reset();
            }
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            reset();
        }
    }
}
