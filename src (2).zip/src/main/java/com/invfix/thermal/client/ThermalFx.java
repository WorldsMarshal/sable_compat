package com.invfix.thermal.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.List;

/**
 * Вид Thermal Sense (thermal.fsh): мир холодный, серо-синий, по яркости и
 * граням глубины — как в тепловизоре; лава, огонь и прочее раскалённое в кадре
 * пылают; силуэты живого (ThermalMask) светятся поверх всего, сквозь стены —
 * по палитре «железной дуги»: холодное — фиолетово-красное, живое —
 * красно-жёлтое, горящее — добела. Идёт первым проходом: остальные эффекты
 * рисуются поверх уже в своих цветах.
 */
@OnlyIn(Dist.CLIENT)
public final class ThermalFx extends FxEffect {

    private static final int LINGER = 3;
    private static ThermalFx instance;

    private final ClientLevel level;
    private int idle;

    private ThermalFx(ClientLevel level) {
        this.level = level;
    }

    static void keepAlive(ClientLevel level) {
        if (instance == null || instance.finished() || instance.level != level) {
            instance = new ThermalFx(level);
            FxManager.add(instance);
        }
        instance.idle = 0;
    }

    @Override
    protected void onTick(Minecraft minecraft, ClientLevel level, int age) {
        idle++;
    }

    @Override
    protected int duration() {
        return Integer.MAX_VALUE;
    }

    @Override
    public boolean finished() {
        return idle > LINGER || Minecraft.getInstance().level != level;
    }

    @Override
    protected void onRemoved() {
        if (instance == this) instance = null;
    }

    @Override
    public Vec3 focus() {
        return FxManager.camera();
    }

    @Override
    public double range() {
        return Double.MAX_VALUE;
    }

    @Override
    public boolean first() {
        return true;
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        float k = ThermalClient.strength(frame.partial());
        if (k <= 0.001F) return;
        float time = (ThermalClient.ticks + frame.partial()) / 20.0F;
        // волна от центра: радиус в долях высоты экрана, с запасом до углов
        float wipe = k * 1.25F;
        int mask = ThermalMask.texture();
        float hasMask = mask != 0 ? 1.0F : 0.0F;
        float range = (float) ThermalMask.RANGE;
        out.add(new FxPass("thermal", u -> {
            u.glTexture("ThermalMask", mask);
            u.f4("P0", k, time, range, wipe);
            u.f4("P1", hasMask, ThermalClient.on() ? 1.0F : 0.0F, (float) ThermalMask.BLOCK_RANGE, 0.0F);
        }));
    }

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        float k = ThermalClient.strength(frame.partial());
        if (k <= 0.001F) return;
        // горячее чуть расплывается светом, края кадра — тёмно-синие, как у прибора
        screen.bloom = Math.max(screen.bloom, 0.55F * k);
        screen.bloomRadius = Math.max(screen.bloomRadius, 1.15F);
        screen.addVignette(0x050C1C, 0.45F * k);
    }
}
