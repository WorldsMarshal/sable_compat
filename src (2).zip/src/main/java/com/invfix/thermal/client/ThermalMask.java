package com.invfix.thermal.client;

import com.invfix.mixin.client.thermal.LevelRendererEntityTargetAccessor;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.AbstractGolem;
import net.minecraft.world.entity.projectile.Fireball;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL30;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Тепловые силуэты Thermal Sense: каждый кадр, пока режим включён, все живые
 * сущности в {@link #RANGE} блоках рисуются заново — моделью, как их рисует
 * игра (с анимацией, бронёй, предметом в руке), — но только типами рендера
 * outline, то есть в цель контура светящихся сущностей и без теста глубины:
 * сквозь стены. Это тот же путь, каким ванилла рисует свечение (зелье/стрела
 * свечения), только цвет вершин — не цвет команды, а данные для шейдера:
 *  R — насколько сущность горячая (0..1, {@link #heat});
 *  G — её расстояние до камеры / RANGE (стоит ли она за стеной — решает шейдер
 *      по глубине сцены);
 *  A — 1 там, где силуэт.
 * Ближние рисуются последними — поверх дальних.
 *
 * Готовая картинка копируется в собственную текстуру ({@link #texture()}),
 * которую читает проход thermal.fsh (ThermalFx), а цель контура очищается —
 * ванильный вывод контура в этот кадр её уже не покажет.
 *
 * Раскалённые блоки (ThermalHeatBlocks) идут в ту же маску первыми, с B = 1:
 * их шейдер показывает только там, где они видны глазом.
 *
 * Делается на RenderLevelStageEvent AFTER_WEATHER: всё ванильное, включая
 * обработку контура светящихся, к этому времени уже нарисовано.
 */
@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class ThermalMask {

    /** Дальше этого силуэты не рисуются, блоков. */
    public static final double RANGE = 160.0;
    /** Шкала расстояния для раскалённых блоков (их ищут ближе — точнее и шкала). */
    public static final double BLOCK_RANGE = 64.0;

    private static final net.minecraft.resources.ResourceLocation WHITE =
            net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("sable_compat", "textures/misc/thermal_white.png");

    private static final int GL_READ_FRAMEBUFFER = 0x8CA8;
    private static final int GL_DRAW_FRAMEBUFFER = 0x8CA9;
    private static final int GL_DRAW_FRAMEBUFFER_BINDING = 0x8CA6;
    private static final int GL_READ_FRAMEBUFFER_BINDING = 0x8CAA;
    private static final int GL_FRAMEBUFFER = 0x8D40;
    private static final int GL_COLOR_ATTACHMENT0 = 0x8CE0;
    private static final int GL_TEXTURE_BINDING_2D = 0x8069;
    private static final int GL_RGBA8 = 0x8058;
    private static final int GL_PIXEL_UNPACK_BUFFER = 0x88EC;
    private static final int GL_PIXEL_UNPACK_BUFFER_BINDING = 0x88EF;
    private static final int GL_RGBA = 0x1908;
    private static final int GL_UNSIGNED_BYTE = 0x1401;
    private static final int GL_LINEAR = 0x2601;
    private static final int GL_NEAREST = 0x2600;
    private static final int GL_CLAMP_TO_EDGE = 0x812F;
    private static final int GL_COLOR_BUFFER_BIT = 0x4000;

    private static boolean drawing;
    private static boolean valid;
    private static int fbo;
    private static int tex;
    private static int width;
    private static int height;
    private static ByteBufferBuilder bytes;
    private static MultiBufferSource.BufferSource buffers;

    private ThermalMask() {}

    /** Сейчас рисуются силуэты (для ThermalGlowingMixin). */
    public static boolean drawing() {
        return drawing;
    }

    /** Текстура силуэтов этого кадра; 0 — нет (цели контура нет, или режим выключен). */
    static int texture() {
        return valid ? tex : 0;
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_WEATHER) return;
        valid = false;
        if (!ThermalClient.visible()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || mc.player == null) return;
        RenderTarget outline = ((LevelRendererEntityTargetAccessor) mc.levelRenderer).invfix$entityTarget();
        if (outline == null) return;

        int prevDraw = GL11.glGetInteger(GL_DRAW_FRAMEBUFFER_BINDING);
        int prevRead = GL11.glGetInteger(GL_READ_FRAMEBUFFER_BINDING);
        try {
            if (!ensure(outline.width, outline.height)) return;
            outline.clear(Minecraft.ON_OSX);
            GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, prevDraw);
            GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, prevRead);

            draw(mc, level, event);

            GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, outline.frameBufferId);
            GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, fbo);
            GL30.glBlitFramebuffer(0, 0, width, height, 0, 0, width, height, GL_COLOR_BUFFER_BIT, GL_NEAREST);
            outline.clear(Minecraft.ON_OSX);
            valid = true;
        } catch (Throwable ignored) {
            valid = false;
            // буфер мог остаться недописанным — следующий кадр начнёт с чистого
            try {
                if (bytes != null) bytes.close();
            } catch (Throwable ignoredToo) {}
            bytes = null;
            buffers = null;
        } finally {
            drawing = false;
            GL30.glBindFramebuffer(GL_DRAW_FRAMEBUFFER, prevDraw);
            GL30.glBindFramebuffer(GL_READ_FRAMEBUFFER, prevRead);
        }
    }

    private record Target(Entity entity, double distSq) {}

    private static void draw(Minecraft mc, ClientLevel level, RenderLevelStageEvent event) {
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        Entity self = mc.getCameraEntity();

        if (buffers == null) {
            bytes = new ByteBufferBuilder(1536);
            buffers = MultiBufferSource.immediate(bytes);
        }
        PoseStack pose = event.getPoseStack();

        // раскалённые блоки — первыми, живое ложится поверх
        List<ThermalHeatBlocks.Box> hot = ThermalHeatBlocks.boxes();
        if (!hot.isEmpty()) {
            VertexConsumer vc = buffers.getBuffer(RenderType.outline(WHITE));
            org.joml.Matrix4f m = pose.last().pose();
            for (ThermalHeatBlocks.Box b : hot) {
                if (!event.getFrustum().isVisible(b.box())) continue;
                double dist = b.box().getCenter().distanceTo(cam);
                if (dist > BLOCK_RANGE) continue;
                int r = Mth.clamp((int) (b.heat() * 255.0F), 0, 255);
                int g = Mth.clamp((int) (dist / BLOCK_RANGE * 255.0), 0, 255);
                box(vc, m, b.box().move(-cam.x, -cam.y, -cam.z), b.faces(), r, g);
            }
            buffers.endBatch();
        }

        List<Target> targets = new ArrayList<>();
        for (Entity e : level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity) && !(e instanceof Fireball) && !e.isOnFire()) continue;
            if (e instanceof LivingEntity le && le.isRemoved()) continue;
            if (e == self && !camera.isDetached()) continue;
            double d2 = e.getPosition(partial).distanceToSqr(cam);
            if (d2 > RANGE * RANGE) continue;
            if (!event.getFrustum().isVisible(e.getBoundingBoxForCulling().inflate(0.5))) continue;
            targets.add(new Target(e, d2));
        }
        if (targets.isEmpty()) return;
        // дальние первыми: ближний силуэт ложится поверх
        targets.sort((a, b) -> Double.compare(b.distSq, a.distSq));

        EntityRenderDispatcher dispatcher = mc.getEntityRenderDispatcher();
        Tinted source = new Tinted(buffers);
        drawing = true;
        try {
            for (Target t : targets) {
                Entity e = t.entity;
                source.r = Mth.clamp((int) (heat(e) * 255.0F), 0, 255);
                source.g = Mth.clamp((int) (Math.sqrt(t.distSq) / RANGE * 255.0), 0, 255);
                double x = Mth.lerp(partial, e.xOld, e.getX()) - cam.x;
                double y = Mth.lerp(partial, e.yOld, e.getY()) - cam.y;
                double z = Mth.lerp(partial, e.zOld, e.getZ()) - cam.z;
                float yaw = Mth.lerp(partial, e.yRotO, e.getYRot());
                try {
                    dispatcher.render(e, x, y, z, yaw, partial, pose, source, 0xF000F0);
                } catch (Throwable ignored) {
                    // чужой рендерер упал — без его силуэта, остальным не мешает
                }
            }
        } finally {
            drawing = false;
            buffers.endBatch();
        }
    }

    /** Открытые грани коробки (биты по Direction.get3DDataValue), наружу против часовой. */
    private static void box(VertexConsumer vc, org.joml.Matrix4f m, net.minecraft.world.phys.AABB b, int faces,
                            int r, int g) {
        float x0 = (float) b.minX, y0 = (float) b.minY, z0 = (float) b.minZ;
        float x1 = (float) b.maxX, y1 = (float) b.maxY, z1 = (float) b.maxZ;
        // DOWN 0, UP 1, NORTH 2 (-z), SOUTH 3 (+z), WEST 4 (-x), EAST 5 (+x)
        if ((faces & 1) != 0) quad(vc, m, r, g, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0, -1, 0);
        if ((faces & 2) != 0) quad(vc, m, r, g, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, 0, 1, 0);
        if ((faces & 4) != 0) quad(vc, m, r, g, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0, 0, 0, -1);
        if ((faces & 8) != 0) quad(vc, m, r, g, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0, 0, 1);
        if ((faces & 16) != 0) quad(vc, m, r, g, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, -1, 0, 0);
        if ((faces & 32) != 0) quad(vc, m, r, g, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, 1, 0, 0);
    }

    /** Четыре угла; если они идут по часовой, если смотреть снаружи (с нормали), порядок разворачивается. */
    private static void quad(VertexConsumer vc, org.joml.Matrix4f m, int r, int g,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float nx, float ny, float nz) {
        float ux = bx - ax, uy = by - ay, uz = bz - az;
        float wx = cx - ax, wy = cy - ay, wz = cz - az;
        float dot = (uy * wz - uz * wy) * nx + (uz * wx - ux * wz) * ny + (ux * wy - uy * wx) * nz;
        if (dot >= 0.0F) {
            vc.addVertex(m, ax, ay, az).setColor(r, g, 255, 255).setUv(0.0F, 0.0F);
            vc.addVertex(m, bx, by, bz).setColor(r, g, 255, 255).setUv(0.0F, 1.0F);
            vc.addVertex(m, cx, cy, cz).setColor(r, g, 255, 255).setUv(1.0F, 1.0F);
            vc.addVertex(m, dx, dy, dz).setColor(r, g, 255, 255).setUv(1.0F, 0.0F);
        } else {
            vc.addVertex(m, dx, dy, dz).setColor(r, g, 255, 255).setUv(1.0F, 0.0F);
            vc.addVertex(m, cx, cy, cz).setColor(r, g, 255, 255).setUv(1.0F, 1.0F);
            vc.addVertex(m, bx, by, bz).setColor(r, g, 255, 255).setUv(0.0F, 1.0F);
            vc.addVertex(m, ax, ay, az).setColor(r, g, 255, 255).setUv(0.0F, 0.0F);
        }
    }

    /**
     * Насколько сущность горячая, 0..1: горящее и огненное — добела; обычные
     * живые (игроки, звери, жители) — красно-жёлтые; нежить и големы холодные;
     * водные — прохладнее. Умирающие остывают.
     */
    static float heat(Entity e) {
        EntityType<?> type = e.getType();
        float h;
        if (e.isOnFire() || e instanceof Fireball || type == EntityType.BLAZE || type == EntityType.MAGMA_CUBE) {
            h = 1.0F;
        } else if (type == EntityType.STRIDER || type == EntityType.GHAST || type == EntityType.WITHER
                || type == EntityType.ENDER_DRAGON) {
            h = 0.86F;
        } else if (type.is(EntityTypeTags.UNDEAD)) {
            h = 0.3F;
        } else if (e instanceof AbstractGolem) {
            h = 0.22F;
        } else if (type.is(EntityTypeTags.AQUATIC)) {
            h = 0.4F;
        } else if (type.is(EntityTypeTags.ARTHROPOD)) {
            h = 0.5F;
        } else {
            h = 0.66F;
        }
        // The Whole Sentry Power — раскалён
        if (com.invfix.sentry.client.SentryClient.isActive(e.getId())) h = Math.max(h, 0.95F);
        if (e instanceof LivingEntity le && le.deathTime > 0) {
            h *= 1.0F - 0.7F * Math.min(1.0F, le.deathTime / 20.0F);
        }
        return h;
    }

    /** Своя текстура размера цели контура; пересоздаётся при смене размера окна. */
    private static boolean ensure(int w, int h) {
        if (w <= 0 || h <= 0) return false;
        if (fbo != 0 && w == width && h == height) return true;
        int prevTex = GL11.glGetInteger(GL_TEXTURE_BINDING_2D);
        int unpack = GL11.glGetInteger(GL_PIXEL_UNPACK_BUFFER_BINDING);
        GL15.glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);
        if (fbo == 0) {
            fbo = GL30.glGenFramebuffers();
            tex = GL11.glGenTextures();
        }
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, tex);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, 0L);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, prevTex);
        GL15.glBindBuffer(GL_PIXEL_UNPACK_BUFFER, unpack);
        GL30.glBindFramebuffer(GL_FRAMEBUFFER, fbo);
        GL30.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, tex, 0);
        width = w;
        height = h;
        return true;
    }

    /**
     * Источник буферов, который пропускает только то, что ванилла пустила бы в
     * контур: тип outline самого рендера или его outline-пару. Всё прочее
     * (тени, надписи, поводки, хитбоксы) — в никуда. Цвет вершин — свой.
     */
    private static final class Tinted implements MultiBufferSource {
        private final MultiBufferSource.BufferSource out;
        int r;
        int g;

        Tinted(MultiBufferSource.BufferSource out) {
            this.out = out;
        }

        @Override
        public VertexConsumer getBuffer(RenderType type) {
            if (type.isOutline()) return new Tint(out.getBuffer(type), r, g);
            Optional<RenderType> outline = type.outline();
            return outline.isPresent() ? new Tint(out.getBuffer(outline.get()), r, g) : Sink.INSTANCE;
        }
    }

    /** Вершины как есть (позиция и uv — для отсечения прозрачных пикселей текстуры), цвет — данные. */
    private record Tint(VertexConsumer delegate, int r, int g) implements VertexConsumer {
        @Override
        public VertexConsumer addVertex(float x, float y, float z) {
            delegate.addVertex(x, y, z).setColor(r, g, 0, 255);
            return this;
        }

        @Override
        public VertexConsumer setColor(int red, int green, int blue, int alpha) {
            return this;
        }

        @Override
        public VertexConsumer setUv(float u, float v) {
            delegate.setUv(u, v);
            return this;
        }

        @Override
        public VertexConsumer setUv1(int u, int v) {
            return this;
        }

        @Override
        public VertexConsumer setUv2(int u, int v) {
            return this;
        }

        @Override
        public VertexConsumer setNormal(float x, float y, float z) {
            return this;
        }
    }

    /** Ничего не пишет. */
    private enum Sink implements VertexConsumer {
        INSTANCE;

        @Override public VertexConsumer addVertex(float x, float y, float z) { return this; }
        @Override public VertexConsumer setColor(int r, int g, int b, int a) { return this; }
        @Override public VertexConsumer setUv(float u, float v) { return this; }
        @Override public VertexConsumer setUv1(int u, int v) { return this; }
        @Override public VertexConsumer setUv2(int u, int v) { return this; }
        @Override public VertexConsumer setNormal(float x, float y, float z) { return this; }
    }
}
