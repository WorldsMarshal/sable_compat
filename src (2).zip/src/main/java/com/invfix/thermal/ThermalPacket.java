package com.invfix.thermal;

import com.invfix.thermal.client.ThermalClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Сервер → игрок: Thermal Sense включён (active) или выключен. */
public record ThermalPacket(boolean active) implements CustomPacketPayload {

    public static final Type<ThermalPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "thermal_sense"));

    public static final StreamCodec<FriendlyByteBuf, ThermalPacket> STREAM_CODEC = StreamCodec.of(
            (buf, m) -> buf.writeBoolean(m.active()),
            buf -> new ThermalPacket(buf.readBoolean()));

    @Override
    public Type<ThermalPacket> type() {
        return TYPE;
    }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(ThermalPacket p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ThermalClient.set(p.active));
    }
}
