package com.invfix.altrumite;

/**
 * Новая раса Altrumite — усиленная версия Вильтрумитов (~10x).
 * Доступ ко всем способностям Viltrumite Power + эксклюзивные Heat Vision и Neutron Beam.
 */
public final class AltrumiteRace {
    private AltrumiteRace() {}

    /** Строка расы (§1 — тёмно-синий). */
    public static final String RACE  = "§1§lAlien(Metroman)";
    /** Строка Power-набора (§1 — тёмно-синий). */
    public static final String POWER = "§1§lAlien(Metroman)";

    /**
     * Прежняя строка расы (до переименования Altrumite → Alien(Metroman)).
     * Хранится в сейвах старых миров в полях Race/Power/racePower.
     * Используется только для миграции — см. {@link AltrumiteMigration}.
     */
    public static final String OLD_RACE = "§1§lAltrumite";

    /**
     * Коэффициент расы. Viltrumite = 0.6 → statMultiplier 1.6.
     * Altrumite = 15.0 → statMultiplier 16.0 (ровно 10x от Viltrumite).
     */
    public static final double RACE_STAT_MULTIPLIER = 3.5;

    public static boolean isAltrumite(String race) {
        return RACE.equals(race);
    }
}