package com.invfix.altrumite;

import com.mojang.brigadier.Command;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.mcreator.invincibleinc.procedures.ClearAbilitiesProcedure;
import net.mcreator.invincibleinc.procedures.ClearPassiveProcedure;
import net.mcreator.invincibleinc.procedures.FullResetProcedure;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * Команда /altrumite — назначает игроку расу Altrumite.
 * Дублирует логику RSViltrumiteItemProcedure: ставит расу, чистит абилки/пассивки, сбрасывает.
 */
@EventBusSubscriber(modid = "sable_compat")
public class AltrumiteCommand {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("altrumite")
                        .requires(s -> s.hasPermission(2))
                        .executes(ctx -> {
                            if (ctx.getSource().getEntity() instanceof ServerPlayer player) {
                                applyAltrumite(player);
                                ctx.getSource().sendSuccess(
                                        () -> Component.literal("§cРаса установлена: Alien(Metroman)"), false);
                                return Command.SINGLE_SUCCESS;
                            }
                            return 0;
                        })
        );
    }

    public static void applyAltrumite(ServerPlayer player) {
        InvincibleIncModVariables.PlayerVariables vars =
                player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        vars.Race = AltrumiteRace.RACE;
        vars.Power = AltrumiteRace.POWER;
        vars.racePower = AltrumiteRace.POWER;
        vars.RaceStatMultiplier = AltrumiteRace.RACE_STAT_MULTIPLIER;
        vars.markSyncDirty();

        try { ClearAbilitiesProcedure.execute(player); } catch (Exception ignored) {}
        try { ClearPassiveProcedure.execute(player); } catch (Exception ignored) {}
        try { FullResetProcedure.execute(player.level(), player); } catch (Exception ignored) {}
    }
}