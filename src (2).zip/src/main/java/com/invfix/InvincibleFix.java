package com.invfix;

import com.invfix.ammo.AmmoForgeItems;
import com.invfix.cyberware.CompositeItems;
import com.invfix.cyberware.CompositeFluids;
import com.invfix.heatvision.HeatVisionSounds;
import com.invfix.kineticstrike.NukeSounds;
import com.invfix.scourge.ScourgeRegistry;
import com.invfix.theboys.CompoundVRegistry;
import com.invfix.thing.ThingRegistry;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod("sable_compat")
public class InvincibleFix {

    public static final String MOD_ID = "sable_compat";

    public InvincibleFix(IEventBus modEventBus) {
        // Патч работает через Mixin — никакой доп. логики здесь не нужно
        HeatVisionSounds.SOUNDS.register(modEventBus);

        // Звук ядерного удара Kinetic Strike. Визуал — шейдерный (kineticstrike.client.NukeFx).
        NukeSounds.SOUNDS.register(modEventBus);
        com.invfix.timestop.blink.TimeStopBlinkSounds.SOUNDS.register(modEventBus);
        // Звуки попаданий ударных способностей при Attackpwr > 500 (combo.ComboImpact).
        com.invfix.combo.ComboSounds.SOUNDS.register(modEventBus);
        com.invfix.heatdisruption.HeatDisruptionSounds.SOUNDS.register(modEventBus);
        com.invfix.dismantle.DismantleSounds.SOUNDS.register(modEventBus);
        com.invfix.energyblast.EnergyBlastSounds.SOUNDS.register(modEventBus);
        com.invfix.sentry.SentrySounds.SOUNDS.register(modEventBus);
        com.invfix.spacefold.SpaceFoldSounds.SOUNDS.register(modEventBus);

        // Кастомные эффекты препарата V (раса Human) — Critical Poisoning и т.п.
        CompoundVRegistry.register(modEventBus);

        // Scourge Virus — предмет, снаряд и эффект заражения вильтрумитов.
        ScourgeRegistry.register(modEventBus);

        // Промежуточные предметы для крафта боеприпасов PointBlank (Create/CBC).
        AmmoForgeItems.register(modEventBus);

        // Композитные материалы ветки кибер-протезов (Metal Gear).
        CompositeItems.register(modEventBus);

        // Жидкость «незавершённый композит» (фаза 2 ветки кибер-протезов).
        CompositeFluids.register(modEventBus);

        ThingRegistry.register(modEventBus);
        com.invfix.missile.MissileRegistry.register(modEventBus);
        com.invfix.railgun.RailgunRegistry.register(modEventBus);

        // Жидкость «фоторезист» (фаза 5a, наноэлектроника) — наносится на
        // окислённую пластину спаутом, превращая её в покрытую (вход литографа).
        com.invfix.cyberware.NanoFluids.register(modEventBus);

        // Общая инфраструктура машин: единый Энергоприёмник (power_input, FE только от
        // powergrid device_connector) + Create-шлюз предметов (machine_item_port).
        // Регистрирует свои capability самостоятельно.
        com.invfix.cyberware.machines.SableRecipes.register(modEventBus);
        com.invfix.cyberware.machines.MachineRegistry.register(modEventBus);

        com.invfix.rick.RickRegistry.register(modEventBus);

        // Самозарядный энергетический куб — эксклюзив Рика. Рецепт лежит в
        // sable_compat:precision с tier 137; станков такого тира в сборке нет, а
        // карманный резолвер Рика тир не проверяет — отсюда и эксклюзивность.
        com.invfix.rick.cube.RickCubeRegistry.register(modEventBus);

        // Портальная пушка и портальная жидкость. Жидкости в ricksportalgun нет —
        // там только предмет-бутылёк, поэтому настоящий Fluid заводится у нас.
        com.invfix.rick.portalgun.PortalGunRegistry.register(modEventBus);

        // Пульт остановки времени: нижний уровень тайм-стопа. Эксклюзивность
        // та же — рецепт tier 137, станков такого тира в сборке нет.
        com.invfix.rick.timedevice.TimeDeviceRegistry.register(modEventBus);

        // Камень Времени: пока только предмет и камень-на-земле. Модель,
        // текстура и поведение предмета — из Infinity Stones Core.
        com.invfix.infinity.TimeStoneRegistry.register(modEventBus);
        if (net.neoforged.fml.loading.FMLEnvironment.dist == net.neoforged.api.distmarker.Dist.CLIENT) {
            com.invfix.infinity.client.TimeStoneClient.init(modEventBus);
        }

        // Модуль управления щитом: щит злого Морти из ricks_stuff на FE.
        com.invfix.rick.shield.ShieldRegistry.register(modEventBus);

        // Бластер для Point Blank: сам предмет — из нашего пака расширений
        // (PointBlankExtensionPackMixin), здесь — его питание от FE.
        com.invfix.compat.pointblank.FlaxanBlasterEnergy.register(modEventBus);
        if (net.neoforged.fml.loading.FMLEnvironment.dist == net.neoforged.api.distmarker.Dist.CLIENT) {
            com.invfix.compat.pointblank.FlaxanBlasterClient.init();
        }

        // Aeroworks: тяжёлый гироскоп для сверхтяжёлых кораблей. Регистрация
        // сама проверяет наличие aeroworks и create и без них ничего не делает.
        com.invfix.aeroworks.AeroworksIntegration.register(modEventBus);
        if (net.neoforged.fml.loading.FMLEnvironment.dist == net.neoforged.api.distmarker.Dist.CLIENT) {
            com.invfix.rick.cube.client.RickCubeClient.init(modEventBus);
            com.invfix.rick.portalgun.client.PortalGunClient.init(modEventBus);
            com.invfix.aeroworks.AeroworksClient.init(modEventBus);
        }

        if (net.neoforged.fml.loading.FMLEnvironment.dist == net.neoforged.api.distmarker.Dist.CLIENT) {
            com.invfix.cyberware.machines.MachineClient.init(modEventBus);
            com.invfix.integration.SableIntegrations.initClient(modEventBus);
        }

        // Литограф (фаза 9): блоки, BlockEntity, меню, multiblock. Энергию берёт из
        // общего Энергоприёмника (power_input) в стене структуры.
        com.invfix.cyberware.lithograph.LithographRegistry.register(modEventBus);
        modEventBus.addListener((net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent e) -> {
            com.invfix.cyberware.lithograph.LithographControllerBlockEntity.registerCapabilities(e);
        });
        if (net.neoforged.fml.loading.FMLEnvironment.dist == net.neoforged.api.distmarker.Dist.CLIENT) {
            com.invfix.cyberware.lithograph.LithographClient.init(modEventBus);
        }

        // Бионические протезы (фаза 4) — только если загружен createcybernetics,
        // т.к. предметы наследуют его классы (иначе без мода был бы краш).
        if (net.neoforged.fml.ModList.get().isLoaded("createcybernetics")) {
            com.invfix.cyberware.CyberwareItems.register(modEventBus);
            // Кап скорости/прыжка: пересчёт по факту операции (не по тику).
            net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(new com.invfix.cybercompat.SurgeryCapListener());
        }

        // Высоковольтный провод — расширение проводов powergrid. Класс ссылается на
        // powergrid.WireItem, поэтому регистрируем только при загруженном powergrid.
        // АФАР (AESA) — только при загруженном create_radar (классы compileOnly).
        if (net.neoforged.fml.ModList.get().isLoaded("create_radar")) {
            com.invfix.radar.RadarIntegration.register(modEventBus);
        }

        if (net.neoforged.fml.ModList.get().isLoaded("powergrid")) {
            com.invfix.cyberware.compat.PowergridExtras.register(modEventBus);
        }
    }
}