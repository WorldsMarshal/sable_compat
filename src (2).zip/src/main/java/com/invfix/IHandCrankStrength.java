package com.invfix;

/**
 * Интерфейс, который инжектируется в HandCrankBlockEntity через миксин.
 * Хранит множитель силы игрока для расчёта выдаваемой нагрузки (SU).
 */
public interface IHandCrankStrength {
    void invfix$setStrengthMult(double mult);
    double invfix$getStrengthMult();
}
