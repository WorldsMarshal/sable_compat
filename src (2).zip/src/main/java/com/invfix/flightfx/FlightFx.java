package com.invfix.flightfx;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Визуал быстрого полёта — тем же путём, что взрыв Kinetic Strike (NukeFx) и
 * удар The Shooting Star: мировые проходы по буферу глубины плюс композит.
 * Заменяет прежний конус из полигонов (ShockwaveConeRenderer), серверный
 * циклон из частиц, облако частиц каждого тика и Photon-всплески ударов.
 *
 * Один эффект на всех: живёт, пока FlightFxTracker кого-то ведёт.
 *
 *  flight.fsh, на каждого из 3 ближайших летящих:
 *    - конус Маха: полуугол asin(1/M) — сужается с разгоном; спереди плотный
 *      воротник конденсата с резкой кромкой, рвущийся назад полосами, за ним —
 *      прозрачный скачок уплотнения, преломляющий мир; при нагреве нос
 *      раскаляется добела, оболочка горит оранжевым;
 *    - след по реальному пути: дрожь воздуха, клочья конденсата, при нагреве —
 *      тонкое остывающее плазменное ядро;
 *    - пыль и марево на поверхностях, мимо которых прошёл след;
 *    - свой полёт: воздух, несущийся мимо камеры полосами (при нагреве — плазма).
 *  boom.fsh, на каждый звуковой удар: сфера скачка уплотнения, кольцо
 *    конденсата поперёк линии полёта, вспышка в центре.
 *  Композит: свой полёт — радиальное размытие, аберрация, виньетка; удары —
 *    тряска (в трекере), вспышка, bloom; удар ступени 4 рядом или свой — два
 *    белых импакт-кадра.
 *
 * Все числа ниже сверены на стенде (тот же конвейер в WebGL2): виды сбоку,
 * сзади, спереди, от первого лица, удары ступеней 2 и 4.
 */
@OnlyIn(Dist.CLIENT)
public final class FlightFx extends FxEffect {

    private static final int MAX_DRAWN = 3;
    private static final double BOOM_RANGE = 400.0;

    private final ClientLevel level;

    FlightFx(ClientLevel level) {
        this.level = level;
    }

    @Override
    protected int duration() {
        return Integer.MAX_VALUE;
    }

    @Override
    public boolean finished() {
        return Minecraft.getInstance().level != level
                || (FlightFxTracker.FLIERS.isEmpty() && FlightFxTracker.BOOMS.isEmpty());
    }

    @Override
    protected void onRemoved() {
        if (FlightFxTracker.effect == this) FlightFxTracker.effect = null;
    }

    /** Отсечение — своё, по каждому летящему и удару; сам эффект всегда «у камеры». */
    @Override
    public Vec3 focus() {
        return FxManager.camera();
    }

    @Override
    public double range() {
        return Double.MAX_VALUE;
    }

    // ── параметры, общие для проходов и композита ──────────────────────────

    private record Look(FlightFxTracker.Flier flier, Entity entity, Vec3 centre, double distance) {}

    private List<Look> nearest(FxFrame frame) {
        List<Look> list = new ArrayList<>();
        for (FlightFxTracker.Flier f : FlightFxTracker.FLIERS.values()) {
            Entity e = level.getEntity(f.id);
            Vec3 c = e != null ? FlightFxTracker.centre(e, frame.partial()) : f.last;
            if (c == null) continue;
            list.add(new Look(f, e, c, c.distanceTo(frame.camera())));
        }
        list.sort(Comparator.comparingDouble(Look::distance));
        return list.size() > MAX_DRAWN ? list.subList(0, MAX_DRAWN) : list;
    }

    private static boolean isCamera(Minecraft mc, Entity e) {
        return e != null && e == mc.getCameraEntity();
    }

    private float seconds(FxFrame frame, long tick) {
        return (level.getGameTime() - tick + frame.partial()) / 20.0F;
    }

    // ── проходы ────────────────────────────────────────────────────────────

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        Minecraft mc = frame.minecraft();
        float time = ((level.getGameTime() % 24000L) + frame.partial()) / 20.0F;
        Vec3 cam = frame.camera();
        float ox = (float) (cam.x - 2048.0 * Math.floor(cam.x / 2048.0));
        float oy = (float) (cam.y - 2048.0 * Math.floor(cam.y / 2048.0));
        float oz = (float) (cam.z - 2048.0 * Math.floor(cam.z / 2048.0));

        boolean firstPerson = mc.options.getCameraType().isFirstPerson();
        Entity cameraEntity = mc.getCameraEntity();

        // удары — первыми: конус летящего ложится поверх
        for (FlightFxTracker.Boom b : FlightFxTracker.BOOMS) {
            if (b.pos().distanceTo(cam) > BOOM_RANGE) continue;
            float s = seconds(frame, b.tick());
            if (s < 0.0F || s > FlightFxTracker.BOOM_TICKS / 20.0F) continue;
            int stage = b.stage();
            float shell = 3.0F + s * (55.0F + 12.0F * stage);
            float ring = 1.5F + (18.0F + 6.0F * stage) * (1.0F - (float) Math.exp(-s / 0.35F));
            float thick = 0.7F + s * 2.5F + 0.3F * stage;
            float flash = (0.12F + 0.05F * stage + 0.4F * Math.max(stage - 2, 0)) * (float) Math.exp(-s / 0.09F);
            Vec3 at = b.pos();
            Vec3 d = b.dir();
            // свой удар от первого лица: точка удара уже позади камеры, и кольцо со сферой не видны.
            // Удар держится в 8 блоках перед летящим — кольцо расходится вокруг взгляда.
            if (b.own() && firstPerson && cameraEntity != null) {
                FlightFxTracker.Flier self = FlightFxTracker.FLIERS.get(cameraEntity.getId());
                if (self != null) d = self.dir;
                at = FlightFxTracker.centre(cameraEntity, frame.partial()).add(d.scale(8.0));
            }
            Vec3 c = frame.rel(at);
            Vec3 dd = d;
            float seed = b.seed();
            out.add(new FxPass("boom", u -> {
                u.v3("Target", c);
                u.v3("Facing", dd);
                u.f4("P0", s, stage, seed, 1.0F);
                u.f4("P1", shell, ring, thick, flash);
            }));
        }

        Vec3 forward = FxManager.cameraForward();
        for (Look look : nearest(frame)) {
            FlightFxTracker.Flier f = look.flier();
            float k = f.presence;
            float wake = f.wake;
            if (k <= 0.001F && wake <= 0.001F) continue;
            double speed = f.nominal;
            boolean camera = isCamera(mc, look.entity());
            float own = camera && firstPerson ? 1.0F : 0.0F;
            float heat = f.dashing ? 1.0F : FlightFxTracker.heat(look.entity());
            float mach = (float) Mth.clamp(speed / 3.2, 1.1, 4.5);
            float sinceBoom = seconds(frame, f.boomTick);
            float cone = k * (0.55F + 0.45F * (float) Math.exp(-sinceBoom / 0.5F));
            float scale = f.dashing ? 2.0F : 1.0F;
            // крупнее прежнего в ~1.6 раза; вершина вынесена вперёд, за голову, — конус
            // начинается перед летящим, а не в нём
            float length = (float) (6.5 + speed * 0.9) * scale;
            float collar = (float) (3.0 + speed * 0.55) * scale;
            float apex = (float) (2.0 + speed * 0.1) * scale;
            float ground = wake * (float) FlightFxTracker.smooth((speed - 5.0) / 5.0);
            // воздух мимо камеры — только когда камера смотрит по ходу полёта (не вид спереди)
            float along = (float) FlightFxTracker.smooth((forward.dot(f.dir) - 0.2) / 0.4);
            // с третьей скорости уже заметно (0.35), к двенадцатой — полностью
            float tunnel = camera ? k * along * (0.35F + 0.65F * (float) FlightFxTracker.smooth((speed - 4.0) / 9.0)) : 0.0F;

            float[] pts = new float[64];
            Vec3 head = frame.rel(look.centre());
            pts[0] = (float) head.x;
            pts[1] = (float) head.y;
            pts[2] = (float) head.z;
            pts[3] = 0.0F;
            int count = 1;
            for (int i = 0; i < f.count && count < 16; i++, count++) {
                Vec3 p = frame.rel(f.path[i]);
                pts[count * 4] = (float) p.x;
                pts[count * 4 + 1] = (float) p.y;
                pts[count * 4 + 2] = (float) p.z;
                pts[count * 4 + 3] = Math.max(seconds(frame, f.pathTick[i]), 0.0F);
            }
            int n = count;
            Vec3 dir = f.dir;
            float fSpeed = (float) speed;
            float seed = f.seed;
            out.add(new FxPass("flight", u -> {
                u.v3("Target", head);
                u.v3("Facing", dir);
                u.f3("Origin", ox, oy, oz);
                u.vec4s("Pts", pts);
                u.f4("P0", fSpeed, time, seed, n);
                u.f4("P1", cone, mach, heat, wake);
                u.f4("P2", ground, length, own, collar);
                u.f4("P3", tunnel, apex, 0.0F, 0.0F);
            }));
        }
    }

    // ── композит ───────────────────────────────────────────────────────────

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        Minecraft mc = frame.minecraft();
        for (Look look : nearest(frame)) {
            FlightFxTracker.Flier f = look.flier();
            float heat = f.dashing ? 1.0F : FlightFxTracker.heat(look.entity());
            float near = (float) Mth.clamp(1.0 - look.distance() / 200.0, 0.0, 1.0);
            if (heat > 0.0F && near > 0.0F) {
                screen.bloom = Math.max(screen.bloom, 0.7F * heat * f.presence * near);
                screen.bloomRadius = Math.max(screen.bloomRadius, 1.0F + 0.5F * heat);
            }
            if (!isCamera(mc, look.entity())) continue;
            double speed = f.nominal;
            float k = f.presence;
            screen.zoomBlur = Math.max(screen.zoomBlur, (0.08F + 0.37F * (float) FlightFxTracker.smooth((speed - 4.0) / 10.0)) * k);
            screen.aberration = Math.max(screen.aberration, (float) FlightFxTracker.smooth((speed - 7.0) / 7.0) * 0.35F * k);
            screen.addVignette(0x000000, (float) FlightFxTracker.smooth((speed - 6.0) / 8.0) * 0.3F * k);
            screen.shake = Math.max(screen.shake, (float) FlightFxTracker.smooth((speed - 9.0) / 5.0) * 0.12F * k);
        }

        for (FlightFxTracker.Boom b : FlightFxTracker.BOOMS) {
            float s = seconds(frame, b.tick());
            if (s < 0.0F) continue;
            double distance = b.pos().distanceTo(frame.camera());
            float near = b.own() ? 1.0F : (float) Mth.clamp(1.0 - distance / 160.0, 0.0, 1.0);
            if (near <= 0.0F) continue;
            int stage = b.stage();
            if (stage >= 3) {
                screen.addFlash(0xFFFFFF, (0.15F + 0.2F * (stage - 2)) * (float) Math.exp(-s / 0.12F) * near);
            }
            if (stage >= 4 && (b.own() || distance < 48.0)) {
                impactSequence(screen, s, b.pos(), 0.8F, 0.04F, 37, 36);
            }
            screen.bloom = Math.max(screen.bloom, 0.8F * (float) Math.exp(-s / 0.3F) * near);
            screen.bloomRadius = Math.max(screen.bloomRadius, 1.4F);
        }
    }
}
