package com.invfix.flightfx;

import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.CommandEvent;

/**
 * Глушит Photon-всплески звуковых ударов полёта Invincible: на скорости 3, 6,
 * 9 и 12 FlightTicksProcedure трижды (раз в 5 тиков, через queueServerWork)
 * выполняет команды «photon fx photon:beast_pounce…» и
 * «photon fx photon:misc_heavyhit2_downup». Удары теперь рисует FlightFx
 * (boom.fsh). Звук взрыва Invincible остаётся.
 *
 * Те же эффекты Photon вызывают и другие способности (тяжёлая атака, прыжок,
 * Speed Blitz, Upperfang) — их не трогаем: команда гасится, только если в
 * стеке вызова есть FlightTicksProcedure (его отложенные повторы — тоже: их
 * лямбды и анонимный класс лежат в нём же, FlightTicksProcedure$N).
 *
 * Сервер (и встроенный сервер одиночной игры): CommandEvent из
 * Commands#performCommand, отмена без исключения — команда тихо не выполняется.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class FlightPhotonFilter {

    private static final String PROCEDURE = "net.mcreator.invincibleinc.procedures.FlightTicksProcedure";

    private FlightPhotonFilter() {}

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onCommand(CommandEvent event) {
        String command = event.getParseResults().getReader().getString();
        if (command.startsWith("/")) command = command.substring(1);
        if (!command.startsWith("photon fx ")) return;
        if (!command.contains("photon:beast_pounce") && !command.contains("photon:misc_heavyhit2_downup")) return;
        boolean fromFlight = StackWalker.getInstance().walk(frames ->
                frames.limit(64).anyMatch(f -> f.getClassName().startsWith(PROCEDURE)));
        if (fromFlight) event.setCanceled(true);
    }
}
