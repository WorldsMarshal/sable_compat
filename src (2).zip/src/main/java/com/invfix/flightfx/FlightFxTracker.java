package com.invfix.flightfx;

import com.invfix.flightheat.client.SupersonicHeatManager;
import com.invfix.fx.FxManager;
import com.invfix.kineticstrike.client.KineticStrikeClient;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


/**
 * Кто сейчас летит быстро и где прогремели звуковые удары — всё, что нужно
 * визуалу полёта (FlightFx). Только клиент, только по тому, что клиент и так
 * знает: позиции игроков и синхронизированные переменные Invincible (их мод
 * рассылает всем в измерении).
 *
 * Летящий: полёт Invincible (elytraflighton, не на земле, flightSpeed >= 3) или
 * рывок Kinetic Strike. Скорость и направление — по реальному смещению за тик,
 * не по взгляду. Путь — 15 точек раз в 2 тика (1.5 с).
 *
 * Звуковые удары — на тех же порогах, что у Invincible (flightSpeed 3, 6, 9,
 * 12 — ступени 1..4): ступень выросла — удар. Рывок Kinetic Strike при
 * старте — удар ступени 3.
 */
@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class FlightFxTracker {

    /** Дальше от камеры не следим. */
    static final double RANGE = 512.0;
    /** Точек пути (плюс текущая позиция — 16, как Pts в шейдере). */
    static final int HISTORY = 15;
    static final int SAMPLE_EVERY = 2;
    /** Жизнь следа, секунд (WAKE_LIFE в flight.fsh). */
    static final float WAKE_LIFE = 1.6F;
    /** Жизнь удара, тиков. */
    static final int BOOM_TICKS = 34;
    static final int MAX_BOOMS = 6;
    /** Смещение за тик больше этого — телепорт, путь начинается заново. */
    private static final double TELEPORT = 80.0;

    static final class Flier {
        final int id;
        final Vec3[] path = new Vec3[HISTORY];
        final long[] pathTick = new long[HISTORY];
        int count;
        Vec3 last;
        Vec3 velocity = Vec3.ZERO;
        Vec3 dir = new Vec3(0.0, 0.0, 1.0);
        /** Измеренная скорость, блоков/тик (по смещению за тик). */
        double speed;
        /** Визуальная скорость (visualSpeed): по ней строится весь визуал. */
        double nominal;
        double flightSpeed;
        int stage;
        boolean dashing;
        boolean active;
        /** Летит по состоянию Invincible в этом тике (ещё до замера скорости). */
        boolean flying;
        /** Был ли активен в прошлом тике — для гистерезиса порога. */
        boolean wasActive;
        /** Присутствие конуса 0..1: быстро набирается, плавно гаснет. */
        float presence;
        /** Сила следа 0..1: гаснет медленнее, след досыхает после остановки. */
        float wake;
        long boomTick = Long.MIN_VALUE / 2;
        final float seed;

        Flier(int id) {
            this.id = id;
            this.seed = (float) ((id * 0.6180339887) % 1.0);
        }

        void push(Vec3 p, long tick) {
            System.arraycopy(path, 0, path, 1, HISTORY - 1);
            System.arraycopy(pathTick, 0, pathTick, 1, HISTORY - 1);
            path[0] = p;
            pathTick[0] = tick;
            count = Math.min(count + 1, HISTORY);
        }

        void resetPath() {
            count = 0;
        }

        boolean expired(long now) {
            // Пока летит — не удалять: иначе запись пересоздаётся каждый тик, last всегда пуст,
            // смещение всегда 0 и визуал никогда не включается (так и было).
            if (flying || presence > 0.0F || active) return false;
            return count == 0 || (now - pathTick[0]) / 20.0F > WAKE_LIFE;
        }
    }

    record Boom(Vec3 pos, Vec3 dir, int stage, long tick, boolean own, float seed) {}

    static final Map<Integer, Flier> FLIERS = new HashMap<>();
    static final List<Boom> BOOMS = new ArrayList<>();
    static FlightFx effect;


    private FlightFxTracker() {}

    /** С этой скорости Invincible визуал начинается… */
    static final double FS_START = 3.0;
    /** …и на этой достигает полной силы. */
    static final double FS_FULL = 9.0;

    /**
     * «Визуальная скорость», по которой подобран весь визуал, блоков/тик: 4 на
     * flightSpeed 3, 13 (прежний максимум, бывший на 12) — уже на 9 и выше.
     * Шкала сжата: начинается с 3, полный эффект — на 9.
     */
    public static double visualSpeed(double flightSpeed) {
        double t = Mth.clamp((flightSpeed - FS_START) / (FS_FULL - FS_START), 0.0, 1.0);
        return 4.0 + 9.0 * t;
    }

    /** Летит ли игрок по-настоящему быстро сейчас (по замеру, с гистерезисом). */
    public static boolean isFast(int entityId) {
        Flier f = FLIERS.get(entityId);
        return f != null && f.active;
    }

    /** Ступени звукового удара на сжатой шкале: 3, 5, 7, 9. */
    static int stageOf(double flightSpeed) {
        if (flightSpeed >= 9.0) return 4;
        if (flightSpeed >= 7.0) return 3;
        if (flightSpeed >= 5.0) return 2;
        if (flightSpeed >= 3.0) return 1;
        return 0;
    }

    /**
     * Реальный быстрый полёт Invincible (ветка со спринтом) — ~(1 + flightSpeed)
     * блоков/тик: в логе 4.0 на 3, 9.4 на 9, 12.9 на 12. Без спринта игрок летит
     * медленно, 0.3–0.6 блока/тик, — это не полёт на скорости, визуала нет.
     * Включается выше 2.5, гаснет ниже 1.5 (чтобы не мигало на границе).
     */
    static final double ON_SPEED = 2.5;
    static final double OFF_SPEED = 1.5;

    static Vec3 centre(Entity e, float partial) {
        return e.getPosition(partial).add(0.0, e.getBbHeight() * 0.5, 0.0);
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.isPaused()) return;
        ClientLevel level = mc.level;
        if (level == null) {
            clear();
            return;
        }
        long now = level.getGameTime();
        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
        Entity cameraEntity = mc.getCameraEntity();

        for (Flier f : FLIERS.values()) {
            f.active = false;
            f.flying = false;
        }
        List<Integer> seen = new ArrayList<>();

        for (AbstractClientPlayer p : level.players()) {
            if (p.position().distanceToSqr(cam) > RANGE * RANGE) continue;
            boolean dashing = KineticStrikeClient.isDashing(p.getId());
            double flightSpeed = 0.0;
            boolean flying = false;
            try {
                InvincibleIncModVariables.PlayerVariables v = p.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                flightSpeed = v.flightSpeed;
                flying = v.elytraflighton && !p.onGround() && v.flightSpeed >= 3.0;
            } catch (Exception ignored) {}
            flying |= dashing;

            Flier f = FLIERS.get(p.getId());
            if (f == null) {
                if (!flying) continue;
                f = new Flier(p.getId());
                FLIERS.put(p.getId(), f);
            }
            seen.add(p.getId());

            Vec3 c = centre(p, 1.0F);
            Vec3 delta = f.last == null ? Vec3.ZERO : c.subtract(f.last);
            double moved = delta.length();
            if (moved > TELEPORT) {
                f.resetPath();
                delta = Vec3.ZERO;
                moved = 0.0;
            }
            f.last = c;
            f.speed = f.speed * 0.5 + moved * 0.5;
            if (moved > 1.0E-3) {
                f.velocity = f.velocity.lerp(delta, 0.6);
                if (f.velocity.lengthSqr() > 1.0E-6) f.dir = f.velocity.normalize();
            }
            f.flightSpeed = flightSpeed;
            f.nominal = dashing ? 13.0 : visualSpeed(flightSpeed);
            // летит и действительно движется (не висит на месте)
            f.flying = flying;
            f.active = flying && f.speed > (f.wasActive ? OFF_SPEED : ON_SPEED);
            f.wasActive = f.active;

            float target = f.active ? 1.0F : 0.0F;
            f.presence = approach(f.presence, target, f.active ? 0.25F : 0.1F);
            float wakeTarget = f.active ? (float) smooth((f.nominal - 3.0) / 3.0) : 0.0F;
            f.wake = approach(f.wake, wakeTarget, wakeTarget > f.wake ? 0.2F : 1.0F / 32.0F);

            int stage = f.active ? (dashing ? 3 : stageOf(flightSpeed)) : 0;
            if (stage > f.stage || (dashing && !f.dashing && f.active)) {
                addBoom(new Boom(c, f.dir, Math.max(stage, 1), now, p == cameraEntity, f.seed + now * 0.013F));
                f.boomTick = now;
            }
            f.stage = stage;
            f.dashing = dashing && f.active;

            if (f.active && (now % SAMPLE_EVERY == 0 || f.count == 0)) f.push(c, now);
        }

        Iterator<Map.Entry<Integer, Flier>> it = FLIERS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Flier> e = it.next();
            Flier f = e.getValue();
            if (!seen.contains(e.getKey())) {
                // ушёл из виду или из мира — догорает только уже оставленное
                f.active = false;
                f.presence = approach(f.presence, 0.0F, 0.1F);
                f.wake = approach(f.wake, 0.0F, 1.0F / 32.0F);
            }
            if (f.expired(now)) it.remove();
        }
        BOOMS.removeIf(b -> now - b.tick() > BOOM_TICKS);

        if ((!FLIERS.isEmpty() || !BOOMS.isEmpty()) && effect == null) {
            effect = new FlightFx(level);
            FxManager.add(effect);
        }
    }

    private static void addBoom(Boom boom) {
        while (BOOMS.size() >= MAX_BOOMS) BOOMS.remove(0);
        BOOMS.add(boom);
        FxManager.shake(boom.pos(), 0.08F * boom.stage(), 140.0);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        clear();
    }

    static void clear() {
        FLIERS.clear();
        BOOMS.clear();
    }

    /** Нагрев для шейдера — тот же, что у свечения модели (SupersonicHeatManager), чтобы плазма и тело грелись вместе. */
    static float heat(Entity e) {
        return e == null ? 0.0F : SupersonicHeatManager.getHeat(e.getUUID());
    }

    static float approach(float v, float target, float step) {
        return v < target ? Math.min(target, v + step) : Math.max(target, v - step);
    }

    static double smooth(double x) {
        x = Mth.clamp(x, 0.0, 1.0);
        return x * x * (3.0 - 2.0 * x);
    }
}
