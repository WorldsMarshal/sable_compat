package com.invfix.spacefold;

import com.invfix.spacefold.client.SpaceFoldClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Угол Space Fold в обе стороны: клиент → сервер — сохранить из меню; сервер → клиент — сохранённый (при входе). */
public record SpaceFoldSettingsPacket(double angle) implements CustomPacketPayload {

    public static final Type<SpaceFoldSettingsPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "space_fold_settings"));

    public static final StreamCodec<FriendlyByteBuf, SpaceFoldSettingsPacket> STREAM_CODEC = StreamCodec.of(
            (buf, m) -> buf.writeDouble(m.angle()),
            buf -> new SpaceFoldSettingsPacket(buf.readDouble()));

    @Override
    public Type<SpaceFoldSettingsPacket> type() {
        return TYPE;
    }

    public static void handleServer(SpaceFoldSettingsPacket p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer player) new SpaceFoldSettings(p.angle).save(player);
        });
    }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(SpaceFoldSettingsPacket p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> SpaceFoldClient.setSettings(new SpaceFoldSettings(p.angle)));
    }
}
