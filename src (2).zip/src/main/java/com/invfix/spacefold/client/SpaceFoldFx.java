package com.invfix.spacefold.client;

import com.invfix.fx.FxEffect;
import com.invfix.fx.FxFrame;
import com.invfix.fx.FxManager;
import com.invfix.fx.FxPass;
import com.invfix.fx.FxScreen;
import com.invfix.spacefold.SpaceFoldShape;
import com.invfix.spacefold.SpaceFoldSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.List;

/**
 * Space Fold на клиенте (space_fold.fsh) — у всех игроков измерения: разлом
 * видно за километры.
 *
 * Таймлайн, тиков от нажатия ({@link SpaceFoldShape}):
 *  0–6    разрыв: ослепительный шов бежит по линии на 3 км, по кадру расходятся
 *         трещины, картинка дрожит;
 *  6–26   разлом раскрыт: половины мира расходятся клином (у разрывающего —
 *         кадр буквально расслаивается по линии), сдвигаются вдоль линии в
 *         разные стороны, между ними пустота; края горят и искрят, вокруг —
 *         осколки кадра, часть выпала в пустоту; цвета расслаиваются; мир
 *         тускнеет, края кадра темнеют фиолетовым, всё мелко трясётся;
 *  26     схлопывание: импакт-кадры (негатив, контуры, чёрно-белые), вспышка и
 *         выжженный послеобраз, линия горит белым, от плоскости по земле бежит
 *         ударная полоса, сильная тряска;
 *  …220   шрам: разрез светится по земле до горизонта, шов в воздухе гаснет.
 *
 * Звуки (SpaceFoldSounds) слышны во всём измерении — громкость от расстояния до
 * линии разлома (не тише 30 % за 3 км). Частицы — только в 160 блоках от камеры:
 * пока разлом раскрыт, в щель тянет фиолетовую пыль и искры; при схлопывании по
 * линии — звуковые удары (кольца) и взрывы; потом из разреза поднимается дым.
 */
@OnlyIn(Dist.CLIENT)
public final class SpaceFoldFx extends FxEffect {

    /** Полураскрытие клина (тангенс): у разрывающего щель ≈ 11° поперёк кадра. */
    private static final float K_OPEN = 0.1F;
    /** Сдвиг каждой половины вдоль линии (тангенс). */
    private static final float SLIDE = 0.06F;
    /** Импакт-кадры и вспышка — ближе этого к линии разлома (или своему разлому), блоков. */
    private static final double FRAMES_RANGE = 1500.0;

    private final ClientLevel level;
    private final Vec3 eye;
    private final Vec3 f;
    private final Vec3 u;
    private final float seed;
    private final boolean mine;
    private boolean shook;

    private SpaceFoldFx(ClientLevel level, Vec3 eye, Vec3 f, Vec3 u, float seed, boolean mine) {
        this.level = level;
        this.eye = eye;
        this.f = f;
        this.u = u;
        this.seed = seed;
        this.mine = mine;
    }

    public static void start(int casterId, double x, double y, double z, float fx, float fy, float fz,
                             float ux, float uy, float uz, float seed) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        boolean mine = mc.player != null && mc.player.getId() == casterId;
        FxManager.add(new SpaceFoldFx(level, new Vec3(x, y, z), new Vec3(fx, fy, fz).normalize(),
                new Vec3(ux, uy, uz).normalize(), seed, mine));
    }

    // ── звук и частицы ─────────────────────────────────────────────────────

    /** Слышимость звука разлома, блоков от линии: дальше — тишина. */
    private static final float SOUND_RANGE = 4000.0F;

    /**
     * Звук — так же, как остальные звуки мода (HeatDisruptionFx): из точки, с
     * линейным затуханием на volume × 16 = 256 блоков. Источник стоит в стороне
     * линии разлома (слышно, откуда), но не дальше 216 блоков от слушателя:
     * у самой линии — в 16 блоках (почти полная громкость), чем дальше линия, тем
     * дальше источник — до ~45 % громкости за 4 км.
     */
    private void play(SoundEvent event) {
        Minecraft mc = Minecraft.getInstance();
        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
        Vec3 line = nearestOnLine(cam);
        double dist = cam.distanceTo(line);
        double far = Mth.clamp(dist / SOUND_RANGE, 0.0, 1.0);
        double reach = 16.0 + 200.0 * far;
        Vec3 at = dist > reach ? cam.add(line.subtract(cam).normalize().scale(reach)) : line;
        mc.getSoundManager().play(new SimpleSoundInstance(event.getLocation(), SoundSource.PLAYERS,
                16.0F, 1.0F, SoundInstance.createUnseededRandom(), false, 0,
                SoundInstance.Attenuation.LINEAR, at.x, at.y, at.z, false));
    }

    private float near() {
        Vec3 cam = FxManager.camera();
        return (float) Mth.clamp(1.0 - cam.distanceTo(nearestOnLine(cam)) / 3000.0, 0.3, 1.0);
    }

    @Override
    protected void onTick(Minecraft minecraft, ClientLevel level, int t) {
        if (t == 0) play(SpaceFoldSounds.TEAR.get());
        if (t == SpaceFoldShape.SNAP) play(SpaceFoldSounds.SNAP.get());
        particles(level, t);
    }

    /** Точка разлома: s вдоль взгляда, a вдоль линии, d от плоскости. */
    private Vec3 at(double s, double a, double d) {
        Vec3 n = f.cross(u).normalize();
        return eye.add(f.scale(s)).add(u.scale(a)).add(n.scale(d));
    }

    private void particles(ClientLevel level, int t) {
        Vec3 cam = FxManager.camera();
        Vec3 n = f.cross(u).normalize();
        double sc = Mth.clamp(cam.subtract(eye).dot(f), SpaceFoldShape.CLEAR, SpaceFoldShape.LENGTH);
        if (cam.distanceTo(nearestOnLine(cam)) > 400.0) return;
        double s0 = Math.max(SpaceFoldShape.CLEAR + 1.0, sc - 160.0), s1 = Math.min(SpaceFoldShape.LENGTH, sc + 160.0);
        if (s1 <= s0) return;
        RandomSource r = level.random;
        int snap = SpaceFoldShape.SNAP;
        float k = K_OPEN * open(t);
        if (t >= SpaceFoldShape.TEAR_END && t < snap) {
            // пыль и искры тянет в щель с обеих сторон
            for (int i = 0; i < 48; i++) {
                double s = s0 + r.nextDouble() * (s1 - s0);
                double span = Math.min(SpaceFoldShape.SPAN * s, 96.0);
                double a = (r.nextDouble() * 2.0 - 1.0) * span;
                double side = r.nextBoolean() ? 1.0 : -1.0;
                double d = side * (k * s + 1.0 + r.nextDouble() * 6.0);
                Vec3 p = at(s, a, d);
                Vec3 v = n.scale(-side * (0.15 + r.nextDouble() * 0.25));
                level.addParticle(i % 3 == 0 ? ParticleTypes.END_ROD : ParticleTypes.REVERSE_PORTAL,
                        p.x, p.y, p.z, v.x, v.y, v.z);
            }
        } else if (t == snap) {
            // по линии — кольца звукового удара и взрывы
            for (double s = s0; s <= s1; s += 8.0) {
                Vec3 p = at(s, (r.nextDouble() * 2.0 - 1.0) * Math.min(SpaceFoldShape.SPAN * s, 48.0), 0.0);
                level.addParticle(ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 0.0, 0.0, 0.0);
                if (r.nextInt(3) == 0) level.addParticle(ParticleTypes.EXPLOSION, p.x, p.y, p.z, 0.0, 0.0, 0.0);
            }
        } else if (t > snap && t < snap + 80) {
            // из разреза поднимается дым, искры гаснут
            int count = t < snap + 20 ? 24 : 8;
            for (int i = 0; i < count; i++) {
                double s = s0 + r.nextDouble() * (s1 - s0);
                double a = (r.nextDouble() * 2.0 - 1.0) * Math.min(SpaceFoldShape.SPAN * s, 96.0);
                Vec3 p = at(s, a, (r.nextDouble() * 2.0 - 1.0) * SpaceFoldShape.WIDTH * 0.5);
                if (i % 4 == 0) {
                    level.addParticle(ParticleTypes.END_ROD, p.x, p.y, p.z,
                            (r.nextDouble() - 0.5) * 0.1, 0.05 + r.nextDouble() * 0.1, (r.nextDouble() - 0.5) * 0.1);
                } else {
                    level.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE, p.x, p.y, p.z, 0.0, 0.04, 0.0);
                }
            }
        }
    }

    @Override
    protected int duration() {
        return SpaceFoldShape.END;
    }

    @Override
    public boolean finished() {
        return super.finished() || Minecraft.getInstance().level != level;
    }

    @Override
    public Vec3 focus() {
        return nearestOnLine(FxManager.camera());
    }

    @Override
    public double range() {
        return SpaceFoldShape.LENGTH + 2000.0;
    }

    /** Ближайшая к точке точка линии разлома (оси взгляда от CLEAR до LENGTH). */
    private Vec3 nearestOnLine(Vec3 p) {
        double s = Mth.clamp(p.subtract(eye).dot(f), SpaceFoldShape.CLEAR, SpaceFoldShape.LENGTH);
        return eye.add(f.scale(s));
    }

    // ── таймлайн ───────────────────────────────────────────────────────────

    private float open(float t) {
        return smooth((t - SpaceFoldShape.TEAR_END) / 4.0F)
                * (1.0F - smooth((t - SpaceFoldShape.SNAP + 1.5F) / 1.5F));
    }

    @Override
    public void passes(FxFrame frame, List<FxPass> out) {
        float t = ticks(frame);
        float seconds = t / 20.0F;
        float open = open(t);
        float k = K_OPEN * open * (1.0F + 0.06F * (float) Math.sin(t * 2.3F));
        float slide = SLIDE * open * smooth((t - SpaceFoldShape.TEAR_END) / 8.0F);
        float tear = Mth.clamp(t / SpaceFoldShape.TEAR_END, 0.0F, 1.0F);
        float seamTip = (float) (SpaceFoldShape.CLEAR + (SpaceFoldShape.LENGTH - SpaceFoldShape.CLEAR) * tear * tear);
        float seamK = window(t, 0.0F, 0.5F, SpaceFoldShape.SNAP + 2.0F, SpaceFoldShape.SNAP + 6.0F);
        int snap = SpaceFoldShape.SNAP;
        float blaze = window(t, snap - 1.5F, snap, snap + 1.0F, snap + 10.0F);
        float since = (t - snap) / 20.0F;
        float shockR = t >= snap ? 320.0F * (1.0F - (float) Math.exp(-since / 0.6F)) : 0.0F;
        float shockK = t >= snap ? (float) Math.exp(-since / 1.5F) : 0.0F;
        float scar = window(t, snap, snap + 1.0F, snap + 40.0F, SpaceFoldShape.END);
        float shards = Math.max(window(t, 2.0F, 8.0F, snap - 1.0F, snap + 2.0F),
                0.6F * window(t, snap, snap + 0.5F, snap + 6.0F, snap + 16.0F));
        float cracks = window(t, 3.0F, 10.0F, snap + 10.0F, snap + 80.0F);
        // небо гаснет до ночи со звёздами, пока пространство разорвано
        float dark = Math.max(open, 0.5F * window(t, 0.0F, 3.0F, SpaceFoldShape.TEAR_END, SpaceFoldShape.TEAR_END + 2.0F))
                * near();

        Vec3 target = frame.rel(eye);
        Vec3 ff = f, uu = u;
        float sd = seed;
        float length = (float) SpaceFoldShape.LENGTH, span = (float) SpaceFoldShape.SPAN,
                clear = (float) SpaceFoldShape.CLEAR;
        out.add(new FxPass("space_fold", p -> {
            p.v3("Target", target);
            p.v3("Facing", ff);
            p.v3("Caster", uu);
            p.f4("P0", seconds, sd, k, slide);
            p.f4("P1", seamTip, seamK, blaze, shockR);
            p.f4("P2", length, span, clear, scar);
            p.f4("P3", shards, cracks, shockK, dark);
        }));
    }

    @Override
    public void screen(FxFrame frame, FxScreen screen) {
        float t = ticks(frame);
        Vec3 cam = frame.camera();
        Vec3 line = nearestOnLine(cam);
        double dist = cam.distanceTo(line);
        float near = (float) Mth.clamp(1.0 - dist / 3000.0, 0.3, 1.0);
        float open = open(t);
        int snap = SpaceFoldShape.SNAP;

        // разрыв и раскрытие: кадр дрожит, цвета расслаиваются, края темнеют фиолетовым
        float tearing = window(t, 0.0F, 2.0F, SpaceFoldShape.TEAR_END, snap);
        screen.aberration = Math.max(screen.aberration, (0.5F * tearing + 0.9F * open) * near);
        screen.zoomBlur = Math.max(screen.zoomBlur, (0.25F * window(t, 0.0F, 1.0F, 4.0F, 8.0F) + 0.12F * open) * near);
        screen.shake = Math.max(screen.shake, (0.3F * tearing + 0.35F * open) * near);
        screen.addVignette(0x14062A, 0.55F * open * near);
        screen.desaturate = Math.max(screen.desaturate, 0.3F * open * near);
        screen.bloom = Math.max(screen.bloom, 1.0F * Math.max(open, tearing) * near);
        screen.bloomRadius = Math.max(screen.bloomRadius, 1.3F);

        if (t >= snap) {
            float since = (t - snap) / 20.0F;
            if (!shook) {
                shook = true;
                FxManager.shake(line, 0.9F, 3000.0);
            }
            boolean close = mine || dist < FRAMES_RANGE;
            if (close) {
                // негатив, белые контуры, чёрно-белые — семь кадров по 0.05 с
                impactSequence(screen, since, line, 1.0F, 0.05F, 6, 37, 6, 41, 36, 6, 40);
                if (since >= 0.35F) {
                    screen.addFlash(0xF4EEFF, 1.5F * (float) Math.exp(-(since - 0.35F) / 0.25F) * near);
                }
                if (since >= 0.35F && since < 0.5F) screen.capture = 1.0F;
                screen.afterimage = Math.max(screen.afterimage, window(since, 0.35F, 0.37F, 0.8F, 3.0F) * 0.5F * near);
            }
            screen.shake = Math.max(screen.shake, window(since, 0.0F, 0.05F, 1.0F, 3.0F) * near);
            screen.aberration = Math.max(screen.aberration, window(since, 0.0F, 0.05F, 0.6F, 2.5F) * 1.5F * near);
            screen.zoomBlur = Math.max(screen.zoomBlur, window(since, 0.0F, 0.03F, 0.3F, 1.2F) * 0.7F * near);
            screen.bloom = Math.max(screen.bloom, window(since, 0.0F, 0.05F, 1.0F, 4.0F) * 1.2F * near);
        }
    }
}
