package com.invfix.spacefold.client;

import com.invfix.spacefold.SpaceFoldSettings;
import com.mojang.math.Axis;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

/**
 * Меню Space Fold (Shift + клавиша способности): угол плоскости разлома — круг
 * с самим разломом, его тянут мышью; он ляжет на экране так же (0° —
 * горизонтально, 90° — вертикально, плюс — против часовой). Колесо — по 1°, с
 * Shift — 15°. Enter / «Сохранить» — сохранить; Esc / «Отмена» — без изменений.
 */
@OnlyIn(Dist.CLIENT)
public final class SpaceFoldScreen extends Screen {

    private static final int W = 270, H = 236;
    private static final int DIAL_R = 76;
    private static final int PANEL = 0xF00C0A12, FRAME = 0xFF3A2C52, ACCENT = 0xFFEDE6FF, MUTED = 0xFF9A90B2;
    private static final int DIAL_BG = 0xFF1A1426, DIAL_RING = 0xFF5B4A82, TICK = 0xFF3E3358;

    private double angle;
    private boolean dragging;
    private int left, top, cx, cy;

    public SpaceFoldScreen(SpaceFoldSettings current) {
        super(Component.literal("Space Fold"));
        this.angle = current.angle();
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        cx = left + 18 + DIAL_R;
        cy = top + 34 + DIAL_R;
        int fx = left + W - 92;
        addRenderableWidget(Button.builder(Component.literal("Сохранить"), b -> saveAndClose())
                .bounds(fx, top + H - 52, 80, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Отмена"), b -> onClose())
                .bounds(fx, top + H - 30, 80, 18).build());
    }

    private void saveAndClose() {
        SpaceFoldClient.save(new SpaceFoldSettings(angle));
        onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private boolean overDial(double mx, double my) {
        return Mth.square(mx - cx) + Mth.square(my - cy) <= Mth.square(DIAL_R + 8);
    }

    private void aimAt(double mx, double my) {
        double a = Math.toDegrees(Math.atan2(cy - my, mx - cx));
        if (a > 90.0) a -= 180.0;
        if (a <= -90.0) a += 180.0;
        if (hasShiftDown()) a = Math.round(a / 15.0) * 15.0;
        angle = Math.round(a);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && overDial(mx, my)) {
            dragging = true;
            aimAt(mx, my);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            aimAt(mx, my);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (overDial(mx, my) && scrollY != 0.0) {
            double a = angle + Math.signum(scrollY) * (hasShiftDown() ? 15.0 : 1.0);
            if (a > 90.0) a -= 180.0;
            if (a <= -90.0) a += 180.0;
            angle = a;
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            saveAndClose();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float partial) {
        super.renderBackground(g, mx, my, partial);
        g.fill(left - 1, top - 1, left + W + 1, top + H + 1, FRAME);
        g.fill(left, top, left + W, top + H, PANEL);
        g.fill(left, top, left + W, top + 22, 0xF0181226);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        super.render(g, mx, my, partial);
        g.drawString(font, "SPACE FOLD  ·  плоскость разлома", left + 10, top + 7, ACCENT, false);
        int fx = left + W - 92;
        g.drawString(font, "Разлом ляжет", fx, top + 40, MUTED, false);
        g.drawString(font, "на экране так,", fx, top + 51, MUTED, false);
        g.drawString(font, "как в круге.", fx, top + 62, MUTED, false);
        g.drawString(font, "0° — гориз.", fx, top + 80, MUTED, false);
        g.drawString(font, "90° — верт.", fx, top + 91, MUTED, false);
        drawDial(g, mx, my);
        g.drawCenteredString(font, String.format(Locale.ROOT, "Угол: %+d°", (int) Math.round(angle)),
                cx, cy + DIAL_R + 8, ACCENT);
        g.drawCenteredString(font, "тяни мышью · колесо ±1° · Shift — 15°", cx, cy + DIAL_R + 20, MUTED);
    }

    private void drawDial(GuiGraphics g, int mx, int my) {
        int r = DIAL_R;
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.round(Math.sqrt(r * r - dy * dy));
            g.fill(cx - half, cy + dy, cx + half, cy + dy + 1, DIAL_BG);
        }
        for (int i = 0; i < 360; i++) {
            double a = Math.toRadians(i);
            int x = (int) Math.round(cx + Math.cos(a) * (r + 1));
            int y = (int) Math.round(cy - Math.sin(a) * (r + 1));
            g.fill(x, y, x + 1, y + 1, DIAL_RING);
        }
        for (int deg = 0; deg < 360; deg += 15) {
            double a = Math.toRadians(deg);
            int len = deg % 90 == 0 ? 8 : deg % 45 == 0 ? 6 : 3;
            for (int k = 0; k < len; k++) {
                int x = (int) Math.round(cx + Math.cos(a) * (r - 2 - k));
                int y = (int) Math.round(cy - Math.sin(a) * (r - 2 - k));
                g.fill(x, y, x + 1, y + 1, TICK);
            }
        }
        // сам разлом: чёрная щель с бело-фиолетовой кромкой во весь круг
        var pose = g.pose();
        pose.pushPose();
        pose.translate(cx, cy, 0.0F);
        pose.mulPose(Axis.ZP.rotationDegrees((float) -angle));
        int half = r - 4;
        g.fill(-half, -5, half, 5, 0x40B48CFF);
        g.fill(-half, -3, half, 3, 0xFFF0E8FF);
        g.fill(-half, -2, half, 2, 0xFF020104);
        pose.popPose();

        double ar = Math.toRadians(angle);
        int hx = (int) Math.round(cx + Math.cos(ar) * (r - 4));
        int hy = (int) Math.round(cy - Math.sin(ar) * (r - 4));
        boolean hot = dragging || overDial(mx, my);
        g.fill(hx - 3, hy - 3, hx + 4, hy + 4, hot ? 0xFFFFFFFF : 0xFFBDB2D6);
        g.fill(hx - 2, hy - 2, hx + 3, hy + 3, 0xFF0C0A12);
    }
}
