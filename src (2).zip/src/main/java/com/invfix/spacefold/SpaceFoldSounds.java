package com.invfix.spacefold;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Звуки Space Fold — из The Shooting Star 1.2.0 с добавленным басом (под-октава
 * ниже 160 Гц и подъём низов, ограничитель):
 *  - space_fold/tear — star_collapse, разрыв;
 *  - space_fold/snap — gungnir_boom, схлопывание.
 */
public final class SpaceFoldSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, "sable_compat");

    public static final DeferredHolder<SoundEvent, SoundEvent> TEAR = SOUNDS.register("space_fold_tear",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("sable_compat", "space_fold_tear")));
    public static final DeferredHolder<SoundEvent, SoundEvent> SNAP = SOUNDS.register("space_fold_snap",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("sable_compat", "space_fold_snap")));

    private SpaceFoldSounds() {}
}
