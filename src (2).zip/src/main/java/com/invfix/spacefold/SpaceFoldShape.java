package com.invfix.spacefold;

import net.minecraft.world.phys.Vec3;

/**
 * Геометрия и таймлайн Space Fold — общие для сервера и клиента.
 *
 * Плоскость разлома проходит через глаза разрывающего, его взгляд f и линию u на
 * экране под выбранным углом; n = f × u — её нормаль. Точка мира в координатах
 * разлома: s — вдоль взгляда, a — вдоль линии, d — от плоскости.
 *
 * Разлом начинается в {@link #CLEAR} блоках от глаз и уходит на {@link #LENGTH};
 * поперёк — на {@link #SPAN}·s в обе стороны (весь кадр разрывающего).
 */
public final class SpaceFoldShape {

    /** Ближе этого к глазам разлома нет, блоков. */
    public static final double CLEAR = 3.0;
    /** Длина разлома вдоль взгляда, блоков. */
    public static final double LENGTH = 3000.0;
    /** Полуширина разлома поперёк взгляда — доля расстояния (≈ ±80°, весь кадр; вдвое выше прежних 3). */
    public static final double SPAN = 6.0;

    /** Тики от нажатия: разрыв бежит по линии до {@link #TEAR_END}, раскрыт — до {@link #SNAP}, там схлопывается. */
    public static final int TEAR_END = 6;
    public static final int SNAP = 26;
    /** Визуальные последствия — до этого тика. */
    public static final int END = 220;

    /** Блоки: вырез шириной WIDTH по плоскости, за ним с плюсовой стороны — пласт глубиной DEPTH, сдвинутый на SHIFT вдоль линии. */
    public static final double WIDTH = 8.0;
    public static final double DEPTH = 10.0;
    public static final double SHIFT = 6.0;
    /** Поперёк взгляда блоки трогаются не дальше этого от линии взгляда, блоков. */
    public static final double BLOCK_SPAN = 128.0;

    private SpaceFoldShape() {}

    /** Линия разлома на экране: вправо по экрану с поворотом на angle против часовой. */
    public static Vec3 lineDir(Vec3 f, float yRot, double angleDeg) {
        double yaw = Math.toRadians(yRot);
        Vec3 right = new Vec3(-Math.cos(yaw), 0.0, -Math.sin(yaw));
        Vec3 up = right.cross(f);
        if (up.lengthSqr() < 1.0E-6) up = new Vec3(0.0, 1.0, 0.0);
        up = up.normalize();
        right = f.cross(up).normalize();
        double a = Math.toRadians(angleDeg);
        return right.scale(Math.cos(a)).add(up.scale(Math.sin(a))).normalize();
    }
}
