package com.invfix.spacefold;

import com.invfix.altrumite.AltrumiteRace;
import net.mcreator.invincibleinc.init.InvincibleIncModGameRules;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Space Fold — Metroman (Alien(Metroman)), LVL {@link #LVL_REQUIRED}.
 *
 * Не удар, а разрыв пространства: по линии взгляда, в плоскости под углом из
 * меню (Shift + клавиша — круг, как у Dismantle), мир расходится на две
 * половины, между ними чёрная пустота. Таймлайн (тики от нажатия,
 * {@link SpaceFoldShape}): 0–6 разрыв бежит по линии на 3 км, 6–26 разлом
 * раскрыт, на 26-м всё схлопывается обратно:
 *  - всё живое на линии разлома (|d| до половины ширины выреза) по всей длине —
 *    Attackpwr × {@link #DAMAGE_MULT} разрывающего; тех, кто в сдвинутом пласте, сдвигает вместе
 *    с ним;
 *  - блоки ({@link SpaceFoldCarver}): вырез шириной 8 по плоскости, за ним с
 *    одной стороны пласт глубиной 10, сдвинутый на 6 блоков вдоль линии, —
 *    волной от разрывающего на все 3 км; чанки по линии догружаются.
 *
 * Картинка — у всех игроков измерения (SpaceFoldFx). Пока разлом не схлопнулся
 * и ещё секунду после — новый не открыть.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class SpaceFoldHandler {

    public static final String ABILITY = "§5§lSpace Fold";
    public static final int LVL_REQUIRED = 1000;
    private static final int REARM_AFTER_SNAP = 20;
    /** Урон = Attackpwr × этот множитель. */
    public static final double DAMAGE_MULT = 30.0;

    private static final ResourceKey<DamageType> DAMAGE = ResourceKey.create(Registries.DAMAGE_TYPE,
            ResourceLocation.parse("sable_compat:space_fold"));

    private static final class Fold {
        final ServerLevel level;
        final UUID caster;
        final Vec3 eye, f, u, n;
        final boolean carve;
        int age;

        Fold(ServerLevel level, UUID caster, Vec3 eye, Vec3 f, Vec3 u, boolean carve) {
            this.level = level;
            this.caster = caster;
            this.eye = eye;
            this.f = f;
            this.u = u;
            this.n = f.cross(u).normalize();
            this.carve = carve;
        }
    }

    private static final Map<UUID, Fold> FOLDS = new ConcurrentHashMap<>();
    private static final List<SpaceFoldCarver> CARVERS = new ArrayList<>();
    private static final Map<UUID, Long> HELD = new ConcurrentHashMap<>();

    private SpaceFoldHandler() {}

    public static boolean eligible(ServerPlayer player) {
        try {
            InvincibleIncModVariables.PlayerVariables v = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            return AltrumiteRace.isAltrumite(v.Race) && v.Lvl >= LVL_REQUIRED;
        } catch (Exception e) {
            return false;
        }
    }

    // ── нажатие (AbilityCallProcedureMixin, каждый тик, пока клавиша зажата) ──

    public static void onKeyHeld(ServerPlayer player) {
        long now = player.level().getGameTime();
        Long last = HELD.put(player.getUUID(), now);
        if (last != null && now - last <= 1) return; // то же нажатие
        if (player.isShiftKeyDown()) return;         // Shift — меню угла на клиенте
        if (FOLDS.containsKey(player.getUUID())) return;
        if (!eligible(player)) return;
        ServerLevel level = (ServerLevel) player.level();
        Vec3 look = player.getLookAngle();
        if (look.lengthSqr() < 1.0E-6) return;
        Vec3 f = look.normalize();
        Vec3 u = SpaceFoldShape.lineDir(f, player.getYRot(), SpaceFoldSettings.of(player).angle());
        Vec3 eye = player.getEyePosition();
        boolean carve = level.getGameRules().getBoolean(InvincibleIncModGameRules.INVINCIBLE_BLOCK_DESTRUCTION);
        FOLDS.put(player.getUUID(), new Fold(level, player.getUUID(), eye, f, u, carve));
        float seed = (float) (level.random.nextInt(65536) / 65535.0);
        PacketDistributor.sendToPlayersInDimension(level, new SpaceFoldPacket(player.getId(), eye.x, eye.y, eye.z,
                (float) f.x, (float) f.y, (float) f.z, (float) u.x, (float) u.y, (float) u.z, seed));
    }

    // ── тик ────────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (!FOLDS.isEmpty()) {
            Iterator<Map.Entry<UUID, Fold>> it = FOLDS.entrySet().iterator();
            while (it.hasNext()) {
                Fold fold = it.next().getValue();
                if (fold.level != level) continue;
                int age = fold.age++;
                if (age == SpaceFoldShape.SNAP) {
                    try {
                        snap(fold);
                    } catch (Exception ignored) {}
                }
                if (age >= SpaceFoldShape.SNAP + REARM_AFTER_SNAP) it.remove();
            }
        }
        if (!CARVERS.isEmpty()) {
            Iterator<SpaceFoldCarver> it = CARVERS.iterator();
            while (it.hasNext()) {
                SpaceFoldCarver c = it.next();
                if (c.level != level) continue;
                try {
                    c.tick();
                } catch (Exception e) {
                    c.release();
                }
                if (c.finished()) it.remove();
            }
        }
    }

    /** Схлопывание: урон всему на линии, сдвиг тех, кто в сдвинутом пласте, и блоки. */
    private static void snap(Fold fold) {
        ServerLevel level = fold.level;
        ServerPlayer caster = level.getServer().getPlayerList().getPlayer(fold.caster);
        double ap = 0.0;
        if (caster != null) {
            try {
                ap = caster.getData(InvincibleIncModVariables.PLAYER_VARIABLES).attackPower;
            } catch (Exception ignored) {}
        }
        float damage = (float) Math.min(ap * DAMAGE_MULT, Float.MAX_VALUE);
        DamageSource source = new DamageSource(level.holderOrThrow(DAMAGE), caster);
        double half = SpaceFoldShape.WIDTH * 0.5;
        Vec3 shift = fold.u.scale(SpaceFoldShape.SHIFT);

        List<LivingEntity> hit = new ArrayList<>();
        List<Entity> moved = new ArrayList<>();
        for (Entity e : level.getAllEntities()) {
            if (e == caster || e.isRemoved()) continue;
            Vec3 q = e.getBoundingBox().getCenter().subtract(fold.eye);
            double s = q.dot(fold.f);
            if (s < SpaceFoldShape.CLEAR || s > SpaceFoldShape.LENGTH) continue;
            double a = q.dot(fold.u);
            if (Math.abs(a) > SpaceFoldShape.SPAN * s) continue;
            double d = q.dot(fold.n);
            double margin = Math.max(e.getBbWidth(), e.getBbHeight()) * 0.5;
            if (Math.abs(d) <= half + margin) {
                if (e instanceof LivingEntity le && le.isAlive()) hit.add(le);
            } else if (d > half && d <= half + SpaceFoldShape.DEPTH && Math.abs(a) <= SpaceFoldShape.BLOCK_SPAN) {
                if (!(e instanceof Player p) || !(p.isCreative() || p.isSpectator())) moved.add(e);
            }
        }
        if (damage > 0.0F) {
            for (LivingEntity le : hit) {
                le.invulnerableTime = 0;
                le.hurtTime = 0;
                le.hurt(source, damage);
            }
        }
        for (Entity e : moved) {
            e.teleportTo(e.getX() + shift.x, e.getY() + shift.y, e.getZ() + shift.z);
        }

        if (fold.carve) CARVERS.add(new SpaceFoldCarver(level, fold.eye, fold.f, fold.u, fold.n));
    }

    // ── настройка: за игроком, переживает смерть, приходит клиенту при входе ──

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            PacketDistributor.sendToPlayer(player, new SpaceFoldSettingsPacket(SpaceFoldSettings.of(player).angle()));
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        CompoundTag from = event.getOriginal().getPersistentData();
        if (from.contains(SpaceFoldSettings.NBT)) {
            event.getEntity().getPersistentData().put(SpaceFoldSettings.NBT, from.getCompound(SpaceFoldSettings.NBT).copy());
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        HELD.remove(event.getEntity().getUUID());
    }
}
