package com.invfix.spacefold;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ThreadedLevelLightEngine;
import net.minecraft.server.level.TicketType;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/**
 * Блоки Space Fold после схлопывания — волной от разрывающего по всей длине
 * разлома ({@link SpaceFoldShape#LENGTH}).
 *
 * Разлом режется отрезками по {@link #SEGMENT} блоков вдоль взгляда. В отрезке:
 *  - вырез: всё, что ближе {@link SpaceFoldShape#WIDTH}/2 к плоскости, — воздух;
 *  - сдвиг: пласт за вырезом с плюсовой стороны (до DEPTH от выреза)
 *    переписывается тем, что стояло на {@link SpaceFoldShape#SHIFT} блоков
 *    ниже по линии разлома, — половина мира съехала вдоль разлома;
 *  - поперёк взгляда — не дальше {@link SpaceFoldShape#BLOCK_SPAN} от линии
 *    взгляда (и не дальше SPAN·s, как и сам разлом).
 * Блоки пишутся прямо в секции (без обновлений соседей и дропа), потом
 * пересвет и свежий пакет чанка игрокам — как Carving у The Shooting Star.
 * Режется всё, бедрок тоже, и сдвигается тоже; не сдвигаются только блоки
 * с содержимым (сундуки и т.п.) — в вырезе они просто исчезают.
 *
 * Чанки по линии догружаются: на отрезки впереди ставится тикет (не больше
 * {@link #AHEAD} отрезков сразу), отрезок режется, когда все его чанки готовы,
 * или через {@link #WAIT} тиков — тем, что успело загрузиться. Работа за тик
 * ограничена {@link #SAMPLES_PER_TICK} пробами точек.
 */
final class SpaceFoldCarver {

    static final double SEGMENT = 8.0;
    private static final int AHEAD = 6;
    private static final int WAIT = 200;
    private static final int SAMPLES_PER_TICK = 240_000;
    private static final double STEP = 0.5;
    /** Не дольше этого вообще (5 минут) — дальше бросаем, тикеты снимаем. */
    private static final int MAX_AGE = 6000;

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final TicketType<ChunkPos> TICKET =
            TicketType.create("sable_compat:space_fold", Comparator.comparingLong(ChunkPos::toLong));

    final ServerLevel level;
    private final Vec3 eye, f, u, n;
    private final int vx, vy, vz;

    private final class Segment {
        final double s0, s1;
        final LongOpenHashSet chunks = new LongOpenHashSet();
        int waited;

        Segment(double s0, double s1) {
            this.s0 = s0;
            this.s1 = s1;
            // чанки отрезка: углы его объёма (с запасом на сдвиг) по сетке 8 блоков
            double aMax = Math.min(SpaceFoldShape.BLOCK_SPAN, SpaceFoldShape.SPAN * s1) + SpaceFoldShape.SHIFT;
            double dMin = -SpaceFoldShape.WIDTH * 0.5, dMax = SpaceFoldShape.WIDTH * 0.5 + SpaceFoldShape.DEPTH;
            for (double s = s0; s <= s1 + 1e-6; s += 4.0) {
                for (double a = -aMax; a <= aMax + 1e-6; a += 4.0) {
                    for (double d = dMin; d <= dMax + 1e-6; d += 4.0) {
                        Vec3 p = at(s, a, d);
                        if (p.y < level.getMinBuildHeight() - 8 || p.y > level.getMaxBuildHeight() + 8) continue;
                        chunks.add(ChunkPos.asLong(Mth.floor(p.x) >> 4, Mth.floor(p.z) >> 4));
                    }
                }
            }
        }

        boolean ready() {
            for (long c : chunks) {
                if (level.getChunkSource().getChunkNow(ChunkPos.getX(c), ChunkPos.getZ(c)) == null) return false;
            }
            return true;
        }

        void ticket(boolean add) {
            for (long c : chunks) {
                ChunkPos pos = new ChunkPos(c);
                if (add) level.getChunkSource().addRegionTicket(TICKET, pos, 1, pos);
                else level.getChunkSource().removeRegionTicket(TICKET, pos, 1, pos);
            }
        }
    }

    private final ArrayDeque<Segment> queue = new ArrayDeque<>();
    private double nextS = SpaceFoldShape.CLEAR;
    private int age;
    private boolean released;

    // работа над текущим отрезком (пробы разбиты по тикам)
    private Segment current;
    private final List<long[]> cut = new ArrayList<>();     // {pos}
    private final List<long[]> shifted = new ArrayList<>(); // {pos, src}
    private final LongOpenHashSet seen = new LongOpenHashSet();
    private double cursorS;

    SpaceFoldCarver(ServerLevel level, Vec3 eye, Vec3 f, Vec3 u, Vec3 n) {
        this.level = level;
        this.eye = eye;
        this.f = f;
        this.u = u;
        this.n = n;
        Vec3 v = u.scale(SpaceFoldShape.SHIFT);
        this.vx = (int) Math.round(v.x);
        this.vy = (int) Math.round(v.y);
        this.vz = (int) Math.round(v.z);
    }

    private Vec3 at(double s, double a, double d) {
        return eye.add(f.scale(s)).add(u.scale(a)).add(n.scale(d));
    }

    boolean finished() {
        return released;
    }

    void release() {
        if (released) return;
        released = true;
        if (current != null) current.ticket(false);
        for (Segment s : queue) s.ticket(false);
        queue.clear();
        current = null;
    }

    void tick() {
        if (released) return;
        if (++age > MAX_AGE) {
            release();
            return;
        }
        // тикеты на отрезки впереди
        while (queue.size() < AHEAD && nextS < SpaceFoldShape.LENGTH) {
            double s1 = Math.min(nextS + SEGMENT, SpaceFoldShape.LENGTH);
            Segment seg = new Segment(nextS, s1);
            seg.ticket(true);
            queue.add(seg);
            nextS = s1;
        }
        int budget = SAMPLES_PER_TICK;
        while (budget > 0) {
            if (current == null) {
                Segment head = queue.peek();
                if (head == null) {
                    if (nextS >= SpaceFoldShape.LENGTH) release();
                    return;
                }
                if (!head.ready() && head.waited++ < WAIT) return;
                current = queue.poll();
                // пробы с запасом в блок по краям; блок достаётся тому отрезку, где центр
                cursorS = current.s0 - 1.0;
                cut.clear();
                shifted.clear();
                seen.clear();
            }
            budget = sample(budget);
            if (cursorS >= current.s1 + 1.0) {
                apply();
                current.ticket(false);
                current = null;
            }
        }
    }

    /** Пробы точек отрезка слоями по s; возвращает остаток бюджета. */
    private int sample(int budget) {
        double half = SpaceFoldShape.WIDTH * 0.5;
        double dMax = half + SpaceFoldShape.DEPTH;
        int minY = level.getMinBuildHeight(), maxY = level.getMaxBuildHeight() - 1;
        while (budget > 0 && cursorS < current.s1 + 1.0) {
            double s = cursorS;
            double aMax = Math.min(SpaceFoldShape.BLOCK_SPAN, SpaceFoldShape.SPAN * s);
            for (double a = -aMax; a <= aMax + 1e-6; a += STEP) {
                for (double d = -half; d <= dMax + 1e-6; d += STEP) {
                    budget--;
                    Vec3 p = at(s, a, d);
                    int x = Mth.floor(p.x), y = Mth.floor(p.y), z = Mth.floor(p.z);
                    if (y < minY || y > maxY) continue;
                    long key = BlockPos.asLong(x, y, z);
                    if (!seen.add(key)) continue;
                    // класс — по центру блока
                    Vec3 q = new Vec3(x + 0.5, y + 0.5, z + 0.5).subtract(eye);
                    double qs = q.dot(f);
                    if (qs < SpaceFoldShape.CLEAR || qs < current.s0 || qs >= current.s1) continue;
                    if (Math.abs(q.dot(u)) > Math.min(SpaceFoldShape.BLOCK_SPAN, SpaceFoldShape.SPAN * qs)) continue;
                    double qd = q.dot(n);
                    if (Math.abs(qd) <= half) {
                        cut.add(new long[]{key});
                    } else if (qd > half && qd <= dMax) {
                        int sy = y - vy;
                        if (sy < minY || sy > maxY) continue;
                        shifted.add(new long[]{key, BlockPos.asLong(x - vx, sy, z - vz)});
                    }
                }
            }
            cursorS += STEP;
        }
        return budget;
    }

    /** Записать отрезок: сначала прочитать все источники сдвига, потом писать. */
    private void apply() {
        Long2ObjectOpenHashMap<LevelChunk> chunks = new Long2ObjectOpenHashMap<>();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        BlockState[] src = new BlockState[shifted.size()];
        for (int i = 0; i < src.length; i++) {
            long[] e = shifted.get(i);
            LevelChunk sc = chunk(chunks, e[1]);
            LevelChunk tc = chunk(chunks, e[0]);
            if (sc == null || tc == null) continue;
            pos.set(e[1]);
            if (sc.getBlockEntity(pos) != null) continue;
            BlockState s = sc.getBlockState(pos);
            src[i] = s;
        }

        Long2ObjectOpenHashMap<boolean[]> touched = new Long2ObjectOpenHashMap<>();
        for (long[] e : cut) {
            LevelChunk c = chunk(chunks, e[0]);
            if (c == null) continue;
            pos.set(e[0]);
            BlockState was = c.getBlockState(pos);
            if (was.isAir()) continue; // бедрок тоже режется
            if (c.getBlockEntity(pos) != null) c.removeBlockEntity(pos);
            write(c, pos, AIR, touched);
        }
        for (int i = 0; i < src.length; i++) {
            if (src[i] == null) continue;
            long[] e = shifted.get(i);
            LevelChunk c = chunk(chunks, e[0]);
            if (c == null) continue;
            pos.set(e[0]);
            BlockState was = c.getBlockState(pos);
            if (was == src[i] || c.getBlockEntity(pos) != null) continue;
            write(c, pos, src[i], touched);
        }

        ThreadedLevelLightEngine light = level.getChunkSource().getLightEngine();
        for (Long2ObjectOpenHashMap.Entry<boolean[]> t : touched.long2ObjectEntrySet()) {
            LevelChunk c = chunks.get(t.getLongKey());
            boolean[] secs = t.getValue();
            LevelChunkSection[] sections = c.getSections();
            for (int i = 0; i < secs.length; i++) {
                if (secs[i]) {
                    light.updateSectionStatus(SectionPos.of(c.getPos(), level.getSectionYFromSectionIndex(i)),
                            sections[i].hasOnlyAir());
                }
            }
            relight(c);
        }
        cut.clear();
        shifted.clear();
        seen.clear();
    }

    private LevelChunk chunk(Long2ObjectOpenHashMap<LevelChunk> cache, long blockPos) {
        int cx = BlockPos.getX(blockPos) >> 4, cz = BlockPos.getZ(blockPos) >> 4;
        long key = ChunkPos.asLong(cx, cz);
        LevelChunk c = cache.get(key);
        if (c == null && !cache.containsKey(key)) {
            c = level.getChunkSource().getChunkNow(cx, cz);
            cache.put(key, c);
        }
        return c;
    }

    private void write(LevelChunk c, BlockPos pos, BlockState state, Long2ObjectOpenHashMap<boolean[]> touched) {
        int i = c.getSectionIndex(pos.getY());
        LevelChunkSection[] sections = c.getSections();
        if (i < 0 || i >= sections.length) return;
        sections[i].setBlockState(pos.getX() & 15, pos.getY() & 15, pos.getZ() & 15, state, false);
        touched.computeIfAbsent(c.getPos().toLong(), k -> new boolean[sections.length])[i] = true;
    }

    /** Как Carving.relight у The Shooting Star: карты высот, свет, свежий чанк игрокам. */
    private void relight(LevelChunk chunk) {
        ChunkPos pos = chunk.getPos();
        ThreadedLevelLightEngine light = level.getChunkSource().getLightEngine();
        Heightmap.primeHeightmaps(chunk, EnumSet.allOf(Heightmap.Types.class));
        chunk.initializeLightSources();
        light.propagateLightSources(pos);
        chunk.setUnsaved(true);
        ClientboundLevelChunkWithLightPacket packet =
                new ClientboundLevelChunkWithLightPacket(chunk, light, (BitSet) null, (BitSet) null);
        for (ServerPlayer player : level.getChunkSource().chunkMap.getPlayers(pos, false)) {
            player.connection.send(packet);
        }
    }
}
