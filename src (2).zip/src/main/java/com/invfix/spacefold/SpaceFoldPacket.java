package com.invfix.spacefold;

import com.invfix.spacefold.client.SpaceFoldFx;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Сервер → все игроки измерения: Space Fold. Начало разлома (глаза
 * разрывающего), направление взгляда f и направление линии разлома на экране u
 * (плоскость разлома — через f и u), seed для рисунка.
 */
public record SpaceFoldPacket(int casterId, double x, double y, double z,
                              float fx, float fy, float fz, float ux, float uy, float uz, float seed)
        implements CustomPacketPayload {

    public static final Type<SpaceFoldPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "space_fold"));

    public static final StreamCodec<FriendlyByteBuf, SpaceFoldPacket> STREAM_CODEC = StreamCodec.of(
            (buf, m) -> {
                buf.writeVarInt(m.casterId());
                buf.writeDouble(m.x()); buf.writeDouble(m.y()); buf.writeDouble(m.z());
                buf.writeFloat(m.fx()); buf.writeFloat(m.fy()); buf.writeFloat(m.fz());
                buf.writeFloat(m.ux()); buf.writeFloat(m.uy()); buf.writeFloat(m.uz());
                buf.writeFloat(m.seed());
            },
            buf -> new SpaceFoldPacket(buf.readVarInt(), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                    buf.readFloat(), buf.readFloat(), buf.readFloat(),
                    buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat()));

    @Override
    public Type<SpaceFoldPacket> type() {
        return TYPE;
    }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(SpaceFoldPacket p, IPayloadContext ctx) {
        ctx.enqueueWork(() -> SpaceFoldFx.start(p.casterId, p.x, p.y, p.z, p.fx, p.fy, p.fz, p.ux, p.uy, p.uz, p.seed));
    }
}
