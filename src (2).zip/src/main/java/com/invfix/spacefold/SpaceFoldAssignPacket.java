package com.invfix.spacefold;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Клиент → Сервер: выбрать Space Fold как текущую способность (для назначения в слот). */
public record SpaceFoldAssignPacket(int x, int y, int z) implements CustomPacketPayload {

    public static final Type<SpaceFoldAssignPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "space_fold_assign"));

    public static final StreamCodec<FriendlyByteBuf, SpaceFoldAssignPacket> STREAM_CODEC = StreamCodec.of(
            (buf, m) -> { buf.writeInt(m.x()); buf.writeInt(m.y()); buf.writeInt(m.z()); },
            buf -> new SpaceFoldAssignPacket(buf.readInt(), buf.readInt(), buf.readInt()));

    @Override public Type<SpaceFoldAssignPacket> type() { return TYPE; }

    public static void handleServer(SpaceFoldAssignPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer player) || !SpaceFoldHandler.eligible(player)) return;
            try {
                InvincibleIncModVariables.PlayerVariables vars =
                        player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                vars.AbilitySet = SpaceFoldHandler.ABILITY;
                vars.abilityDescription = SpaceFoldHandler.ABILITY + " | LVL:" + SpaceFoldHandler.LVL_REQUIRED
                        + " | Shift + клавиша — угол разлома";
                vars.markSyncDirty();
            } catch (Exception ignored) {}
        });
    }
}
