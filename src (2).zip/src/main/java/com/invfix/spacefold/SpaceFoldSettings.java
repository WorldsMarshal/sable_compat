package com.invfix.spacefold;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

/**
 * Настройка Space Fold (меню на Shift + клавиша способности): угол плоскости
 * разлома на экране в градусах (0 — горизонтально, 90 — вертикально, плюс —
 * против часовой стрелки). На сервере хранится в persistentData игрока.
 */
public record SpaceFoldSettings(double angle) {

    public static final SpaceFoldSettings DEFAULT = new SpaceFoldSettings(90.0);
    static final String NBT = "invfix_spacefold";

    public SpaceFoldSettings {
        angle = Mth.wrapDegrees(angle);
        if (angle > 90.0) angle -= 180.0;
        if (angle <= -90.0) angle += 180.0;
    }

    static SpaceFoldSettings of(Player player) {
        CompoundTag data = player.getPersistentData();
        if (!data.contains(NBT)) return DEFAULT;
        return new SpaceFoldSettings(data.getCompound(NBT).getDouble("angle"));
    }

    void save(Player player) {
        CompoundTag t = new CompoundTag();
        t.putDouble("angle", angle);
        player.getPersistentData().put(NBT, t);
    }
}
