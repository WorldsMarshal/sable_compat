package com.invfix.scourge;

import com.invfix.scourge.client.ScourgeClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Сервер → Клиент: снимок «замороженных» статов заражённого игрока, чтобы
 * экран статов мог показать их в скобках рядом с текущими (=1/20).
 *
 * Если {@code infected == false} — клиент стирает запись (заражение снято/истекло).
 */
public record ScourgeSyncPacket(
        int playerId,
        boolean infected,
        double lvl,
        double currentStr, double trueStr,
        double currentDura, double trueDura,
        double currendSpeed, double trueSpeed,
        double currentHealth
) implements CustomPacketPayload {

    public static final Type<ScourgeSyncPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "scourge_sync"));

    public static final StreamCodec<FriendlyByteBuf, ScourgeSyncPacket> STREAM_CODEC =
            StreamCodec.of(ScourgeSyncPacket::encode, ScourgeSyncPacket::decode);

    private static void encode(FriendlyByteBuf buf, ScourgeSyncPacket p) {
        buf.writeVarInt(p.playerId);
        buf.writeBoolean(p.infected);
        buf.writeDouble(p.lvl);
        buf.writeDouble(p.currentStr);
        buf.writeDouble(p.trueStr);
        buf.writeDouble(p.currentDura);
        buf.writeDouble(p.trueDura);
        buf.writeDouble(p.currendSpeed);
        buf.writeDouble(p.trueSpeed);
        buf.writeDouble(p.currentHealth);
    }

    private static ScourgeSyncPacket decode(FriendlyByteBuf buf) {
        return new ScourgeSyncPacket(
                buf.readVarInt(),
                buf.readBoolean(),
                buf.readDouble(),
                buf.readDouble(), buf.readDouble(),
                buf.readDouble(), buf.readDouble(),
                buf.readDouble(), buf.readDouble(),
                buf.readDouble());
    }

    @Override public Type<ScourgeSyncPacket> type() { return TYPE; }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(ScourgeSyncPacket p, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (p.infected()) {
                ScourgeClientState.put(p);
            } else {
                ScourgeClientState.clear(p.playerId());
            }
        });
    }
}