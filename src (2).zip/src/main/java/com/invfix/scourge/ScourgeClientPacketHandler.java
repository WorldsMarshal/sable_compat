package com.invfix.scourge;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Клиентская обёртка приёма ScourgeSyncPacket.
 *
 * Весь класс помечен @OnlyIn(Dist.CLIENT), поэтому на сервере он не загружается
 * вообще, и ссылка на вырезаемый ScourgeSyncPacket.handleClient изолирована здесь.
 * ScourgePackets.receive вызывает этот класс только после проверки стороны, так что
 * на сервере JVM никогда не доходит до его загрузки.
 */
@OnlyIn(Dist.CLIENT)
final class ScourgeClientPacketHandler {

    private ScourgeClientPacketHandler() {}

    static void handle(ScourgeSyncPacket packet, IPayloadContext context) {
        ScourgeSyncPacket.handleClient(packet, context);
    }
}