package com.invfix.scourge;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Хранилище и логика заражения Scourge Virus.
 *
 * Данные лежат в {@code player.getPersistentData()} под подтегом "sable_compat:scourge",
 * чтобы переживать смерть (копируются вручную в {@link ScourgeVirusHandler#onClone}).
 *
 * При заражении снимается СНИМОК всех «вильтрумитских» статов (уровень, сила,
 * прочность, скорость, хп + их XP), после чего статы замораживаются и
 * принудительно держатся на 1 (хп — на 20) до истечения 50-минутного таймера
 * либо до дебаг-команды {@code /effect clear}. По окончании снимок возвращается.
 */
public final class ScourgeVirusState {

    private ScourgeVirusState() {}

    // ── Константы ──────────────────────────────────────────────
    /** 50 минут заражения. */
    public static final int  INFECTION_TICKS  = 50 * 60 * 20;   // 60000
    /** 10-минутный «букет» вредных эффектов, выдаётся один раз. */
    public static final int  BURST_TICKS      = 10 * 60 * 20;   // 12000
    /** Отравление людей при попадании в облако — 5 минут. */
    public static final int  HUMAN_POISON_TICKS = 5 * 60 * 20;  // 6000

    private static final String ROOT = "sable_compat:scourge";
    private static final double VANILLA_SPEED = 0.10000000149011612;

    /**
     * Флаг обхода защиты от снятия эффекта. Выставляется только нашим кодом
     * ({@link #cure}) на время удаления, чтобы {@code MobEffectEvent.Remove}
     * пропустил снятие именно нашего эффекта. Любое чужое снятие (молоко и т.п.)
     * идёт мимо этого флага и блокируется.
     */
    static boolean bypassRemoval = false;

    // ── Доступ к состоянию ─────────────────────────────────────
    public static boolean isInfected(Player player) {
        CompoundTag root = player.getPersistentData().getCompound(ROOT);
        return root.getBoolean("infected");
    }

    private static CompoundTag root(Player player) {
        CompoundTag pd = player.getPersistentData();
        if (!pd.contains(ROOT)) pd.put(ROOT, new CompoundTag());
        return pd.getCompound(ROOT);
    }

    public static int getTicksRemaining(Player player) {
        return root(player).getInt("ticks");
    }

    static void setTicksRemaining(Player player, int ticks) {
        root(player).putInt("ticks", ticks);
    }

    /** Снимок статов — для показа «заморозки» в скобках в меню. */
    public static double getFrozen(Player player, String key, double fallback) {
        CompoundTag snap = root(player).getCompound("snap");
        return snap.contains(key) ? snap.getDouble(key) : fallback;
    }

    // ── Заражение ──────────────────────────────────────────────
    /**
     * Заражает вильтрумита. Идемпотентна: повторный вызов на уже заражённом
     * игроке ничего не делает. Только серверная сторона.
     */
    public static void infect(Player player) {
        if (player.level().isClientSide()) return;
        if (isInfected(player)) return;
        if (!ScourgeRaces.isViltrumite(ScourgeRaces.raceOf(player))) return;

        InvincibleIncModVariables.PlayerVariables vars;
        try {
            vars = player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
        } catch (Exception e) {
            return;
        }

        CompoundTag root = root(player);
        root.putBoolean("infected", true);
        root.putInt("ticks", INFECTION_TICKS);
        root.putBoolean("burst", false);

        // Снимок всех значимых статов.
        CompoundTag snap = new CompoundTag();
        snap.putDouble("Lvl",          vars.Lvl);
        snap.putDouble("currentStr",   vars.currentStr);
        snap.putDouble("trueStr",      vars.trueStr);
        snap.putDouble("maxStr",       vars.maxStr);
        snap.putDouble("currentDura",  vars.currentDura);
        snap.putDouble("trueDura",     vars.trueDura);
        snap.putDouble("maxDura",      vars.maxDura);
        snap.putDouble("currendSpeed", vars.currendSpeed);
        snap.putDouble("trueSpeed",    vars.trueSpeed);
        snap.putDouble("maxSpeed",     vars.maxSpeed);
        snap.putDouble("currentHealth",vars.currentHealth);
        snap.putDouble("trueHealth",   vars.trueHealth);
        snap.putDouble("maxHealth",    vars.maxHealth);
        snap.putDouble("xp",           vars.xp);
        snap.putDouble("xpCap",        vars.xpCap);
        snap.putDouble("strengthXP",   vars.strengthXP);
        snap.putDouble("defenseXP",    vars.defenseXP);
        snap.putDouble("speedXP",      vars.speedXP);
        snap.putDouble("healthXP",     vars.healthXP);
        snap.putDouble("DamageTolerance", vars.DamageTolerance);
        // Снимок ванильных атрибутов.
        if (player.getAttribute(Attributes.MAX_HEALTH) != null)
            snap.putDouble("attrHp", player.getAttribute(Attributes.MAX_HEALTH).getBaseValue());
        if (player.getAttribute(Attributes.MOVEMENT_SPEED) != null)
            snap.putDouble("attrSpd", player.getAttribute(Attributes.MOVEMENT_SPEED).getBaseValue());
        root.put("snap", snap);

        // Сразу замораживаем статы и вешаем видимый эффект.
        freezeStats(player, vars);
        applyEffectInstance(player, INFECTION_TICKS);

        // Разовый 10-минутный «букет» вредных эффектов.
        applyInitialBurst(player);
        root.putBoolean("burst", true);

        vars.markSyncDirty();
        syncTo(player);
    }

    /**
     * Принудительно держит статы заражённого на «scourge»-значениях.
     * Вызывается каждый серверный тик, чтобы перебить пересчёт статов
     * процедурами оригинального мода.
     */
    public static void freezeStats(Player player, InvincibleIncModVariables.PlayerVariables vars) {
        vars.Lvl          = 1.0;
        vars.currentStr   = 1.0;
        vars.trueStr      = 1.0;
        vars.maxStr       = 1.0;
        vars.currentDura  = 1.0;
        vars.trueDura     = 1.0;
        vars.maxDura      = 1.0;
        vars.currendSpeed = 1.0;
        vars.trueSpeed    = 1.0;
        vars.currentHealth= 20.0;
        vars.trueHealth   = 20.0;
        vars.maxHealth    = 20.0;
        // Расовый щит сбит — уязвим ко всему урону.
        vars.DamageTolerance = 0.0;

        // Прогрессия заморожена: XP откатывается к снимку, копить нельзя.
        CompoundTag snap = root(player).getCompound("snap");
        vars.xp         = snap.getDouble("xp");
        vars.xpCap      = snap.contains("xpCap") ? snap.getDouble("xpCap") : vars.xpCap;
        vars.strengthXP = snap.getDouble("strengthXP");
        vars.defenseXP  = snap.getDouble("defenseXP");
        vars.speedXP    = snap.getDouble("speedXP");
        vars.healthXP   = snap.getDouble("healthXP");

        // Ванильные атрибуты.
        if (player.getAttribute(Attributes.MAX_HEALTH) != null
                && player.getAttribute(Attributes.MAX_HEALTH).getBaseValue() != 20.0) {
            player.getAttribute(Attributes.MAX_HEALTH).setBaseValue(20.0);
        }
        if (player.getAttribute(Attributes.MOVEMENT_SPEED) != null
                && player.getAttribute(Attributes.MOVEMENT_SPEED).getBaseValue() != VANILLA_SPEED) {
            player.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(VANILLA_SPEED);
        }
        if (player.getHealth() > 20.0f) player.setHealth(20.0f);

        // Глушим полёт и лётные флаги (на случай, если что-то их включило).
        if (!player.isCreative() && !player.isSpectator()) {
            if (player.getAbilities().mayfly || player.getAbilities().flying) {
                player.getAbilities().mayfly = false;
                player.getAbilities().flying = false;
                player.onUpdateAbilities();
            }
        }
        vars.isflying        = false;
        vars.flightActive    = false;
        vars.newflightactive = false;
        vars.elytraflighton  = false;
    }

    private static void applyInitialBurst(Player player) {
        // Иссушение, слепота, тошнота, отравление + логичные слабость и голод.
        addBurst(player, MobEffects.WITHER,    0);
        addBurst(player, MobEffects.BLINDNESS, 0);
        addBurst(player, MobEffects.CONFUSION, 0); // Nausea
        addBurst(player, MobEffects.POISON,    0);
        addBurst(player, MobEffects.WEAKNESS,  0);
        addBurst(player, MobEffects.HUNGER,    0);
    }

    private static void addBurst(Player player, net.minecraft.core.Holder<net.minecraft.world.effect.MobEffect> e, int amp) {
        player.addEffect(new MobEffectInstance(e, BURST_TICKS, amp, false, true, true));
    }

    static void applyEffectInstance(Player player, int duration) {
        MobEffectInstance cur = player.getEffect(ScourgeRegistry.SCOURGE_VIRUS);
        if (cur == null || cur.getDuration() < duration - 5) {
            player.addEffect(new MobEffectInstance(
                    ScourgeRegistry.SCOURGE_VIRUS, duration, 0, false, false, true));
        }
    }

    // ── Снятие / истечение ─────────────────────────────────────
    /**
     * Полностью снимает заражение: возвращает снимок статов, чистит флаги и
     * удаляет эффект (с обходом защиты от снятия).
     * Используется и при истечении таймера, и дебаг-командой {@code /effect clear}.
     */
    public static void cure(Player player) {
        if (player.level().isClientSide()) return;
        if (!isInfected(player)) return;

        CompoundTag root = root(player);
        CompoundTag snap = root.getCompound("snap");

        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);

            vars.Lvl          = snap.getDouble("Lvl");
            vars.currentStr   = snap.getDouble("currentStr");
            vars.trueStr      = snap.getDouble("trueStr");
            vars.maxStr       = snap.getDouble("maxStr");
            vars.currentDura  = snap.getDouble("currentDura");
            vars.trueDura     = snap.getDouble("trueDura");
            vars.maxDura      = snap.getDouble("maxDura");
            vars.currendSpeed = snap.getDouble("currendSpeed");
            vars.trueSpeed    = snap.getDouble("trueSpeed");
            vars.maxSpeed     = snap.getDouble("maxSpeed");
            vars.currentHealth= snap.getDouble("currentHealth");
            vars.trueHealth   = snap.getDouble("trueHealth");
            vars.maxHealth    = snap.getDouble("maxHealth");
            vars.xp           = snap.getDouble("xp");
            vars.xpCap        = snap.contains("xpCap") ? snap.getDouble("xpCap") : vars.xpCap;
            vars.strengthXP   = snap.getDouble("strengthXP");
            vars.defenseXP    = snap.getDouble("defenseXP");
            vars.speedXP      = snap.getDouble("speedXP");
            vars.healthXP     = snap.getDouble("healthXP");
            vars.DamageTolerance = snap.getDouble("DamageTolerance");
            vars.markSyncDirty();
        } catch (Exception ignored) {}

        if (player.getAttribute(Attributes.MAX_HEALTH) != null && snap.contains("attrHp")) {
            player.getAttribute(Attributes.MAX_HEALTH).setBaseValue(snap.getDouble("attrHp"));
        }
        if (player.getAttribute(Attributes.MOVEMENT_SPEED) != null && snap.contains("attrSpd")) {
            player.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(snap.getDouble("attrSpd"));
        }

        // Снимаем сам эффект с обходом блокировки удаления.
        bypassRemoval = true;
        try {
            player.removeEffect(ScourgeRegistry.SCOURGE_VIRUS);
        } finally {
            bypassRemoval = false;
        }

        // Чистим состояние.
        player.getPersistentData().remove(ROOT);

        // Сообщаем клиенту снять «(заморозку)» с экрана статов.
        if (player instanceof ServerPlayer sp) {
            PacketDistributor.sendToPlayer(sp, new ScourgeSyncPacket(
                    sp.getId(), false, 0, 0, 0, 0, 0, 0, 0, 0));
        }
    }

    /** Отправляет клиенту снимок замороженных статов для показа в скобках. */
    public static void syncTo(Player player) {
        if (!(player instanceof ServerPlayer sp)) return;
        if (!isInfected(player)) {
            PacketDistributor.sendToPlayer(sp, new ScourgeSyncPacket(
                    sp.getId(), false, 0, 0, 0, 0, 0, 0, 0, 0));
            return;
        }
        CompoundTag snap = root(player).getCompound("snap");
        PacketDistributor.sendToPlayer(sp, new ScourgeSyncPacket(
                sp.getId(), true,
                snap.getDouble("Lvl"),
                snap.getDouble("currentStr"),  snap.getDouble("trueStr"),
                snap.getDouble("currentDura"), snap.getDouble("trueDura"),
                snap.getDouble("currendSpeed"),snap.getDouble("trueSpeed"),
                snap.getDouble("currentHealth")));
    }

    /** Копирование состояния при респавне/возврате (PlayerEvent.Clone). */
    static void copy(Player from, Player to) {
        CompoundTag pd = from.getPersistentData();
        if (pd.contains(ROOT)) {
            to.getPersistentData().put(ROOT, pd.getCompound(ROOT).copy());
        }
    }
}