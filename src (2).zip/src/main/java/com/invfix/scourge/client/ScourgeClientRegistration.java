package com.invfix.scourge.client;

import com.invfix.scourge.ScourgeRegistry;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/**
 * Рендер метательного снаряда Scourge Virus — обычный ThrownItemRenderer
 * (рисует иконку предмета в полёте), как у снежка/зелья.
 */
@EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ScourgeClientRegistration {

    private ScourgeClientRegistration() {}

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ScourgeRegistry.SCOURGE_BOTTLE.get(), ThrownItemRenderer::new);
    }
}
