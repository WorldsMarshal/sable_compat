package com.invfix.scourge.client;

import com.invfix.scourge.ScourgeSyncPacket;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Клиентское зеркало снимков замороженных статов (по entityId игрока).
 * Заполняется из {@link ScourgeSyncPacket}, читается экраном статов.
 */
@OnlyIn(Dist.CLIENT)
public final class ScourgeClientState {

    private ScourgeClientState() {}

    private static final Map<Integer, ScourgeSyncPacket> SNAPSHOTS = new ConcurrentHashMap<>();

    public static void put(ScourgeSyncPacket p) {
        SNAPSHOTS.put(p.playerId(), p);
    }

    public static void clear(int playerId) {
        SNAPSHOTS.remove(playerId);
    }

    /** Снимок для игрока, либо null если он не заражён. */
    public static ScourgeSyncPacket get(int playerId) {
        return SNAPSHOTS.get(playerId);
    }
}