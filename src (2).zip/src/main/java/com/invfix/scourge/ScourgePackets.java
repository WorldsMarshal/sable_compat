package com.invfix.scourge;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Регистрация сетевого пакета снимка заражения (server → client).
 *
 * ВАЖНО: ScourgeSyncPacket.handleClient помечен @OnlyIn(Dist.CLIENT), поэтому на
 * физическом сервере его тело вырезается RuntimeDistCleaner'ом. Если ссылаться на
 * него напрямую (ScourgeSyncPacket::handleClient) при регистрации, которая идёт на
 * ОБЕИХ сторонах, на сервере получаем NoSuchMethodError.
 *
 * Решение: на клиенте подключаем настоящий handleClient, на сервере — no-op
 * приёмник (сервер этот пакет только ОТПРАВЛЯЕт, принимать ему нечего). Так пакет
 * зарегистрирован на обеих сторонах, а клиентский метод на сервере не трогается.
 */
@EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD)
public final class ScourgePackets {

    private ScourgePackets() {}

    @SubscribeEvent
    public static void onRegisterPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("sable_compat");
        registrar.playToServer(
                com.invfix.unleashed.UnleashedTogglePacket.TYPE,
                com.invfix.unleashed.UnleashedTogglePacket.STREAM_CODEC,
                com.invfix.unleashed.UnleashedTogglePacket::handle);
        registrar.playToClient(
                ScourgeSyncPacket.TYPE,
                ScourgeSyncPacket.STREAM_CODEC,
                ScourgePackets::receive);

        // --- Rick C137 ---
        // Оба пакета server -> client. Их handle сам проверяет FMLEnvironment.dist и
        // трогает клиентские классы только на клиенте, поэтому на выделенном сервере
        // RuntimeDistCleaner ничего не ломает — та же схема, что у ScourgeSyncPacket.
        registrar.playToClient(
                com.invfix.rick.RickTanksSyncPacket.TYPE,
                com.invfix.rick.RickTanksSyncPacket.STREAM_CODEC,
                com.invfix.rick.RickTanksSyncPacket::handle);

        registrar.playToClient(
                com.invfix.rick.RickVariantPackets.Sync.TYPE,
                com.invfix.rick.RickVariantPackets.Sync.STREAM_CODEC,
                com.invfix.rick.RickVariantPackets.Sync::handle);
        registrar.playToServer(
                com.invfix.rick.RickVariantPackets.Select.TYPE,
                com.invfix.rick.RickVariantPackets.Select.STREAM_CODEC,
                com.invfix.rick.RickVariantPackets.Select::handle);

        // Пакеты портальных пушек — в rick/portalgun/PortalGunNetwork.
    }

    /**
     * Диспетчер приёма. Делегирует клиентскому коду ТОЛЬКО на клиенте; ссылка на
     * ScourgeSyncPacket.handleClient берётся внутри отдельного класса-обёртки,
     * который загружается лишь на клиентской стороне — поэтому на сервере класс с
     * вырезанным методом не трогается.
     */
    private static void receive(ScourgeSyncPacket packet, IPayloadContext context) {
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ScourgeClientPacketHandler.handle(packet, context);
        }
        // на сервере приходить нечему — игнорируем
    }
}