package com.invfix.scourge;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;

import java.util.List;

/**
 * Метательный снаряд вируса Scourge. Ведёт себя как взрывное (splash) зелье:
 * летит по баллистике, разбивается при попадании и создаёт облако поражения
 * в радиусе {@link #RADIUS} блоков.
 *
 * В зоне поражения:
 *   • люди (Human и человекоподобные расы) — отравление на 5 минут;
 *   • вильтрумиты и их гибриды — заражение Scourge Virus (50 минут);
 *   • прочие расы и мобы — игнорируются.
 */
public class ScourgeVirusBottle extends ThrowableItemProjectile {

    private static final double RADIUS = 4.0;

    public ScourgeVirusBottle(EntityType<? extends ScourgeVirusBottle> type, Level level) {
        super(type, level);
    }

    public ScourgeVirusBottle(Level level, LivingEntity thrower) {
        super(ScourgeRegistry.SCOURGE_BOTTLE.get(), thrower, level);
    }

    public ScourgeVirusBottle(Level level, double x, double y, double z) {
        super(ScourgeRegistry.SCOURGE_BOTTLE.get(), x, y, z, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ScourgeRegistry.SCOURGE_VIRUS_ITEM.get();
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (level().isClientSide()) return;

        applyAreaEffect();

        // Звук и частицы разбившегося сосуда.
        level().playSound(null, getX(), getY(), getZ(),
                SoundEvents.SPLASH_POTION_BREAK, SoundSource.NEUTRAL, 1.0f, 1.0f);
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.SNEEZE,
                    getX(), getY(), getZ(), 60, RADIUS / 2.0, 0.5, RADIUS / 2.0, 0.0);
            server.sendParticles(ParticleTypes.ITEM_SLIME,
                    getX(), getY(), getZ(), 40, RADIUS / 2.0, 0.5, RADIUS / 2.0, 0.0);
        }

        discard();
    }

    private void applyAreaEffect() {
        AABB box = getBoundingBox().inflate(RADIUS, RADIUS / 2.0, RADIUS);
        List<Player> players = level().getEntitiesOfClass(Player.class, box,
                p -> p.isAlive() && p.distanceToSqr(this) <= (RADIUS + 1.0) * (RADIUS + 1.0));

        for (Player player : players) {
            String race = ScourgeRaces.raceOf(player);

            if (ScourgeRaces.isHuman(race)) {
                // Люди: только отравление, схожесть ДНК делает вирус опасным.
                player.addEffect(new MobEffectInstance(MobEffects.POISON,
                        ScourgeVirusState.HUMAN_POISON_TICKS, 0, false, true, true));
            } else if (ScourgeRaces.isViltrumite(race)) {
                // Вильтрумиты и гибриды: полноценное заражение.
                ScourgeVirusState.infect(player);
            }
            // Altrumite, Battle Beast, Unopan и прочие — невосприимчивы.
        }
    }
}
