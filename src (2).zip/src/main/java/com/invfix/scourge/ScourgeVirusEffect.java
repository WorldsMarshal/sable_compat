package com.invfix.scourge;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/**
 * «Scourge Virus» — эффект-индикатор заражения вильтрумита.
 *
 * Сам по себе он ничего не тикает: вся логика (заморозка статов, уязвимости,
 * распространение, обратный отсчёт 50 минут) живёт в {@link ScourgeVirusHandler}
 * и {@link ScourgeVirusState}. Эффект нужен как:
 *   • видимая иконка в инвентаре/HUD на всё время заражения;
 *   • маркер категории HARMFUL.
 *
 * Снять его ничем нельзя (молоко, смерть и т.п. блокируются в
 * {@link ScourgeVirusHandler#onEffectRemove}) — только командой
 * {@code /effect clear}, которая перехватывается отдельно для дебага.
 *
 * Иконка: assets/sable_compat/textures/mob_effect/scourge_virus.png
 */
public class ScourgeVirusEffect extends MobEffect {

    public ScourgeVirusEffect() {
        // Болезненно-зелёный цвет частиц.
        super(MobEffectCategory.HARMFUL, 0x6B8E23);
    }
}
