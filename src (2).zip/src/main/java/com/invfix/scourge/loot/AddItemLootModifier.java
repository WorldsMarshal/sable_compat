package com.invfix.scourge.loot;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.neoforged.neoforge.common.loot.IGlobalLootModifier;
import net.neoforged.neoforge.common.loot.LootModifier;
import org.jetbrains.annotations.NotNull;

/**
 * Простейший глобальный модификатор лута: добавляет один экземпляр заданного
 * предмета в результат генерации, если выполнены условия из JSON.
 *
 * Вся фильтрация (нужная лут-таблица + шанс) задаётся в condition'ах JSON:
 *   • minecraft:random_chance — шанс (1/20 = 0.05);
 *   • neoforge:loot_table_id  — только сундуки Энд-городов.
 * Так Java-логика остаётся тривиальной и не подвержена багам.
 */
public class AddItemLootModifier extends LootModifier {

    public static final MapCodec<AddItemLootModifier> CODEC =
            RecordCodecBuilder.mapCodec(inst -> LootModifier.codecStart(inst)
                    .and(BuiltInRegistries.ITEM.byNameCodec()
                            .fieldOf("item")
                            .forGetter(m -> m.item))
                    .apply(inst, AddItemLootModifier::new));

    private final Item item;

    public AddItemLootModifier(LootItemCondition[] conditions, Item item) {
        super(conditions);
        this.item = item;
    }

    @Override
    protected @NotNull ObjectArrayList<ItemStack> doApply(
            ObjectArrayList<ItemStack> generatedLoot, LootContext context) {
        generatedLoot.add(new ItemStack(item));
        return generatedLoot;
    }

    @Override
    public MapCodec<? extends IGlobalLootModifier> codec() {
        return CODEC;
    }
}