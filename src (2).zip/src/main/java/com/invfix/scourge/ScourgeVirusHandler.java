package com.invfix.scourge;

import com.invfix.InvincibleFix;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.context.ParsedCommandNode;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.ResourceArgument;
import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.CommandEvent;
import net.neoforged.neoforge.event.entity.living.MobEffectEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Серверная логика заражения Scourge Virus.
 *
 *  • Каждый тик у заражённого: удержание заморозки статов, обратный отсчёт
 *    50-минутного таймера, ресинк видимого эффекта, распространение вируса.
 *  • Перенос состояния через смерть/респавн (Clone).
 *  • Блокировка любого снятия эффекта, кроме дебаг-команды {@code /effect clear}.
 */
@EventBusSubscriber(modid = InvincibleFix.MOD_ID)
public final class ScourgeVirusHandler {

    private ScourgeVirusHandler() {}

    private static final double SPREAD_RADIUS    = 8.0;
    private static final int    SPREAD_INTERVAL  = 200;
    private static final float  SPREAD_CHANCE    = 0.35f;

    // ── Тик заражённого ────────────────────────────────────────
    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide()) return;
        if (!ScourgeVirusState.isInfected(player)) return;

        // Обратный отсчёт.
        int ticks = ScourgeVirusState.getTicksRemaining(player) - 1;
        if (ticks <= 0) {
            ScourgeVirusState.cure(player);   // естественное истечение — статы вернутся
            return;
        }
        ScourgeVirusState.setTicksRemaining(player, ticks);

        // Удержание заморозки (перебивает пересчёт процедур оригинала).
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            ScourgeVirusState.freezeStats(player, vars);
            vars.markSyncDirty();
        } catch (Exception ignored) {}

        // Видимый эффект держим синхронным с таймером.
        ScourgeVirusState.applyEffectInstance(player, ticks);

        // Распространение раз в 200 тиков.
        if (player.tickCount % SPREAD_INTERVAL == 0) {
            spread(player);
        }
    }

    private static void spread(Player carrier) {
        AABB box = carrier.getBoundingBox().inflate(SPREAD_RADIUS);
        double r2 = SPREAD_RADIUS * SPREAD_RADIUS;
        List<Player> nearby = carrier.level().getEntitiesOfClass(Player.class, box);
        for (Player other : nearby) {
            if (other == carrier) continue;
            if (other.distanceToSqr(carrier) > r2) continue;
            if (ScourgeVirusState.isInfected(other)) continue;
            if (!ScourgeRaces.isViltrumite(ScourgeRaces.raceOf(other))) continue;
            if (carrier.getRandom().nextFloat() < SPREAD_CHANCE) {
                ScourgeVirusState.infect(other);
            }
        }
    }

    // ── Перенос через смерть/респавн ───────────────────────────
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        ScourgeVirusState.copy(event.getOriginal(), event.getEntity());
        // Эффект и заморозка восстановятся автоматически в onPlayerTick;
        // ресинк клиента — после полного респавна (onRespawn).
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (ScourgeVirusState.isInfected(event.getEntity())) {
            ScourgeVirusState.syncTo(event.getEntity());
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (ScourgeVirusState.isInfected(event.getEntity())) {
            ScourgeVirusState.syncTo(event.getEntity());
        }
    }

    // ── Блокировка снятия эффекта ──────────────────────────────
    @SubscribeEvent
    public static void onEffectRemove(MobEffectEvent.Remove event) {
        Holder<MobEffect> effect = event.getEffect();
        if (effect != null && effect.value() == ScourgeRegistry.SCOURGE_VIRUS.value()) {
            if (!ScourgeVirusState.bypassRemoval) {
                event.setCanceled(true);   // молоко, смерть и т.п. не снимают
            }
        }
    }

    // ── Дебаг-снятие через /effect clear ───────────────────────
    @SubscribeEvent
    public static void onCommand(CommandEvent event) {
        ParseResults<CommandSourceStack> parse = event.getParseResults();
        CommandContext<CommandSourceStack> ctx;
        try {
            ctx = parse.getContext().build(parse.getReader().getString());
        } catch (Exception e) {
            return;
        }

        // Команда должна быть «effect clear ...».
        List<ParsedCommandNode<CommandSourceStack>> nodes = ctx.getNodes();
        if (nodes.size() < 2) return;
        if (!"effect".equals(nodes.get(0).getNode().getName())) return;
        if (!"clear".equals(nodes.get(1).getNode().getName())) return;

        // Наличие аргументов определяем по разобранным узлам:
        // структура команды — effect / clear / [targets] / [effect].
        boolean hasTargets   = nodes.size() >= 3 && "targets".equals(nodes.get(2).getNode().getName());
        boolean hasEffectArg = nodes.size() >= 4 && "effect".equals(nodes.get(3).getNode().getName());

        // Если указан конкретный эффект и это не наш — не трогаем.
        if (hasEffectArg) {
            try {
                Holder<MobEffect> specified = ResourceArgument.getMobEffect(ctx, "effect");
                if (specified.value() != ScourgeRegistry.SCOURGE_VIRUS.value()) return;
            } catch (Exception e) {
                return;
            }
        }

        // Цели.
        Collection<? extends Entity> targets;
        if (hasTargets) {
            try {
                targets = EntityArgument.getEntities(ctx, "targets");
            } catch (Exception e) {
                return;
            }
        } else {
            Entity self = ctx.getSource().getEntity();
            if (self == null) return;
            List<Entity> one = new ArrayList<>();
            one.add(self);
            targets = one;
        }

        for (Entity target : targets) {
            if (target instanceof Player player && ScourgeVirusState.isInfected(player)) {
                ScourgeVirusState.cure(player);
            }
        }
    }
}