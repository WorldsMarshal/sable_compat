package com.invfix.scourge;

import com.invfix.scourge.loot.AddItemLootModifier;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.loot.IGlobalLootModifier;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/**
 * Реестр всего, что относится к Scourge Virus.
 *   • предмет          invincible_inc:scourge_virus   (метательный, как взрывное зелье);
 *   • предмет          invincible_inc:viltrumite_fossil (ингредиент крафта);
 *   • сущность-снаряд  sable_compat:scourge_virus_bottle;
 *   • эффект           sable_compat:scourge_virus.
 *
 * ПРЕДМЕТЫ намеренно регистрируются в namespace оригинального мода
 * (invincible_inc), сущность и эффект остаются в sable_compat.
 *
 * Вызывается из {@link com.invfix.InvincibleFix} через {@link #register(IEventBus)}.
 */
public final class ScourgeRegistry {

    private ScourgeRegistry() {}

    private static final String NS = "sable_compat";
    /** Namespace оригинального мода — под ним регистрируем НАШИ предметы,
     *  чтобы их id-путь был invincible_inc:..., а не sable_compat:... */
    private static final String ITEM_NS = "invincible_inc";

    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(ITEM_NS);

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, NS);

    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(Registries.MOB_EFFECT, NS);

    public static final DeferredRegister<MapCodec<? extends IGlobalLootModifier>> LOOT_MODIFIERS =
            DeferredRegister.create(NeoForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, NS);

    // ── Эффект ────────────────────────────────────────────────
    public static final DeferredHolder<MobEffect, ScourgeVirusEffect> SCOURGE_VIRUS =
            EFFECTS.register("scourge_virus", ScourgeVirusEffect::new);

    // ── Снаряд ────────────────────────────────────────────────
    public static final DeferredHolder<EntityType<?>, EntityType<ScourgeVirusBottle>> SCOURGE_BOTTLE =
            ENTITIES.register("scourge_virus_bottle",
                    () -> EntityType.Builder
                            .<ScourgeVirusBottle>of(ScourgeVirusBottle::new, MobCategory.MISC)
                            .sized(0.25f, 0.25f)
                            .clientTrackingRange(4)
                            .updateInterval(10)
                            .build("scourge_virus_bottle"));

    // ── Предмет ───────────────────────────────────────────────
    public static final DeferredItem<ScourgeVirusItem> SCOURGE_VIRUS_ITEM =
            ITEMS.register("scourge_virus",
                    () -> new ScourgeVirusItem(new Item.Properties().stacksTo(16)));

    /** Окаменелость вильтрумита — редкий ингредиент крафта (лут Энда). */
    public static final DeferredItem<Item> VILTRUMITE_FOSSIL =
            ITEMS.register("viltrumite_fossil",
                    () -> new Item(new Item.Properties()));

    // ── Глобальный модификатор лута (окаменелость в сундуки Энд-городов) ──
    public static final DeferredHolder<MapCodec<? extends IGlobalLootModifier>, MapCodec<AddItemLootModifier>>
            ADD_ITEM_MODIFIER = LOOT_MODIFIERS.register("add_item", () -> AddItemLootModifier.CODEC);

    public static void register(IEventBus modEventBus) {
        EFFECTS.register(modEventBus);
        ENTITIES.register(modEventBus);
        ITEMS.register(modEventBus);
        LOOT_MODIFIERS.register(modEventBus);
        modEventBus.addListener(ScourgeRegistry::onBuildCreativeTabs);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(SCOURGE_VIRUS_ITEM);
        }
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(VILTRUMITE_FOSSIL);
        }
    }
}