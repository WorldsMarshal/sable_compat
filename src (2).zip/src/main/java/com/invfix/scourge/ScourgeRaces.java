package com.invfix.scourge;

import com.invfix.humanlike.HumanLikeRaces;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;

import java.util.Set;

/**
 * Раздаёт цели вируса Scourge по расовой строке (vars.Race).
 *
 * Канон: вирус Scourge смертелен для Вильтрумитов и опасен для людей из-за
 * сходства ДНК. Прочие расы (Altrumite, Battle Beast, Unopan) к нему невосприимчивы.
 *
 *  • HUMAN_RACES         — получают только отравление на 5 минут;
 *  • VILTRUMITE_RACES    — получают полноценный эффект Scourge Virus (заражение);
 *                          сюда входят чистые вильтрумиты И их гибриды;
 *  • остальные расы      — игнорируются полностью.
 *
 * ВАЖНО: Altrumite НЕ входит в список заражаемых, хотя в
 * {@link com.invfix.ViltrumiteImmunityHandler} он механически копирует
 * вильтрумитов. Для вируса он — отдельная невосприимчивая раса.
 */
public final class ScourgeRaces {

    private ScourgeRaces() {}

    /** Чистые вильтрумиты и их гибриды — заражаются. Altrumite сюда НЕ входит. */
    public static final Set<String> VILTRUMITE_RACES = Set.of(
            "§4§lViltrumite",
            "§f§lHuman-Viltrumite",
            "§1§lThraxan-Viltrumite"
    );

    /** Человеческие расы — получают только отравление. */
    public static final Set<String> HUMAN_RACES = Set.of(
            "§f§lHuman",
            "§lHuman",
            HumanLikeRaces.BORN_FOR_V,
            HumanLikeRaces.PREDISPOSITION
    );

    public static boolean isViltrumite(String race) {
        return race != null && VILTRUMITE_RACES.contains(race);
    }

    public static boolean isHuman(String race) {
        return race != null && HUMAN_RACES.contains(race);
    }

    /** Безопасно достаёт расовую строку игрока ("" если нет данных). */
    public static String raceOf(Entity entity) {
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            return vars.Race == null ? "" : vars.Race;
        } catch (Exception e) {
            return "";
        }
    }
}
