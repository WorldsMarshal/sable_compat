package com.invfix.infinity;

import com.invfix.timestop.TimeStopConfig;
import com.invfix.timestop.TimeStopInstance;
import com.invfix.timestop.TimeStopManager;
import com.invfix.timestop.TimeStopTier;
import com.invfix.timestop.blink.BlinkTarget;
import com.invfix.timestop.blink.TimeStopBlink;
import com.invfix.timestop.blink.TimeStopBlinkClientHook;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Камень Времени. Модель, текстура и поведение предмета — из Pugmeowlas
 * Infinity Stones Core 7.x (аддон Palladium), функционал свой.
 *
 * Что перенесено из оригинала:
 *  - addon/infinity/items/time_stone.json: стак 1, редкость epic, не горит;
 *  - givetimestone.mcfunction: имя зелёным жирным и блеск зачарования
 *    (Enchantments:[{}] — пустое зачарование ради свечения);
 *  - items/time.mcfunction: на земле камень не лежит обычным предметом,
 *    см. {@link TimeStoneEntity}.
 *
 * Остановка времени — та же раскладка, что у пульта Рика:
 *  - ПКМ — остановить время / возобновить своё;
 *  - Шифт + ПКМ — мгновенная остановка (рывок, TimeStopBlink), а при своей
 *    остановке — её снятие.
 * Уровень {@link TimeStopTier#STONE}: свой слой, с пультом и Metroman не
 * пересекается.
 *
 * Запас — полоска предмета. Единица запаса — один тик остановленного времени:
 *  - ёмкость: здоровье носителя × 20 секунд (MAX_HEALTH, у рас Invincible это
 *    и есть стат Health — см. RealHealthSync);
 *  - в остановке тратится тик за тик, кончился — время пошло;
 *  - перезарядка — ёмкость / 10: пустой камень заполняется за десятую часть
 *    своего максимума, то есть в 10 раз быстрее, чем тратится. Это и есть
 *    кулдаун — отдельного запрета на включение нет, включить можно с любым
 *    ненулевым запасом;
 *  - выброшенный и подобранный камень пуст (TimeStoneEntity#interact);
 *  - пока камень с запасом лежит в инвентаре, носитель не замирает в чужой
 *    остановке, а запас тратится тик за тик (правило time_stone в
 *    TimeStopExemptions, трата — TimeStoneEvents). Перезарядки в это время нет.
 *
 * Замена брошенного предмета сделана штатным путём NeoForge: hasCustomEntity
 * + createEntity. NeoForgeEventHandler#onEntityJoinWorld сам гасит ItemEntity
 * и добавляет нашу сущность на следующем тике.
 */
public class TimeStoneItem extends Item {

    /** Секунд остановленного времени на единицу здоровья. */
    public static final int SECONDS_PER_HP = 20;
    /** Во сколько раз перезарядка быстрее траты: кулдаун = максимум / 10. */
    public static final int RECHARGE_FACTOR = 10;
    /** Перезарядка пишется в стек раз в столько тиков — меньше синхронизаций. */
    public static final int RECHARGE_INTERVAL = 5;
    /**
     * Цена тика мгновенной остановки в тиках запаса. В ROTP мгновенная стоит
     * 0.8 от поддержания обычной (TimeStopInstant#getStaminaCostTicking) —
     * так же посчитано у пульта (TimeDeviceItem#BLINK_COST_PER_TICK).
     */
    public static final float BLINK_COST_FACTOR = 0.8F;
    /** Кулдаун между нажатиями, тиков. Только от дребезга, как у пульта. */
    public static final int DEBOUNCE_TICKS = 20;
    /** Тёмно-зелёная полоса. */
    public static final int BAR_COLOR = 0x006400;

    public TimeStoneItem(Properties props) {
        super(props);
    }

    // ── запас ──────────────────────────────────────────────────────────────

    /** Ёмкость для носителя, тиков. Без переполнения: HP у рас бывает огромным. */
    public static int capacityFor(LivingEntity holder) {
        long hp = Math.max(0L, (long) Mth.floor(holder.getMaxHealth()));
        long ticks = hp * SECONDS_PER_HP * 20L;
        return (int) Math.min(ticks, Integer.MAX_VALUE);
    }

    public static int capacity(ItemStack stack) {
        Integer v = stack.get(TimeStoneRegistry.CAPACITY.get());
        return v == null ? 0 : Math.max(0, v);
    }

    public static int charge(ItemStack stack) {
        Integer v = stack.get(TimeStoneRegistry.CHARGE.get());
        int c = v == null ? 0 : Math.max(0, v);
        return Math.min(c, capacity(stack));
    }

    public static void setCharge(ItemStack stack, int value) {
        stack.set(TimeStoneRegistry.CHARGE.get(), Math.max(0, Math.min(value, capacity(stack))));
    }

    /** Новая ёмкость; запас сверх неё срезается (здоровье упало). */
    private static void setCapacity(ItemStack stack, int value) {
        int current = charge(stack);
        stack.set(TimeStoneRegistry.CAPACITY.get(), Math.max(0, value));
        setCharge(stack, current);
    }

    // ── привязка к зоне ────────────────────────────────────────────────────

    /** id зоны, которую держит этот стек, либо -1. */
    public static int boundZone(ItemStack stack) {
        Integer id = stack.get(TimeStoneRegistry.ZONE.get());
        return id == null ? -1 : id;
    }

    public static void bind(ItemStack stack, int zoneId) {
        if (zoneId < 0) stack.remove(TimeStoneRegistry.ZONE.get());
        else stack.set(TimeStoneRegistry.ZONE.get(), zoneId);
    }

    /**
     * Камень в инвентаре, привязанный к этой зоне; протухшие привязки на
     * других камнях снимаются по дороге. Тот же приём, что
     * TimeDeviceItem#findBound.
     */
    public static @Nullable ItemStack findBound(Player player, int zoneId) {
        var inv = player.getInventory();
        final int size = inv.getContainerSize();
        ItemStack found = null;
        for (int i = 0; i < size; i++) {
            ItemStack s = inv.getItem(i);
            if (!(s.getItem() instanceof TimeStoneItem)) continue;
            int bound = boundZone(s);
            if (bound < 0) continue;
            if (bound == zoneId && found == null) found = s;
            else bind(s, -1);
        }
        return found;
    }

    // ── пассивная защита ───────────────────────────────────────────────────

    /** Суммарный запас всех камней в инвентаре — для правила иммунитета. */
    public static int totalCharge(Player player) {
        var inv = player.getInventory();
        final int size = inv.getContainerSize();
        long sum = 0;
        for (int i = 0; i < size; i++) {
            ItemStack s = inv.getItem(i);
            if (s.getItem() instanceof TimeStoneItem) sum += charge(s);
        }
        return (int) Math.min(sum, Integer.MAX_VALUE);
    }

    /** Снять запас с камней игрока по очереди. @return сколько сняли */
    public static int drainFrom(Player player, int amount) {
        var inv = player.getInventory();
        final int size = inv.getContainerSize();
        int left = amount;
        for (int i = 0; i < size && left > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (!(s.getItem() instanceof TimeStoneItem)) continue;
            int c = charge(s);
            if (c <= 0) continue;
            int taken = Math.min(c, left);
            setCharge(s, c - taken);
            left -= taken;
        }
        return amount - left;
    }

    /**
     * Камень сейчас держит носителя на ногах в чужой остановке: игрок внутри
     * зоны и сам ни одной не владеет. Владелец любой зоны и так не замерзает
     * (TimeStopManager#frozenIn), камню там делать нечего.
     */
    public static boolean shielding(ServerLevel level, Player player) {
        return TimeStopManager.ownedBy(level, player.getId()) == null
                && TimeStopManager.isInside(player);
    }

    /** Держит ли стек живую зону своего владельца. */
    private static boolean holdsLiveZone(ItemStack stack, ServerLevel level, Player player) {
        int bound = boundZone(stack);
        if (bound < 0) return false;
        TimeStopInstance own = TimeStopManager.ownedBy(level, player.getId());
        return own != null && own.id == bound && own.tierRank == TimeStopTier.STONE.rank;
    }

    /**
     * Ёмкость под носителя и перезарядка. Трату в остановке ведёт
     * {@link TimeStoneEvents}: ей нужно ловить и пропажу камня из инвентаря,
     * а inventoryTick в этот момент уже не зовётся.
     *
     * Замороженный чужой остановкой игрок не тикает — значит, и камень у него
     * не заряжается: для него время стоит.
     */
    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slotId, boolean isSelected) {
        if (level.isClientSide() || !(entity instanceof Player player)) return;
        if (!(level instanceof ServerLevel serverLevel)) return;

        int cap = capacityFor(player);
        if (cap != capacity(stack)) setCapacity(stack, cap);

        if (holdsLiveZone(stack, serverLevel, player)) return;
        if (boundZone(stack) >= 0) bind(stack, -1);

        // Камень работает щитом в чужой остановке — запас тратится, а не
        // копится. Иначе перезарядка (10 за тик) перекрывала бы трату (1 за тик).
        if (shielding(serverLevel, player)) return;

        if (player.tickCount % RECHARGE_INTERVAL != 0) return;
        int charge = charge(stack);
        if (charge >= cap) return;
        long next = (long) charge + (long) RECHARGE_FACTOR * RECHARGE_INTERVAL;
        setCharge(stack, (int) Math.min(next, cap));
    }

    // ── ПКМ ────────────────────────────────────────────────────────────────

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide()) {
            // Шифт — мгновенная остановка: цель берёт клиент из прицела, как в
            // ROTP, выполняет сервер по пакету (blink ниже).
            if (player.isShiftKeyDown()) {
                TimeStopBlinkClientHook.requestStoneBlink(hand);
            }
            return InteractionResultHolder.success(stack);
        }
        if (!(level instanceof ServerLevel serverLevel)) return InteractionResultHolder.pass(stack);

        // Своя остановка камня — снимаем, с шифтом или без. Выключить можно всегда.
        TimeStopInstance own = TimeStopManager.ownedBy(serverLevel, player.getId());
        if (own != null) {
            if (own.tierRank != TimeStopTier.STONE.rank) {
                // У игрока уже есть остановка другого источника (пульт, Metroman).
                // Камень её не трогает: борьбы уровней пока нет.
                message(player, "message.sable_compat.time_stone.other_active", ChatFormatting.GRAY);
                return InteractionResultHolder.fail(stack);
            }
            TimeStopManager.stopOwnedBy(serverLevel, player.getId());
            ItemStack bound = findBound(player, own.id);
            if (bound != null) bind(bound, -1);
            player.getCooldowns().addCooldown(this, DEBOUNCE_TICKS);
            sound(serverLevel, player, false);
            message(player, "message.sable_compat.time_stone.off", ChatFormatting.GRAY);
            return InteractionResultHolder.success(stack);
        }

        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }

        // Шифт без своей зоны — рывок, его выполнит пакет от клиента.
        if (player.isShiftKeyDown()) {
            return InteractionResultHolder.success(stack);
        }

        if (charge(stack) <= 0) {
            message(player, "message.sable_compat.time_stone.no_charge", ChatFormatting.RED);
            return InteractionResultHolder.fail(stack);
        }

        bind(stack, -1);
        TimeStopInstance inst = TimeStopManager.start(serverLevel, player,
                0, TimeStopConfig.chunkRange, true, TimeStopTier.STONE);
        if (inst == null) {
            message(player, "message.sable_compat.time_stone.rejected", ChatFormatting.RED);
            return InteractionResultHolder.fail(stack);
        }

        bind(stack, inst.id);
        player.getCooldowns().addCooldown(this, DEBOUNCE_TICKS);
        sound(serverLevel, player, true);
        return InteractionResultHolder.success(stack);
    }

    /**
     * Мгновенная остановка камнем. Вызывается из TimeStopBlinkPacket.
     *
     * Как у пульта: запас не запрещает рывок, а укорачивает его — потолок
     * подразумеваемых тиков равен тому, сколько оплачивает запас, списывается
     * ровно за пройденное.
     */
    public static boolean blink(ServerPlayer player, InteractionHand hand, BlinkTarget target) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(stack.getItem() instanceof TimeStoneItem self)) return false;
        if (player.getCooldowns().isOnCooldown(self)) return false;
        if (!TimeStopBlink.allowedAt(player)) return false;

        int charge = charge(stack);
        int maxTicks = (int) (charge / BLINK_COST_FACTOR);
        if (maxTicks < 1) {
            message(player, "message.sable_compat.time_stone.no_charge", ChatFormatting.RED);
            return false;
        }

        TimeStopBlink.Plan plan = TimeStopBlink.plan(player, target, maxTicks);
        int cost = Mth.ceil(plan.impliedTicks() * BLINK_COST_FACTOR);
        setCharge(stack, charge - cost);
        TimeStopBlink.perform(player, plan);
        player.getCooldowns().addCooldown(self, DEBOUNCE_TICKS);
        return true;
    }

    static void message(Player player, String key, ChatFormatting color) {
        player.displayClientMessage(Component.translatable(key).withStyle(color), true);
    }

    static void sound(ServerLevel level, Player player, boolean on) {
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                on ? SoundEvents.BEACON_ACTIVATE : SoundEvents.BEACON_DEACTIVATE,
                SoundSource.PLAYERS, 0.4F, on ? 1.6F : 1.2F);
    }

    // ── полоска ────────────────────────────────────────────────────────────

    /** Видна всегда, когда ёмкость известна: это и есть шкала времени камня. */
    @Override
    public boolean isBarVisible(ItemStack stack) {
        return capacity(stack) > 0;
    }

    @Override
    public int getBarWidth(ItemStack stack) {
        int cap = capacity(stack);
        if (cap <= 0) return 0;
        return Math.round(13.0F * charge(stack) / cap);
    }

    @Override
    public int getBarColor(ItemStack stack) {
        return BAR_COLOR;
    }

    /**
     * Запас меняется каждый тик, а смена компонентов у предмета в руке по
     * умолчанию запускает анимацию «достал заново»
     * (IItemExtension#shouldCauseReequipAnimation сравнивает стеки целиком).
     * Камень дёргался бы в руке всю остановку и всю перезарядку.
     */
    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || !ItemStack.isSameItem(oldStack, newStack);
    }

    /** По той же причине не сбрасываем копание блока. */
    @Override
    public boolean shouldCauseBlockBreakReset(ItemStack oldStack, ItemStack newStack) {
        return !newStack.is(oldStack.getItem());
    }

    // ── вид ────────────────────────────────────────────────────────────────

    /** Блеск зачарования — как у givetimestone (Enchantments:[{}]). */
    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    /** Имя зелёным жирным — как у givetimestone ("color":"green","bold":true). */
    @Override
    public Component getName(ItemStack stack) {
        return super.getName(stack).copy().withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        int cap = capacity(stack);
        lines.add(Component.translatable("tooltip.sable_compat.time_stone.charge",
                        charge(stack) / 20, cap / 20)
                .withStyle(ChatFormatting.DARK_GREEN));
        lines.add(Component.translatable("tooltip.sable_compat.time_stone.recharge",
                        cap / RECHARGE_FACTOR / 20)
                .withStyle(ChatFormatting.GRAY));
        lines.add(Component.translatable("tooltip.sable_compat.time_stone.rule")
                .withStyle(ChatFormatting.DARK_GRAY));
        lines.add(Component.translatable("tooltip.sable_compat.time_stone.shield")
                .withStyle(ChatFormatting.DARK_AQUA));
        lines.add(Component.translatable("tooltip.sable_compat.time_stone.drop")
                .withStyle(ChatFormatting.DARK_GRAY));
        lines.add(Component.translatable("tooltip.sable_compat.time_stone.hint")
                .withStyle(ChatFormatting.DARK_GRAY));
    }

    // ── камень на земле ────────────────────────────────────────────────────

    @Override
    public boolean hasCustomEntity(ItemStack stack) {
        return true;
    }

    /**
     * Только на сервере. Клиенту подменять нечего: ItemEntity, отменённый на
     * сервере, до клиента не доходит, а наша сущность придёт к нему обычной
     * синхронизацией.
     */
    @Override
    public @Nullable Entity createEntity(Level level, Entity location, ItemStack stack) {
        if (level.isClientSide()) return null;
        return TimeStoneEntity.at(level, location, stack);
    }
}
