package com.invfix.infinity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;

/**
 * Камень, лежащий на земле.
 *
 * Порт связки из items/time.mcfunction оригинала: невидимая маленькая стойка
 * (Invulnerable, Tags time_stone_ground) с рендер-слоем камня и сущность
 * interaction на ней. Поведение то же:
 *  - неуязвим, не исчезает со временем, не горит;
 *  - сам не подбирается, воронки его не видят — только ПКМ, и тогда камень
 *    уходит в инвентарь (give), а если места нет — выпадает под ноги;
 *  - разворачивается к игроку, подошедшему вплотную (tp ... facing entity @p).
 *
 * Отличие одно: в оригинале замена срабатывала, только если в 8 блоках был
 * игрок (сканирование @e раз в тик). Здесь — всегда и сразу, через
 * IItemExtension#createEntity, без сканирования.
 *
 * Стек хранится целиком, а не просто «тут камень»: всё, что потом будет жить
 * в компонентах предмета (заряд, привязки), переживёт и бросок, и сейв.
 */
public class TimeStoneEntity extends Entity {

    private static final EntityDataAccessor<ItemStack> DATA_ITEM =
            SynchedEntityData.defineId(TimeStoneEntity.class, EntityDataSerializers.ITEM_STACK);

    /** Радиус, в котором камень разворачивается к игроку. В оригинале 0.5–1 блок. */
    private static final double FACE_PLAYER_RADIUS = 1.0;

    public TimeStoneEntity(EntityType<? extends TimeStoneEntity> type, Level level) {
        super(type, level);
        this.setInvulnerable(true);
    }

    /** Камень на месте брошенного предмета. Скорость не наследуется — как у стойки из оригинала. */
    public static TimeStoneEntity at(Level level, Entity location, ItemStack stack) {
        TimeStoneEntity e = new TimeStoneEntity(TimeStoneRegistry.TIME_STONE_ENTITY.get(), level);
        e.setPos(location.getX(), location.getY(), location.getZ());
        e.setYRot(location.getYRot());
        e.setItem(stack.copy());
        return e;
    }

    public ItemStack getItem() {
        return this.entityData.get(DATA_ITEM);
    }

    public void setItem(ItemStack stack) {
        this.entityData.set(DATA_ITEM, stack);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_ITEM, ItemStack.EMPTY);
    }

    @Override
    public void tick() {
        super.tick();

        // Падение с трением — как у ItemEntity, без плавучести: стойка из
        // оригинала в воде тонет.
        Vec3 v = this.getDeltaMovement();
        if (!this.isNoGravity()) v = v.add(0.0, -0.04, 0.0);
        this.move(MoverType.SELF, v);
        v = this.getDeltaMovement();
        double friction = this.onGround() ? 0.5 : 0.98;
        v = v.multiply(friction, 0.98, friction);
        if (this.onGround() && v.y < 0.0) v = v.multiply(1.0, -0.5, 1.0);
        this.setDeltaMovement(v);

        if (this.level().isClientSide()) return;

        if (this.getItem().isEmpty()) {
            this.discard();
            return;
        }

        Player near = this.level().getNearestPlayer(this, FACE_PLAYER_RADIUS);
        if (near != null) {
            double dx = near.getX() - this.getX();
            double dz = near.getZ() - this.getZ();
            if (dx * dx + dz * dz > 1.0e-6) {
                this.setYRot((float) Math.toDegrees(Mth.atan2(dz, dx)) - 90.0F);
            }
        }
    }

    /** Подбор только правой кнопкой — роль сущности interaction из оригинала. */
    @Override
    public @NotNull InteractionResult interact(@NotNull Player player, @NotNull InteractionHand hand) {
        if (player.isSpectator() || this.isRemoved()) return InteractionResult.PASS;
        if (this.level().isClientSide()) return InteractionResult.SUCCESS;

        ItemStack stack = this.getItem().copy();
        this.discard();
        if (stack.isEmpty()) return InteractionResult.PASS;

        // Выброшенный и подобранный камень пуст. Привязка к зоне тоже уходит:
        // зону сняли ещё в тот тик, когда камень покинул инвентарь.
        TimeStoneItem.setCharge(stack, 0);
        TimeStoneItem.bind(stack, -1);

        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.2F,
                ((this.random.nextFloat() - this.random.nextFloat()) * 0.7F + 1.0F) * 2.0F);
        return InteractionResult.CONSUME;
    }

    /** Цель для прицела, иначе ПКМ по камню не попадёт. */
    @Override
    public boolean isPickable() {
        return !this.isRemoved();
    }

    /** Invulnerable:1b оригинала. Удалить можно только /kill. */
    @Override
    public boolean hurt(@NotNull DamageSource source, float amount) {
        return false;
    }

    @Override
    protected void addAdditionalSaveData(@NotNull CompoundTag tag) {
        tag.put("Item", this.getItem().saveOptional(this.registryAccess()));
    }

    @Override
    protected void readAdditionalSaveData(@NotNull CompoundTag tag) {
        this.setItem(ItemStack.parseOptional(this.registryAccess(), tag.getCompound("Item")));
    }
}
