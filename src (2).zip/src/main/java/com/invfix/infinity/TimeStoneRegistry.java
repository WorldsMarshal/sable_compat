package com.invfix.infinity;

import com.invfix.timestop.TimeStopExemptions;
import com.invfix.timestop.TimeStopTier;
import com.mojang.serialization.Codec;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Камень Времени: предмет, сущность «камень на земле» и компоненты стека
 * (запас остановленного времени, ёмкость, привязка к зоне).
 */
public final class TimeStoneRegistry {

    private static final String MODID = "sable_compat";

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, MODID);
    public static final DeferredRegister<DataComponentType<?>> COMPONENTS =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, MODID);

    /**
     * Запас остановленного времени, тиков. Синхронизируется — по нему клиент
     * рисует полоску.
     */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> CHARGE =
            COMPONENTS.register("time_stone_charge", () -> DataComponentType.<Integer>builder()
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT)
                    .build());

    /**
     * Ёмкость, тиков. Зависит от здоровья носителя, поэтому живёт на стеке:
     * у Item#getBarWidth нет доступа к игроку, а полоска должна рисоваться
     * и в сундуке, и в чужом инвентаре.
     */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> CAPACITY =
            COMPONENTS.register("time_stone_capacity", () -> DataComponentType.<Integer>builder()
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT)
                    .build());

    /** id зоны, которую держит этот стек, — как time_device_zone у пульта. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> ZONE =
            COMPONENTS.register("time_stone_zone", () -> DataComponentType.<Integer>builder()
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT)
                    .build());

    /** Свойства — из addon/infinity/items/time_stone.json оригинала. */
    public static final DeferredItem<TimeStoneItem> TIME_STONE =
            ITEMS.register("time_stone", () -> new TimeStoneItem(new Item.Properties()
                    .stacksTo(1)
                    .rarity(Rarity.EPIC)
                    .fireResistant()));

    /**
     * Габарит — под прицел: сам камень 3/16 блока, но в такой кубик трудно
     * попасть мышью. В оригинале interaction был шириной 0.4.
     */
    public static final DeferredHolder<EntityType<?>, EntityType<TimeStoneEntity>> TIME_STONE_ENTITY =
            ENTITIES.register("time_stone", () -> EntityType.Builder
                    .<TimeStoneEntity>of(TimeStoneEntity::new, MobCategory.MISC)
                    .sized(0.3F, 0.3F)
                    .fireImmune()
                    .noSummon()
                    .clientTrackingRange(8)
                    .updateInterval(2)
                    .build("time_stone"));

    private TimeStoneRegistry() {}

    public static void register(IEventBus modEventBus) {
        COMPONENTS.register(modEventBus);
        ITEMS.register(modEventBus);
        ENTITIES.register(modEventBus);
        modEventBus.addListener(TimeStoneRegistry::onBuildCreativeTabs);

        // Носитель камня не замирает в чужой остановке, пока в камне есть
        // время. Запас за это списывается — см. TimeStoneEvents.
        TimeStopExemptions.register("time_stone", TimeStopTier.STONE, (player, vars) ->
                TimeStoneItem.totalCharge(player) >= 1);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(TIME_STONE);
        }
    }
}
