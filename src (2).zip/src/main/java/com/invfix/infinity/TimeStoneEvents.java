package com.invfix.infinity;

import com.invfix.timestop.TimeStopInstance;
import com.invfix.timestop.TimeStopManager;
import com.invfix.timestop.TimeStopTier;
import net.minecraft.ChatFormatting;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Содержание зоны камня: тик остановки — тик запаса. И плата за пассивную
 * защиту в чужой остановке — по той же цене.
 *
 * Не в Item#inventoryTick по той же причине, что у пульта (TimeDeviceEvents):
 * inventoryTick перестаёт зваться в ту секунду, когда камень покинул
 * инвентарь, а зону тогда надо снять сразу. Инвариант: зона уровня STONE живёт,
 * пока в инвентаре владельца лежит привязанный к ней камень с запасом.
 * Сторож менеджера (requiresUpkeep) страхует, если сюда перестали попадать.
 *
 * Владелец в своей остановке не заморожен, поэтому его тик идёт всегда.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class TimeStoneEvents {

    private TimeStoneEvents() {}

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(player.level() instanceof ServerLevel level)) return;
        if (!TimeStopManager.hasAny(level)) return;

        TimeStopInstance own = TimeStopManager.ownedBy(level, player.getId());
        if (own == null) {
            // Чужая остановка накрыла. Камень держит носителя на ногах
            // (правило time_stone) и платит за это тик запаса за тик.
            // Запас кончился — правило отпустит игрока на ближайшем
            // пересчёте исключений, и он замрёт.
            if (TimeStopManager.isInside(player)) TimeStoneItem.drainFrom(player, 1);
            return;
        }
        if (own.tierRank != TimeStopTier.STONE.rank) return;

        ItemStack stone = TimeStoneItem.findBound(player, own.id);
        if (stone == null) {
            // Выкинули, убрали в сундук, отдали. Держать зону нечем.
            stop(level, player, "message.sable_compat.time_stone.lost");
            return;
        }

        int charge = TimeStoneItem.charge(stone);
        if (charge <= 0) {
            TimeStoneItem.bind(stone, -1);
            stop(level, player, "message.sable_compat.time_stone.drained");
            return;
        }

        TimeStoneItem.setCharge(stone, charge - 1);
        TimeStopManager.heartbeat(level, own);
    }

    private static void stop(ServerLevel level, ServerPlayer player, String message) {
        TimeStopManager.stopOwnedBy(level, player.getId());
        player.getCooldowns().addCooldown(TimeStoneRegistry.TIME_STONE.get(), TimeStoneItem.DEBOUNCE_TICKS);
        TimeStoneItem.sound(level, player, false);
        TimeStoneItem.message(player, message, ChatFormatting.RED);
    }
}
