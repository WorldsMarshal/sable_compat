package com.invfix.infinity.client;

import com.invfix.infinity.TimeStoneEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

/**
 * Камень на земле — та же модель, что у предмета.
 *
 * В оригинале на земле рисуется space_stone_ground.geo.json с текстурой
 * item/time.png: куб 3x3x3 пикселя с теми же UV, что у модели предмета,
 * render_type "glow" и enchantment_glint. Поэтому здесь отдельной модели нет:
 * рисуется сам стек, полной яркостью (glow), а блеск даёт isFoil предмета.
 *
 * Смещение. Контекст NONE не применяет трансформ модели, но ItemRenderer
 * после трансформа всегда сдвигает на (-0.5, -0.5, -0.5) (ItemRenderer.render,
 * строка после handleCameraTransforms). Куб модели лежит в [7..10] по X/Z и
 * [0..3] по Y, то есть после сдвига центр по X/Z на +1/32, низ на -0.5.
 * Компенсируем: камень стоит на земле ровно по центру сущности.
 */
public class TimeStoneRenderer extends EntityRenderer<TimeStoneEntity> {

    private static final float CENTER_FIX = -1.0F / 32.0F;

    public TimeStoneRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public @NotNull ResourceLocation getTextureLocation(@NotNull TimeStoneEntity entity) {
        return TextureAtlas.LOCATION_BLOCKS;
    }

    @Override
    public void render(TimeStoneEntity entity, float entityYaw, float partialTicks, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        ItemStack stack = entity.getItem();
        if (!stack.isEmpty()) {
            poseStack.pushPose();
            poseStack.mulPose(Axis.YP.rotationDegrees(-entityYaw));
            poseStack.translate(CENTER_FIX, 0.5F, CENTER_FIX);
            Minecraft.getInstance().getItemRenderer().renderStatic(stack, ItemDisplayContext.NONE,
                    LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, poseStack, buffer,
                    entity.level(), entity.getId());
            poseStack.popPose();
        }
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }
}
