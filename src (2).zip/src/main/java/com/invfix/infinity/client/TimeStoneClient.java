package com.invfix.infinity.client;

import com.invfix.infinity.TimeStoneRegistry;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

public final class TimeStoneClient {

    private TimeStoneClient() {}

    public static void init(IEventBus modEventBus) {
        modEventBus.addListener(TimeStoneClient::onRegisterRenderers);
    }

    private static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(TimeStoneRegistry.TIME_STONE_ENTITY.get(), TimeStoneRenderer::new);
    }
}
