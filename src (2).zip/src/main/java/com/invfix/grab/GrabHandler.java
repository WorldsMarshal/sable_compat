package com.invfix.grab;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Grab &amp; Throw — автономный порт механики из мода The Boys (server/GrabHandler).
 *
 * Полностью самодостаточен: НЕ зависит от мода The Boys в рантайме и от его скилл-системы.
 * Скилл-гейт и множитель из скилла убраны; триггерится способностью Grab &amp; Throw из
 * invincible (эффект GRABN_THROW_ACTIVE → GrabTicksProcedure для держания; shift+кнопка →
 * ThrowPProcedure для броска), см. GrabTicksProcedureMixin / ThrowPProcedureMixin / GrabEvents.
 *
 * Жертва каждый тик телепортируется к точке перед игроком (позиция синкается штатно),
 * рука держателя разворачивается вперёд клиентским GrabArmMixin. Брошенная цель получает
 * урон при приземлении (tickLandingDamage).
 */
public final class GrabHandler {
    private GrabHandler() {}

    /** Фикс. множитель силы броска (в The Boys брался из скилла; тут автономно). */
    private static final float GRAB_MULTIPLIER = 1.0F;

    private static final Map<UUID, Integer> GRABBED_ENTITIES = new ConcurrentHashMap<>();
    private static final List<ThrownTracker> THROWN_TRACKING = new CopyOnWriteArrayList<>();

    public static void handleGrab(ServerPlayer player) {
        if (GRABBED_ENTITIES.containsKey(player.getUUID())) return;

        double reachDistance = player.entityInteractionRange() + 1.0;
        Vec3 eyePos = player.getEyePosition();
        Vec3 lookVec = player.getLookAngle();
        Vec3 endPos = eyePos.add(lookVec.scale(reachDistance));
        double r = 2.0;
        AABB searchBox = new AABB(
                Math.min(eyePos.x, endPos.x) - r, Math.min(eyePos.y, endPos.y) - r, Math.min(eyePos.z, endPos.z) - r,
                Math.max(eyePos.x, endPos.x) + r, Math.max(eyePos.y, endPos.y) + r, Math.max(eyePos.z, endPos.z) + r);

        List<LivingEntity> potentialTargets = player.level().getEntitiesOfClass(
                LivingEntity.class, searchBox, e -> e != player && e.isAlive());

        LivingEntity target = null;
        double closestDistance = Double.MAX_VALUE;
        for (LivingEntity entity : potentialTargets) {
            AABB entityBox = entity.getBoundingBox().inflate(0.3);
            Optional<Vec3> hit = entityBox.clip(eyePos, endPos);
            if (hit.isPresent()) {
                double dist = eyePos.distanceToSqr(hit.get());
                if (dist < closestDistance) {
                    closestDistance = dist;
                    target = entity;
                }
            }
        }

        if (target != null) {
            GRABBED_ENTITIES.put(player.getUUID(), target.getId());
            teleportEntityToHand(player, target);
            PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                    player, new GrabSyncPacket(player.getId(), target.getId(), true), new CustomPacketPayload[0]);
            player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.PLAYER_ATTACK_WEAK, SoundSource.PLAYERS, 1.0F, 0.6F);
        }
    }

    public static void handleHoldTick(ServerPlayer player) {
        Integer entityId = GRABBED_ENTITIES.get(player.getUUID());
        if (entityId == null) return;
        Entity entity = player.level().getEntity(entityId);
        if (entity != null && entity.isAlive()) {
            teleportEntityToHand(player, entity);
            entity.setDeltaMovement(Vec3.ZERO);
            entity.fallDistance = 0.0F;
            if (entity instanceof LivingEntity living) {
                living.hurtTime = 0;
            }
        } else {
            handleRelease(player);
        }
    }

    public static void handleThrow(ServerPlayer player) {
        Integer entityId = GRABBED_ENTITIES.remove(player.getUUID());
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                player, new GrabSyncPacket(player.getId(), entityId != null ? entityId : -1, false), new CustomPacketPayload[0]);
        if (entityId == null) return;

        Entity entity = player.level().getEntity(entityId);
        if (entity != null && entity.isAlive()) {
            Vec3 lookVec = player.getLookAngle();
            double throwSpeed = 2.5 * GRAB_MULTIPLIER;
            entity.setDeltaMovement(lookVec.scale(throwSpeed));
            entity.hurtMarked = true;
            if (player.level() instanceof ServerLevel serverLevel) {
                THROWN_TRACKING.add(new ThrownTracker(
                        entity.getId(), player.getId(), serverLevel, serverLevel.getGameTime(), GRAB_MULTIPLIER));
            }
            player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1.0F, 0.8F);
        }
    }

    public static void handleRelease(ServerPlayer player) {
        Integer entityId = GRABBED_ENTITIES.remove(player.getUUID());
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                player, new GrabSyncPacket(player.getId(), entityId != null ? entityId : -1, false), new CustomPacketPayload[0]);
        if (entityId != null) {
            Entity entity = player.level().getEntity(entityId);
            if (entity != null) {
                entity.setDeltaMovement(0.0, -0.1, 0.0);
                entity.hurtMarked = true;
            }
        }
    }

    private static void teleportEntityToHand(ServerPlayer player, Entity entity) {
        Vec3 eyePos = player.getEyePosition();
        Vec3 lookVec = player.getLookAngle();
        Vec3 handPos = eyePos.add(lookVec.scale(1.5));
        entity.teleportTo(handPos.x, handPos.y - (double) entity.getBbHeight() * 0.5, handPos.z);
        entity.setDeltaMovement(Vec3.ZERO);
        entity.fallDistance = 0.0F;
    }

    public static void tickLandingDamage() {
        THROWN_TRACKING.removeIf(tracker -> {
            Entity entity = tracker.level.getEntity(tracker.entityId);
            if (entity == null || entity.isRemoved()) return true;
            long elapsed = tracker.level.getGameTime() - tracker.throwTick;
            if (elapsed > 100L) return true;
            if (elapsed < 3L) return false;
            if (!entity.onGround() && !entity.isInWater()) return false;

            if (entity instanceof LivingEntity living) {
                Entity thrower = tracker.level.getEntity(tracker.throwerId);
                living.invulnerableTime = 0;
                living.hurtTime = 0;
                if (thrower instanceof ServerPlayer sp) {
                    living.hurt(sp.damageSources().playerAttack(sp), 20.0F * tracker.damageMultiplier);
                } else {
                    living.hurt(tracker.level.damageSources().fall(), 20.0F * tracker.damageMultiplier);
                }
            }

            double x = entity.getX(), y = entity.getY(), z = entity.getZ();
            float w = entity.getBbWidth();
            tracker.level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y + 0.2, z, 30, w * 1.5, 0.4, w * 1.5, 0.06);
            tracker.level.sendParticles(ParticleTypes.CLOUD, x, y + 0.3, z, 20, w, 0.5, w, 0.04);
            tracker.level.playSound(null, x, y, z, (SoundEvent) SoundEvents.GENERIC_EXPLODE.value(),
                    SoundSource.PLAYERS, 0.4F, 0.8F);
            return true;
        });
    }

    public static boolean isGrabbing(UUID playerId) {
        return GRABBED_ENTITIES.containsKey(playerId);
    }

    public static Integer getGrabbedEntityId(UUID playerId) {
        return GRABBED_ENTITIES.get(playerId);
    }

    public static void onPlayerLogout(ServerPlayer player) {
        GRABBED_ENTITIES.remove(player.getUUID());
    }

    private record ThrownTracker(int entityId, int throwerId, ServerLevel level, long throwTick, float damageMultiplier) {}
}