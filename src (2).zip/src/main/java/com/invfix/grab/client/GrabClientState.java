package com.invfix.grab.client;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Клиентское состояние захвата (порт The Boys): какой игрок какую сущность держит.
 * Заполняется GrabSyncPacket, читается GrabArmMixin для позы руки.
 */
public final class GrabClientState {
    private GrabClientState() {}

    private static final Map<Integer, Integer> GRABBING = new ConcurrentHashMap<>();

    public static void setGrabbing(int playerId, int targetEntityId) { GRABBING.put(playerId, targetEntityId); }
    public static void clearGrabbing(int playerId) { GRABBING.remove(playerId); }
    public static boolean isGrabbing(int playerId) { return GRABBING.containsKey(playerId); }
    public static Integer getTargetEntityId(int playerId) { return GRABBING.get(playerId); }
    public static void clearAll() { GRABBING.clear(); }
}