package com.invfix.grab;

import net.mcreator.invincibleinc.init.InvincibleIncModMobEffects;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Жизненный цикл Grab &amp; Throw:
 *  - ServerTickEvent.Post: урон/частицы при приземлении брошенных целей;
 *  - PlayerTickEvent.Post: релиз цели, когда родной эффект GRABN_THROW_ACTIVE истёк
 *    (держание гонится через GrabTicksProcedure только пока эффект активен);
 *  - logout: очистка.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class GrabEvents {
    private GrabEvents() {}

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        GrabHandler.tickLandingDamage();
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player p = event.getEntity();
        if (!(p instanceof ServerPlayer sp)) return;
        if (GrabHandler.isGrabbing(sp.getUUID()) && !sp.hasEffect(InvincibleIncModMobEffects.GRABN_THROW_ACTIVE)) {
            GrabHandler.handleRelease(sp);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            GrabHandler.onPlayerLogout(sp);
        }
    }
}