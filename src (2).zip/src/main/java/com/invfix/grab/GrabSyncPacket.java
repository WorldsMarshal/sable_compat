package com.invfix.grab;

import com.invfix.grab.client.GrabClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Сервер → Клиенты: состояние захвата (кто кого держит) для рендера руки/жертвы.
 * Порт GrabSyncPacket из The Boys, namespace sable_compat.
 */
public record GrabSyncPacket(int playerId, int targetEntityId, boolean grabbing) implements CustomPacketPayload {

    public static final Type<GrabSyncPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("sable_compat", "grab_sync"));

    public static final StreamCodec<FriendlyByteBuf, GrabSyncPacket> STREAM_CODEC =
            StreamCodec.of(GrabSyncPacket::encode, GrabSyncPacket::decode);

    private static void encode(FriendlyByteBuf buf, GrabSyncPacket p) {
        buf.writeVarInt(p.playerId);
        buf.writeVarInt(p.targetEntityId);
        buf.writeBoolean(p.grabbing);
    }

    private static GrabSyncPacket decode(FriendlyByteBuf buf) {
        return new GrabSyncPacket(buf.readVarInt(), buf.readVarInt(), buf.readBoolean());
    }

    @Override public Type<GrabSyncPacket> type() { return TYPE; }

    @OnlyIn(Dist.CLIENT)
    public static void handleClient(GrabSyncPacket packet, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (packet.grabbing()) {
                GrabClientState.setGrabbing(packet.playerId(), packet.targetEntityId());
            } else {
                GrabClientState.clearGrabbing(packet.playerId());
            }
        });
    }
}