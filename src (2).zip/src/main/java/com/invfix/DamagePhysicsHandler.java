package com.invfix;

import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingKnockBackEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;

@EventBusSubscriber(modid = InvincibleFix.MOD_ID)
public class DamagePhysicsHandler {

    // ── ОТБРАСЫВАНИЕ ──────────────────────────────────────
    //
    // Не используем ThreadLocal — порядок срабатывания LivingIncomingDamageEvent
    // и LivingKnockBackEvent внутри одного хёрта не гарантирован.
    //
    // Вместо этого сравниваем DTstat напрямую с event.getStrength():
    //   event.getStrength() — сила отбрасывания (обычный удар ≈ 0.4, спринт ≈ 0.8)
    //   DTstat — броня игрока = currentDura * 0.5 * statMultiplier
    //
    // Отбрасывание отменяется если: DTstat >= strength * 100
    //   Обычный удар (0.4): нужно DTstat >= 40 → currentDura >= 80
    //   Спринт (0.8):       нужно DTstat >= 80 → currentDura >= 160
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onKnockBack(LivingKnockBackEvent event) {
        double dtstat = getDTstat(event.getEntity());
        if (dtstat <= 0) return;

        if (dtstat >= event.getStrength() * 100.0) {
            event.setCanceled(true);
        }
    }

    // ── ОТСКОК СТРЕЛ ──────────────────────────────────────
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        if (!(event.getRayTraceResult() instanceof EntityHitResult hitResult)) return;
        Entity defender = hitResult.getEntity();

        double dtstat = getDTstat(defender);
        if (dtstat <= 0) return;

        // Playful/Threatening Mode у ЗАЩИЩАЮЩЕГОСЯ: снаряд не отскакивает,
        // а честно попадает — урон уйдёт в дюру-щит обычным конвейером
        // Invincible (LivingIncomingDamage), мы просто не вмешиваемся.
        if (com.invfix.threatmode.ThreatModeState.isHeld(defender)) return;

        Projectile projectile = event.getProjectile();
        if (!(projectile instanceof AbstractArrow arrow)) return;

        double arrowDamage = arrow.getBaseDamage();

        if (dtstat >= arrowDamage * 3.0) {
            event.setCanceled(true);
            Vec3 delta = projectile.getDeltaMovement();
            projectile.setDeltaMovement(delta.scale(-0.2));
            detachOwner(projectile);
        }
    }

    // Отвязываем стрелка у отрикошеченной стрелы.
    //
    // Ваниль: setOwner(null) безопасен. Но некоторые модовые стрелы переопределяют
    // setOwner и разыменовывают аргумент без проверки на null — например
    // MineColonies FireArrowEntity.setOwner сразу делает shooter.getX(), из-за чего
    // setOwner(null) кидает NPE прямо в тике сущности и крашит сервер.
    //
    // Отвязка владельца — не критична для логики отскока, поэтому защищаемся:
    // если у конкретного снаряда setOwner не null-safe, просто оставляем владельца.
    private static void detachOwner(Projectile projectile) {
        if (projectile.getOwner() == null) return;
        try {
            projectile.setOwner(null);
        } catch (Exception ignored) {
            // Модовый снаряд с не-null-safe setOwner (напр. minecolonies:firearrow) —
            // оставляем владельца как есть, чтобы не уронить тик.
        }
    }

    private static double getDTstat(Entity entity) {
        if (entity == null) return 0;
        try {
            InvincibleIncModVariables.PlayerVariables vars =
                    entity.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
            if ("§f§lHuman".equals(vars.Race)) return 0;
            return vars.DTstat;
        } catch (Exception e) {
            return 0;
        }
    }
}