package com.invfix.cbc;

import dan200.computercraft.api.lua.IArguments;
import dan200.computercraft.api.lua.LuaException;
import dan200.computercraft.api.lua.LuaFunction;
import dan200.computercraft.api.peripheral.IComputerAccess;
import dan200.computercraft.api.peripheral.IPeripheral;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nullable;
import rbasamoyai.createbigcannons.cannon_control.cannon_mount.CannonMountBlockEntity;

/**
 * ComputerCraft peripheral for the CBC cannon mount: exact angles in, exact
 * angles out. Replaces the clutch/gearshift + Display Link rig entirely.
 *
 * Lua type: "cannon_mount"
 */
public class CannonMountPeripheral implements IPeripheral {

    private final CannonMountBlockEntity be;

    public CannonMountPeripheral(CannonMountBlockEntity be) {
        this.be = be;
    }

    private SmartCannonMount smart() throws LuaException {
        if (this.be instanceof SmartCannonMount s) return s;
        throw new LuaException("cannon mount is not computer-aimable");
    }

    // ---------- reading ----------

    /** Current yaw in degrees, full float precision. */
    @LuaFunction(mainThread = true)
    public final double getYaw() throws LuaException { return smart().invfix$yaw(); }

    /** Current elevation in degrees, full float precision. */
    @LuaFunction(mainThread = true)
    public final double getPitch() throws LuaException { return smart().invfix$pitch(); }

    /** {yaw, pitch} in one call, so both come from the same tick. */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getAngles() throws LuaException {
        SmartCannonMount s = smart();
        Map<String, Object> m = new HashMap<>();
        m.put("yaw", s.invfix$yaw());
        m.put("pitch", s.invfix$pitch());
        m.put("aiming", s.invfix$isAiming());
        return m;
    }

    /** True while still slewing toward the commanded angles. */
    @LuaFunction(mainThread = true)
    public final boolean isAiming() throws LuaException { return smart().invfix$isAiming(); }

    /** True when a cannon is assembled on the mount. */
    @LuaFunction(mainThread = true)
    public final boolean isAssembled() throws LuaException { return smart().invfix$isAssembled(); }

    /** {min, max} elevation of the assembled cannon, or nil. */
    @LuaFunction(mainThread = true)
    @Nullable
    public final Map<String, Object> getPitchLimits() throws LuaException {
        float[] lim = smart().invfix$pitchLimits();
        if (lim == null) return null;
        Map<String, Object> m = new HashMap<>();
        m.put("min", lim[0]);
        m.put("max", lim[1]);
        return m;
    }

    /**
     * World position of the mount pivot. Works while the rig drives around on
     * a Sable vehicle - the coordinates are projected out of the sublevel.
     */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getWorldPosition() throws LuaException {
        double[] p = smart().invfix$worldPos();
        Map<String, Object> m = new HashMap<>();
        m.put("x", p[0]);
        m.put("y", p[1]);
        m.put("z", p[2]);
        return m;
    }

    /**
     * World position of the pivot: {@code up} blocks above the mount along the
     * hull's own up axis, so a tilted platform is handled correctly.
     */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getPivot(double up) throws LuaException {
        double[] p = smart().invfix$pivotPos(up);
        Map<String, Object> m = new HashMap<>();
        m.put("x", p[0]);
        m.put("y", p[1]);
        m.put("z", p[2]);
        return m;
    }

    /** Hull heading in world space (MC yaw, 0 = +Z). Zero for a static build. */
    @LuaFunction(mainThread = true)
    public final double getHullYaw() throws LuaException { return smart().invfix$hullYaw(); }

    /**
     * World azimuth the barrel points at, hull rotation included. This is the
     * number the fire solution needs; no lodestone or calibration required.
     */
    @LuaFunction(mainThread = true)
    public final double getBoreAzimuth() throws LuaException {
        SmartCannonMount s = smart();
        double az = s.invfix$hullYaw() + s.invfix$yaw();
        return ((az + 540.0) % 360.0) - 180.0;
    }

    /**
     * Where the barrel really points in the world: {az, elev} in degrees, with
     * the hull's yaw, pitch and roll all applied. Use this, not getPitch(), for
     * a fire solution on a vehicle that may be tilted.
     */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getBoreWorld() throws LuaException {
        double[] b = smart().invfix$boreWorld();
        Map<String, Object> m = new HashMap<>();
        m.put("az", b[0]);
        m.put("elev", b[1]);
        return m;
    }

    /**
     * Lay the barrel on an absolute world azimuth/elevation. Hull tilt is
     * compensated automatically.
     */
    @LuaFunction(mainThread = true)
    public final void aimWorld(double azDeg, double elevDeg) throws LuaException {
        smart().invfix$aimWorld(azDeg, elevDeg);
    }

    /** True when riding a Sable sublevel (vehicle) rather than sitting in the world. */
    @LuaFunction(mainThread = true)
    public final boolean isOnSublevel() throws LuaException { return smart().invfix$onSublevel(); }

    // ---------- commanding ----------

    /** Slew to an absolute yaw. Needs rotation on the yaw shaft. */
    @LuaFunction(mainThread = true)
    public final void setYaw(double deg) throws LuaException {
        smart().invfix$setTargetYaw((float) deg);
    }

    /** Slew to an elevation; clamped to the cannon's limits. Needs rotation on the pitch shaft. */
    @LuaFunction(mainThread = true)
    public final void setPitch(double deg) throws LuaException {
        smart().invfix$setTargetPitch((float) deg);
    }

    /** Both axes at once. */
    @LuaFunction(mainThread = true)
    public final void aim(double yawDeg, double pitchDeg) throws LuaException {
        SmartCannonMount s = smart();
        s.invfix$setTargetYaw((float) yawDeg);
        s.invfix$setTargetPitch((float) pitchDeg);
    }

    /**
     * Hold an absolute world direction. Re-solved from the hull pose every
     * tick (20 Hz), so the barrel stays put while the platform wobbles - the
     * fix for a levitite airframe that never quite settles.
     */
    @LuaFunction(mainThread = true)
    public final void holdWorld(double azDeg, double elevDeg) throws LuaException {
        smart().invfix$holdWorld(azDeg, elevDeg);
    }

    /** Drop the world hold; the mount keeps whatever angles it has. */
    @LuaFunction(mainThread = true)
    public final void releaseWorld() throws LuaException {
        smart().invfix$holdWorld(null, null);
    }

    @LuaFunction(mainThread = true)
    public final boolean isHoldingWorld() throws LuaException {
        return smart().invfix$isHoldingWorld();
    }

    /** How far the barrel sits off the held direction: {az=, elev=, total=}. */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getWorldError() throws LuaException {
        double[] e = smart().invfix$worldError();
        double[] l = smart().invfix$launchError();
        Map<String, Object> m = new HashMap<>();
        m.put("az", e[0]);
        m.put("elev", e[1]);
        m.put("total", Math.sqrt(e[0]*e[0] + e[1]*e[1]));
        // The error that actually decides where the shell goes: the barrel's
        // orientation as of last tick, which is what CBC hands the projectile.
        // Watch this one, not the pair above.
        m.put("laz", l[0]);
        m.put("lelev", l[1]);
        m.put("ltotal", Math.sqrt(l[0]*l[0] + l[1]*l[1]));
        // Launch speed rides along because the aiming loop polls this every
        // iteration anyway. It is a field the mount already refreshed this tick,
        // so it costs nothing here and saves the caller a separate round trip
        // for a number that goes stale in a few ticks on a moving hull.
        m.put("lspeed", smart().invfix$launchSpeed());
        return m;
    }

    /**
     * The velocity the hull hands the shell at the muzzle, blocks per tick.
     * This is what makes two identical shots from a drifting platform land in
     * different places: the shell keeps it for the whole flight.
     */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getHullVelocity() throws LuaException {
        double[] v = smart().invfix$hullVelocity();
        Map<String, Object> m = new HashMap<>();
        m.put("x", v[0]);
        m.put("y", v[1]);
        m.put("z", v[2]);
        m.put("speed", Math.sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]));
        return m;
    }

    /**
     * Firing gate per axis, in degrees. Azimuth and elevation buy different
     * numbers of blocks per degree, so a round gate wastes accuracy on one axis
     * and throws it away on the other. Set both to the angle worth the same
     * miss; pass 0,0 to go back to the single scalar tolerance.
     */
    @LuaFunction(mainThread = true)
    public final void setFireTolAxes(double tolAz, double tolElev) throws LuaException {
        smart().invfix$setFireTolAxes(tolAz, tolElev);
    }

    /**
     * Both ways of measuring the hull's contribution, blocks/tick. If sable is
     * zero while fd is not, the physics-handle lookup is failing and only the
     * pose difference is keeping the compensation alive.
     */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getHullVelocitySources() throws LuaException {
        double[] v = smart().invfix$hullVelocitySources();
        Map<String, Object> m = new HashMap<>();
        m.put("sx", v[0]); m.put("sy", v[1]); m.put("sz", v[2]);
        m.put("fx", v[3]); m.put("fy", v[4]); m.put("fz", v[5]);
        m.put("sable", Math.sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]));
        m.put("fd",    Math.sqrt(v[3]*v[3] + v[4]*v[4] + v[5]*v[5]));
        return m;
    }

    /** {az, elev, speed} the shell would actually leave with right now. */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getLaunchVector() throws LuaException {
        double[] v = smart().invfix$launchVector();
        Map<String, Object> m = new HashMap<>();
        m.put("az", v[0]);
        m.put("elev", v[1]);
        m.put("speed", v[2]);
        return m;
    }

    /**
     * Hold so the SHELL flies along this world direction. Unlike holdWorld,
     * which aims the barrel, this re-solves the hull's contribution every tick,
     * so the correction stays fresh no matter how the platform is moving.
     */
    @LuaFunction(mainThread = true)
    public final void holdLaunch(double az, double elev) throws LuaException {
        smart().invfix$holdLaunch(az, elev);
    }

    /** Tell the mount the muzzle speed and geometry it needs for that. */
    @LuaFunction(mainThread = true)
    public final void setBallistics(double v0, double pivotUp, double barrelLen) throws LuaException {
        smart().invfix$setBallistics(v0, pivotUp, barrelLen);
    }

    /** Launch speed implied by the current solution - V0 only on a still hull. */
    @LuaFunction(mainThread = true)
    public final double getLaunchSpeed() throws LuaException {
        return smart().invfix$launchSpeed();
    }

    /**
     * Удержание вылета вместе с опорным решением для поправки на каждом тике.
     * Заменяет holdLaunch: углы ставятся в том же задании, что и опора, чтобы
     * между ними не оказалось тика без поправки.
     *
     * Аргументы по порядку: tx ty tz - точка прицеливания в мире; tvx tvy tvz -
     * её скорость, блоков в тик (нули для неподвижной); t0 - игровой тик, к
     * которому относится точка; az0 el0 - решение; R0 dy0 s0 - дальность по
     * горизонтали, превышение цели над срезом и скорость вылета, с которыми оно
     * получено; cR cDy cS - на сколько градусов сдвинуть угол места на блок
     * дальности, на блок превышения и на блок в тик скорости.
     *
     * Без аргументов снимает поправку.
     */
    @LuaFunction(mainThread = true)
    public final void setLaunchRef(IArguments args) throws LuaException {
        if (args.count() == 0 || args.get(0) == null) {
            smart().invfix$setLaunchRef(null);
            return;
        }
        double[] r = new double[15];
        for (int i = 0; i < 15; i++) r[i] = args.getFiniteDouble(i);
        smart().invfix$setLaunchRef(r);
    }

    /** {active, dEl, dR, dDy, dS}: что поправка сделала на последнем тике. */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getLaunchRef() throws LuaException {
        double[] v = smart().invfix$launchRefState();
        Map<String, Object> m = new HashMap<>();
        m.put("active", v[0] != 0.0);
        m.put("dEl", v[1]);
        m.put("dR", v[2]);
        m.put("dDy", v[3]);
        m.put("dS", v[4]);
        return m;
    }

    /**
     * Заряжена ли пушка: {assembled, medium, closed, round, loaded, item}.
     * loaded - в затворе живой патрон и затвор закрыт, то есть выстрел сейчас
     * действительно вылетит.
     */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getLoadState() throws LuaException {
        return BreechProbe.state(this.be);
    }

    /**
     * Игровой тик мира.
     *
     * Нужен, чтобы привязать отметку радара к моменту выстрела: радар ставит на
     * трек игровой тик, и только в тех же единицах можно честно сказать, где
     * цель окажется, когда до неё долетит снаряд.
     */
    @LuaFunction(mainThread = true)
    public final double getGameTime() throws LuaException {
        return this.be.getLevel() != null ? (double) this.be.getLevel().getGameTime() : -1.0;
    }

    /**
     * What the tracking loop is asking of each shaft versus what the shaft can
     * give, deg/tick: {dyaw, dpitch, syaw, spitch}. Demand above supply is the
     * one failure the aiming maths cannot fix by itself.
     */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getTrackLoad() throws LuaException {
        double[] v = smart().invfix$trackLoad();
        Map<String, Object> m = new HashMap<>();
        m.put("dyaw", v[0]);
        m.put("dpitch", v[1]);
        m.put("syaw", v[2]);
        m.put("spitch", v[3]);
        return m;
    }

    /**
     * Freeze or release the barrel. Frozen, the mount keeps measuring the error
     * and keeps the trigger armed, but does not move: the hull's own swing does
     * the last fraction of a degree. Use it on an airframe where traversing
     * shifts the centre of mass and starts a fight between gun and hull.
     */
    @LuaFunction(mainThread = true)
    public final void setServo(boolean on) throws LuaException {
        smart().invfix$setServo(on);
    }

    @LuaFunction(mainThread = true)
    public final boolean getServo() throws LuaException {
        return smart().invfix$servoOn();
    }

    /** Aiming error below which the barrel is left alone, degrees. */
    @LuaFunction(mainThread = true)
    public final void setDeadband(double deg) throws LuaException {
        smart().invfix$setDeadband(deg);
    }

    @LuaFunction(mainThread = true)
    public final double getDeadband() throws LuaException {
        return smart().invfix$deadband();
    }

    /**
     * Ticks of hull rotation the setpoint is extrapolated by. 1 is correct and
     * is the default: the barrel angles set on one tick meet the hull pose of
     * the next.
     */
    @LuaFunction(mainThread = true)
    public final void setPoseLead(double ticks) throws LuaException {
        smart().invfix$setPoseLead(ticks);
    }

    @LuaFunction(mainThread = true)
    public final double getPoseLead() throws LuaException {
        return smart().invfix$poseLead();
    }

    /** How fast the hull itself is rotating, deg/tick. */
    @LuaFunction(mainThread = true)
    public final double getHullRate() throws LuaException {
        return smart().invfix$hullRate();
    }

    /**
     * Fire now. Lets the computer pick the instant - on a wobbling platform a
     * shot only lands true if it leaves while the error is near zero.
     */
    @LuaFunction(mainThread = true)
    public final boolean fire() throws LuaException {
        return smart().invfix$fire();
    }

    /**
     * Arm the gun to fire itself on the first tick its pointing error is within
     * tolDeg of the held direction. The check and the shot happen in the SAME
     * server tick - a computer that reads the error and then calls fire() is
     * always a tick late, which on a floating platform is exactly when the
     * barrel has swung off again. Needs holdWorld active. timeoutTicks 0 disarms.
     */
    @LuaFunction(mainThread = true)
    public final void armAutoFire(double tolDeg, int timeoutTicks) throws LuaException {
        smart().invfix$armAutoFire(tolDeg, timeoutTicks);
    }

    @LuaFunction(mainThread = true)
    public final boolean isArmed() throws LuaException { return smart().invfix$isArmed(); }

    /**
     * Degrees per tick the pointing error is currently moving. On a platform
     * that never settles this never reaches zero; the trigger compensates by
     * predicting one tick ahead rather than waiting for stillness.
     */
    @LuaFunction(mainThread = true)
    public final double getErrorRate() throws LuaException { return smart().invfix$errorRate(); }

    /** Ticks the trigger extrapolates ahead to cancel the contraption's lag. */
    @LuaFunction(mainThread = true)
    public final void setFireLead(double ticks) throws LuaException { smart().invfix$setFireLead(ticks); }

    @LuaFunction(mainThread = true)
    public final double getFireLead() throws LuaException { return smart().invfix$fireLead(); }

    /**
     * What the barrel was doing in the exact tick the last shot left:
     * {az=, elev=, errAz=, errElev=}. Measured inside that tick, so it is the
     * ground truth for calibrating the lead.
     */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getLastShot() throws LuaException {
        double[] v = smart().invfix$lastShot();
        Map<String, Object> m = new HashMap<>();
        m.put("az", v[0]);
        m.put("elev", v[1]);
        m.put("errAz", v[2]);
        m.put("errElev", v[3]);
        // where the mount actually was when the shell left
        m.put("x", v[4]);
        m.put("y", v[5]);
        m.put("z", v[6]);
        // What the controller had just commanded on that tick. az/elev above is
        // what the shell actually got - one tick older. The gap between them is
        // the size of the last slew step, and it used to go straight into the
        // miss.
        m.put("cmdAz", v[7]);
        m.put("cmdElev", v[8]);
        // hull velocity handed to that shell, blocks/tick
        m.put("vpx", v[9]);
        m.put("vpy", v[10]);
        m.put("vpz", v[11]);
        return m;
    }

    /** "idle" | "armed" | "fired" | "timeout" */
    @LuaFunction(mainThread = true)
    public final String getAutoFireState() throws LuaException {
        switch (smart().invfix$autoFireState()) {
            case 1:  return "armed";
            case 2:  return "fired";
            case 3:  return "timeout";
            default: return "idle";
        }
    }

    /**
     * The last cannon projectile's ACTUAL launch state, captured by
     * CannonLaunchWatcher when the shell was added to the world.
     *
     * Diagnostic fields first, because an empty log has three very different
     * causes and the old version could not tell them apart:
     *   hook  - false: the watcher class never loaded, the build is stale
     *   ok    - false: watcher alive, but no shell has ever spawned
     *   age   - ticks since the record; large means this trigger pull produced
     *           no shell (empty breech, squib) and you are reading an old shot
     */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getLastLaunch() throws LuaException {
        Map<String, Object> m = new HashMap<>();
        long now = this.be.getLevel() != null ? this.be.getLevel().getGameTime() : -1L;
        boolean have = LaunchLog.gameTime >= 0;

        m.put("hook", LaunchLog.hookInstalled);
        m.put("ok", have);
        m.put("seen", (double) LaunchLog.seen);
        m.put("age", have && now >= 0 ? (double) (now - LaunchLog.gameTime) : -1.0);

        m.put("id", (double) LaunchLog.entityId);
        m.put("x", LaunchLog.x);
        m.put("y", LaunchLog.y);
        m.put("z", LaunchLog.z);
        m.put("vx", LaunchLog.vx);
        m.put("vy", LaunchLog.vy);
        m.put("vz", LaunchLog.vz);
        m.put("speed", LaunchLog.speed());
        m.put("az", LaunchLog.azimuth());
        m.put("elev", LaunchLog.elevation());
        m.put("gameTime", (double) LaunchLog.gameTime);
        m.put("type", LaunchLog.type);

        // second sample, head of the shell's first tick
        m.put("hasFirst", LaunchLog.firstTickSeen);
        m.put("fx", LaunchLog.fx);
        m.put("fy", LaunchLog.fy);
        m.put("fz", LaunchLog.fz);
        m.put("fspeed", LaunchLog.firstSpeed());
        m.put("faz", LaunchLog.firstAzimuth());
        m.put("felev", LaunchLog.firstElevation());
        return m;
    }

    /** Drop the commanded angles. The mount still holds position while attached. */
    @LuaFunction(mainThread = true)
    public final void stop() throws LuaException { smart().invfix$clearTargets(); }

    /**
     * true  - the computer owns the angles, vanilla rotation is suppressed (default)
     * false - hand the mount back to CBC's kinetic control without unplugging
     */
    @LuaFunction(mainThread = true)
    public final void setHold(boolean hold) throws LuaException { smart().invfix$setHold(hold); }

    @LuaFunction(mainThread = true)
    public final boolean getHold() throws LuaException { return smart().invfix$hold(); }

    /** Degrees per tick (0.01..20). 2.0 is the default, 20 RPM-ish feel. */
    @LuaFunction(mainThread = true)
    public final void setSlewRate(double degPerTick) throws LuaException {
        smart().invfix$setSlewRate((float) degPerTick);
    }

    @LuaFunction(mainThread = true)
    public final double getSlewRate() throws LuaException { return smart().invfix$slewRate(); }

    /** Ticks spent accelerating to full speed and braking. Higher = smoother. */
    @LuaFunction(mainThread = true)
    public final void setRamp(double ticks) throws LuaException {
        smart().invfix$setRampTicks((float) ticks);
    }

    @LuaFunction(mainThread = true)
    public final double getRamp() throws LuaException { return smart().invfix$rampTicks(); }

    /**
     * Degrees per tick each axis can currently do, straight from the kinetics.
     * Zero means that shaft is not turning, so that axis cannot be laid.
     */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getAxisSpeeds() throws LuaException {
        float[] sp = smart().invfix$axisSpeeds();
        Map<String, Object> m = new HashMap<>();
        m.put("yaw", sp[0]);
        m.put("pitch", sp[1]);
        return m;
    }

    // ---------- IPeripheral ----------

    @Override
    public void attach(IComputerAccess computer) {
        if (this.be instanceof SmartCannonMount s) s.invfix$computerAttached(true);
    }

    @Override
    public void detach(IComputerAccess computer) {
        if (this.be instanceof SmartCannonMount s) s.invfix$computerAttached(false);
    }

    @Override
    public String getType() { return "cannon_mount"; }

    @Override
    public boolean equals(@Nullable IPeripheral other) {
        return other instanceof CannonMountPeripheral p && p.be == this.be;
    }

    @Override
    public Object getTarget() { return this.be; }
}