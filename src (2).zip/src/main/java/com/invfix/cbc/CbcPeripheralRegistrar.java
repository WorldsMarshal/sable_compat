package com.invfix.cbc;

import dan200.computercraft.api.peripheral.PeripheralCapability;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import rbasamoyai.createbigcannons.cannon_control.cannon_mount.CannonMountBlockEntity;

/**
 * Exposes the CBC cannon mount to ComputerCraft on every side, so a plain
 * wired modem (or a computer placed flush against it) sees "cannon_mount".
 *
 * The block entity type is looked up from the registry by id rather than
 * through CBC's Registrate entry: the entry is a raw BlockEntityEntry, which
 * breaks generic inference on registerBlockEntity.
 */
@EventBusSubscriber(modid = "sable_compat", bus = EventBusSubscriber.Bus.MOD)
public final class CbcPeripheralRegistrar {

    private CbcPeripheralRegistrar() {}

    /**
     * One peripheral per block entity. The capability provider is called on
     * every query, and the peripheral tracks attach/detach counts, so handing
     * out fresh instances would let that count drift.
     */
    private static final Map<CannonMountBlockEntity, CannonMountPeripheral> CACHE =
            Collections.synchronizedMap(new WeakHashMap<>());

    private static final ResourceLocation CANNON_MOUNT_ID =
            ResourceLocation.fromNamespaceAndPath("createbigcannons", "cannon_mount");

    @SuppressWarnings("unchecked")
    @SubscribeEvent
    public static void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
        ModList mods = ModList.get();
        if (mods == null || !mods.isLoaded("createbigcannons") || !mods.isLoaded("computercraft")) return;

        BlockEntityType<?> raw = BuiltInRegistries.BLOCK_ENTITY_TYPE.get(CANNON_MOUNT_ID);
        if (raw == null) return;   // CBC present but the type moved: fail quietly

        BlockEntityType<CannonMountBlockEntity> type = (BlockEntityType<CannonMountBlockEntity>) raw;
        event.registerBlockEntity(
                PeripheralCapability.get(),
                type,
                (be, side) -> CACHE.computeIfAbsent(be, CannonMountPeripheral::new));
    }
}