package com.invfix.cbc;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/**
 * Fills {@link LaunchLog} with the true launch state of every Create Big
 * Cannons projectile.
 *
 * Why an event and not a mixin: EntityJoinLevelEvent fires from
 * ServerLevel#addEntity, which is downstream of every path a shell can take -
 * CBC's MountedBigCannonContraption, MW's MountedMediumcannonContraption, and
 * Sable's kickEntity, which rewrites position and velocity at the HEAD of
 * addFreshEntity to move the shell out of the sublevel. So what lands here is
 * the world-space state the shell actually flies with, including any velocity
 * inherited from the platform.
 *
 * CBC is an optional dependency, so this class must not import it: the shell is
 * recognised by walking its superclass names instead. That also means it keeps
 * working if CBC renames a subclass.
 */
@EventBusSubscriber(modid = "sable_compat")
public final class CannonLaunchWatcher {

    private CannonLaunchWatcher() {}

    private static final String CBC_PROJECTILE =
            "rbasamoyai.createbigcannons.munitions.AbstractCannonProjectile";

    /** Class check is a hierarchy walk, so cache the verdict per entity class. */
    private static final Map<Class<?>, Boolean> IS_SHELL = new ConcurrentHashMap<>();

    static {
        // The class is loaded when NeoForge scans for @EventBusSubscriber, so
        // reaching this line is proof the handler is registered. Lua reads it
        // back as "hook" and can tell a dead hook from a shot that spawned
        // nothing - the old code could not.
        LaunchLog.hookInstalled = true;
    }

    private static boolean isCannonProjectile(Entity e) {
        return IS_SHELL.computeIfAbsent(e.getClass(), c -> {
            for (Class<?> k = c; k != null; k = k.getSuperclass()) {
                if (CBC_PROJECTILE.equals(k.getName())) return Boolean.TRUE;
            }
            return Boolean.FALSE;
        });
    }

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        Entity e = event.getEntity();
        if (!isCannonProjectile(e)) return;

        Vec3 v = e.getDeltaMovement();
        LaunchLog.record(
                e.getType().toString(), e.getId(),
                e.getX(), e.getY(), e.getZ(),
                v.x, v.y, v.z,
                event.getLevel().getGameTime());
    }

    /**
     * Second sample, taken at the head of the shell's first tick. If the speed
     * here is not the speed at spawn, something is editing the shell between
     * the two - which would explain range errors no amount of angle trimming
     * can fix.
     */
    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Pre event) {
        if (LaunchLog.firstTickSeen) return;
        Entity e = event.getEntity();
        if (e.getId() != LaunchLog.entityId) return;
        if (e.level() == null || e.level().isClientSide) return;

        Vec3 v = e.getDeltaMovement();
        LaunchLog.recordFirstTick(e.getX(), e.getY(), e.getZ(), v.x, v.y, v.z);
    }
}