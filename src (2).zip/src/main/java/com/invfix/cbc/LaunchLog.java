package com.invfix.cbc;

/**
 * Records what a cannon projectile actually got at launch: where it appeared
 * and the velocity vector it was given.
 *
 * Filled by {@link CannonLaunchWatcher} from EntityJoinLevelEvent, i.e. at the
 * moment the shell is added to the world - after CBC has called shoot() and
 * after Sable has kicked it out of the sublevel, which is exactly the state the
 * ballistics model claims to know.
 *
 * The earlier version was filled from a mixin on the projectile's first tick.
 * That never ran, and because the injector was declared with require = 0 it
 * failed silently. There is no mixin here any more: an event handler cannot
 * miss its target class, and hookInstalled proves the handler is alive.
 */
public final class LaunchLog {

    private LaunchLog() {}

    /** true once the watcher class has been loaded and subscribed. */
    public static volatile boolean hookInstalled = false;
    /** how many cannon projectiles the watcher has seen since server start. */
    public static volatile long    seen = 0;

    // ---- state at spawn ----
    public static volatile int    entityId = -1;
    public static volatile double x, y, z;      // spawn position
    public static volatile double vx, vy, vz;   // velocity, blocks per tick
    public static volatile long   gameTime = -1;
    public static volatile String type = "";

    // ---- state at the head of the shell's first tick ----
    // If this differs from the spawn state, something touched the shell
    // between being added to the world and moving for the first time.
    public static volatile boolean firstTickSeen = false;
    public static volatile double  fx, fy, fz;
    public static volatile double  fvx, fvy, fvz;

    public static synchronized void record(String type, int entityId,
                                           double x, double y, double z,
                                           double vx, double vy, double vz, long gameTime) {
        LaunchLog.type = type;
        LaunchLog.entityId = entityId;
        LaunchLog.x = x;   LaunchLog.y = y;   LaunchLog.z = z;
        LaunchLog.vx = vx; LaunchLog.vy = vy; LaunchLog.vz = vz;
        LaunchLog.gameTime = gameTime;
        LaunchLog.firstTickSeen = false;
        LaunchLog.fx = 0; LaunchLog.fy = 0; LaunchLog.fz = 0;
        LaunchLog.fvx = 0; LaunchLog.fvy = 0; LaunchLog.fvz = 0;
        LaunchLog.seen++;
    }

    public static synchronized void recordFirstTick(double x, double y, double z,
                                                    double vx, double vy, double vz) {
        LaunchLog.fx = x;   LaunchLog.fy = y;   LaunchLog.fz = z;
        LaunchLog.fvx = vx; LaunchLog.fvy = vy; LaunchLog.fvz = vz;
        LaunchLog.firstTickSeen = true;
    }

    public static double speed()      { return len(vx, vy, vz); }
    public static double firstSpeed() { return len(fvx, fvy, fvz); }

    /** Minecraft yaw of the velocity vector, degrees. */
    public static double azimuth()      { return az(vx, vz); }
    public static double firstAzimuth() { return az(fvx, fvz); }

    /** Elevation of the velocity vector, degrees. */
    public static double elevation()      { return el(vx, vy, vz); }
    public static double firstElevation() { return el(fvx, fvy, fvz); }

    private static double len(double a, double b, double c) { return Math.sqrt(a*a + b*b + c*c); }
    private static double az(double x, double z)            { return Math.toDegrees(Math.atan2(-x, z)); }
    private static double el(double x, double y, double z)  {
        return Math.toDegrees(Math.atan2(y, Math.sqrt(x*x + z*z)));
    }
}