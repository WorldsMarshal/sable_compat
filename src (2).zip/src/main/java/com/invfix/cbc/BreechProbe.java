package com.invfix.cbc;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ItemStack;
import rbasamoyai.createbigcannons.cannon_control.cannon_mount.CannonMountBlockEntity;
import rbasamoyai.createbigcannons.cannon_control.contraption.AbstractMountedCannonContraption;
import rbasamoyai.createbigcannons.cannon_control.contraption.PitchOrientedContraptionEntity;
import riftyboi.cbcmodernwarfare.cannons.medium_cannon.breech.MediumcannonBreechBlockEntity;
import riftyboi.cbcmodernwarfare.munitions.medium_cannon.MediumcannonAmmoItem;

/**
 * Заряжена ли пушка - тем же вопросом, которым задаётся сам выстрел.
 *
 * MountedMediumcannonContraption.fireShot стреляет, только если в затворе на
 * стартовой позиции контрапции лежит патрон средней пушки и затвор закрыт
 * (canFire: openProgress == 0). После выстрела MW кладёт в затвор пустую
 * гильзу - обычный предмет, не патрон, - так что выстрелянная пушка сама
 * становится незаряженной, пока заряжающий не сменит гильзу на новый патрон.
 *
 * Патрон считается живым, если у него есть тип снаряда: гильза без снаряда
 * формально тоже патрон, но вылетать из неё нечему.
 *
 * Отдельный класс, чтобы классы MW трогались только здесь.
 */
final class BreechProbe {

    private BreechProbe() {}

    static Map<String, Object> state(CannonMountBlockEntity be) {
        Map<String, Object> m = new HashMap<>();
        PitchOrientedContraptionEntity poce = be.getContraption();
        if (poce == null || !(poce.getContraption() instanceof AbstractMountedCannonContraption cannon)) {
            m.put("assembled", false);
            m.put("loaded", false);
            return m;
        }
        m.put("assembled", true);
        BlockPos start = cannon.getStartPos();
        Object at = start == null ? null : cannon.presentBlockEntities.get(start);
        if (!(at instanceof MediumcannonBreechBlockEntity breech)) {
            // не средняя пушка MW: у этих своя механика заряжания
            m.put("medium", false);
            m.put("loaded", false);
            return m;
        }
        ItemStack in = breech.getInputBuffer();
        boolean round = !in.isEmpty()
                && in.getItem() instanceof MediumcannonAmmoItem ammo
                && ammo.getEntityType(in) != null;
        boolean closed = breech.canFire();
        m.put("medium", true);
        m.put("closed", closed);
        m.put("round", round);
        m.put("loaded", round && closed);
        m.put("item", in.isEmpty() ? "" : BuiltInRegistries.ITEM.getKey(in.getItem()).toString());
        return m;
    }
}