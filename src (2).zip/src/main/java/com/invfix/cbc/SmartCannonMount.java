package com.invfix.cbc;

/**
 * Duck-interface implanted into CBC's CannonMountBlockEntity by
 * {@code CannonMountAimMixin}. Lets a ComputerCraft peripheral drive the mount
 * to an exact angle instead of pulsing clutches and reading a rounded display.
 */
public interface SmartCannonMount {

    /** Absolute mount yaw in degrees (same value the Yaw display source shows, unrounded). */
    float invfix$yaw();

    /** Elevation in degrees (same convention as getDisplayPitch(), unrounded). */
    float invfix$pitch();

    /** True while the mount is still slewing toward a commanded angle. */
    boolean invfix$isAiming();

    /** Command an absolute yaw. Pass null to leave the axis free. */
    void invfix$setTargetYaw(Float yawDeg);

    /** Command an elevation, clamped to the cannon's own limits. */
    void invfix$setTargetPitch(Float pitchDeg);

    Float invfix$targetYaw();

    Float invfix$targetPitch();

    /** Abandon both commanded angles; the mount reverts to normal kinetic control. */
    void invfix$clearTargets();

    /**
     * Upper bound in degrees per tick. The real traverse speed is whichever is
     * lower, this cap or what the kinetic input on that axis can deliver.
     */
    void invfix$setSlewRate(float degPerTick);

    float invfix$slewRate();

    /** Ticks spent ramping up to full speed (and braking again). Higher = smoother. */
    void invfix$setRampTicks(float ticks);

    float invfix$rampTicks();

    /** {yaw, pitch} degrees per tick currently available from the shafts. */
    float[] invfix$axisSpeeds();

    /** Called by the peripheral when a computer attaches or detaches. */
    void invfix$computerAttached(boolean attached);

    boolean invfix$hasComputer();

    /**
     * While true (the default) an attached computer owns the angles and the
     * vanilla kinetic rotation is suppressed. Set false to let CBC drive the
     * mount normally without unplugging the modem.
     */
    void invfix$setHold(boolean hold);

    boolean invfix$hold();

    /** Elevation limits of the currently mounted cannon, or null when nothing is assembled. */
    float[] invfix$pitchLimits();

    boolean invfix$isAssembled();

    /**
     * World position of the mount, projected out of the Sable sublevel if the
     * rig is riding one. {x, y, z}. On a static build this is just the block.
     */
    double[] invfix$worldPos();

    /**
     * World position of a point sitting {@code up} blocks above the mount along
     * the HULL's own up axis - the pivot the cannon turns about. Adding the
     * offset vertically in world space is only right while the platform is
     * level; a tilting airframe moves the pivot sideways too.
     */
    double[] invfix$pivotPos(double up);

    /**
     * Heading of the hull in world space, degrees, Minecraft yaw convention
     * (0 = +Z). Zero for a static build. Add the mount yaw to get the true
     * world azimuth of the barrel.
     */
    double invfix$hullYaw();

    /** True when the mount is riding a Sable sublevel rather than the world. */
    boolean invfix$onSublevel();

    /**
     * True world direction of the barrel as {azimuth, elevation} in degrees,
     * with the hull's full orientation applied - yaw, pitch AND roll. On a
     * tilted vehicle this is what the shell actually follows; mount pitch
     * alone is not enough.
     */
    double[] invfix$boreWorld();

    /**
     * Aim at an absolute world azimuth/elevation. The hull orientation is
     * inverted out, so the mount is given the angles that put the barrel on
     * that world heading no matter how the vehicle is parked.
     */
    void invfix$aimWorld(double azDeg, double elDeg);

    /**
     * Hold an absolute world direction. Unlike aimWorld, which converts once,
     * this is re-solved from the hull orientation EVERY TICK, so the barrel
     * stays on the world heading while the platform wobbles underneath it.
     * Pass null to release.
     */
    void invfix$holdWorld(Double azDeg, Double elDeg);

    boolean invfix$isHoldingWorld();

    /** {azError, elError} degrees between the barrel and the held direction. */
    double[] invfix$worldError();

    /**
     * The world direction the shell would actually leave along if the trigger
     * were pulled this tick: {az, elev}.
     *
     * Not the same as invfix$boreWorld(). CBC reads the contraption transform at
     * partialTick 0, which is the previous tick's orientation, so a barrel that
     * moved this tick fires along where it was, not where it is.
     */
    /**
     * Barrel servo. Turn it OFF to freeze the barrel where it is while still
     * tracking the world target: the trigger keeps watching, and the hull's own
     * swing carries the bore through the solution. On an airframe where every
     * traverse shifts the centre of mass this is the only way to get a settled
     * shot - a barrel that keeps correcting keeps the hull rocking.
     */
    /**
     * Tracking load: {demandYaw, demandPitch, supplyYaw, supplyPitch}, deg/tick.
     * Demand above supply means the hull is turning faster than the shafts can
     * follow - the cure is rotational speed and a higher slew cap, not more
     * prediction.
     */
    double[] invfix$trackLoad();

    void invfix$setServo(boolean on);

    boolean invfix$servoOn();

    /** Aiming error below which the barrel is not moved at all, degrees. */
    void invfix$setDeadband(double deg);

    double invfix$deadband();

    /**
     * Ticks of hull rotation to extrapolate when converting the world hold into
     * barrel angles. Must be 1 on a moving platform: the angles set this tick
     * meet the hull pose of the next one.
     */
    void invfix$setPoseLead(double ticks);

    double invfix$poseLead();

    /** How fast the hull is rotating on its own, deg/tick. */
    double invfix$hullRate();

    /**
     * Velocity the hull will add to the shell at the muzzle, world frame,
     * blocks per tick. Sable hands the projectile linearVelocity + omega x r at
     * its spawn point; on a drifting airframe this is the largest remaining
     * source of dispersion, because the shell carries it for the whole flight.
     */
    double[] invfix$hullVelocity();

    /** {sable x,y,z, finite-difference x,y,z} in blocks/tick, for diagnosis. */
    double[] invfix$hullVelocitySources();

    /** {az, elev, speed} of what the shell would actually leave with. */
    /** Elliptical firing gate: separate tolerance per axis, degrees. */
    void invfix$setFireTolAxes(double tolAz, double tolEl);

    double[] invfix$launchVector();

    /** Hold so the SHELL flies this way, hull motion compensated every tick. */
    void invfix$holdLaunch(Double azDeg, Double elDeg);

    /** Muzzle speed and mount geometry, needed for the hull-motion correction. */
    void invfix$setBallistics(double v0, double pivotUp, double barrelLen);

    /** |V0*bore + hullVelocity| for the current solution - not V0. */
    double invfix$launchSpeed();

    double[] invfix$launchBore();

    /** Error of invfix$launchBore() against the world hold: {az, elev}. */
    double[] invfix$launchError();

    /** Pull the trigger, as if a redstone edge arrived on the mount. */
    boolean invfix$fire();

    /**
     * Arm the gun to fire itself on the first tick the pointing error is within
     * tolerance. Checking and firing must happen in the SAME tick: a computer
     * that reads the error and then calls fire() is always a tick or more late,
     * which on a floating platform is exactly when the barrel has swung off
     * again. Timeout is in ticks; 0 disarms.
     */
    void invfix$armAutoFire(double tolDeg, int timeoutTicks);

    boolean invfix$isArmed();

    /** 0 = idle, 1 = armed and waiting, 2 = fired, 3 = timed out. */
    int invfix$autoFireState();

    /** How fast the pointing error is changing, degrees per tick. */
    double invfix$errorRate();

    /**
     * How many ticks ahead the trigger extrapolates - fractional, because the
     * measured lag is not a whole tick. Two shots with different hull wobble
     * both missed by 0.70 and 0.80 of one tick's worth of angular motion, so
     * 0.75 is the fitted value. With a still platform any value works; the lag
     * only shows up once the airframe is moving.
     */
    void invfix$setFireLead(double ticks);

    double invfix$fireLead();

    /**
     * Everything about the last shot, captured IN the tick it went off:
     * {az, elev, errAz, errEl, mountX, mountY, mountZ}. The mount position
     * matters as much as the angles: the computer reads the platform's place
     * before arming, but the shot leaves later, and a drifting airframe means
     * the shell starts somewhere else entirely.
     */
    double[] invfix$lastShot();

    /**
     * Опорное решение для поправки на каждом тике: tx ty tz, tvx tvy tvz, t0,
     * az0 el0, R0 dy0 s0, cR cDy cS. null снимает поправку.
     */
    void invfix$setLaunchRef(double[] ref);

    /** {active, dEl, dR, dDy, dS} последнего тика. */
    double[] invfix$launchRefState();
}