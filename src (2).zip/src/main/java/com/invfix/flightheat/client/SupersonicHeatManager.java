package com.invfix.flightheat.client;

import com.invfix.flightfx.FlightFxTracker;
import com.invfix.kineticstrike.client.KineticStrikeClient;
import net.mcreator.invincibleinc.network.InvincibleIncModVariables;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Клиентский «нагрев» летящего 0..1 — общий для свечения модели
 * (AtmosphericHeatLayer) и плазмы в визуале полёта (FlightFx), чтобы тело и
 * воздух вокруг грелись вместе.
 *
 * На малых скоростях воздух только конденсируется (белый конус пара, без
 * огня); греться начинает примерно с flightSpeed 5.7, полностью — на 9 (шкала
 * визуала сжата: 3 → 9). Рывок Kinetic Strike — полностью. Набирается за
 * ~2 с, остывает за ~1 с.
 */
@EventBusSubscriber(modid = "sable_compat", value = Dist.CLIENT)
public final class SupersonicHeatManager {

    /** Порог полёта, с которого вообще считается нагрев (flightSpeed >= 3). */
    public static final double SUPERSONIC_SPEED = 3.0;

    private static final float RAMP_UP   = 1.0f / 40.0f; // ~2 секунды до максимума
    private static final float RAMP_DOWN = 1.0f / 20.0f; // ~1 секунда остывание

    private static final Map<UUID, Float> HEAT = new HashMap<>();

    private SupersonicHeatManager() {}

    public static float getHeat(UUID id) {
        return HEAT.getOrDefault(id, 0.0f);
    }

    /** Нагрев, к которому стремится летящий: по сжатой шкале визуала (FlightFxTracker.visualSpeed) — полный на flightSpeed 9. */
    static float targetFor(double flightSpeed) {
        double x = Math.max(0.0, Math.min(1.0, (FlightFxTracker.visualSpeed(flightSpeed) - 8.0) / 5.0));
        return (float) (x * x * (3.0 - 2.0 * x));
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) { HEAT.clear(); return; }
        if (mc.isPaused()) return;

        for (AbstractClientPlayer player : mc.level.players()) {
            float target = 0.0f;
            if (KineticStrikeClient.isDashing(player.getId())) {
                target = 1.0f;
            } else {
                try {
                    InvincibleIncModVariables.PlayerVariables v =
                            player.getData(InvincibleIncModVariables.PLAYER_VARIABLES);
                    // греется только настоящий быстрый полёт (замер трекера), не медленное перемещение
                    if (v.flightSpeed >= SUPERSONIC_SPEED && FlightFxTracker.isFast(player.getId())) {
                        target = targetFor(v.flightSpeed);
                    }
                } catch (Exception ignored) {}
            }

            UUID id = player.getUUID();
            float cur = HEAT.getOrDefault(id, 0.0f);
            cur = cur < target ? Math.min(target, cur + RAMP_UP) : Math.max(target, cur - RAMP_DOWN);
            if (cur <= 0.0f) HEAT.remove(id);
            else HEAT.put(id, cur);
        }
        // чистим отключившихся
        HEAT.keySet().removeIf(id -> mc.level.players().stream().noneMatch(p -> p.getUUID().equals(id)));
    }
}
