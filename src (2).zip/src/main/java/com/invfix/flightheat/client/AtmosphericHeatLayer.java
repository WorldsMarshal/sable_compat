package com.invfix.flightheat.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

/**
 * Слой атмосферного нагрева: раскалённое оранжево-красное свечение поверх модели
 * игрока при сверхзвуковом полёте. Портировано из viltrumiteflight.
 *
 * Перерисовывает модель игрока 3 раза с лёгким увеличением и дрожанием,
 * через energySwirl (бегущая UV), цветом от чёрного к (1.0, 0.8, 0.2).
 */
@OnlyIn(Dist.CLIENT)
public class AtmosphericHeatLayer
        extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {

    private static final ResourceLocation WHITE_TEXTURE =
            ResourceLocation.withDefaultNamespace("textures/block/white_concrete.png");

    public AtmosphericHeatLayer(
            RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffers, int packedLight,
                       AbstractClientPlayer player, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {

        float heat = SupersonicHeatManager.getHeat(player.getUUID());
        if (heat <= 0.0f) return;

        float time = (float) player.tickCount + partialTick;
        float maxR = 1.0f;
        float maxG = Mth.lerp(heat, 0.0f, 0.8f);
        float maxB = Mth.lerp(heat, 0.0f, 0.2f);
        float baseIntensity = heat;

        int glowLight = 15728880; // full-bright

        RenderType rt = RenderType.energySwirl(WHITE_TEXTURE, time * 0.015f, time * 0.015f);
        VertexConsumer vc = buffers.getBuffer(rt);

        poseStack.pushPose();
        poseStack.translate(0.0, 0.0225, 0.0);

        for (int i = 0; i < 3; i++) {
            poseStack.pushPose();
            float jitter = (float) Math.sin(time * 5.0f + i) * 0.005f * heat;
            float scale = 1.0625f + jitter;
            poseStack.translate(0.0, 1.0, 0.0);
            poseStack.scale(scale, scale, scale);
            poseStack.translate(0.0, -1.0, 0.0);

            float intensity = baseIntensity / (i + 1);
            int r = (int) (maxR * intensity * 255.0f);
            int g = (int) (maxG * intensity * 255.0f);
            int b = (int) (maxB * intensity * 255.0f);
            int color = 0xFF000000 | (clamp(r) << 16) | (clamp(g) << 8) | clamp(b);

            this.getParentModel().renderToBuffer(
                    poseStack, vc, glowLight, OverlayTexture.NO_OVERLAY, color);
            poseStack.popPose();
        }

        poseStack.popPose();
    }

    private static int clamp(int v) {
        return v < 0 ? 0 : Math.min(v, 255);
    }
}